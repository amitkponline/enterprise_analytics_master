package com.hpe.utils

import java.text.{ParseException, SimpleDateFormat}
import java.util.{Arrays, Date}

import org.apache.log4j.Logger


object DataQuality {
  val log = Logger.getLogger(getClass.getName)
  def isThisDateValid(dateToValidate: String, dateFormat: String): Boolean = {

    var flag = false
    if (dateToValidate == null) {
      false
    }
    val sdf: SimpleDateFormat = new SimpleDateFormat(dateFormat)
    sdf.setLenient(false)
    try {
      //if not valid, it will throw ParseException
      val date: Date = sdf.parse(dateToValidate)
      flag = true
    } catch {
      case e: ParseException => {
        e.printStackTrace()
        // flag = false
      }

    }
    flag
  }

  def DQValidchck(
    message:       String,
    colNm:         String,
    msgdelimeter:  String,
    NulchkCol:     String,
    lnchkVal:      String,
    DtfmtchkCol:   String,
    intchkCol:     String,
    doublechkCol:  String,
    booleanchkCol: String,
    longchkCol:String): String = {
    // Will store the reject Message
    var returnMsg = "VALID"
    var dataqualitychkmsg: String = ""
    if(!message.contains("com.fasterxml.jackson.core.JsonParseException")){
    if (message != null && colNm != null) {
      val msgArry: Array[String] = message.split(msgdelimeter, -1)
      var arrLen: Int = msgArry.length
      var colNam: Array[String] = colNm.toLowerCase().split(",")
      if (NulchkCol.trim().length() != 0) {
        val nulCol: Array[String] = NulchkCol.toLowerCase().split(",")
        var nulcllen: Int = nulCol.length
        // Null Check on required Columns
        try while (nulcllen > 0) {
          nulcllen = nulcllen - 1
          val indx: Int = Arrays.asList(colNam: _*).indexOf(nulCol(nulcllen).trim())
          if (msgArry(indx).trim() == null || msgArry(indx).trim().==("") || ("null").equalsIgnoreCase(msgArry(indx).trim()) || msgArry(indx).trim().equalsIgnoreCase("nul") || msgArry(indx).trim().length == 0) {
            dataqualitychkmsg = dataqualitychkmsg + " | " + colNam(indx) + " column is null"
          }

        } catch {
          case ex: Exception =>
            dataqualitychkmsg = dataqualitychkmsg + "|" + ex + " Exception during null check"

        }
      }
      if (lnchkVal.trim().length() != 0) {
        val lnchkCol: Array[String] = lnchkVal.toLowerCase().split(",")
        // Length Check on all columns
        var arrLen: Int = lnchkCol.length
        try while (arrLen > 0) {
          arrLen = arrLen - 1
          val msgAndLenght: Array[String] = lnchkCol(arrLen).split("\\|")
          val indx: Int = Arrays.asList(colNam: _*).indexOf(msgAndLenght(0).trim())
          if ((msgArry(indx).trim() != null && !("null").equalsIgnoreCase(msgArry(indx).trim())) && msgArry(indx).trim().length > java.lang.Integer.parseInt(msgAndLenght(1))) {
            dataqualitychkmsg = dataqualitychkmsg + " | " + colNam(indx) + " column length exceeds"
          }

        } catch {
          case ex: Exception =>
            dataqualitychkmsg = dataqualitychkmsg + "|" + ex + " Exception during length check"

        }
      }
      if (DtfmtchkCol != null && DtfmtchkCol.trim.length() != 0 && !"null".equalsIgnoreCase("DtfmtchkCol")) {
        val dateFrmt: Array[String] = DtfmtchkCol.split(",")
        var dtarrlen: Int = dateFrmt.length
        // Date Format Check on all required columns
        try while (dtarrlen > 0) {
          dtarrlen = dtarrlen - 1
          val datepattrn: Array[String] = dateFrmt(dtarrlen).split("\\|")
          val indx: Int = Arrays.asList(colNam: _*).indexOf(datepattrn(0).toLowerCase().trim())
          if (msgArry(indx).trim() != null && msgArry(indx).trim().length() > 0 && !msgArry(indx).trim().equalsIgnoreCase("null")) {
            if (msgArry(indx).trim() != ("00000000000000") && msgArry(indx).trim() != ("0") && msgArry(indx).trim() != ("00000000") && !(isThisDateValid(msgArry(indx).trim(), datepattrn(1)))) {
              //log.info(msgArry(indx).trim())
              //log.info(datepattrn(1))
              dataqualitychkmsg = dataqualitychkmsg + " | " + colNam(indx) + " column has Date format mismatch"
            }
          }

        } catch {
          case ex: Exception =>
            dataqualitychkmsg = dataqualitychkmsg + "|" + ex + " Exception while Date check"

        }
      }
      if (intchkCol != null && intchkCol.!=("") && intchkCol.length > 0) {
        val inChkcol: Array[String] = intchkCol.toLowerCase().split(",")
        var intChklen: Int = inChkcol.length
        // Integer data type Check on required Columns
        try while (intChklen > 0) {
          intChklen = intChklen - 1
          val indx: Int =
            Arrays.asList(colNam: _*).indexOf(inChkcol(intChklen).trim())
          //val intStringPattern: String = "^\\d+$"
          if ((msgArry(indx).trim() != null && msgArry(indx).trim() != ("") && !"null".equalsIgnoreCase(msgArry(indx).trim()))) {
            try {
              if (msgArry(indx).trim().contains(".") && (msgArry(indx).trim().size - (msgArry(indx).trim().substring(0, msgArry(indx).trim().lastIndexOf(".")).size)) == 2) {
                msgArry(indx).trim().substring(0, msgArry(indx).trim().lastIndexOf(".")).toInt
              } else {
                msgArry(indx).trim().toInt
                //dataqualitychkmsg = dataqualitychkmsg + " | " + colNam(indx) + " column is Not an Integer"
              }
            } catch {
              case ex: Exception =>
                log.info(ex)
                dataqualitychkmsg = dataqualitychkmsg + " | " + colNam(indx) + " column is Not an Integer"

            }
          }

        } catch {
          case ex: Exception =>
            dataqualitychkmsg = dataqualitychkmsg + "|" + ex + " Exception while Integer check"

        }
      }
      //Double data type check
      if (doublechkCol != null && doublechkCol.!=("") && doublechkCol.length > 0) {
        val dblChkcol: Array[String] = doublechkCol.toLowerCase().split(",")
        var dblChklen: Int = dblChkcol.length

        try {
          while (dblChklen > 0) {
            dblChklen = dblChklen - 1
            //log.info(dblChkcol(dblChklen))
            val indx: Int = Arrays.asList(colNam: _*).indexOf(dblChkcol(dblChklen).trim())
            // val dblStringPattern: String = "[-+]?[0-9]+(\\.){0,1}[0-9]*"
            if ((msgArry(indx).trim() != null && msgArry(indx).trim() != ("") && !"null".equalsIgnoreCase(msgArry(indx).trim()) &&
              msgArry(indx).trim() != ("0"))) {
              try {
                msgArry(indx).trim().toDouble
              } catch {
                case ex: Exception =>
                  dataqualitychkmsg = dataqualitychkmsg + " | " + colNam(indx) + " column is Not an Double"

              }

            }

          }
        } catch {
          case ex: Exception =>
            log.info(ex)
            dataqualitychkmsg = dataqualitychkmsg + "|" + ex + " Exception while Double check"

        }
      }

      //Boolean data type check
      if (booleanchkCol != null && booleanchkCol.!=("") && booleanchkCol.length > 0) {
        val booleanChkCols: Array[String] = booleanchkCol.toLowerCase().split(",")
        var booleanChklen: Int = booleanChkCols.length
        try {
          while (booleanChklen > 0) {
            booleanChklen = booleanChklen - 1
            val indx: Int = Arrays.asList(colNam: _*).indexOf(booleanChkCols(booleanChklen).trim())
            //log.info(indx+ " colname "+ booleanChkCols(booleanChklen)+" value=="+msgArry(indx).trim())
            
            // val dblStringPattern: String = "[-+]?[0-9]+(\\.){0,1}[0-9]*"
            if ((msgArry(indx).trim() != null && msgArry(indx).trim() != ("") && !"null".equalsIgnoreCase(msgArry(indx).trim()))) {
              try {
                //log.info("test")
                msgArry(indx).trim().toBoolean
              } catch {
                case ex: Exception =>
                  dataqualitychkmsg = dataqualitychkmsg + " | " + colNam(indx) + " column is Not an Boolean"

              }

            }

          }
        }
        catch {
          case ex: Exception =>
            dataqualitychkmsg = dataqualitychkmsg + "|" + ex + " Exception while Boolean check"

        }
      }
      if (longchkCol != null && longchkCol.!=("") && longchkCol.length > 0) {
        val lngChkcol: Array[String] = longchkCol.toLowerCase().split(",")
        var longChklen: Int = lngChkcol.length
        // Integer data type Check on required Columns
        try while (longChklen > 0) {
          longChklen = longChklen - 1
          val indx: Int =
            Arrays.asList(colNam: _*).indexOf(lngChkcol(longChklen).trim())
          //val intStringPattern: String = "^\\d+$"
          if ((msgArry(indx).trim() != null && msgArry(indx).trim() != ("") && !"null".equalsIgnoreCase(msgArry(indx).trim()))) {
            try {
              msgArry(indx).trim().toLong
              //dataqualitychkmsg = dataqualitychkmsg + " | " + colNam(indx) + " column is Not a Long Integer
            } catch {
              case ex: Exception =>
                log.info(ex)
                dataqualitychkmsg = dataqualitychkmsg + " | " + colNam(indx) + " column is Not a Long/BIG Integer"

            }
          }

        } catch {
          case ex: Exception =>
            dataqualitychkmsg = dataqualitychkmsg + "|" + ex + " Exception while Long check"

        }
      }

    }
    }else{
      dataqualitychkmsg = "Exception while parsing JSON"
    }
    if (dataqualitychkmsg.trim.length() > 0) {
      returnMsg = "INVALID " + "|" + dataqualitychkmsg
    }
    returnMsg
  }
}

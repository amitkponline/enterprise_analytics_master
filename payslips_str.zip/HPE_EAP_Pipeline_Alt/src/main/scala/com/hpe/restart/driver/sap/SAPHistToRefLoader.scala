package com.hpe.restart.driver.sap

import java.net.ConnectException
import java.util.HashMap

import com.hpe.config.{ StreamingPropertiesObject, _ }
import com.hpe.utils.{ DataQuality, Utilities }
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, AnalysisException, Row }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{ StringType, StructField, StructType }
import org.apache.spark.storage.StorageLevel

import scala.collection.Map
import java.sql.Connection
import com.github.opendevl.JFlat

object SAPHistToRefLoader {

  //Initialized Log
  val logger = Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    if (args == null || args.isEmpty || args.length != 1) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Properties file path>")
      println("Stopping the flow")
      System.exit(1)
    }
    logger.info("Number of argument passed is:::" + args.length)

    try {
      val propertiesFilePath = String.valueOf(args(0).trim())
      val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
      var offsetColumnName = "intgtn_fbrc_msg_id"

      val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
      val configurationObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
      val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
      val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
      val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
      val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)

      val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()

      var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
      import scala.collection.JavaConversions._
      val tblMappingArr = propertiesObject.getTableNameMapping().split(",")
      val idocColumnName = propertiesObject.getFilterExpression()
      var idocCrtDt: String = null
      if (propertiesObject.getIdocCrtDtTs() != null) {
        idocCrtDt = propertiesObject.getIdocCrtDtTs()
      }

      logger.info("Mapping Array: " + tblMappingArr.foreach { println })
      val tblTopicMap: Map[String, String] = new HashMap[String, String]()
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      for (element <- tblMappingArr) {
        logger.info("****************************" + element)
        val topic = element.split("\\|")(0)
        val histTbl = element.split("\\|")(1)
        tblTopicMap.put(topic, histTbl)
      }

      val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
      val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
      val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
      val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
      val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)

      auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
      auditObj.setAudObjectName(propertiesObject.getObjName())
      var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
      auditObj.setAudJobStartTimeStamp(startTime)
      auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
      auditObj.setAudSrcRowCount(0)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configurationObject.getSpark().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)

      val spark = configurationObject.getSpark()
      val appName = configurationObject.getSpark().sparkContext.appName
      val appId = configurationObject.getSpark().sparkContext.applicationId
      var isAppAlreadyRunning = Utilities.isJobAlreadyRunning(envPropertiesObject, appName, appId)
      logger.info("============isAppAlreadyRunning::::" + isAppAlreadyRunning)
      if (!isAppAlreadyRunning) {
        val errTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblErr()
        val rwTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw()
        val refTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef()

        val dataDFRef = spark.sqlContext.sql(f"""select * from $refTblNm limit 0""")
        val colListRef = dataDFRef.columns
        val dataDF = spark.sqlContext.sql(f"""select * from $errTblNm limit 0""")
        val colList = dataDF.columns
        val dataDFRaw = spark.sqlContext.sql(f"""select * from $rwTblNm limit 0""")
        val colListRaw = dataDFRaw.columns

        var ctrlTblPresentFlag = false
        logger.info("Control Table Name::" + propertiesObject.tgt_ctrl_tbl)
        if (propertiesObject.getTgt_ctrl_tbl == null) {
          ctrlTblPresentFlag = false
        } else {
          ctrlTblPresentFlag = true
        }

        var schema = StructType(propertiesObject.getColListSep().split(propertiesObject.getRcdDelimiter()).map(fieldName => StructField(fieldName, StringType, true)))
        val offset_schema = StructType(Array(StructField("intgtn_fbrc_msg_id", StringType, true)))
        schema = StructType(schema ++ offset_schema )

        // Registering all the UDFs
        val jsonToFlatUDF = udf(Utilities.jsonToString _)
        val putNullToFlatUDF = udf(Utilities.nullPutUDF _)
        val dqvalidate = udf(DataQuality.DQValidchck _)

        val dateFormatQuery = Utilities.prepareDateDoubleFormatQuery(colListRaw, propertiesObject.getDateCastFields(), propertiesObject.getDoublechkCol)
        val dateFormatQueryRef = Utilities.prepareDateDoubleFormatQuery(colListRef, propertiesObject.getDateCastFields(), propertiesObject.getDoublechkCol)
        val json_hive_raw_map_rdd = spark.sparkContext.parallelize(Seq(propertiesObject.getHiveJsonRawMap()))
        var json_hive_ctrl_map_rdd: RDD[String] = null
        var json_hive_total_map_rdd: RDD[String] = null
        var colListCtrl: Array[String] = null
        if (ctrlTblPresentFlag == true) {
          var ctrlTblNm = propertiesObject.getDbName + "." + propertiesObject.getTgt_ctrl_tbl
          val dataDFCtrl = spark.sqlContext.sql(f"""select * from $ctrlTblNm limit 0""")
          colListCtrl = dataDFCtrl.columns
          json_hive_ctrl_map_rdd = spark.sparkContext.parallelize(Seq(propertiesObject.getHiveJsonCtrlMap()))
          json_hive_total_map_rdd = json_hive_ctrl_map_rdd.union(json_hive_raw_map_rdd)
        } else {
          json_hive_total_map_rdd = json_hive_raw_map_rdd
        }
        val jsonHeaderList: String = Utilities.getJsonHeaders(json_hive_total_map_rdd, propertiesObject.getRcdDelimiter())

        val auditBatchId = ld_jb_nr + "_" + batchId
        var rawSqlQuery = Utilities.final_hive_json_mapper(json_hive_raw_map_rdd)
        logger.info("idocCrtDt=====" + idocCrtDt)
        rawSqlQuery = rawSqlQuery.replace("FROM Temp_DF", ",intgtn_fbrc_msg_id as intgtn_fbrc_msg_id,'' AS src_sys_upd_ts, '" + src_sys_ky + "' as src_sys_ky, '' AS lgcl_dlt_ind,  current_timestamp() AS ins_gmt_ts, " + idocCrtDt + " AS upd_gmt_ts, '' AS src_sys_extrc_gmt_ts," + idocColumnName + " AS src_sys_btch_nr, '" + fl_nm + "'  AS fl_nm, '" + auditBatchId + "' AS ld_jb_nr FROM Temp_DF")
        var ctrlSqlQuery = ""
        if (ctrlTblPresentFlag == true) {
          ctrlSqlQuery = Utilities.final_hive_json_mapper(json_hive_ctrl_map_rdd)
          ctrlSqlQuery = ctrlSqlQuery.replace("FROM Temp_DF", ",intgtn_fbrc_msg_id as intgtn_fbrc_msg_id,'' AS src_sys_upd_ts, '" + src_sys_ky + "' as src_sys_ky, '' AS lgcl_dlt_ind,  current_timestamp() AS ins_gmt_ts, " + idocCrtDt + " AS upd_gmt_ts, '' AS src_sys_extrc_gmt_ts," + idocColumnName + " AS src_sys_btch_nr, '" + fl_nm + "'  AS fl_nm, '" + auditBatchId + "' AS ld_jb_nr FROM Temp_DF")
        }
        auditObj.setAudBatchId(auditBatchId)
        val eff_frm_date = Utilities.getCurrentTimestamp()

        val topicList = propertiesObject.topicList.split(",").toList
        for (topic <- topicList) {
          val histTbl = propertiesObject.getDbName() + "." + tblTopicMap(topic)
          var sqlCon = Utilities.getConnection(envPropertiesObject)
          var lastMaxLoadTs: String = Utilities.readHistMaxLoadTimestamp(sqlCon, propertiesObject.getObjName(), auditTbl);
          val lastMaxLoadDt = lastMaxLoadTs.substring(0, 10)
          logger.info("#############Last loaded timestamp lastMaxLoadTs##################=" + lastMaxLoadTs)
          
          var dfLoc = spark.sql("describe formatted " + histTbl)
          import spark.implicits._
          var rows = dfLoc.filter(dfLoc("col_name").contains("ins_gmt_dt") && dfLoc("data_type").contains("date")).select("col_name").distinct.as[String].collect
          val partitionCol = if (rows != null && rows.toList.length > 0) rows(0) else null
          var histDf: DataFrame = null
          if (partitionCol != null) {
            histDf = configurationObject.getSpark().sql(f"""select payload,cast($offsetColumnName  as string) as intgtn_fbrc_msg_id,ins_gmt_ts from $histTbl where ins_gmt_dt >= '$lastMaxLoadDt' and ins_gmt_ts > '$lastMaxLoadTs'""")
          } else {
            histDf = configurationObject.getSpark().sql(f"""select payload,cast($offsetColumnName  as string) as intgtn_fbrc_msg_id,ins_gmt_ts from $histTbl where ins_gmt_ts > '$lastMaxLoadTs'""")
          }
          //var histDf = configurationObject.getSpark().sql(f"""select payload,cast($offsetColumnName  as string) as intgtn_fbrc_msg_id,ins_gmt_ts from $histTbl where ins_gmt_dt >= '$lastMaxLoadDt' and ins_gmt_ts > '$lastMaxLoadTs'""")
          /* Selecting Unique records from Payload in History table */
          histDf = histDf.dropDuplicates("payload")
          // //Start Time for hist_control load
          startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
          auditObj.setAudJobStartTimeStamp(startTime)
          var dupChkWndw = if (propertiesObject.getDupChkWndw() != null) propertiesObject.getDupChkWndw().toInt else 7
          dfLoc = spark.sql("describe formatted " + propertiesObject.getDbName() + "." + propertiesObject.getTgt_ctrl_tbl())
          rows = dfLoc.filter(dfLoc("col_name").contains("ins_gmt_dt") && dfLoc("data_type").contains("date")).select("col_name").distinct.as[String].collect
          val partitionColCtrl = if (rows != null && rows.toList.length > 0) rows(0) else null
          var existingControlIdocs: List[String] = null
          if (partitionColCtrl != null) {
            existingControlIdocs = spark.sql("select distinct idoc_nr from " + propertiesObject.getDbName() + "." + propertiesObject.getTgt_ctrl_tbl() + " where ins_gmt_dt>=date_sub(current_date," + dupChkWndw + ")").collect.map(row => row.getString(0)).toList
          } else {
            existingControlIdocs = spark.sql("select distinct idoc_nr from " + propertiesObject.getDbName() + "." + propertiesObject.getTgt_ctrl_tbl() + " where to_date(ins_gmt_ts)>=date_sub(current_date," + dupChkWndw + ")").collect.map(row => row.getString(0)).toList
          }
          auditObj.setAudDataLayerName("hist_ctrl")
          if (!histDf.head(1).isEmpty) {
            // Parsing JSON

            logger.info("########+++++++============>REGISTERING UDF===================#####")
            logger.info("########+++++++============>propertiesObject.getColListSep()===================#####" + propertiesObject.getColListSep())
            val currentMaxTs = histDf.agg(max("ins_gmt_ts")).first().getTimestamp(0).toString()
            import spark.implicits._
            val final_df = histDf.flatMap((row: Row) => {
              import spark.implicits._
              val payload = row.getString(0)
              val intFabric = row.getString(1)
              val flatMe = new JFlat(payload)
              val intResult = flatMe.json2Sheet().headerSeparator("_").getJsonAsSheet()
              var headerTrimmedList: List[String] = null
              val headerString = intResult.get(0).toList.map(_.toString.toUpperCase().replaceAll("[@:-]| ", "_").replaceAll("[()]", ""))
              headerTrimmedList = headerString.map(_.toString.trim)
              val listRes = intResult.map { res =>
                (res.toList.map(str => Option(str).getOrElse("")).mkString(propertiesObject.getRcdDelimiter()), headerTrimmedList.toList.mkString(propertiesObject.getRcdDelimiter()), intFabric)
              }
              listRes.toList.map(x => (x._1.toString, x._2.toString, x._3.toString))
            }).toDF("updatedCol", "header", "intgtn_fbrc_msg_id")

            var final_df2 = final_df.filter(!lower(final_df.col("updatedCol")).contains(propertiesObject.getFilterExpression().toLowerCase()))

            //final_df2.persist(StorageLevel.MEMORY_AND_DISK)
            final_df2.createOrReplaceTempView("testdf")
            final_df2 = spark.sqlContext.sql("select * from testdf where length(trim(updatedCol))<>0")
            import spark.implicits._
            //final_df2.repartition($"intgtn_fbrc_msg_id")
            final_df2 = final_df2.withColumn("dataWithNull", putNullToFlatUDF(final_df2("updatedCol"), lit(propertiesObject.getRcdDelimiter()), final_df2("header"), lit(propertiesObject.getColListSep())))
            final_df2 = final_df2.drop("header", "updatedCol")

            logger.info("Raw SQL===================" + rawSqlQuery)
            var rdd = final_df2.select("dataWithNull", "intgtn_fbrc_msg_id").rdd.map { row: Row => (row.getString(0) + propertiesObject.getRcdDelimiter() + row.getString(1)).substring(if ((row.getString(0).head).equals('"')) 1 else 0, (row.getString(0) + propertiesObject.getRcdDelimiter() + row.getString(1)).length()).replaceAll("\"" + propertiesObject.getRcdDelimiter(), propertiesObject.getRcdDelimiter()).replaceAll(propertiesObject.getRcdDelimiter() + "\"", propertiesObject.getRcdDelimiter()).replaceAll("\"" + propertiesObject.getRcdDelimiter() + "\"", propertiesObject.getRcdDelimiter()).replaceAll("\\\\\"", "\"").replaceAll("\n", System.lineSeparator()) }.map(line => line.split(propertiesObject.getRcdDelimiter(), -1)).map(line => Row.fromSeq(line))
            var loadingDF = spark.createDataFrame(rdd, schema)
            //loadingDF.persist(StorageLevel.MEMORY_AND_DISK)
            loadingDF.createOrReplaceTempView("Temp_DF")
            logger.info("Raw SQl::::::::::::::::" + rawSqlQuery)
            var rawDF_curr = spark.sqlContext.sql(rawSqlQuery)
            logger.info("#####################  ALL DONE #####################")
            var src_count = histDf.count
            var tgt_count: Long = 0
            var err_count: Long = 0
            var loadStatus: Boolean = false
            var partitionDate:String=null
            if (ctrlTblPresentFlag == true) {
              logger.info("Control SQl::::::::::::::::" + ctrlSqlQuery)
              var ctrlDF_curr = spark.sqlContext.sql(ctrlSqlQuery)
              val ctrlDfNullRemoved = ctrlDF_curr.na.fill("")
              // Unique records to Control table after flattening.
              //var ctrlDfNullRemovedDistinct = ctrlDfNullRemoved.repartition($"idoc_nr").distinct()
			  var ctrlDfNullRemovedDistinct = ctrlDfNullRemoved.distinct()
              ctrlDfNullRemovedDistinct = Utilities.trimAllColumns(ctrlDfNullRemovedDistinct)
              err_count = 0 //No error records for Control table

              logger.info("====================== Control Table Columns =========================" + colListCtrl)
              logger.info("========================= Date Format Query - Control Table ============================")
              logger.info(" The date cast property value for Control Table is : " + propertiesObject.getCntrlDateCastFields)
              var cntrlDateFormatQuery = Utilities.prepareDateDoubleFormatQuery(colListCtrl, propertiesObject.getCntrlDateCastFields(), "")
              logger.info(cntrlDateFormatQuery)
              ctrlDfNullRemovedDistinct.createOrReplaceTempView("Temp_DF")
              var validCntrlDfWithDateFormat = spark.sqlContext.sql(cntrlDateFormatQuery)

              logger.info("========================== Inserting to Control Table ==================================================")

              validCntrlDfWithDateFormat = validCntrlDfWithDateFormat.filter(!col("idoc_nr").isin(existingControlIdocs: _*))
              loadStatus = Utilities.storeDataFrame(validCntrlDfWithDateFormat, "Append", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgt_ctrl_tbl(), 1)
              
              if (partitionColCtrl != null) {
                partitionDate = validCntrlDfWithDateFormat.select("ins_gmt_dt").first().getString(0)
                tgt_count = spark.sql("select count(*) from " + propertiesObject.getDbName() + "." + propertiesObject.getTgt_ctrl_tbl() + " where ld_jb_nr='" + auditBatchId + "' and ins_gmt_dt='"+partitionDate+"'").first().getLong(0)
              }else{
                tgt_count = spark.sql("select count(*) from " + propertiesObject.getDbName() + "." + propertiesObject.getTgt_ctrl_tbl() + " where ld_jb_nr='" + auditBatchId+ "'").first().getLong(0)
              }
              var sqlCon = Utilities.getConnection(envPropertiesObject)
              if (!loadStatus) {
                logger.error("Control Table load failed!")
                auditObj.setAudLoadTimeStamp(currentMaxTs)
                auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
                auditObj.setAudSrcRowCount(src_count)
                auditObj.setAudTgtRowCount(tgt_count)
                auditObj.setAudErrorRecords(err_count)
                auditObj.setAudJobStatusCode("failed")
                auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
                Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
                System.exit(1)
              } else {
                auditObj.setAudLoadTimeStamp(currentMaxTs)
                auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
                auditObj.setAudSrcRowCount(src_count)
                auditObj.setAudTgtRowCount(tgt_count)
                auditObj.setAudErrorRecords(err_count)
                auditObj.setAudJobStatusCode("success")
                auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
                sqlCon = Utilities.getConnection(envPropertiesObject)
                Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
              }
            }

            auditObj.setAudDataLayerName("hist_rw")
            var rawDfNullRemoved = rawDF_curr.na.fill("")
            // Currency Cast
            var currCastFields: String = propertiesObject.getCurrencyCastFields
            if (currCastFields != null && currCastFields.trim().length() != 0) {
              logger.info("==================== Currency Cast Changes Function ===========================================")
              var currCastFieldsArray: Array[String] = currCastFields.split(",")
              var noOfCols = currCastFieldsArray.length
              while (noOfCols > 0) {
                noOfCols = noOfCols - 1
                rawDfNullRemoved = Utilities.getcurrCastFields(rawDfNullRemoved, currCastFieldsArray(noOfCols))
              }
            }

            var result = rawDfNullRemoved.withColumn("newCol", concat_ws(propertiesObject.getRcdDelimiter(), rawDF_curr.schema.fieldNames.map(c => col(c)): _*))

            logger.info("=======propertiesObject.getBooleanchkCol()=================" + propertiesObject.getBooleanchkCol())

            //result.persist(StorageLevel.MEMORY_AND_DISK)
            var nf = result.withColumn("flag", dqvalidate(result("newCol"), lit(rawDF_curr.schema.fieldNames.toList.mkString(",")), lit(propertiesObject.getRcdDelimiter()), lit(propertiesObject.getNulchkCol()), lit(propertiesObject.getLnchkVal()), lit(propertiesObject.getDtfmtchkCol()), lit(propertiesObject.getIntchkCol()), lit(propertiesObject.getDoublechkCol()), lit(propertiesObject.getBooleanchkCol()), lit(propertiesObject.getLongchkCol)))

            logger.info("=====================After nullify===========================")

            nf = Utilities.nullifyEmptyStrings(nf)
            //nf.persist(StorageLevel.MEMORY_AND_DISK)
            logger.info("++++++++++++++++++++++++++++++++raw schema+++++++++++++++++++++++++++++++++++++++++++++==============================" + rawDF_curr.schema.fieldNames.toList.mkString(","))

            var validrawDF = nf.filter(nf("flag") === "VALID")
            var errorDF = nf.filter(nf("flag").contains("INVALID"))

            errorDF = errorDF.drop("newCol").withColumn("err_cd", lit("100")).withColumnRenamed("flag", "err_msg_cd")
            logger.info("No of error table column===" + colList.length)
            var errorDFWithCol = errorDF.select(colList.head, colList.tail: _*)

            logger.info(" The date cast property value is : " + propertiesObject.getDateCastFields)
            val dateFormatQuery = Utilities.prepareDateDoubleFormatQuery(colListRaw, propertiesObject.getDateCastFields(), propertiesObject.getDoublechkCol)
            logger.info("================+++++++Date Format Query : RAW++++++++++++++++++++++++++++===============")
            logger.info(dateFormatQuery)
            logger.info("===== Date Caste Columns ====" + propertiesObject.getDateCastFields)
            validrawDF.createOrReplaceTempView("Temp_DF")
            var validRawDfWithDateFormat = spark.sqlContext.sql(dateFormatQuery)
            
            dfLoc = spark.sql("describe formatted " + rwTblNm)
            import spark.implicits._
            rows = dfLoc.filter(dfLoc("col_name").contains("ins_gmt_dt") && dfLoc("data_type").contains("date")).select("col_name").distinct.as[String].collect
            val partitionColRw = if (rows != null && rows.toList.length > 0) rows(0) else null
            var existingRwIdocs: List[String] = null
            if(partitionColRw != null){
              existingRwIdocs = spark.sql("select distinct idoc_nr from " + rwTblNm + " where ins_gmt_dt>=date_sub(current_date," + dupChkWndw + ")").collect.map(row => row.getString(0)).toList
            }else{
              existingRwIdocs = spark.sql("select distinct idoc_nr from " + rwTblNm + " where to_date(ins_gmt_ts)>=date_sub(current_date," + dupChkWndw + ")").collect.map(row => row.getString(0)).toList
            }
            validRawDfWithDateFormat = validRawDfWithDateFormat.filter(!col("idoc_nr").isin(existingRwIdocs: _*))
            loadStatus = Utilities.storeDataFrame(validRawDfWithDateFormat, "Append", "ORC", rwTblNm,10)
            var errLoadStatus: Boolean = false
            errLoadStatus = Utilities.storeErrDataFrame(errorDFWithCol, "Append", "ORC", errTblNm)
            
            
            if(partitionColRw != null){
              tgt_count = spark.sql("select count(*) from " + rwTblNm + " where ld_jb_nr='" + auditBatchId + "' and ins_gmt_dt='"+partitionDate+"'").first().getLong(0)
              err_count = spark.sql("select count(*) from " + errTblNm + " where ld_jb_nr='" + auditBatchId + "' and ins_gmt_dt='"+partitionDate+"'").first().getLong(0)
            }else{
              tgt_count = spark.sql("select count(*) from " + rwTblNm + " where ld_jb_nr='" + auditBatchId + "'").first().getLong(0)
              err_count = spark.sql("select count(*) from " + errTblNm + " where ld_jb_nr='" + auditBatchId + "'").first().getLong(0)
            }
            var sqlCon: Connection = Utilities.getConnection(envPropertiesObject)
            if (!loadStatus) {
              logger.error("Raw Table load failed!")
              auditObj.setAudLoadTimeStamp(currentMaxTs)
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              auditObj.setAudErrorRecords(err_count)
              auditObj.setAudJobStatusCode("failed")
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
              System.exit(1)
            }

            auditObj.setAudLoadTimeStamp(currentMaxTs)
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
            auditObj.setAudSrcRowCount(src_count)
            auditObj.setAudTgtRowCount(tgt_count)
            auditObj.setAudErrorRecords(err_count)
            auditObj.setAudJobStatusCode("success")
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            sqlCon = Utilities.getConnection(envPropertiesObject)
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            //loadingDF.unpersist()
            //final_df2.unpersist()
            //nf.unpersist()
            //result.unpersist()
          } else {
            logger.info("No records fetched in restart History to Raw layer job!")
          }
          startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
          val startDate = Utilities.getCurrentTimestamp("yyyy-MM-dd")
          auditObj.setAudJobStartTimeStamp(startTime)
          auditObj.setAudDataLayerName("rw_ref")
          var colListRefForQuery = colListRef.mkString(",")
          sqlCon = Utilities.getConnection(envPropertiesObject)
          var lastRawMaxLoadTs: String = Utilities.readRawMaxLoadTimestamp(sqlCon, propertiesObject.getObjName(), auditTbl);
          val lastRawMaxLoadDt = lastRawMaxLoadTs.substring(0, 10)
          
          dfLoc = spark.sql("describe formatted " + rwTblNm)
          import spark.implicits._
          rows = dfLoc.filter(dfLoc("col_name").contains("ins_gmt_dt") && dfLoc("data_type").contains("date")).select("col_name").distinct.as[String].collect
          val partitionColRw = if (rows != null && rows.toList.length > 0) rows(0) else null
          var rwTableDf: DataFrame = null
          if (partitionColRw != null) {
            rwTableDf = configurationObject.getSpark().sql(f"""select $colListRefForQuery from $rwTblNm where ins_gmt_dt >= '$lastRawMaxLoadDt' and ins_gmt_ts > '$lastRawMaxLoadTs'""")
            rwTableDf = rwTableDf.withColumn("ins_gmt_ts", lit(startTime).cast("Timestamp")).withColumn("ins_gmt_dt", lit(startDate).cast("Date"))
          }else{
            rwTableDf = configurationObject.getSpark().sql(f"""select $colListRefForQuery from $rwTblNm where ins_gmt_ts > '$lastRawMaxLoadTs'""")
            rwTableDf = rwTableDf.withColumn("ins_gmt_ts", lit(startTime).cast("Timestamp"))
          }
          //rwTableDf = rwTableDf.withColumn("ins_gmt_ts", lit(startTime).cast("Timestamp")).withColumn("ins_gmt_dt", lit(startDate).cast("Date"))
          val rwCount = rwTableDf.count();
          sqlCon = Utilities.getConnection(envPropertiesObject)
          if (rwCount != 0) {
            var existingRefIdocs: List[String] = null
            if(partitionColRw != null){
              existingRefIdocs = spark.sql("select distinct idoc_nr from " + refTblNm + " where ins_gmt_dt>=date_sub(current_date," + dupChkWndw + ")").collect.map(row => row.getString(0)).toList
            }else{
              existingRefIdocs = spark.sql("select distinct idoc_nr from " + refTblNm + " where to_date(ins_gmt_ts)>=date_sub(current_date," + dupChkWndw + ")").collect.map(row => row.getString(0)).toList
            }
            rwTableDf = rwTableDf.filter(!col("idoc_nr").isin(existingRefIdocs: _*))
            var dfLoadStatus = Utilities.storeDataFrame(rwTableDf, "Append", "ORC", refTblNm,10)
            if (!dfLoadStatus) {
              auditObj.setAudLoadTimeStamp(startTime)
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudSrcRowCount(rwCount)
              auditObj.setAudTgtRowCount(rwCount)
              auditObj.setAudErrorRecords(0)
              auditObj.setAudJobStatusCode("failed")
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
              System.exit(1)
            }
            auditObj.setAudJobStatusCode("success")
            // Loading Data into Mysql
            auditObj.setAudLoadTimeStamp(startTime)
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
            auditObj.setAudSrcRowCount(rwCount)
            auditObj.setAudTgtRowCount(rwCount)
            auditObj.setAudErrorRecords(0)
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            sqlCon = Utilities.getConnection(envPropertiesObject)
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          } else {
            logger.info("No records fetched in restart Raw to Refined layer job!")
          }

        }
      } else {
        logger.error("Application with same name is already running in yarn")
        System.exit(1)
      }

    } catch {
      case sslException: InterruptedException => {
        logger.error("Interrupted Exception" + sslException.printStackTrace())
        System.exit(1)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        System.exit(1)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        System.exit(1)
      }
      case connException: ConnectException => {
        logger.error("Connection Exception: " + connException.printStackTrace())
        System.exit(1)
      }
      case exception: Exception => {
        logger.error("Exception:" + exception.printStackTrace())
        System.exit(1)
      }
    }
  }

}
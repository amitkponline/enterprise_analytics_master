package com.hpe.restart.driver.other

import java.net.ConnectException
import java.util.HashMap

import com.hpe.config.{ StreamingPropertiesObject, _ }
import com.hpe.utils.{ DataQuality, Utilities }
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, AnalysisException, Row }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{ StringType, StructField, StructType }
import org.apache.spark.storage.StorageLevel

import scala.collection.Map
import java.sql.Connection
import com.github.opendevl.JFlat

object NonSAPHistToRefLoader {

  //Initialized Log
  val logger = Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    if (args == null || args.isEmpty || args.length != 1) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Properties file path>")
      println("Stopping the flow")
      System.exit(1)
    }
    logger.info("Number of argument passed is:::" + args.length)
    try {
      val propertiesFilePath = String.valueOf(args(0).trim())
      var offsetColumnName = "intgtn_fbrc_msg_id"

      val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
      val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
      val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
      val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
      val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
      val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
      val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()

      var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
      import scala.collection.JavaConversions._
      val tblMappingArr = propertiesObject.getTableNameMapping().split(",")
      val idocColumnName = propertiesObject.getFilterExpression()

      logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Mapping Array: " + tblMappingArr.foreach { println })
      val tblTopicMap: Map[String, String] = new HashMap[String, String]()
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

      val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
      val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
      val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
      val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
      val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
      val auditBatchId = ld_jb_nr + "_" + Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

      auditObj.setAudBatchId(auditBatchId)
      auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
      auditObj.setAudObjectName(propertiesObject.getObjName())
      var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
      val startDate = Utilities.getCurrentTimestamp("yyyy-MM-dd")
      auditObj.setAudJobStartTimeStamp(startTime)
      auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
      auditObj.setAudDataLayerName("hist_rw")
      auditObj.setAudSrcRowCount(0)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSpark().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)

      for (element <- tblMappingArr) {
        val topic = element.split("\\|")(0)
        val histTbl = element.split("\\|")(1)
        tblTopicMap.put(topic, histTbl)
      }
      val topicList = propertiesObject.topicList.split(",").toList
      var sqlCon = Utilities.getConnection(envPropertiesObject)
      var histLastMaxLoadTs: String = Utilities.readHistMaxLoadTimestamp(sqlCon, propertiesObject.getObjName(), auditTbl)
      val appName = configObject.getSpark().sparkContext.appName
      val appId = configObject.getSpark().sparkContext.applicationId
      var isAppAlreadyRunning = Utilities.isJobAlreadyRunning(envPropertiesObject, appName, appId)
      logger.info("============isAppAlreadyRunning::::" + isAppAlreadyRunning)
      if (!isAppAlreadyRunning) {
        for (topic <- topicList) {
          var numPartitions = 1
          if (propertiesObject.getNumPartitions() != null && propertiesObject.getNumPartitions().trim().length() != 0) {
            numPartitions = propertiesObject.getNumPartitions().toInt
          }
          val histTbl = propertiesObject.getDbName() + "." + tblTopicMap(topic)
          val lastMaxLoadDt = histLastMaxLoadTs.substring(0, 10)
          logger.info("############################lastMaxLoadDt::::::::" + lastMaxLoadDt)
          val histDf = configObject.getSpark().sql(f"""select cast(payload as string),cast($offsetColumnName  as string) as intgtn_fbrc_msg_id,ins_gmt_ts from $histTbl where ins_gmt_dt >= '$lastMaxLoadDt' and ins_gmt_ts > '$histLastMaxLoadTs'""")//.repartition(200)

          val spark = configObject.getSpark()

          val errTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblErr()
          val rwTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw()
          val refTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef()

          val dataDFRef = spark.sqlContext.sql(f"""select * from $refTblNm limit 0""")
          val colListRef = dataDFRef.columns
          val dataDF = spark.sqlContext.sql(f"""select * from $errTblNm limit 0""")
          val colList = dataDF.columns
          val dataDFRaw = spark.sqlContext.sql(f"""select * from $rwTblNm limit 0""")
          val colListRaw = dataDFRaw.columns

          val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          val obj_nm = propertiesObject.getObjName();

          var schema = StructType(propertiesObject.getColListSep().split(propertiesObject.getRcdDelimiter()).map(fieldName => StructField(fieldName, StringType, true)))
          val offset_schema = StructType(Array(StructField("intgtn_fbrc_msg_id", StringType, true)))
          schema = StructType(schema ++ offset_schema)

          val jsonToFlatUDF = udf(Utilities.jsonToString _)
          val putNullToFlatUDF = udf(Utilities.nullPutUDF _)
          val dqvalidate = udf(DataQuality.DQValidchck _)

          val dateFormatQuery = Utilities.prepareDateDoubleFormatQuery(colListRaw, propertiesObject.getDateCastFields(), propertiesObject.getDoublechkCol)

          val json_hive_raw_map_rdd = spark.sparkContext.parallelize(Seq(propertiesObject.getHiveJsonRawMap()))
          val jsonHeaderList: String = Utilities.getJsonHeaders(json_hive_raw_map_rdd, propertiesObject.getRcdDelimiter())
          var rawSqlQuery = Utilities.final_hive_json_mapper(json_hive_raw_map_rdd)
          rawSqlQuery = rawSqlQuery.replaceAll("FROM Temp_DF", ",intgtn_fbrc_msg_id as intgtn_fbrc_msg_id,'' AS src_sys_upd_ts, '" + src_sys_ky + "' as src_sys_ky, '' AS lgcl_dlt_ind,  current_timestamp() AS ins_gmt_ts, '' AS upd_gmt_ts, '' AS src_sys_extrc_gmt_ts,'' AS src_sys_btch_nr, '" + fl_nm + "'  AS fl_nm, '" + auditBatchId + "' AS ld_jb_nr FROM Temp_DF")

          var tgt_count: Long = 0
          var src_count: Long = 0
          var err_count: Long = 0

          //If Data frame count is non-zero(0) Load from History to Ref table
          //Else load from Raw to Ref
          if (!histDf.head(1).isEmpty) {
            import spark.implicits._
            val final_df2 = histDf.flatMap((row: Row) => {
              import spark.implicits._
              val payload = row.getString(0)
              val intFabric = row.getString(1)
              val flatMe = new JFlat(payload)
              val intResult = flatMe.json2Sheet().headerSeparator("_").getJsonAsSheet()
              var headerTrimmedList: List[String] = null
              val headerString = intResult.get(0).toList.map(_.toString.toUpperCase().replaceAll("[@:-]| ", "_").replaceAll("[()]", ""))
              headerTrimmedList = headerString.map(_.toString.trim)
              val listRes = intResult.map { res =>
                (res.toList.map(str => Option(str).getOrElse("")).mkString(propertiesObject.getRcdDelimiter()), headerTrimmedList.toList.mkString(propertiesObject.getRcdDelimiter()), intFabric)
              }
              listRes.toList.map(x => (x._1.toString, x._2.toString, x._3.toString))
            }).toDF("updatedCol", "header", "intgtn_fbrc_msg_id")

            var final_df = final_df2.filter(!lower(final_df2.col("updatedCol")).contains(propertiesObject.getFilterExpression().toLowerCase()))
            //final_df.persist(StorageLevel.MEMORY_AND_DISK_SER)
            final_df.createOrReplaceTempView("testdf")
            final_df = spark.sqlContext.sql("select * from testdf where length(trim(updatedCol))<>0")
            //final_df.repartition(200)
            final_df = final_df.withColumn("dataWithNull", putNullToFlatUDF(final_df("updatedCol"), lit(propertiesObject.getRcdDelimiter()), final_df("header"), lit(propertiesObject.getColListSep())))
            final_df = final_df.drop("header", "updatedCol")
            //final_df = final_df.repartition(configObject.sparkConf.get("spark.executor.instances").toInt)

            logger.info("Raw SQL===================" + rawSqlQuery)
            var rdd = final_df.select("dataWithNull", "intgtn_fbrc_msg_id").rdd.map { row: Row => (row.getString(0) + propertiesObject.getRcdDelimiter() + row.getString(1)).substring(if ((row.getString(0).head).equals('"')) 1 else 0, (row.getString(0) + propertiesObject.getRcdDelimiter() + row.getString(1)).length()).replaceAll("\"" + propertiesObject.getRcdDelimiter(), propertiesObject.getRcdDelimiter()).replaceAll(propertiesObject.getRcdDelimiter() + "\"", propertiesObject.getRcdDelimiter()).replaceAll("\"" + propertiesObject.getRcdDelimiter() + "\"", propertiesObject.getRcdDelimiter()).replaceAll("\\\\\"", "\"").replaceAll("\n", System.lineSeparator()) }.map(line => line.split(propertiesObject.getRcdDelimiter(), -1)).map(line => Row.fromSeq(line))
            var loadingDF = spark.sqlContext.createDataFrame(rdd, schema)
            //loadingDF.persist(StorageLevel.MEMORY_AND_DISK)
            loadingDF.createOrReplaceTempView("Temp_DF")
            logger.info("Raw SQl::::::::::::::::" + rawSqlQuery)
            var rawDF_curr = spark.sqlContext.sql(rawSqlQuery)
            logger.info("#####################  ALL DONE #####################")
            var rawDfNullRemoved = rawDF_curr.na.fill("")

            // Currency Cast _______________________________________________________
            var currCastFields: String = propertiesObject.getCurrencyCastFields
            if (currCastFields != null && currCastFields.trim().length() != 0) {
              logger.info("==================== Currency Cast Changes Function ===========================================")
              var currCastFieldsArray: Array[String] = currCastFields.split(",")
              var noOfCols = currCastFieldsArray.length
              while (noOfCols > 0) {
                noOfCols = noOfCols - 1
                rawDfNullRemoved = Utilities.getcurrCastFields(rawDfNullRemoved, currCastFieldsArray(noOfCols))
              }
            }
            var result = rawDfNullRemoved.withColumn("newCol", concat_ws(propertiesObject.getRcdDelimiter(), rawDF_curr.schema.fieldNames.map(c => col(c)): _*))

            logger.info("=======propertiesObject.getBooleanchkCol()=================" + propertiesObject.getBooleanchkCol())
            //result.persist(StorageLevel.MEMORY_AND_DISK_SER)
            logger.info("DQ INPUT===========================")
            logger.info("schema================" + rawDF_curr.schema.fieldNames.toList.mkString(","))
            var nf = result.withColumn("flag", dqvalidate(result("newCol"), lit(rawDF_curr.schema.fieldNames.toList.mkString(",")), lit(propertiesObject.getRcdDelimiter()), lit(propertiesObject.getNulchkCol()), lit(propertiesObject.getLnchkVal()), lit(propertiesObject.getDtfmtchkCol()), lit(propertiesObject.getIntchkCol()), lit(propertiesObject.getDoublechkCol()), lit(propertiesObject.getBooleanchkCol()), lit(propertiesObject.getLongchkCol)))
            nf = Utilities.nullifyEmptyStrings(nf)
            
            nf = nf.repartition(numPartitions).persist(StorageLevel.MEMORY_AND_DISK_SER)

            logger.info("==++++++++++++++++++++++++++++++++raw schema+++++++++++++++++++++++++++++==" + rawDF_curr.schema.fieldNames.toList.mkString(","))
            var validrawDF = nf.filter(nf("flag") === "VALID")
            var errorDF = nf.filter(nf("flag").contains("INVALID"))
            errorDF = errorDF.drop("newCol").withColumn("err_cd", lit("100")).withColumnRenamed("flag", "err_msg_cd")
            logger.info("No of error table column===" + colList.length)
            src_count = histDf.count
            logger.info("============LAST=================")
            var errorDFWithCol = errorDF.select(colList.head, colList.tail: _*)
            //err_count = errorDFWithCol.count
            logger.info("================+++++++Date Format Query : RAW ++++++++++++++++++++++++++++===============")
            logger.info(dateFormatQuery)
            validrawDF.createOrReplaceTempView("Temp_DF")
            var validRawDfWithDateFormat = spark.sqlContext.sql(dateFormatQuery)

            var histToRawLoadStatus = false
            var histToErrLoadStatus = false
            if (propertiesObject.getCustomSQL() != null && propertiesObject.getCustomSQL().size != 0) {
              validRawDfWithDateFormat.createOrReplaceTempView("temp_view")
              val customQuery = propertiesObject.getCustomSQL()
              val validRawDfAfterCustom = spark.sqlContext.sql(customQuery)
              //tgt_count = validRawDfAfterCustom.count
              histToRawLoadStatus = Utilities.storeDataFrame(validRawDfAfterCustom, "Append", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw(),numPartitions)
            } else {
              histToRawLoadStatus = Utilities.storeDataFrame(validRawDfWithDateFormat, "Append", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw(),numPartitions)
              //tgt_count = validRawDfWithDateFormat.count
            }
            histToErrLoadStatus = Utilities.storeErrDataFrame(errorDFWithCol, "Append", "ORC", errTblNm, numPartitions)
            
            val dfLoc = spark.sql("describe formatted " + rwTblNm)
            import spark.implicits._
            val rows = dfLoc.filter(dfLoc("col_name").contains("ins_gmt_dt") && dfLoc("data_type").contains("date")).select("col_name").distinct.as[String].collect
            val partitionColRw = if (rows != null && rows.toList.length > 0) rows(0) else null
            var rwTableDf: DataFrame = null
            val partitionDate = validRawDfWithDateFormat.select("ins_gmt_dt").first().getDate(0).toString()
            if(partitionColRw!=null){
             tgt_count = spark.sql("select count(*) from " + rwTblNm + " where ld_jb_nr='" + auditBatchId + "' and ins_gmt_dt='"+partitionDate+"'").first().getLong(0)
            err_count = spark.sql("select count(*) from " + errTblNm + " where ld_jb_nr='" + auditBatchId + "' and ins_gmt_dt='"+partitionDate+"'").first().getLong(0) //ctrlDfNullRemovedDistinct.count()
            }else{
              tgt_count = spark.sql("select count(*) from " + rwTblNm + " where ld_jb_nr='" + auditBatchId + "'").first().getLong(0)
              err_count = spark.sql("select count(*) from " + errTblNm + " where ld_jb_nr='" + auditBatchId + "'").first().getLong(0)
            }
            var sqlCon = Utilities.getConnection(envPropertiesObject)
            if (histToRawLoadStatus == false && histToErrLoadStatus == false) {
              auditObj.setAudJobStatusCode("failed")
              auditObj.setAudLoadTimeStamp(startTime)
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              auditObj.setAudErrorRecords(err_count)
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
              System.exit(1)
            } else {
              auditObj.setAudJobStatusCode("success")
              auditObj.setAudLoadTimeStamp(startTime)
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              auditObj.setAudErrorRecords(err_count)
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            }
            //final_df.unpersist()
            //loadingDF.unpersist()
            nf.unpersist()
            //result.unpersist()
          }
          startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
          auditObj.setAudJobStartTimeStamp(startTime)
          auditObj.setAudDataLayerName("rw_ref")
          var sqlCon = Utilities.getConnection(envPropertiesObject)
          var lastRawMaxLoadTs: String = Utilities.readRawMaxLoadTimestamp(sqlCon, propertiesObject.getObjName(), auditTbl)
          val lastRawMaxLoadDt = lastRawMaxLoadTs.substring(0, 10)
          var colListRefForQuery = colListRef.mkString(",")
          var refTableDf = configObject.getSpark().sql(f"""select $colListRefForQuery from $rwTblNm where ins_gmt_dt >= '$lastRawMaxLoadDt' and ins_gmt_ts > '$lastRawMaxLoadTs'""")
          refTableDf = refTableDf.withColumn("ins_gmt_ts", lit(startTime).cast("Timestamp")).withColumn("ins_gmt_dt", lit(startDate).cast("Date"))
          //var refTableDf = configObject.getSpark().sql(f"""select $colListRefForQuery from $rwTblNm where ins_gmt_ts > '$lastRawMaxLoadTs'""")
		      var refTableCntDf = configObject.getSpark().sql(f"""select count(1) from $rwTblNm where ins_gmt_dt >= '$lastRawMaxLoadDt' and ins_gmt_ts > '$lastRawMaxLoadTs'""")
          val refTblCnt = refTableCntDf.first.getLong(0).toInt
          logger.info("Rw Table Cnt :" + refTblCnt)
          sqlCon = Utilities.getConnection(envPropertiesObject)
          if (refTblCnt != 0) {

            val rawToRefLoadStatus = Utilities.storeDataFrame(refTableDf, "Append", "ORC", refTblNm,numPartitions)
            
            if (rawToRefLoadStatus == false) {
              auditObj.setAudJobStatusCode("failed")
              auditObj.setAudLoadTimeStamp(startTime)
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudSrcRowCount(refTblCnt)
              auditObj.setAudTgtRowCount(refTblCnt)
              auditObj.setAudErrorRecords(0)
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
              System.exit(1)
            } else {
              auditObj.setAudJobStatusCode("success")
              auditObj.setAudSrcRowCount(refTblCnt)
              auditObj.setAudTgtRowCount(refTblCnt)
              auditObj.setAudErrorRecords(0)
              auditObj.setAudLoadTimeStamp(startTime)
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            }
          }
        }
      } else {
        logger.error("Application with same name is already running in yarn")
        System.exit(1)
      }
    } catch {
      case sslException: InterruptedException => {
        logger.error("Interrupted Exception" + sslException.printStackTrace())
        System.exit(1)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        System.exit(1)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        System.exit(1)
      }
      case connException: ConnectException => {
        logger.error("Connection Exception: " + connException.printStackTrace())
        System.exit(1)
      }
      case exception: Exception => {
        logger.error("Exception:" + exception.printStackTrace())
        System.exit(1)
      }
    }
  }
}
package com.hpe.batch.driver.facts.scits

import java.net.ConnectException
import java.text.SimpleDateFormat
import java.util.Calendar

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.functions.row_number

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object ExternalManufacturingPartnerInventoryFact extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  var auditBatchId = ld_jb_nr + "_" + "19000101000000"
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  var src_count = 0
  var tgt_count = 0
  var loadStatus = true
  val srcTblConsmtn = propertiesObject.getSrcTblConsmtn()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn()
  val numPartitions = propertiesObject.getNumPartitions().trim().toInt
  val bufferDays = propertiesObject.getRetainRecords()
  val daysLimit = propertiesObject.getDaysLimit().toInt
  val sdf = new SimpleDateFormat("yyyy-MM-dd")
  def daysAgo(days: Int): String = {
    val calender = Calendar.getInstance()
    calender.add(Calendar.DAY_OF_YEAR, -days)
    sdf.format(calender.getTime())
  }
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (tgtTblConsmtn.trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = tgtTblConsmtn.trim().split("\\.", -1)(0)
    consmptnTable = tgtTblConsmtn.trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  //************************Set Audit Entries*******************************//

  auditObj.setAudBatchId(auditBatchId)
  auditObj.setAudDataLayerName("fact_load")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(objName)
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(src_count)
  auditObj.setAudTgtRowCount(tgt_count)

  try {
    //****************Dropping Older Partitions in Dimension table*****************//

    for (i <- daysLimit to daysLimit + 7) {
      var dateLimit = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + srcTblConsmtn + " DROP IF EXISTS PARTITION(rfnc_dt='" + dateLimit + "')")
        spark.sql("ALTER TABLE " + tgtTblConsmtn + " DROP IF EXISTS PARTITION(rfnc_dt='" + dateLimit + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for dropping partitions")
        }
      }
    }

    val refBatchIdList: List[String] = Utilities.readFactLoadBatchIdList(sqlCon, propertiesObject.getObjName(), auditTbl)

    val transformeSrcdDF = spark.sql("""select ld_jb_nr,rfnc_dt 
      from """ + srcTblConsmtn).filter(col("rfnc_dt") >= daysAgo(bufferDays.toInt)).filter(col("ld_jb_nr") isin (refBatchIdList: _*))

    var src_count = transformeSrcdDF.count().toInt

    logger.info("source records count :" + src_count)

    if (src_count != 0) {

      auditBatchId = refBatchIdList.map(x => (x, x.reverse.slice(0, 14).reverse)).maxBy(_._2)._1

      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudBatchId(auditBatchId)

      //****************************Fact Load Code****************************************//

      val hiveRefSelectDF = spark.sql("""select xtrn_mfrg_ptnr_invy_ky as fct_asscn_ky,rec_typ_cd,src_site_cd,prod_ln_cd,prt_nr,rgn_cd,lctn_cd,avl_qty,
        prs_qty,rwrk_qty,awaiting_dspn_qty,trst_depot_qty,mtd_rtn_qty,mtd_build_qty,mtd_consumed_qty,mtd_prch_ord_rcv_qty,mtd_inrn_misc_trsn_qty,
        mtd_xtrn_misc_trsn_qty,mtd_cyc_cnt_adjmt_qty,inspn_qty,consigned_qty,invy_qty_unt_msr_cd,invy_own_id,invy_own_nm,allctn_lctn_cd,uncommitted_qty,
        xtnd_invy_own_id,storg_lctn_cd,splyr_prt_nr,ptnr_prt_nr as invy_ptnr_prt_nr,mrp_ar_cd,gps_prj_nr,invy_own_typ_cd,invy_hldr_typ_cd,invy_hldr_id,
        invy_hldr_nm,rstd_us_qty,blckd_stk_qty,rtns_qty,hdr_rec_typ_cd,hdr_fl_sbj_cd,hdr_fl_tm_prd_cd,hdr_fl_sndr_id,hdr_fl_sqn_nr,hdr_dta_extrc_ts,
        hdr_fl_crt_ts,hdr_rfnc_dt,hdr_scits_vrsn_nr,trlr_rec_typ_cd,trlr_fl_sbj_cd,trlr_fl_tm_prd_cd,trlr_fl_sndr_id,trlr_fl_sqn_nr,trlr_fl_crt_ts,
        trlr_rec_cnt_nr,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,
        current_timestamp as ins_ts,rfnc_dt 
        from """ + srcTblConsmtn).filter(col("rfnc_dt") >= daysAgo(bufferDays.toInt)).filter(col("ld_jb_nr") isin (refBatchIdList: _*))

      logger.info("""hiveRefSelectDF: select xtrn_mfrg_ptnr_invy_ky as fct_asscn_ky,rec_typ_cd,src_site_cd,prod_ln_cd,prt_nr,rgn_cd,lctn_cd,avl_qty,
        prs_qty,rwrk_qty,awaiting_dspn_qty,trst_depot_qty,mtd_rtn_qty,mtd_build_qty,mtd_consumed_qty,mtd_prch_ord_rcv_qty,mtd_inrn_misc_trsn_qty,
        mtd_xtrn_misc_trsn_qty,mtd_cyc_cnt_adjmt_qty,inspn_qty,consigned_qty,invy_qty_unt_msr_cd,invy_own_id,invy_own_nm,allctn_lctn_cd,uncommitted_qty,
        xtnd_invy_own_id,storg_lctn_cd,splyr_prt_nr,ptnr_prt_nr as invy_ptnr_prt_nr,mrp_ar_cd,gps_prj_nr,invy_own_typ_cd,invy_hldr_typ_cd,invy_hldr_id,
        invy_hldr_nm,rstd_us_qty,blckd_stk_qty,rtns_qty,hdr_rec_typ_cd,hdr_fl_sbj_cd,hdr_fl_tm_prd_cd,hdr_fl_sndr_id,hdr_fl_sqn_nr,hdr_dta_extrc_ts,
        hdr_fl_crt_ts,hdr_rfnc_dt,hdr_scits_vrsn_nr,trlr_rec_typ_cd,trlr_fl_sbj_cd,trlr_fl_tm_prd_cd,trlr_fl_sndr_id,trlr_fl_sqn_nr,trlr_fl_crt_ts,
        trlr_rec_cnt_nr,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,
        current_timestamp as ins_ts,rfnc_dt 
        from """ + srcTblConsmtn)

      val prtMstrDF = spark.sql("""select prt_dn_cd,sap_mtrl_typ_cd,ptnr_prt_nr,prt_nr,lctn_cd,rfnc_dt 
        from """ + dbNameConsmtn + "." + """xtrn_mfrg_ptnr_prt_mstr_fact""")

      logger.info("""prtMstrDF : select prt_dn_cd,sap_mtrl_typ_cd,ptnr_prt_nr,prt_nr,lctn_cd,rfnc_dt 
        from """ + dbNameConsmtn + "." + """xtrn_mfrg_ptnr_prt_mstr_fact""")

      val prtMstrJoinDF = hiveRefSelectDF.as("a").join(
        prtMstrDF.as("b"),
        col("a.prt_nr") === col("b.prt_nr") && col("a.lctn_cd") === col("b.lctn_cd"),
        "left").select(col("a.fct_asscn_ky"), col("a.rec_typ_cd"), col("a.src_site_cd"), col("a.prod_ln_cd"), col("a.prt_nr"),
          col("a.rgn_cd"), col("a.lctn_cd"), col("a.avl_qty"), col("a.prs_qty"), col("a.rwrk_qty"), col("a.awaiting_dspn_qty"),
          col("a.trst_depot_qty"), col("a.mtd_rtn_qty"), col("a.mtd_build_qty"), col("a.mtd_consumed_qty"), col("a.mtd_prch_ord_rcv_qty"),
          col("a.mtd_inrn_misc_trsn_qty"), col("a.mtd_xtrn_misc_trsn_qty"), col("a.mtd_cyc_cnt_adjmt_qty"), col("a.inspn_qty"), col("a.consigned_qty"),
          col("a.invy_qty_unt_msr_cd"), col("a.invy_own_id"), col("a.invy_own_nm"), col("a.allctn_lctn_cd"), col("a.uncommitted_qty"),
          col("a.xtnd_invy_own_id"), col("a.storg_lctn_cd"), col("a.splyr_prt_nr"), col("a.invy_ptnr_prt_nr"), col("a.mrp_ar_cd"),
          col("a.gps_prj_nr"), col("a.invy_own_typ_cd"), col("a.invy_hldr_typ_cd"), col("a.invy_hldr_id"), col("a.invy_hldr_nm"),
          col("a.rstd_us_qty"), col("a.blckd_stk_qty"), col("a.rtns_qty"), col("a.hdr_rec_typ_cd"), col("a.hdr_fl_sbj_cd"), col("a.hdr_fl_tm_prd_cd"),
          col("a.hdr_fl_sndr_id"), col("a.hdr_fl_sqn_nr"), col("a.hdr_dta_extrc_ts"), col("a.hdr_fl_crt_ts"), col("a.hdr_rfnc_dt"),
          col("a.hdr_scits_vrsn_nr"), col("a.trlr_rec_typ_cd"), col("a.trlr_fl_sbj_cd"), col("a.trlr_fl_tm_prd_cd"), col("a.trlr_fl_sndr_id"),
          col("a.trlr_fl_sqn_nr"), col("a.trlr_fl_crt_ts"), col("a.trlr_rec_cnt_nr"), col("a.src_sys_upd_ts"), col("a.src_sys_ky"),
          col("a.lgcl_dlt_ind"), col("a.ins_gmt_ts"), col("a.upd_gmt_ts"), col("a.src_sys_extrc_gmt_ts"), col("a.src_sys_btch_nr"),
          col("a.fl_nm"), col("a.ld_jb_nr"), col("a.ins_ts"), col("a.rfnc_dt"), col("b.prt_dn_cd"), col("b.sap_mtrl_typ_cd"), col("b.ptnr_prt_nr"),
          col("b.rfnc_dt").alias("b_rfnc_dt"))

      val windowSpecPrtMstr = Window.partitionBy("a.fct_asscn_ky", "a.rec_typ_cd", "a.src_site_cd", "a.prod_ln_cd", "a.prt_nr", "a.rgn_cd",
        "a.lctn_cd", "a.avl_qty", "a.prs_qty", "a.rwrk_qty", "a.awaiting_dspn_qty", "a.trst_depot_qty", "a.mtd_rtn_qty", "a.mtd_build_qty",
        "a.mtd_consumed_qty", "a.mtd_prch_ord_rcv_qty", "a.mtd_inrn_misc_trsn_qty", "a.mtd_xtrn_misc_trsn_qty", "a.mtd_cyc_cnt_adjmt_qty",
        "a.inspn_qty", "a.consigned_qty", "a.invy_qty_unt_msr_cd", "a.invy_own_id", "a.invy_own_nm", "a.allctn_lctn_cd", "a.uncommitted_qty",
        "a.xtnd_invy_own_id", "a.storg_lctn_cd", "a.splyr_prt_nr", "a.invy_ptnr_prt_nr", "a.mrp_ar_cd", "a.gps_prj_nr", "a.invy_own_typ_cd",
        "a.invy_hldr_typ_cd", "a.invy_hldr_id", "a.invy_hldr_nm", "a.rstd_us_qty", "a.blckd_stk_qty", "a.rtns_qty", "a.hdr_rec_typ_cd",
        "a.hdr_fl_sbj_cd", "a.hdr_fl_tm_prd_cd", "a.hdr_fl_sndr_id", "a.hdr_fl_sqn_nr", "a.hdr_dta_extrc_ts", "a.hdr_fl_crt_ts", "a.hdr_rfnc_dt",
        "a.hdr_scits_vrsn_nr", "a.trlr_rec_typ_cd", "a.trlr_fl_sbj_cd", "a.trlr_fl_tm_prd_cd", "a.trlr_fl_sndr_id", "a.trlr_fl_sqn_nr",
        "a.trlr_fl_crt_ts", "a.trlr_rec_cnt_nr", "a.src_sys_upd_ts", "a.src_sys_ky", "a.lgcl_dlt_ind", "a.ins_gmt_ts", "a.upd_gmt_ts",
        "a.src_sys_extrc_gmt_ts", "a.src_sys_btch_nr", "a.fl_nm", "a.ld_jb_nr", "a.ins_ts", "a.rfnc_dt").orderBy(desc("b_rfnc_dt"))

      val prtMstrJoinLatestDF = prtMstrJoinDF.withColumn("row_nm", row_number() over windowSpecPrtMstr).where(col("row_nm").equalTo(1)).drop(
        "row_nm",
        "b_rfnc_dt")

      val splyrPrtMstrDF = spark.sql("""select ord_lead_tm_dy_cnt_qty,prt_nr,lctn_cd,rfnc_dt 
        from """ + dbNameConsmtn + "." + """xtrn_mfrg_ptnr_splyr_prt_mstr_fact""")

      val splyrPrtMstrJoinDF = prtMstrJoinLatestDF.as("a").join(
        splyrPrtMstrDF.as("b"),
        col("a.prt_nr") === col("b.prt_nr") && col("a.lctn_cd") === col("b.lctn_cd"),
        "left").select(col("a.fct_asscn_ky"), col("a.rec_typ_cd"), col("a.src_site_cd"), col("a.prod_ln_cd"), col("a.prt_nr"), col("a.rgn_cd"),
          col("a.lctn_cd"), col("a.avl_qty"), col("a.prs_qty"), col("a.rwrk_qty"), col("a.awaiting_dspn_qty"), col("a.trst_depot_qty"),
          col("a.mtd_rtn_qty"), col("a.mtd_build_qty"), col("a.mtd_consumed_qty"), col("a.mtd_prch_ord_rcv_qty"), col("a.mtd_inrn_misc_trsn_qty"),
          col("a.mtd_xtrn_misc_trsn_qty"), col("a.mtd_cyc_cnt_adjmt_qty"), col("a.inspn_qty"), col("a.consigned_qty"), col("a.invy_qty_unt_msr_cd"),
          col("a.invy_own_id"), col("a.invy_own_nm"), col("a.allctn_lctn_cd"), col("a.uncommitted_qty"), col("a.xtnd_invy_own_id"),
          col("a.storg_lctn_cd"), col("a.splyr_prt_nr"), col("a.invy_ptnr_prt_nr"), col("a.mrp_ar_cd"), col("a.gps_prj_nr"), col("a.invy_own_typ_cd"),
          col("a.invy_hldr_typ_cd"), col("a.invy_hldr_id"), col("a.invy_hldr_nm"), col("a.rstd_us_qty"), col("a.blckd_stk_qty"), col("a.rtns_qty"),
          col("a.hdr_rec_typ_cd"), col("a.hdr_fl_sbj_cd"), col("a.hdr_fl_tm_prd_cd"), col("a.hdr_fl_sndr_id"), col("a.hdr_fl_sqn_nr"),
          col("a.hdr_dta_extrc_ts"), col("a.hdr_fl_crt_ts"), col("a.hdr_rfnc_dt"), col("a.hdr_scits_vrsn_nr"), col("a.trlr_rec_typ_cd"),
          col("a.trlr_fl_sbj_cd"), col("a.trlr_fl_tm_prd_cd"), col("a.trlr_fl_sndr_id"), col("a.trlr_fl_sqn_nr"), col("a.trlr_fl_crt_ts"),
          col("a.trlr_rec_cnt_nr"), col("a.src_sys_upd_ts"), col("a.src_sys_ky"), col("a.lgcl_dlt_ind"), col("a.ins_gmt_ts"),
          col("a.upd_gmt_ts"), col("a.src_sys_extrc_gmt_ts"), col("a.src_sys_btch_nr"), col("a.fl_nm"), col("a.ld_jb_nr"), col("a.ins_ts"),
          col("a.prt_dn_cd"), col("a.sap_mtrl_typ_cd"), col("a.ptnr_prt_nr"), col("b.ord_lead_tm_dy_cnt_qty"),
          col("a.rfnc_dt"), col("b.rfnc_dt").alias("b_rfnc_dt"))

      val windowSpecSplyrPrtMstr = Window.partitionBy("a.fct_asscn_ky", "a.rec_typ_cd", "a.src_site_cd", "a.prod_ln_cd", "a.prt_nr",
        "a.rgn_cd", "a.lctn_cd", "a.avl_qty", "a.prs_qty", "a.rwrk_qty", "a.awaiting_dspn_qty", "a.trst_depot_qty", "a.mtd_rtn_qty",
        "a.mtd_build_qty", "a.mtd_consumed_qty", "a.mtd_prch_ord_rcv_qty", "a.mtd_inrn_misc_trsn_qty", "a.mtd_xtrn_misc_trsn_qty",
        "a.mtd_cyc_cnt_adjmt_qty", "a.inspn_qty", "a.consigned_qty", "a.invy_qty_unt_msr_cd", "a.invy_own_id", "a.invy_own_nm",
        "a.allctn_lctn_cd", "a.uncommitted_qty", "a.xtnd_invy_own_id", "a.storg_lctn_cd", "a.splyr_prt_nr", "a.invy_ptnr_prt_nr",
        "a.mrp_ar_cd", "a.gps_prj_nr", "a.invy_own_typ_cd", "a.invy_hldr_typ_cd", "a.invy_hldr_id", "a.invy_hldr_nm", "a.rstd_us_qty",
        "a.blckd_stk_qty", "a.rtns_qty", "a.hdr_rec_typ_cd", "a.hdr_fl_sbj_cd", "a.hdr_fl_tm_prd_cd", "a.hdr_fl_sndr_id",
        "a.hdr_fl_sqn_nr", "a.hdr_dta_extrc_ts", "a.hdr_fl_crt_ts", "a.hdr_rfnc_dt", "a.hdr_scits_vrsn_nr", "a.trlr_rec_typ_cd",
        "a.trlr_fl_sbj_cd", "a.trlr_fl_tm_prd_cd", "a.trlr_fl_sndr_id", "a.trlr_fl_sqn_nr", "a.trlr_fl_crt_ts", "a.trlr_rec_cnt_nr",
        "a.src_sys_upd_ts", "a.src_sys_ky", "a.lgcl_dlt_ind", "a.ins_gmt_ts", "a.upd_gmt_ts", "a.src_sys_extrc_gmt_ts", "a.src_sys_btch_nr",
        "a.fl_nm", "a.ld_jb_nr", "a.ins_ts", "a.prt_dn_cd", "a.sap_mtrl_typ_cd", "a.ptnr_prt_nr", "a.rfnc_dt").orderBy(desc("b_rfnc_dt"))

      val finalDF = splyrPrtMstrJoinDF.withColumn("row_nm", row_number() over windowSpecSplyrPrtMstr).where(col("row_nm").equalTo(1)).drop(
        "row_nm",
        "b_rfnc_dt").coalesce(numPartitions)

      finalDF.write.mode("Append").format("ORC").insertInto(dbNameConsmtn + "." + consmptnTable)

      logger.info("Data has been loaded to: " + consmptnTable + " Table")

      var transformeTgtdDF = spark.sql("""select ld_jb_nr,rfnc_dt 
        from """ + tgtTblConsmtn).filter(col("rfnc_dt") >= daysAgo(bufferDays.toInt)).filter(col("ld_jb_nr") isin (refBatchIdList: _*))

      var tgt_count = transformeTgtdDF.count().toInt

      logger.info("target records count:" + tgt_count)

      //************************Completion Audit Entries*******************************//

      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudJobStatusCode("success")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
      toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).
        getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = true
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).
        getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = true
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).
        getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = true
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).
        getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = true
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).
        getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = true
    }
  } finally {
    if (loadStatus) {
      logger.info("Finally Block executed for no Exception")
      sqlCon.close()
      spark.close()
    } else {
      logger.info("Finally Block executed for Exception")
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
  }
}
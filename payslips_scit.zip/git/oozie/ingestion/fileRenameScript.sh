kinit -kt /etc/security/keytabs/srvc_nextgen_hpro.keytab srvc_nextgen_hpro@EAPPRD.HPEIT.HPE.COM
hdfs dfs -ls /user/srvc_ima_platform/EA/${1}/*.${2}| awk '{print $8}'> ${1}.tmp
if [ $? == 1 ]
then
exit 1;
fi
while read line; do
sourcefile=$(basename $line)
##echo $sourcefile
targetfile=`echo $sourcefile | cut -f1 -d"."`
##echo $targetfile
hdfs dfs -mv /user/srvc_ima_platform/EA/${1}/$sourcefile /user/srvc_ima_platform/EA/${1}/$targetfile.${3}
done<${1}.tmp

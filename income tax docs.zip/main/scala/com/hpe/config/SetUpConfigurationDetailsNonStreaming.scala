package com.hpe.config


import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

object SetUpConfigurationNonStreaming extends ConfigurationDetails {

  val logger = Logger.getLogger(getClass.getName)
  /**
   * Function to set the Spark Context objects
   *
   * @return Configuration Object
   */	
  def getSparkContext():ConfigObjectNonStreaming={
  		try{
  		      val sparkConf=new SparkConf()
  		      SetUpConfigurationNonStreaming.setproperties(sparkConf)
						val spark = SparkSession.builder().enableHiveSupport().config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").config("spark.sql.hive.convertMetastoreOrc", "false").config("spark.sql.codegen.wholeStage", "true").config(sparkConf).getOrCreate()
  		      val configObject=new ConfigObjectNonStreaming(sparkConf,spark)
      			return configObject
  		} 
  		catch {
  		case textError: Throwable => textError.printStackTrace() // TODO: handle error
  				logger.error("Could Not create the sparkConf,sparkContext,sqlContext,hiveContext")
  				logger.debug(textError)
  				sys.exit(1)
  		}
  	}


  /**
   * Function to set the Spark related properties
   *
   * @param configObject		: Configuration Object   
   */
	def setproperties(sparkConf: SparkConf)
	{
	    logger.info("Setting up the properties for SparkContext")
	    //sparkConf.set("spark.executor.cores", SPARK_EXECUTOR_CORES)
	    //sparkConf.set("spark.executor.memory", SPARK_EXECUTOR_MEMORY)
	    sparkConf.set("spark.network.timeout", SPARK_NETWORK_TIMOUT_TS)
	    sparkConf.set("spark.sql.broadcastTimeout", SPARK_SQL_BROADCAST_TIMEOUT)
	    sparkConf.set("spark.sql.tungsten.enabled", "true")
	    sparkConf.set("spark.eventLog.enabled", "true")
	    sparkConf.set("spark.io.compression.codec", "snappy")
	    sparkConf.set("spark.rdd.compress", "true")
	    //configObject.sparkConf.set("spark.dynamicAllocation.enabled", "true")
	    //configObject.sparkConf.set("spark.shuffle.service.enabled", "true")
      sparkConf.set("spark.streaming.kafka.maxRatePerPartition","10000")
      sparkConf.set("spark.streaming.concurrentJobs","6")
      sparkConf.set("spark.streaming.unpersist","true")
      sparkConf.set("spark.streaming.backpressure.enabled","true")
      sparkConf.set("spark.cores.max", "50")
      sparkConf.set("spark.executor.instances", "4")
      //sparkConf.set("spark.executor.cores", "10")
      sparkConf.set("spark.serializer","org.apache.spark.serializer.KryoSerializer")
      sparkConf.set("spark.driver.extraJavaOptions", "-XX:+UseG1GC")
      sparkConf.set("spark.executor.extraJavaOptions", "-XX:+UseG1GC")
      sparkConf.set("spark.speculation", "false")
      sparkConf.set("spark.hadoop.mapreduce.map.speculative", "false")
      sparkConf.set("spark.hadoop.mapreduce.reduce.speculative", "false")
	}
	
	/**
	 * setup method invokes other methods for setup before job processing starts
	 * @return : Configuration Object
	 */
	def setup():ConfigObjectNonStreaming = {
	  val config=SetUpConfigurationNonStreaming.getSparkContext()
		return config	
	}

}
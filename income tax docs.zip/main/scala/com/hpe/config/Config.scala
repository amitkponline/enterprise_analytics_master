package com.hpe.config

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.StreamingContext

import scala.beans.BeanProperty

class ConfigObjectBatch(
                         @BeanProperty var sparkConf: SparkConf,
                         @BeanProperty var spark: SparkSession) extends Serializable

class ConfigObject(
                    @BeanProperty var sparkConf: SparkConf,
                    @BeanProperty var spark: SparkSession,
                    @BeanProperty var ssc: StreamingContext) extends Serializable

class ConfigObjectNonStreaming(
                                @BeanProperty var sparkConf:SparkConf,
                                @BeanProperty var spark:SparkSession) extends Serializable

class StreamingPropertiesObject(
                                 @BeanProperty var objName: String,
                                 @BeanProperty var autoCommit: String,
                                 @BeanProperty var dbName: String,
                                 @BeanProperty var ctrl_doc_num: String,
                                 @BeanProperty var topicList: String,
                                 @BeanProperty var tableNameMapping: String,
                                 //    @BeanProperty var jsonHiveMapTbl: String,
                                 //    @BeanProperty var tgt_data_tbl: String,
                                 @BeanProperty var tgt_ctrl_tbl: String,
                                 //    @BeanProperty var colNm: String,
                                 //    @BeanProperty var msgdelimeter: String,
                                 @BeanProperty var NulchkCol: String,
                                 @BeanProperty var lnchkVal: String,
                                 @BeanProperty var DtfmtchkCol: String,
                                 @BeanProperty var intchkCol: String,
                                 @BeanProperty var doublechkCol: String,
                                 @BeanProperty var booleanchkCol: String,
                                 @BeanProperty var longchkCol: String,
                                 @BeanProperty var rcdDelimiter: String,
                                 //    @BeanProperty var maxRunTime: String,
                                 @BeanProperty var colListSep: String,
                                 @BeanProperty var filterExpression: String,
                                 @BeanProperty var tgtTblRw: String,
                                 @BeanProperty var tgtTblErr: String,
                                 @BeanProperty var tgtTblRef: String,
                                 @BeanProperty var tgtTblConsmtn: String,
                                 @BeanProperty var unqKeyCols: String,
                                 @BeanProperty var masterDataFields: String,
                                 @BeanProperty var hiveJsonRawMap: String,
                                 @BeanProperty var hiveJsonCtrlMap: String,
                                 @BeanProperty var lookUpTable: String,
                                 @BeanProperty var customSQL: String,
                                 @BeanProperty var dateCastFields: String,
                                 @BeanProperty var consumerGroupVal : String,
                                 @BeanProperty var currencyCastFields : String,
                                 @BeanProperty var maxRatePerPartition : String,
                                 @BeanProperty var cntrlDateCastFields : String,
                                 @BeanProperty var idocCrtDtTs : String,
                                 @BeanProperty var dupChkWndw : String,
                                 @BeanProperty var numPartitions : String
                                                                 ) extends Serializable


class FilePropertiesObject(
                            @BeanProperty var objName: String,
                            @BeanProperty var dbName: String,
                            @BeanProperty var fileBasePath: String,
                            @BeanProperty var delimiter: String,
                            @BeanProperty var archiveFileBasePath: String,
                            @BeanProperty var rejectFileBasePath: String,
                            @BeanProperty var NulchkCol: String,
                            @BeanProperty var lnchkVal: String,
                            @BeanProperty var DtfmtchkCol: String,
                            @BeanProperty var intchkCol: String,
                            @BeanProperty var doublechkCol: String,
                            @BeanProperty var booleanchkCol: String,
                            @BeanProperty var rcdDelimiter: String,
                            @BeanProperty var tgtTblRw: String,
                            @BeanProperty var tgtTblErr: String,
                            @BeanProperty var tgtTblRef: String,
                            @BeanProperty var tgtTblEnr: String,
                            @BeanProperty var unqKeyCols: String,
                            @BeanProperty var sqlPropertyPath: String,
                            @BeanProperty var masterDataFields: String,
                            @BeanProperty var headerOptions: String,
                            @BeanProperty var enclosedBy: String,
                            @BeanProperty var refrencedColumnMap: String,
                            @BeanProperty var loadType: String,
                            @BeanProperty var customSQL: String,
                            @BeanProperty var rejFileForErrorRec: String) extends Serializable

class EnvPropertiesObject(
  @BeanProperty var brokersList:String,
  @BeanProperty var trustStoreLoc:String,
  @BeanProperty var trustPwd:String,
  @BeanProperty var keyStoreLocation: String,
  @BeanProperty var keyStorePwd: String,
  @BeanProperty var keyPwd : String,
  @BeanProperty var mySqlHostName: String,
  @BeanProperty var mySqlDBName: String,
  @BeanProperty var mySqlUserName: String,
  @BeanProperty var mySqlPassword: String,
  @BeanProperty var mySqlPort: String,
  @BeanProperty var mySqlAuditTbl: String,
  @BeanProperty var ambariHost: String,
  @BeanProperty var ambariPort: String,
  @BeanProperty var ambariUser: String,
  @BeanProperty var ambariPwd: String,
  @BeanProperty var clusterName: String,
  @BeanProperty var rmPort: String,
  @BeanProperty var rmUser: String,
  @BeanProperty var rmPwd: String) extends Serializable
  
class SKeyObject(
  @BeanProperty var sKey:String
  ) extends Serializable
class AuditLoadObject(
                       @BeanProperty var audBatchId: String,
                       @BeanProperty var audApplicationName: String,
                       @BeanProperty var audObjectName: String,
                       @BeanProperty var audDataLayerName: String,
                       @BeanProperty var audJobStatusCode: String,
                       // @BeanProperty var audJobstartTimestamp:String,
                       @BeanProperty var audJobEndTimestamp: String,
                       @BeanProperty var audLoadTimeStamp: String,
                       @BeanProperty var audSrcRowCount: Long,
                       @BeanProperty var audTgtRowCount: Long,
                       @BeanProperty var audErrorRecords: Long,
                       @BeanProperty var audCreatedBy: String,
                       @BeanProperty var audJobStartTimeStamp: String,
                       @BeanProperty var audJobDuration: String,
                       @BeanProperty var flNm: String,
                       @BeanProperty var sysBtchNr: String) extends Serializable {
}

class KafkaPropetiesObject(
                            @BeanProperty var propertiesObject: StreamingPropertiesObject,
                            @BeanProperty var consumergroup: String,
                            @BeanProperty var OffsetResetVal: String) extends Serializable

class TransformationPropetiesObject(
                                     @BeanProperty var lookUpTable: String,
                                     @BeanProperty var customSQL1: String,
                                     @BeanProperty var customSQL2: String) extends Serializable
  
  
  


package com.hpe.stream.processor.other
import java.net.ConnectException
import java.sql.Connection
import java.util.HashMap

import com.hpe.config._
import com.hpe.utils.{ Utilities, _ }
import org.apache.log4j.Logger
import org.apache.spark.sql.{ DataFrame, AnalysisException, Row }
import org.apache.spark.sql.types.{ LongType, StringType, StructField, StructType }
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

import scala.collection.Map;
import org.apache.spark.streaming.kafka010.HasOffsetRanges
import org.apache.spark.streaming.kafka010.OffsetRange
import org.apache.spark.TaskContext
import org.apache.spark.streaming.kafka010.CanCommitOffsets
import org.apache.spark.sql.types.IntegerType

object KafkaToHistoryProcessor {

  val logger = Logger.getLogger(getClass.getName)

  def checkAndRestartSQLConnection(sqlCon: Connection, propertiesFilePath: String): Connection = {
    var sqlConTemp: Connection = sqlCon
    logger.info("+++++++++++ SQL Connection Active ?-" + !(sqlCon.isClosed) + "+++++++++++")
    //  sqlCon.close()
    if (sqlCon.isClosed) {
      logger.info("+++++++++++ SQL Connection was closed. Restarting the connection +++++++++++")
      val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
      val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
      val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
      val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
      sqlConTemp = Utilities.getConnection(envPropertiesObject)
      logger.info("+++++++++++ SQL Connection Active ?-" + !sqlCon.isClosed + "+++++++++++")
    }
    sqlConTemp
  }

  def dataPipeLine(propertiesObject: StreamingPropertiesObject, kafkaParams: Map[String, Object], configObject: ConfigObject, topicList: List[String], envPropertiesObject: EnvPropertiesObject, auditTbl: String, propertiesFilePath: String): Boolean = {

    /*Check if the SQL connection is active */

    val messages = KafkaUtils.createDirectStream[String, String](configObject.getSsc(), PreferConsistent, Subscribe[String, String](propertiesObject.getTopicList().split(','), kafkaParams))
    var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    import scala.collection.JavaConversions._
    val tblMappingArr = propertiesObject.getTableNameMapping().split(",")
    val idocColumnName = propertiesObject.getFilterExpression()
    logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Mapping Array: " + tblMappingArr.foreach { println })
    val tblTopicMap: Map[String, String] = new HashMap[String, String]()
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    for (element <- tblMappingArr) {
      logger.info("****************************" + element)
      val topic = element.split("\\|")(0)
      val histTbl = element.split("\\|")(1)
      tblTopicMap.put(topic, histTbl)
    }

    val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
    val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
    val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
    val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
    val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
    //val auditBatchId = ld_jb_nr + "_" + Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

    //auditObj.setAudBatchId(auditBatchId)
    auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudDataLayerName("history_load")
    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
    auditObj.setAudJobStatusCode("success")
    auditObj.setAudSrcRowCount(0)
    auditObj.setAudTgtRowCount(0)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    val hist_tbl_schema = (new StructType).add("payload", StringType).add("intgtn_fbrc_msg_id", LongType).add("topic", StringType).add("kafka_partition_id", IntegerType)

    val spark = configObject.getSpark()

    // Registering all the UDFs
    val jsonToFlatUDF = udf(Utilities.jsonToString _)
    val putNullToFlatUDF = udf(Utilities.nullPutUDF _)
    val dqvalidate = udf(DataQuality.DQValidchck _)

    val json_hive_raw_map_rdd = spark.sparkContext.parallelize(Seq(propertiesObject.getHiveJsonRawMap()))
    val jsonHeaderList: String = Utilities.getJsonHeaders(json_hive_raw_map_rdd, propertiesObject.getRcdDelimiter())

    messages.foreachRDD(streamRDD => {
      val auditBatchId = ld_jb_nr + "_" + Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
      auditObj.setAudBatchId(auditBatchId)
      auditObj.setAudDataLayerName("history_load")
      var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
      auditObj.setAudJobStartTimeStamp(startTime)
      val offsetRanges = streamRDD.asInstanceOf[HasOffsetRanges].offsetRanges
      var isHistoryLoaded = false
      if (!streamRDD.isEmpty()) {
        val eff_frm_date = Utilities.getCurrentTimestamp()
        auditObj.setAudLoadTimeStamp(startTime)
        val kafkaRDD = streamRDD.map(x => Row(x.value().toString(), x.offset(), x.topic(), x.partition()))
        var input_df_single_col = spark.sqlContext.createDataFrame(kafkaRDD, hist_tbl_schema)
        input_df_single_col.createOrReplaceTempView("hist_temp")
        //logger.debug(input_df_single_col.show)
        for (topic <- topicList) {
          import spark.implicits._
          val histTbl = propertiesObject.getDbName() + "." + tblTopicMap(topic)
          logger.info("############ Extracting data for Topic : " + topic + " and dumping to table : " + histTbl)
          var dfLoc = spark.sql("describe formatted " + histTbl)
          val rows = dfLoc.filter(dfLoc("col_name").contains("ins_gmt_dt") && dfLoc("data_type").contains("date")).select("col_name").distinct.as[String].collect
          val partitionCol = if (rows != null && rows.toList.length > 0) rows(0) else null
          var histDf: DataFrame = null
          if (partitionCol != null) {
            histDf = spark.sqlContext.sql(f"""select payload,cast(intgtn_fbrc_msg_id as String) as intgtn_fbrc_msg_id,cast("$eff_frm_date" as timestamp) as ins_gmt_ts, "$auditBatchId" as ld_jb_nr, kafka_partition_id, date(cast("$eff_frm_date" as timestamp)) as ins_gmt_dt  from hist_temp where topic='$topic'""")
          } else {
            histDf = spark.sqlContext.sql(f"""select payload,cast(intgtn_fbrc_msg_id as String) as intgtn_fbrc_msg_id,cast("$eff_frm_date" as timestamp) as ins_gmt_ts, "$auditBatchId" as ld_jb_nr, kafka_partition_id from hist_temp where topic='$topic'""")
          }
          isHistoryLoaded = Utilities.storeDataFrame(histDf, "Append", "ORC", histTbl, 1)
          if (isHistoryLoaded && propertiesObject.getAutoCommit().toBoolean) {
            logger.info("######COMMITING OFFSET#######")
            messages.asInstanceOf[CanCommitOffsets].commitAsync(offsetRanges)
          } else if (isHistoryLoaded || !propertiesObject.getAutoCommit().toBoolean) {
            logger.info("######NOT COMMITING OFFSET SINCE AUTOCOMMIT IS FALSE#######")
          }
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudSrcRowCount(kafkaRDD.count().toInt)
          auditObj.setAudTgtRowCount(histDf.count().toInt)
          auditObj.setAudErrorRecords((auditObj.audSrcRowCount - auditObj.audTgtRowCount).toInt)
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          auditObj.setAudJobStatusCode("success")
          //Check if SQL connection is active
          var sqlCon = Utilities.getConnection(envPropertiesObject)
          try {
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          } finally {
            if (sqlCon != null) {
              sqlCon.close()
            }
          }
        }
      }
    })
    return true
  }

}

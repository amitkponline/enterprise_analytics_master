package com.hpe.stream.processor.other
import java.net.ConnectException
import java.sql.Connection
import java.util.HashMap

import com.hpe.config._
import com.hpe.utils.{ Utilities, _ }
import org.apache.log4j.Logger
import org.apache.spark.sql.{ AnalysisException, Row, DataFrame }
import org.apache.spark.sql.types.{ LongType, StringType, StructField, StructType }
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

import scala.collection.Map;
import org.apache.spark.streaming.kafka010.HasOffsetRanges
import org.apache.spark.streaming.kafka010.OffsetRange
import org.apache.spark.TaskContext
import org.apache.spark.streaming.kafka010.CanCommitOffsets
import org.apache.spark.sql.types.IntegerType
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path

object HistorytoRefStreaming {

  val logger = Logger.getLogger(getClass.getName)

  def checkAndRestartSQLConnection(sqlCon:Connection,propertiesFilePath:String):Connection ={
    var sqlConTemp:Connection=sqlCon
    logger.info("+++++++++++ SQL Connection Active ?-"+ ! (sqlCon.isClosed)+"+++++++++++" )
    if(sqlCon.isClosed){
      logger.info("+++++++++++ SQL Connection was closed. Restarting the connection +++++++++++")
      val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
      val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
      val envPropertiesFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"connection.properties"
	    val envPropertiesObject:EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
	    sqlConTemp = Utilities.getConnection(envPropertiesObject)
      logger.info("+++++++++++ SQL Connection Active ?-"+ !sqlCon.isClosed+"+++++++++++" )
    }
    sqlConTemp
  }

  def dataPipeLine(propertiesObject: StreamingPropertiesObject, kafkaParams: Map[String, Object], configObject: ConfigObject, topicList: List[String], envPropertiesObject: EnvPropertiesObject, auditTbl: String, propertiesFilePath: String): Boolean = {
    val messages = KafkaUtils.createDirectStream[String, String](configObject.getSsc(), PreferConsistent, Subscribe[String, String](propertiesObject.getTopicList().split(','), kafkaParams))
    var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    import scala.collection.JavaConversions._
    val tblMappingArr = propertiesObject.getTableNameMapping().split(",")
    val idocColumnName = propertiesObject.getFilterExpression()
    logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@Mapping Array: " + tblMappingArr.foreach { println })
    val tblTopicMap: Map[String, String] = new HashMap[String, String]()
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    for (element <- tblMappingArr) {
      logger.info("****************************" + element)
      val topic = element.split("\\|")(0)
      val histTbl = element.split("\\|")(1)
      tblTopicMap.put(topic, histTbl)
    }

    val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
    val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
    val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
    val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
    val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
    auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudDataLayerName("history_load")
    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
    auditObj.setAudJobStatusCode("success")
    auditObj.setAudSrcRowCount(0)
    auditObj.setAudTgtRowCount(0)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    val hist_tbl_schema = (new StructType).add("payload", StringType).add("intgtn_fbrc_msg_id", LongType).add("topic", StringType).add("kafka_partition_id",IntegerType)

    val spark = configObject.getSpark()
    val errTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblErr()
    val rwTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw()
    val refTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef()
    val dataDFRef = spark.sqlContext.sql(f"""select * from $refTblNm limit 0""")
    val colListRef = dataDFRef.columns
    val dataDF = spark.sqlContext.sql(f"""select * from $errTblNm limit 0""")
    val colList = dataDF.columns
    val dataDFRaw = spark.sqlContext.sql(f"""select * from $rwTblNm limit 0""")
    val colListRaw = dataDFRaw.columns
    var schema = StructType(propertiesObject.getColListSep().split(propertiesObject.getRcdDelimiter()).map(fieldName => StructField(fieldName, StringType, true)))
    val offset_schema = StructType(Array(StructField("intgtn_fbrc_msg_id", StringType, true)))
    schema = StructType(schema ++ offset_schema)

    // Registering all the UDFs
    val jsonToFlatUDF = udf(Utilities.jsonToString _)
    val putNullToFlatUDF = udf(Utilities.nullPutUDF _)
    val dqvalidate = udf(DataQuality.DQValidchck _)
    val generateSeqID = udf(Utilities.generateSeqID _)

    val dateFormatQuery = Utilities.prepareDateDoubleFormatQuery(colListRaw, propertiesObject.getDateCastFields(), propertiesObject.getDoublechkCol)
    val dateFormatQueryRef = Utilities.prepareDateDoubleFormatQuery(colListRef, propertiesObject.getDateCastFields(), propertiesObject.getDoublechkCol)

    val json_hive_raw_map_rdd = spark.sparkContext.parallelize(Seq(propertiesObject.getHiveJsonRawMap()))
    val jsonHeaderList: String = Utilities.getJsonHeaders(json_hive_raw_map_rdd, propertiesObject.getRcdDelimiter())
    
    

    messages.foreachRDD(streamRDD => {
        val auditBatchId = ld_jb_nr + "_" + Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
        var rawSqlQuery = Utilities.final_hive_json_mapper(json_hive_raw_map_rdd)
        rawSqlQuery = rawSqlQuery.replaceAll("FROM Temp_DF", ",intgtn_fbrc_msg_id as intgtn_fbrc_msg_id,'' AS src_sys_upd_ts, '" + src_sys_ky + "' as src_sys_ky, '' AS lgcl_dlt_ind,  current_timestamp() AS ins_gmt_ts, '' AS upd_gmt_ts, '' AS src_sys_extrc_gmt_ts,'' AS src_sys_btch_nr, '" + fl_nm + "'  AS fl_nm, '" + auditBatchId + "' AS ld_jb_nr FROM Temp_DF")
        auditObj.setAudBatchId(auditBatchId)
        auditObj.setAudDataLayerName("history_load")
        var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
        auditObj.setAudJobStartTimeStamp(startTime)
        val offsetRanges = streamRDD.asInstanceOf[HasOffsetRanges].offsetRanges
        
        var isHistoryLoaded = false
        if (!streamRDD.isEmpty() && streamRDD.count != 0) {
          val eff_frm_date = Utilities.getCurrentTimestamp()
          auditObj.setAudLoadTimeStamp(startTime)
          val kafkaRDD = streamRDD.map(x => Row(x.value().toString(), x.offset(), x.topic(),x.partition()))
          var input_df_single_col = spark.sqlContext.createDataFrame(kafkaRDD, hist_tbl_schema)
          input_df_single_col.createOrReplaceTempView("hist_temp")
          for (topic <- topicList) {
            val histTbl = propertiesObject.getDbName() + "." + tblTopicMap(topic)
            logger.info("############ Extracting data for Topic : " + topic + " and dumping to table : " + histTbl)
            import spark.implicits._ 
            var dfLoc = spark.sql("describe formatted " + histTbl)
            val rows = dfLoc.filter(dfLoc("col_name").contains("ins_gmt_dt") && dfLoc("data_type").contains("date")).select("col_name").distinct.as[String].collect
            val partitionCol = if (rows!=null && rows.toList.length>0) rows(0) else null 
            var histDf: DataFrame = null
            if(partitionCol!=null){
               histDf = spark.sqlContext.sql(f"""select payload,cast(intgtn_fbrc_msg_id as String) as intgtn_fbrc_msg_id,cast("$eff_frm_date" as timestamp) as ins_gmt_ts, "$auditBatchId" as ld_jb_nr, kafka_partition_id, date(cast("$eff_frm_date" as timestamp)) as ins_gmt_dt  from hist_temp where topic='$topic'""")
            }else{
               histDf = spark.sqlContext.sql(f"""select payload,cast(intgtn_fbrc_msg_id as String) as intgtn_fbrc_msg_id,cast("$eff_frm_date" as timestamp) as ins_gmt_ts, "$auditBatchId" as ld_jb_nr, kafka_partition_id from hist_temp where topic='$topic'""")
            }
            isHistoryLoaded = Utilities.storeDataFrame(histDf, "Append", "ORC", histTbl)
            if(isHistoryLoaded && propertiesObject.getAutoCommit().toBoolean){
              logger.info("######COMMITING OFFSET#######")
              messages.asInstanceOf[CanCommitOffsets].commitAsync(offsetRanges)
            }else if (isHistoryLoaded || !propertiesObject.getAutoCommit().toBoolean){
              logger.info("######NOT COMMITING OFFSET SINCE AUTOCOMMIT IS FALSE#######")
            }
            auditObj.setAudJobStatusCode("success")
            auditObj.setAudSrcRowCount(kafkaRDD.count().toInt)
            auditObj.setAudTgtRowCount(histDf.count().toInt)
            auditObj.setAudErrorRecords((auditObj.audSrcRowCount - auditObj.audTgtRowCount).toInt)
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            auditObj.setAudJobStatusCode("success")
            //Check if SQL connection is active
            var sqlCon:Connection = Utilities.getConnection(envPropertiesObject)
            sqlCon = checkAndRestartSQLConnection(sqlCon,propertiesFilePath)
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

            //Start Time for hist_rw load
            startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
            auditObj.setAudJobStartTimeStamp(startTime)
            auditObj.setAudDataLayerName("hist_rw")

            //----------- Selecting Unique records from Payload in History table -----------------------------------------------------
            input_df_single_col = spark.sqlContext.sql(f"""select payload,max(intgtn_fbrc_msg_id) as intgtn_fbrc_msg_id ,topic from hist_temp group by payload,topic """)

            // Parsing JSON

            logger.info("########+++++++============>REGISTERING UDF===================#####")
            logger.info("########+++++++============>propertiesObject.getColListSep()===================#####" + propertiesObject.getColListSep())

            val newDF = input_df_single_col.withColumn("jsonFlatCol", jsonToFlatUDF(input_df_single_col("payload"), lit(propertiesObject.getRcdDelimiter()), lit(jsonHeaderList)))
            newDF.createOrReplaceTempView("temp_table_hist")
            var final_df = spark.sqlContext.sql(f"""select intgtn_fbrc_msg_id,explode(split(jsonFlatCol, '\\n')) as updatedCol, regexp_replace(regexp_replace(split(jsonFlatCol,'\\n')[0],'[@:-]| ','_'),'[()]','') as header from temp_table_hist where topic='$topic'""")

            final_df = final_df.filter(!lower(final_df.col("updatedCol")).contains(propertiesObject.getFilterExpression().toLowerCase()))
            final_df.persist(StorageLevel.MEMORY_AND_DISK_SER)
            final_df.createOrReplaceTempView("testdf")
            final_df = spark.sqlContext.sql("select * from testdf where length(trim(updatedCol))<>0")
            final_df = final_df.withColumn("dataWithNull", putNullToFlatUDF(final_df("updatedCol"), lit(propertiesObject.getRcdDelimiter()), final_df("header"), lit(propertiesObject.getColListSep())))
            final_df = final_df.drop("header", "updatedCol")
            final_df.repartition(10)

            logger.info("Raw SQL===================" + rawSqlQuery)
            var rdd = final_df.select("dataWithNull", "intgtn_fbrc_msg_id").rdd.map { row: Row => (row.getString(0) + propertiesObject.getRcdDelimiter() + row.getLong(1).toString).substring(if ((row.getString(0).head).equals('"')) 1 else 0, (row.getString(0) + propertiesObject.getRcdDelimiter() + row.getLong(1).toString).length()).replaceAll("\"" + propertiesObject.getRcdDelimiter(), propertiesObject.getRcdDelimiter()).replaceAll(propertiesObject.getRcdDelimiter() + "\"", propertiesObject.getRcdDelimiter()).replaceAll("\"" + propertiesObject.getRcdDelimiter() + "\"", propertiesObject.getRcdDelimiter()).replaceAll("\\\\\"", "\"").replaceAll("\n", System.lineSeparator()) }.map(line => line.split(propertiesObject.getRcdDelimiter(), -1)).map(line => Row.fromSeq(line))
            var loadingDF = spark.sqlContext.createDataFrame(rdd, schema)
            loadingDF.createOrReplaceTempView("Temp_DF")
            logger.info("Raw SQl::::::::::::::::" + rawSqlQuery)
            var rawDF_curr = spark.sqlContext.sql(rawSqlQuery)
            logger.info("#####################  ALL DONE #####################")
            var rawDfNullRemoved = rawDF_curr.na.fill("")
      
            // Currency Cast 
            var currCastFields:String = propertiesObject.getCurrencyCastFields
            if (currCastFields != null && currCastFields.trim().length() != 0 ) {
              logger.info("==================== Currency Cast Changes Function ===========================================")
              var currCastFieldsArray: Array[String] = currCastFields.split(",")
              var noOfCols = currCastFieldsArray.length
              while (noOfCols > 0) {
                noOfCols = noOfCols - 1
                logger.info("Currency Cast Column - "+currCastFieldsArray(noOfCols))
                rawDfNullRemoved = Utilities.getcurrCastFields(rawDfNullRemoved,currCastFieldsArray(noOfCols))
              }
            }
            
            var result = rawDfNullRemoved.withColumn("newCol", concat_ws(propertiesObject.getRcdDelimiter(), rawDF_curr.schema.fieldNames.map(c => col(c)): _*))
            //Trimming all columns data
            logger.info("=======propertiesObject.getBooleanchkCol()=================" + propertiesObject.getBooleanchkCol())
            result.persist(StorageLevel.MEMORY_AND_DISK_SER)

            var nf = result.withColumn("flag", dqvalidate(result("newCol"), lit(rawDF_curr.schema.fieldNames.toList.mkString(",")), lit(propertiesObject.getRcdDelimiter()), lit(propertiesObject.getNulchkCol()), lit(propertiesObject.getLnchkVal()), lit(propertiesObject.getDtfmtchkCol()), lit(propertiesObject.getIntchkCol()), lit(propertiesObject.getDoublechkCol()), lit(propertiesObject.getBooleanchkCol()),lit(propertiesObject.getLongchkCol)))

            nf = Utilities.nullifyEmptyStrings(nf)
            nf = nf.persist(StorageLevel.MEMORY_AND_DISK_SER)

            logger.info("==++++++++++++++++++++++++++++++++raw schema+++++++++++++++++++++++++++++==" + rawDF_curr.schema.fieldNames.toList.mkString(","))

            var validrawDF = nf.filter(nf("flag") === "VALID")
            var errorDF = nf.filter(nf("flag").contains("INVALID"))

            errorDF = errorDF.drop("newCol").withColumn("err_cd", lit("100")).withColumnRenamed("flag", "err_msg_cd")

            logger.info("No of error table column===" + colList.length)
            var src_count = input_df_single_col.count

            logger.info("============LAST=================")
            var errorDFWithCol = errorDF.select(colList.head, colList.tail: _*)
            var err_count = errorDFWithCol.count

            logger.info("================+++++++Date Format Query : RAW ++++++++++++++++++++++++++++===============")
            logger.info(dateFormatQuery)
            validrawDF.createOrReplaceTempView("Temp_DF")
            var validRawDfWithDateFormat = spark.sqlContext.sql(dateFormatQuery)
            var tgt_count: Long = 0
            if (propertiesObject.getCustomSQL() != null && propertiesObject.getCustomSQL().size != 0) {
              validRawDfWithDateFormat.createOrReplaceTempView("temp_view")
              val customQuery = propertiesObject.getCustomSQL()
              val validRawDfAfterCustom = spark.sqlContext.sql(customQuery)
              tgt_count = validRawDfAfterCustom.count
              Utilities.storeDataFrame(validRawDfAfterCustom, "Append", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw())
            } else {
              Utilities.storeDataFrame(validRawDfWithDateFormat, "Append", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw())
              tgt_count = validRawDfWithDateFormat.count
            }


            Utilities.storeDataFrame(errorDFWithCol, "Append", "ORC", errTblNm)
            auditObj.setAudLoadTimeStamp(startTime)
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
            auditObj.setAudSrcRowCount(src_count)
            auditObj.setAudTgtRowCount(tgt_count)
            auditObj.setAudErrorRecords(err_count)
            auditObj.setAudJobStatusCode("success")
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            //Check if SQL connection is active
            sqlCon = checkAndRestartSQLConnection(sqlCon,propertiesFilePath)
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            
            startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
            auditObj.setAudJobStartTimeStamp(startTime)
            auditObj.setAudDataLayerName("rw_ref")
            var validRefDfWithDateFormat = spark.sqlContext.sql(dateFormatQueryRef)
            logger.info("================+++++++Date Format Query: REF ++++++++++++++++++++++++++++===============")
            logger.debug(dateFormatQueryRef)
            if (propertiesObject.getCustomSQL() != null && propertiesObject.getCustomSQL().size != 0) {
              validRefDfWithDateFormat.createOrReplaceTempView("temp_view")
              val customQuery = propertiesObject.getCustomSQL()
              validRefDfWithDateFormat = spark.sqlContext.sql(customQuery)
              tgt_count = validRefDfWithDateFormat.count
              Utilities.storeDataFrame(validRefDfWithDateFormat, "Append", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef())
            } else {

              Utilities.storeDataFrame(validRefDfWithDateFormat, "Append", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef())
              tgt_count = validRefDfWithDateFormat.count()
            }
            src_count = tgt_count

            err_count = tgt_count - src_count
            auditObj.setAudSrcRowCount(src_count)
            auditObj.setAudTgtRowCount(tgt_count)
            auditObj.setAudErrorRecords(err_count)
            auditObj.setAudJobStatusCode("success")
            auditObj.setAudLoadTimeStamp(startTime)
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            //Check if SQL connection is active
            sqlCon = checkAndRestartSQLConnection(sqlCon,propertiesFilePath)
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            
            //store consumption layer
            if (propertiesObject.getTgtTblConsmtn() != null && propertiesObject.getTgtTblConsmtn().size != 0) {
              startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
              auditObj.setAudJobStartTimeStamp(startTime)
              auditObj.setAudDataLayerName("ref_cnsmptn")
              validRefDfWithDateFormat.createOrReplaceTempView("temp_view")
              val cnsmptnTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblConsmtn()
              val dataDFCnsmptn = spark.sqlContext.sql(f"""select * from $cnsmptnTblNm limit 0""")
              val colListCnsmptn = dataDFCnsmptn.columns
              val queryCnsmptn = Utilities.prepareConsumptionQuery(colListCnsmptn)
              var validCnsmptnDf = spark.sqlContext.sql(queryCnsmptn)
              logger.debug(queryCnsmptn)
              tgt_count = validCnsmptnDf.count
              Utilities.storeDataFrame(validCnsmptnDf, "Append", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblConsmtn())
              
              src_count = tgt_count
  
              err_count = tgt_count - src_count
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              auditObj.setAudErrorRecords(err_count)
              auditObj.setAudJobStatusCode("success")
              auditObj.setAudLoadTimeStamp(startTime)
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              //Check if SQL connection is active
              sqlCon = checkAndRestartSQLConnection(sqlCon,propertiesFilePath)
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            }
            //end consumption layer

            final_df.unpersist()
            nf.unpersist()
            result.unpersist()
          }
        }
    })
    return true
  }

}

package com.hpe.stream.driver.sap

import java.math.BigInteger
import com.hpe.utils.Utilities
import scala.collection.Map
import org.apache.log4j.Logger
import java.util.HashMap
import com.hpe.config._
import com.hpe.stream.processor.sap.HistorytoRefStreaming
import org.apache.hadoop.fs.{ FileSystem, Path }
import org.apache.hadoop.conf.Configuration
import org.apache.spark.sql.AnalysisException
import java.net.ConnectException

//import com.hpe.finance.ConsumerListener

object SAPKafkaStreaming {
  val log = Logger.getLogger(getClass.getName)
  val shutdownMarker = "hdfs:///tmp/"
  var stopFlag: Boolean = false
  def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty || args.length != 4) {
      log.error("Invalid number of arguments passed.")
      log.error("Arguments Usage: <Waiting Window in seconds> <consumer-group> <OffsetReset> <Properties file path>")
      log.error("Stopping the flow")
      System.exit(1)
    }
    log.info("Number of argument passed is:::" + args.length)
    try {
      val pollingWindow = new BigInteger(String.valueOf(args(0).trim())).longValue()
      // val consumerGroup = String.valueOf(args(1).trim())
      var consumerGroup = String.valueOf(args(1).trim())
      val offsetreset = String.valueOf(args(2).trim())
      val propertiesFilePath = String.valueOf(args(3).trim())
      log.info("Reading kafka properties file from ######################################################" + propertiesFilePath)
      val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
      val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
      val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
      val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
      val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
      var topicList: List[String] = null
      if (args.length == 6) {
        topicList = String.valueOf(args(5).trim()).split(",").toList
      } else {
        topicList = propertiesObject.topicList.split(",").toList
      }

      if (propertiesObject.consumerGroupVal != null && propertiesObject.consumerGroupVal.size != 0) {
        consumerGroup = propertiesObject.consumerGroupVal
      }
      log.info("Connecting to consumer group#########################################################" + consumerGroup + " with offset Reset as :" + offsetreset)
      log.info("#############################################Topic List####" + topicList.foreach { println })
      val kafkaObject: KafkaPropetiesObject = new KafkaPropetiesObject(propertiesObject, consumerGroup, offsetreset)
      val configurationObject: ConfigObject = SetUpConfiguration.setup(pollingWindow, if (propertiesObject.getMaxRatePerPartition() != null) propertiesObject.getMaxRatePerPartition() else "100")
      val kafkaParam: Map[String, Object] = Utilities.getKafkaparam(kafkaObject, envPropertiesObject)
      val appName = configurationObject.getSpark().sparkContext.appName
      val appId = configurationObject.getSpark().sparkContext.applicationId
      var isAppAlreadyRunning = Utilities.isJobAlreadyRunning(envPropertiesObject, appName, appId)
      log.info("============isAppAlreadyRunning::::" + isAppAlreadyRunning)
      if (!isAppAlreadyRunning) {
        val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
        var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
        var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
        auditObj.setAudLoadTimeStamp(startTime)
        auditObj.setAudJobStartTimeStamp(startTime)
        val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
        var status = HistorytoRefStreaming.dataPipeLine(propertiesObject, kafkaParam, configurationObject, topicList, envPropertiesObject, auditTbl, propertiesFilePath)

        if (status) {

          configurationObject.getSsc().start()

          log.info("Triggered the Kafka Batch Successfully")
          var isStopped = false
          while (!isStopped) {
            log.info("calling awaitTerminationOrTimeout")
            isStopped = configurationObject.getSsc().awaitTerminationOrTimeout(-1)
            if (isStopped)
              log.info("confirmed! The streaming context is stopped. Exiting application...")
            else
              log.info("Streaming App is still running. Timeout...")
            if (!isStopped && stopFlag) {
              log.info("stopping ssc right now")
              configurationObject.getSsc().stop(true, true)
              log.info("ssc is stopped!!!!!!!")
            }
          }

        } else {
          log.error("Error triggering the Kafka Batch.")
          configurationObject.getSsc().stop(true, true)
        }
      } else {
        log.error("Application with same name is already running in yarn")
        System.exit(1)
      }
    } catch {
      case sslException: InterruptedException => {
        log.error("Interrupted Exception" + sslException.printStackTrace())
        System.exit(1)
      }
      case nseException: NoSuchElementException => {
        log.error("No Such element found: " + nseException.printStackTrace())
        System.exit(1)
      }
      case anaException: AnalysisException => {
        log.error("SQL Analysis Exception: " + anaException.printStackTrace())
        System.exit(1)
      }
      case connException: ConnectException => {
        log.error("Connection Exception: " + connException.printStackTrace())
        System.exit(1)
      }
      case exception: Exception => {
        log.error("Exception:" + exception.printStackTrace())
        System.exit(1)
      }
    }

  }
}
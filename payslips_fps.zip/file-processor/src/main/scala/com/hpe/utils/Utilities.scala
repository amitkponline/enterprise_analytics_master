package com.hpe.utils

import org.apache.log4j.Logger

import util.control.Breaks._
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SQLImplicits
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{ udf, lit, col, broadcast }
import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import org.joda.time.DateTime
import java.util.HashMap
import scala.collection.mutable.Map
import org.apache.spark.streaming.kafka010.Subscribe
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import scala.util.control.Breaks.break
import scala.sys.process._
import org.apache.hadoop.fs.FileSystem
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.SparkException
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SaveMode
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.hadoop.mapred.InvalidInputException
import scala.collection.JavaConverters._
import scala.collection.mutable._
import org.yaml.snakeyaml.Yaml
import org.yaml.snakeyaml.constructor.Constructor
import java.time
import java.text.SimpleDateFormat
import java.util.Date
import org.apache.spark.sql.DataFrame
import javax.xml.crypto.Data
import org.apache.spark.rdd.RDD
import java.util.Calendar
import org.apache.commons.lang3.StringUtils

import org.apache.spark.sql.Row
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.DateType
import java.util.Properties
import java.io.FileReader
import org.apache.hadoop.fs.FSDataInputStream
import java.io.FileNotFoundException
import java.util.ArrayList
import org.apache.spark.SparkConf
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.DataFrameWriter
import java.nio.ByteBuffer
import scala.Byte
import java.math.BigInteger
import org.apache.hadoop.io.{ LongWritable, Text }

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat
import org.apache.spark.{ SparkContext, SparkConf }
import org.apache.spark.streaming.{ Seconds, StreamingContext }
import kafka.serializer.StringDecoder
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions.lit
import com.hpe.config.PropertiesObject
import com.hpe.config.KafkaPropetiesObject
import scala.io.Source
import scala.util.control.Exception.Catch
import java.io.IOException
import java.io.FileInputStream
import java.io.File
import java.sql.Connection
import java.sql.DriverManager
import com.github.opendevl.JFlat
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import com.hpe.config.AuditLoadObject
import com.hpe.config.SKeyObject
import com.hpe.config.AES
import com.hpe.config.SQLPropertiesObject
import java.sql.ResultSet
import java.sql.Statement
import scala.util.control.Breaks
import com.hpe.config.EnvPropertiesObject
import com.hpe.config.StreamingPropertiesObject
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.AnalysisException
import java.util.{ Properties }
import javax.mail.{ Message, Session, Transport }
import javax.mail.internet.{ InternetAddress, MimeMessage ,MimeBodyPart,MimeMultipart}
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.util.ByteArrayDataSource
import com.hpe.config.SharedConfigObjectProperties
import org.apache.spark.sql.Dataset
import com.hpe.config.SQLConfigObjectProperties


object Utilities {
  val log = Logger.getLogger(getClass.getName)
  val ISOFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

  /**
   * removeDuplicates function removes the duplicate rows from a DataFrame.
   *
   *
   * @param DataFrame			: Input DataFrame
   * @return DataFrame    : DataFrame with unique rows
   */
  def removeDuplicates(inputDF: DataFrame): DataFrame = {
    log.info("Removing duplicate rows")
    val columnList = inputDF.drop("intgtn_fbrc_msg_id").drop("ins_gmt_ts").columns
    val de_dup_DF = inputDF.dropDuplicates(columnList)
    log.info("Count After Dropping the Duplicate Rows :" + de_dup_DF.count())
    return de_dup_DF
  }

  /**
   * @param str
   * @return
   */
  def getPropertiesobject(str: String): PropertiesObject =
    {

      import scala.collection.JavaConversions._
      val propfileSystem: FileSystem = FileSystem.get(new Configuration)
      val propFileInputStream = propfileSystem.open(new Path(str))
      var properties: Properties = new Properties();
      properties.load(propFileInputStream);
      //	      var properties: Properties = null
      var pObj: PropertiesObject = null
      log.info("++++++++++++++++++++++++++" + str)
      try {
        //						  properties.load(new FileInputStream(str))
        //							val path = getClass.getResource(str)
        log.info("########################################Utilities::::::::::::::" + str.toString())
        if (str != null) {
          /*										val source = Source.fromURL(path)
												properties = new Properties()
												properties.load(source.bufferedReader())*/
          pObj = new PropertiesObject(
            properties.getProperty("objName"),
            properties.getProperty("dbName"),
            properties.getProperty("colNm"),
            properties.getProperty("msgdelimeter"),
            properties.getProperty("NulchkCol"),
            properties.getProperty("lnchkVal"),
            properties.getProperty("DtfmtchkCol"),
            properties.getProperty("intchkCol"),
            properties.getProperty("doublechkCol"),
            properties.getProperty("booleanchkCol"),
            properties.getProperty("rcdDelimiter"),
            properties.getProperty("colListSep"),
            properties.getProperty("filterExpression"),
            properties.getProperty("tgtTblRw"),
            properties.getProperty("tgtTblErr"),
            properties.getProperty("tgtTblRef"),
            properties.getProperty("tgtTblEnr"),
            properties.getProperty("sqlPropertyPath"),
            properties.getProperty("masterDataFields"),
            properties.getProperty("hiveJsonRawMap"),
            properties.getProperty("dateCastFields"),
            properties.getProperty("longchkCol"),
            properties.getProperty("sourceFilePath"), // Added for File System
            properties.getProperty("tgtTblStg"),
            properties.getProperty("customBooleanFields"),
            properties.getProperty("regexQuery"),
            properties.getProperty("rwTblSaveMode"),
            properties.getProperty("refTblSaveMode"),
            properties.getProperty("multilineOption"),
            properties.getProperty("currencyCastFields"),
            properties.getProperty("quotes"),
            properties.getProperty("ArchiveDir"),
            properties.getProperty("lrTrimFields"),
            properties.getProperty("errorDir"),
            properties.getProperty("hederMatchReqd"),
            properties.getProperty("primaryKeyColList"),
            properties.getProperty("srcReferenceKeyColList"),
            properties.getProperty("tgtReferenceKeyColList"),
            properties.getProperty("naturalKeys"),
            properties.getProperty("surrKey"),
            properties.getProperty("latestEntryKey"),
            properties.getProperty("tgtTblConsmtn"),
            properties.getProperty("cnsmpTblSaveMode"),
            properties.getProperty("sourceSystem"),
            properties.getProperty("fileToObjNmMap"),
            properties.getProperty("sendMailTo"),
            properties.getProperty("sendMailFrom"),
            properties.getProperty("sendMailSMTPHost"),
            properties.getProperty("sendMailSMTPPort"),
            properties.getProperty("sendMailUsername"),
            properties.getProperty("sendMailPassword"),
            properties.getProperty("srcFilePattern"),
            properties.getProperty("isPositional"),
            properties.getProperty("headerLength"),
            properties.getProperty("dataLength"),
            properties.getProperty("trailerLength"),
            properties.getProperty("repartitionNo"),
            properties.getProperty("strtIndx"),
            properties.getProperty("endIndx"),
            properties.getProperty("apiName", ""),
            properties.getProperty("deleteflag", ""),
            properties.getProperty("deletejoinCol", ""),
            properties.getProperty("deleteTableName", ""),
            properties.getProperty("preConsmtnTbl", ""),
            properties.getProperty("groupByKeys", ""),
            properties.getProperty("retainRecords", ""),
            properties.getProperty("hardDeleteCol", ""),
            properties.getProperty("multipleSurrKeyInd", ""),
            properties.getProperty("filterKey", ""),
            properties.getProperty("lateralView", ""),
            properties.getProperty("pkNullChkReqd", ""),
            properties.getProperty("commonErrTblNm", ""))         
        }
        return pObj
      } catch {
        case ex: FileNotFoundException => return null
        case ex: IOException           => return null

      }

    }

  def getSQLPropertiesObject(path: String, sk:SKeyObject): SQLPropertiesObject =
    {
      import scala.collection.JavaConversions._
      val propfileSystem: FileSystem = FileSystem.get(new Configuration)
      val propFileInputStream = propfileSystem.open(new Path(path))
      var properties: Properties = new Properties();
      properties.load(propFileInputStream);
      //	      var properties: Properties = null
      var sqlObj: SQLPropertiesObject = null
      try {
        if (path != null) {
          sqlObj = new SQLPropertiesObject(
            properties.getProperty("mySqlHostName"),
            properties.getProperty("mySqlDBName"),
            properties.getProperty("mySqlUserName"),
            properties.getProperty("mySqlPassword"),
            properties.getProperty("mySqlPort"),
            properties.getProperty("mySqlAuditTbl"))
        }
        return sqlObj
      } catch {
        case ex: FileNotFoundException => return null
        case ex: IOException           => return null

      }

    }

  def getConnection(sqlPropertiesObject: SQLPropertiesObject): Connection = {
    val host = sqlPropertiesObject.getMySqlHostName()
    val port = sqlPropertiesObject.getMySqlPort()
    val username = sqlPropertiesObject.getMySqlUserName()
    val password = sqlPropertiesObject.getMySqlPassword()
    val dbName = sqlPropertiesObject.getMySqlDBName()
    try {
      Class.forName("com.mysql.jdbc.Driver");
      var con: Connection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + dbName, username, password);
      return con
    } catch {
      case e: Exception => return null
    }
  }

  def insertIntoAudit(sqlcon: Connection, auditObj: AuditLoadObject, fulltblName: String) = {

    try {
      log.info("WRITING INTO AUDIT LOG -- ")
      val audBatchId = auditObj.getAudBatchId()
      val audApplicationName = auditObj.getAudApplicationName
      val audObjectName = auditObj.getAudObjectName
      val audLayerName = auditObj.getAudDataLayerName
      val audStatusCode = auditObj.getAudJobStatusCode
      val audJobEndTimestamp = auditObj.getAudJobEndTimestamp()
      val audLoadTimeStamp = auditObj.getAudLoadTimeStamp()
      val audSrcRowCount = auditObj.getAudSrcRowCount()
      val audTgtRowCount = auditObj.getAudTgtRowCount()
      val audErrorRecords = auditObj.getAudErrorRecords()
      val audCreatedBy = auditObj.getAudCreatedBy()
      val audJobStartTimestamp = auditObj.getAudJobStartTimeStamp()
      val jobDuration = auditObj.getAudJobDuration()
      val flNm = auditObj.getFlNm()
      val sysBtchNr = auditObj.getSysBtchNr()

      val auditSQL = "INSERT INTO " + fulltblName + " SELECT \"" + audBatchId + "\" as btch_id, \"" + audApplicationName + "\" as appl_nm,\"" + audObjectName + "\" as obj_nm , \"" + audLayerName + "\" as dta_lyr_nm, \"" + audStatusCode + "\" as jb_stts_cd, \"" + audJobEndTimestamp + "\" as jb_cmpltn_ts, \"" + audLoadTimeStamp + "\" as ld_ts, \"" + audSrcRowCount + "\" as src_rec_qty, \"" + audTgtRowCount + "\" as tgt_rec_qty, \"" + audErrorRecords + "\" as err_rec_qty, \"" + audCreatedBy + "\" as crtd_by_nm ,\"" + audJobStartTimestamp + "\" as jb_strt_ts,\"" + jobDuration + "\" as jb_durtn_tm_ss,\"" + flNm + "\" as fl_nm,\"" + sysBtchNr + "\" as sys_btch_nr"
      log.info("===================Print SQL :: " + auditSQL)
      val preparedStmt = sqlcon.prepareStatement(auditSQL);
      preparedStmt.execute();

      log.info("INSERTED INTO AUDIT LOG")
    } catch {
      case e: Exception => e.printStackTrace()

    }

  }

   def readHistMaxLoadTimestamp(sqlcon: Connection, objName: String): String = {
    var max_ld_ts: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(ld_ts) is NULL then '1900-01-01 00:00:00' else max(ld_ts) end as max_ld_ts from jb_aud_tbl where  dta_lyr_nm='hist_rw' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and tgt_rec_qty >0 and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("max(ld_ts)=" + rs.getTimestamp("max_ld_ts"))
        max_ld_ts = rs.getTimestamp("max_ld_ts").toString()
      }
      // close ResultSet rs
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_ld_ts
  }

  def validateNotNull(sqlContext: HiveContext, df: DataFrame, primary_key_col_list: List[String]): List[DataFrame] = {
    var primary_correct_col = ""
    var primary_incorrect_col = ""

    for (z <- primary_key_col_list) {
      primary_correct_col = primary_correct_col + "and length(trim(" + z + "))>0 and  trim(" + z + ")<>'(null)' and trim(" + z + ") not like '%?'"
      primary_incorrect_col = primary_incorrect_col + "OR " + z + " is null OR length(trim(" + z + "))=0  OR trim(" + z + ")='(null)' OR trim(" + z + ") like '%?'"
    }
    df.show
    import sqlContext.implicits._
    df.registerTempTable("null_data")
    val valid_select_query = "select * from null_data where " + (primary_correct_col.drop(3))
    val invalid_select_query = "select * from null_data where " + (primary_incorrect_col.drop(2))

    log.info("valid_records_query:- " + valid_select_query)
    log.info("invalid_records_query:- " + invalid_select_query)

    val validDF = sqlContext.sql(valid_select_query)
    val invalidDF = sqlContext.sql(invalid_select_query)
    List(validDF, invalidDF)
  }

  def convertDateTime(dt: String, fmt: String): String = {
    try {
      val dateFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern(fmt)
      val jodatime: DateTime = dateFormatGeneration.parseDateTime(dt);
      val str: String = ISOFormatGeneration.print(jodatime);
      str
    } catch {
      case xe: IllegalArgumentException => return null
      case xe: NullPointerException     => return null
    }
  }

  /**
   * getCurrentTimestamp function returns the current timestamp in ISO format
   * @return : current timestamp in ISO format
   */
  def getCurrentTimestamp(): String = {
    val ISOFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS");
    val now: DateTime = new org.joda.time.DateTime()
    ISOFormatGeneration.print(now)
  }

  def getCurrentTimestamp(format: String): String = {
    val ISOFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern(format)
    //("yyyy-MM-dd HH:mm:ss.SSS");
    val now: DateTime = new org.joda.time.DateTime()
    ISOFormatGeneration.print(now)
  }

  def getDate(input: String ,format: String): String = {
    val datetime_format: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS");
    val date_int_format: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd");
    val string_to_date = datetime_format.parseDateTime(input)
    date_int_format.formatted(string_to_date.toString())
  }
  /**
   * @param hiveContext
   * @param dbName
   * @param tgtTableName
   * @return
   */
  def getTableCount(hiveContext: HiveContext, dbName: String, tgtTableName: String): Long = {
    val tableName = dbName + "." + tgtTableName
    val df = hiveContext.table(tableName)
    return df.count()
  }
 def storeErrDataFrame(transformedDF: DataFrame, saveMode: String, storageFormat: String, targetTable: String): Boolean = {
    var loadStatus = true
    try {
      val tblCount = transformedDF.count
      log.info("Writing to HIVE TABLE : " + targetTable)// + " :: DataFrame Count :" + tblCount)
      if (transformedDF != null && tblCount>0 && saveMode.trim().length() != 0 && storageFormat.trim().length() != 0 && targetTable.trim().length() != 0) {
        log.info("SAVE MODE::" + saveMode + " Table Name :: " + targetTable + " Format :: " + storageFormat)
        transformedDF.coalesce(2).write.mode(saveMode).format(storageFormat.trim()).insertInto(targetTable.trim())
      } 

    } catch {
      case e: AnalysisException => e.printStackTrace();
        log.error("ERROR Writing to HIVE TABLE : " + targetTable);
        loadStatus = false;
    }
    return loadStatus
  }
  /**
   * storeDataFrame function stores the data frame to input HIVE table
   *
   * @param transformedDF	: DataFrame to be stored
   * @param saveMode			: Mode of saving (OverWrite,Append,Ignore,ErrofIfExists)
   * @param storageFormat	: Storage format for the target table (ORC,Parquet etc)
   * @param targetTable		:	Target HIVE table name with Database name
   * @return Boolean			: flag to indicate if the action was successful or not
   */
  def storeDataFrame(transformedDF: DataFrame, saveMode: String, storageFormat: String, targetTable: String): Boolean = {
    var loadStatus = true
    try {
      //val tblCount = transformedDF.count
      log.info("Writing to HIVE TABLE : " + targetTable)// + " :: DataFrame Count :" + tblCount)
      if (transformedDF != null && saveMode.trim().length() != 0 && storageFormat.trim().length() != 0 && targetTable.trim().length() != 0) {
        log.info("SAVE MODE::" + saveMode + " Table Name :: " + targetTable + " Format :: " + storageFormat)
        transformedDF.write.mode(saveMode).format(storageFormat.trim()).insertInto(targetTable.trim())
      } 

    } catch {
      case e: AnalysisException => e.printStackTrace(); log.info("ERROR Writing to HIVE TABLE : " + targetTable); loadStatus = false;
    }
    return loadStatus
  }
  def storeDataFrame(transformedDF: DataFrame, saveMode: String, storageFormat: String, targetTable: String,numPartitions: Integer): Boolean = {
    var loadStatus = true
    try {
      //val tblCount = transformedDF.count
      log.info("Writing to HIVE TABLE : " + targetTable )//+ " :: DataFrame Count :" + tblCount)
      if (transformedDF != null && saveMode.trim().length() != 0 && storageFormat.trim().length() != 0 && targetTable.trim().length() != 0) {
        log.info("SAVE MODE::" + saveMode + " Table Name :: " + targetTable + " Format :: " + storageFormat)
        transformedDF.repartition(numPartitions).write.mode(saveMode).format(storageFormat.trim()).insertInto(targetTable.trim())
      } 

    } catch {
      case e: AnalysisException => e.printStackTrace(); log.info("ERROR Writing to HIVE TABLE : " + targetTable); loadStatus = false;
    }
    return loadStatus
  }
  /**
   * @param rdd
   * @return
   */
  def hive_json_mapper(rdd: RDD[String]): String = {
    var sql = ""
    rdd.collect.foreach { x =>
      val cols = x.split(';').toList
      cols.foreach { y =>
        sql = sql + y.replace("|", " AS ") + ","
      }
    }
    sql = sql.dropRight(1)
    return sql
  }

  def getJsonHeaders(rdd: RDD[String], dlmit: String): String = {
    var stringHeader: String = ""
    rdd.collect.foreach { x =>
      val cols = x.split(';').toList
      cols.foreach { y =>
        stringHeader = stringHeader.trim() + y.split("\\|")(0).trim() + dlmit.trim()
      }
    }
    stringHeader = stringHeader.substring(0, stringHeader.lastIndexOf(dlmit))
    return stringHeader
  }

  def final_hive_json_mapper(rdd: RDD[String]): String = {
    var sql = ""
    rdd.collect.foreach { x =>
      val cols = x.split(';').toList
      cols.foreach { y =>
        sql = sql + y.replace("|", " AS ") + ","
      }
    }
    sql = "select " + sql.dropRight(1) + " FROM Temp_DF"
    return sql
  }
  
  def prepareDropPartitionQuery (partitions: String, partititionCol:String, partitionTable: String): String ={
    var sql = ""
    val partitionsList = partitions.split(",").map(_.toString())
    partitionsList.foreach{
      x=> 
        sql = sql+ "PARTITION("+partititionCol+"='"+x+"'), "
    }
   sql = "ALTER TABLE "+partitionTable+" DROP IF EXISTS " + sql.dropRight(2) 
   return sql
  }
  
  def prepareDateFormatQuery(colList: Array[String], dtFmtCol: String): String = {
    var sql = ""
    var hm: Map[String, String] = scala.collection.mutable.Map[String, String]()
    if (dtFmtCol != null && dtFmtCol.size != 0) {
      val colArray = dtFmtCol.split(',').toList

      colArray.foreach { x =>
        //if(x.split('|').toList(1).trim().length()<=10){
        hm.put(x.split('|').toList(0).trim().toLowerCase(), x.split('|').toList(1).trim())

        //}
      }
    }
    colList.foreach { x =>
      if (hm.contains(x)) {
        //sql = sql + "TO_DATE(CAST(UNIX_TIMESTAMP("+x+", '"+hm.getOrElse(x,"yyyy-MM-dd HH:mm:ss")+"') AS TIMESTAMP))" +" AS "+ x + ","
        //sql = sql + "from_unixtime(unix_timestamp("+x+" ,'"+hm.getOrElse(x,"yyyy-MM-dd HH:mm:ss")+"'), 'yyyy-MM-dd HH:mm:ss')"+" AS "+ x + ","
        sql = sql + "case when " + x + " in ('0','00000000','00000000000000') then null else from_unixtime(unix_timestamp(" + x + " ,'" + hm.getOrElse(x, "yyyy-MM-dd HH:mm:ss") + "'), 'yyyy-MM-dd HH:mm:ss')" + " end AS " + x + ","
      } else {
        sql = sql + x + " AS " + x + ","
      }
    }
    sql = "select " + sql.dropRight(1) + " FROM Temp_DF"
    return sql
  }

  /**
   * @param sqlQuery
   * @param colMap
   * @return
   */
  def sqlGenerator(sqlQuery: String, colMap: Map[String, List[String]]): Map[String, String] = {
    var colWithSQL = scala.collection.mutable.Map[String, String]()

    for ((cols, listNull) <- colMap) {
      var sql = sqlQuery
      listNull.foreach { x =>
        sql = sql.replaceAllLiterally(x + " AS", "NULL AS")
      }
      colWithSQL(cols) = "select " + sql + " FROM Temp_DF"
    }
    return colWithSQL
  }

  /**
   * @param str
   * @return
   */
  def jsonToString(str: String, delimeter: String, header: String): String = {
    if (str != null) {
      try {
        val flatMe = new JFlat(str);
        return flatMe.json2Sheet().headerSeparator("_").write2csv(delimeter)
      } catch {
        case ex: Exception =>
          //log.fatal("Exception while parsing JSON")
          log.fatal("Exception Parsing JSON:" + ex)
          //System.exit(1)
          var error = StringBuilder.newBuilder
          error.append("\n")
          val list: Array[String] = header.split(delimeter)
          var count: Int = 0
          for (fileds <- list) {
            if (count == 0) {
              //val subEx = ex.getCause.toString().replaceAll("\n", " ")
              log.info(":::::::::::::JsonToString::::::::::::::"+str.substring(0, if (str.length() > 100) 100 else str.length()) + ".... with exception :" + ex.getCause)
              error.append(" Exception while Parsing JSON : " + str.substring(0, if (str.length() > 100) 100 else str.length()) + ".... with exception :" + ex.getCause).append(delimeter)
            } else {
              error.append("N/A").append(delimeter)
            }
            count = count + 1
          }
          // error =
          return header + error.substring(0, error.lastIndexOf(delimeter))
        //val flatMe = new JFlat("{\"LastModifiedDate\":\"Exception Parsing JSON\"}");
        //return flatMe.json2Sheet().headerSeparator("_").write2csv(delimeter)

      }
    } else { str + "\n" }
  }

  /**
   * @param str
   * @return
   */
  def generateHiveColumns(rdd: RDD[String]): List[String] = {
    var hiveColList = List[String]()
    rdd.collect.foreach { x =>
      val mapList = x.split(";").toList
      mapList.foreach { x =>
        hiveColList = x.split("\\|")(0).trim() :: hiveColList
      }
      hiveColList = hiveColList.filter(_ != "NULL")
    }
    return hiveColList
  }

  def generateHeaderMap(jsonHeaderDF: DataFrame, jsonColList: List[String], delimter: String): Map[String, List[String]] = {
    var headerMap = scala.collection.mutable.Map[String, List[String]]()

    jsonHeaderDF.rdd.map(_.getString(0)).collect().foreach { x =>
      println("==================================headerColumn======" + x)
      import java.util._
      var p = x.split(delimter, -1).toList
      p = jsonColList.diff(p)
      headerMap(x) = p
    }
    return headerMap
  }

  def insert(list: List[String], i: Int, value: String): List[String] = {
    val (front, back) = list.splitAt(i)
    front ++ List(value) ++ back
  }

  def CreateMap(data: List[String], header: List[String]): Map[String, String] = {
    import scala.collection.breakOut
    val hm: LinkedHashMap[String, String] = (header zip data)(breakOut)
    return hm
  }

  def nullPutUDF(str: String, delimeter: String, header: String, cols: String): String = {
    import collection.breakOut
    var colList: List[String] = cols.toUpperCase().split(delimeter).map(_.trim)(breakOut)
    var trimmedList: List[String] = str.split(delimeter, -1).map(_.trim)(breakOut)
    var headerTrimmedList: List[String] = header.toUpperCase().split(delimeter, -1).map(_.trim)(breakOut)
    var hm: Map[String, String] = CreateMap(trimmedList, headerTrimmedList)
    var fullMap: Map[String, String] = collection.mutable.LinkedHashMap[String, String]()
    /*for(i <- 0 until colList.size)
			{
				val newKey:String=colList(i).toUpperCase()
						val newVal:String=hm.getOrElse(newKey, "\"null\"")
						fullMap.put(newKey, newVal)
			}*/
    colList.foreach { x =>
      val newKey: String = x.toUpperCase()
      var newVal: String = hm.getOrElse(newKey, "")
      val tags = "a|abbr|acronym|address|applet|area|article|aside|audio|b|base|basefont|bdo|big|blockquote|body|br|button|canvas|caption|center|cite|code|col|colgroup|datalist|dd|del|dfn|div|dl|dt|em|embed|fieldset|figcaption|figure|font|footer|form|frame|frameset|head|header|h1|h2|h3|h4|h5|h6|hr|html|i|iframe|img|input|ins|kbd|label|legend|li|link|main|map|mark|meta|meter|nav|noscript|object|ol|optgroup|option|p|param|pre|progress|q|s|samp|script|section|select|small|source|span|strike|strong|style|sub|sup|table|tbody|td|textarea|tfoot|th|thead|time|title|tr|u|ul|var|video|wbr"
      if (newVal.contains("</") || newVal.contains("<br>") || newVal.contains("<area>") || newVal.contains("<base>") || newVal.contains("<col>") || newVal.contains("<hr>") || newVal.contains("<img>") || newVal.contains("<input>") || newVal.contains("<link>") || newVal.contains("<meta>") || newVal.contains("<param>") || newVal.contains("<source>")) newVal = newVal.replaceAll("\\<(" + tags + ").*?>", " ").replaceAll("\\</(" + tags + ").*?>", " ").replaceAll("\\\\\\\\", "\\\\") else newVal = newVal.replaceAll("\\\\\\\\", "\\\\")
      if (newVal != null && newVal.length() > 2) {
        newVal = "\"" + newVal.substring(1, newVal.length() - 1).trim() + "\""
      }
      fullMap.put(newKey, newVal)
    }
    fullMap.valuesIterator.toList.mkString(delimeter)

  }
  def prepareQuery(colList: ArrayBuffer[String], hiveColNames: String, customBooleanFields: String): String = {
    import collection.breakOut
    var sql = ""
    var i = 0
    var colnm: Array[String] = hiveColNames.toLowerCase().split(",").map(_.trim)(breakOut)

    colList.foreach { x =>

      if (customBooleanFields != null) {
        val customBooleanFieldsArr: Array[String] = customBooleanFields.toLowerCase().split(",").map(_.trim)(breakOut)

        if (customBooleanFieldsArr contains (colnm(i))) {

          sql = sql + " case when " + x + " ='0' then 'false' when " + x + " ='1' then 'true' else " + x + " end  AS " + colnm(i) + ","
        } else {
          sql = sql + "trim("+x+")" + " AS " + colnm(i) + ","
        }

      } else {
        sql = sql + "trim("+ x +")"+ " AS " + colnm(i) + ","
      }
      i = i + 1
    }
    sql = "select " + sql.dropRight(1) + " FROM Stg_Tmp"
    return sql
  }
  def validateHeader(actualFileHeader: ArrayBuffer[String], expectedFileHeader: ArrayBuffer[String]): Boolean = {
    var isHeaderMatched = false
    if (actualFileHeader.size == expectedFileHeader.size) {
      if (actualFileHeader.mkString(",").equalsIgnoreCase(expectedFileHeader.mkString(","))) {
        isHeaderMatched = true
      } else {
        val loop = new Breaks;
        loop.breakable {
          actualFileHeader.foreach { x =>
            if (expectedFileHeader contains x) {
              isHeaderMatched = true
            } else {
              log.error("Source Column: "+x+" does not match with any of the target field")
              isHeaderMatched = false
              loop.break;
            }

          }
        }

      }
    } else {
      isHeaderMatched = false
    }
    isHeaderMatched
  }
  def validateGLHeader(actualFileHeader: Array[String], expectedFileHeader: Array[String]): Boolean = {
    var isHeaderMatched = false
    if (actualFileHeader.size >= expectedFileHeader.size) {
      if (actualFileHeader.mkString(",").equalsIgnoreCase(expectedFileHeader.mkString(","))) {
        isHeaderMatched = true
      } else {
        val loop = new Breaks;
        loop.breakable {
          expectedFileHeader.foreach { x =>
            if (actualFileHeader contains x) {
              isHeaderMatched = true
            } else {
              log.error("Source Column: "+x+" does not match with any of the source field")
              isHeaderMatched = false
              loop.break;
            }

          }
        }

      }
    } else {
      isHeaderMatched = false
    }
    isHeaderMatched
  }
  def generateSeqID(naturalKey: String): Long = {
    var m: MessageDigest = null
    var seqId: Long = 0
    try {
      m = MessageDigest.getInstance("MD5")
      m.reset()
      m.update(naturalKey.getBytes, 0, naturalKey.getBytes.length)
      val digest: Array[Byte] = m.digest()
      val bigInt: BigInteger = new BigInteger(digest)
      val original: Long = bigInt.longValue()
      var signum: Int = java.lang.Long.signum(original)
      seqId = original
      while (signum == -1) {
        val m1: MessageDigest = MessageDigest.getInstance("MD5")
        m1.reset()
        m1.update(("" + seqId).getBytes, 0, ("" + seqId).getBytes.length)
        val digest1: Array[Byte] = m1.digest()
        val bigInt1: BigInteger = new BigInteger(digest1)
        seqId = bigInt1.longValue()
        signum = java.lang.Long.signum(seqId)
      }
    } catch {
      case e: NoSuchAlgorithmException => e.printStackTrace()
    }
    seqId
  }
  def deleteFileFromHdfs(filePath: String): Boolean = {

    try {
      val conf = new Configuration()
      val fs = FileSystem.get(conf)
      fs.delete(new Path(filePath), true)
    } catch {
      case e: Exception =>
        e.printStackTrace()
        false
    }
    true
  }
  def nullifyEmptyStrings(df: DataFrame): DataFrame = {
    val sqlCtx = df.sqlContext
    val schema = df.schema
    val updatedField = schema.map(x => StructField(x.name,x.dataType,true))
    val updatedSchema = StructType(updatedField)
    val rdd = df.rdd.map(
      row =>
        row.toSeq.map {
          case "" => null
          case otherwise => otherwise
        })
      .map(Row.fromSeq)

    sqlCtx.createDataFrame(rdd, updatedSchema)
  }
  def performCDC(sqlContext: SQLContext, history_df: DataFrame, incremental_df: DataFrame, primary_key_col_list: Array[String]): DataFrame = {
    import sqlContext.implicits._
    log.info("Starting CDC")
    val dataSchema = history_df.columns
    //    val final_incremental_df = incremental_df.except(history_df)
    val dfInnerJoin = history_df.filter(col("dl_load_flag")
      .eqNullSafe("Y")).as("L1").join(broadcast(incremental_df), primary_key_col_list)
      .select($"L1.*").select(dataSchema.head, dataSchema.tail: _*)
    val unchangedData = history_df.except(dfInnerJoin)
    val changedData = dfInnerJoin.drop("dl_load_flag").withColumn("dl_load_flag", lit("N")).select(dataSchema.head, dataSchema.tail: _*)
    val finalData = unchangedData.unionAll(incremental_df.drop("dl_load_date").withColumn("dl_load_date", lit(getCurrentTimestamp)).select(dataSchema.head, dataSchema.tail: _*))
      .unionAll(changedData)
    log.info("Completed CDC !!!")
    finalData
  }
  
   def getEnvPropertiesobject(str: String,sk:SKeyObject): EnvPropertiesObject =
  {
    try {
      val propfileSystem: FileSystem = FileSystem.get(new Configuration)
      val propFileInputStream = propfileSystem.open(new Path(str))
      var properties: Properties = new Properties();
      properties.load(propFileInputStream);
      var pObj: EnvPropertiesObject = null
      log.info("++++++++++++++++++++++++++" + str)

      log.info("########################################Utilities::::::::::::::" + str.toString())
      if (str != null) {
        pObj = new EnvPropertiesObject(
          properties.getProperty("brokersList"),
          properties.getProperty("trustStoreLocString"),
          AES.decrypt(properties.getProperty("trustPwd"),sk.getSKey()),
          properties.getProperty("keyStoreLocation"),
          AES.decrypt(properties.getProperty("keyStorePwd"),sk.getSKey()),
          AES.decrypt(properties.getProperty("keyPwd"),sk.getSKey()),
          properties.getProperty("mySqlHostName"),
          properties.getProperty("mySqlDBName"),
          properties.getProperty("mySqlUserName"),
          AES.decrypt(properties.getProperty("mySqlPassword"),sk.getSKey()),
          properties.getProperty("mySqlPort"),
          properties.getProperty("mySqlAuditTbl")
        )
      }
      return pObj
    } catch {
      case ex: FileNotFoundException =>
      {log.error("Please place the \"connection.properties\" file in "+str+" path"  )
        sys.exit(1)}
      case ex: IOException           => {sys.exit(1)}

    }

  }
   
   def getConnection(envPropertiesObject: EnvPropertiesObject): Connection = {
    val host = envPropertiesObject.getMySqlHostName()
    val port = envPropertiesObject.getMySqlPort()
    val username = envPropertiesObject.getMySqlUserName()
    val password = envPropertiesObject.getMySqlPassword()
    val dbName = envPropertiesObject.getMySqlDBName()

    val url:String = "jdbc:mysql://" + host + ":" + port + "/" + dbName
    import java.util.Properties
    var info = new Properties() // Create Properties object
    info.put("user", username)         // Set user ID for connection
    info.put("password", password)
    info.put("autoReconnect","true")

    //try {
      Class.forName("com.mysql.jdbc.Driver");
      //var con: Connection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + dbName+"?autoReconnect=true", username, password);
      var con:Connection = DriverManager.getConnection(url,info)
      return con
    //} catch {
    //  case e: Exception => return null
    //}
  }
   def checkAndRestartSQLConnection(sqlCon:Connection,propertiesFilePath:String):Connection ={
    var sqlConTemp:Connection=sqlCon
    log.info("+++++++++++ SQL Connection Active ?-"+ ! (sqlCon.isClosed)+"+++++++++++" )
    //  sqlCon.close()
    if(sqlCon.isClosed){
      log.info("+++++++++++ SQL Connection was closed. Restarting the connection +++++++++++")
      val envPropertiesFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"connection.properties"
      val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
      val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
      val envPropertiesObject:EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
      sqlConTemp = Utilities.getConnection(envPropertiesObject)
      log.info("+++++++++++ SQL Connection Active ?-"+ !sqlCon.isClosed+"+++++++++++" )
    }
    sqlConTemp
  }
  def getStreamingPropertiesobject(str: String): StreamingPropertiesObject = {
    val propfileSystem: FileSystem = FileSystem.get(new Configuration)
    val propFileInputStream = propfileSystem.open(new Path(str))
    var properties: Properties = new Properties();
    properties.load(propFileInputStream);
    //	      var properties: Properties = null
    var pObj: StreamingPropertiesObject = null
    log.info("++++++++++++++++++++++++++" + str)
    try {
      //						  properties.load(new FileInputStream(str))
      //							val path = getClass.getResource(str)
      log.info("########################################Utilities::::::::::::::" + str.toString())
      if (str != null) {
        /*										val source = Source.fromURL(path)
                    properties = new Properties()
                    properties.load(source.bufferedReader())*/
        pObj = new StreamingPropertiesObject(
          properties.getProperty("objName"),
          properties.getProperty("autoCommit"),
          properties.getProperty("dbName"),
          properties.getProperty("ctrl_doc_num"),
          properties.getProperty("topicList"),
          properties.getProperty("tableNameMapping"),
          //  properties.getProperty("jsonHiveMapTbl"),
          //  properties.getProperty("tgt_data_tbl"),
          properties.getProperty("tgt_ctrl_tbl"),
          //  properties.getProperty("colNm"),
          // properties.getProperty("msgdelimeter"),
          properties.getProperty("NulchkCol"),
          properties.getProperty("lnchkVal"),
          properties.getProperty("DtfmtchkCol"),
          properties.getProperty("intchkCol"),
          properties.getProperty("doublechkCol"),
          properties.getProperty("booleanchkCol"),
          properties.getProperty("longchkCol"),
          properties.getProperty("rcdDelimiter"),
          //  properties.getProperty("maxRunTime"),
          properties.getProperty("colListSep"),
          properties.getProperty("filterExpression"),
          properties.getProperty("tgtTblRw"),
          properties.getProperty("tgtTblErr"),
          properties.getProperty("tgtTblRef"),
          properties.getProperty("tgtTblConsmtn"),
          properties.getProperty("unqKeyCols"),
          properties.getProperty("masterDataFields"),
          properties.getProperty("hiveJsonRawMap"),
          properties.getProperty("hiveJsonCtrlMap"),
          properties.getProperty("lookUpTable"),
          properties.getProperty("customSQL"),
          properties.getProperty("dateCastFields"),
          properties.getProperty("consumerGroupVal"),
          properties.getProperty("currencyCastFields"),
          properties.getProperty("maxRatePerPartition"),
          properties.getProperty("cntrlDateCastFields"),
          properties.getProperty("sourceFilePath"),
          properties.getProperty("errorDir"),
          properties.getProperty("numPartitions")
        )

      }
      return pObj
    } catch {
      case ex: FileNotFoundException => return null
      case ex: IOException => return null

    }

  }
  
      /**
    * trimAllColumns function is used to trim both trailing and leading white spaces
    */
   def trimRequiredColumns(result: DataFrame, lrTrimCol:String): DataFrame = {
    
    var tempDF :DataFrame = result
    try{
    //for (c_name <- tempDF.columns) {
      tempDF = tempDF.withColumn(lrTrimCol, trim(tempDF.col(lrTrimCol)))
    //}
    }
    catch {
      case ex : Exception => ex.printStackTrace()
    }
     return tempDF
   }
       
    def getcurrCastFields(result: DataFrame, currCol:String) : DataFrame ={

    var tempDF :DataFrame = result
    try {

      tempDF = tempDF.withColumn(currCol, when(trim(tempDF.col(currCol)).contains("-")
        && locate("-", trim(tempDF.col(currCol))) === length(trim(tempDF.col(currCol))), concat(lit("-"), regexp_replace(trim(tempDF.col(currCol)), "-", "")))
        .when(trim(tempDF.col(currCol)).contains(","), regexp_replace(trim(tempDF.col(currCol)), ",", ""))
        .otherwise(trim(tempDF.col(currCol))))
    }
    catch {
      case ex : Exception => ex.printStackTrace()
    }
    return tempDF
  }
    
     def prepareDateDoubleFormatQuery(colList: Array[String], dtFmtCol: String, doubleCol: String): String = {
    var sql = ""
    var hm: Map[String, String] = scala.collection.mutable.Map[String, String]()
    var dCol: List[String] = List()
    if (doubleCol != null && doubleCol.size != 0) {
      dCol = doubleCol.split(",").toList
    }
    if (dtFmtCol != null && dtFmtCol.size != 0) {
      val colArray = dtFmtCol.split(',').toList

      colArray.foreach { x =>
        //if(x.split('|').toList(1).trim().length()<=10){
        hm.put(x.split('|').toList(0).trim().toLowerCase(), x.split('|').toList(1).trim())
        //}
      }
    }
    colList.foreach { x =>
      if (hm.contains(x)) {
        sql = sql + "case when "+x+" in ('0','00000000','00000000000000') then null else from_unixtime(unix_timestamp("+x+" ,'"+hm.getOrElse(x,"yyyy-MM-dd HH:mm:ss")+"'), 'yyyy-MM-dd HH:mm:ss')"+" end AS "+ x + ","
      }
      else if (dCol.contains(x)) {
        sql = sql + "CAST ( " + x + " AS DOUBLE ) AS " + x + ","
      }
      else {
        sql = sql + x + " AS " + x + ","
      }
    }
    sql = "select " + sql.dropRight(1) + " FROM Temp_DF"
    return sql

  }
     
  def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
    val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*).desc)
    val rowDF = df.withColumn("rn", row_number().over(part))
    val res = rowDF.filter("rn==1").drop("rn")
    res
  }
  
  /*Read Raw Table Max load Timestamp*/
  
  def readRawMaxLoadTimestamp(sqlcon:Connection, objName:String, audTbl:String):String ={
    var max_ld_ts:String = null
    try {
      log.info("Reading from Audit table")

      val stmt:Statement=sqlcon.createStatement()
      val auditSQL = "select case when max(ld_ts) is NULL then '1900-01-01 00:00:00' else max(ld_ts) end as max_ld_ts from "+audTbl+" where  dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and tgt_rec_qty >0 and obj_nm='"+objName+"'"
      log.info("===================Print SQL :: "+auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs:ResultSet=stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while(rs.next()){
        log.info("max(ld_ts)="+rs.getTimestamp("max_ld_ts"))
        max_ld_ts=rs.getTimestamp("max_ld_ts").toString()
      }
      // close ResultSet rs
      rs.close();
    } catch {
      case e: Exception =>e.printStackTrace()

    }
    max_ld_ts
  }
  
  /*Read History Table Max load Timestamp*/
  
  def readHistMaxLoadTimestamp(sqlcon: Connection, objName: String, audTbl:String): String = {
    var max_ld_ts: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(ld_ts) is NULL then '1900-01-01 00:00:00' else max(ld_ts) end as max_ld_ts from "+audTbl+ " where  dta_lyr_nm='hist_rw' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and tgt_rec_qty >0 and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("max(ld_ts)=" + rs.getTimestamp("max_ld_ts"))
        max_ld_ts = rs.getTimestamp("max_ld_ts").toString()
      }
      // close ResultSet rs
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_ld_ts
  }
  
   def readHistBatchId(sqlcon: Connection, objName: String,audTbl:String): String = {
    var max_btch_id: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(btch_id) is NULL then '1900-01-01 00:00:00' else max(btch_id) end as max_btch_id from "+audTbl+" where dta_lyr_nm='hist_rw' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      
      while (rs.next()) {
        log.info("max(btch_id)=" + rs.getString("max_btch_id"))
        max_btch_id = rs.getString("max_btch_id")
        
      }
      
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_btch_id
  }
  
   def readRawBatchId(sqlcon: Connection, objName: String,audTbl:String): String = {
    var max_btch_id: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(btch_id) is NULL then '1900-01-01 00:00:00' else max(btch_id) end as max_btch_id from "+audTbl+" where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      
      while (rs.next()) {
        log.info("max(btch_id)=" + rs.getString("max_btch_id"))
        max_btch_id = rs.getString("max_btch_id")
        
      }
      
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_btch_id
  }
   
   /* Malformed JSON exception Handling by sending custom message*/
   
   def isValidJson(json:String): Boolean = {
    var isValidJson = true
    try{
      val flatMe = new JFlat(json)
      //log.info("JSON==============="+json)
      val intResult = flatMe.json2Sheet().headerSeparator("_").getJsonAsSheet()
    }catch{
      case exception: Exception => {
        log.error("Not a Valid JSON"+exception.printStackTrace())
        isValidJson=false
      }
      case illegalStateException: IllegalStateException => {
        log.error("Not a Valid JSON"+illegalStateException.printStackTrace())
        isValidJson=false
      }
    }
    isValidJson
  }
   def readRefBatchId(sqlcon: Connection, objName: String,audTbl:String): String = {
    var max_btch_id: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(btch_id) is NULL then '1900-01-01 00:00:00' else max(btch_id) end as max_btch_id from "+audTbl+" where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      
      while (rs.next()) {
        log.info("max(btch_id)=" + rs.getString("max_btch_id"))
        max_btch_id = rs.getString("max_btch_id")
        
      }
      
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_btch_id
  }
  
  def readCnsmptnBatchId(sqlcon: Connection, objName: String,audTbl: String): String = {
    var max_btch_id: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(btch_id) is NULL then '1900-01-01 00:00:00' else max(btch_id) end as max_btch_id from "+audTbl+" where dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      
      val rs: ResultSet = stmt.executeQuery(auditSQL)
   
      while (rs.next()) {
        log.info("max(btch_id)=" + rs.getString("max_btch_id"))
        max_btch_id = rs.getString("max_btch_id")
      }
      
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_btch_id
  }   
  
  def readRefCount(sqlcon: Connection, objName: String): Long = {
    var refCount: Option[Long] = None
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select sum(tgt_rec_qty) as ref_count from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='rw_ref' and lower(jb_stts_cd)='success' and btch_id > (select COALESCE(max(btch_id),'') from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd) ='success')"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("refCount = " + rs.getLong("ref_count"))
        refCount = Option(rs.getLong("ref_count"))
      }
      // close ResultSet rs
      rs.close();

    } catch {
      case e: Exception => e.printStackTrace()

    }
    refCount match {
      case Some(value) => value
      case None        => 0L
    }

  }

  def sendemail(mailTo: String, mailFrom: String, mailSubject: String, mailContent: String, mailHost: String, stream: FSDataInputStream, fileName: String) = {
  
  var properties: Properties = System.getProperties();
  properties.setProperty("mail.smtp.host", mailHost)
  var session: Session = Session.getDefaultInstance(properties)
  try {
    var message: MimeMessage = new MimeMessage(session)
    message.setFrom(new InternetAddress(mailFrom))
    var mailrecipient = mailTo.split(",")
    for (mailto <- mailrecipient) {
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailto))
    }
    message.setSubject(mailSubject)
    
    var messageBodyPart = new MimeBodyPart()
    
   // messageBodyPart.setText(mailContent) 
    
    messageBodyPart.setText(mailContent, "UTF-8", "html")
    //htmlBodyPart.setText(templ.getMailHtmlBody(), "UTF-8", "html");
        
    var multipart = new MimeMultipart();
    
    var attachmentPart = new MimeBodyPart()
    
    attachmentPart.setDataHandler(new DataHandler(new ByteArrayDataSource(stream,"text/csv")))
    attachmentPart.setFileName(fileName)
    
    multipart.addBodyPart(messageBodyPart)
    
    multipart.addBodyPart(attachmentPart)
    message.setContent(multipart)
    
   // Send email
    Transport.send(message)
  } catch {
    case ex: Exception =>
      log.info("Exception while sendind mail :- "+ex)
  }
}
  
  def getsharedConfigObjectProperties(str: String): SharedConfigObjectProperties =
    {
      try {
        val propfileSystem: FileSystem = FileSystem.get(new Configuration)
        val propFileInputStream = propfileSystem.open(new Path(str))
        var properties: Properties = new Properties();
        properties.load(propFileInputStream);
        var pObj: SharedConfigObjectProperties = null
        log.info("++++++++++++++++++++++++++" + str)
  
        log.info("########################################Utilities::::::::::::::" + str.toString())
        if (str != null) {
          pObj = new SharedConfigObjectProperties(
            properties.getProperty("configFileSourceDir"),
            properties.getProperty("configFileArchiveDir"),
            properties.getProperty("configFileExt"),
            properties.getProperty("configFileDelimiter"),
            properties.getProperty("configObjectNameList"),
            properties.getProperty("schemaName"),
            properties.getProperty("configBaseDir"),
            properties.getProperty("errorStgTable"),
            properties.getProperty("errorTable"),
            properties.getProperty("configErrorDir"),
            properties.getProperty("dataLayerSrcToStg"),
            properties.getProperty("auditStatusSuccess"),
            properties.getProperty("auditStatusFailed"),
            properties.getProperty("configObjPropTable"),
            properties.getProperty("masterDataFile"))
        }
        return pObj
      } catch {
        case ex: FileNotFoundException =>
        {log.error("Please place the \"sharedConfigObjectProperties.properties\" file in "+str+" path"  )
          sys.exit(1)}
        case ex: IOException           => {sys.exit(1)}
  
      }
    }
  //Override function without attachment
  
 def sendemail(mailTo: String, mailFrom: String, mailSubject: String, mailContent: String, mailHost: String) = {
  
  var properties: Properties = System.getProperties();
  properties.setProperty("mail.smtp.host", mailHost)
  var session: Session = Session.getDefaultInstance(properties)
  try {
    var message: MimeMessage = new MimeMessage(session)
    message.setFrom(new InternetAddress(mailFrom))
    var mailrecipient = mailTo.split(",")
    for (mailto <- mailrecipient) {
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailto))
    }
    message.setSubject(mailSubject)
    
    message.setContent(mailContent, "text/html; charset=utf-8");
    //log.info("Sending Message :-"+mailFrom+":"+mailTo+":"+mailSubject+":"+mailContent+ ":" +mailHost)
   // Send email
    Transport.send(message)
  } catch {
    case ex: Exception =>
      log.info("Exception while sendind mail")
  }
}
 
  def createHtmlEmailBody(mail_body: String,alert_msg: String): String = {
    
  val msg =
    s"""<html xmlns:v=\"urn:schemas-microsoft-com:vml\"
xmlns:o=\"urn:schemas-microsoft-com:office:office\"
xmlns:w=\"urn:schemas-microsoft-com:office:word\"
xmlns:m=\"http://schemas.microsoft.com/office/2004/12/omml\"
xmlns=\"http://www.w3.org/TR/REC-html40\">

<head>
<meta http-equiv=Content-Type content=\"text/html; charset=windows-1252\">
<meta name=ProgId content=Word.Document>
<meta name=Generator content=\"Microsoft Word 15\">
<meta name=Originator content=\"Microsoft Word 15\">
<link rel=File-List
href=\"IMPORTANT%20COMMUNICATIONS%20-%20S4%20QTG%20Roseville%20to%20Chandler%20Migration%20-%20Planned%20Outage_files/filelist.xml\">
<link rel=Edit-Time-Data
href=\"IMPORTANT%20COMMUNICATIONS%20-%20S4%20QTG%20Roseville%20to%20Chandler%20Migration%20-%20Planned%20Outage_files/editdata.mso\">

<link rel=themeData
href=\"IMPORTANT%20COMMUNICATIONS%20-%20S4%20QTG%20Roseville%20to%20Chandler%20Migration%20-%20Planned%20Outage_files/themedata.thmx\">
<link rel=colorSchemeMapping
href=\"IMPORTANT%20COMMUNICATIONS%20-%20S4%20QTG%20Roseville%20to%20Chandler%20Migration%20-%20Planned%20Outage_files/colorschememapping.xml\">

<style>

</style>

</head>

<body lang=EN-US link=\"#0563C1\" vlink=\"#954F72\" style='tab-interval:.5in'>

<div class=WordSection1>

<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=0
style='width:22.0in;border-collapse:collapse;mso-yfti-tbllook:1184;mso-padding-alt:
0in 0in 0in 0in'>
<tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:53.75pt'>
  <td width=2112 colspan=4 valign=top style='width:22.0in;background:#425563;
  padding:5.65pt 5.65pt 5.65pt 5.65pt;height:53.75pt'>
  <p class=MsoNormal><![if !vml]><img width=170 height=67
  src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAABUBAMAAAA10mWVAAAABGdBTUEAALGPC/xhBQAAACRQTFRFALOIALOIAAAAAAAAAAAAAAAAAAAAAGZOAAAAALWJAAAAAAAAO7pJFgAAAAt0Uk5TqUq4248yXxz2+gDyATdBAAAGDklEQVRo3u2YTW/aSBjHc1vt3va6R0KbCt8gDVV8Swip8LF5Qc6NTUxln7YpUPnYTRqk+QR7DdiW5ogBjfR8uf0/M+YlCQ2hjarVllFL7fHM85vndWa6IZe1ztK2VMTG0hG//rOs/bGG/HDIL495/a9ngvz22OdkDVlD1pD/F2Rdhf9rkN+XtvD7Ic/Q1pA1ZA35qSBJh0uP+X14NVm8Ty28lCwWoUdv1LvXeDrrlh9+jtTnhdMuu2jb7r3eQNQWju6r4cYZjXgELYJQOlvPxQU6TrTkS+L25T6ECoshNNyok9ZELNQknRs6kLJON1OIIv++JoWvamIgwVKI0pBrAxlU9kjsrgpZqkmshlJ+yjRRsLCjzfxkyGiiSbSX92VcPZBJ9VBG1QMDiXVvg1Kv+pauvJAhYyl7+Gnv5Q6kGdLUkCPvgDur8KFXjSqujHP5WENuMk0Siyh14Sc4YMx/NSSyiQbhLU2am0Fu1TDm9y0wMCQNGWJTORLofM1BE1CNRRY1ZOh5noPoulREosySIUD2SD/KOvcW+g8gPTXkTgFXBUoYSF8pl8kiDTFXiFpPMZIhppWlI7b3Id1W7iVi94wKGmKJ/L4a90ukSiWb0lI49cm4n+Y3SfgRhOYUQwJYINadtYhl1hxBpQyC1CLWMw2lnYaO8AMsGP8wJEJUJVjuw+iicuzzGmq3SvnyCJADCJcROh1RAOTqxLXFa/lezWkCB7VOLXKxIizAt5TLkL4at06B7s9H1yRPIu8C8i75E8fOJi+EOwOxCwi+s3VNdI2NT/qkul0hYKuyldIWVq/do3uVm2mShTBTxjKCWwUVzox+UJ+QOonuBAR2idne/fnoynzr39LY3qEdONdAjLu1JtOMV7p2GSMAUs4gnJ893fkAkuVJX6U5NIQH6/E3ug1kwL3hXU3GugpbYufcFlNNRIkXEogrz5pBwrsZH2uLQl9EXc1i1Y1PhpO8nYfoPhsWD+Z8UmU/WMKHNAOZ80lWu5BFqNWotRYJN9CBgoXE7ODkwizqE43vQyzODjLRVbCQ0gxxMojU0XWnCjsCIT5mYBqeCQjAQoqhJdLKqxEgVKzBGTl3BoG5GvBJJES6qfOkDp0ccXU+8QlETfJkUoV7iApeah126+myZXdV+I57RzBil7BmQXOQM0SZQjGB2ibjYyX8uu7cZStw7cHk7mzTuuEk5qoD2Bj+Zju/JxVySHKBQvAUEtuUFWM1GUO2g61KlzfJTxaN8KKQEBGmmnjepsFG22tifNtDokbn+arOpiZnFD9V8iH/cKlFiXZRYauYGuspPKvSbHtuVqhP8NTGtHblMPb8xPNMfa4m3sX63LWGzNrJhYc/4dMkJN8IcXQlrT2JEb3xvxHC51AxnZwcPyKg/5WD43LIl9bx8fHUXDG5j2givlWT6zuvj0JkS/4AiPw+SFQJGzmcHveogprWzqF4yaPaUV6e+w0+OiYVv/EiwTlRNnIvQy5vucOVITE1+PTIu3aqS+2Y3SVSaW/r4EtEBcdM7Fgf8HqjC3XqrgDB9Qj1V4n8W6r1c5TPY5ep/gl5TneQw261vQdiYoviDkOcobePfY22zxed278GSUul0hVmsaCy8Yn1Bc+70lH8PAgBdRN7yDclP7H1vv0J21R9uFoyDiEck52RhkR8WQtG0uH9yiqzLWsM1RBzkcNX2U9XyJMTD9tPzJepwEBianY69bFxl4X8S+yC1oDNZX92NbrT+ZiGT4bcZI6fQfp8YhZzEGntTiEBpQd8IkBT7qohPA9RLOIOpDyFRK+Ijccjuu7KITwPOT3tdE4XayKjBmLE3tIjvgMSZ5fdKSQSM5/wwWYA6moZ/9AnSXbZNZBrrr7+BJLwCWsgg+GKVfiYq/AEEtFWIp2BKz/6GUQ1W04qJ5BoJ5Tv+QJ4KFsvVt20JpDETos47qWbyAcDEekbHDynECpu4jWyVdEerbppTaJLvuP//9hHHXMzyEubn6c+MZ/kB0Gq9mQIb1kwl94RW6d600f28RFRtnTaFSJ+lnpfw4/5xOfQ5vOdVqzCM+wnPw/E3v0BEM9fbfy/CrJQJj+mCgYAAAAASUVORK5CYII=\"
  align=left hspace=8 style='height:.701in;width:1.763in'
  alt=\"cid:image007.png@01D19CBD.FEA42FA0\" v:shapes=\"Picture_x0020_1\"><![endif]></p>
  </td>
</tr>
<tr style='mso-yfti-irow:1'>
  <td width=2112 colspan=4 valign=top style='width:22.0in;background:#F2F2F2;
  padding:5.65pt 5.65pt 5.65pt 5.65pt'>
  <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 align=left
   width=0 style='width:877.5pt;border-collapse:collapse;mso-yfti-tbllook:1184;
   mso-table-lspace:9.65pt;margin-left:7.85pt;mso-table-rspace:9.65pt;
   margin-right:7.85pt;mso-table-anchor-vertical:paragraph;mso-table-anchor-horizontal:
   column;mso-table-left:left;mso-padding-alt:0in 0in 0in 0in'>
   <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
    <td width=1170 style='width:877.5pt;background:white;padding:0in 0in 0in 0in'>
    <p class=MsoNormal align=center style='text-align:center'><span lang=EN-GB
    style='font-size:12.0pt;font-family:\"Arial\",sans-serif;color:black;
    mso-ansi-language:EN-GB;mso-fareast-language:ZH-TW'>&nbsp;</span></p>
    </td>
   </tr>
   <tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes;height:.9in'>
    <td width=1170 valign=top style='width:877.5pt;background:white;padding:
    0in 0in 0in 0in;height:.9in'>
    <p class=MsoNormal><b><span lang=EN-GB style='font-size:20.0pt;font-family:
    \"Arial\",sans-serif;color:black;mso-ansi-language:EN-GB;mso-fareast-language:
    ZH-TW'>&nbsp;</span></b><b><span lang=EN-GB style='font-size:16.0pt;
    font-family:\"Arial\",sans-serif;color:#404040;mso-ansi-language:EN-GB;
    mso-fareast-language:ZH-TW'>$alert_msg</span></b><b><span
    lang=EN-GB style='font-size:20.0pt;font-family:\"Arial\",sans-serif;
    color:black;mso-ansi-language:EN-GB;mso-fareast-language:ZH-TW'><o:p></o:p></span></b></p>
     <p class=MsoNormal><span lang=EN-GB style='font-size:14.0pt;font-family:
     \"Arial\",sans-serif;color:#000000;mso-ansi-language:EN-GB;mso-fareast-language:
     ZH-TW'>$mail_body<o:p></o:p></span></p> 
    </td>
   </tr>
  </table>
  </td>
</tr>

<tr style='mso-yfti-irow:3'>
  <td width=2112 colspan=4 valign=top style='width:22.0in;background:#F2F2F2;
  padding:5.65pt 5.65pt 5.65pt 5.65pt'><a name=\"_H1_Heading\"></a>
  <p class=MsoNormal><o:p>&nbsp;</o:p></p>
  </td>
</tr>
<tr style='mso-yfti-irow:4'>
  <td width=2112 colspan=4 style='width:22.0in;background:#F2F2F2;padding:5.65pt 5.65pt 5.65pt 5.65pt'>
  <p class=MsoNormal align=center style='text-align:center'><o:p>&nbsp;</o:p></p>
  </td>
</tr>
<tr style='mso-yfti-irow:5;mso-yfti-lastrow:yes'>
  <td width=1177 style='width:882.7pt;padding:0in 0in 0in 0in'>
  <p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Times New Roman\",serif'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=260 style='width:194.8pt;padding:0in 0in 0in 0in'>
  <p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Times New Roman\",serif'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=666 style='width:499.85pt;padding:0in 0in 0in 0in'>
  <p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Times New Roman\",serif'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=9 style='width:6.65pt;padding:0in 0in 0in 0in'>
  <p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Times New Roman\",serif'><o:p>&nbsp;</o:p></span></p>
  </td>
</tr>
</table>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

<p class=MsoNormal><o:p>&nbsp;</o:p></p>

</div>

</body>

</html>"""
  msg
}

  //Surrogate key Generation 
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import java.util.HashMap

def surrogateKeyCreation(naturalKey: String,surrKey: String,latestEntryKey: String,ref_df: DataFrame,spark: SparkSession): DataFrame = {
    //import spark.implicits._

    var keyCols = List[String]()
    
    //var sourceSystem ="SFDC"
    //val nk = "activity_id#case_tbl" //get it from parameter file
   // val naturalKey = "activity_id#case_tbl" //get it from parameter file
    //var multiplesurrogateKeyIndicator="N" //get it from parameter file,change it to Y for multiple surrogatekey check
    val surrKeyList = surrKey.split(",").toList
    val naturalKeyList = naturalKey.split("#").toList //propertiesObject.getNaturalKeys().split("#").toList
    val surrogatekeyMap: HashMap[String, String] = new HashMap[String, String]();
    for (i <- 0 to surrKeyList.length - 1) {
      surrogatekeyMap.put(surrKeyList(i), naturalKeyList(i))
    }
            
    /*def sourceSystemCheck(sourceSystem:String,natural_ky:String):String = {
      var a= " "
    if (sourceSystem.trim().length() !=0){
      a="crc32(lower(trim("+natural_ky+")))"
    }
      return a
  } 
   def sourceSystemCheck1(sourceSystem:String,isConcat:Boolean):String = {
     var a=" "
    if (sourceSystem.trim().length() !=0){
      if (isConcat)  a="crc32(lower(TRIM(COALESCE(concat("
      else a="crc32(lower(TRIM(COALESCE("
    }
    return a
  }  */
   
   //This check is for multiple surrogate keys as there will be corresponding natural keys
        if (naturalKey.contains("#")) {
          val tempkeyCols = naturalKey.trim.split("#", -1)
          tempkeyCols.foreach {
            a =>
              if (a.contains(",")) {
                val tempList = a.split(",").toList
                keyCols = keyCols ::: tempList
              }

              keyCols = a :: keyCols

          }
        } else {

          keyCols = naturalKey.trim.split(",", -1).toList
          log.info("Key Cols!!!!!!!!"+keyCols)
        }

        var sql = ""

        var Nullkeyfilter = ""
        //var finalrefLatestDf = spark.emptyDataFrame
        // condition to check if source 
        //For single surrogate key naturalKey will not have # 
       if (!naturalKey.contains("#")) {

        log.info("-------------->>>>>>>>Single Surrogate Key<<<<<<<<<<<<<<----------------" + surrKey)

          keyCols.foreach { a =>
            sql = sql + "COALESCE(" + a + ",\"\")" + ","
          }
          //creating a string which will be like concat_ws('#',coalesce(colName1,""),coalesce(colName2,""),)
          var natural_ky = "concat(" + sql.dropRight(1) + ")"
          sql = "concat_ws('#'," + sql.dropRight(1) + ")"
          

          log.info("################## Filter Criteria ##################"+sql.toString() );
          
          Nullkeyfilter = Nullkeyfilter.dropRight(4)

         // logger.info("################## Null Key Filter for Single Surrogate Key ##################" + Nullkeyfilter)

          ref_df.createOrReplaceTempView("ref_tbl_without_surr_ky")

          val naturalKeyList = naturalKey.split(',').toList

          //Filtering Out records which have null values for concatenated natural keys i.e records which have all natiural keys as null
          val refLatestDfWithNaturalKey =
            if (naturalKeyList.length > 1) {
              var str = ""
              for (s <- 1 to naturalKeyList.length - 1) {
                str = str + "#"
              }
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_surr_ky").filter(col("natural_ky") =!= "str")
            } else {
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_surr_ky").filter(col("natural_ky") =!= "")
            }

         log.info("################## Count Without NULL ##################" + refLatestDfWithNaturalKey.count())

          refLatestDfWithNaturalKey.drop("natural_ky").createOrReplaceTempView("natural_ky_tbl")

          //Creating Surrogate Key
        //  val crc32StringSingle = sourceSystemCheck(sourceSystem, natural_ky)
          val crc32StringSingle ="crc32(lower(trim("+natural_ky+")))"
          val surrogateKeyDf = spark.sql(f"""select ${crc32StringSingle} as ${surrKey},*,row_number() over ( partition by $naturalKey order by $latestEntryKey desc) as row_num from natural_ky_tbl""").drop("natural_ky")
         log.info(s"select ${crc32StringSingle} as ${surrKey},*,row_number() over ( partition by $naturalKey order by $latestEntryKey desc) as row_num from natural_ky_tbl")
         return surrogateKeyDf
       }
       else
       {
          var multiplesurrKey = ""
          if (naturalKey.contains("#")) {
            log.info("################## Multiple Surrogate Key Multiple Natural Key Logic ##################")
            
           // logger.info("#############Natural Key Column List##############"+keyCols.toString())
            
           val naturalKeypart =naturalKey.split('#')(0)
            
            ref_df.createOrReplaceTempView("ref_tbl_without_ntrl_ky")
           
            keyCols.foreach(a =>
            sql = sql + "COALESCE(" + a + ",\"\")" + ",")
            
            sql = "concat_ws('#'," + sql.dropRight(1) + ")" 
           
            println("sql"+sql)
            //logger.info("################## Filter Criteria ##################"+sql.toString() );
           
            val refLatestDfWithNaturalKey =
            if (keyCols.length > 1) {
              var str = ""
              for (s <- 1 to keyCols.length - 1) {
                str = str + "#"
              }
              spark.sql(f"select *,${sql} as natural_ky,row_number() over ( partition by $naturalKeypart order by $latestEntryKey desc) from ref_tbl_without_ntrl_ky")
                .filter(col("natural_ky") =!= "str")
            } else {
              spark.sql(f"select *,${sql} as natural_ky,row_number() over ( partition by $naturalKeypart order by $latestEntryKey desc) from ref_tbl_without_ntrl_ky")
               .filter(col("natural_ky") =!= "")
            }
                 
             refLatestDfWithNaturalKey.drop("natural_ky").createOrReplaceTempView("ref_tbl_without_surr_ky")

            val tempsurrkey = surrKey.split(",", -1).toList
           
            tempsurrkey.foreach {
              a =>
                var tempNk = surrogatekeyMap.get(a)
                //val crc32StringMultiple = sourceSystemCheck(sourceSystem)
                if (tempNk.contains(",")) {
                  val temp1 = tempNk.split(",").toList
                  val temp = temp1.foldLeft("")(_ + "coalesce(cast(" + _ + " as string),\"\"),")
                  
                  println("################## tempsurrkey ##################" + temp.dropRight(1))
                 // val crc32StringMultiple = sourceSystemCheck1(sourceSystem,true)
                  val crc32StringMultiple = "crc32(lower(TRIM(COALESCE(concat("
                  multiplesurrKey = multiplesurrKey + crc32StringMultiple + temp.dropRight(1) + ")))))" + " as " + a + ","
                  
                } else {
                  //val crc32StringMultiple = sourceSystemCheck1(sourceSystem,false)
                  val crc32StringMultiple ="crc32(lower(TRIM(COALESCE("
                  multiplesurrKey = multiplesurrKey + crc32StringMultiple+ "cast(" + tempNk + " as string),\"\"))))" + " as " + a + ","
                }
                
                
            }
             
            multiplesurrKey = multiplesurrKey.dropRight(1)
            println("################## Multiple Surrogate Key Multiple Natural Key ##################" + multiplesurrKey)

          } else {
            //val crc32StringMultiple = sourceSystemCheck1(sourceSystem,false)
            val crc32StringMultiple = "crc32(lower(TRIM(COALESCE("
            surrKey.foreach { a =>
              multiplesurrKey = multiplesurrKey + crc32StringMultiple + surrogatekeyMap.get(a) + ",\"\"))))" + " as " + a + ","
            }
            multiplesurrKey = multiplesurrKey.dropRight(1)
          }

         // logger.info("################## Multiple Surrogate Key ##################" + multiplesurrKey)

          val surrogateKeyDf = spark.sql(f"select *,${multiplesurrKey}  from ref_tbl_without_surr_ky")
          return surrogateKeyDf
       }
   }

def getResult(resultSet: ResultSet, list: List[String] = Nil): List[String] = {
    if (resultSet.next()) {
      val value = resultSet.getString("btch_id").trim()
      getResult(resultSet, value :: list)
    } else {
      list
    }
  }

  def readRefBatchIdListNew(sqlcon: Connection, objName: String, auditTbl: String): List[String] = {

    var btch_id_list: List[String] = Nil

    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select btch_id from " + auditTbl + " where obj_nm='" + objName + "' and dta_lyr_nm='rw_ref' and lower(jb_stts_cd) ='success' and reverse(substring(reverse(COALESCE(btch_id,'')),1,instr(reverse(COALESCE(btch_id,'')),'_')-1)) > (select coalesce(max(reverse(substring(reverse(COALESCE(btch_id,'')),1,instr(reverse(COALESCE(btch_id,'')),'_')-1))),19000101000000) from " + auditTbl + " where obj_nm='" + objName + "' and dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd) ='success')"
      //val auditSQL = "select sum(tgt_rec_qty) sum from jb_aud_tbl where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and obj_nm='" + objName + "' group by dta_lyr_nm"

      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      btch_id_list = getResult(rs)
      //Extact result from ResultSet rs
      /* while (rs.next()) {
        log.info("max(tgt_rec_qty)=" + rs.getArray("btch_id_list"))
        btch_id_list = btch_id_list :: rs.getArray("btch_id_list")
      }*/
      // close ResultSet rs
      rs.close()

    } catch {
      case e: Exception => e.printStackTrace()

    }
    btch_id_list
  }
  
 def getSKeyPropertiesobject(str: String): SKeyObject =
  {
    val propfileSystem: FileSystem = FileSystem.newInstance(new Configuration)
    val propFileInputStream = propfileSystem.open(new Path(str))
    try {
      var properties: Properties = new Properties();
      properties.load(propFileInputStream);
      var pObj: SKeyObject = null
      log.info("++++++++++++++++++++++++++" + str)

      log.info("########################################Utilities::::::::::::::" + str.toString())
      if (str != null) {
        pObj = new SKeyObject(
          properties.getProperty("sKey")
        )
      }
      return pObj
    } catch {
      case ex: FileNotFoundException =>
      {log.error("Please place the \"sKey\" file in "+str+" path"  )
        sys.exit(1)}
      case ex: IOException           => {sys.exit(1)}

    }
    finally{
      if(propFileInputStream!=null){
        propFileInputStream.close()
      }
      if(propfileSystem!=null){
        propfileSystem.close()
      }
      
    }
  }
 def splitstring(pos: List[Int], str: String): String  = 
        {
          var strr=str
          var value=""
          var k=0
          var b = new ListBuffer[String]()
    try{ 
         for (i <- 0 until pos.length) {
    
              value=strr.substring(k, pos(i))
              
              strr = strr.slice(pos(i), str.length)
              b += value
              
             //log.info("prininting the splistirng"+b)
           }
     }  catch {
      case e: Exception => e.printStackTrace()
    }
    return b.toList.mkString("@~@")
     }
        
def pademptyvalues(array_value:Array[String],exceptedlength:Int):Array[String]={

		try{ for (i<-0 to array_value.length-1){
			val actuallength=array_value(i).length
					if(exceptedlength>actuallength)
					{

						val lgth=exceptedlength-actuallength
								val final_lgth=lgth+array_value(i).length()

								array_value(i)=array_value(i).padTo(final_lgth, ' ') 

					}
	 }
		}catch {
		case e: Exception => e.printStackTrace()
		}
		return array_value
}
        
  def readAuditTble(sqlcon: Connection, sql:String, spark:SparkSession, envPropertiesObject: EnvPropertiesObject): DataFrame = {
    
    val host = envPropertiesObject.getMySqlHostName()
    val port = envPropertiesObject.getMySqlPort()
    val username = envPropertiesObject.getMySqlUserName()
    val password = envPropertiesObject.getMySqlPassword()
    val dbName = envPropertiesObject.getMySqlDBName()
   
      //Class.forName("com.mysql.jdbc.Driver");
      //var con: Connection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + dbName, username, password);
    
    log.info(" Extract SQL::::"+sql)
    var jdbcDF: DataFrame = null
    try {
      
      jdbcDF = spark.read
        .format("jdbc")
        .option("url", "jdbc:mysql://" + host + ":" + port + "/" + dbName)
        .option("dbtable", s"( $sql ) t")
        .option("user", username)
        .option("password", password)
        .option("driver", "com.mysql.jdbc.Driver")
        .load()
      log.info("Reading from Audit table")

     
    } catch {
      case e: Exception => e.printStackTrace()

    }
    jdbcDF
  }
    def getAllFiles(path:String, sc: SparkContext): Seq[String] = {
    val conf = sc.hadoopConfiguration
    val fs = FileSystem.get(conf)
    val files = fs.listStatus(new Path(path)).filter(_.isFile())
    files.map(_.getPath().toString)
  }
    def getValue(colName:String, row: Dataset[Row]): String = {
    var colValue = row.select(colName).collectAsList().toString().split(",")(0)
    colValue = colValue.replace("[", "").replace("]", "")
    log.info(colName+": "+colValue)
    colValue
  }
    /*Read control table info from mysql*/
  def getControlTableInfo(sqlcon:Connection, objName:String):SQLConfigObjectProperties ={
    var configObjectProperties: SQLConfigObjectProperties = new SQLConfigObjectProperties("", "", "", "", "", "")
    try {
      log.info("Reading from Audit table")
      val sqlQuery="select src_tbl_nm, cnfg_obj_nm, tgt_tbl_nm, ld_jb_nr, src_sys_ky, cnfg_fl_nm from cnfg_obj_prpt_tbl where upper(cnfg_fl_nm) = '"+objName+"' or tgt_tbl_nm = ''"
      val stmt:Statement=sqlcon.createStatement()
      log.info("===================Print SQL :: "+sqlQuery)
      
      val rs:ResultSet=stmt.executeQuery(sqlQuery)
      //Extact result from ResultSet rs
      while(rs.next()){
        log.info("src_tbl_nm="+rs.getString("src_tbl_nm"))
        log.info("cnfg_obj_nm="+rs.getString("cnfg_obj_nm"))
        log.info("tgt_tbl_nm="+rs.getString("tgt_tbl_nm"))
        log.info("ld_jb_nr="+rs.getString("ld_jb_nr"))
        log.info("src_sys_ky="+rs.getString("src_sys_ky"))
        log.info("cnfg_fl_nm="+rs.getString("cnfg_fl_nm"))
        
        configObjectProperties = new SQLConfigObjectProperties(rs.getString("src_tbl_nm"), rs.getString("cnfg_obj_nm"), rs.getString("tgt_tbl_nm"),
            rs.getString("ld_jb_nr"), rs.getString("src_sys_ky"), rs.getString("cnfg_fl_nm"))
      }
      // close ResultSet rs
      rs.close();
    } catch {
      case e: Exception =>e.printStackTrace()
    } finally { 
       sqlcon.close() 
    }
    configObjectProperties
  }
  def storeErrDataFrame(transformedDF: DataFrame, saveMode: String, compressionType: String, storageFormat: String, targetTable: String): Boolean = {
    var loadStatus = true
    try {
      val tblCount = transformedDF.count
      log.info("Writing to HIVE TABLE : " + targetTable)// + " :: DataFrame Count :" + tblCount)
      if (transformedDF != null && tblCount>0 && saveMode.trim().length() != 0 && storageFormat.trim().length() != 0 && targetTable.trim().length() != 0) {
        log.info("SAVE MODE::" + saveMode + " Table Name :: " + targetTable + " Format :: " + storageFormat)
        transformedDF.coalesce(2).write.mode(saveMode).option("compression", compressionType).format(storageFormat.trim()).insertInto(targetTable.trim())
      } 

    } catch {
      case e: AnalysisException => e.printStackTrace();
        log.error("ERROR Writing to HIVE TABLE : " + targetTable);
        loadStatus = false;
    }
    return loadStatus
  }
def updateConfigObjPropTableLoadStatus(sqlcon: Connection, configTable: String, configObjectProperties: SQLConfigObjectProperties, loadStatus: String) = {
    try {
      val updateSQL = "update amc."+configTable+" set ld_status='to be processed' where cnfg_fl_nm='"+configObjectProperties.getCnfg_fl_nm()+"' and cnfg_obj_nm='"+configObjectProperties.getCnfg_obj_nm()+"' and ld_jb_nr='"+configObjectProperties.getLd_jb_nr()+"' and src_sys_ky='"+configObjectProperties.getSrc_sys_ky()+"' and src_tbl_nm='"+configObjectProperties.getSrc_tbl_nm()+"' and src_data_layer='stg'" 
      //val updateSQL = "update "+configTable+" set ld_status='to be processed' where cnfg_obj_nm='"+configObjectProperties.getCnfg_obj_nm()
      log.info("===================Print SQL :: " + updateSQL)
      val preparedStmt = sqlcon.prepareStatement(updateSQL);
      preparedStmt.execute();

      log.info("INSERTED INTO AUDIT LOG")
    } catch {
      case e: Exception => {
        log.error("exception is:- "+e.printStackTrace())
      }
    } finally {
      sqlcon.close()
    }

  }
 //Read distinct object names from the MYsql table where status ="to be processed"      
    
 def readObjectList(sqlcon: Connection): List[String] = {
    var object_list:List[String] = Nil 
    try {
      log.info("Reading from Audit table")
      val stmt: Statement = sqlcon.createStatement()
      val query = "select distinct cnfg_obj_nm from amc.cnfg_obj_prpt_tbl where ld_status='to be processed'"
      log.info("===================Print SQL :: " + query)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(query)
      object_list = getObjNm(rs)
      print(object_list)    //remove
      rs.close()
    } catch {
      case e: Exception => e.printStackTrace()
    }
    object_list
  }
 def ConfSQLReadRw(sqlcon: Connection,x:String): ArrayList[String]  = {
    var Rw: ArrayList[String] = new ArrayList[String]
    try {
      log.info("Reading from Audit table")
      val stmt: Statement = sqlcon.createStatement()
      val query = "select distinct src_tbl_nm,cast(src_sys_ky as char(10)) as src_sys_ky,cnfg_fl_nm,tgt_tbl_nm,ld_qery,join_query from amc.cnfg_obj_prpt_tbl where cnfg_obj_nm='"+x+"' and ld_ord=1 limit 1"
      log.info("===================Print ConfSQLReadRw SQL :: " + query)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(query)
      Rw = getconfigSQL(rs)
      rs.close()
    } catch {
      case e: Exception => e.printStackTrace()
    }
    Rw
  }

def ConfSQLReadRef(sqlcon: Connection,x:String): ArrayList[String]  = {
    var Ref: ArrayList[String] = new ArrayList[String]
    try {
      log.info("Reading from Audit table")
      val stmt: Statement = sqlcon.createStatement()
      val query = "select distinct src_tbl_nm,cast(src_sys_ky as char(10)) as src_sys_ky,cnfg_fl_nm,tgt_tbl_nm,ld_qery,join_query from amc.cnfg_obj_prpt_tbl where cnfg_obj_nm='"+x+"' and ld_ord=2 limit 1"
      log.info("===================Print ConfSQLReadRef SQL :: " + query)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(query)
      Ref = getconfigSQL(rs)
      rs.close()
    } catch {
      case e: Exception => e.printStackTrace()
    }
    Ref
  }
  def ConfSQLRead(sqlcon: Connection, x: String): List[ArrayList[String]] = {
    var Rw: List[ArrayList[String]] = Nil
    try {
      log.info("Reading from Audit table")
      val stmt: Statement = sqlcon.createStatement()
      val query = "select distinct src_tbl_nm,cast(src_sys_ky as char(10)) as src_sys_ky,cnfg_fl_nm,tgt_tbl_nm,ld_qery,join_query,ld_ord from amc.cnfg_obj_prpt_tbl where cnfg_obj_nm='" + x + "' order by ld_ord desc"
      log.info("===================Print ConfSQLRead SQL :: " + query)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(query)
      //var list: ArrayList[String] = new ArrayList[String]()
      while (rs.next()) {
        var list: ArrayList[String] = new ArrayList[String]()
        val v1 = rs.getString("src_tbl_nm")
        val v2 = rs.getString("src_sys_ky")
        val v3 = rs.getString("cnfg_fl_nm")
        val v4 = rs.getString("tgt_tbl_nm")
        val v5 = rs.getString("ld_qery")
        val v6 = rs.getString("join_query")
        val v7 = rs.getString("ld_ord")
        list.add(v1)
        list.add(v2)
        list.add(v3)
        list.add(v4)
        list.add(v5)
        list.add(v6)
        list.add(v7)
        Rw = list :: Rw
      }
      rs.close()
    } catch {
      case e: Exception => e.printStackTrace()
    }
    Rw
  }
   
def AudSQLRead(sqlcon: Connection,x:String): List[String] = {
    var sys_btch_nr:List[String] = Nil 
    try {
      log.info("Reading from Audit table")
      val stmt: Statement = sqlcon.createStatement()
      val query = "select distinct ld_jb_nr from amc.cnfg_obj_prpt_tbl where cnfg_obj_nm='"+x+"' limit 1"
      log.info("===================Print AudSQLRead SQL :: " + query)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(query)
      sys_btch_nr = getBatchNr(rs)
      rs.close()
    } catch {
      case e: Exception => e.printStackTrace()
    }
    sys_btch_nr
  }
def getBatchNr(resultSet: ResultSet, list: List[String] = Nil): List[String] = {
  if (resultSet.next()) {
    val value = resultSet.getString("ld_jb_nr")
    getBatchNr(resultSet, value :: list)
  }
  else {
    list
  }
}
def getObjNm(resultSet: ResultSet, list: List[String] = Nil): List[String] = {
  if (resultSet.next()) {
    val value = resultSet.getString("cnfg_obj_nm")
    getObjNm(resultSet, value :: list)
  }
  else {
    list
  }
}
def getconfigSQL(resultSet: ResultSet, list: ArrayList[String] = new ArrayList[String]): ArrayList[String] = {
  if (resultSet.next()) {
    val v1 = resultSet.getString("src_tbl_nm")
    val v2 = resultSet.getString("src_sys_ky")
    val v3 = resultSet.getString("cnfg_fl_nm")
    val v4 = resultSet.getString("tgt_tbl_nm")
    val v5 = resultSet.getString("ld_qery")
    val v6 = resultSet.getString("join_query")
    list.add(v1)
    list.add(v2)
    list.add(v3)
    list.add(v4)
    list.add(v5)
    list.add(v6)  
    list
  }
  else {
    list
  }
}   
def insertIntoConfigAudit(sqlcon: Connection, ConfigaudQry: String) = {
    try {
      log.info("WRITING INTO JOB AUDIT LOG -- ")
      val auditSQL = ConfigaudQry
      log.info("===================Print Config SQL :: " + auditSQL)
      val preparedStmt = sqlcon.prepareStatement(auditSQL);
      preparedStmt.execute();
      log.info("INSERTED INTO JOB AUDIT LOG")
    } catch {
      case e: Exception => e.printStackTrace()
    }
  }

}

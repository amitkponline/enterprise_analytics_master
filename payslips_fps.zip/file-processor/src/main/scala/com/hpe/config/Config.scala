package com.hpe.config

import scala.beans.BeanProperty
import org.apache.spark.sql.DataFrame
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.hive.HiveContext
import scala.collection.Map
import org.datanucleus.store.types.backed.HashMap
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.sql.SparkSession

class ConfigObjectNonStreaming(
  @BeanProperty var sparkConf:SparkConf,
  @BeanProperty var spark:SparkSession) extends Serializable
  
class ConfigObject(
  @BeanProperty var sparkConf:SparkConf,
  @BeanProperty var spark:SparkSession,
  @BeanProperty var ssc:StreamingContext) extends Serializable  
  
class EnvPropertiesObject(
  @BeanProperty var brokersList:String,
  @BeanProperty var trustStoreLoc:String,
  @BeanProperty var trustPwd:String,
  @BeanProperty var keyStoreLocation: String,
  @BeanProperty var keyStorePwd: String,
  @BeanProperty var keyPwd : String,
  @BeanProperty var mySqlHostName: String,
  @BeanProperty var mySqlDBName: String,
  @BeanProperty var mySqlUserName: String,
  @BeanProperty var mySqlPassword: String,
  @BeanProperty var mySqlPort: String,
  @BeanProperty var mySqlAuditTbl: String) extends Serializable
  
class PropertiesObject(
  @BeanProperty var objName:String,
  @BeanProperty var dbName: String,
  @BeanProperty var colNm: String,
  @BeanProperty var msgdelimeter: String,
  @BeanProperty var NulchkCol: String,
  @BeanProperty var lnchkVal: String,
  @BeanProperty var DtfmtchkCol: String,
  @BeanProperty var intchkCol: String,
  @BeanProperty var doublechkCol: String,
  @BeanProperty var booleanchkCol: String,
  @BeanProperty var rcdDelimiter: String,
  @BeanProperty var colListSep:String,
  @BeanProperty var filterExpression:String,
  @BeanProperty var tgtTblRw:String,
  @BeanProperty var tgtTblErr:String,
  @BeanProperty var tgtTblRef:String,
  @BeanProperty var tgtTblEnr:String,
  @BeanProperty var sqlPropertyPath:String,
  @BeanProperty var masterDataFields:String,
  @BeanProperty var hiveJsonRawMap:String,
  @BeanProperty var dateCastFields:String,
  @BeanProperty var longchkCol:String,
  @BeanProperty var sourceFilePath:String,
  @BeanProperty var tgtTblStg:String,
  @BeanProperty var customBooleanFields:String,
  @BeanProperty var regexQuery:String,
  @BeanProperty var rwTblSaveMode:String,
  @BeanProperty var refTblSaveMode:String,
  @BeanProperty var multilineOption:String,
  @BeanProperty var currencyCastFields : String,
  @BeanProperty var quotes:String,
  @BeanProperty var ArchiveDir:String,
  @BeanProperty var lrTrimFields:String, 
  @BeanProperty var errorDir:String,
  @BeanProperty var hederMatchReqd:String,
  @BeanProperty var primaryKeyColList:String,
  @BeanProperty var srcReferenceKeyColList:String,
  @BeanProperty var tgtReferenceKeyColList:String,
  @BeanProperty var naturalKeys:String,
  @BeanProperty var surrKey:String,
  @BeanProperty var latestEntryKey:String,
  @BeanProperty var tgtTblConsmtn:String,
  @BeanProperty var cnsmpTblSaveMode:String,
  @BeanProperty var sourceSystem:String,
  @BeanProperty var fileToObjNmMap:String,
  @BeanProperty var sendMailTo:String,
  @BeanProperty var sendMailFrom:String,
  @BeanProperty var sendMailSMTPHost:String,
  @BeanProperty var sendMailSMTPPort:String,
  @BeanProperty var sendMailUsername:String,
  @BeanProperty var sendMailPassword:String,
  @BeanProperty var srcFilePattern:String,
  @BeanProperty var isPositional:String,
  @BeanProperty var headerLength:String,
  @BeanProperty var dataLength:String,
  @BeanProperty var trailerLength:String,
  @BeanProperty var repartitionNo:String,
  @BeanProperty var strtIndx:String,
  @BeanProperty var endIndx:String,
  @BeanProperty var apiName:String,
  @BeanProperty var deleteflag:String,
  @BeanProperty var deletejoinCol:String,
  @BeanProperty var deleteTableName:String,
  @BeanProperty var preConsmtnTbl:String,
  @BeanProperty var groupByKeys:String,
  @BeanProperty var retainRecords:String,
  @BeanProperty var hardDeleteCol:String,
  @BeanProperty var multipleSurrKeyInd:String,
  @BeanProperty var filterKey:String,
  @BeanProperty var lateralView:String,
  @BeanProperty var pkNullChkReqd:String,
  @BeanProperty var commonErrTblNm:String
) extends Serializable

class SQLPropertiesObject(
  @BeanProperty var mySqlHostName: String,
  @BeanProperty var mySqlDBName: String,
  @BeanProperty var mySqlUserName: String,
  @BeanProperty var mySqlPassword: String,
  @BeanProperty var mySqlPort: String,
  @BeanProperty var mySqlAuditTbl: String) extends Serializable
class SKeyObject(
  @BeanProperty var sKey:String) extends Serializable
class AuditLoadObject(
  @BeanProperty var audBatchId :String,
  @BeanProperty var audApplicationName :String,
  @BeanProperty var audObjectName :String,
  @BeanProperty var audDataLayerName :String,
  @BeanProperty var audJobStatusCode :String,  
 // @BeanProperty var audJobstartTimestamp:String,
  @BeanProperty var audJobEndTimestamp:String,
  @BeanProperty var audLoadTimeStamp:String,
  @BeanProperty var audSrcRowCount:Long,
  @BeanProperty var audTgtRowCount:Long,
  @BeanProperty var audErrorRecords:Long,
  @BeanProperty var audCreatedBy:String,
  @BeanProperty var audJobStartTimeStamp:String,
  @BeanProperty var audJobDuration:String,
  @BeanProperty var flNm:String,
  @BeanProperty var sysBtchNr:String) extends Serializable{
}

class KafkaPropetiesObject(
  @BeanProperty var propertiesObject: PropertiesObject,
  @BeanProperty var consumergroup : String,
  @BeanProperty var OffsetResetVal : String) extends Serializable
  
class StreamingPropertiesObject(
                                 @BeanProperty var objName: String,
                                 @BeanProperty var autoCommit: String,
                                 @BeanProperty var dbName: String,
                                 @BeanProperty var ctrl_doc_num: String,
                                 @BeanProperty var topicList: String,
                                 @BeanProperty var tableNameMapping: String,
                                 //    @BeanProperty var jsonHiveMapTbl: String,
                                 //    @BeanProperty var tgt_data_tbl: String,
                                 @BeanProperty var tgt_ctrl_tbl: String,
                                 //    @BeanProperty var colNm: String,
                                 //    @BeanProperty var msgdelimeter: String,
                                 @BeanProperty var NulchkCol: String,
                                 @BeanProperty var lnchkVal: String,
                                 @BeanProperty var DtfmtchkCol: String,
                                 @BeanProperty var intchkCol: String,
                                 @BeanProperty var doublechkCol: String,
                                 @BeanProperty var booleanchkCol: String,
                                 @BeanProperty var longchkCol: String,
                                 @BeanProperty var rcdDelimiter: String,
                                 //    @BeanProperty var maxRunTime: String,
                                 @BeanProperty var colListSep: String,
                                 @BeanProperty var filterExpression: String,
                                 @BeanProperty var tgtTblRw: String,
                                 @BeanProperty var tgtTblErr: String,
                                 @BeanProperty var tgtTblRef: String,
                                 @BeanProperty var tgtTblConsmtn: String,
                                 @BeanProperty var unqKeyCols: String,
                                 @BeanProperty var masterDataFields: String,
                                 @BeanProperty var hiveJsonRawMap: String,
                                 @BeanProperty var hiveJsonCtrlMap: String,
                                 @BeanProperty var lookUpTable: String,
                                 @BeanProperty var customSQL: String,
                                 @BeanProperty var dateCastFields: String,
                                 @BeanProperty var consumerGroupVal : String,
                                 @BeanProperty var currencyCastFields : String,
                                 @BeanProperty var maxRatePerPartition : String,
                                 @BeanProperty var cntrlDateCastFields : String,
                                 @BeanProperty var sourceFilePath:String,
                                 @BeanProperty var errorDir:String,
                                 @BeanProperty var numPartitions:String) extends Serializable
                                 
class SharedConfigObjectProperties(
  @BeanProperty var configFileSourceDir: String,
  @BeanProperty var configFileArchiveDir: String,
  @BeanProperty var configFileExt : String,
  @BeanProperty var configFileDelimiter : String,
  @BeanProperty var configObjectNameList : String,
  @BeanProperty var schemaName : String,
  @BeanProperty var configBaseDir: String,
  @BeanProperty var errorStgTable: String,
  @BeanProperty var errorTable: String,
  @BeanProperty var configErrorDir: String,
  @BeanProperty var dataLayerSrcToStg: String,
  @BeanProperty var auditStatusSuccess: String,
  @BeanProperty var auditStatusFailed: String,
  @BeanProperty var configObjPropTable: String,
  @BeanProperty var masterDataFile: String) extends Serializable
class SQLConfigObjectProperties(
  @BeanProperty var src_tbl_nm: String,
  @BeanProperty var cnfg_obj_nm: String,
  @BeanProperty var tgt_tbl_nm: String,
  @BeanProperty var ld_jb_nr: String,
  @BeanProperty var src_sys_ky: String,
  @BeanProperty var cnfg_fl_nm: String) extends Serializable
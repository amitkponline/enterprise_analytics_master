package com.hpe.config

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import kafka.serializer.StringDecoder
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.DataFrame
import com.hpe.utils.Utilities
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructType
import java.math.BigInteger
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.Subscribe
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.sql.catalyst.plans.logical.With
import org.apache.log4j.Logger

object SetUpConfigurationNonStreaming extends ConfigurationDetails {

  val logger = Logger.getLogger(getClass.getName)
  /**
   * Function to set the Spark Context objects
   *
   * @return Configuration Object
   */	
  def getSparkContext():ConfigObjectNonStreaming={
  		try{
  		      val sparkConf=new SparkConf().setMaster("yarn")
  		      SetUpConfigurationNonStreaming.setproperties(sparkConf)
						//val spark = SparkSession.builder().enableHiveSupport().config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").config("spark.sql.hive.convertMetastoreOrc", "false").config("spark.kryoserializer.buffer.max.mb", "512").config(sparkConf).getOrCreate()
  		      val spark = SparkSession.builder().enableHiveSupport().config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").config("spark.sql.hive.convertMetastoreOrc", "false").config(sparkConf).getOrCreate()
  		      val configObject=new ConfigObjectNonStreaming(sparkConf,spark)
  		     
      			return configObject
  		}
  		catch {
  		case textError: Throwable => textError.printStackTrace() 
  				logger.error("Could Not create the sparkConf,sparkContext,sqlContext,hiveContext")
  				logger.debug(textError)
  				sys.exit(1)
  		}
  	}


  /**
   * Function to set the Spark related properties
   *
   * @param configObject		: Configuration Object   
   */
	def setproperties(sparkConf: SparkConf)
	{
	    logger.info("Setting up the properties for SparkContext")
	    /*sparkConf.set("spark.executor.cores", SPARK_EXECUTOR_CORES)
	    sparkConf.set("spark.executor.memory", SPARK_EXECUTOR_MEMORY)*/
	    sparkConf.set("spark.network.timeout", SPARK_NETWORK_TIMOUT_TS)
	    sparkConf.set("spark.sql.broadcastTimeout", SPARK_SQL_BROADCAST_TIMEOUT)
	    sparkConf.set("spark.sql.tungsten.enabled", "true")
	    sparkConf.set("spark.eventLog.enabled", "true")
	    sparkConf.set("spark.io.compression.codec", "snappy")
	    sparkConf.set("spark.rdd.compress", "true")
	    sparkConf.set("spark.dynamicAllocation.enabled", "true")
	    sparkConf.set("spark.shuffle.service.enabled", "true")
	    /*spark.sqlContext.setConf("hive.exec.dynamic.partition", "true");
      spark.sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict");
      spark.sqlContext.setConf("spark.sql.hive.convertMetastoreOrc", "false");*/
      sparkConf.set("spark.streaming.kafka.maxRatePerPartition","100")
      //sparkConf.set("spark.streaming.concurrentJobs","6")
      sparkConf.set("spark.streaming.unpersist","true")
      sparkConf.set("spark.streaming.backpressure.enabled","true")
      /*sparkConf.set("spark.cores.max", "50")
      sparkConf.set("spark.executor.instances", "4")
      sparkConf.set("spark.executor.cores", "10")*/
      sparkConf.set("spark.serializer","org.apache.spark.serializer.KryoSerializer")
      sparkConf.set("spark.driver.extraJavaOptions", "-XX:+UseG1GC")
      sparkConf.set("spark.executor.extraJavaOptions", "-XX:+UseG1GC")
      sparkConf.set("spark.speculation", "false")
      sparkConf.set("spark.hadoop.mapreduce.map.speculative", "false")
      sparkConf.set("spark.hadoop.mapreduce.reduce.speculative", "false")
	}
	
	/**
	 * setup method invokes other methods for setup before job processing starts
	 * @return : Configuration Object
	 */
	def setup():ConfigObjectNonStreaming = {
	  val config=SetUpConfigurationNonStreaming.getSparkContext()
		return config	
	}

}
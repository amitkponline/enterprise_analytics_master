package com.hpe.config

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.Column
import org.apache.spark.sql.Column
import org.apache.spark.sql.Column
import org.apache.spark.sql.Column
import org.apache.spark.sql.Column
import java.text.SimpleDateFormat
import java.util.Date
import java.text.ParseException
import com.hpe.utils.Utilities

object Demo {
  val list:Seq[String]=Seq("a","b",null,"d")
  
 // val list:Seq[Column]=Seq(Column("a"),Column("b"),Column(null),Column("d"))

val t1=Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
val t2=Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")

//println(t2.toLong-t1.toLong)

val nn="new"
val str="apple ball"
println(str.replaceAll("ball", nn+" as ff"))


  def specialConcat(sep:String, colNames:Seq[String]): String=
  {
    var finalString=""
    colNames.foreach(x=>
     finalString=finalString+sep+x
     )
    println(finalString.replaceFirst(sep, ""))
    return null
  }
  
  
  def isThisDateValid(dateToValidate: String, dateFromat: String): Boolean = {
    if (dateToValidate == null) {
      false
    }
    val sdf: SimpleDateFormat = new SimpleDateFormat(dateFromat)
    sdf.setLenient(false)
    try {
      //if not valid, it will throw ParseException
      val date: Date = sdf.parse(dateToValidate)
      println(date)
    } catch {
      case e: ParseException => {
        e.printStackTrace()
        false
      }

    }
    true
  }
  
  def test()
  {
    val str="abc#!pqr#!mnp#!yot#!"
    println(str.substring(0,str.lastIndexOf("#!")))
    
  }
  def main (args:Array[String]){
    
    println(isThisDateValid("2018-03-02T16:57:14","yyyy-MM-dd'T'HH:mm:ss"))
    test()
    
  //specialConcat("#!",list)
  //val sparkConf = new SparkConf().setAppName("Spark-sql-demo")
    /*val sparkContext = new SparkContext(sparkConf)
    val sqlContext = new org.apache.spark.sql.SQLContext(sparkContext)
    val hiveContext = new org.apache.spark.sql.hive.HiveContext(sparkContext)
    val policyDF = hiveContext.sql("select policy_number from table  where  datediff(policy_end_date,accident_date)=3")
    policyDF.show*/
/*val a="a afrom from tt C"
val json="ffff"

println(a.replaceAll("from tt", "111"))

var col="1aaa2"
println(col.drop(1))
println(col.dropRight(1))
col=col.drop(1).dropRight(1)
println(col)*/
 val strtest= "#!\"Predefined\"#!\"100\"#!\"14994.31\"#!\"0\"#!\"#FF0000\"#!\"Below Floor\"#!\"8\"#!\"7\""
 
 println(strtest.replaceAll("\""+"#!", "#!").replaceAll("#!"+"\"", "#!").replaceAll("\""+"#!"+"\"", "#!").replaceAll("\\\\\"", "\""))
  }
}
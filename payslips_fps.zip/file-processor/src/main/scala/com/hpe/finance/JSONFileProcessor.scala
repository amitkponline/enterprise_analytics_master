package com.hpe.finance

import com.hpe.config.PropertiesObject
import java.sql.Connection
import com.hpe.config.ConfigObjectNonStreaming
import com.hpe.config.AuditLoadObject
import java.sql.Date
import com.hpe.utils.Utilities
import com.hpe.utils.DataQuality
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.Row
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.{ lower, upper, lit, col, concat_ws, split, struct, udf }
import org.apache.spark.sql.AnalysisException
import scala.collection.mutable.ArrayBuffer

object JSONFileProcessor {
  val log = Logger.getLogger(getClass.getName)
  def jsonFlattenPipeline(propertiesObject: PropertiesObject, configurationObject: ConfigObjectNonStreaming, sqlCon: Connection, auditTbl: String, batchId: String, propertiesFilePath: String): Boolean = {

    var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    try {

      val sparkSession = configurationObject.getSpark()
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      val date: Date = null;

      val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
      val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
      val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
      val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
      val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
      val auditBatchId = ld_jb_nr + "_" + batchId

      var errTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblErr()
      var rwTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw()

      auditObj.setAudBatchId(auditBatchId)
      auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudDataLayerName("File_Stg")
      auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(0)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configurationObject.getSpark().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)

      val schema = StructType(Array(StructField("pqb_data_SLS_QTN_ID_id", StringType, true), StructField("pqb_data_SLS_QTN_VRSN_SQN_NR_cd", StringType, true), StructField("PRICE_BAND_ADDTNL_INFO", StringType, true)))

      var df = sparkSession.read.format("csv").option("header", "true").option("delimiter", propertiesObject.getMsgdelimeter()).load(propertiesObject.getSourceFilePath())
      var src_count = df.count
      if (src_count > 0) {
        val fileHeaders: ArrayBuffer[String] = ArrayBuffer("SLS_QTN_ID", "SLS_QTN_VRSN_SQN_NR", "PRICE_BAND_ADDTNL_INFO")
        
        val isHeaderMatched = Utilities.validateHeader(ArrayBuffer(df.columns:_*), fileHeaders)

        log.info(":::::::::::::::::::Is header matched with target:::::::::::::::::::=" + isHeaderMatched)

        if (isHeaderMatched) {
          //val nonBlankDf = df.filter("PRICE_BAND_ADDTNL_INFO != ''")
          
          val nonBlankDf = (df.filter("PRICE_BAND_ADDTNL_INFO != ''")).filter("PRICE_BAND_ADDTNL_INFO != '{pqbBand:[],pricingType:null}'")
          
          var blankDf = sparkSession.createDataFrame(df.except(nonBlankDf).rdd,schema)

          blankDf = blankDf.withColumn("PRICE_BAND_ADDTNL_INFO", lit(null))

          val rdd = nonBlankDf.select("SLS_QTN_ID", "SLS_QTN_VRSN_SQN_NR", "PRICE_BAND_ADDTNL_INFO").rdd.map { row: Row => (row.getString(0) + "!#" + row.getString(1) + "!#" + row.getString(2).substring(if ((row.getString(2).head).equals('"')) 1 else 0, if ((row.getString(2).head).equals('"')) (row.getString(2).length() - 1) else row.getString(2).length())).replaceAll("pqbBand", "\"pqbBand\"").replaceAll("pricingType", "\"pricingType\"").replaceAll("currentBand", "\"currentBand\"").replaceAll("minprct", "\"minprct\"").replaceAll("maxValue", "\"maxValue\"").replaceAll("minValue", "\"minValue\"").replaceAll("colorCode", "\"colorCode\"").replaceAll("label", "\"label\"").replaceAll("id", "\"id\"").replaceAll("seq", "\"seq\"") }.map(line => line.split("!#", -1)).map(line => Row.fromSeq(line))

          var loadingDF = sparkSession.createDataFrame(rdd, schema)
          loadingDF = loadingDF.unionAll(blankDf)
          loadingDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
          loadingDF.write.mode("overwrite").format("ORC").insertInto(propertiesObject.getDbName() + "." + propertiesObject.getTgtTblStg())

          auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudDataLayerName("file_stg")
          var tgt_count = src_count
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(0)
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

          auditObj.setAudDataLayerName("stg_raw")

          log.info("@@@@@@@@@@@@@@@@@ Stage Loaded Successfully @@@@@@@@@@@@@@@@@@@@@@@@@@@")
          import sparkSession.implicits._
          //************************************************
          var sourceDF = loadingDF.select("pqb_data_SLS_QTN_ID_id", "pqb_data_SLS_QTN_VRSN_SQN_NR_cd", "PRICE_BAND_ADDTNL_INFO")
          log.info("########+++++++============>REGISTERING UDF===================#####")
          log.info("########+++++++============>propertiesObject.getColListSep()===================#####" + propertiesObject.getColListSep())
          val jsonToFlatUDF = udf(Utilities.jsonToString _)
          val putNullToFlatUDF = udf(Utilities.nullPutUDF _)
          val dqvalidate = udf(DataQuality.DQValidchck _)
          val generateSeqID = udf(Utilities.generateSeqID _)
          import org.apache.spark.sql.functions.regexp_replace

          //val newLineRemoveddf = sourceDF.withColumn("newLineReplaced", regexp_replace(loadingDF("PRICE_BAND_ADDTNL_INFO"),"\\n"," "))
          val json_hive_raw_map_rdd = sparkSession.sparkContext.parallelize(Seq(propertiesObject.getHiveJsonRawMap()))
          val jsonHeaderList: String = Utilities.getJsonHeaders(json_hive_raw_map_rdd, propertiesObject.getRcdDelimiter())
          val newDF = sourceDF.withColumn("jsonFlatCol", jsonToFlatUDF(regexp_replace(sourceDF("PRICE_BAND_ADDTNL_INFO"), "\\n", " "), lit(propertiesObject.getRcdDelimiter()), lit(jsonHeaderList)))
          newDF.createTempView("temp_table_hist")
          var final_df = sparkSession.sql("select pqb_data_SLS_QTN_ID_id, pqb_data_SLS_QTN_VRSN_SQN_NR_cd, explode(split(jsonFlatCol, '\\n')) as updatedCol, regexp_replace(split(jsonFlatCol,'\\n')[0],'[@:-]','_') as header from temp_table_hist")

          final_df.show(false)

          var rwJsonschema = StructType(propertiesObject.getColListSep().split(propertiesObject.getRcdDelimiter()).map(fieldName => StructField(fieldName, StringType, true)))

          var rwSchema = StructType(Array(StructField("pqb_data_SLS_QTN_ID_id", StringType, true), StructField("pqb_data_SLS_QTN_VRSN_SQN_NR_cd", StringType, true)))

          final_df = final_df.filter(!lower(final_df.col("updatedCol")).contains(propertiesObject.getFilterExpression().toLowerCase()))
          final_df.createOrReplaceTempView("testdf")
          final_df = sparkSession.sql("select * from testdf where length(trim(updatedCol))<>0")
          final_df.show(false)
          //final_df.select("updatedCol").show(false)
          final_df = final_df.withColumn("dataWithNull", putNullToFlatUDF(final_df("updatedCol"), lit(propertiesObject.getRcdDelimiter()), final_df("header"), lit(propertiesObject.getColListSep())))
          final_df = final_df.drop("header", "updatedCol")
          final_df.repartition(10)
          final_df.show(false)        	
          var rawSqlQuery = Utilities.final_hive_json_mapper(json_hive_raw_map_rdd)
          println("Raw SQL===================" + rawSqlQuery)
          rawSqlQuery = rawSqlQuery.replaceAll("FROM Temp_DF", ",null as intgtn_fbrc_msg_id,'' AS src_sys_upd_ts, '" + src_sys_ky + "' as src_sys_ky, '' AS lgcl_dlt_ind,  current_timestamp() AS ins_gmt_ts, '' AS upd_gmt_ts, '' AS src_sys_extrc_gmt_ts,'' AS src_sys_btch_nr, '" + fl_nm + "'  AS fl_nm, '" + auditBatchId + "' AS ld_jb_nr FROM Temp_DF")
          var rwRdd = final_df.select("dataWithNull", "pqb_data_SLS_QTN_ID_id", "pqb_data_SLS_QTN_VRSN_SQN_NR_cd").rdd.map { row: Row => (row.getString(0) + propertiesObject.getRcdDelimiter() + row.getString(1) + propertiesObject.getRcdDelimiter() + row.getString(2)).substring(if ((row.getString(2).head).equals('"')) 1 else 0, (row.getString(0) + propertiesObject.getRcdDelimiter() + row.getString(1) + propertiesObject.getRcdDelimiter() + row.getString(2)).length()).replaceAll("\"" + propertiesObject.getRcdDelimiter(), propertiesObject.getRcdDelimiter()).replaceAll(propertiesObject.getRcdDelimiter() + "\"", propertiesObject.getRcdDelimiter()).replaceAll("\"" + propertiesObject.getRcdDelimiter() + "\"", propertiesObject.getRcdDelimiter()).replaceAll("\\\\\"", "\"") }.map(line => line.split(propertiesObject.getRcdDelimiter(), -1)).map(line => Row.fromSeq(line))
          //println("+++++++++++++++++++++++++RDD++++++++++++++++++++++++++++++:"+rdd)
          //var rdd=final_df.select("dataWithNull","intgtn_fbrc_msg_id").rdd.map {row:Row => (row.getString(0)+ propertiesObject.getRcdDelimiter()+row.getString(1)).substring(if((row.getString(0).head).equals('"')) 1 else 0,(row.getString(0)+propertiesObject.getRcdDelimiter()+row.getString(1)).length()).replaceAll("\""+propertiesObject.getRcdDelimiter(), propertiesObject.getRcdDelimiter()).replaceAll(propertiesObject.getRcdDelimiter()+"\"", propertiesObject.getRcdDelimiter()).replaceAll("\""+propertiesObject.getRcdDelimiter()+"\"", propertiesObject.getRcdDelimiter()).replaceAll("\\\\\"", "\"").replaceAll("\\<.*?>", "")}.map(line=>line.split(propertiesObject.getRcdDelimiter(),-1)).map(line=>Row.fromSeq(line))
          // rdd.collect().foreach(println)
          rwSchema = StructType(rwJsonschema ++ rwSchema)
          println(rwSchema)
          var rwLoadingDF = sparkSession.createDataFrame(rwRdd, rwSchema)
          import sparkSession.sqlContext.implicits._
          rwLoadingDF.show(false)
          
          import org.apache.spark.sql.functions.col
          
          //****************Setting typeOfJson**********************//
		      var blankPricingDf    = rwLoadingDF.filter((col("pqbBand_minprct") === "" && (col("pqbBand_maxValue") === "") && (col("pqbBand_minValue") === "") && (col("pqbBand_colorCode") === "")&& (col("pqbBand_label") === "")&& (col("pqbBand_id") === "")&& (col("pqbBand_seq") === "")))

          var nonBlankPricingDf = sparkSession.createDataFrame(rwLoadingDF.except(blankPricingDf).rdd,rwSchema)

          blankPricingDf     = blankPricingDf.withColumn("typeofjsondata", lit("No Info"))
		  
		      nonBlankPricingDf  = nonBlankPricingDf.withColumn("typeofjsondata", lit("pqbBand"))
		  
		      rwLoadingDF = nonBlankPricingDf.unionAll(blankPricingDf)
		  
		      println("#####################  Setting typeofjsondata completed #####################")
		  
		      rwLoadingDF.show(false)
		      //********************************************************//
          rwLoadingDF.createOrReplaceTempView("Temp_DF")
          log.info("Raw SQl::::::::::::::::" + rawSqlQuery)
          var rawDF_curr = sparkSession.sql(rawSqlQuery)
          println("#####################  ALL DONE #####################")
          val rawDfNullRemoved = rawDF_curr.na.fill("")
          val result = rawDfNullRemoved.withColumn("newCol", concat_ws(propertiesObject.getRcdDelimiter(), rawDF_curr.schema.fieldNames.map(c => col(c)): _*))
          result.select("newCol").show(false)
          var dataDF = sparkSession.sql(f"""select * from $rwTblNm limit 0""")
          var nf = result.withColumn("flag", dqvalidate(result("newCol"), lit(dataDF.schema.fieldNames.toList.mkString(",")), lit(propertiesObject.getRcdDelimiter()), lit(propertiesObject.getNulchkCol()), lit(propertiesObject.getLnchkVal()), lit(propertiesObject.getDtfmtchkCol()), lit(propertiesObject.getIntchkCol()), lit(propertiesObject.getDoublechkCol()), lit(propertiesObject.getBooleanchkCol()), lit(propertiesObject.getLongchkCol())))
          nf.persist(StorageLevel.MEMORY_AND_DISK_SER)
          nf = Utilities.nullifyEmptyStrings(nf)
          var validrawDF = nf.filter(nf("flag") === "VALID")
          validrawDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
          validrawDF.show(false)
          validrawDF.repartition(10)
          var errorDF = nf.filter(nf("flag").contains("INVALID"))
          errorDF.repartition(10)
          // nf.show(false)
          errorDF = errorDF.drop("newCol").withColumn("err_cd", lit("100")).withColumnRenamed("flag", "err_msg_cd")
          // errorDF.show(false)
          // errorDF.printSchema()
          var errDF = sparkSession.sql(f"""select * from $errTblNm limit 0""")
          var errColumnList = errDF.columns

          src_count = df.count

          var errorDFWithCol = errorDF.select(errColumnList.head, errColumnList.tail: _*)
          var err_count = errorDFWithCol.count
          var dataDFRaw = sparkSession.sql(f"""select * from $rwTblNm limit 0""")
          var colListRaw = dataDFRaw.columns
          val dateFormatQuery = Utilities.prepareDateFormatQuery(colListRaw, propertiesObject.getDateCastFields())
          //log.info("================+++++++Date Format Query++++++++++++++++++++++++++++===============")
          log.info(dateFormatQuery)
          validrawDF.createOrReplaceTempView("Temp_DF")
          var validRawDfWithDateFormat = sparkSession.sql(dateFormatQuery)
          tgt_count = validRawDfWithDateFormat.count
          Utilities.storeDataFrame(validRawDfWithDateFormat, "Append", "ORC", rwTblNm)
          Utilities.storeDataFrame(errorDFWithCol, "Append", "ORC", errTblNm)
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(err_count)
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

          auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          Utilities.storeDataFrame(validRawDfWithDateFormat, "Append", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef())
          auditObj.setAudDataLayerName("rw_ref")
          println("****************** Target count for ref" + tgt_count)
          src_count = tgt_count
          err_count = tgt_count - src_count
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(err_count)
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          loadingDF.unpersist()
          validrawDF.unpersist()
          nf.unpersist()
        } else {
          log.error("File Header did not match with target table")
          auditObj.setAudJobStatusCode("failed")
          val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          return false
        }
      } else {
        log.warn("File is empty")
        auditObj.setAudJobStatusCode("success")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false
      }
    } catch {
      case sslException: InterruptedException => {
        log.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false
      }
      case nseException: NoSuchElementException => {
        log.error("No Such element found: " + nseException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false
      }
      case anaException: AnalysisException => {
        log.error("SQL Analysis Exception: " + anaException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false

      }
      case exception: Exception => {
        log.error(exception.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false

      }

    } //end of try
    true
  }
}
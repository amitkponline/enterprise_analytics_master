package com.hpe.finance

import org.apache.log4j.Logger
import com.hpe.config.PropertiesObject
import java.sql.Connection
import com.hpe.config.ConfigObjectNonStreaming
import com.hpe.config.AuditLoadObject
import java.sql.Date
import com.hpe.utils.Utilities
import com.hpe.utils.DataQuality
import org.apache.spark.sql.functions.{ udf, concat_ws, col, lit }
import org.apache.spark.sql.AnalysisException
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.functions.callUDF
import org.apache.spark.sql.functions.input_file_name
import java.util.ArrayList

object GLFileProcessor {
  val log = Logger.getLogger(getClass.getName)
  def glFilePipeline(propertiesObject: PropertiesObject, configurationObject: ConfigObjectNonStreaming, sqlCon: Connection, auditTbl: String, batchId: String, propertiesFilePath: String): Boolean = {
    var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    try {
      val sparkSession = configurationObject.getSpark()
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      val date: Date = null;

      val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
      //val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
      val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
      val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
      val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
      val auditBatchId = ld_jb_nr + "_" + batchId

      var errTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblErr()
      var rwTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw()

      var rwTblSaveMode = "Append"
      var refTblSaveMode = "Append"
      var multilineOption = "false"
      var quotes = ""
      var loadStatus:Boolean = false

      if (propertiesObject.getRwTblSaveMode() != null && propertiesObject.getRwTblSaveMode().size != 0) {
        rwTblSaveMode = propertiesObject.getRwTblSaveMode()
      }
      if (propertiesObject.getRefTblSaveMode() != null && propertiesObject.getRefTblSaveMode().size != 0) {
        refTblSaveMode = propertiesObject.getRefTblSaveMode()
      }
      if (propertiesObject.getMultilineOption() != null && propertiesObject.getMultilineOption().size != 0) {
        multilineOption = propertiesObject.getMultilineOption()
      }

      if (propertiesObject.getQuotes() != null && propertiesObject.getQuotes().size != 0) {
        quotes = """"""
      }

      auditObj.setAudBatchId(auditBatchId)
      auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudDataLayerName("File_Stg")
      auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(0)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configurationObject.getSpark().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)

      /*Getting File Names of current batch*/
      val fileListToRead = sparkSession.read.format("csv").option("header", "true").option("delimiter", ",").load(propertiesObject.getSourceFilePath())
      sparkSession.udf.register("get_file_name", (path: String) => path.split(" ").last)
      val fileNamelist1 = fileListToRead.withColumn("fileName", callUDF("get_file_name", input_file_name()))
      val fileNamelist2 = fileNamelist1.select(fileNamelist1("fileName")).distinct
      val fileNamelist = fileNamelist2.select("fileName").rdd.map(r => r(0)).collect()

      val fileList = new ArrayList[String]
      for (x <- fileNamelist) {
        fileList.add(((x + "").split("/").last))
      }
      val fl_nm = fileList.toArray.mkString(",")
      
      /* Load all the files prerent in source directory in current bathc */
      var df = sparkSession.read.format("csv").option("header", "true").option("delimiter", propertiesObject.getMsgdelimeter()).option("quote", quotes).option("multiLine", multilineOption).load(propertiesObject.getSourceFilePath()).persist(StorageLevel.MEMORY_AND_DISK) //.option("mode", "DROPMALFORMED")

      if (!df.head(1).isEmpty) {
        var src_count = df.count
        val fileHiveMapping = propertiesObject.getHiveJsonRawMap().split(";")
        var hiveCols: ArrayBuffer[String] = ArrayBuffer[String]()
        var fileHeaders: ArrayBuffer[String] = ArrayBuffer[String]()

        fileHiveMapping.foreach { x =>
          fileHeaders += (x.split("\\|")(0))
          hiveCols += (x.split("\\|")(1))

        }
        log.info(":::::::::::::::::Expected File Headers:::::::::::::::=" + propertiesObject.getColListSep().split(propertiesObject.getRcdDelimiter()))
        //println(":::::::::::::::::Hive Columns:::::::::::::::=" + hiveCols.mkString(","))

        //df = df.columns.foldLeft(df) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(".", "_").replace("-", "_").replace("%", "_").replace("(", "").replace(")", "").replaceAll("^\"|\"$", "")) }
        df.createOrReplaceTempView("Stg_Temp_DF")
        val colList = df.columns
        log.info(":::::::::::::::::Actual File Headers:::::::::::::::=" + colList.mkString(","))
        val isHeaderMatched = Utilities.validateGLHeader(colList, propertiesObject.getColListSep().split(propertiesObject.getRcdDelimiter()))

        log.info(":::::::::::::::::::Is header matched with target:::::::::::::::::::=" + isHeaderMatched)

        var hiveCollist = hiveCols.mkString(propertiesObject.getMsgdelimeter())
        var fileHeaderList = fileHeaders.mkString(",")
        var queryTest = "select " + fileHeaderList + " from Stg_Temp_DF"
        if (isHeaderMatched) {

          //Applying any reegext or other operation required on columns
          if (propertiesObject.getRegexQuery() != null && propertiesObject.getRegexQuery().size != 0) {
            df = sparkSession.sqlContext.sql(f"""select """ + propertiesObject.getRegexQuery() + """ from Stg_Temp_DF """)
          }
          df.createOrReplaceTempView("Stg_Tmp")

          var sql = Utilities.prepareQuery(fileHeaders, propertiesObject.getColNm(), propertiesObject.getCustomBooleanFields())

          sql = sql.replaceAll("FROM Stg_Tmp", ",'' as intgtn_fbrc_msg_id,'' AS src_sys_upd_ts, '" + src_sys_ky + "' as src_sys_ky, '' AS lgcl_dlt_ind,  current_timestamp() AS ins_gmt_ts, '' AS upd_gmt_ts, '' AS src_sys_extrc_gmt_ts,'' AS src_sys_btch_nr, '" + fl_nm + "'  AS fl_nm, '" + auditBatchId + "' AS ld_jb_nr FROM Stg_Tmp")


          val dbName = propertiesObject.getDbName()
          val tgtTable = propertiesObject.getTgtTblStg()
          val colList = sparkSession.sql(f"""select * from ${dbName}.${tgtTable} limit 1""").columns

          var final_DF = sparkSession.sql(sql)

          final_DF = final_DF.select(colList.map(col): _*)

          loadStatus = Utilities.storeDataFrame(final_DF, "overwrite", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblStg())
          var tgt_count = sparkSession.sql("select count(*) from " + propertiesObject.getDbName() + "." + propertiesObject.getTgtTblStg() + " where ld_jb_nr='" + auditBatchId + "'").first().getLong(0) //ctrlDfNullRemovedDistinct.count()
          if (loadStatus) {
            auditObj.setAudJobStatusCode("success")
            auditObj.setAudTgtRowCount(tgt_count)
          } else {
            auditObj.setAudJobStatusCode("failed")
            auditObj.setAudTgtRowCount(0)
          }

          auditObj.setAudDataLayerName("file_stg")
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudErrorRecords(0)
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

          auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudDataLayerName("stg_raw")

          log.info("#################### Stage Loaded Successfully ############################")
          import sparkSession.implicits._
          val dqvalidate = udf(DataQuality.DQValidchck _)
          var rawDfNullRemoved = sparkSession.sql("select * from " + propertiesObject.getDbName() + "." + propertiesObject.getTgtTblStg()).na.fill("")
          // Currency Cast
          var currCastFields: String = propertiesObject.getCurrencyCastFields
          if (currCastFields != null && currCastFields.trim().length() != 0) {
            log.info("###Currency Cast Changes Function in progress#################")
            var currCastFieldsArray: Array[String] = currCastFields.split(",")
            var noOfCols = currCastFieldsArray.length
            while (noOfCols > 0) {
              noOfCols = noOfCols - 1
              rawDfNullRemoved = Utilities.getcurrCastFields(rawDfNullRemoved, currCastFieldsArray(noOfCols))
            }
          }

          val result = rawDfNullRemoved.withColumn("newCol", concat_ws(propertiesObject.getRcdDelimiter(), final_DF.schema.fieldNames.map(c => col(c)): _*)).persist(StorageLevel.MEMORY_AND_DISK)

          var dataDF = sparkSession.sql(f"""select * from $rwTblNm limit 0""")
          var nf = result.withColumn("flag", dqvalidate(result("newCol"), lit(dataDF.schema.fieldNames.toList.mkString(",")), lit(propertiesObject.getRcdDelimiter()), lit(propertiesObject.getNulchkCol()), lit(propertiesObject.getLnchkVal()), lit(propertiesObject.getDtfmtchkCol()), lit(propertiesObject.getIntchkCol()), lit(propertiesObject.getDoublechkCol()), lit(propertiesObject.getBooleanchkCol()), lit(propertiesObject.getLongchkCol())))
          nf = nf.persist(StorageLevel.MEMORY_AND_DISK_SER)
          nf = Utilities.nullifyEmptyStrings(nf)

          var validrawDF = nf.filter(nf("flag") === "VALID")
          validrawDF.repartition(10)
          var errorDF = nf.filter(nf("flag").contains("INVALID"))
          errorDF.repartition(10)
          errorDF = errorDF.drop("newCol").withColumn("err_cd", lit("100")).withColumnRenamed("flag", "err_msg_cd")
          var errDF = sparkSession.sql(f"""select * from $errTblNm limit 0""")
          var errColumnList = errDF.columns

          src_count = sparkSession.sql("select count(*) from " + propertiesObject.getDbName() + "." + propertiesObject.getTgtTblStg() + " where ld_jb_nr='" + auditBatchId + "'").first().getLong(0) //ctrlDfNullRemovedDistinct.count()//rawDfNullRemoved.count

          var errorDFWithCol = errorDF.select(errColumnList.head, errColumnList.tail: _*)

          var dataDFRaw = sparkSession.sql(f"""select * from $rwTblNm limit 0""")
          var colListRaw = dataDFRaw.columns
          val dateFormatQuery = Utilities.prepareDateFormatQuery(colListRaw, propertiesObject.getDateCastFields())
          log.info(dateFormatQuery)
          validrawDF.createOrReplaceTempView("Temp_DF")
          var validRawDfWithDateFormat = sparkSession.sql(dateFormatQuery)
          loadStatus = Utilities.storeDataFrame(validRawDfWithDateFormat, rwTblSaveMode, "ORC", rwTblNm)
          val loadStatusErr = Utilities.storeDataFrame(errorDFWithCol, "Append", "ORC", errTblNm)
          val partitionDate = validRawDfWithDateFormat.select("ins_gmt_dt").first().getDate(0).toString()
          tgt_count = sparkSession.sql("select count(*) from " + rwTblNm + " where ld_jb_nr='" + auditBatchId + "' and ins_gmt_dt='"+partitionDate+"'").first().getLong(0) 
          //ctrlDfNullRemovedDistinct.count()
          var err_count = sparkSession.sql("select count(*) from " + errTblNm + " where ld_jb_nr='" + auditBatchId + "' and ins_gmt_dt='"+partitionDate+"'").first().getLong(0)
          if (loadStatus && loadStatusErr) {
            auditObj.setAudJobStatusCode("success")
            auditObj.setAudTgtRowCount(tgt_count)
          } else {
            auditObj.setAudJobStatusCode("failed")
            auditObj.setAudTgtRowCount(0)
          }
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudSrcRowCount(src_count)
          //auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(err_count)
          //auditObj.setAudJobStatusCode("success")
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

          auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          loadStatus = Utilities.storeDataFrame(validRawDfWithDateFormat, refTblSaveMode, "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef())
          auditObj.setAudDataLayerName("rw_ref")
          src_count = tgt_count
          tgt_count = sparkSession.sql("select count(*) from " + propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef() + " where ld_jb_nr='" + auditBatchId + "' and ins_gmt_dt='"+partitionDate+"'").first().getLong(0) //ctrlDfNullRemovedDistinct.count()
          if (loadStatus) {
            auditObj.setAudJobStatusCode("success")
            auditObj.setAudTgtRowCount(tgt_count)
          } else {
            auditObj.setAudJobStatusCode("failed")
            auditObj.setAudTgtRowCount(0)
          }
          err_count = tgt_count - src_count
          auditObj.setAudSrcRowCount(src_count)
          //auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(err_count)
          //auditObj.setAudJobStatusCode("success")
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          df.unpersist()
          result.unpersist()
          nf.unpersist()
        } else {
          log.error("File Header did not match with target table")
          auditObj.setAudJobStatusCode("failed")
          val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          return false
        }
      } else {
        log.warn("File is empty")
        auditObj.setAudJobStatusCode("success")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false
      }

    } catch {
      case sslException: InterruptedException => {
        log.error("Interrupted Exception" + sslException.printStackTrace())
        return false
      }
      case nseException: NoSuchElementException => {
        log.error("No Such element found: " + nseException.printStackTrace())
        return false
      }
      case anaException: AnalysisException => {
        log.error("SQL Analysis Exception: " + anaException.printStackTrace())
        return false
      }
      case exception: Exception => {
        log.error("Exception: " + exception.printStackTrace())
        return false
      }

    }finally{
      if(sqlCon!=null){
        sqlCon.close()
      }
    }

    true
  }
}

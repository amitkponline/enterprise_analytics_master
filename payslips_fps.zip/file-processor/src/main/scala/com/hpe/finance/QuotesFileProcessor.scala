package com.hpe.finance

import org.apache.log4j.Logger
import com.hpe.config.PropertiesObject
import java.sql.Connection
import com.hpe.config.ConfigObjectNonStreaming
import com.hpe.config.AuditLoadObject
import java.sql.Date
import com.hpe.utils.Utilities
import com.hpe.utils.DataQuality
import org.apache.spark.sql.functions.{ udf, concat_ws, col, lit }
import org.apache.spark.sql.AnalysisException
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.functions.callUDF
import org.apache.spark.sql.functions.input_file_name
import sys.process._
import org.apache.spark.sql.SparkSession

object QuotesFileProcessor {
 
  val log = Logger.getLogger(getClass.getName)
  def filePipeline(propertiesObject: PropertiesObject, configurationObject: ConfigObjectNonStreaming, sqlCon: Connection, auditTbl: String, batchId: String, propertiesFilePath: String): Boolean = {
    var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    try {
      val sparkSession = configurationObject.getSpark()
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      val date: Date = null;

      val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
      val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
      val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
      val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
     // var auditBatchId = ld_jb_nr + "_" + batchId

      var errTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblErr()
      var rwTblNm  = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw()
      
      var rwTblSaveMode   = "Append"
      var refTblSaveMode  = "Append"
      var multilineOption = "false"
      var quotes = ""
      var hederMatchReqd  = "Y"
      
      if (propertiesObject.getRwTblSaveMode()  != null && propertiesObject.getRwTblSaveMode().size    != 0){
           rwTblSaveMode  = propertiesObject.getRwTblSaveMode()        
      }
      if (propertiesObject.getRefTblSaveMode() != null && propertiesObject.getRefTblSaveMode().size   != 0){
           refTblSaveMode = propertiesObject.getRefTblSaveMode()
          }
      if (propertiesObject.getMultilineOption() != null && propertiesObject.getMultilineOption().size != 0){
           multilineOption  = propertiesObject.getMultilineOption()        
      }
      if (propertiesObject.getQuotes() != null && propertiesObject.getQuotes().size != 0){
            //quotes  = """"""
             quotes="\""
      }
      if (propertiesObject.getHederMatchReqd() != null && propertiesObject.getHederMatchReqd().size != 0){
           hederMatchReqd  = propertiesObject.getHederMatchReqd()        
      }
      
      auditObj.setAudApplicationName("job_EA_loadConfigFile")
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudDataLayerName("file_stg")
      auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(0)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configurationObject.getSpark().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      
      /*Dynamic code handling*/
      val fileListToRead = sparkSession.read.format("csv").option("header", "true").option("delimiter", ",").load(propertiesObject.getSourceFilePath())
      sparkSession.udf.register("get_file_name", (path: String) => path.split(" ").last)
      val fileNamelist1 = fileListToRead.withColumn("fileName", callUDF("get_file_name", input_file_name()))
      val fileNamelist2 = fileNamelist1.select(fileNamelist1("fileName")).distinct
      val fileNamelist = fileNamelist2.select("fileName").rdd.map(r => r(0)).collect() 
      
      var x=' '
      for ( x <- fileNamelist ) {
      var fl_nm = ((x+"").split("/").last)
      var fileNamewithpath = ((x+""))
      
      log.info(":::::::::::::::::File to be processed:::::::::::::::= " + fileNamewithpath)
      
      var batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
      
      var auditBatchId = ld_jb_nr + "_" + batchId
      
      auditObj.setAudBatchId(auditBatchId)
      
      var df = SparkSession.builder().getOrCreate().emptyDataFrame
      
      if(propertiesObject.getQuotes() != null && propertiesObject.getQuotes().size != 0)
      {
       df = sparkSession.read.format("csv").option("header", "true").option("delimiter", propertiesObject.getMsgdelimeter()).option("quote",quotes).option("escape", quotes).option("multiLine", multilineOption).load(fileNamewithpath) //For Files with quotes in data
      }
      else
      {
       df = sparkSession.read.format("csv").option("header", "true").option("delimiter", propertiesObject.getMsgdelimeter()).option("multiLine", multilineOption).load(fileNamewithpath)
      }
      var src_count = df.count
      if (src_count > 0) {

        val fileHiveMapping = propertiesObject.getHiveJsonRawMap().split(";")
        var hiveCols: ArrayBuffer[String] = ArrayBuffer[String]()
        var fileHeaders: ArrayBuffer[String] = ArrayBuffer[String]()
       // var colList: Array[String] = Array[String]()
        var colList:ArrayBuffer[String] = ArrayBuffer[String]()
        fileHiveMapping.foreach { x =>
          fileHeaders += (x.split("\\|")(0))
          hiveCols += (x.split("\\|")(1))
        }
        
        log.info(":::::::::::::::::Expected File Headers:::::::::::::::=" + fileHeaders.mkString(","))
        
        df = df.columns.foldLeft(df) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(".", "_").replace("-", "_").replace("%", "_").replace("(", "").replace(")", "").replace("#", "").replace("?", "").replace("[", "").replace("]", "").replace("|", "").replace("/", "").replace(":", "").replaceAll("^\"|\"$", "")) }
        df.createOrReplaceTempView("Stg_Temp_DF")
        colList = ArrayBuffer(df.columns:_*)
               
        log.info(":::::::::::::::::Actual File Headers:::::::::::::::=" + colList.mkString(","))
        
        //val isHeaderMatched = Utilities.validateHeader(colList, fileHeaders)

        val isHeaderMatched = true
        //log.info(":::::::::::::::::::Is header matched with target:::::::::::::::::::=" + isHeaderMatched  +":::Header matched required::::" +hederMatchReqd)

        var hiveCollist = hiveCols.mkString(propertiesObject.getMsgdelimeter())
        var fileHeaderList = fileHeaders.mkString(",")
        var queryTest  = "select "+ fileHeaderList +" from Stg_Temp_DF"
       
        if (isHeaderMatched || hederMatchReqd == "N") {        
          
          //Applying any regex or other operation required on columns
          
          if (propertiesObject.getRegexQuery() != null && propertiesObject.getRegexQuery().size != 0){
          df = sparkSession.sqlContext.sql(f"""select """+ propertiesObject.getRegexQuery() +""" from Stg_Temp_DF """)
          }
                    
          df.createOrReplaceTempView("Stg_Tmp")
          
         //var sql = Utilities.prepareQuery(fileHeaders, propertiesObject.getColNm() , propertiesObject.getCustomBooleanFields())
         
          var sql = Utilities.prepareQuery(colList, propertiesObject.getColNm() , propertiesObject.getCustomBooleanFields())
         
         sql = sql.replaceAll("FROM Stg_Tmp", ",'' as intgtn_fbrc_msg_id,'' AS src_sys_upd_ts, '" + src_sys_ky + "' as src_sys_ky, '' AS lgcl_dlt_ind,  current_timestamp() AS ins_gmt_ts, '' AS upd_gmt_ts, '' AS src_sys_extrc_gmt_ts,'' AS src_sys_btch_nr, '" + fl_nm + "'  AS fl_nm, '" + auditBatchId + "' AS ld_jb_nr , date(current_timestamp) AS ins_gmt_dt FROM Stg_Tmp")
                     
         val dbName=propertiesObject.getDbName()
         
         val tgtTable=propertiesObject.getTgtTblStg()
                  
         val hiveColList = sparkSession.sql(f"""select * from ${dbName}.${tgtTable} limit 1""").columns
        
         var final_DF = sparkSession.sql(sql)         
          
         final_DF=final_DF.select(hiveColList.map(col): _*)
                    
         val loadStatus = Utilities.storeDataFrame(final_DF, "overwrite", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblStg())
         log.info("stage table Data")
         final_DF.show()
         var tgt_count = src_count
          
         if(loadStatus){
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudTgtRowCount(tgt_count)
           }
         else {
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudTgtRowCount(0)
           }

          auditObj.setAudDataLayerName("file_stg")
         
          auditObj.setAudSrcRowCount(src_count)
         
          auditObj.setAudErrorRecords(0)
         
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          
          auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudDataLayerName("stg_rw")

          log.info("@@@@@@@@@@@@@@@@@ Stage Loaded Successfully @@@@@@@@@@@@@@@@@@@@@@@@@@@")
          import sparkSession.implicits._
          val dqvalidate = udf(DataQuality.DQValidchck _)
          var rawDfNullRemoved = final_DF.na.fill("")
          
          // Currency Cast 
          
          var currCastFields: String = propertiesObject.getCurrencyCastFields
          if (currCastFields != null && currCastFields.trim().length() != 0) {
            var currCastFieldsArray: Array[String] = currCastFields.split(",")
            var noOfCols = currCastFieldsArray.length
            while (noOfCols > 0) {
              noOfCols = noOfCols - 1
              rawDfNullRemoved = Utilities.getcurrCastFields(rawDfNullRemoved, currCastFieldsArray(noOfCols))
            }
          }
          
          //Applying lrtrim on all attributes
                   
          var lrTrimFields: String = propertiesObject.getLrTrimFields()
          if (lrTrimFields != null && lrTrimFields.trim().length() != 0) {
            var lrTrimFieldsArray: Array[String] = lrTrimFields.split(",")
            var noOfCols = lrTrimFieldsArray.length
            while (noOfCols > 0) {
              noOfCols = noOfCols - 1
              rawDfNullRemoved = Utilities.trimRequiredColumns(rawDfNullRemoved, lrTrimFieldsArray(noOfCols))
            }
          }
          
          val result = rawDfNullRemoved.withColumn("newCol", concat_ws(propertiesObject.getRcdDelimiter(), final_DF.schema.fieldNames.map(c => col(c)): _*))
          var dataDF = sparkSession.sql(f"""select * from $rwTblNm limit 0""")

          var nf = result.withColumn("flag", dqvalidate(result("newCol"), lit(dataDF.schema.fieldNames.toList.mkString(",")), lit(propertiesObject.getRcdDelimiter()), lit(propertiesObject.getNulchkCol()), lit(propertiesObject.getLnchkVal()), lit(propertiesObject.getDtfmtchkCol()), lit(propertiesObject.getIntchkCol()), lit(propertiesObject.getDoublechkCol()), lit(propertiesObject.getBooleanchkCol()), lit(propertiesObject.getLongchkCol())))
          nf = nf.persist(StorageLevel.MEMORY_AND_DISK_SER)
          nf = Utilities.nullifyEmptyStrings(nf)

          var validrawDF = nf.filter(nf("flag") === "VALID")
         
          validrawDF.repartition(10)
          var errorDF = nf.filter(nf("flag").contains("INVALID"))
          errorDF.repartition(10)
          
          errorDF = errorDF.drop("newCol").withColumn("err_cd", lit("100")).withColumnRenamed("flag", "err_msg_cd")
          
          var errDF = sparkSession.sql(f"""select * from $errTblNm limit 0""")
          var errColumnList = errDF.columns

          src_count = final_DF.count
          
          var errorDFWithCol = errorDF.select(errColumnList.head, errColumnList.tail: _*)
          var err_count = errorDFWithCol.count
          var dataDFRaw = sparkSession.sql(f"""select * from $rwTblNm limit 0""")
          var colListRaw = dataDFRaw.columns
          val dateFormatQuery = Utilities.prepareDateFormatQuery(colListRaw, propertiesObject.getDateCastFields())

          validrawDF.createOrReplaceTempView("Temp_DF")
          var validRawDfWithDateFormat = sparkSession.sql(dateFormatQuery)
          tgt_count = validRawDfWithDateFormat.count
          Utilities.storeDataFrame(validRawDfWithDateFormat, rwTblSaveMode, "ORC", rwTblNm)
          Utilities.storeDataFrame(errorDFWithCol, "Append", "ORC", errTblNm)
          log.info("Raw table Data")
          validRawDfWithDateFormat.show()
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(err_count)
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

          auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          Utilities.storeDataFrame(validRawDfWithDateFormat, refTblSaveMode, "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef())
          log.info("Ref table Data")
          validRawDfWithDateFormat.show()
          auditObj.setAudDataLayerName("rw_ref")
          
          src_count = tgt_count
          err_count = tgt_count - src_count
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(err_count)
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          nf.unpersist()   
          if (propertiesObject.getArchiveDir() != null && propertiesObject.getArchiveDir().size != 0 && fileNamewithpath.contains(".")){
            log.warn("Moving "+fileNamewithpath+" file to Archive Directory")
            (s"hdfs dfs -mv "+fileNamewithpath +" " +propertiesObject.getArchiveDir())! //Moving source file to Archive Directory.
            
           }
        } else {
          log.error("File Header did not match with target table")
          auditObj.setAudJobStatusCode("failed")
          val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          return false
        }
      } else {
        log.warn("File is empty")
        if (propertiesObject.getArchiveDir() != null && propertiesObject.getArchiveDir().size != 0 && fileNamewithpath.contains(".")){
            
          log.warn("Moving "+fileNamewithpath+" file to Archive Directory")
            
            (s"hdfs dfs -mv "+fileNamewithpath +" " +propertiesObject.getArchiveDir())! //Moving source file to Archive Directory.
            
           }
        auditObj.setAudJobStatusCode("success")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false
      }
     
    }

    } catch {
      case sslException: InterruptedException => {
        log.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false
      }
      case nseException: NoSuchElementException => {
        log.error("No Such element found: " + nseException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false
      }
      case anaException: AnalysisException => {
        log.error("SQL Analysis Exception: " + anaException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false
      }
      
      case exception: Exception => {
        log.error(exception.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        return false
      }

    }

    true
  }
}

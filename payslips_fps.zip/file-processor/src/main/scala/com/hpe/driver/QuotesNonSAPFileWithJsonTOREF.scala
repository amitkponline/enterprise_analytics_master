package com.hpe.driver
import com.hpe.config.PropertiesObject
import com.hpe.utils.Utilities
import com.hpe.config.ConfigObject
import com.hpe.config.SetUpConfiguration
import org.apache.log4j.Logger
import com.hpe.config.SetUpConfigurationNonStreaming
import com.hpe.config.ConfigObjectNonStreaming
import java.util.HashMap
import scala.collection.Map
import com.hpe.config.SQLPropertiesObject
import java.sql.Connection
import scala.collection.JavaConversions._

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{ lit, col, concat_ws, split, struct }
import org.apache.spark.sql.catalyst.expressions.Explode
import org.apache.spark.sql.types.{ StructType, StructField, StringType };
import org.apache.spark.rdd.RDD

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.types.LongType
import com.hpe.config._

import com.hpe.utils.Utilities
import com.hpe.utils.DataQuality
import org.apache.spark.sql.functions.{ lower, upper }
import java.sql.Connection
import java.sql.Date

import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.{ lit, max, row_number }
import org.apache.spark.sql.Row
//import org.apache.avro.generic.GenericData.Array
import org.apache.spark.sql.functions.regexp_replace
import org.apache.spark.storage.StorageLevel
import com.hpe.finance.QuotesJSONFileProcessor

object QuotesNonSAPFileWithJsonTOREF {
  val log = Logger.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Waiting Window in seconds> <consumer-group> <OffsetReset> <Properties file path> <Optional arg: Kafka Topic List>")
      println("Stopping the flow")
      System.exit(1)
    }
    val propertiesFilePath = String.valueOf(args(0).trim())
    val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

    val propertiesObject: PropertiesObject = Utilities.getPropertiesobject(propertiesFilePath)
    val configurationObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
    val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
    val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
    val envPropertiesFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"connection.properties"
    val sqlPropertyObject: EnvPropertiesObject =  Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
    val sqlCon = Utilities.getConnection(sqlPropertyObject)
    val auditTbl = sqlPropertyObject.getMySqlDBName() + "." + sqlPropertyObject.getMySqlAuditTbl()

    var status = QuotesJSONFileProcessor.jsonFlattenPipeline(propertiesObject, configurationObject, sqlCon, auditTbl, batchId, propertiesFilePath)
    if(status){
      sys.exit(0)
    }else{
      sys.exit(1)
    }
    

  }

}

package com.hpe.driver

import com.hpe.utils.Utilities
import org.apache.log4j.Logger
import com.hpe.config.SetUpConfigurationNonStreaming
import com.hpe.config.ConfigObjectNonStreaming
import scala.collection.JavaConversions._
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
import org.apache.log4j.Logger
import com.hpe.config._
import com.hpe.utils.Utilities
import org.apache.spark.sql.types.{ LongType, StringType, StructField, StructType }
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel

object ABCInfoLoader {
  val logger = Logger.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty || args.length < 3) {
      logger.error("Invalid number of arguments passed.")
      logger.error("Arguments Usage: <Hive Table> <Interval By Days> <Connection Properties File>")
      logger.error("Stopping the flow")
      System.exit(1)
    }
    var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")

    try {
      val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
      val tblNm = String.valueOf(args(0).trim())
      val interval = String.valueOf(args(1).trim()).toInt
      val envPropertiesFilePath = String.valueOf(args(2).trim())
      
      //val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
      val sKeyFilePath = envPropertiesFilePath.substring(0, envPropertiesFilePath.lastIndexOf("/") + 1) + "sKey"
      val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
      val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
      val sqlCon = Utilities.getConnection(envPropertiesObject)
      val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
      val spark = configObject.getSpark()
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
      val ld_jb_nr = "ABC_Ingestion"
      val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
      val auditBatchId = ld_jb_nr + "_" + batchId
      val objNm = tblNm.split("\\.")(1) 

      auditObj.setAudBatchId(auditBatchId)
      auditObj.setAudApplicationName(spark.sparkContext.appName)
      auditObj.setAudObjectName(objNm)
      auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(0)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(spark.sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      var sql = "select raw.obj_nm,'streaming' as ingestion_type, (CURRENT_DATE - INTERVAL "+interval+" DAY) as on_date ,total_number_batches,total_trsn_count,total_flatten_count,ref_last_loaded_on,current_timestamp as ins_gmt_ts from (select sum(src_rec_qty) as total_trsn_count,count(distinct btch_id) as total_number_batches, obj_nm from "+auditTbl+" where dta_lyr_nm='hist_rw' and date(ld_ts)=CURRENT_DATE - INTERVAL "+interval+" DAY group by obj_nm)raw inner join ( select sum(src_rec_qty) as total_flatten_count, max(ld_ts) as ref_last_loaded_on, obj_nm from "+auditTbl+" where dta_lyr_nm='rw_ref' and date(ld_ts)=CURRENT_DATE - INTERVAL "+interval+" DAY group by obj_nm)ref on raw.obj_nm=ref.obj_nm"
      /* Read Audit Table */
      val auditDfStreaming = Utilities.readAuditTble(sqlCon, sql, spark, envPropertiesObject)
      sql = "select raw.obj_nm,'batch' as ingestion_type, (CURRENT_DATE - INTERVAL "+interval+" DAY) as on_date ,total_number_batches,total_trsn_count,total_flatten_count,ref_last_loaded_on,current_timestamp as ins_gmt_ts from (select sum(src_rec_qty) as total_trsn_count,count(distinct btch_id) as total_number_batches, obj_nm from "+auditTbl+" where lower(dta_lyr_nm)='file_stg' and date(ld_ts)=CURRENT_DATE - INTERVAL "+interval+" DAY group by obj_nm)raw inner join ( select sum(src_rec_qty) as total_flatten_count, max(ld_ts) as ref_last_loaded_on, obj_nm from "+auditTbl+" where dta_lyr_nm='rw_ref' and date(ld_ts)=CURRENT_DATE - INTERVAL "+interval+" DAY group by obj_nm)ref on raw.obj_nm=ref.obj_nm"
      val auditDfBatch = Utilities.readAuditTble(sqlCon, sql, spark, envPropertiesObject)
      val auditDf = auditDfStreaming.union(auditDfBatch).persist(StorageLevel.MEMORY_AND_DISK)
      val cols = spark.sql("select * from " + tblNm + " limit 0")
      val status = Utilities.storeDataFrame(auditDf.select(cols.columns.head, cols.columns.tail: _*), "Overwrite", "ORC", tblNm)
      if(status){
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(auditDf.count())
        auditObj.setAudTgtRowCount(auditDf.count())
      }else{
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudTgtRowCount(0)
      }
        auditObj.setAudDataLayerName("rw_ref")
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        auditDf.unpersist()
    } catch {
      case sslException: InterruptedException => {
        logger.error("Interrupted Exception")
        sys.exit(1)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        sys.exit(1)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        sys.exit(1)
      }
      case exception: Exception => {
        logger.error("Exception: " + exception.printStackTrace())
        sys.exit(1)
      }
    }
  }
}
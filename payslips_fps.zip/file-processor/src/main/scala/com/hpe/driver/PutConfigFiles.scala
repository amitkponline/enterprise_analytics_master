package com.hpe.driver

import org.apache.log4j.Logger
import java.sql.Connection
import com.hpe.utils.Utilities
import com.hpe.config.EnvPropertiesObject
import com.hpe.config.PropertiesObject
import com.hpe.config.ConfigObjectNonStreaming
import com.hpe.config.SetUpConfigurationNonStreaming
import com.hpe.config.AuditLoadObject
import scala.collection.Map
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.TimestampType
import com.hpe.config.SKeyObject
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.AnalysisException
import java.net.ConnectException
import org.apache.spark.sql.Row
import com.hpe.utils._
import com.hpe.config._
import util.control.Breaks._
import org.apache.hadoop.fs.{FileSystem, Path}
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.sql.Timestamp
import org.apache.spark.sql.types.StructType
import scala.sys.process._
import org.apache.spark.sql.types.StructField

object PutConfigFiles {

  //Initialized Log
  val logger = Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    if (args == null || args.isEmpty) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
      println("Stopping the flow")
      System.exit(1)
    }
    
    var br: BufferedReader=null
    var validOut, invalidOut: OutputStreamWriter=null
    val propertiesFilePath = String.valueOf(args(0).trim())
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val auditBatchId = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())

    val sharedConfigObjectProperties: SharedConfigObjectProperties = Utilities.getsharedConfigObjectProperties(propertiesFilePath)
    
    //sharedConfigObjectProperties.properties
    val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
    val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
    val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
    val envPropertiesFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"connection.properties"
    val sqlPropertyObject: EnvPropertiesObject =  Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
    val auditTbl = sqlPropertyObject.getMySqlDBName() + "." + sqlPropertyObject.getMySqlAuditTbl()
    
    var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    auditObj.setAudApplicationName(configObject.spark.sparkContext.appName)
    auditObj.setAudDataLayerName("file_stg")
    auditObj.setAudCreatedBy(System.getProperty("user.name"))
    auditObj.setAudJobStartTimeStamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()))
    
    try {
      val configObjectNameList = sharedConfigObjectProperties.getConfigObjectNameList().split(",",-1)
      var i=0; var key=""
      var globalMap = Map.empty[String, Int]
      for ( result <- configObjectNameList ) {
          i+=1
          if(i==2) {
            globalMap += (key -> result.toInt)
            key="";i=0
          } else {
            key=result
          }
        }
      logger.info(s"Element in globalMap = $globalMap")
      
      val schema = StructType(Array(StructField("srs_sys_ky", StringType, true), 
          StructField("fl_nm", StringType, true), StructField("ld_jb_nr", StringType, true), 
          StructField("jb_nm", StringType, true), StructField("file_name", StringType, true)))
      val master_csv = configObject.spark.sqlContext.read.format("csv").option("header", true).schema(schema).option("delimiter", ",").load(sharedConfigObjectProperties.getMasterDataFile())
      
      val fileNames=Utilities.getAllFiles(sharedConfigObjectProperties.getConfigFileSourceDir(), configObject.spark.sparkContext)
      breakable {
        for( fileName <- fileNames) {
          logger.info("fileName: "+fileName)
          var fileNameWithExtn=fileName.substring(fileName.lastIndexOf(sharedConfigObjectProperties.getConfigFileSourceDir()), fileName.length).diff(sharedConfigObjectProperties.getConfigFileSourceDir())
          var fileNameWithoutExtn=fileName.substring(fileName.lastIndexOf(sharedConfigObjectProperties.getConfigFileSourceDir()), fileName.lastIndexOf(".")).diff(sharedConfigObjectProperties.getConfigFileSourceDir())
          
          breakable {
            if(fileNameWithoutExtn.trim().length() == 0 || globalMap.get(fileNameWithoutExtn).equals("None")
                || !fileName.toUpperCase().endsWith(sharedConfigObjectProperties.getConfigFileExt().toUpperCase()) ) {
              break;
            } else {
              val date=new Date
              val currentTimestamp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(date)
              logger.info("currentTimestamp: "+currentTimestamp)
              
              val row = master_csv.filter(s"file_name='$fileNameWithExtn'")
              val obj_nm = Utilities.getValue("fl_nm", row)
              val ld_jb_nr = Utilities.getValue("ld_jb_nr", row)
              val srs_sys_ky = Utilities.getValue("srs_sys_ky", row)
          
              var sqlCon = Utilities.getConnection(sqlPropertyObject)
              val configObjectProperties = Utilities.getControlTableInfo(sqlCon, fileNameWithExtn.toUpperCase())
              sqlCon.close()
              if(configObjectProperties.getCnfg_obj_nm()==null || configObjectProperties.getCnfg_obj_nm().isEmpty()) { configObjectProperties.setCnfg_obj_nm(obj_nm) }
              if(configObjectProperties.getLd_jb_nr()==null || configObjectProperties.getLd_jb_nr().isEmpty()) { configObjectProperties.setLd_jb_nr(ld_jb_nr) }
              if(configObjectProperties.getSrc_sys_ky()==null || configObjectProperties.getSrc_sys_ky().isEmpty()) { configObjectProperties.setSrc_sys_ky(srs_sys_ky) }
              
              auditObj.setFlNm(fileNameWithExtn)
              auditObj.setSysBtchNr(configObjectProperties.getLd_jb_nr())
              auditObj.setAudBatchId(configObjectProperties.getLd_jb_nr()+auditBatchId)
              auditObj.setAudObjectName(configObjectProperties.getCnfg_obj_nm())
              
              var newLine=""
              var lineCount, validRecCount, invalidRecCount=0
              var err_msg="Structural validation failed for "+fileNameWithExtn+" ! Please check column Counts in source file and property files !"
              
              val fileSystem = FileSystem.get(configObject.spark.sparkContext.hadoopConfiguration)
              br = new BufferedReader(new InputStreamReader(fileSystem.open(new Path(sharedConfigObjectProperties.getConfigFileSourceDir()+fileNameWithExtn))))
              var line = br.readLine()
              while (line != null) {
                if(lineCount==0) {
                  lineCount +=1
                } else {
                  //logger.info("globalMap.get(fileNameWithoutExtn): "+globalMap.get(fileNameWithoutExtn))
                  //logger.info("line.split(sharedConfigObjectProperties.getConfigFileDelimiter()).length"+line.split(sharedConfigObjectProperties.getConfigFileDelimiter()).length)
                  
                  if(line.replaceAll("[^\\t]", "").length==globalMap.getOrElse(fileNameWithoutExtn, 0)-1) {
                    if(validRecCount==0) {
                      newLine=""
                      validOut = new OutputStreamWriter(fileSystem.create(new Path(sharedConfigObjectProperties.getConfigBaseDir()+fileNameWithoutExtn+"/"+fileNameWithExtn), true))
                    }
                    validOut.write(newLine+line)
                    newLine="\n"
                    validRecCount+=1
                  } else {
                    if(invalidRecCount==0) {
                      newLine=""
                      invalidOut = new OutputStreamWriter(fileSystem.create(new Path(sharedConfigObjectProperties.getConfigErrorDir()+"configObject"), true))
                    }
                    invalidOut.write(newLine+line+"\u001C"+configObjectProperties.getCnfg_obj_nm()+"\u001C"+fileNameWithExtn+"\u001C"+currentTimestamp+"\u001C"+err_msg)
                    newLine="\n"
                    invalidRecCount+=1
                  }
                }
                line = br.readLine()
              }
              
              if(br!=null) { br.close() }
              if(validOut!=null) { validOut.flush(); validOut.close() }
              if(invalidOut!=null) { invalidOut.flush(); invalidOut.close() }
              br=null; validOut=null; invalidOut=null
              
              logger.info(fileNameWithoutExtn+": Valid Record Count: "+validRecCount)
              if(validRecCount>0) {
                val validDF = configObject.spark.sqlContext.read.format("csv").option("header", false).option("delimiter", sharedConfigObjectProperties.getConfigFileDelimiter()).load(sharedConfigObjectProperties.getConfigBaseDir()+fileNameWithoutExtn+"/"+fileNameWithExtn)
                logger.info("ValidDF: "+validDF.count())
                //logger.info("ValidDF: "+validDF.printSchema())
                Utilities.storeDataFrame(validDF, "overwrite", "textfile", sharedConfigObjectProperties.getSchemaName()+"."+configObjectProperties.getSrc_tbl_nm())
              }
              
              logger.info(fileNameWithoutExtn+": Error Record Count: "+invalidRecCount)
              if(invalidRecCount>0) {
                val errRecDF = configObject.spark.sql("""select * from """ + sharedConfigObjectProperties.getSchemaName()+"."+sharedConfigObjectProperties.getErrorStgTable())
                Utilities.storeErrDataFrame(errRecDF, "Append", "ORC", "snappy", sharedConfigObjectProperties.getSchemaName()+"."+sharedConfigObjectProperties.getErrorTable())
              }
              
              val currentDate=new Date()
              auditObj.setAudJobStatusCode(sharedConfigObjectProperties.getAuditStatusSuccess())
              auditObj.setAudJobStartTimeStamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date))
              auditObj.setAudJobEndTimestamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(currentDate))
              auditObj.setAudLoadTimeStamp(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(currentDate))
              auditObj.setAudSrcRowCount(validRecCount+invalidRecCount)
              auditObj.setAudTgtRowCount(validRecCount)
              auditObj.setAudErrorRecords(invalidRecCount)
              auditObj.setAudJobDuration((currentDate.getTime-date.getTime).toString())
              
              sqlCon = Utilities.getConnection(sqlPropertyObject)
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)             
              sqlCon.close()
              if(validRecCount>0) {
                sqlCon = Utilities.getConnection(sqlPropertyObject)
                Utilities.updateConfigObjPropTableLoadStatus(sqlCon, sharedConfigObjectProperties.getConfigObjPropTable(), configObjectProperties, "ld_status_to_process")
                sqlCon.close()
              }
              
              logger.info("Archiving the file: "+fileNameWithExtn)
              val currentTime=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date).replaceAll("[\\s:]","_")
              (s"hdfs dfs -mv "+sharedConfigObjectProperties.getConfigFileSourceDir()+fileNameWithExtn +" " +sharedConfigObjectProperties.getConfigFileArchiveDir()+fileNameWithExtn+"_"+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date).replaceAll("[\\s:]","_"))!
            }
          }
        }
        
      }
    } catch {
      case sslException: InterruptedException => {
        logger.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        val sqlCon = Utilities.getConnection(sqlPropertyObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        logger.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        val sqlCon = Utilities.getConnection(sqlPropertyObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        logger.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        val sqlCon = Utilities.getConnection(sqlPropertyObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case connException: ConnectException => {
        logger.error("Connection Exception: " + connException.printStackTrace())
        logger.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        val sqlCon = Utilities.getConnection(sqlPropertyObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case exception: Exception => {
        logger.error(exception.printStackTrace())
        logger.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        val sqlCon = Utilities.getConnection(sqlPropertyObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
    } finally {
        if(br!=null) { br.close() } 
        if(validOut!=null) { validOut.flush(); validOut.close() }
        if(invalidOut!=null) { invalidOut.flush(); invalidOut.close() }
    }
  }
  
}
package com.hpe.driver

import com.hpe.utils.Utilities
import org.apache.log4j.Logger
import com.hpe.config.SetUpConfigurationNonStreaming
import com.hpe.config.ConfigObjectNonStreaming
import scala.collection.JavaConversions._
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
import org.apache.log4j.Logger
import com.hpe.config._
import com.hpe.utils.Utilities
import org.apache.spark.sql.types.{ LongType, StringType, StructField, StructType }
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel

object ArchiveAllPartitions {
  val logger = Logger.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty || args.length < 9) {
      logger.error("Invalid number of arguments passed.")
      logger.error("Arguments Usage: <Object Name> <Hive Schema> <Partition Window in Days> <Hive Partition Column Name> <Parimary key> <Sorting Column> <Record Identifier> <Object Type> <Ref Partition Window>")
      logger.error("Stopping the flow")
      System.exit(1)
    }
    try {
      val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()

      val objNm = String.valueOf(args(0).trim())
      val dbschema = String.valueOf(args(1).trim())
      val partitionWindow = String.valueOf(args(2).trim())//7 - this is used for rw, err, ctrl
      val partitionColNm = String.valueOf(args(3).trim())//ins_gmt_dt
      val primaryKey = String.valueOf(args(4).trim())//e1edk01_idoc_dcmt_nr--order number
      val sortCols = String.valueOf(args(5).trim())//upd_gmt_ts
      val recIdentifier = String.valueOf(args(6).trim())//idoc_nr
      val objType = String.valueOf(args(7).trim())//serp,other(flatten structures not having control table)
      val partitionWindowRef = String.valueOf(args(8).trim())//used for refined tables - 180 for order/7 for others
      val isErrorArchived = if(String.valueOf(args(9))!=null) String.valueOf(args(9).trim()) else "N"// Y  for archiving error table and N or blank for not archiving error table
      val spark = configObject.getSpark()
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
      var latestDistintPartitions = ""
      var dropPartitionQuery = ""
      var endTime = startTime
      var duration = "0"
      
      logger.info("ARGS============================"+objNm+" "+dbschema+" "+partitionWindow+" "+partitionColNm+" "+primaryKey+" "+sortCols+" "+recIdentifier+" "+objType+" "+partitionWindowRef)
      
      if(!objType.equalsIgnoreCase("serp") && !objType.equalsIgnoreCase("other")){
        logger.warn("Object type provided is: "+objType +" Please provide appropriate type. [serp/other]")
        sys.exit(1)
      }
      
      if(objType.equalsIgnoreCase("serp")){
        /* Archiving Control table */
        val ctrlTblNm = dbschema + "." + objNm + "_ctrl"
        val ctrlTblArcNm = dbschema + "." + objNm + "_ctrl_arc"
       
        val arcCtrlDf = spark.sql("select * from " + ctrlTblNm + " where " + partitionColNm + " <= DATE_SUB(to_date(current_timestamp)," + partitionWindow + ")")
        if (!arcCtrlDf.head(1).isEmpty) {
          arcCtrlDf.write.mode(SaveMode.Append).format("orc").insertInto(ctrlTblArcNm)
  
          latestDistintPartitions = arcCtrlDf.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0)).toSeq.mkString(",")
          dropPartitionQuery = Utilities.prepareDropPartitionQuery(latestDistintPartitions, partitionColNm, ctrlTblNm)
          spark.sql(dropPartitionQuery)
          logger.info("Ctrl Archiving Query:::::::::::::"+dropPartitionQuery)
          spark.sql("MSCK REPAIR TABLE " + ctrlTblNm)
          spark.sql("MSCK REPAIR TABLE " + ctrlTblArcNm)
  
          endTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
          duration = (((format.parse(endTime).getTime - format.parse(startTime).getTime).toString()).toInt / 1000).toString()
          logger.info("Archiving of " + ctrlTblNm + " for " + partitionWindow + " days took " + duration + " seconds")
        } else {
          logger.warn("No new partitions found to be archived in control table!")
        }
      }      
      /* Archiving Raw table */
      val rwTblNm = dbschema + "." + objNm + "_rw"
      val rwTblArcNm = dbschema + "." + objNm + "_rw_arc"
      startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")

      val arcDf = spark.sql("select * from " + rwTblNm + " where " + partitionColNm + " <= DATE_SUB(to_date(current_timestamp)," + partitionWindow + ")")
      if (!arcDf.head(1).isEmpty) {
        val partitionList = arcDf.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0))
        val archiveDf = spark.sql("select * from " + rwTblArcNm).filter(col(partitionColNm) isin (partitionList: _*))
        if(!archiveDf.head(1).isEmpty){
          val duplicatePartitions = archiveDf.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0)).toSeq.mkString(",")
          logger.error("Archival of Raw layer failed as "+duplicatePartitions+" partition(s) are already archived. Please archive these partitions manually to fix the issue!")
          sys.exit(1)
        }else{
        arcDf.write.mode(SaveMode.Append).format("orc").insertInto(rwTblArcNm)
        latestDistintPartitions = arcDf.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0)).toSeq.mkString(",")
        //spark.sql("ALTER TABLE "+rwTblNm+" DROP PARTITION("+partitionColNm+" <= DATE_SUB(to_date(current_timestamp),"+partitionWindow+")")
        dropPartitionQuery = Utilities.prepareDropPartitionQuery(latestDistintPartitions, partitionColNm, rwTblNm)
        logger.info("Raw Archiving Query:::::::::::::"+dropPartitionQuery)
        spark.sql(dropPartitionQuery)
        spark.sql("MSCK REPAIR TABLE " + rwTblNm)
        spark.sql("MSCK REPAIR TABLE " + rwTblArcNm)

        endTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
        duration = (((format.parse(endTime).getTime - format.parse(startTime).getTime).toString()).toInt / 1000).toString()
        logger.info("Archiving of " + rwTblNm + " for " + partitionWindow + " days took " + duration + " seconds")}
      } else {
        logger.warn("No new partitions found to be archived in raw table!")
      }

      /* Archiving Refined table */
      val refTblNm = dbschema + "." + objNm + "_ref"
      val refTblArcNm = dbschema + "." + objNm + "_ref_arc"
      startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")

      val arcRefDfAll = spark.sql("select * from " + refTblNm + " where " + partitionColNm + " <= DATE_SUB(to_date(current_timestamp)," + partitionWindowRef + ")")
      var arcRefDfLatest:DataFrame=null
      if(objType.equalsIgnoreCase("serp")){
        val latestIdocs = Utilities.getLatestRecs(arcRefDfAll, List(primaryKey), List(sortCols)).select(recIdentifier).collect.map(row => row.getString(0)).toSeq
        arcRefDfLatest =arcRefDfAll.where(col(recIdentifier).isin(latestIdocs: _*))
      }else if(objType.equalsIgnoreCase("other")){
        arcRefDfLatest = Utilities.getLatestRecs(arcRefDfAll, List(primaryKey), List(sortCols))
        arcRefDfLatest.persist(StorageLevel.MEMORY_AND_DISK)
      }else{
        logger.warn("Please provide appropriate type. [serp/other]")
        logger.error("Refined and Error Archival failed")
        sys.exit(1)
      }
      if (!arcRefDfLatest.head(1).isEmpty) {

        val latestDistintOrders = arcRefDfLatest.select(col(primaryKey)).persist(StorageLevel.MEMORY_AND_DISK_SER)
        val existingRefPartitions = spark.sql("select distinct " + partitionColNm + ", " + primaryKey + " from " + refTblArcNm+" union all select distinct " + partitionColNm + ", " + primaryKey + " from " + refTblNm).join(latestDistintOrders, Seq(primaryKey), "inner").select(col(partitionColNm)).distinct().collect.map(row => row.getDate(0)).toSeq

        var allOrdersFromOverwrite = spark.sql("select * from " + refTblArcNm).where(col(partitionColNm).isin(existingRefPartitions: _*))

        val unChangedOrders = allOrdersFromOverwrite.join(arcRefDfLatest, Seq(primaryKey), "left_anti")
        val arcRefDf = unChangedOrders.select(arcRefDfLatest.columns.head, arcRefDfLatest.columns.tail: _*).union(arcRefDfLatest)
        arcRefDf.write.mode(SaveMode.Overwrite).format("orc").insertInto(refTblArcNm)
        latestDistintPartitions = arcRefDfAll.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0)).toSeq.mkString(",")
        dropPartitionQuery = Utilities.prepareDropPartitionQuery(latestDistintPartitions, partitionColNm, refTblNm)
        logger.info("Ref Archiving Query:::::::::::::"+dropPartitionQuery)
        spark.sql(dropPartitionQuery)
        spark.sql("MSCK REPAIR TABLE " + refTblNm)
        spark.sql("MSCK REPAIR TABLE " + refTblArcNm)

        endTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
        duration = (((format.parse(endTime).getTime - format.parse(startTime).getTime).toString()).toInt / 1000).toString()
        logger.info("Archiving of " + refTblNm + " for " + partitionWindowRef + " days took " + duration + " seconds")
        arcRefDfLatest.unpersist()
        latestDistintOrders.unpersist()
      } else {
        logger.warn("No new partitions found to be archived in ref table!")
      }

      /* Archiving Error table */
      if(isErrorArchived.equalsIgnoreCase("Y")){
        val errTblNm = dbschema + "." + objNm + "_err"
        val errTblArcNm = dbschema + "." + objNm + "_err_arc"
        startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
  
        val arcErrDf = spark.sql("select * from " + errTblNm + " where " + partitionColNm + " <= from_unixtime(unix_timestamp(to_date(DATE_SUB(to_date(current_timestamp)," + partitionWindow + ")),'yyyy-MM-dd'),'yyyyMMdd')")
        if (!arcErrDf.head(1).isEmpty) {
          arcErrDf.write.mode(SaveMode.Append).format("orc").insertInto(errTblArcNm)
          latestDistintPartitions = arcErrDf.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0)).toSeq.mkString(",")
          val latestDistintPartitionsErr = latestDistintPartitions.replace("-", "")
          dropPartitionQuery = Utilities.prepareDropPartitionQuery(latestDistintPartitionsErr, partitionColNm, errTblNm)
          logger.info("Err Archiving Query:::::::::::::"+dropPartitionQuery)
          spark.sql(dropPartitionQuery)
          spark.sql("MSCK REPAIR TABLE " + errTblNm)
          spark.sql("MSCK REPAIR TABLE " + errTblArcNm)
  
          endTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
          duration = (((format.parse(endTime).getTime - format.parse(startTime).getTime).toString()).toInt / 1000).toString()
          logger.info("Archiving of " + errTblNm + " for " + partitionWindow + " days took " + duration + " seconds")
        } else {
          logger.warn("No new partitions found to be archived in err table!")
        }
      }else{
        logger.warn("Not archiving err table as isErrorArchived argument is not passed or set to N")
      }

    } catch {
      case sslException: InterruptedException => {
        logger.error("Interrupted Exception")
        sys.exit(1)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        sys.exit(1)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        sys.exit(1)
      }
      case exception: Exception => {
        logger.error(exception.printStackTrace())
        sys.exit(1)
      }
    }
  }
}
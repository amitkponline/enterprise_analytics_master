package com.hpe.driver

import com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import com.hpe.utils._
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import java.util.ArrayList
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import scala.io.Source
import scala.collection.mutable.ListBuffer

object job_EA_loadConfigFile {

  val logger = Logger.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    println("##### EAP Load config files Program:")
    if (args == null || args.isEmpty) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Properties file path>  ")
      println("Stopping the flow")
      System.exit(1)
    }
    val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
    var spark = configObject.getSpark()
    val propertiesFilePath = String.valueOf(args(0).trim())
    val sharedConfigObjectProperties: SharedConfigObjectProperties = Utilities.getsharedConfigObjectProperties(propertiesFilePath)
    val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
    val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
    val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
    val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
    //logger.info("Mysql password access test: "+envPropertiesObject.mySqlPassword)
    var sqlCon: Connection = null
    val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
    var auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

    try {
      var spark = configObject.getSpark()
      val spark2 = spark
      import spark2.implicits._
      val startTime = com.hpe.utils.Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
      sqlCon = Utilities.getConnection(envPropertiesObject)
      var objList: List[String] = Utilities.readObjectList(sqlCon)
      sqlCon.close()
      val length = objList.length

      var err = "N"
      if (length != 0) {
        logger.info(" The Number of the objects to be loaded in current batch :: " + length)
        logger.info(" The list of the objects to be loaded :: " + objList)
        for (x <- objList) {
          var confSQL: ArrayList[String] = null
          try {
            logger.info("Data loading for object : " + x + " started successfully ")
            val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            val startTime = com.hpe.utils.Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss") //Make it same as startTime
            sqlCon = Utilities.getConnection(envPropertiesObject)
            var confSQLAll: List[ArrayList[String]] = Utilities.ConfSQLRead(sqlCon, x)
            sqlCon.close()

            logger.info("Number of queries to be processed::::" + confSQLAll.size)
            for (i <- 0 to confSQLAll.size - 1) {
              confSQL = confSQLAll(i)
              sqlCon = Utilities.getConnection(envPropertiesObject)
              var audSQL: List[String] = Utilities.AudSQLRead(sqlCon, x)
              sqlCon.close()
              var sys_btch_nr = audSQL(0) //sys_btch_nr 1st is EA_****  (sys_btch_nr) = ld_jb_nr
              var ld_jb_nr = sys_btch_nr //Same here ^^^
              var auditBatchId = audSQL(0) + "_" + Utilities.getCurrentTimestamp("yyyyMMddHHmmssSSS")
              val jb_nm = spark.sparkContext.appName
              var objectName = x
              var src_tbl = confSQL.get(0) //confSQL 1st is source table name(src_tbl_nm) i.e- staging table name
              var src_sys_ky = confSQL.get(1) //confSQL 2nd is source system key(src_sys_ky) i.e- 1,2,3.....
              var fl_nm = confSQL.get(2) //confSQL 3rd is file name(cnfg_fl_nm) i.e- Account_Type.txt,TVRK.txt etc
              var tgt_tbl_nm = confSQL.get(3) //confSQL 4th is Target table name(tgt_tbl_nm) i.e- rw table name here
              var ld_qery = confSQL.get(4) //confSQL 5th is load query (ld_qery) or select part of insert query for hive table
              var join_query = confSQL.get(5) //confSQL 6th is joining conditions (join_query)
              var ld_ord = confSQL.get(6)
              logger.info("Load order is::" + ld_ord)
              var schema = sharedConfigObjectProperties.getSchemaName()
              logger.info("Schema###########" + schema)

              auditObj.setAudBatchId(auditBatchId)
              auditObj.setAudApplicationName(jb_nm)
              auditObj.setAudObjectName(objectName)

              auditObj.setAudCreatedBy(configObject.spark.sparkContext.sparkUser)
              auditObj.setSysBtchNr(sys_btch_nr)

              auditObj.setAudErrorRecords(0)
              if (Option(join_query).getOrElse("").isEmpty) {
                join_query = src_tbl
              }
              var endTs: String = ""
              if (ld_ord.toInt == 1) {
                logger.info("##############Raw load starts##################")
                val count_query = "select count(*) from " + schema + "." + src_tbl
                var count = spark.sql(count_query).first().get(0).toString.toInt
                logger.info("	Count of records of Object : " + x + " is = " + count)
                auditObj.setAudSrcRowCount(count)
                auditObj.setAudTgtRowCount(count)
                auditObj.setAudDataLayerName("stg_rw") //Different for refined
                auditObj.setAudJobStartTimeStamp(startTime) //Different for refined
                auditObj.setAudLoadTimeStamp(startTime) //Different for refined
                auditObj.setFlNm(fl_nm) //Different for refined
                var InsertQueryRW = "insert overwrite table " + schema + "." + tgt_tbl_nm + " select " + ld_qery + ",'" + startTime + "'," + src_sys_ky + "," + "'N'" + ",'" + startTime + "','" + startTime + "','" + startTime + "','" + src_sys_ky + "','" + fl_nm + "','" + auditBatchId + "' from " + schema + "." + join_query
                logger.info("Dynamic query for object : " + x + " : Raw layer : " + InsertQueryRW)
                spark.sql(InsertQueryRW)
                var endTs = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
                var ConfigUpdateQuery = "update amc.cnfg_obj_prpt_tbl set ld_status = 'success' , jb_strt_ts = '" + startTime + "', jb_end_ts = '" + endTs + "'  where tgt_tbl_nm  = '" + tgt_tbl_nm + "'"
                sqlCon = Utilities.getConnection(envPropertiesObject)
                Utilities.insertIntoConfigAudit(sqlCon, ConfigUpdateQuery)
                sqlCon.close()

                auditObj.setAudJobStatusCode("success")
                auditObj.setAudJobEndTimestamp(endTs)
                auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
                sqlCon = Utilities.getConnection(envPropertiesObject)
                Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
                sqlCon.close()

                logger.info("##############Raw load ends##################")
              } else if (ld_ord.toInt == 2) {

                logger.info("##############Refined load starts##################")
                /*val count_query = "select count(*) from " + schema + "." + src_tbl
                var count = spark.sql(count_query).first().get(0).toString.toInt
                logger.info("	Count of records of Object : " + x + " is = " + count)
                auditObj.setAudSrcRowCount(count)
                auditObj.setAudTgtRowCount(count)*/
                sqlCon = Utilities.getConnection(envPropertiesObject)
                //var confSQLRef: ArrayList[String] = Utilities.ConfSQLReadRef(sqlCon, x)
                sqlCon.close()
                src_sys_ky = confSQL.get(1) //confSQL 2nd is source system key(src_sys_ky) i.e- 1,2,3.....
                fl_nm = confSQL.get(2) //confSQL 3rd is file name(cnfg_fl_nm) i.e- Account_Type.txt,TVRK.txt etc
                tgt_tbl_nm = confSQL.get(3) //confSQL 4th is Target table name(tgt_tbl_nm) i.e- rw table name here
                ld_qery = confSQL.get(4) //confSQL 5th is load query (ld_qery) or select part of insert query for hive table
                join_query = confSQL.get(5)
                auditObj.setAudDataLayerName("rw_ref")
                auditObj.setAudJobStartTimeStamp(startTime)
                auditObj.setAudLoadTimeStamp(startTime)
                auditObj.setFlNm(fl_nm)
                if (Option(join_query).getOrElse("").isEmpty) {
                  join_query = src_tbl
                }
                endTs = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
                val regex = " join ".r
                val joinQuerySchema = regex.replaceAllIn(join_query.replaceAll("\\s{2,}", " ").trim(), " join " + " " + schema + ".")
                val InsertQueryRef = "insert overwrite table " + schema + "." + tgt_tbl_nm + " select " + ld_qery + ",'" + startTime + "'," + src_sys_ky + "," + "'N'" + ",'" + startTime + "','" + startTime + "','" + startTime + "','" + src_sys_ky + "','" + fl_nm + "','" + auditBatchId + "' from  " + schema + "." + joinQuerySchema
                logger.info("Dynamic query for object : " + x + " : Refined layer : " + InsertQueryRef)
                var ConfigUpdateQueryRef = "update amc.cnfg_obj_prpt_tbl set ld_status = 'success' , jb_strt_ts = '" + startTime + "', jb_end_ts = '" + endTs + "'  where tgt_tbl_nm  = '" + tgt_tbl_nm + "'"
                spark.sql(InsertQueryRef)
                sqlCon = Utilities.getConnection(envPropertiesObject)
                Utilities.insertIntoConfigAudit(sqlCon, ConfigUpdateQueryRef)
                sqlCon.close()
                auditObj.setAudJobStatusCode("success")
                auditObj.setAudJobEndTimestamp(endTs)
                auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
                sqlCon = Utilities.getConnection(envPropertiesObject)
                Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
                sqlCon.close()

                logger.info("##############Refine load ends##################")
              } else if (ld_ord.toInt == 3) {
                logger.info("##############Dimension load starts##################")
                val count_query = "select count(*) from " + schema + "." + src_tbl
                var count = spark.sql(count_query).first().get(0).toString.toInt
                logger.info("	Count of records of Object : " + x + " is = " + count)
                auditObj.setAudSrcRowCount(count)
                auditObj.setAudTgtRowCount(count)
                auditObj.setAudDataLayerName("ref_cnsmpn")
                auditObj.setAudJobStartTimeStamp(startTime)
                auditObj.setAudLoadTimeStamp(startTime)
                auditObj.setFlNm(fl_nm)

                var InsertQueryDmnsn = "insert overwrite table " + schema + "." + tgt_tbl_nm + " select " + ld_qery + ",'" + startTime + "'," + src_sys_ky + "," + "'N'" + ",'" + startTime + "','" + startTime + "','" + startTime + "','" + src_sys_ky + "','" + fl_nm + "','" + auditBatchId + "' from " + schema + "." + join_query
                logger.info("Dynamic query for object : " + x + " : Dimension layer : " + InsertQueryDmnsn)
                spark.sql(InsertQueryDmnsn)
                var endTs = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
                var ConfigUpdateQuery = "update amc.cnfg_obj_prpt_tbl set ld_status = 'success' , jb_strt_ts = '" + startTime + "', jb_end_ts = '" + endTs + "'  where tgt_tbl_nm  = '" + tgt_tbl_nm + "'"
                sqlCon = Utilities.getConnection(envPropertiesObject)
                Utilities.insertIntoConfigAudit(sqlCon, ConfigUpdateQuery)
                sqlCon.close()
                auditObj.setAudJobStatusCode("success")
                auditObj.setAudJobEndTimestamp(endTs)
                auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
                sqlCon = Utilities.getConnection(envPropertiesObject)
                Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
                sqlCon.close()
                logger.info("##############Dimension load ends##################")
              }
            }
            logger.info("Data loading for object : " + x + " : Completed Successfully ")

          } catch {
            case e: Exception =>
              logger.info("Exception::" + e.printStackTrace())
              err = "Y"
          }
          if (err == "Y") {
            var endTs = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
            sqlCon = Utilities.getConnection(envPropertiesObject)
            //var confSQL: ArrayList[String] = Utilities.ConfSQLReadRw(sqlCon, x)
            sqlCon.close()
            var tgt_tbl_nm = confSQL.get(3)
            var ConfigUpdateQuery = "update amc.cnfg_obj_prpt_tbl set ld_status = 'failed' , jb_strt_ts = '" + startTime + "', jb_end_ts = '" + endTs + "'  where tgt_tbl_nm  = '" + tgt_tbl_nm + "'"
            sqlCon = Utilities.getConnection(envPropertiesObject)
            Utilities.insertIntoConfigAudit(sqlCon, ConfigUpdateQuery)
            sqlCon.close()
            auditObj.setAudJobStatusCode("failed")
            auditObj.setAudJobEndTimestamp(endTs)
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            sqlCon = Utilities.getConnection(envPropertiesObject)
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            sqlCon.close()
          }
        }
      } else {
        logger.info("No objects loaded in current Batch:::::End of Program")
      }
    } catch {
      case sslException: InterruptedException => {
        logger.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        sqlCon = Utilities.getConnection(envPropertiesObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        sqlCon = Utilities.getConnection(envPropertiesObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        sqlCon = Utilities.getConnection(envPropertiesObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case connException: ConnectException => {
        logger.error("Connection Exception: " + connException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        sqlCon = Utilities.getConnection(envPropertiesObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case exception: Exception => {
        logger.error(exception.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        //Check if SQL connection is active
        sqlCon = Utilities.getConnection(envPropertiesObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
    } finally {
      if (sqlCon != null) {
        sqlCon.close()
      }
    }
  }
}
package com.hpe.driver

import com.hpe.utils.Utilities
import org.apache.log4j.Logger
import com.hpe.config.SetUpConfigurationNonStreaming
import com.hpe.config.ConfigObjectNonStreaming
import scala.collection.JavaConversions._
import org.apache.log4j.Logger
import com.hpe.config._
import com.hpe.utils.Utilities
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType}
import org.apache.spark.sql.types.TimestampType

object SqlToHiveDataMigration {
  val logger = Logger.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Properties file path>")
      println("Stopping the flow")
      System.exit(1)
    }
    val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
    val propertiesFilePath = String.valueOf(args(0).trim())
    val targetTabl = String.valueOf(args(1).trim())
    val audTbl     = String.valueOf(args(2).trim())
    val saveMod    = String.valueOf(args(3).trim())
    val envPropertiesFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"connection.properties"
        val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
    val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
    val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
    var sqlConTemp = Utilities.getConnection(envPropertiesObject)
    val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
   
   import org.apache.spark.sql.SQLContext
   val spark = configObject.getSpark()
   val sqlcontext = new org.apache.spark.sql.SQLContext(spark.sparkContext)
	 
	 Class.forName("com.mysql.jdbc.Driver");
   
   val sql="""select * from """+audTbl
	 
   logger.info("::::::::::::::Establishing connection to Mysql and fetching Records:::::::::::::::")
   
   val host = envPropertiesObject.getMySqlHostName()
   val port = envPropertiesObject.getMySqlPort()
   val username = envPropertiesObject.getMySqlUserName()
   val password = envPropertiesObject.getMySqlPassword()
   val dbName = envPropertiesObject.getMySqlDBName()

   val url:String = "jdbc:mysql://" + host + ":" + port + "/" + dbName
    
	 val dataframe_mysql = sqlcontext.read.format("jdbc").option("url",url).option("driver", "com.mysql.jdbc.Driver").option("dbtable",s"($sql)t").option("user",username).option("password", password).load()
   
	 dataframe_mysql.show(false)
	 
	 val dmnsn_tbl_schema = (new StructType).add("btch_id", StringType).add("appl_nm", StringType).add("obj_nm", StringType).add("dta_lyr_nm", StringType).add("jb_stts_cd", StringType).add("jb_cmpltn_ts", TimestampType).add("ld_ts", TimestampType).add("src_rec_qty", LongType).add("tgt_rec_qty", LongType).add("err_rec_qty", LongType).add("crtd_by_nm", StringType).add("jb_strt_ts", TimestampType).add("jb_durtn_tm_ss", LongType).add("fl_nm", StringType).add("sys_btch_nr", StringType)
	 
	 val dmnsn_tbl_rdd = dataframe_mysql.rdd
	 
	 var loadingDF = spark.createDataFrame(dmnsn_tbl_rdd, dmnsn_tbl_schema)
	 
	 logger.info(":::::::::Target Table :- "+targetTabl)
	
	 //loadingDF.printSchema()
	 	             	 
	 val loadStatus = Utilities.storeDataFrame(loadingDF, saveMod, "ORC", targetTabl)
   
	 var record_count = loadingDF.count()
          
   if(loadStatus){
    logger.info("::::::::::::::Load completed to Audit Dimension Table::::::::::::::--->Total Record:- "+record_count)
   }
   else{
     logger.info("::::::::::::::JOb Failed , Check log for more details::::::::::::::::")
   }
     
  }
}
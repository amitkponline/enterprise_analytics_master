package com.hpe.driver

import com.hpe.config.PropertiesObject
import com.hpe.utils.Utilities
import com.hpe.config.ConfigObject
import com.hpe.config.SetUpConfiguration
import org.apache.log4j.Logger
import com.hpe.config.SetUpConfigurationNonStreaming
import com.hpe.config.ConfigObjectNonStreaming
import java.util.HashMap
import scala.collection.Map
import com.hpe.config.SQLPropertiesObject
import java.sql.Connection
import scala.collection.JavaConversions._

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{ desc, lit, col, concat, concat_ws, split, struct, lower, upper, count, max, row_number, size, coalesce }
import org.apache.spark.sql.catalyst.expressions.Explode
import org.apache.spark.sql.types.{ StructType, StructField, StringType };
import org.apache.spark.rdd.RDD

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.types.LongType
import com.hpe.config._
import com.hpe.config.PropertiesObject
import com.hpe.utils.Utilities
import com.hpe.utils.DataQuality
import java.sql.Connection
import java.sql.Date

import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.Row
//import org.apache.avro.generic.GenericData.Array
import org.apache.spark.sql.functions.regexp_replace
import com.hpe.finance.FileProcessor
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import sys.process._
import org.apache.spark.sql.functions.callUDF
import org.apache.spark.sql.functions.input_file_name
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable.ArrayBuffer

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import scala.collection.mutable.ListBuffer
import com.hpe.processor._

object GenericFileToREF {
  val log = Logger.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty) {
      log.error("Invalid number of arguments passed.")
      log.error("Arguments Usage: <Waiting Window in seconds> <consumer-group> <OffsetReset> <Properties file path> <Optional arg: Kafka Topic List>")
      log.warn("Stopping the flow")
      System.exit(1)
    }
    val propertiesFilePath = String.valueOf(args(0).trim())
    val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss") //String.valueOf(args(1).trim())

    var propertiesObject: PropertiesObject = Utilities.getPropertiesobject(propertiesFilePath)
    val configurationObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
    val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
    val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
    val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
    val sqlPropertyObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
    val sqlCon = Utilities.getConnection(sqlPropertyObject)
    val auditTbl = sqlPropertyObject.getMySqlDBName() + "." + sqlPropertyObject.getMySqlAuditTbl()

    val sparkSession = configurationObject.getSpark()
    import sparkSession.implicits._
    var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val date: Date = null;

    var sourceSystem = propertiesObject.getSourceSystem()
    val reportDtTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
    val errDir = propertiesObject.getErrorDir()
    val sendMailSMTPHost = propertiesObject.getSendMailSMTPHost()
    val toemail = propertiesObject.getSendMailTo() //Default email in case a object is not configured
    val fromemail = propertiesObject.getSendMailFrom()
    var funcReturn: Boolean = true
    val archiveDir = propertiesObject.getArchiveDir()
    val fileToObjectMap = propertiesObject.getFileToObjNmMap()
    val srcFilePattern = propertiesObject.getSrcFilePattern()
    try {

      auditObj.setAudApplicationName("job_EA_loadConfigFile")
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudDataLayerName("file_stg")
      auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(0)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configurationObject.getSpark().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr("EA-EAI")

      /*Dynamic code handling*/
      log.info("!!!!Starting load for the source System :- " + sourceSystem)

      //val fileListToRead = sparkSession.read.format("csv").option("header", "true").option("delimiter", ",").load(propertiesObject.getSourceFilePath() + "*")
      val fileListToRead = sparkSession.sparkContext.textFile(propertiesObject.getSourceFilePath() + "*").toDF
      sparkSession.udf.register("get_file_name", (path: String) => path.split(" ").last)
      val fileNamelist1 = fileListToRead.withColumn("fileName", callUDF("get_file_name", input_file_name()))
      val fileNamelist2 = fileNamelist1.select(fileNamelist1("fileName")).distinct
      val fileNamelist = fileNamelist2.select("fileName").rdd.map(r => r(0)).collect()

      var x = ' '
      for (x <- fileNamelist) {
        var fl_nm = ((x + "").split("/").last)
        var fileNamewithpath = ((x + ""))

        log.info(":::::::::::::::::File to be processed:::::::::::::::= " + fileNamewithpath)

        var fl_nm_patr = fl_nm.split('.')(0)
        var obj_nm = " "
        var fl_nmchk = " "
        // Looking the object name dynamically if this is a BMT object with Mysql COnfiguration.
        if (fileToObjectMap != null && fileToObjectMap.length() > 0) {
          if (srcFilePattern != null && srcFilePattern.length() > 0) {
            for (patrn <- srcFilePattern.split("\\|")) {
              //code to get the file Pattern
              fl_nmchk = fl_nm.toLowerCase()
              var patrn_chk = patrn.toLowerCase()
              if (propertiesObject.getIsPositional() != null && propertiesObject.getIsPositional().size != 0 && propertiesObject.getStrtIndx() != null && propertiesObject.getStrtIndx().size != 0) {
                fl_nmchk = fl_nmchk.substring(propertiesObject.getStrtIndx().toInt, propertiesObject.getEndIndx().toInt)
                log.info("fl_nm after substring- " + fl_nmchk + "Start Indx:-" + propertiesObject.getStrtIndx().toInt + "end Indx:-" + propertiesObject.getEndIndx().toInt)
              }
              if (fl_nmchk.contains(patrn_chk)) {
                fl_nm_patr = patrn_chk
              }
            }
          } else {
            val numPatrn = "[0-9]+".r

            var matches = numPatrn.findAllIn(fl_nm_patr).toArray

            while (matches.size > 0 & fl_nm_patr.contains("_")) {
              var index = fl_nm_patr.lastIndexOf("_")
              fl_nm_patr = fl_nm_patr.substring(0, index)
              matches = numPatrn.findAllIn(fl_nm_patr).toArray
            }
          }
          // Join to the file name to Object name mapping table to fetch object name filter out the timestamp part from file
          if (fl_nm_patr != null && fl_nm_patr.length() > 0) {
            //obj_nm = sparkSession.sql(s"""select obj_nm from """+fileToObjectMap+""" where fl_nm like'"""+fl_nm_patr+"""'""").first().get(0).toString()
            obj_nm = sparkSession.sql(s"""select obj_nm from """ + fileToObjectMap + """ where lower(fl_nm) like lower('""" + fl_nm_patr + """')""").first().get(0).toString()
            log.info("object Name derived : " + obj_nm + "property file path :- " + propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + obj_nm + ".properties")
          }
          if (obj_nm != null && obj_nm != "") {
            propertiesObject = Utilities.getPropertiesobject(propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + obj_nm + ".properties")
          }
        } else {
          obj_nm = propertiesObject.getObjName()
          log.info("object Name : " + obj_nm)
        }
        if (obj_nm != null && obj_nm != "") {
          //val propertiesObject: PropertiesObject = Utilities.getPropertiesobject(propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+obj_nm+".properties")
          val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
          val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
          val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
          val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)

          var errTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblErr()
          var rwTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRw()
          var refTblNm = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef()
          var commonErrTblNm = propertiesObject.getDbName() + "." + propertiesObject.getCommonErrTblNm()

          var repartitionNo: Int = 1
          if (propertiesObject.getRepartitionNo() != null && propertiesObject.getRepartitionNo().length() > 0) {
            repartitionNo = propertiesObject.getRepartitionNo().toInt
          }

          val toemail = propertiesObject.getSendMailTo() // User email Id
          val fromemail = propertiesObject.getSendMailFrom()
          var rwTblSaveMode = "Append"
          var refTblSaveMode = "Append"
          var multilineOption = "false"
          var quotes = ""
          var hederMatchReqd = "Y"

          if (propertiesObject.getRwTblSaveMode() != null && propertiesObject.getRwTblSaveMode().size != 0) {
            rwTblSaveMode = propertiesObject.getRwTblSaveMode()
          }
          if (propertiesObject.getRefTblSaveMode() != null && propertiesObject.getRefTblSaveMode().size != 0) {
            refTblSaveMode = propertiesObject.getRefTblSaveMode()
          }
          if (propertiesObject.getMultilineOption() != null && propertiesObject.getMultilineOption().size != 0) {
            multilineOption = propertiesObject.getMultilineOption()
          }
          if (propertiesObject.getQuotes() != null && propertiesObject.getQuotes().size != 0) {
            quotes = """""""
          }
          if (propertiesObject.getHederMatchReqd() != null && propertiesObject.getHederMatchReqd().size != 0) {
            hederMatchReqd = propertiesObject.getHederMatchReqd()
          }

          auditObj.setAudApplicationName("job_EA_loadConfigFile")
          auditObj.setAudObjectName(propertiesObject.getObjName())
          auditObj.setAudDataLayerName("file_stg")
          auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudSrcRowCount(0)
          auditObj.setAudTgtRowCount(0)
          auditObj.setAudErrorRecords(0)
          auditObj.setAudCreatedBy(configurationObject.getSpark().sparkContext.sparkUser)
          auditObj.setFlNm("")
          auditObj.setSysBtchNr(ld_jb_nr)

          var batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

          var auditBatchId = ld_jb_nr + "_" + batchId

          auditObj.setAudBatchId(auditBatchId)

          auditObj.setFlNm(fl_nm)

          var df = SparkSession.builder().getOrCreate().emptyDataFrame

          if (propertiesObject.getQuotes() != null && propertiesObject.getQuotes().size != 0) {
            log.info("Readng file by enabling quotes :- " + quotes)
            df = sparkSession.read.format("csv").option("header", "true").option("delimiter", propertiesObject.getMsgdelimeter()).option("multiLine", multilineOption).option("quote", quotes).option("escape", quotes).load(fileNamewithpath) //For Files with quotes in data
          } else if (propertiesObject.getIsPositional() != null && propertiesObject.getIsPositional().size != 0) { // For positional
            //df = sparkSession.read.format("csv").load(fileNamewithpath) //For Files with quotes in data
            df = sparkSession.sparkContext.textFile(fileNamewithpath).toDF()

          } else {
            df = sparkSession.read.format("csv").option("header", "true").option("delimiter", propertiesObject.getMsgdelimeter()).option("multiLine", multilineOption).load(fileNamewithpath)
          }
          var src_count = df.count
          val fl_src_cnt = src_count // It will be used in Email Notification.
          if (src_count > 0) {

            val fileHiveMapping = propertiesObject.getHiveJsonRawMap().split(";")
            var hiveCols: ArrayBuffer[String] = ArrayBuffer[String]()
            var fileHeaders: ArrayBuffer[String] = ArrayBuffer[String]()
            // var colList: Array[String] = Array[String]()
            var colList: ArrayBuffer[String] = ArrayBuffer[String]()
            fileHiveMapping.foreach { x =>
              fileHeaders += (x.split("\\|")(0))
              hiveCols += (x.split("\\|")(1))
            }

            var expFileHeader = fileHeaders.mkString(",")
            var hiveCollist = " "
            var fileHeaderList = " "
            var actFileHeader = " "
            var isHeaderMatched: Boolean = true
            if (propertiesObject.getIsPositional() != null && propertiesObject.getIsPositional().size != 0) {
              hederMatchReqd = "N"
              log.info("Performing Positional File Load:-")
              //Write code for positional file
              val headerLength = propertiesObject.getHeaderLength().split(",").toList.map(ele => ele.toInt)
              val dataLength = propertiesObject.getDataLength().split(",").toList.map(ele => ele.toInt)
              val trailerLength = propertiesObject.getTrailerLength().split(",").toList.map(ele => ele.toInt)

              //var dropheadtail = df.take(src_count.toInt).drop(1).dropRight(1).map(ele=>ele.toString())
              var dropheadtail = df.take(src_count.toInt).drop(1).dropRight(1).map(ele => ele.toString().replace("[", "").replace("]", ""))
              //var header       = df.take(src_count.toInt).take(1).map(ele=>ele.toString())
              var header = df.take(src_count.toInt).take(1).map(ele => ele.toString().replace("[", "").replace("]", ""))
              //var footer       = df.take(src_count.toInt).takeRight(1).map(ele=>ele.toString())
              var footer = df.take(src_count.toInt).takeRight(1).map(ele => ele.toString().replace("[", "").replace("]", ""))
              log.info("body head tail determined")
              //dropheadtail= dropheadtail.distinct //Removing duplicates.

              val head_lengthsum = headerLength.sum
              val data_lengthsum = dataLength.sum
              val tail_lengthsum = trailerLength.sum

              //log.info("Before Padding:-"+dropheadtail(1))

              //Calling Space padding utilities.
              Utilities.pademptyvalues(dropheadtail, data_lengthsum)
              Utilities.pademptyvalues(header, head_lengthsum)
              Utilities.pademptyvalues(footer, tail_lengthsum)
              log.info("pademptyvalues")
              //log.info("After Padding:-"+dropheadtail(1))

              val header_val = "@~@" + Utilities.splitstring(headerLength, header.mkString)
              val footer_val = "@~@" + Utilities.splitstring(trailerLength, footer.mkString)
              log.info("header footer split")
              var outputList = new ListBuffer[String]()
              dropheadtail.foreach(i => {

                var res: String = Utilities.splitstring(dataLength, i.toString())
                //log.info("Result set:-"+res)

                outputList += (res.concat(header_val).concat(footer_val))
                //log.info("Output list:-"+outputList)
              }) //End of for each
              log.info("#########outputList fetched##############")
              var list = outputList.toList
              //log.info("Printing the List content")
              //for(x<-list)
              //log.info(x)
              //list.foreach(log.info())

              val rdd = sparkSession.sparkContext.parallelize(list)
              val df1 = rdd.map(ele => ele.split("@~@")).toDF()
              log.info("###########split done#########")
              val ncols = dataLength.length + headerLength.length + trailerLength.length
              //val selectCols = (0 until  ncols).map(i => $"value"(i).as(s"col_$i"))
              var Number_of_cols = fileHeaders.toList.size
              //log.info("Number_of_cols:-"+Number_of_cols)
              //log.info("header_val:-"+header_val)
              //log.info("footer_val:-"+footer_val)

              val selectCols = (0 until Number_of_cols).map(i => $"value"(i).as(fileHeaders.toList(i)))
              df = df1.select(selectCols: _*)
              colList = ArrayBuffer(df.columns: _*)
              //df.show(false)
            } else {
              log.info(":::::::::::::::::Expected File Headers:::::::::::::::=" + expFileHeader)

              df = df.columns.foldLeft(df) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(".", "_").replace("-", "_").replace("%", "_").replace("@", "").replace("(", "").replace(")", "").replace("#", "").replace("?", "").replace("[", "").replace("]", "").replace("|", "").replace("/", "").replace(":", "").replaceAll("^\"|\"$", "")) }
              df.createOrReplaceTempView("Stg_Temp_DF")
              colList = ArrayBuffer(df.columns: _*)

              actFileHeader = colList.mkString(",")

              log.info(":::::::::::::::::Actual File Headers:::::::::::::::=" + actFileHeader)

              isHeaderMatched = Utilities.validateHeader(colList, fileHeaders)

              log.info(":::::::::::::::::::Is header matched with target:::::::::::::::::::=" + isHeaderMatched)

              hiveCollist = hiveCols.mkString(propertiesObject.getMsgdelimeter())
              fileHeaderList = fileHeaders.mkString(",")
              //var queryTest  = "select "+ fileHeaderList +" from Stg_Temp_DF"
            }
            if (isHeaderMatched || hederMatchReqd == "N") {

              df.createOrReplaceTempView("Stg_Tmp")

              var sql = Utilities.prepareQuery(colList, propertiesObject.getColNm(), propertiesObject.getCustomBooleanFields())

              sql = sql.replaceAll("FROM Stg_Tmp", ",'' as intgtn_fbrc_msg_id,'' AS src_sys_upd_ts, '" + src_sys_ky + "' as src_sys_ky, '' AS lgcl_dlt_ind,  current_timestamp() AS ins_gmt_ts, '' AS upd_gmt_ts, '' AS src_sys_extrc_gmt_ts,'' AS src_sys_btch_nr, '" + fl_nm + "'  AS fl_nm, '" + auditBatchId + "' AS ld_jb_nr , date(current_timestamp) AS ins_gmt_dt FROM Stg_Tmp")

              val dbName = propertiesObject.getDbName()

              val tgtTable = propertiesObject.getTgtTblStg()

              var hiveColList = sparkSession.sql(f"""select * from ${dbName}.${tgtTable} limit 1""").columns

              var final_DF = sparkSession.sql(sql)
              var dup_rec_pk_select_df = sparkSession.emptyDataFrame

              final_DF.createOrReplaceTempView("regex_Temp_DF")

              //Applying any regex or other operation required on columns

              if (propertiesObject.getRegexQuery() != null && propertiesObject.getRegexQuery().size != 0) {
                //final_DF = sparkSession.sqlContext.sql(f"""select """+ propertiesObject.getRegexQuery() +""",intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_gmt_dt from regex_Temp_DF""")
                final_DF = sparkSession.sqlContext.sql(f"""select """ + propertiesObject.getRegexQuery() + """,intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_gmt_dt from regex_Temp_DF """ + propertiesObject.getLateralView())
              }

              //final_DF.show(false)

              var stg_DF = final_DF.select(hiveColList.map(col): _*)

              var loadStatus = Utilities.storeDataFrame(stg_DF, "overwrite", "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblStg())
              var tgt_count = src_count

              if (loadStatus) {
                auditObj.setAudJobStatusCode("success")
                auditObj.setAudTgtRowCount(tgt_count)
              } else {
                auditObj.setAudJobStatusCode("failed")
                auditObj.setAudTgtRowCount(0)
              }

              auditObj.setAudDataLayerName("file_stg")

              auditObj.setAudSrcRowCount(src_count)

              auditObj.setAudErrorRecords(0)

              auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

              auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudDataLayerName("stg_rw")

              log.info("@@@@@@@@@@@@@@@@@ Stage Loaded Successfully @@@@@@@@@@@@@@@@@@@@@@@@@@@")

              // ************** Primary Key check starts. **********************************

              var reject_rec_Df = SparkSession.builder().getOrCreate().emptyDataFrame
              var null_rec_df = SparkSession.builder().getOrCreate().emptyDataFrame
              var notnull_df = SparkSession.builder().getOrCreate().emptyDataFrame
              var pk_df = SparkSession.builder().getOrCreate().emptyDataFrame
              if (propertiesObject.getPrimaryKeyColList() != null && propertiesObject.getPrimaryKeyColList().size != 0) {
                val pkcolumns = propertiesObject.getPrimaryKeyColList.split(",").toSeq
                //val pk_df= final_DF.withColumn("primarykey",concat(pkcolumns.map(c => col(c.toString())): _*)).persist(StorageLevel.MEMORY_AND_DISK_SER)

                if (propertiesObject.getPkNullChkReqd() != "N") {
                  log.info("Null check for the primary key columns will be done.")
                  pk_df = final_DF.withColumn("primarykey", concat(pkcolumns.map(c => col(c.toString())): _*)).persist(StorageLevel.MEMORY_AND_DISK_SER)
                  null_rec_df = pk_df.filter(pk_df.col("primarykey").isNull).withColumn("err_msg_cd", lit("Primary Key check Failed ,Null value in Primary Key columns")).withColumn("err_cd", lit("100")).drop("primarykey")
                  notnull_df = pk_df.filter(pk_df.col("primarykey").isNotNull).persist(StorageLevel.MEMORY_AND_DISK_SER)
                } else {
                  log.info("Null check skipped for the primary key columns As PkNullChkReqd is:-" + propertiesObject.getPkNullChkReqd())
                  notnull_df = final_DF.withColumn("primarykey", concat(pkcolumns.map(c => coalesce(col(c), lit(1).cast(StringType))): _*)).persist(StorageLevel.MEMORY_AND_DISK_SER)
                }

                // val nameWindow = Window.partitionBy("primarykey")
                val nameWindow = Window.partitionBy("primarykey").orderBy(desc("primarykey"))

                //val dup_check  = notnull_df.withColumn("count", count(lit(1)).over(nameWindow)).repartition(1)

                val dup_check = notnull_df.withColumn("count", row_number() over nameWindow)

                // Updated on 27th July val dup_rec_df=dup_check.withColumn("err_msg_cd", lit("Primary Key check Failed ,duplicate Record Found")).withColumn("err_cd", lit("100")).where(col("count")>1).drop("count").drop("primarykey")

                val dup_rec_pk_df = dup_check.withColumn("err_msg_cd", lit("Primary Key check Failed ,duplicate Record Found")).withColumn("err_cd", lit("100")).where(col("count") > 1).drop("count")

                if (commonErrTblNm != null && commonErrTblNm.size != 0 && propertiesObject.getIsPositional() != null && propertiesObject.getIsPositional().size != 0) {

                  dup_rec_pk_df.createOrReplaceTempView("dup_rec_pk_tmp_tbl")
                  dup_rec_pk_select_df = sparkSession.sql("SELECT primarykey AS record,'" + obj_nm + "' AS obj_nm,fl_nm AS fl_nm,ins_gmt_ts as ld_ts,err_cd,err_msg_cd as err_msg,ld_jb_nr from dup_rec_pk_tmp_tbl")
                  sparkSession.catalog.dropTempView("dup_rec_pk_tmp_tbl")

                }
                val dup_rec_df = dup_rec_pk_df.drop("primarykey")
                final_DF = dup_check.where(col("count") <= 1).drop("count").drop("primarykey")

                if (null_rec_df.count() > 0 & dup_rec_df.count() > 0)
                  reject_rec_Df = null_rec_df.unionAll(dup_rec_df)
                else if (dup_rec_df.count() > 0)
                  reject_rec_Df = dup_rec_df
                else
                  reject_rec_Df = null_rec_df
                //log.info("Primary Key check reject DF:-")
                //reject_rec_Df.show(false)
                // *********************Primary key check ends.******************************

                //********************* Reference key check Starts.******************************
                if (propertiesObject.getTgtReferenceKeyColList() != null && propertiesObject.getSrcReferenceKeyColList() != null && propertiesObject.getTgtReferenceKeyColList().size != 0
                  && propertiesObject.getSrcReferenceKeyColList().size != 0) {

                  val srcrefkey = propertiesObject.getSrcReferenceKeyColList.split(",").toSeq

                  final_DF = final_DF.withColumn("primarykey", concat(srcrefkey.map(c => col(c.toString())): _*))

                  var foreingKy = propertiesObject.getTgtReferenceKeyColList()

                  var tgtReferenceKeyColList = foreingKy.split("\\|")(0).toString()
                  var trgt_table = foreingKy.split("\\|")(1).toString()

                  //print("tgtReferenceKeyColList"+tgtReferenceKeyColList)
                  //print("trgt_table"+trgt_table)

                  val fk_df = sparkSession.sql("select " + tgtReferenceKeyColList + "," + "concat(" + tgtReferenceKeyColList + ") as refkey from " + trgt_table)

                  val succ_df = final_DF.as("d1").join(fk_df.as("d2"), $"d1.primarykey" === $"d2.refkey", "left").select(col("d1.*"), col("d2.refkey"))

                  val fk_nulls_df = succ_df.filter(succ_df.col("refkey").isNull).withColumn("err_msg_cd", lit("Foreign Key Check Failed")).withColumn("err_cd", lit("100")).drop("refkey").drop("primarykey")

                  //log.info("foreignKey check DF:")
                  //fk_nulls_df.show(false)

                  if (fk_nulls_df.count() > 0) {
                    reject_rec_Df = reject_rec_Df.unionAll(fk_nulls_df)
                  }

                  final_DF = succ_df.filter(succ_df.col("refkey").isNotNull).drop("refkey").drop("primarykey")

                }
              }
              //********************* Reference key check Ends.******************************

              //log.info("finalfailure df before DQ")
              //reject_rec_Df.show(false)
              val dqvalidate = udf(DataQuality.DQValidchck _)
              var rawDfNullRemoved = final_DF.na.fill("")

              // Currency Cast

              var currCastFields: String = propertiesObject.getCurrencyCastFields
              if (currCastFields != null && currCastFields.trim().length() != 0) {
                var currCastFieldsArray: Array[String] = currCastFields.split(",")
                var noOfCols = currCastFieldsArray.length
                while (noOfCols > 0) {
                  noOfCols = noOfCols - 1
                  rawDfNullRemoved = Utilities.getcurrCastFields(rawDfNullRemoved, currCastFieldsArray(noOfCols))
                }
              }

              //Applying lrtrim on all attributes

              var lrTrimFields: String = propertiesObject.getLrTrimFields()
              if (lrTrimFields != null && lrTrimFields.trim().length() != 0) {
                var lrTrimFieldsArray: Array[String] = lrTrimFields.split(",")
                var noOfCols = lrTrimFieldsArray.length
                while (noOfCols > 0) {
                  noOfCols = noOfCols - 1
                  rawDfNullRemoved = Utilities.trimRequiredColumns(rawDfNullRemoved, lrTrimFieldsArray(noOfCols))
                }
              }

              val result = rawDfNullRemoved.withColumn("newCol", concat_ws(propertiesObject.getRcdDelimiter(), final_DF.schema.fieldNames.map(c => col(c)): _*))
              var dataDF = sparkSession.sql(f"""select * from $rwTblNm limit 0""")

              var nf = result.withColumn("flag", dqvalidate(result("newCol"), lit(dataDF.schema.fieldNames.toList.mkString(",")), lit(propertiesObject.getRcdDelimiter()), lit(propertiesObject.getNulchkCol()), lit(propertiesObject.getLnchkVal()), lit(propertiesObject.getDtfmtchkCol()), lit(propertiesObject.getIntchkCol()), lit(propertiesObject.getDoublechkCol()), lit(propertiesObject.getBooleanchkCol()), lit(propertiesObject.getLongchkCol())))
              nf = nf.persist(StorageLevel.MEMORY_AND_DISK_SER)
              nf = Utilities.nullifyEmptyStrings(nf)

              var validrawDF = nf.filter(nf("flag") === "VALID")

              validrawDF.repartition(repartitionNo)
              var errorDF = nf.filter(nf("flag").contains("INVALID"))
              errorDF.repartition(repartitionNo)

              errorDF = errorDF.drop("newCol").withColumn("err_cd", lit("100")).withColumnRenamed("flag", "err_msg_cd")

              var errDF = sparkSession.sql(f"""select * from $errTblNm limit 0""")
              var errColumnList = errDF.columns

              src_count = final_DF.count

              // Final Union of PK & FK reject record With DQ failed error record
              //log.info("Schema of Reject df : "+reject_rec_Df.printSchema())
              //reject_rec_Df.show(false)
              //log.info("Schema of Error df : "+errorDF.printSchema())
              //errorDF.show(false)

              if (reject_rec_Df.count() > 0)
                errorDF = errorDF.unionAll(reject_rec_Df)

              var errorDFWithCol = errorDF.select(errColumnList.head, errColumnList.tail: _*)
              var err_count = errorDFWithCol.count

              //Email Notification Parameters Initialised
              val fl_err_cnt = err_count
              val hadoopConf = new Configuration()
              val hdfs = FileSystem.get(hadoopConf)
              var path = new Path(propertiesFilePath)
              var stream = hdfs.open(path)
              log.info("Error Record count :-" + err_count + " Err Dir:-" + errDir)
              if (err_count > 0 && errDir != null && errDir.length() > 0) {
                log.info("Creating log files for the error record in :-" + errDir)
                errorDFWithCol.repartition(1).write.mode("overwrite").format("com.databricks.spark.csv").option("header", "true").save(errDir)
                val file = hdfs.globStatus(new Path(errDir + "part-0000*"))(0).getPath().getName()
                path = new Path(errDir + file)
                stream = hdfs.open(path)
              }
              var dataDFRaw = sparkSession.sql(f"""select * from $rwTblNm limit 0""")
              var colListRaw = dataDFRaw.columns
              val dateFormatQuery = Utilities.prepareDateFormatQuery(colListRaw, propertiesObject.getDateCastFields())

              validrawDF.createOrReplaceTempView("Temp_DF")
              val validDfWithDateFormat = sparkSession.sql(dateFormatQuery)
              tgt_count = validDfWithDateFormat.count
              val fl_tgt_cnt = tgt_count //It will be used for email notification

              // Map Df to only required Hive columns.
              hiveColList = sparkSession.sql(f"""select * from $rwTblNm limit 1""").columns
              val validRawDfWithDateFormat = validDfWithDateFormat.select(hiveColList.map(col): _*)

              hiveColList = sparkSession.sql(f"""select * from $errTblNm limit 1""").columns
              errorDFWithCol = errorDFWithCol.select(hiveColList.map(col): _*)

              loadStatus = Utilities.storeDataFrame(validRawDfWithDateFormat, rwTblSaveMode, "ORC", rwTblNm, repartitionNo)

              Utilities.storeDataFrame(errorDFWithCol, "Append", "ORC", errTblNm, repartitionNo)

              if (commonErrTblNm != null && commonErrTblNm.size != 0 && propertiesObject.getIsPositional() != null && propertiesObject.getIsPositional().size != 0) {
                Utilities.storeDataFrame(dup_rec_pk_select_df, "Append", "ORC", commonErrTblNm, repartitionNo)
              }

              if (loadStatus) {
                auditObj.setAudJobStatusCode("success")
                auditObj.setAudTgtRowCount(tgt_count)
              } else {
                auditObj.setAudJobStatusCode("failed")
                auditObj.setAudTgtRowCount(0)
              }
              auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudSrcRowCount(src_count)
              //auditObj.setAudTgtRowCount(tgt_count)
              auditObj.setAudErrorRecords(err_count)
              //auditObj.setAudJobStatusCode("success")
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

              auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudDataLayerName("rw_ref")

              hiveColList = sparkSession.sql(f"""select * from $refTblNm limit 1""").columns
              val validRefDfWithDateFormat = validDfWithDateFormat.select(hiveColList.map(col): _*)

              loadStatus = Utilities.storeDataFrame(validRefDfWithDateFormat, refTblSaveMode, "ORC", refTblNm, repartitionNo)

              src_count = tgt_count
              err_count = tgt_count - src_count

              if (loadStatus) {
                auditObj.setAudJobStatusCode("success")
                auditObj.setAudTgtRowCount(tgt_count)
              } else {
                auditObj.setAudJobStatusCode("failed")
                auditObj.setAudTgtRowCount(0)
              }

              auditObj.setAudSrcRowCount(src_count)
              //auditObj.setAudTgtRowCount(tgt_count)
              auditObj.setAudErrorRecords(err_count)
              //auditObj.setAudJobStatusCode("success")
              auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

              // ***Dimension Load Starts*************
              if (propertiesObject.getNaturalKeys() != null && propertiesObject.getTgtTblConsmtn() != null && propertiesObject.getNaturalKeys().size > 0 && propertiesObject.getTgtTblConsmtn().size > 0 && propertiesObject.getCnsmpTblSaveMode().toLowerCase() != "cdc") {
                auditObj.setAudDataLayerName("ref_cnsmptn")
                auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
                var cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, obj_nm, auditTbl)
                var naturalKey = propertiesObject.getNaturalKeys()
                var surrKey = propertiesObject.getSurrKey()
                var latestEntryKey = propertiesObject.getLatestEntryKey()

                val ref_df = sparkSession.sql(f"""select * from """ + propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef() + """ where ld_jb_nr >'""" + cnsmptn_btch_id + """'""")

                //ref_df.registerTempTable("refTmpData")

                val cnsmptn_Df = Utilities.surrogateKeyCreation(naturalKey, surrKey, latestEntryKey, ref_df, sparkSession)

                log.info("Surrogate key generation + Ref df count !!!!!!!!!!" + ref_df.count() + " batch id " + cnsmptn_btch_id)

                //cnsmptn_Df.show(false)
                //log.info("Returned Df"+cnsmptn_Df)

                //val cnsmptn_Df=sparkSession.sql(s"select crc32(concat($naturalKeys)) as $surrKey, row_number() over ( partition by $naturalKeys order by $latestEntryKey) as row_num,t.* from refTmpData t")

                val cnsmptn_Df_final = cnsmptn_Df.filter(col("row_num") === 1).drop("row_num").withColumn("ins_ts", lit(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")))

                ref_df.persist(StorageLevel.MEMORY_AND_DISK_SER)

                ref_df.repartition(10)

                src_count = ref_df.count().toInt

                hiveColList = sparkSession.sql(f"""select * from """ + propertiesObject.getDbName() + "." + propertiesObject.getTgtTblConsmtn() + """ limit 1""").columns

                val cnsmptn_ld_Df = cnsmptn_Df_final.select(hiveColList.map(col): _*)

                loadStatus = Utilities.storeDataFrame(cnsmptn_ld_Df, propertiesObject.getCnsmpTblSaveMode(), "ORC", propertiesObject.getDbName() + "." + propertiesObject.getTgtTblConsmtn(), repartitionNo)

                cnsmptn_ld_Df.persist(StorageLevel.MEMORY_AND_DISK_SER)

                cnsmptn_ld_Df.repartition(10)

                src_count = cnsmptn_ld_Df.count().toInt

                tgt_count = src_count

                ref_df.unpersist()

                cnsmptn_Df_final.unpersist()

                if (loadStatus) {
                  auditObj.setAudJobStatusCode("success")
                  auditObj.setAudTgtRowCount(tgt_count)
                } else {
                  auditObj.setAudJobStatusCode("failed")
                  auditObj.setAudTgtRowCount(0)
                }

                err_count = 0
                auditObj.setAudSrcRowCount(src_count)
                //auditObj.setAudTgtRowCount(tgt_count)
                auditObj.setAudErrorRecords(err_count)
                //auditObj.setAudJobStatusCode("success")
                auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
                auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
                auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
                Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

                // ***Dimension Load Ends*************
              } else if (propertiesObject.getNaturalKeys() != null && propertiesObject.getTgtTblConsmtn() != null && propertiesObject.getNaturalKeys().size > 0 && propertiesObject.getTgtTblConsmtn().size > 0 && propertiesObject.getCnsmpTblSaveMode().toLowerCase() != null && propertiesObject.getCnsmpTblSaveMode().toLowerCase().size > 0 && propertiesObject.getCnsmpTblSaveMode().toLowerCase() == "cdc") {
                log.info("+++++++++########## CDC Class called ##########+++++++++")

                new CDC(auditObj, propertiesObject, sparkSession, sqlCon, auditTbl, propertiesObject.getDbName()).run()

                log.info("+++++++++########## CDC completed ##########+++++++++")

              }
              //******Email Notification *********

              if (propertiesObject.getSendMailTo() != null && propertiesObject.getSendMailFrom() != null) {

                if (fl_err_cnt > 0) {
                  log.info("Preparing Email Notification for failure records.")
                  val message_body = s"The $sourceSystem file $fl_nm has invalid records. Only valid records are loaded to $sourceSystem tables.<br> please find the stats as below :-  </br><br>  Total Source rows processed : $fl_src_cnt  </br><br>  Total Target rows processed : $fl_tgt_cnt  </br><br>  Total Source rows skipped : $fl_err_cnt </br>"

                  val alertmsg = s"The $sourceSystem job has Invalid Record."

                  val message = Utilities.createHtmlEmailBody(message_body, alertmsg)

                  val subject = s"$sourceSystem Job has Failed || $reportDtTime"

                  Utilities.sendemail(toemail, fromemail, subject, message, sendMailSMTPHost, stream, fl_nm)
                } else {
                  log.info("Preparing Email Notification for success")
                  val message_body = s"The $sourceSystem Job has successfully processed the file $fl_nm. The data has been loaded into the $sourceSystem table. <br> please find the stats as below :- </br> <br> Total Source rows processed : $fl_src_cnt </br><br> Total Target rows processed : $fl_tgt_cnt </br> <br> Total Source rows skipped : $fl_err_cnt</br> "

                  val alertmsg = s"The $sourceSystem job has successfully completed."

                  val message = Utilities.createHtmlEmailBody(message_body, alertmsg)

                  val subject = s"$sourceSystem Job has successfully completed || $reportDtTime"

                  Utilities.sendemail(toemail, fromemail, subject, message, sendMailSMTPHost)

                }
              }
              nf.unpersist()
              if (archiveDir != null && archiveDir.size != 0 && fileNamewithpath.contains(".")) {
                log.warn("Load completed successfully , Moving " + fileNamewithpath + " file to Archive Directory" + archiveDir + fl_nm + "-" + batchId)
                (s"hdfs dfs -mv " + fileNamewithpath + " " + archiveDir + fl_nm + "-" + batchId)! //Moving source file to Archive Directory.

              }
            } else {
              log.error("File Header did not match with target table")
              if (propertiesObject.getSendMailTo() != null && propertiesObject.getSendMailFrom() != null) {
                log.info("Preparing Email Notification for failure records.")

                val message_body = s"The $sourceSystem job has failed while processing the file $fl_nm , due to header mismatch. <br> \n Expected File Header::::::::::::::: $expFileHeader  </br> <br> Actual File Headers::::::::::::::: $actFileHeader</br>"

                val alertmsg = s"The $sourceSystem job has failed as File Header did not match with target table."

                val message = Utilities.createHtmlEmailBody(message_body, alertmsg)

                val subject = s"$sourceSystem Job has Failed || $reportDtTime"

                Utilities.sendemail(toemail, fromemail, subject, message, sendMailSMTPHost)
              }
              if (archiveDir != null && archiveDir.size != 0 && fileNamewithpath.contains(".")) {
                log.warn("Moving " + fileNamewithpath + " file to Archive Directory")

                (s"hdfs dfs -mv " + fileNamewithpath + " " + archiveDir + fl_nm + "-" + batchId)! //Moving source file to Archive Directory.

              }
              auditObj.setAudJobStatusCode("failed")
              val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            }
          } else {
            log.warn("File is empty")
            if (propertiesObject.getSendMailTo() != null && propertiesObject.getSendMailFrom() != null) {
              log.info("Preparing Email Notification for failure records.")
              val message_body = s"The $sourceSystem job has failed while processing the file $fl_nm , as source file is Empty."

              val alertmsg = s"The $sourceSystem job has failed as File is empty."

              val message = Utilities.createHtmlEmailBody(message_body, alertmsg)

              val subject = s"$sourceSystem Job has Failed || $reportDtTime"

              Utilities.sendemail(toemail, fromemail, subject, message, sendMailSMTPHost)
            }
            if (archiveDir != null && archiveDir.size != 0 && fileNamewithpath.contains(".")) {

              log.warn("Moving " + fileNamewithpath + " file to Archive Directory")

              (s"hdfs dfs -mv " + fileNamewithpath + " " + archiveDir + fl_nm + "-" + batchId)! //Moving source file to Archive Directory.

            }
            auditObj.setAudJobStatusCode("failed")
            val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          }
        } else {
          log.warn("The $sourceSystem file :- " + fl_nm + " is not configured for EAP load")
          if (propertiesObject.getSendMailTo() != null && propertiesObject.getSendMailFrom() != null) {
            log.info("Preparing Email Notification for failure records.")
            val message_body = s"The $sourceSystem job has failed while processing the file $fl_nm ,as its configuratrion is not completed in EAP"

            val alertmsg = "The $sourceSystem job has failed as its configuration for EAP load is not completed."

            val message = Utilities.createHtmlEmailBody(message_body, alertmsg)

            val subject = s"$sourceSystem Job has Failed || $reportDtTime"

            Utilities.sendemail(toemail, fromemail, subject, message, sendMailSMTPHost)
          }
          if (archiveDir != null && archiveDir.size != 0 && fileNamewithpath.contains(".")) {

            log.warn("Moving " + fileNamewithpath + " file to Archive Directory")

            (s"hdfs dfs -mv " + fileNamewithpath + " " + archiveDir + fl_nm + "-" + batchId)! //Moving source file to Archive Directory.

          }
          auditObj.setAudJobStatusCode("failed")
          val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        }
      }
    } catch {
      case sslException: InterruptedException => {
        log.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        funcReturn = false
      }
      case nseException: NoSuchElementException => {
        log.error("No Such element found: " + nseException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        funcReturn = false
      }
      case anaException: AnalysisException => {
        log.error("SQL Analysis Exception: " + anaException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        funcReturn = false
      }

      case exception: Exception => {
        log.error(exception.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        funcReturn = false
      }
    } finally {
      if (funcReturn) {
        log.info("Finally Block executed for no Exception")
        sqlCon.close()
        sparkSession.close()
      } else {

        if (propertiesObject.getSendMailTo() != null && propertiesObject.getSendMailFrom() != null) {
          log.info("Preparing Email Notification for failure records.")
          val message_body = s"The $sourceSystem job has failed with Exception ,Check the job log for more information."

          val alertmsg = s"The $sourceSystem job has failed with Exception."

          val message = Utilities.createHtmlEmailBody(message_body, alertmsg)

          val subject = s"$sourceSystem Job has Failed || $reportDtTime"

          Utilities.sendemail(toemail, fromemail, subject, message, sendMailSMTPHost)
          log.info("Finally Block executed for Exception")
          sqlCon.close()
          sparkSession.close()
          System.exit(1)
        }
      }
    }
  }
}
package com.hpe.driver

import com.hpe.utils.Utilities
import org.apache.log4j.Logger
import com.hpe.config.SetUpConfigurationNonStreaming
import com.hpe.config.ConfigObjectNonStreaming
import scala.collection.JavaConversions._
import org.apache.log4j.Logger
import com.hpe.config._
import com.hpe.utils.Utilities
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType}
import org.apache.spark.sql.types.TimestampType

object TableFileMerge {
   val logger = Logger.getLogger(getClass.getName)
   def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Properties file path>")
      println("Stopping the flow")
      System.exit(1)
    }
   val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
    
   val objNm        = String.valueOf(args(0).trim())
   val dbschema     = String.valueOf(args(1).trim())
   val partitionNum = String.valueOf(args(2).trim())
   val objType      = String.valueOf(args(3).trim())
    
   val rwTblNm   = dbschema+"."+objNm+"_rw"
   
   val refTblNm   = dbschema+"."+objNm+"_ref"
   
   val errTblNm   = dbschema+"."+objNm+"_err"
   
   import org.apache.spark.sql.SQLContext
   val spark      = configObject.getSpark()
   val sqlcontext = new org.apache.spark.sql.SQLContext(spark.sparkContext)
	  
   val rwsql  ="""select * from """+rwTblNm
   val refsql ="""select * from """+refTblNm
   val errsql ="""select * from """+errTblNm
	 
   var rwDF   = spark.sql(rwsql)
   var refDF  = spark.sql(refsql)
   var errDF  = spark.sql(errsql)
   
   if ("SERP".equalsIgnoreCase(objType)){
   var ctrlDF = spark.sql("""select * from """+dbschema+"""."""+objNm+"""_ctrl""")
   var loadStatus   = Utilities.storeDataFrame(ctrlDF, "overwrite", "ORC",dbschema+"."+objNm+"_ctrl",partitionNum.toInt)
	 var record_count = ctrlDF.count()
	 if(loadStatus){
    logger.info("::::::::::::::Load completed ::::::::::::::--->Total Record count for Table "+objNm+"_ctrl is "+record_count)
       }
   else{
     logger.info("::::::::::::::JOb Failed , Check log for more details::::::::::::::::")
       }
   }
   
	 var loadStatus   = Utilities.storeDataFrame(rwDF, "overwrite", "ORC",rwTblNm,partitionNum.toInt)
	 var record_count = rwDF.count()
	 if(loadStatus){
    logger.info("::::::::::::::Load completed ::::::::::::::--->Total Record count for Table "+rwTblNm+" is "+record_count)
   }
   else{
     logger.info("::::::::::::::JOb Failed , Check log for more details::::::::::::::::")
   }
	 
	 loadStatus = Utilities.storeDataFrame(refDF, "overwrite", "ORC",refTblNm,partitionNum.toInt)
	 record_count = refDF.count()
	 if(loadStatus){
    logger.info("::::::::::::::Load completed ::::::::::::::--->Total Record count for Table "+refTblNm+" is "+record_count)
   }
   else{
     logger.info("::::::::::::::JOb Failed , Check log for more details::::::::::::::::")
   }	 
	 loadStatus = Utilities.storeDataFrame(errDF, "overwrite", "ORC",errTblNm,partitionNum.toInt)
	 record_count = errDF.count()
	 if(loadStatus){
    logger.info("::::::::::::::Load completed ::::::::::::::--->Total Record count for Table "+errTblNm+" is "+record_count)
   }
   else{
     logger.info("::::::::::::::JOb Failed , Check log for more details::::::::::::::::")
   }     
  }
}
package com.hpe.driver

import com.hpe.utils.Utilities
import org.apache.log4j.Logger
import com.hpe.config.SetUpConfigurationNonStreaming
import com.hpe.config.ConfigObjectNonStreaming
import scala.collection.JavaConversions._
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
import org.apache.log4j.Logger
import com.hpe.config._
import com.hpe.utils.Utilities
import org.apache.spark.sql.types.{ LongType, StringType, StructField, StructType }
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel

object ArchiveGLTrsn {
  val logger = Logger.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty || args.length < 7) {
      logger.error("Invalid number of arguments passed.")
      logger.error("Arguments Usage: <TableName Name> <Hive Schema> <Retention in Days> <Hive Partition Column Name> <Parimary key> <Sorting Column> <Properties File>")
      logger.error("Stopping the flow")
      System.exit(1)
    }
    var auditObj: com.hpe.config.AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")

    try {
      val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
      val trsnTableName = String.valueOf(args(0).trim())
      val dbschema = String.valueOf(args(1).trim())
      val partitionWindow = String.valueOf(args(2).trim()) //7 - this is used for rw, err, ctrl
      val partitionColNm = String.valueOf(args(3).trim()) //ins_gmt_dt
      val primaryKey = String.valueOf(args(4).trim()) //e1edk01_idoc_dcmt_nr--order number
      val sortCols = String.valueOf(args(5).trim()) //upd_gmt_ts
      val propertiesFilePath = String.valueOf(args(6).trim())
      logger.info("ARGS============================" + trsnTableName + " " + dbschema + " " + partitionWindow + " " + partitionColNm + " " + primaryKey + " " + sortCols + " " + propertiesFilePath)
      val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
      val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
      val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
      val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
      val sqlCon = Utilities.getConnection(envPropertiesObject)
      val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
      val spark = configObject.getSpark()
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
      var latestDistintPartitions = ""
      var dropPartitionQuery = ""
      var endTime = startTime
      var duration = "0"
      val propertiesObject: PropertiesObject = Utilities.getPropertiesobject(propertiesFilePath)
      val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
      val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
      val auditBatchId = ld_jb_nr + "_" + batchId

      auditObj.setAudBatchId(auditBatchId)
      auditObj.setAudApplicationName(spark.sparkContext.appName)
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(0)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(spark.sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)

      /* Archiving Refined table */
      val trsnTableNm = dbschema + "." + trsnTableName
      val trsnArcTblNm = dbschema + "." + trsnTableName + "_arc"

      var arcTrsnDfAll = spark.sql("select * from " + trsnTableNm + " where " + partitionColNm + " <= DATE_SUB(to_date(current_timestamp)," + partitionWindow + ")")
      auditObj.setAudSrcRowCount(arcTrsnDfAll.count())
      val trsnCol = spark.sql("select * from " + trsnTableNm + " limit 0")
      val trsnArcCol = spark.sql("select * from " + trsnArcTblNm + " limit 0")
      if (!arcTrsnDfAll.head(1).isEmpty) {
        arcTrsnDfAll.write.mode("Overwrite").format("ORC").saveAsTable(dbschema + ".arcTrsnDfAll_tmp")
        spark.catalog.refreshTable(dbschema + ".arcTrsnDfAll_tmp")
      }
      arcTrsnDfAll = spark.sql("select * from " + dbschema + ".arcTrsnDfAll_tmp")
      if (!arcTrsnDfAll.head(1).isEmpty) {
        latestDistintPartitions = arcTrsnDfAll.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0)).toSeq.mkString(",")
        dropPartitionQuery = Utilities.prepareDropPartitionQuery(latestDistintPartitions, partitionColNm, trsnTableNm)
        logger.info("Transaction Archiving Query:::::::::::::" + dropPartitionQuery)
        spark.sql(dropPartitionQuery)
        spark.sql("MSCK REPAIR TABLE " + trsnTableNm)

        val prdNr = arcTrsnDfAll.select("pstg_prd_nr").distinct().collect.map(row => row.getLong(0)).toSeq
        val yrNr = arcTrsnDfAll.select("fscl_yr_nr").distinct().collect.map(row => row.getLong(0)).toSeq
        var arcRefDfLatest: DataFrame = null
        val arcDf = spark.sql("select * from " + trsnArcTblNm).where(col("fscl_yr_nr").isin(yrNr: _*)).where(col("pstg_prd_nr").isin(prdNr: _*))
        val unChangedFact = arcDf.join(arcTrsnDfAll, Seq(primaryKey), "left_anti")
        arcDf.select(trsnCol.columns.head, trsnCol.columns.tail: _*).write.mode("Append").format("ORC").saveAsTable(dbschema + ".arcTrsnDfAll_tmp")
        spark.catalog.refreshTable(dbschema + ".arcTrsnDfAll_tmp")
        arcTrsnDfAll = spark.sql("select * from " + dbschema + ".arcTrsnDfAll_tmp")
        val latestArcDf = Utilities.getLatestRecs(arcTrsnDfAll, List(primaryKey), List(sortCols))
        val arcStatus = Utilities.storeDataFrame(latestArcDf.select(trsnArcCol.columns.head, trsnArcCol.columns.tail: _*), "Overwrite", "ORC", trsnArcTblNm)
        //.write.mode(SaveMode.Overwrite).format("orc").insertInto(trsnArcTblNm)

        if (arcStatus) {
          spark.sql("MSCK REPAIR TABLE " + trsnArcTblNm)
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudTgtRowCount(latestArcDf.count())
          spark.sql(s"truncate table ${dbschema}.arcTrsnDfAll_tmp")
          spark.catalog.refreshTable(dbschema + ".arcTrsnDfAll_tmp")

        } else {
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudTgtRowCount(0)
          logger.error("Insert into " + trsnArcTblNm + " table failed")
        }
        endTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
        duration = (((format.parse(endTime).getTime - format.parse(startTime).getTime).toString()).toInt / 1000).toString()
        auditObj.setAudDataLayerName("rw_arc")
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        logger.info("Archiving of " + trsnTableNm + " for " + partitionWindow + " days took " + duration + " seconds")
      } else {
        logger.warn("No new partitions found to be archived in ref table!")
      }

    } catch {
      case sslException: InterruptedException => {
        logger.error("Interrupted Exception")
        sys.exit(1)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        sys.exit(1)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        sys.exit(1)
      }
      case exception: Exception => {
        logger.error("Exception: " + exception.printStackTrace())
        sys.exit(1)
      }
    }
  }
}
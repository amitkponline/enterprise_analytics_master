package com.hpe.driver

import com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import com.hpe.utils._
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import scala.io.Source

  object FactLoad {
    
    val logger = Logger.getLogger(getClass.getName)
    
    def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
      println("Stopping the flow")
      System.exit(1)
    }
    val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
    var spark = configObject.getSpark()
    val propertiesFilePath = String.valueOf(args(0).trim())
    var objectName         = propertiesFilePath.substring(propertiesFilePath.lastIndexOf("/") + 1)
    var fileBasePath       = String.valueOf(args(1).trim())
    
    //val propertiesObject: FilePropertiesObject = Utilities.getFilePropertiesobject(propertiesFilePath)
    val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
    val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
    val envPropertiesFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"connection.properties"
    val envPropertiesObject: EnvPropertiesObject =  Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
    val sqlCon = Utilities.getConnection(envPropertiesObject)
    
    val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
         
    var auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    
    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    
    val format       = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val fl_nm        = objectName+".hql"
    val sys_btch_nr  = objectName
    val auditBatchId = objectName+"_"+Utilities.getCurrentTimestamp("yyyyMMddHHmmssSSS")

    auditObj.setAudBatchId(auditBatchId)
    auditObj.setAudApplicationName("job_EA_FactLoad")
    auditObj.setAudObjectName(objectName)
    auditObj.setAudSrcRowCount(0)
    auditObj.setAudTgtRowCount(0)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.spark.sparkContext.sparkUser)
    auditObj.setFlNm(fl_nm)
    auditObj.setSysBtchNr(sys_btch_nr)
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
       
  try {
    
    //beeline -u "jdbc:hive2://hnr01n01-i.hpeit.hpecorp.net:2181,hnr01n02-i.hpeit.hpecorp.net:2181,hnr02n02-i.hpeit.hpecorp.net:2181,hnr01n03-i.hpeit.hpecorp.net:2181,hnr02n03-i.hpeit.hpecorp.net:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2?tez.queue.name=eap_batch_srv_uat" -f /opt/mount/talend_conf/contextDir_Rel_2_1/consumptionLayerScriptsDir/consumptionLayerFactScriptsDir/quotes_fact_hst.hql
    
   // val execqueries = Source.fromFile(fileBasePath+"/"+fl_nm).getLines.mkString("\n").split(";")
    
   val execqueries = spark.sparkContext.textFile(fileBasePath+"/"+fl_nm).collect().mkString("\n").split(";") 
    
    var x = ' '
    var i = 1
    
    for(x <-execqueries){
      println(i+" query is : "+x)
      i = i+1
      spark.sql(x)
    }
    
    if ( fileBasePath.contains("consumptionLayerDimensionScriptsDir"))
    { 
      auditObj.setAudDataLayerName("ref_cnsmptn") 
    }
    else if(fileBasePath.contains("consumptionLayerFactScriptsDir"))
    {
      auditObj.setAudDataLayerName("cnsmptn_fact")
    }
     auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
     auditObj.setAudJobStatusCode("success")
     auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
     Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  }
   catch {
      case sslException: InterruptedException => {
        logger.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case connException: ConnectException => {
        logger.error("Connection Exception: " + connException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
       
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case exception: Exception => {
        logger.error(exception.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        //Check if SQL connection is active
        var sqlCon = Utilities.getConnection(envPropertiesObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      }finally{
      if(sqlCon!=null){
        sqlCon.close()
      }
    }
  }
}
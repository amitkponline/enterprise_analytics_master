package com.hpe.driver

import com.hpe.utils.Utilities
import org.apache.log4j.Logger
import com.hpe.config.SetUpConfigurationNonStreaming
import com.hpe.config.ConfigObjectNonStreaming
import scala.collection.JavaConversions._
import org.apache.log4j.Logger
import com.hpe.config._
import com.hpe.utils.Utilities
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType}
import org.apache.spark.sql.types.TimestampType

object CompactNArchive {
   val logger = Logger.getLogger(getClass.getName)
   def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty||args.length!=4) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Table Name> <Hive Schema> <Partition Window in Days> <Target Part Files>")
      println("Stopping the flow")
      System.exit(1)
    }
   val configObject: ConfigObjectNonStreaming = SetUpConfigurationNonStreaming.setup()
    
   val objNm        = String.valueOf(args(0).trim())
   val dbschema     = String.valueOf(args(1).trim())
   val partitionWindow = String.valueOf(args(2).trim())
   val partitionNum = String.valueOf(args(3).trim())
   
    
   val rwTblNm   = dbschema+"."+objNm
   val rwTblArcNm   = dbschema+"."+objNm+"_arc_s"
   
   val spark      = configObject.getSpark()
	  
   val rwsql  ="""select * from """+rwTblNm+""" where to_date(upd_gmt_ts)>DATE_SUB(to_date(current_timestamp),"""+partitionWindow+""")"""
   val rwsqlArc  ="""select * from """+rwTblNm+""" where to_date(upd_gmt_ts)<= DATE_SUB(to_date(current_timestamp),"""+partitionWindow+""") or upd_gmt_ts is null"""
   
   var rwDF   = spark.sql(rwsql)
   var rwArcDF   = spark.sql(rwsqlArc)
   
   var loadStatus   = Utilities.storeDataFrame(rwArcDF, "append", "ORC",rwTblArcNm,partitionNum.toInt)
	 var record_count = rwArcDF.count()
	 if(loadStatus){
    logger.info("::::::::::::::Load completed ::::::::::::::--->Total Record count for Table "+rwTblArcNm+" is "+record_count)
   }
   else{
     logger.info("::::::::::::::JOb Failed , Check log for more details::::::::::::::::")
   }
   
	 loadStatus   = Utilities.storeDataFrame(rwDF, "overwrite", "ORC",rwTblNm,partitionNum.toInt)
	 record_count = rwDF.count()
	 if(loadStatus){
    logger.info("::::::::::::::Load completed ::::::::::::::--->Total Record count for Table "+rwTblNm+" is "+record_count)
   }
   else{
     logger.info("::::::::::::::JOb Failed , Check log for more details::::::::::::::::")
   }
   
   
  }
}
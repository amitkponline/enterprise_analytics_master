import time, threading, os

WAIT_SECONDS = 3600
def ScriptRunner():
    os.system('sh -x /home/srvc_nextgen_hpro/Service_Cost_object/scripts/serviceCost_Output.sh')
    threading.Timer(WAIT_SECONDS, ScriptRunner).start()

ScriptRunner()
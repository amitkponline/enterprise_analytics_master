#!/bin/bash
# ************************************************************** #
# ********* Copyright 2020 HPE. All Rights Reserved ************ #
# ***** Environment setup is based on directory structure ****** #
# ************************************************************** #
# Please edit environmental variables setup before execute this shell script as these varibles is for user authentication purpose
# @Author Sahil Agnihotri
# @Team HPE-NGIT Hive Team

# -----------------------------------------------------------------
# Script Description
# go to path : cd /home/srvc_nextgen_hpro/Service_Cost_object/scripts and trigger below script
# Trigger script as: sh -x serviceCost_Output.sh
# -----------------------------------------------------------------
# This script load the data files coming from DXC and load till ref/dmnsn tables.
# If the processing file contains .13. sequence, then this script create the cost margin zip file and that will shared to DXC team.

# -----------------------------------------------------------------
# environmental variables setup
# -----------------------------------------------------------------

. /home/srvc_nextgen_hpro/Service_Cost_object/config/serviceCost_env.properties

# -----------------------------------------------------------------
# Directories creation and variable initialisation
# -----------------------------------------------------------------

hadoop fs -mkdir -p /tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object/dxc_unzipped_files

#changing permissions to 777 
chmod -R 777 /home/srvc_nextgen_hpro/Service_Cost_object
hadoop fs -chmod -R 777 /tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object

#variable initialisation
ROOT_PATH=/home/srvc_nextgen_hpro/Service_Cost_object
HDFS_ROOT_PATH=${nameNode_1}/tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object
HDFS_ROOT_PATH_LOCAL=/HDFS_ROOT/tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object

OUTBOUND_PATH=/data/01/srvc_ima_platform/EA/DropLocation/Services/EAI3167_ServicesCost/Outbound
ARCHIVE_PATH=/user/srvc_ima_platform/EA/DropLocation/Services/EAI3167_ServicesCost/Outbound/archive

DXC_FILES=/tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object/dxc_unzipped_files
HDFS_DXC_PATH_LOCAL=/HDFS_ROOT/tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object/dxc_unzipped_files

#logs creation
mkdir -p ${ROOT_PATH}/logs
chmod -R 777 ${ROOT_PATH}/logs

LOG_PATH=${ROOT_PATH}/logs
LOG_FILE=${LOG_PATH}/Service_Cost_output_$(date +%Y%m%d%H%M%S0000).log

exec >>${LOG_FILE}
exec 2>>${LOG_FILE}

recent_timestamp=$(date +"%Y%m%d.%H%M%S")
echo "${recent_timestamp}"

recent_date=$(date +"%Y%m%d")
echo "${recent_date}"

# -----------------------------------------------------------------
# Kinit setup
# -----------------------------------------------------------------

kinit -V -kt /etc/security/keytabs/${userName_1}.keytab ${userName_1}@${kPrincipal_1}

# -----------------------------------------------------------------
# serviceCost_Input.sh script start time 
# -----------------------------------------------------------------

job_Start_Time=$(date +"%s"); date
echo ${job_Start_Time}

# -----------------------------------------------------------------
# Beeline connection string setup
# -----------------------------------------------------------------
export HADOOP_CLIENT_OPTS="-Djline.terminal=jline.UnsupportedTerminal"

beelineUrl="jdbc:hive2://hnr01n01.hpeit.hpecorp.net:2181,hnr02n01.hpeit.hpecorp.net:2181,hnr03n01.hpeit.hpecorp.net:2181,hnr02n02.hpeit.hpecorp.net:2181,hnr01n03.hpeit.hpecorp.net:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2?tez.queue.name=${queueName}"

echo ${beelineUrl}

# -----------------------------------------------------------------
# extract all files from latest zip file shared by DXC team
# -----------------------------------------------------------------

#remove already present previous files from ${DXC_FILES} Path
hadoop fs -rm -r ${DXC_FILES}/*

# copy latest zip file shared by DXC team from outbound hdfs path to other hdfs path
hadoop fs -put -f ${OUTBOUND_PATH}/*.zip ${DXC_FILES}/

if [[ $? -eq 0 ]];then
	echo "zip file successfully copied from ${latest_zipfile_name} TO ${DXC_FILES} Path"
	hadoop fs -chmod -R 777 ${DXC_FILES}/*
else
	echo "issue occur while copying zip file from ${latest_zipfile_name} TO ${DXC_FILES} Path"
	exit 1
fi


#unzip the files
cd ${HDFS_DXC_PATH_LOCAL}/

unzip -o '*.zip'

if [[ $? -eq 0 ]];then
	echo "zip file successfully unziped"
	hadoop fs -chmod -R 777 ${DXC_FILES}/*
else
	echo "issue occur while unzipping the files"
	exit 1
fi


# -----------------------------------------------------------------------
# Run Spark submit command and load all the files into respective tables till intermediate ref (intrmdt_ref)
# -----------------------------------------------------------------------

#for ServiceCost_drd.properties

cd /home/srvc_nextgen_hpro/nonSAPSScripts

/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --deploy-mode cluster --principal srvc_nextgen_hpro@EAPPRD.HPEIT.HPE.COM --keytab /etc/security/keytabs/srvc_nextgen_hpro.keytab --conf spark.app.name="ServiceCostdrd"  --conf spark.driver.maxResultSize=3g  --jars /usr/hdp/current/spark2-client/jars/datanucleus-rdbms-3.2.9.jar,/usr/hdp/current/spark2-client/jars/datanucleus-api-jdo-3.2.6.jar,/usr/hdp/current/spark2-client/jars/datanucleus-core-3.2.10.jar,./file-processor-2.2.1.jar  --driver-memory 10g --executor-memory 10g --total-executor-cores 15 --files talend_kfk_keystore.jks,talend_kfk_truststore.jks,/usr/hdp/current/spark-client/conf/hive-site.xml --queue ${queueName} --class com.hpe.driver.NonSAPFileToREF file-processor-2.2.1.jar ${nameNode_1}/user/${userName_1}/properties/ServiceCost_drd.properties



if [[ $? -eq 0 ]];then
        echo "ServiceCost_drd trigger sucessfully"
else
        echo "issue occur while triggering the ServiceCost_drd"
        exit 1
fi


#for ServiceCost_mcc.properties

cd /home/srvc_nextgen_hpro/nonSAPSScripts

/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --deploy-mode cluster --principal srvc_nextgen_hpro@EAPPRD.HPEIT.HPE.COM --keytab /etc/security/keytabs/srvc_nextgen_hpro.keytab --conf spark.app.name="ServiceCostmcc"  --conf spark.driver.maxResultSize=3g  --jars /usr/hdp/current/spark2-client/jars/datanucleus-rdbms-3.2.9.jar,/usr/hdp/current/spark2-client/jars/datanucleus-api-jdo-3.2.6.jar,/usr/hdp/current/spark2-client/jars/datanucleus-core-3.2.10.jar,./file-processor-2.2.1.jar  --driver-memory 10g --executor-memory 10g --total-executor-cores 15 --files talend_kfk_keystore.jks,talend_kfk_truststore.jks,/usr/hdp/current/spark-client/conf/hive-site.xml --queue ${queueName} --class com.hpe.driver.NonSAPFileToREF file-processor-2.2.1.jar ${nameNode_1}/user/${userName_1}/properties/ServiceCost_mcc.properties

if [[ $? -eq 0 ]];then
        echo "ServiceCost_mcc trigger sucessfully"
else
        echo "issue occur while triggering the ServiceCost_mcc"
        exit 1
fi

#for ServiceCost_mtr.properties

cd /home/srvc_nextgen_hpro/nonSAPSScripts

/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --deploy-mode cluster --principal srvc_nextgen_hpro@EAPPRD.HPEIT.HPE.COM --keytab /etc/security/keytabs/srvc_nextgen_hpro.keytab --conf spark.app.name="ServiceCostmtr"  --conf spark.driver.maxResultSize=3g  --jars /usr/hdp/current/spark2-client/jars/datanucleus-rdbms-3.2.9.jar,/usr/hdp/current/spark2-client/jars/datanucleus-api-jdo-3.2.6.jar,/usr/hdp/current/spark2-client/jars/datanucleus-core-3.2.10.jar,./file-processor-2.2.1.jar  --driver-memory 10g --executor-memory 10g --total-executor-cores 15 --files talend_kfk_keystore.jks,talend_kfk_truststore.jks,/usr/hdp/current/spark-client/conf/hive-site.xml --queue ${queueName} --class com.hpe.driver.NonSAPFileToREF file-processor-2.2.1.jar ${nameNode_1}/user/${userName_1}/properties/ServiceCost_mtr.properties

if [[ $? -eq 0 ]];then
        echo "ServiceCost_mtr trigger sucessfully"
else
        echo "issue occur while triggering the ServiceCost_mtr"
        exit 1
fi

# -----------------------------------------------------------------------
# load all records from  intermediate ref (intrmdt_ref) to final ref having stts !='NOT_FOUND'
# -----------------------------------------------------------------------

#get latest partition from ServiceCost_drd_intrmdt_ref table
max_part_drd=`beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "select max(ins_gmt_dt) from ${db_Name}.ServiceCost_drd_intrmdt_ref;"`

echo "${max_part_drd}"

#create static partition in ServiceCost_drd_ref table
beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "Alter table ${db_Name}.ServiceCost_drd_ref ADD IF NOT EXISTS PARTITION(ins_gmt_dt='${max_part_drd}')"

# put data from latest partition from from ServiceCost_drd_intrmdt_ref to ServiceCost_drd_ref where stts !='NOT_FOUND'
beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "INSERT OVERWRITE TABLE ${db_Name}.ServiceCost_drd_ref PARTITION(ins_gmt_dt='${max_part_drd}') SELECT distinct e1edka1_ctry_ky_cd,price_descriptor,zord_item01_inctrms_prt_1_cd,e1edp01_idoc_drdl_id_nm,option,mcc,query_date,elmt_typ,stts,amt,e1edk01_curr_cd,sprt_sfx_identifierspn_op,metric,src_sys_key,lgcl_dlt_flg_ind,actv_flg_ind,src_sys_update_timestamp,md_of_trnsp,intgtn_fbrc_msg_id,src_sys_upd_ts, src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr FROM ${db_Name}.ServiceCost_drd_intrmdt_ref where ((stts !='NOT_FOUND') AND (ins_gmt_dt='${max_part_drd}'));"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
	echo "data sucessfully transfered from ${db_Name}.ServiceCost_drd_intrmdt_ref to ${db_Name}.ServiceCost_drd_ref"
else
	echo "issue while transfer of data from ${db_Name}.ServiceCost_drd_intrmdt_ref to ${db_Name}.ServiceCost_drd_ref"
	exit 1
fi

#get latest partition from ServiceCost_mtr_intrmdt_ref table
max_part_mtr=`beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "select max(ins_gmt_dt) from ${db_Name}.ServiceCost_mtr_intrmdt_ref;"`
echo "${max_part_mtr}"

#create static partition in ServiceCost_mtr_ref table
beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "Alter table ${db_Name}.ServiceCost_mtr_ref ADD IF NOT EXISTS PARTITION(ins_gmt_dt='${max_part_mtr}')"

# put data from latest partition from from ServiceCost_mtr_intrmdt_ref to ServiceCost_mtr_ref where stts !='NOT_FOUND'
beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "INSERT OVERWRITE TABLE ${db_Name}.ServiceCost_mtr_ref PARTITION(ins_gmt_dt='${max_part_mtr}') SELECT distinct e1edka1_ctry_ky_cd,price_descriptor,zord_item01_inctrms_prt_1_cd,e1edp01_idoc_mtrl_id_nm,option,mcc,query_date,elmt_typ,stts,amt,e1edk01_curr_cd,sprt_sfx_identifierspn_op,metric,src_sys_key,lgcl_dlt_flg_ind,actv_flg_ind,src_sys_update_timestamp,md_of_trnsp,intgtn_fbrc_msg_id,src_sys_upd_ts, src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr FROM ${db_Name}.ServiceCost_mtr_intrmdt_ref where ((stts !='NOT_FOUND') AND (ins_gmt_dt='${max_part_mtr}'));"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
	echo "data sucessfully transfered from ${db_Name}.ServiceCost_mtr_intrmdt_ref to ${db_Name}.ServiceCost_mtr_ref"
else
	echo "issue while transfer of data from ${db_Name}.ServiceCost_mtr_intrmdt_ref to ${db_Name}.ServiceCost_mtr_ref"
	exit 1
fi


#get latest partition from ServiceCost_mcc_intrmdt_ref table
max_part_mcc=`beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "select max(ins_gmt_dt) from ${db_Name}.ServiceCost_mcc_intrmdt_ref;"`

echo "${max_part_mcc}"

#create static partition in ServiceCost_mcc_ref table
beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "Alter table ${db_Name}.ServiceCost_mcc_ref ADD IF NOT EXISTS PARTITION(ins_gmt_dt='${max_part_mcc}')"

# put data from latest partition from from ServiceCost_mcc_intrmdt_ref to ServiceCost_mcc_ref where stts !='NOT_FOUND'
beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "INSERT OVERWRITE TABLE ${db_Name}.ServiceCost_mcc_ref PARTITION(ins_gmt_dt='${max_part_mcc}') SELECT distinct e1edka1_ctry_ky_cd,price_descriptor,zord_item01_inctrms_prt_1_cd,e1edp01_idoc_mccl_id_nm,option,mcc,query_date,elmt_typ,stts,amt,e1edk01_curr_cd,sprt_sfx_identifierspn_op,metric,src_sys_key,lgcl_dlt_flg_ind,actv_flg_ind,src_sys_update_timestamp,md_of_trnsp,intgtn_fbrc_msg_id,src_sys_upd_ts, src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr FROM ${db_Name}.ServiceCost_mcc_intrmdt_ref where ((stts !='NOT_FOUND') AND (ins_gmt_dt='${max_part_mcc}'));"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
	echo "data sucessfully transfered from ${db_Name}.ServiceCost_mcc_intrmdt_ref to ${db_Name}.ServiceCost_mcc_ref"
else
	echo "issue while transfer of data from ${db_Name}.ServiceCost_mcc_intrmdt_ref to ${db_Name}.ServiceCost_mcc_ref"
	exit 1
fi


# -----------------------------------------------------------------------
# Run Spark submit command and load Change data capture from intermediate ref (intrmdt_ref) to dmnsn
# -----------------------------------------------------------------------

#for ServiceCost_drd_cnsmpn.properties

cd /home/srvc_nextgen_hpro/nonSAPSScripts

/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --deploy-mode cluster --principal srvc_nextgen_hpro@EAPPRD.HPEIT.HPE.COM --keytab /etc/security/keytabs/srvc_nextgen_hpro.keytab --conf spark.app.name=ServiceCost_drd_cnsmpn --conf spark.dynamicAllocation.initialExecutors=3 --conf spark.dynamicAllocation.maxExecutors=5 --conf spark.dynamicAllocation.cachedExecutorIdleTimeout=60 --conf spark.dynamicAllocation.enabled=true --conf spark.sql.crossJoin.enabled=true --files talend_kfk_keystore.jks,talend_kfk_truststore.jks,/usr/hdp/current/spark-client/conf/hive-site.xml  --jars /usr/hdp/current/spark-client/lib/datanucleus-rdbms-3.2.9.jar,/usr/hdp/current/spark-client/lib/datanucleus-api-jdo-3.2.6.jar,/usr/hdp/current/spark-client/lib/datanucleus-core-3.2.10.jar,./spark-streaming-kafka-0-10_2.11-2.1.0.jar,./kafka_2.11-0.10.2.1.jar,./kafka-clients-0.10.2.1.jar,./json-path-2.2.0.jar,./DataQuality.jar,./json2flat-1.0.3.jar,./gson-2.8.3-SNAPSHOT.jar --num-executors 3 --driver-memory 12g --executor-memory 15g --total-executor-cores 20  --queue ${queueName} --class main.scala.com.hpe.batch.driver.StreamingNonStreamingHandShake EAP_Pipeline_Consumption-2.2.0_final_v0_1.jar ${nameNode_1}/user/${userName_1}/properties/ServiceCost_drd_cnsmpn.properties


if [[ $? -eq 0 ]];then
        echo "ServiceCost_drd dimension load run sucessfully"
else
        echo "issue occur while triggering the ServiceCost_drd dimension load"
        exit 1
fi

# -----------------------------------------------------------------
# get count of records from all .dat files
# -----------------------------------------------------------------

#get count of drd ref
drd_ref_count=`hadoop fs -cat ${DXC_FILES}/*CST_DRD*.dat | wc -l`
echo "${drd_ref_count}"

#get count of mtr ref
mtr_ref_count=`hadoop fs -cat ${DXC_FILES}/*CST_MTR*.dat | wc -l`
echo "${mtr_ref_count}"

#get count of mcc ref
mcc_ref_count=`hadoop fs -cat ${DXC_FILES}/*CST_MCC*.dat | wc -l`
echo "${mcc_ref_count}"

#total records count (drd+mcc+mtr)
Record_count=`expr ${drd_ref_count} + ${mtr_ref_count} + ${mcc_ref_count}`
echo "${Record_count}"

# -----------------------------------------------------------------
# Processed files name
# -----------------------------------------------------------------

#get the names of all zip files in single variable
get_file_names=`ls -ltr ${HDFS_DXC_PATH_LOCAL}/*.zip | awk '{print $9}' | xargs -n 1 basename`
echo "${get_file_names}"

processed_file_name=`echo ${get_file_names} | sed "s/\n//"`
echo ${processed_file_name}

# -----------------------------------------------------------------
# Audit table entry
# -----------------------------------------------------------------

beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "INSERT INTO TABLE ${db_Name}.audit_internal_eap VALUES ('OUTPUT','${recent_timestamp}','${recent_date}','${processed_file_name}','${Record_count}');"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
	echo "The hive query succeeded"
else
	echo "The hive query failed"
	exit 1
fi

#-----------------------------------------------------------
#cost margin (consider only MTR)
#-----------------------------------------------------------

#create static partition in ServiceCost_cost_margin table
beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "Alter table ${db_Name}.ServiceCost_cost_margin ADD IF NOT EXISTS PARTITION(ins_gmt_dt='${max_part_mtr}');"

# put data from latest partition from from ServiceCost_mtr_intrmdt_ref to ServiceCost_cost_margin where stts ='NOT_FOUND'
beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "INSERT OVERWRITE TABLE ${db_Name}.ServiceCost_cost_margin PARTITION(ins_gmt_dt='${max_part_mtr}') SELECT distinct e1edka1_ctry_ky_cd,price_descriptor,zord_item01_inctrms_prt_1_cd,e1edp01_idoc_mtrl_id_nm,option,mcc,query_date,elmt_typ,stts,amt,e1edk01_curr_cd,sprt_sfx_identifierspn_op,metric,src_sys_key,lgcl_dlt_flg_ind,actv_flg_ind,src_sys_update_timestamp,md_of_trnsp,intgtn_fbrc_msg_id,src_sys_upd_ts, src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr FROM ${db_Name}.ServiceCost_mtr_intrmdt_ref where ((stts ='NOT_FOUND') AND (ins_gmt_dt='${max_part_mtr}'));"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
	echo "data sucessfully transfered from ${db_Name}.ServiceCost_mtr_intrmdt_ref to ${db_Name}.ServiceCost_cost_margin"
else
	echo "issue while transfer of data from ${db_Name}.ServiceCost_mtr_intrmdt_ref to ${db_Name}.ServiceCost_cost_margin"
	exit 1
fi


#check the sequence of zip file processed recently
#if zip file name contains 13 then we need to create a zip file and send all the records having stts=NOT_FOUND to DXC team
if [[ ${processed_file_name} == *".13."* ]]; then
	{	 
		#run cost_margin_zip_creation_shell_script
		sh -x ${ROOT_PATH}/scripts/serviceCost_margin_zip_creation.sh
		
		if [[ $? -eq 0 ]];then
			echo "serviceCost_margin_zip_creation.sh run successfully"
		else
			echo "serviceCost_margin_zip_creation.sh failed"
			exit 1
		fi
	}
else
	{
		echo " Cost Margin zip creation is N/A"
	}
fi

# -----------------------------------------------------------------
# Archiving source zip file
# Archiving the source zip file from ${OUTBOUND_PATH} to ${ARCHIVE_PATH}
# -----------------------------------------------------------------

hadoop fs -put -f ${OUTBOUND_PATH}/*.zip ${ARCHIVE_PATH}/

if [[ $? -eq 0 ]];then
        echo "zip files successfully copied from ${OUTBOUND_PATH}/ TO ${ARCHIVE_PATH}/ Path"
        rm -r ${OUTBOUND_PATH}/*.zip
else
        echo "issue occur while copying files from ${OUTBOUND_PATH}/ TO ${ARCHIVE_PATH}/ Path"
        exit 1
fi


# -----------------------------------------------------------------
# serviceCost_output.sh script end time 
# -----------------------------------------------------------------

job_End_Time=$(date +"%s"); date
echo ${job_End_Time}

# -----------------------------------------------------------------
# total time elapsed by serviceCost_output.sh script 
# -----------------------------------------------------------------

diff=$((${job_End_Time}-${job_Start_Time}))
echo ${diff}

running_Hours=$((${diff} / 3600))
echo ${running_Hours}

running_Minutes=$(((${diff} % 3600) / 60))
echo ${running_Minutes}

running_Seconds=$((${diff} % 60))
echo ${running_Seconds}

elapsed_Time_Taken="$(echo "Elapsed time taken by serviceCost_output.sh = ${running_Hours} HOURS :: ${running_Minutes} MINUTES :: ${running_Seconds} SECONDS")"

echo "---------------------------END-of-Script----------------------------------------------------------"
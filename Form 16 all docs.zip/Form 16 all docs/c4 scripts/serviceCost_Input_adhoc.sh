#!/bin/bash
# ************************************************************** #
# ********* Copyright 2020 HPE. All Rights Reserved ************ #
# ***** Environment setup is based on directory structure ****** #
# ************************************************************** #
# Please edit environmental variables setup before execute this shell script as these varibles is for user authentication purpose
# @Author Sahil Agnihotri
# @Team HPE-NGIT Hive Team

# -----------------------------------------------------------------
# Script Description
# go to path : cd /home/srvc_nextgen_hpro/Service_Cost_object/scripts and trigger below script
# Trigger script as: sh -x serviceCost_Input_adhoc.sh
# -----------------------------------------------------------------
# This script read the data from order tables and create a zip file that will share to DXC team
# output of this script is generated at below path
# /user/srvc_ima_platform/R2_3/Ingestion/Services/ServicesCostLR1/IF/Inbound

# -----------------------------------------------------------------
# environmental variables setup
# -----------------------------------------------------------------

. /home/srvc_nextgen_hpro/Service_Cost_object/config/serviceCost_env.properties

# -----------------------------------------------------------------
# Directories creation and variable initialisation
# -----------------------------------------------------------------

#creating local and hdfs root path
mkdir -p /home/srvc_nextgen_hpro/Service_Cost_object
mkdir -p /home/srvc_nextgen_hpro/Service_Cost_object/inp_files
mkdir -p /home/srvc_nextgen_hpro/Service_Cost_object/zip_files
hadoop fs -mkdir -p /tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object/Service_Cost_data_set

#changing permissions to 777
chmod -R 777 /home/srvc_nextgen_hpro/Service_Cost_object
hadoop fs -chmod -R 777 /tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object

#variable initialisation
ROOT_PATH=/home/srvc_nextgen_hpro/Service_Cost_object
HDFS_ROOT_PATH=${nameNode_1}/tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object
HDFS_ROOT_PATH_LOCAL=/HDFS_ROOT/tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object

INP_FILES=/home/srvc_nextgen_hpro/Service_Cost_object/inp_files
ZIP_FILES=/home/srvc_nextgen_hpro/Service_Cost_object/zip_files

INBOUND_PATH=/data/01/srvc_ima_platform/EA/DropLocation/Services/EAI3167_ServicesCost/Inbound


#logs creation
mkdir -p ${ROOT_PATH}/logs
chmod -R 777 ${ROOT_PATH}/logs

LOG_PATH=${ROOT_PATH}/logs
LOG_FILE=${LOG_PATH}/Service_Cost_input_$(date +%Y%m%d%H%M%S0000).log

exec >>${LOG_FILE}
exec 2>>${LOG_FILE}

recent_timestamp=$(date +"%Y%m%d.%H%M%S")
echo "${recent_timestamp}"

recent_date=$(date +"%Y%m%d")
echo "${recent_date}"

# -----------------------------------------------------------------
# Kinit setup
# -----------------------------------------------------------------

kinit -V -kt /etc/security/keytabs/${userName_1}.keytab ${userName_1}@${kPrincipal_1}

# -----------------------------------------------------------------
# serviceCost_Input.sh script start time
# -----------------------------------------------------------------

job_Start_Time=$(date +"%s"); date
echo ${job_Start_Time}

# -----------------------------------------------------------------
#Remove already existing inp and zip files from local directory
# -----------------------------------------------------------------

rm -r ${INP_FILES}/*
rm -r ${ZIP_FILES}/*

#Remove service_cost_final_data_set.txt and *.inp files from ${HDFS_ROOT_PATH}/Service_Cost_data_set/ folder
hadoop fs -rm -r ${HDFS_ROOT_PATH}/Service_Cost_data_set/service_cost_final_data_set.txt
hadoop fs -rm -r ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.deflate
hadoop fs -rm -r ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.inp

# -----------------------------------------------------------------
# Beeline connection string setup
# -----------------------------------------------------------------

beelineUrl="jdbc:hive2://hnr01n01.hpeit.hpecorp.net:2181,hnr02n01.hpeit.hpecorp.net:2181,hnr03n01.hpeit.hpecorp.net:2181,hnr02n02.hpeit.hpecorp.net:2181,hnr01n03.hpeit.hpecorp.net:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2?tez.queue.name=${queueName}"


echo ${beelineUrl}

# -----------------------------------------------------------------
#track the run sequence (this should be between 1-12)
# -----------------------------------------------------------------

if [ -s ${ROOT_PATH}/run_sequence.txt ]; then
        {
                echo "file exist"
                seq=`cat ${ROOT_PATH}/run_sequence.txt`
                echo "${seq}"
        }
else
        {
                echo "file not exist"
                seq=1
                echo "${seq}" >${ROOT_PATH}/run_sequence.txt
                chmod 777 ${ROOT_PATH}/run_sequence.txt
        }
fi

# -----------------------------------------------------------------
# getting ins_gmt_ts for ${db_Name}.Ord_itm_ref
# -----------------------------------------------------------------

if [ -s ${ROOT_PATH}/Ord_itm_ref.txt ]; then
        {
                echo "file exist"
                max_ins_gmt_ts_1=`cat ${ROOT_PATH}/Ord_itm_ref.txt`
                echo "${max_ins_gmt_ts_1}"
        }
else
        {
                echo "file not exist"
                max_ins_gmt_ts_1="1950-01-01 00:00:00.0"
                echo "${max_ins_gmt_ts_1}" >${ROOT_PATH}/Ord_itm_ref.txt
                chmod 777 ${ROOT_PATH}/Ord_itm_ref.txt
        }
fi

# -----------------------------------------------------------------
# getting ins_gmt_ts for ${db_Name}.OPE_PS_REF table
# -----------------------------------------------------------------

if [ -s ${ROOT_PATH}/Ope_ps_ref.txt ]; then
        {
                echo "file exist"
                max_ins_gmt_ts_2=`cat ${ROOT_PATH}/Ope_ps_ref.txt`
                echo "${max_ins_gmt_ts_2}"
        }
else
        {
                echo "file not exist"
                max_ins_gmt_ts_2="1950-01-01 00:00:00.0"
                echo "${max_ins_gmt_ts_2}" >${ROOT_PATH}/Ope_ps_ref.txt
                chmod 777 ${ROOT_PATH}/Ope_ps_ref.txt
        }
fi


# -----------------------------------------------------------------
# Load data from orders and for zyme into one single table
# ${db_Name}.service_cost_and_zyme_intermediate
# -----------------------------------------------------------------

# load all required data from different orders tables to intermediate table

beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --hiveconf hive.auto.convert.join=true --showHeader=false --outputformat=tsv2 -e "INSERT OVERWRITE TABLE ${db_Name}.service_cost_and_zyme_intermediate select distinct a.e1edka1_ctry_ky_cd_AG as country_code, from_unixtime(unix_timestamp(current_date, 'yyyy-MM-dd'),'yyyy/MM/dd') AS query_date, case when trim(upper(f.mtrl_sls_mtrl_itm_cgy_grp_cd)) IN ('ZMCP') then g.e1edp19_idoc_mtrl_i_1_nm_2 when isnull(split(b.e1edp19_idoc_mtrl_i_1_nm_2,'#')[0]) then b.e1edp19_idoc_mtrl_i_1_nm_2 else (split(b.e1edp19_idoc_mtrl_i_1_nm_2,'#')[0]) end  as material_id, split(b.e1edp19_idoc_mtrl_i_1_nm_2,'#')[1] as Opt, NULL AS spn, case when trim(upper(f.mtrl_sls_mtrl_itm_cgy_grp_cd)) IN ('ZMCP') and substr(b.e1edp19_idoc_mtrl_i_1_nm_2,1,1) IN ('M') then substr(b.e1edp19_idoc_mtrl_i_1_nm_2,2)  else null end  as Mcc, concat(coalesce(a.e1edka1_ctry_ky_cd_AG,''),coalesce(e.currency_code,''), coalesce(d.prcng_lst_typ,'DP')) as Price_descriptor, d.zord_item01_inctrms_prt_1_cd as delivery_method, '?' AS MOT, 'USD'as output_currency, 'TCOS' as Metric from (select * from ea_common.Ord_itm_ref where to_date(ins_gmt_ts) >= '2020-04-01') d left join ea_common.Ord_mtrl_ref b on (d.idoc_nr=b.idoc_nr) and(d.e1edk01_idoc_dcmt_nr=b.e1edk01_idoc_dcmt_nr) and d.e1edp01_itm_nr =b.e1edp01_itm_nr left join ea_common.ord_pttnr_hddr_ref a on  (d.idoc_nr=a.idoc_nr) and(d.e1edk01_idoc_dcmt_nr=a.e1edk01_idoc_dcmt_nr) left join ea_common.Ord_hddr_ref c on (d.idoc_nr=c.idoc_nr) and(d.e1edk01_idoc_dcmt_nr=c.e1edk01_idoc_dcmt_nr) Left join ea_common.bmt_service_cost_currency_code_dmnsn e on (c.e1edk01_curr_cd = e.iso_currency_code ) left join ea_common.pdm_mtrl_sls_grp_dmnsn f on (f.mtrl_sls_mtrl_id  = b.e1edp19_idoc_mtrl_i_1_nm_2 ) and (f.mtrl_sls_sls_org_cd = c.e1edk14_idoc_org_nm_8) left join ea_common.ord_mtrl_ref g on  concat_ws('-',d.idoc_nr,d.e1edk01_idoc_dcmt_nr,d.e1edp01_higherlevel_itm_bom_structures_cd) =concat_ws('-',g.idoc_nr,g.e1edk01_idoc_dcmt_nr,g.e1edp01_itm_nr) WHERE (e.currency_code IS NOT NULL);"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
        echo "The hive query succeeded"
else
        echo "The hive query failed"
        exit 1
fi

#load all the required data into ${db_Name}.service_cost_and_zyme_intermediate table
beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --hiveconf hive.auto.convert.join=true --showHeader=false --outputformat=tsv2 -e "INSERT INTO ${db_Name}.service_cost_and_zyme_intermediate select DISTINCT A.ope_ctry_cd AS country_code, from_unixtime(unix_timestamp(A.trs_1_dt, 'yyyy-MM-dd'),'yyyy/MM/dd') AS query_date, case when isnull(split(A.hpe_prod_i_1_id,'#')[0]) then A.hpe_prod_i_1_id else (split(A.hpe_prod_i_1_id,'#')[0]) end  AS material_id, split(A.hpe_prod_i_1_id,'#')[1] AS Opt, NULL AS spn, NULL AS mcc, concat(coalesce(A.ope_ctry_cd,''),'UD','DP') as Price_descriptor, 'DDP' as delivery_method, '?' AS MOT, 'USD' as output_currency, 'TCOS' as Metric from (select * from ${db_Name}.OPE_PS_REF where to_date(ins_gmt_ts) >= '2020-04-01') A JOIN ${db_Name}.bmt_gbl_carepack_dmnsn B ON A.hpe_prod_i_1_id=B.mfrg_prod_id where (A.ope_ctry_cd IS NOT NULL);"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
        echo "The hive query succeeded"
else
        echo "The hive query failed"
        exit 1
fi

# -----------------------------------------------------------------
# load data from ${db_Name}.service_cost_and_zyme_intermediate
# and store into '|' separated .txt file placed at hdfs path {HDFS_ROOT_PATH}/Service_Cost_data_set/
# remove all NULL from file
# -----------------------------------------------------------------

intermediate_table_count=$(beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "select count(*) from ${db_Name}.service_cost_and_zyme_intermediate;")

echo "${intermediate_table_count}"

if [ "${intermediate_table_count}" = "0" ];then
        {
                #create a dummy empty .inp file
                touch ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}.${recent_timestamp}.inp
                chmod 777 ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}.${recent_timestamp}.inp
                # number of records available in the created file
                Record_count=0
                echo "Record_count:${Record_count}"
        }
else
        {
                beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "INSERT OVERWRITE DIRECTORY '${HDFS_ROOT_PATH}/Service_Cost_data_set/' ROW FORMAT DELIMITED FIELDS TERMINATED BY '|' NULL DEFINED AS '' select * from ${db_Name}.service_cost_and_zyme_intermediate WHERE ((country_code IS NOT NULL) AND (query_date IS NOT NULL) AND (material_id IS NOT NULL) AND (Price_descriptor IS NOT NULL) AND (delivery_method IS NOT NULL) AND (output_currency IS NOT NULL) AND (Metric IS NOT NULL));"

                status=$?
                echo "The hive query status is ${status}"
                if test ${status} -eq 0
                then
                        echo "The hive query succeeded"
                else
                        echo "The hive query failed"
                        exit 1
                fi

                #converting all *.deflate files to .txt file
                hadoop fs -text ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.deflate | hadoop fs -put -f - ${HDFS_ROOT_PATH}/Service_Cost_data_set/service_cost_final_data_set.txt

                if [[ $? -eq 0 ]];then
                        {
                                echo "deflate file is successfully converted to txt files"
                                hadoop fs -chmod 777 ${HDFS_ROOT_PATH}/Service_Cost_data_set/service_cost_final_data_set.txt
                                hadoop fs -rm -r ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.deflate
                        }
                else
                        {
                                echo "error occur while converting deflate file to .txt file"
                        }
                fi

                # -----------------------------------------------------------------
                # file splitting logic
                # if Record_count = 1000000 then split the files
                # -----------------------------------------------------------------

                # number of records available in the created file
                Record_count=`hadoop fs -cat ${HDFS_ROOT_PATH}/Service_Cost_data_set/service_cost_final_data_set.txt | wc -l`
                echo "Record_count:${Record_count}"

                split_count_baseline=1000000
                echo "${split_count_baseline}"

                if [ "${seq}" = "1" ];then
                {
					if [ "${Record_count}" -le "${split_count_baseline}" ];then
                        {
                                mv ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/service_cost_final_data_set.txt ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST_NEW.1.${recent_timestamp}.inp
                        }
					else
                        {
                                split -l ${split_count_baseline} ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/service_cost_final_data_set.txt
                                i=97
                                for x in `ls x* | sort`
                                        do
                                            j=$(echo $i | awk '{printf("%c",$1)}')
                                            echo $j
                                            mv $x ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST_NEW.1$j.${recent_timestamp}.inp
                                            chmod 777 ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST_NEW.1$j.${recent_timestamp}.inp
                                            i=$(($i+1))
                                        done
                        }
					fi
				}
				else
				{
					if [ "${Record_count}" -le "${split_count_baseline}" ];then
                        {
                                mv ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/service_cost_final_data_set.txt ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}.${recent_timestamp}.inp
                        }
					else
                        {
                                split -l ${split_count_baseline} ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/service_cost_final_data_set.txt
                                i=97
                                for x in `ls x* | sort`
                                        do
                                              j=$(echo $i | awk '{printf("%c",$1)}')
                                              echo $j
                                              mv $x ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}$j.${recent_timestamp}.inp
                                              chmod 777 ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}$j.${recent_timestamp}.inp
                                              i=$(($i+1))
                                        done
                        }
					fi
				}
				fi
        }
fi

# copy all .inp files from HDFS path to local path

hadoop fs -copyToLocal ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.inp ${INP_FILES}/

if [[ $? -eq 0 ]];then
        echo "inp files successfully copied from ${HDFS_ROOT_PATH} TO ${INP_FILES} Path"
        chmod 777 ${INP_FILES}/*.inp
else
        echo "issue occur while copying files from ${HDFS_ROOT_PATH} TO ${INP_FILES} Path"
        exit 1
fi

# -----------------------------------------------------------------
# creating zip file which will act as input file for DXC
# -----------------------------------------------------------------

#count number of .inp files present in ${INP_FILES}/
inp_file_count=`hdfs dfs -ls  ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.inp -R 2>/dev/null | grep -E '^-' | wc -l`
echo "${inp_file_count}"

if [ "${inp_file_count}" = "1" ];then
        {

                if [ "${seq}" = "1" ];then
                {
                        echo "seq is : $seq"
						cd ${INP_FILES}/
                        zip -r T.EAP.FWD_CST_NEW.1.${recent_timestamp}.zip *.inp
                                if [[ $? -eq 0 ]];then
                                        {
                                                echo "zip file created sucessfully"
												mv *.zip ${ZIP_FILES}/
                                        }
                                else
                                        {
                                                echo "error occur while creating zip file"
                                        }
                                fi
                }
                else
                {
                        echo "seq is : $seq"
						cd ${INP_FILES}/
                        zip -r T.EAP.FWD_CST.${seq}.${recent_timestamp}.zip *.inp
                                if [[ $? -eq 0 ]];then
                                        {
                                                echo "zip file created sucessfully"
												mv *.zip ${ZIP_FILES}/
                                        }
                                else
                                        {
                                                echo "error occur while creating zip file"
                                        }
                                fi
                }
                fi

        }
else
        {
                if [ "${seq}" = "1" ];then
                {
						cd ${INP_FILES}/
                        FILES=*
                        m=97
                        for f in $FILES
                                do
                                        n=$(echo $m | awk '{printf("%c",$1)}')
                                        echo $n
                                        zip -r T.EAP.FWD_CST_NEW.1$n.${recent_timestamp}.zip $f
										mv T.EAP.FWD_CST_NEW.1$n.${recent_timestamp}.zip ${ZIP_FILES}/
                                        m=$(($m+1))
                                done
                }
                else
                {
						cd ${INP_FILES}/
                        echo "seq is : $seq"
                        FILES=*
                        m=97
                        for f in $FILES
                                do
                                        n=$(echo $m | awk '{printf("%c",$1)}')
                                        echo $n
                                        zip -r T.EAP.FWD_CST.${seq}$n.${recent_timestamp}.zip $f
										mv T.EAP.FWD_CST.${seq}$n.${recent_timestamp}.zip ${ZIP_FILES}/
                                        m=$(($m+1))
                                done
                }
                fi

        }
fi

# -----------------------------------------------------------------
# Put zip file from ${ZIP_FILES}/ path to ${INBOUND_PATH}/ path
# -----------------------------------------------------------------

chmod 777 ${ZIP_FILES}/*.zip

#get the names of all zip files in single variable
get_file_names=`ls -ltr ${ZIP_FILES}/*.zip | awk '{print $9}' | xargs -n 1 basename`
echo "${get_file_names}"

file_name=`echo ${get_file_names} | sed "s/\n//"`
echo ${file_name}

cp -f ${ZIP_FILES}/*.zip ${INBOUND_PATH}/

if [[ $? -eq 0 ]];then
        echo "inp files successfully copied from ${ZIP_FILES}/ TO ${INBOUND_PATH}/ Path"
        chmod 777 ${INBOUND_PATH}/*.zip
else
        echo "issue occur while copying files from ${ZIP_FILES}/ TO ${INBOUND_PATH}/ Path"
        exit 1
fi

# -----------------------------------------------------------------
#changing the entry into ${ROOT_PATH}/run_sequence.txt for next run:
# -----------------------------------------------------------------

seq_next=$(($seq+1))

if [ "${seq}" -ge "12" ];then
        {
                rm -r ${ROOT_PATH}/run_sequence.txt
        }
else
        {
                seq_next=$(($seq+1))
                echo "${seq_next}" >${ROOT_PATH}/run_sequence.txt
        }
fi

#-----------------------------------------------------------------
#changing the entry into ${ROOT_PATH}/Ord_itm_ref.txt for next run:
#-----------------------------------------------------------------

beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "select max(ins_gmt_ts) from  ${db_Name}.Ord_itm_ref limit 1;" >${ROOT_PATH}/Ord_itm_ref.txt

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
        echo "The hive query succeeded"
else
        echo "The hive query failed"
        exit 1
fi

#-----------------------------------------------------------------
#changing the entry into ${ROOT_PATH}/Ope_ps_ref.txt for next run:
#-----------------------------------------------------------------

beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "select max(ins_gmt_ts) from  ${db_Name}.Ope_ps_ref limit 1;" >${ROOT_PATH}/Ope_ps_ref.txt

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
        echo "The hive query succeeded"
else
        echo "The hive query failed"
        exit 1
fi

# -----------------------------------------------------------------
# Audit table entry
# -----------------------------------------------------------------

beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "INSERT INTO TABLE ${db_Name}.audit_internal_eap VALUES ('INPUT','${recent_timestamp}','${recent_date}','${file_name}','${Record_count}');"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
        echo "The hive query succeeded"
else
        echo "The hive query failed"
        exit 1
fi

# -----------------------------------------------------------------
# serviceCost_Input.sh script end time
# -----------------------------------------------------------------

job_End_Time=$(date +"%s"); date
echo ${job_End_Time}

# -----------------------------------------------------------------
# total time elapsed by serviceCost_Input.sh script
# -----------------------------------------------------------------

diff=$((${job_End_Time}-${job_Start_Time}))
echo ${diff}

running_Hours=$((${diff} / 3600))
echo ${running_Hours}

running_Minutes=$(((${diff} % 3600) / 60))
echo ${running_Minutes}

running_Seconds=$((${diff} % 60))
echo ${running_Seconds}

elapsed_Time_Taken="$(echo "Elapsed time taken by serviceCost_Input.sh = ${running_Hours} HOURS :: ${running_Minutes} MINUTES :: ${running_Seconds} SECONDS")"

echo "END-of-Script:--> Please check the output files at path: ${INBOUND_PATH}/"
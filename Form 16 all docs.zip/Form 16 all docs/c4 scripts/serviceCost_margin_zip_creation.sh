#!/bin/bash
# ************************************************************** #
# ********* Copyright 2020 HPE. All Rights Reserved ************ #
# ***** Environment setup is based on directory structure ****** #
# ************************************************************** #
# Please edit environmental variables setup before execute this shell script as these varibles is for user authentication purpose
# @Author Sahil Agnihotri
# @Team HPE-NGIT Hive Team

# -----------------------------------------------------------------
# Script Description
# -----------------------------------------------------------------
# This script is triggered by serviceCost_output.sh and create a cost margin zip file that will share to DXC team
# output of this script is generated at below path
# /user/srvc_ima_platform/R2_3/Ingestion/Services/ServicesCostLR1/IF/Inbound

# -----------------------------------------------------------------
# environmental variables setup
# -----------------------------------------------------------------

. /home/srvc_nextgen_hpro/Service_Cost_object/config/serviceCost_env.properties

# -----------------------------------------------------------------
# Directories creation and variable initialisation
# -----------------------------------------------------------------

#changing permissions to 777
chmod -R 777 /home/srvc_nextgen_hpro/Service_Cost_object
hadoop fs -chmod -R 777 /tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object

#variable initialisation
ROOT_PATH=/home/srvc_nextgen_hpro/Service_Cost_object
HDFS_ROOT_PATH=${nameNode_1}/tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object
HDFS_ROOT_PATH_LOCAL=/HDFS_ROOT/tmp/opt/mount/talend_conf/nonSAPScripts/Service_Cost_object

INP_FILES=/home/srvc_nextgen_hpro/Service_Cost_object/inp_files
ZIP_FILES=/home/srvc_nextgen_hpro/Service_Cost_object/zip_files

INBOUND_PATH=/data/01/srvc_ima_platform/EA/DropLocation/Services/EAI3167_ServicesCost/Inbound


#logs creation
chmod -R 777 ${ROOT_PATH}/logs

LOG_PATH=${ROOT_PATH}/logs
LOG_FILE=${LOG_PATH}/Service_Cost_margin_$(date +%Y%m%d%H%M%S0000).log

exec >>${LOG_FILE}
exec 2>>${LOG_FILE}

recent_timestamp=$(date +"%Y%m%d.%H%M%S")
echo "${recent_timestamp}"

recent_date=$(date +"%Y%m%d")
echo "${recent_date}"

# -----------------------------------------------------------------
# Kinit setup
# -----------------------------------------------------------------

kinit -V -kt /etc/security/keytabs/${userName_1}.keytab ${userName_1}@${kPrincipal_1}

# -----------------------------------------------------------------
# serviceCost_margin_zip_creation.sh script start time
# -----------------------------------------------------------------

job_Start_Time=$(date +"%s"); date
echo ${job_Start_Time}

# -----------------------------------------------------------------
#Remove already existing inp and zip files from local directory
# -----------------------------------------------------------------

seq=14
echo "${seq}"

rm -r ${INP_FILES}/*
rm -r ${ZIP_FILES}/*

#Remove service_cost_final_data_set.txt and *.inp files from ${HDFS_ROOT_PATH}/Service_Cost_data_set/ folder
hadoop fs -rm -r ${HDFS_ROOT_PATH}/Service_Cost_data_set/service_cost_final_data_set.txt
hadoop fs -rm -r ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.deflate
hadoop fs -rm -r ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.inp

# -----------------------------------------------------------------
# Beeline connection string setup
# -----------------------------------------------------------------

beelineUrl="jdbc:hive2://hnr01n01-i.hpeit.hpecorp.net:2181,hnr01n02-i.hpeit.hpecorp.net:2181,hnr02n02-i.hpeit.hpecorp.net:2181,hnr01n03-i.hpeit.hpecorp.net:2181,hnr02n03-i.hpeit.hpecorp.net:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2?tez.queue.name=${queueName}"

echo ${beelineUrl}

# -----------------------------------------------------------------
# Load data from max partition of ${db_Name}.ServiceCost_cost_margin
# -----------------------------------------------------------------

#get latest partition from ServiceCost_cost_margin table
max_part_cst_mrgn=`beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2  -e "select max(ins_gmt_dt) from ${db_Name}.ServiceCost_cost_margin;"`
echo "${max_part_cst_mrgn}"

# load all required data to intermediate table

beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "INSERT OVERWRITE TABLE ${db_Name}.service_cost_and_zyme_intermediate select distinct e1edka1_ctry_ky_cd AS country_code, from_unixtime(unix_timestamp(query_date, 'yyyy-MM-dd'),'yyyy/MM/dd') AS query_date, e1edp01_idoc_mtrl_id_nm AS material_id, option AS opt, sprt_sfx_identifierspn_op AS spn, mcc AS Mcc, price_descriptor AS Price_descriptor, zord_item01_inctrms_prt_1_cd AS delivery_method, md_of_trnsp AS MOT, e1edk01_curr_cd AS output_currency,metric AS Metric from ${db_Name}.ServiceCost_cost_margin WHERE (ins_gmt_dt='${max_part_cst_mrgn}');"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
        echo "The hive query succeeded"
else
        echo "The hive query failed"
        exit 1
fi

# -----------------------------------------------------------------
# load data from ${db_Name}.service_cost_and_zyme_intermediate
# and store into '|' separated .txt file placed at hdfs path {HDFS_ROOT_PATH}/Service_Cost_data_set/
# remove all NULL from file
# -----------------------------------------------------------------

intermediate_table_count=$(beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "select count(*) from ${db_Name}.service_cost_and_zyme_intermediate;")

echo "${intermediate_table_count}"

if [ "${intermediate_table_count}" = "0" ];then
        {
                #create a dummy empty .inp file
                touch ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}.${recent_timestamp}.inp
                chmod 777 ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}.${recent_timestamp}.inp
                # number of records available in the created file
                Record_count=0
                echo "Record_count:${Record_count}"
        }
else
        {
                beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "INSERT OVERWRITE DIRECTORY '${HDFS_ROOT_PATH}/Service_Cost_data_set/' ROW FORMAT DELIMITED FIELDS TERMINATED BY '|' NULL DEFINED AS '' select * from ${db_Name}.service_cost_and_zyme_intermediate WHERE ((country_code IS NOT NULL) AND (query_date IS NOT NULL) AND (material_id IS NOT NULL) AND (Price_descriptor IS NOT NULL) AND (delivery_method IS NOT NULL) AND (output_currency IS NOT NULL) AND (Metric IS NOT NULL));"

                status=$?
                echo "The hive query status is ${status}"
                if test ${status} -eq 0
                then
                        echo "The hive query succeeded"
                else
                        echo "The hive query failed"
                        exit 1
                fi

                #converting all *.deflate files to .txt file
                hadoop fs -text ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.deflate | hadoop fs -put -f - ${HDFS_ROOT_PATH}/Service_Cost_data_set/service_cost_final_data_set.txt

                if [[ $? -eq 0 ]];then
                        {
                                echo "deflate file is successfully converted to txt files"
                                hadoop fs -chmod 777 ${HDFS_ROOT_PATH}/Service_Cost_data_set/service_cost_final_data_set.txt
                                hadoop fs -rm -r ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.deflate
                        }
                else
                        {
                                echo "error occur while converting deflate file to .txt file"
                        }
                fi

                # -----------------------------------------------------------------
                # file splitting logic
                # if Record_count = 1000000 then split the files
                # -----------------------------------------------------------------

                # number of records available in the created file
                Record_count=`hadoop fs -cat ${HDFS_ROOT_PATH}/Service_Cost_data_set/service_cost_final_data_set.txt | wc -l`
                echo "Record_count:${Record_count}"

                split_count_baseline=1000000
                echo "${split_count_baseline}"

                if [ "${Record_count}" -le "${split_count_baseline}" ];then
                        {
                                mv ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/service_cost_final_data_set.txt ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}.${recent_timestamp}.inp
                        }
                else
                        {
                                split -l ${split_count_baseline} ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/service_cost_final_data_set.txt
                                i=97
                                for x in `ls x* | sort`
                                        do
                                                j=$(echo $i | awk '{printf("%c",$1)}')
                                                echo $j
                                                mv $x ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}$j.${recent_timestamp}.inp
                                                chmod 777 ${HDFS_ROOT_PATH_LOCAL}/Service_Cost_data_set/T.EAP.FWD_CST.${seq}$j.${recent_timestamp}.inp
                                                i=$(($i+1))
                                        done
                        }
                fi
        }
fi

# copy all .inp files from HDFS path to local path

hadoop fs -copyToLocal ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.inp ${INP_FILES}/

if [[ $? -eq 0 ]];then
        echo "inp files successfully copied from ${HDFS_ROOT_PATH} TO ${INP_FILES} Path"
        chmod 777 ${INP_FILES}/*.inp
else
        echo "issue occur while copying files from ${HDFS_ROOT_PATH} TO ${INP_FILES} Path"
        exit 1
fi

# -----------------------------------------------------------------
# creating zip file which will act as input file for DXC
# -----------------------------------------------------------------

#count number of .inp files present in ${INP_FILES}/
inp_file_count=`hdfs dfs -ls  ${HDFS_ROOT_PATH}/Service_Cost_data_set/*.inp -R 2>/dev/null | grep -E '^-' | wc -l`
echo "${inp_file_count}"

if [ "${inp_file_count}" = "1" ];then
        {

            echo "seq is : $seq"
			cd ${INP_FILES}/
            zip -r T.EAP.FWD_CST.${seq}.${recent_timestamp}.zip *.inp
            if [[ $? -eq 0 ]];then
                {
                    echo "zip file created sucessfully"
					mv *.zip ${ZIP_FILES}/
                }
            else
                {
                    echo "error occur while creating zip file"
                }
            fi

        }
else
        {
			cd ${INP_FILES}/
            echo "seq is : $seq"
            FILES=*
            m=97
            for f in $FILES
                do
                    n=$(echo $m | awk '{printf("%c",$1)}')
                    echo $n
                    zip -r T.EAP.FWD_CST.${seq}$n.${recent_timestamp}.zip $f
					mv T.EAP.FWD_CST.${seq}$n.${recent_timestamp}.zip ${ZIP_FILES}/
                    m=$(($m+1))
                done

        }
fi

# -----------------------------------------------------------------
# Put zip file from ${ZIP_FILES}/ path to ${INBOUND_PATH}/ path
# -----------------------------------------------------------------

chmod 777 ${ZIP_FILES}/*.zip

#get the names of all zip files in single variable
get_file_names=`ls -ltr ${ZIP_FILES}/*.zip | awk '{print $9}' | xargs -n 1 basename`
echo "${get_file_names}"

file_name=`echo ${get_file_names} | sed "s/\n//"`
echo ${file_name}

cp -f ${ZIP_FILES}/*.zip ${INBOUND_PATH}/

if [[ $? -eq 0 ]];then
        echo "inp files successfully copied from ${ZIP_FILES}/ TO ${INBOUND_PATH}/ Path"
        chmod 777 ${INBOUND_PATH}/*.zip
else
        echo "issue occur while copying files from ${ZIP_FILES}/ TO ${INBOUND_PATH}/ Path"
        exit 1
fi

# -----------------------------------------------------------------
# Audit table entry
# -----------------------------------------------------------------

beeline -u ${beelineUrl} --hiveconf hive.execution.engine=tez --hiveconf hive.vectorized.execution.enabled=true --hiveconf hive.vectorized.execution.reduce.enabled=true --showHeader=false --outputformat=tsv2 -e "INSERT INTO TABLE ${db_Name}.audit_internal_eap VALUES ('INPUT','${recent_timestamp}','${recent_date}','${file_name}','${Record_count}');"

status=$?
echo "The hive query status is ${status}"
if test ${status} -eq 0
then
        echo "The hive query succeeded"
else
        echo "The hive query failed"
        exit 1
fi

# -----------------------------------------------------------------
# serviceCost_margin_zip_creation.sh script end time
# -----------------------------------------------------------------

job_End_Time=$(date +"%s"); date
echo ${job_End_Time}

# -----------------------------------------------------------------
# total time elapsed by serviceCost_margin_zip_creation.sh script
# -----------------------------------------------------------------

diff=$((${job_End_Time}-${job_Start_Time}))
echo ${diff}

running_Hours=$((${diff} / 3600))
echo ${running_Hours}

running_Minutes=$(((${diff} % 3600) / 60))
echo ${running_Minutes}

running_Seconds=$((${diff} % 60))
echo ${running_Seconds}

elapsed_Time_Taken="$(echo "Elapsed time taken by serviceCost_margin_zip_creation.sh = ${running_Hours} HOURS :: ${running_Minutes} MINUTES :: ${running_Seconds} SECONDS")"

echo "END-of-Script:--> Please check the output files at path: ${INBOUND_PATH}/"
import time, threading, os

WAIT_SECONDS = 7200
def ScriptRunner():
    os.system('sh -x /home/srvc_nextgen_hpro/Service_Cost_object/scripts/serviceCost_Input.sh')
    threading.Timer(WAIT_SECONDS, ScriptRunner).start()

ScriptRunner()
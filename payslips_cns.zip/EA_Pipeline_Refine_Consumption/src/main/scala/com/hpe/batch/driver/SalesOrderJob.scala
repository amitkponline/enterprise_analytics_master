package main.scala.com.hpe.batch.driver

import main.scala.com.hpe.refconsumption.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import org.apache.spark.sql.functions._
import main.scala.com.hpe.refconsumption.processor._ 
import main.scala.com.hpe.refconsumption.utils.Utilities

object SalesOrderJob extends App{
  
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  val objectType = propertiesObject.getObjectType().trim

  objectType.toLowerCase() match {
    case "cdc"       => new CDCSalesCRC64(auditObj, propertiesObject, spark, sqlCon,auditTbl).run()
    case "noncdc"    => new NonCDCSales(auditObj, propertiesObject, spark, sqlCon,auditTbl).run()
    case "heirarchy" => ""
    case _ =>
      throw new IllegalArgumentException("Incorrect Value for objectType Property in Properties File")
      spark.close()
      sqlCon.close()
  }  
  
  
}
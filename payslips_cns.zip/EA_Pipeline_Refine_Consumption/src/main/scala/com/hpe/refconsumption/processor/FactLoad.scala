package main.scala.com.hpe.refconsumption.processor

import main.scala.com.hpe.refconsumption.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.refconsumption.utils._
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source

object FactLoad {

  val logger = Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {
    if (args == null || args.isEmpty) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
      println("Stopping the flow")
      System.exit(1)
    }

    val propertiesFilePath = String.valueOf(args(0).trim())
    var objectName = propertiesFilePath.substring(propertiesFilePath.lastIndexOf("/") + 1)
    var fileBasePath = String.valueOf(args(1).trim())

    //val propertiesObject: FilePropertiesObject = Utilities.getFilePropertiesobject(propertiesFilePath)

    val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
    val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
    val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"

    val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
    var sqlCon = Utilities.getConnection(envPropertiesObject)
    val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()

    var auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")

    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val fl_nm = objectName + ".hql"
    val sys_btch_nr = objectName
    val auditBatchId = objectName + "_" + Utilities.getCurrentTimestamp("yyyyMMddHHmmssSSS")

    auditObj.setAudBatchId(auditBatchId)
    auditObj.setAudApplicationName("job_EA_FactLoad")
    auditObj.setAudObjectName(objectName)
    auditObj.setAudSrcRowCount(0)
    auditObj.setAudTgtRowCount(0)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm(fl_nm)
    auditObj.setSysBtchNr(sys_btch_nr)
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))

    val spark = configObject.getSpark()

    try {
      val execqueries = Source.fromFile(fileBasePath + "/" + fl_nm).getLines.mkString("\n").split(";")

      var x = ' '
      var i = 1

      for (x <- execqueries) {
        println(i + " query is : " + x)
        i = i + 1
        spark.sql(x)
      }

      if (fileBasePath.contains("consumptionLayerDimensionScriptsDir")) {
        auditObj.setAudDataLayerName("ref_cnsmptn")
      } else if (fileBasePath.contains("consumptionLayerFactScriptsDir")) {
        auditObj.setAudDataLayerName("cnsmptn_fact")
      }
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    } catch {
      case sslException: InterruptedException => {
        logger.error("Interrupted Exception")
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case connException: ConnectException => {
        logger.error("Connection Exception: " + connException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())

        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
      case exception: Exception => {
        logger.error(exception.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        //Check if SQL connection is active
        var sqlCon = Utilities.getConnection(envPropertiesObject)
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        sqlCon.close()
        System.exit(1)
      }
    } finally {
      if (sqlCon != null) {
        sqlCon.close()
      }
    }
  }
}
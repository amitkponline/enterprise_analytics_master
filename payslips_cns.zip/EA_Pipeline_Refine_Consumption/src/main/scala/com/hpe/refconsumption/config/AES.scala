package main.scala.com.hpe.refconsumption.config

import java.io.UnsupportedEncodingException
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.Arrays
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec
//remove if not needed
import scala.collection.JavaConversions._
object AES {
  private var secretKey: SecretKeySpec = _
  private var key: Array[Byte] = _
  def setKey(myKey: String): Unit = {
    var sha: MessageDigest = null
    try {
      key = myKey.getBytes("UTF-8")
      sha = MessageDigest.getInstance("SHA-1")
      key = sha.digest(key)
      key = Arrays.copyOf(key, 16)
      secretKey = new SecretKeySpec(key, "AES")
    } catch {
      case e: NoSuchAlgorithmException => e.printStackTrace()
      case e: UnsupportedEncodingException => e.printStackTrace()
    }
  }

  def decrypt(strToDecrypt: String, secret: String): String = {
   try {
      setKey(secret)
      val cipher: Cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING")
      cipher.init(Cipher.DECRYPT_MODE, secretKey)
      new String(cipher.doFinal(Base64.getDecoder.decode(strToDecrypt)))
   } catch {
      case e: Exception => println("Error while decrypting: " + e.toString)
      null
    }
    
  }

}

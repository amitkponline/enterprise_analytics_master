package main.scala.com.hpe.refconsumption.processor

import main.scala.com.hpe.refconsumption.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.refconsumption.utils._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.types.{ StringType, StructField, StructType }
import scala.collection.mutable
import scala.collection.Seq

class CDCTest(auditObj: main.scala.com.hpe.refconsumption.config.AuditLoadObject, propertiesObject: StreamingPropertiesObject, spark: SparkSession, sqlCon: Connection, auditTbl: String) {

  def sourceSystemCheck(sourceSystem: String, natural_ky: String): String = {
    if (sourceSystem.trim().length() != 0 && sourceSystem.equalsIgnoreCase("SFDC")) {
      "crc32(lower(trim(" + natural_ky + ")))"
    } else {
      "crc32(lower(trim(" + natural_ky + ")))"
    }
  }
  def sourceSystemCheck(sourceSystem: String, isConcat: Boolean): String = {
    if (sourceSystem.trim().length() != 0 && sourceSystem.equalsIgnoreCase("SFDC")) {
      if (isConcat) "crc32(lower(TRIM(COALESCE(concat("
      else "crc32(lower(TRIM(COALESCE("
    } else {
      if (isConcat) "crc32(lower(TRIM(COALESCE(concat("
      else "crc32(lower(TRIM(COALESCE("
    }
  }
  
  def run() {

    val logger = Logger.getLogger(getClass.getName)
    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    //val startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
    val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
    val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
    val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
    val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
    val apiName = propertiesObject.getApiName()
    val deleteflag = propertiesObject.getDeleteflag()
    val deletetableName = propertiesObject.getDeleteTableName()
    val joinCol = propertiesObject.getDeletejoinCol()
    val groupByKeys = propertiesObject.getGroupByKeys()
    val sourceSystem = propertiesObject.getMasterDataFields().split(",", -1)(1)
    spark.conf.set("spark.sql.crossJoin.enabled", "true")
    val retainRecords = propertiesObject.getRetainRecords().trim()
    val hardDeleteCol = propertiesObject.getHardDeleteCol().trim().toUpperCase()
    val srcPartitionCol = propertiesObject.getSrcPartitionCol().trim()
    val tgtPartitionCol = propertiesObject.getTgtPartitionCol().trim()

    // set audit batch id to default value 
    var auditBatchId = ld_jb_nr + "_" + "19000101000000"
    val surrKey = propertiesObject.getSurrKey().trim
    val audColList: List[String] = List("intgtn_fbrc_msg_id", "src_sys_upd_ts", "src_sys_ky", "lgcl_dlt_ind", "ins_gmt_ts", "upd_gmt_ts", "src_sys_extrc_gmt_ts", "src_sys_btch_nr", "fl_nm", "ld_jb_nr")
    var dbNameConsmtn: String = null
    var consmptnTable: String = null
    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }
    var refTable: String = null //
    var dbNameRef: String = null
    if (propertiesObject.getTgtTblRef().trim().split("\\.", -1).size == 2) {
      dbNameRef = propertiesObject.getTgtTblRef().trim().split("\\.", -1)(0)
      refTable = propertiesObject.getTgtTblRef().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblRef properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    val latestEntryKey = propertiesObject.getLatestEntryKey().trim
    val multiplesurrogateKeyIndicator = propertiesObject.getMultipleSurrKeyInd().trim()
    val naturalKey = propertiesObject.getNaturalKeys().trim()
    val filterKey = propertiesObject.getFilterKey().trim

    var src_count: Long = 0
    var tgt_count: Long = 0
    var flag: Boolean = false

    val surrKeyList = surrKey.split(",").toList
    val naturalKeyList = propertiesObject.getNaturalKeys().split("#").toList
    
    // Map surrogate key to corresponding natural key
    val surrogatekeyMap: HashMap[String, String] = new HashMap[String, String]();
    for (i <- 0 to surrKeyList.length - 1) {
      surrogatekeyMap.put(surrKeyList(i), naturalKeyList(i))
    }

    // Identify batch Id to be processed
    val refBatchIdList: List[String] = Utilities.readRefBatchIdListNew(sqlCon, propertiesObject.getObjName(), auditTbl)
    
    src_count = Utilities.readRefCount(sqlCon, propertiesObject.getObjName())

    if (refBatchIdList.length != 0) {
      
      logger.info("+++++++++++############# Batch ID identified: " + refBatchIdList)
      try {

        auditBatchId = refBatchIdList.map(x => (x, x.reverse.slice(0, 14).reverse)).maxBy(_._2)._1

        //Filtering out records based on filterKey
        val refBatchIdListDf =
          if (filterKey.isEmpty() || filterKey.trim() == "") {
            spark.sql(f"""select * from ${dbNameRef}.${refTable}""")
              .select(col("*")).filter(col("ld_jb_nr") isin (refBatchIdList: _*))
          } else {
            val filterCol = filterKey.split('|')(0).trim
            val filterVal = filterKey.split('|')(1).trim
            spark.sql(f"""select * from ${dbNameRef}.${refTable}""")
              .select(col("*")).filter(col("ld_jb_nr") isin (refBatchIdList: _*))
              .filter(col(filterCol) === filterVal)
          }

        //Getting schema of Consumption Table
        val countConsumptionDF = spark.sql(f"""select * from ${dbNameConsmtn}.${consmptnTable} limit 1""")
        var colList = countConsumptionDF.drop("src_dlt_ind").columns.toList

        var keyCols = List[String]()
        val nk = propertiesObject.getNaturalKeys()

        //This check is for multiple surrogate keys as there will be corresponding natural keys
        if (naturalKey.contains("#")) {
          val tempkeyCols = nk.trim.split("#", -1)
          tempkeyCols.foreach {
            a =>
              if (a.contains(",")) {
                val tempList = a.split(",").toList
                keyCols = keyCols ::: tempList
              }

              keyCols = a :: keyCols

          }
        } else {

          keyCols = nk.trim.split(",", -1).toList
        }

        var sql = ""

        var Nullkeyfilter = ""
        var finalrefLatestDf = spark.emptyDataFrame
        // condition to check if source
        //For single surrogate key multiplesurrogateKeyIndicator will be 'N'
        if (multiplesurrogateKeyIndicator.equalsIgnoreCase("N")) {

          logger.info("-------------->>>>>>>>Single Surrogate Key<<<<<<<<<<<<<<----------------" + surrKey)

          keyCols.foreach { a =>
            sql = sql + "COALESCE(" + a + ",\"\")" + ","
          }
          //creating a string which will be like concat_ws('#',coalesce(colName1,""),coalesce(colName2,""),)
          var natural_ky = "concat(" + sql.dropRight(1) + ")"
          sql = "concat_ws('#'," + sql.dropRight(1) + ")"

          logger.info("################## Filter Criteria ##################" + sql.toString());
          Nullkeyfilter = Nullkeyfilter.dropRight(4)

          logger.info("################## Null Key Filter for Single Surrogate Key ##################" + Nullkeyfilter)

          refBatchIdListDf.createOrReplaceTempView("ref_tbl_without_surr_ky")

          val naturalKeyList = naturalKey.split(',').toList

          //Filtering Out records which have null values for concatenated natural keys i.e records which have all natiural keys as null
          val refLatestDfWithNaturalKey =
            if (naturalKeyList.length > 1) {
              var str = ""
              for (s <- 1 to naturalKeyList.length - 1) {
                str = str + "#"
              }
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_surr_ky")
                .filter(col("natural_ky") =!= "str")
            } else {
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_surr_ky")
                .filter(col("natural_ky") =!= "")
            }

          // logger.info("################## Count Without NULL ##################" + refLatestDfWithNaturalKey.count())

          refLatestDfWithNaturalKey.drop("natural_ky").createOrReplaceTempView("natural_ky_tbl")

          //Creating Surrogate Key
          val crc32StringSingle = sourceSystemCheck(sourceSystem, natural_ky)
          val surrogateKeyDf = spark.sql(f"""select *,${crc32StringSingle} as ${surrKey} from natural_ky_tbl""").drop("natural_ky")

          // logger.info("################## surrogateKeyDf ##################" + surrogateKeyDf.count())

          surrogateKeyDf.createOrReplaceTempView("surr_ky_tbl")

          val refLatestDf = spark.sql(f"""Select *,MAX(COALESCE(${latestEntryKey})) over (Partition by ${naturalKey}) as max_val from surr_ky_tbl""")
            .filter(col(latestEntryKey) === col("max_val"))
            .drop("max_val")

          //logger.info("################## refLatestDf ##################" + refLatestDf.count())

          finalrefLatestDf = if (retainRecords.equalsIgnoreCase("Y") && retainRecords != null) { //// changes for PACE
            refLatestDf.createOrReplaceTempView("temp_ref_latest_df")
            spark.sql(f"""
              select * from (select *,row_number() over (partition by ${groupByKeys} order by ${naturalKey} desc) as rn
              from  temp_ref_latest_df
              ) a where a.rn = 1
              """).drop("rn")

          } else {

            refLatestDf.createOrReplaceTempView("temp_ref_latest_df")
            spark.sql(f"""
              select * from (select *,row_number() over (partition by ${naturalKey} order by ${latestEntryKey} desc) as rn
              from  temp_ref_latest_df
              ) a where a.rn = 1
              """).drop("rn")
          }
          finalrefLatestDf = finalrefLatestDf.withColumn("ins_ts", from_unixtime(unix_timestamp())).withColumn(tgtPartitionCol, lit(expr(s"substr($srcPartitionCol,0,7)")))

        } //**************Entering into Multiple Surrogate Key scenario*****************************//
        else {

          println("-------------->>>>>>>>Multiple Surrogate Key<<<<<<<<<<<<<<----------------" + surrKey)

          var multiplesurrKey = ""
          if (naturalKey.contains("#")) {
            println("################## Multiple Surrogate Key Multiple Natural Key Logic ##################")

            logger.info("#############Natural Key Column List##############" + keyCols.toString())

            refBatchIdListDf.createOrReplaceTempView("ref_tbl_without_ntrl_ky")

            keyCols.foreach(a =>
              sql = sql + "COALESCE(" + a + ",\"\")" + ",")

            sql = "concat_ws('#'," + sql.dropRight(1) + ")"

            logger.info("################## Filter Criteria ##################" + sql.toString());

            val refLatestDfWithNaturalKey =
              if (keyCols.length > 1) {
                var str = ""
                for (s <- 1 to keyCols.length - 1) {
                  str = str + "#"
                }
                spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_ntrl_ky")
                  .filter(col("natural_ky") =!= "str")
              } else {
                spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_ntrl_ky")
                  .filter(col("natural_ky") =!= "")
              }

            refLatestDfWithNaturalKey.drop("natural_ky").createOrReplaceTempView("ref_tbl_without_surr_ky")

            val tempsurrkey = surrKey.split(",", -1).toList
            tempsurrkey.foreach {
              a =>
                var tempNk = surrogatekeyMap.get(a)
                //val crc32StringMultiple = sourceSystemCheck(sourceSystem)
                if (tempNk.contains(",")) {
                  val temp1 = tempNk.split(",").toList
                  val temp = temp1.foldLeft("")(_ + "coalesce(cast(" + _ + " as string),\"\"),")

                  println("################## tempsurrkey ##################" + temp.dropRight(1))
                  val crc32StringMultiple = sourceSystemCheck(sourceSystem, true)
                  multiplesurrKey = multiplesurrKey + crc32StringMultiple + temp.dropRight(1) + ")))))" + " as " + a + ","

                } else {
                  val crc32StringMultiple = sourceSystemCheck(sourceSystem, false)
                  multiplesurrKey = multiplesurrKey + crc32StringMultiple + "cast(" + tempNk + " as string),\"\"))))" + " as " + a + ","
                }

            }

            multiplesurrKey = multiplesurrKey.dropRight(1)
            println("################## Multiple Surrogate Key Multiple Natural Key ##################" + multiplesurrKey)

          } else {
            val crc32StringMultiple = sourceSystemCheck(sourceSystem, false)
            surrKey.foreach { a =>
              multiplesurrKey = multiplesurrKey + crc32StringMultiple + surrogatekeyMap.get(a) + ",\"\"))))" + " as " + a + ","
            }
            multiplesurrKey = multiplesurrKey.dropRight(1)
          }

          logger.info("################## Multiple Surrogate Key ##################" + multiplesurrKey)

          val refLatestDfWithSurrKey = spark.sql(f"select *,${multiplesurrKey}  from ref_tbl_without_surr_ky")

          //logger.info("################## Count Without NULL ##################" + refLatestDfWithSurrKey.count())

          refLatestDfWithSurrKey.createOrReplaceTempView("surr_ky_tbl")
          var refLatestDF = spark.emptyDataFrame

          // logic to handle surrogate key granularity
          finalrefLatestDf = if (groupByKeys != null && groupByKeys.length() > 0) {
            refLatestDF = spark.sql(
              f"""Select ${groupByKeys},MAX(COALESCE(${latestEntryKey})) as ${latestEntryKey}
                                     from surr_ky_tbl group by ${groupByKeys}""")
            val groupByKeyList = groupByKeys.split(",").toList
            val joinColumnList = latestEntryKey :: groupByKeyList
            var joinList = List[String]()

            refLatestDfWithSurrKey.createTempView("final_view")
            var group_natural_key = naturalKey.split("#").mkString(",")
            if (retainRecords.equalsIgnoreCase("Y") && retainRecords != null) { //// changes for PACE ////
              val srrKey_1 = latestEntryKey :: surrKeyList
              refLatestDF = spark.sql(
                f"""Select ${surrKey},MAX(COALESCE(${latestEntryKey})) as ${latestEntryKey}
                                     from surr_ky_tbl group by ${surrKey}""")

              refLatestDfWithSurrKey.join(broadcast(refLatestDF), srrKey_1.toSeq)
                .select(col("*")).createOrReplaceTempView("temp_ref_latest_df")
              spark.sql(f"""
              select * from (select *,row_number() over (partition by ${groupByKeys} order by ${surrKey} desc) as rn
              from  temp_ref_latest_df ) a
              where a.rn = 1
              """).drop("rn")
            } else {

              spark.sql(f"""
                  WITH ranked_final AS (
                  SELECT *, ROW_NUMBER() OVER (PARTITION BY ${groupByKeys} ORDER BY ${latestEntryKey} DESC) AS rn
                  FROM final_view
                  )
                  SELECT * FROM ranked_final WHERE rn = 1              
              """).drop("rn").dropDuplicates(joinColumnList.toSeq)
            }

          } else {

            var group_natural_key = naturalKey.split("#").mkString(",")

            refLatestDF = spark.sql(
              f"""Select ${group_natural_key},MAX(COALESCE(${latestEntryKey})) as ${latestEntryKey}
                                     from surr_ky_tbl group by ${group_natural_key}""")

            val ntrlKeyList = group_natural_key.split(",").toList
            val ntrlKey_1 = latestEntryKey :: ntrlKeyList

            if (retainRecords.equalsIgnoreCase("Y") && retainRecords != null) { //// changes for PACE

              refLatestDfWithSurrKey.join(broadcast(refLatestDF), ntrlKey_1.toSeq)
                .select(col("*")).createOrReplaceTempView("temp_ref_latest_df")

              spark.sql(f"""
              select * from ( select *,row_number() over (partition by ${groupByKeys} order by ${surrKey} desc) as rn
              from  temp_ref_latest_df ) a
              where a.rn = 1
              """).drop("rn")

            } else {

              refLatestDfWithSurrKey.createOrReplaceTempView("final_ref_temp")

              spark.sql(s"""
              select * from (select *,row_number() over (partition by ${group_natural_key} order by ${latestEntryKey} desc) as rn
              from final_ref_temp ) a
              where a.rn = 1
              """).drop("rn")

            }
          }

          val srrKey_1 = latestEntryKey :: surrKeyList
          finalrefLatestDf = finalrefLatestDf.withColumn("ins_ts", from_unixtime(unix_timestamp())).withColumn(tgtPartitionCol, lit(expr(s"substr($srcPartitionCol,0,7)")))
        }

        //Getting Consumption table records
        val consumptionDF = spark.sql(f"""select * from ${dbNameConsmtn}.${consmptnTable}""").drop("src_dlt_ind")

        val consumotionCountDF = spark.sql(s"select * from ${dbNameConsmtn}.${consmptnTable} limit 1")
        //initialize audit

        auditObj.setAudBatchId(auditBatchId)
        auditObj.setAudDataLayerName("ref_cnsmptn")
        auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
        auditObj.setAudObjectName(propertiesObject.getObjName())
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudErrorRecords(0)
        auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
        auditObj.setFlNm("")
        auditObj.setSysBtchNr(ld_jb_nr)

        consumotionCountDF.count match {

          case 0 =>
            //If consumption table is empty then the dataframe will be inserted into consumption table
            logger.info("####################### consumption table is empty ##############################")
            finalrefLatestDf = finalrefLatestDf.select(colList.head, colList.tail: _*)
            //************Delete Indicator Code
            if (!deleteflag.isEmpty()) {
              if (deleteflag.equalsIgnoreCase("y")) {

                val apijoinColNm = joinCol.split("\\|")(0)
                val deletetablejoinColNm = joinCol.split("\\|")(1)

                logger.info("#########Starting Delete Mechanism for First Time Load########## ")

                val deletetableDF = spark.sql(f"""select * from ${deletetableName} where obj_nm ='${apiName}' """)

                //logger.info("#########Delete Table DF ########## "+deletetableDF.count())

                logger.info("#########Final Ref Latest Df ########## " + apijoinColNm)

                logger.info("#########deletetableDF########## " + deletetablejoinColNm)

                var deleteindicatorDF = finalrefLatestDf.as("d1")
                  .join(broadcast(deletetableDF).as("d2"), finalrefLatestDf(apijoinColNm) === deletetableDF(deletetablejoinColNm), "left")
                  .withColumn("src_dlt_ind", when(deletetableDF(deletetablejoinColNm).isNull, 0).otherwise(1))
                  .select("d1.*", "src_dlt_ind")

                finalrefLatestDf = deleteindicatorDF

              }
            }
            //

            if (!hardDeleteCol.isEmpty() && hardDeleteCol != null) { /// hard delete check
              finalrefLatestDf = finalrefLatestDf.filter(col(hardDeleteCol) === "N" || col(hardDeleteCol) === "FALSE")
            }

            finalrefLatestDf.coalesce(20).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)

            val loaded_data = spark.sql("select * from " + dbNameConsmtn + "." + consmptnTable)

            tgt_count = loaded_data.count.toInt

            if (tgt_count < 0) {
              logger.error("No records to process!")
              auditObj.setAudJobStatusCode("failed")
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            } else {
              logger.info("Process completed !")
              auditObj.setAudJobStatusCode("success")
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            }

          case _ =>
            //Applying CDC when there is already some data in the Consumption Table
            logger.info("####################### CDC ##############################")
            var joinExpr = ""
            if (groupByKeys != null && groupByKeys.length() > 0) {
              val pkColumns = groupByKeys.split(",", -1)
              pkColumns.foreach { a =>
                joinExpr += "coalesce(cast(" + a + " as string),\"\"),"
              }
            } else {

              //val pkColumns = surrKey.split(",", -1)
              val pkColumns = naturalKey.split("#")(0).split(",", -1)
              pkColumns.foreach { a =>
                joinExpr += "coalesce(cast(" + a + " as string),\"\"),"
              }
            }

            val finalJoinExpr = "lower(concat(" + joinExpr.dropRight(1) + "))"

            var latestRecordsId = finalrefLatestDf.selectExpr(finalJoinExpr).toDF("primary_key").persist(StorageLevel.MEMORY_AND_DISK_SER)

            logger.info("###########################Temp DF Columns################" + latestRecordsId.columns.toList)

            val historicalDataSet = consumptionDF

            val keyRecordshistorical = historicalDataSet.withColumn("primary_key", lit(expr(finalJoinExpr))).selectExpr("primary_key", tgtPartitionCol).distinct()
            
            val joinedRows = keyRecordshistorical.join(latestRecordsId, Seq("primary_key")).persist(StorageLevel.MEMORY_AND_DISK_SER)

            if (joinedRows.count > 0) {

              val identifiedPartition = joinedRows.select(col(tgtPartitionCol).cast(StringType)).distinct().collect.map(row => row.getString(0).toString()).toSeq
              logger.info("###################### identified Partition")
              identifiedPartition.foreach(println)
              var nonUpdatedRecords = historicalDataSet.withColumn("primary_key", lit(expr(finalJoinExpr))).where(col(tgtPartitionCol).isin(identifiedPartition: _*)).join(latestRecordsId, Seq("primary_key"), "left_anti").persist(StorageLevel.MEMORY_AND_DISK_SER)
              var finalDf = nonUpdatedRecords.select(colList.head, colList.tail: _*).union(finalrefLatestDf.select(colList.head, colList.tail: _*))
              logger.info("###################### COUNT AFTER CDC " + finalDf.count().toInt)
              if (!deleteflag.isEmpty()) {
                if (deleteflag.equalsIgnoreCase("y")) {

                  val apijoinColNm = joinCol.split("\\|")(0)
                  val deletetablejoinColNm = joinCol.split("\\|")(1)

                  logger.info("#########Starting Delete Mechanism for CDC logic########## ")

                  val deletetableDF = spark.sql(f"""select * from ${deletetableName} where obj_nm ='${apiName}' """)

                  logger.info("#########Delete Table DF ########## " + deletetableDF.count())

                  logger.info("#########Final Ref Latest Df ########## " + apijoinColNm)

                  logger.info("#########deletetableDF########## " + deletetablejoinColNm)

                  var deleteindicatorDF1 = nonUpdatedRecords.select(colList.head, colList.tail: _*).as("d1")
                    .join(deletetableDF.as("d2"), nonUpdatedRecords(apijoinColNm) === deletetableDF(deletetablejoinColNm), "left")
                    .withColumn("src_dlt_ind", when(deletetableDF(deletetablejoinColNm).isNull, 0).otherwise(1))
                    .select("d1.*", "src_dlt_ind")

                  var deleteindicatorDF2 = finalrefLatestDf.select(colList.head, colList.tail: _*).as("d1")
                    .join(deletetableDF.as("d2"), nonUpdatedRecords(apijoinColNm) === deletetableDF(deletetablejoinColNm), "left")
                    .withColumn("src_dlt_ind", when(deletetableDF(deletetablejoinColNm).isNull, 0).otherwise(1))
                    .select("d1.*", "src_dlt_ind")

                  logger.info("#########Checking records post joining with Delete table########## " + deleteindicatorDF1.show(2))

                  nonUpdatedRecords = deleteindicatorDF1 //.withColumn("src_dlt_ind", when(col(deletetablejoinColNm).isNull,0).otherwise(1)).drop(col(deletetablejoinColNm))
                  finalrefLatestDf = deleteindicatorDF2
                }
              }
              //val isViewCreated = Utilities.createRefreshView(dbNameConsmtn + "." + consmptnTable, identifiedPartition, configObject)
              nonUpdatedRecords.select(colList.head, colList.tail: _*).repartition(10).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)
              finalrefLatestDf.select(colList.head, colList.tail: _*).repartition(10).write.mode(SaveMode.Append).format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)
              //val isViewRestored = Utilities.restoreRefreshView(dbNameConsmtn + "." + consmptnTable, configObject)
              tgt_count = finalrefLatestDf.count().toInt

            } else {

              var finalDf = finalrefLatestDf.select(colList.head, colList.tail: _*)

              logger.info("schema ---> " + finalDf.printSchema)

              if (deleteflag.isEmpty()) {
                if (deleteflag.equalsIgnoreCase("y")) {

                  val apijoinColNm = joinCol.split("\\|")(0)
                  val deletetablejoinColNm = joinCol.split("\\|")(1)

                  logger.info("#########Starting Delete Mechanism for CDC logic########## ")

                  val deletetableDF = spark.sql(f"""select * from ${deletetableName} where obj_nm ='${apiName}' """)

                  logger.info("#########Delete Table DF ########## " + deletetableDF.count())

                  logger.info("#########Final Ref Latest Df ########## " + apijoinColNm)

                  logger.info("#########deletetableDF########## " + deletetablejoinColNm)

                  var deleteindicatorDF1 = finalDf.as("d1")
                    .join(deletetableDF.as("d2"), finalDf(apijoinColNm) === deletetableDF(deletetablejoinColNm), "left")
                    .withColumn("src_dlt_ind", when(deletetableDF(deletetablejoinColNm).isNull, 0).otherwise(1))
                    .select("d1.*", "src_dlt_ind")

                  logger.info("#########Checking records post joining with Delete table########## " + deleteindicatorDF1.show(2))

                  finalDf = deleteindicatorDF1 //.withColumn("src_dlt_ind", when(col(deletetablejoinColNm).isNull,0).otherwise(1)).drop(col(deletetablejoinColNm))

                  logger.info("#########Records for final DF after delete indicator ########## " + finalDf.show(2))
                }
              }

              finalDf.repartition(10).write.mode(SaveMode.Append).format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)
              tgt_count = finalDf.count().toInt

            }

            if (tgt_count <= 0) {
              logger.error("No records to process !")
              auditObj.setAudJobStatusCode("failed")
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

            } else {
              logger.info("CDC process completed !")
              auditObj.setAudJobStatusCode("success")
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            }
        }

      } catch {

        case sslException: InterruptedException => {
          logger.error("Interrupted Exception")
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          System.exit(1)
        }
        case nseException: NoSuchElementException => {
          logger.error("No Such element found: " + nseException.printStackTrace())
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          System.exit(1)
        }
        case anaException: AnalysisException => {
          logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          System.exit(1)
        }
        case connException: ConnectException => {
          logger.error("Connection Exception: " + connException.printStackTrace())
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          System.exit(1)
        }
      }
    } else {
      
      logger.info("+++++++++++############# No batch ID to process #############+++++++++++")
      auditObj.setAudBatchId(auditBatchId)
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      spark.close()
      sqlCon.close()
    }
  }
}
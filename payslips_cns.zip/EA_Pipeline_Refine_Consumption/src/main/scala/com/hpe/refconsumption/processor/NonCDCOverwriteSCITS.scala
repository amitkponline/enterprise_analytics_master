package main.scala.com.hpe.refconsumption.processor

import java.net.ConnectException
import java.sql.Connection
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.HashMap

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.from_unixtime
import org.apache.spark.sql.functions.unix_timestamp

import main.scala.com.hpe.refconsumption.config.ConfigObject
import main.scala.com.hpe.refconsumption.config.SetUpConfiguration
import main.scala.com.hpe.refconsumption.config.StreamingPropertiesObject
import main.scala.com.hpe.refconsumption.utils.Utilities

class NonCDCOverwriteSCITS(auditObj: main.scala.com.hpe.refconsumption.config.AuditLoadObject, propertiesObject: StreamingPropertiesObject, spark: SparkSession, sqlCon: Connection, auditTbl: String) {

  def run() {
    //****************** Initialize variables *********************\\
    val logger = Logger.getLogger(getClass.getName)
    val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
    val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
    val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
    val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
    val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
    val apiName = propertiesObject.getApiName()
    val deleteflag = propertiesObject.getDeleteflag()
    val deletetableName = propertiesObject.getDeleteTableName()
    val joinCol = propertiesObject.getDeletejoinCol()
    val groupByKeys = propertiesObject.getGroupByKeys()
    val sourceSystem = propertiesObject.getMasterDataFields().split(",", -1)(1)
    val retainRecords = propertiesObject.getRetainRecords().trim()
    val hardDeleteCol = propertiesObject.getHardDeleteCol().trim().toUpperCase()
    val srcPartitionCol = propertiesObject.getSrcPartitionCol().trim()
    val tgtPartitionCol = propertiesObject.getTgtPartitionCol().trim()
    var auditBatchId = ld_jb_nr + "_" + "19000101000000"
    val surrKey = propertiesObject.getSurrKey().trim
    val audColList: List[String] = List("intgtn_fbrc_msg_id", "src_sys_upd_ts", "src_sys_ky", "lgcl_dlt_ind", "ins_gmt_ts", "upd_gmt_ts", "src_sys_extrc_gmt_ts", "src_sys_btch_nr", "fl_nm", "ld_jb_nr")
    var dbNameConsmtn: String = null
    var consmptnTable: String = null
    var refTable: String = null
    var dbNameRef: String = null
    val latestEntryKey = propertiesObject.getLatestEntryKey().trim
    val multiplesurrogateKeyIndicator = propertiesObject.getMultipleSurrKeyInd().trim()
    val naturalKey = propertiesObject.getNaturalKeys().trim()
    val filterKey = propertiesObject.getFilterKey().trim
    var src_count: Long = 0
    var tgt_count: Long = 0
    var flag: Boolean = false

    //****************** Set Audit Entries *********************\\
    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_ea_ref_to_consumption_load")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)

    //****************** Set Dimension Table Name *********************\\
    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    //****************** Set Refine Table Name *********************\\
    if (propertiesObject.getTgtTblRef().trim().split("\\.", -1).size == 2) {
      dbNameRef = propertiesObject.getTgtTblRef().trim().split("\\.", -1)(0)
      refTable = propertiesObject.getTgtTblRef().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblRef properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val bufferDays = propertiesObject.getBufferDays().trim
    def daysAgo(days: Int): String = {
      val calender = Calendar.getInstance()
      calender.add(Calendar.DAY_OF_YEAR, -days)
      sdf.format(calender.getTime())
    }

    val useGroupByKeys = propertiesObject.getUseGroupByKeys().trim
    val numPartitions = propertiesObject.getNumPartitions().trim
    val surrKeyList = surrKey.split(",").toList
    val naturalKeyList = propertiesObject.getNaturalKeys().split("#").toList
    val surrogatekeyMap: HashMap[String, String] = new HashMap[String, String]();
    for (i <- 0 to surrKeyList.length - 1) {
      surrogatekeyMap.put(surrKeyList(i), naturalKeyList(i))
    }

    //****************** Method to get delta batch id  *********************\\
    val refBatchIdList: List[String] = Utilities.readRefBatchIdListNew(sqlCon, propertiesObject.getObjName(), auditTbl)

    if (refBatchIdList.length != 0) {

      logger.info("+++++++++++++########## Got List ##########+++++++++++++" + refBatchIdList)
      try {

        //****************** Max batch id for consumption load *********************\\
        auditBatchId = refBatchIdList.map(x => (x, x.reverse.slice(0, 14).reverse)).maxBy(_._2)._1

        //Filtering out records based on filterKey
        var refBatchIdListDf = spark.emptyDataFrame
        if (bufferDays.isEmpty() || bufferDays.trim() == "") {
          refBatchIdListDf =
            if (filterKey.isEmpty() || filterKey.trim() == "") {
              spark.sql(f"""select * from ${dbNameRef}.${refTable}""")
                .select(col("*")).filter(col("ld_jb_nr") isin (refBatchIdList: _*))
            } else {
              val filterCol = filterKey.split('|')(0).trim
              val filterVal = filterKey.split('|')(1).trim
              spark.sql(f"""select * from ${dbNameRef}.${refTable}""")
                .select(col("*")).filter(col("ld_jb_nr") isin (refBatchIdList: _*))
                .filter(col(filterCol) === filterVal)
            }
        } else {
          refBatchIdListDf =
            if (filterKey.isEmpty() || filterKey.trim() == "") {
              spark.sql(f"""select * from ${dbNameRef}.${refTable}""")
                .select(col("*")).filter(col("rfnc_dt") >= daysAgo(bufferDays.toInt)).filter(col("ld_jb_nr") isin (refBatchIdList: _*))
            } else {
              val filterCol = filterKey.split('|')(0).trim
              val filterVal = filterKey.split('|')(1).trim
              spark.sql(f"""select * from ${dbNameRef}.${refTable}""")
                .select(col("*")).filter(col("rfnc_dt") >= daysAgo(bufferDays.toInt)).filter(col("ld_jb_nr") isin (refBatchIdList: _*))
                .filter(col(filterCol) === filterVal)
            }
        }
        src_count = refBatchIdListDf.count.toInt

        //Getting schema of Consumption Table
        val countConsumptionDF = spark.sql(f"""select * from ${dbNameConsmtn}.${consmptnTable} limit 1""")
        var colList = countConsumptionDF.drop("src_dlt_ind").columns.toList

        var keyCols = List[String]()
        val nk = propertiesObject.getNaturalKeys()

        //This check is for multiple surrogate keys as there will be corresponding natural keys
        if (naturalKey.contains("#")) {
          val tempkeyCols = nk.trim.split("#", -1)
          tempkeyCols.foreach {
            a =>
              if (a.contains(",")) {
                val tempList = a.split(",").toList
                keyCols = keyCols ::: tempList
              }

              keyCols = a :: keyCols

          }
        } else {

          keyCols = nk.trim.split(",", -1).toList
        }

        var sql = ""

        var Nullkeyfilter = ""
        var finalrefLatestDf = spark.emptyDataFrame
        // condition to check if source
        //For single surrogate key multiplesurrogateKeyIndicator will be 'N'
        if (multiplesurrogateKeyIndicator.equalsIgnoreCase("N")) {

          logger.info("-------------->>>>>>>>Single Surrogate Key<<<<<<<<<<<<<<----------------" + surrKey)

          keyCols.foreach { a =>
            sql = sql + "COALESCE(" + a + ",\"\")" + ","
          }
          //creating a string which will be like concat_ws('#',coalesce(colName1,""),coalesce(colName2,""),)
          var natural_ky = "concat(" + sql.dropRight(1) + ")"
          sql = "concat_ws('#'," + sql.dropRight(1) + ")"

          logger.info("################## Filter Criteria ##################" + sql.toString());
          Nullkeyfilter = Nullkeyfilter.dropRight(4)

          logger.info("################## Null Key Filter for Single Surrogate Key ##################" + Nullkeyfilter)

          refBatchIdListDf.createOrReplaceTempView("ref_tbl_without_surr_ky")

          val naturalKeyList = naturalKey.split(',').toList

          //Filtering Out records which have null values for concatenated natural keys i.e records which have all natiural keys as null
          val refLatestDfWithNaturalKey =
            if (naturalKeyList.length > 1) {
              var str = ""
              for (s <- 1 to naturalKeyList.length - 1) {
                str = str + "#"
              }
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_surr_ky")
                .filter(col("natural_ky") =!= "str")
            } else {
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_surr_ky")
                .filter(col("natural_ky") =!= "")
            }

          refLatestDfWithNaturalKey.drop("natural_ky").createOrReplaceTempView("natural_ky_tbl")

          //Creating Surrogate Key

          val crc32StringSingle = "crc32(lower(trim(" + natural_ky + ")))"

          val surrogateKeyDf = spark.sql(f"""select *,${crc32StringSingle} as ${surrKey} from natural_ky_tbl""").drop("natural_ky")
          if (useGroupByKeys.equalsIgnoreCase("N")) {
            finalrefLatestDf = surrogateKeyDf
          } else {
            finalrefLatestDf = if (retainRecords.equalsIgnoreCase("Y") && retainRecords != null) { //// changes for PACE
              Utilities.getLatestRecs(surrogateKeyDf, groupByKeys.split(",").toList, latestEntryKey.split(",").toList)
            } else {

              Utilities.getLatestRecs(surrogateKeyDf, naturalKey.split("#")(0).split(",").toList, latestEntryKey.split(",").toList)
            }
          }
          finalrefLatestDf = finalrefLatestDf.withColumn("ins_ts", from_unixtime(unix_timestamp())) //.withColumn(tgtPartitionCol, lit(expr(s"substr($srcPartitionCol,0,7)")))

        } //**************Entering into Multiple Surrogate Key scenario*****************************//
        else {

          logger.info("-------------->>>>>>>>Multiple Surrogate Key<<<<<<<<<<<<<<----------------" + surrKey)

          var multiplesurrKey = ""
          if (naturalKey.contains("#")) {
            logger.info("################## Multiple Surrogate Key Multiple Natural Key Logic ##################")

            logger.info("#############Natural Key Column List##############" + keyCols.toString())

            refBatchIdListDf.createOrReplaceTempView("ref_tbl_without_ntrl_ky")

            keyCols.foreach(a =>
              sql = sql + "COALESCE(" + a + ",\"\")" + ",")

            sql = "concat_ws('#'," + sql.dropRight(1) + ")"

            logger.info("################## Filter Criteria ##################" + sql.toString());

            val refLatestDfWithNaturalKey =
              if (keyCols.length > 1) {
                var str = ""
                for (s <- 1 to keyCols.length - 1) {
                  str = str + "#"
                }
                spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_ntrl_ky")
                  .filter(col("natural_ky") =!= "str")
              } else {
                spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_ntrl_ky")
                  .filter(col("natural_ky") =!= "")
              }

            refLatestDfWithNaturalKey.drop("natural_ky").createOrReplaceTempView("ref_tbl_without_surr_ky")

            val tempsurrkey = surrKey.split(",", -1).toList
            tempsurrkey.foreach {
              a =>
                var tempNk = surrogatekeyMap.get(a)
                //val crc32StringMultiple = sourceSystemCheck(sourceSystem)
                if (tempNk.contains(",")) {
                  val temp1 = tempNk.split(",").toList
                  val temp = temp1.foldLeft("")(_ + "coalesce(cast(" + _ + " as string),\"\"),")

                  logger.info("################## tempsurrkey ##################" + temp.dropRight(1))

                  multiplesurrKey = multiplesurrKey + "crc32(lower(TRIM(COALESCE(concat(" + temp.dropRight(1) + ")))))" + " as " + a + ","

                } else {

                  multiplesurrKey = multiplesurrKey + "crc32(lower(TRIM(COALESCE(" + "cast(" + tempNk + " as string),\"\"))))" + " as " + a + ","
                }

            }

            multiplesurrKey = multiplesurrKey.dropRight(1)
            logger.info("################## Multiple Surrogate Key Multiple Natural Key ##################" + multiplesurrKey)

          } else {
            //val crc32StringMultiple = sourceSystemCheck(sourceSystem, false)
            surrKey.foreach { a =>
              multiplesurrKey = multiplesurrKey + "crc32(lower(TRIM(COALESCE(" + surrogatekeyMap.get(a) + ",\"\"))))" + " as " + a + ","
            }
            multiplesurrKey = multiplesurrKey.dropRight(1)
          }

          logger.info("################## Multiple Surrogate Key ##################" + multiplesurrKey)

          val refLatestDfWithSurrKey = spark.sql(f"select *,${multiplesurrKey}  from ref_tbl_without_surr_ky")
          if (useGroupByKeys.equalsIgnoreCase("N")) {
            finalrefLatestDf = refLatestDfWithSurrKey
          } else {
            finalrefLatestDf = if (groupByKeys != null && groupByKeys.length() > 0) {
              if (retainRecords.equalsIgnoreCase("Y") && retainRecords != null) { //// changes for PACE ////
                Utilities.getLatestRecs(refLatestDfWithSurrKey, groupByKeys.split(",").toList, surrKey.split(",").toList)
              } else {
                Utilities.getLatestRecs(refLatestDfWithSurrKey, groupByKeys.split(",").toList, latestEntryKey.split(",").toList)
              }
            } else {
              Utilities.getLatestRecs(refLatestDfWithSurrKey, naturalKey.split("#")(0).split(",").toList, latestEntryKey.split(",").toList)
            }

          }

          finalrefLatestDf = finalrefLatestDf.withColumn("ins_ts", from_unixtime(unix_timestamp())) //.withColumn(tgtPartitionCol, lit(expr(s"substr($srcPartitionCol,0,7)")))
        }

        finalrefLatestDf = finalrefLatestDf.select(colList.head, colList.tail: _*)

        finalrefLatestDf.coalesce(numPartitions.toInt).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)

        val tgt_count = finalrefLatestDf.count.toLong

        if (tgt_count <= 0) {
          logger.error("No records to process !")
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudBatchId(auditBatchId)
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

        } else {
          logger.info("NON CDC process completed !")
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudBatchId(auditBatchId)
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        }

      } catch {

        case sslException: InterruptedException => {
          logger.error("Interrupted Exception")
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        }
        case nseException: NoSuchElementException => {
          logger.error("No Such element found: " + nseException.printStackTrace())
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        }
        case anaException: AnalysisException => {
          logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        }
        case connException: ConnectException => {
          logger.error("Connection Exception: " + connException.printStackTrace())
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        }
      } finally {
        sqlCon.close()
        spark.close()
      }

    } else {

      logger.info("+++++++++++++########## No new batch_id available in RAW REF ##########+++++++++++++" + refBatchIdList)
      auditObj.setAudBatchId(auditBatchId)
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
      auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(0)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      spark.close()
      sqlCon.close()
    }

  }

}
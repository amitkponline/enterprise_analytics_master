package main.scala.com.hpe.refconsumption.utils

import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.commons.lang3.StringUtils
import scala.collection.mutable.ArrayBuffer

class FileParser(column_count: Int, delimiter: String, enclosedBy: String)
  extends Serializable {
  val final_delimiter = enclosedBy + delimiter + enclosedBy
  // This method calls the Validation method for each record on the input rdd
  def invokeValidation(rawRDD: RDD[String]): RDD[(Char, Array[String])] = {
    rawRDD.map(startValidation)
  }

  //start validation check if the record length matches with the Raw Table column count
  def startValidation(record: String) = {
    // Subtract 1 because the number of delimiters will be 1 less than number of columns
    var count: Int = column_count - 1
    try {
      //Check if the record delimiter matches with the expected count
      isViableRecord(record, count) match {
        // If True, Split the record
        case true => doSplit(record, count, enclosedBy)
        // If False, Mark the file as Invalid and append appropriate error message and full record
        case false => ('I', (record + " #" + "Field Count Not %d").format(count + 1).split(delimiter))
      }
    } catch {
      // If any exception occurs while Splitting the file, Mark the record as Failed along with error Message
      case t: Throwable => ('F', (record + "#" + "\u0001" + t.getMessage).split("\u0001"))
    }
  }

  // This method is used to match delimiter counts in the record
  def isViableRecord(record: String, count: Int) =
    {
      val fieldCount = StringUtils.countMatches(record, final_delimiter)
      if (fieldCount == count) true else false
    }

  // Split the record and adjust any NULLs in the end of record

  def doSplit(record: String, count: Int, enclosedBy: String) = {
    val recordArr = new ArrayBuffer[String]
    val errorMsg = new StringBuilder()

    if (delimiter.equals("|") && enclosedBy.equals()) {
      recordArr.++=(record.split("\\|"))
    } else if (delimiter.equals("|") && enclosedBy.equals("'")) {
      recordArr.++=(record.replaceAll("^" + enclosedBy, "").replaceAll(enclosedBy + "$", "").split("'\\|'"))
    } else if (delimiter.equals("|") && enclosedBy.equals("\"")) {
      recordArr.++=(record.replaceAll("^" + enclosedBy, "").replaceAll(enclosedBy + "$", "").split("\"\\|\""))
    } else {
      recordArr.++=(record.replaceAll("^" + enclosedBy, "").replaceAll(enclosedBy + "$", "").split(final_delimiter))
    }
    val recordArrLen = recordArr.length

    // In Scala - When there are empty columns at the end of file, Split will ignore the columns, Hence, Add nulls to the end to maintain the column count
    if (recordArrLen != count) {
      for (i <- recordArrLen to count) recordArr.+=("null")
    }

    // Return the validated Record as an Array
    ('V', recordArr.toArray)
  }

}

package main.scala.com.hpe.refconsumption.processor

import main.scala.com.hpe.refconsumption.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.refconsumption.utils._
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap


class PaceCDC(auditObj: main.scala.com.hpe.refconsumption.config.AuditLoadObject, propertiesObject: StreamingPropertiesObject, spark: SparkSession, sqlCon: Connection, auditTbl: String) {

  def sourceSystemCheck(sourceSystem:String,natural_ky:String):String = {
    if (sourceSystem.trim().length() !=0 && sourceSystem.equalsIgnoreCase("SFDC")){
      "crc32(lower(trim("+natural_ky+")))"
    }
    else {
      "crc32(lower(trim("+natural_ky+")))"
    }
  } 
  def sourceSystemCheck(sourceSystem:String,isConcat:Boolean):String = {
    if (sourceSystem.trim().length() !=0 && sourceSystem.equalsIgnoreCase("SFDC")){
      if (isConcat) "crc32(lower(TRIM(COALESCE(concat("
      else "crc32(lower(TRIM(COALESCE("
    }
    else {
      if (isConcat) "crc32(lower(TRIM(COALESCE(concat("
      else "crc32(lower(TRIM(COALESCE("
    }
  }  
  def run() {

    val logger = Logger.getLogger(getClass.getName)
    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    //val startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")

    val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
    val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
    val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
    val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
    val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
    val apiName = propertiesObject.getApiName()
    val deleteflag = propertiesObject.getDeleteflag()
    val deletetableName= propertiesObject.getDeleteTableName()
    val joinCol= propertiesObject.getDeletejoinCol()
    val groupByKeys = propertiesObject.getGroupByKeys()
    val sourceSystem = propertiesObject.getMasterDataFields().split(",",-1)(1)  
    spark.conf.set("spark.sql.crossJoin.enabled", "true")
    val retainRecords = propertiesObject.getRetainRecords().trim()
      
    
    var auditBatchId = ld_jb_nr + "_" + "19000101000000"
    val surrKey = propertiesObject.getSurrKey().trim
    val audColList: List[String] = List("intgtn_fbrc_msg_id", "src_sys_upd_ts", "src_sys_ky", "lgcl_dlt_ind", "ins_gmt_ts", "upd_gmt_ts", "src_sys_extrc_gmt_ts", "src_sys_btch_nr", "fl_nm", "ld_jb_nr")
    var dbNameConsmtn:String = null
    var consmptnTable: String = null
    if(propertiesObject.getTgtTblConsmtn().trim().split("\\.",-1).size==2){
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.",-1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.",-1)(1)
    }else{
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }
    var refTable: String = null//
    var dbNameRef: String = null
    if(propertiesObject.getTgtTblRef().trim().split("\\.",-1).size==2){
      dbNameRef = propertiesObject.getTgtTblRef().trim().split("\\.",-1)(0)
      refTable = propertiesObject.getTgtTblRef().trim().split("\\.",-1)(1)
    }else{
      logger.error("Please update tgtTblRef properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }
   // val dbName = propertiesObject.getDbName().trim
    
    
   // val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())
    val latestEntryKey = propertiesObject.getLatestEntryKey().trim
    val multiplesurrogateKeyIndicator = propertiesObject.getMultipleSurrKeyInd().trim()
    val naturalKey = propertiesObject.getNaturalKeys().trim()
    val filterKey = propertiesObject.getFilterKey().trim

    var src_count: Long = 0
    var tgt_count: Long = 0
    var flag: Boolean = false
    /*if (consumptionEntryFlag == true) {
      auditObj.setAudBatchId(auditBatchId)
      auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudLoadTimeStamp("1900-01-01 00:00:00")
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    //  Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }*/

    val surrKeyList = surrKey.split(",").toList
    val naturalKeyList = propertiesObject.getNaturalKeys().split("#").toList
    val surrogatekeyMap: HashMap[String, String] = new HashMap[String, String]();
    for (i <- 0 to surrKeyList.length - 1) {
      surrogatekeyMap.put(surrKeyList(i), naturalKeyList(i))
    }

    /*
     * //Reading latest entries of BatchIds from Audit table - original
    val refBatchIdList: List[String] = Utilities.readRefBatchIdList(sqlCon, propertiesObject.getObjName(),auditTbl)
    src_count = Utilities.readRefCount(sqlCon, propertiesObject.getObjName())
		*/
    
    // New method to get BatchIds
    val refBatchIdList: List[String] = Utilities.readRefBatchIdListNew(sqlCon, propertiesObject.getObjName(),auditTbl)
    src_count = Utilities.readRefCount(sqlCon, propertiesObject.getObjName())
    
    if (refBatchIdList.length != 0) {
      logger.info("-------------->>>>>>>>Got List<<<<<<<<<<<<<<----------------" + refBatchIdList)
      try {
        // original way of identifying max batch id       
        //auditBatchId = refBatchIdList.max
        
        // new way of identifying max batch id
        auditBatchId = refBatchIdList.map(x=> (x,x.reverse.slice(0,14).reverse)).maxBy(_._2)._1
        

        //Filtering out records based on filterKey
        val refBatchIdListDf =
          if (filterKey.isEmpty() || filterKey.trim()=="") {
            spark.sql(f"""select * from ${dbNameRef}.${refTable}""")
              .select(col("*")).filter(col("ld_jb_nr") isin (refBatchIdList: _*))
          } else {
            val filterCol = filterKey.split('|')(0).trim
            val filterVal = filterKey.split('|')(1).trim
            spark.sql(f"""select * from ${dbNameRef}.${refTable}""")
              .select(col("*")).filter(col("ld_jb_nr") isin (refBatchIdList: _*))
              .filter(col(filterCol) === filterVal)
          }
        
        logger.info("################## refBatchIdListDf Count ##################" + refBatchIdListDf.count())
        
        //Getting schema of Consumption Table
        val countConsumptionDF = spark.sql(f"""select * from ${dbNameConsmtn}.${consmptnTable} limit 1""")
        var colList = countConsumptionDF.drop("src_dlt_ind").columns.toList
       // colList.foreach(f => logger.info(f.concat(",")))        
        var keyCols = List[String]()
        val nk = propertiesObject.getNaturalKeys()
        //This check is for multiple surrogate keys as there will be corresponding natural keys
        if (naturalKey.contains("#")) {
          val tempkeyCols = nk.trim.split("#", -1)
          tempkeyCols.foreach {
            a =>
              if (a.contains(",")) {
                val tempList = a.split(",").toList
                keyCols = keyCols ::: tempList
              }

              keyCols = a :: keyCols

          }
        } else {

          keyCols = nk.trim.split(",", -1).toList
        }

        var sql = ""

        var Nullkeyfilter = ""
        var finalrefLatestDf = spark.emptyDataFrame
        // condition to check if source 
        //For single surrogate key multiplesurrogateKeyIndicator will be 'N'
        if (multiplesurrogateKeyIndicator.equalsIgnoreCase("N")) {

          logger.info("-------------->>>>>>>>Single Surrogate Key<<<<<<<<<<<<<<----------------" + surrKey)

          keyCols.foreach { a =>
            sql = sql + "COALESCE(" + a + ",\"\")" + ","
          }
          //creating a string which will be like concat_ws('#',coalesce(colName1,""),coalesce(colName2,""),)
          var natural_ky = "concat(" + sql.dropRight(1) + ")"
          sql = "concat_ws('#'," + sql.dropRight(1) + ")"
          

          logger.info("################## Filter Criteria ##################"+sql.toString() );
          Nullkeyfilter = Nullkeyfilter.dropRight(4)

          logger.info("################## Null Key Filter for Single Surrogate Key ##################" + Nullkeyfilter)

          refBatchIdListDf.createOrReplaceTempView("ref_tbl_without_surr_ky")

          val naturalKeyList = naturalKey.split(',').toList

          //Filtering Out records which have null values for concatenated natural keys i.e records which have all natiural keys as null
          val refLatestDfWithNaturalKey =
            if (naturalKeyList.length > 1) {
              var str = ""
              for (s <- 1 to naturalKeyList.length - 1) {
                str = str + "#"
              }
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_surr_ky")
                .filter(col("natural_ky") =!= "str")
            } else {
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_surr_ky")
               .filter(col("natural_ky") =!= "")
            }

          logger.info("################## Count Without NULL ##################" + refLatestDfWithNaturalKey.count())

          refLatestDfWithNaturalKey.drop("natural_ky").createOrReplaceTempView("natural_ky_tbl")

          //Creating Surrogate Key
          val crc32StringSingle = sourceSystemCheck(sourceSystem, natural_ky)
          val surrogateKeyDf = spark.sql(f"""select *,${crc32StringSingle} as ${surrKey} from natural_ky_tbl""").drop("natural_ky")
          
          
          logger.info("################## surrogateKeyDf ##################" + surrogateKeyDf.count())

          surrogateKeyDf.createOrReplaceTempView("surr_ky_tbl")

          //Getting Latest record based on latestEntryKey
          /*
          val refLatestDf = spark.sql(f"""Select *,MAX(COALESCE(${latestEntryKey})) over (Partition by ${surrKey}) as max_val from surr_ky_tbl""")
            .filter(col(latestEntryKey) === col("max_val"))
            .drop("max_val")
					*/
          val refLatestDf = spark.sql(f"""Select *,COALESCE(${latestEntryKey},cast("1999-12-31" as date)) as lastEntryKey,MAX(COALESCE(${latestEntryKey},cast("1999-12-31" as date))) over (Partition by ${naturalKey}) as max_val from surr_ky_tbl""")
            .filter(col("lastEntryKey") === col("max_val"))
            .drop("max_val").drop("lastEntryKey")
          
          logger.info("################## refLatestDf ##################" + refLatestDf.count())
          
          finalrefLatestDf = if(retainRecords.equalsIgnoreCase("Y") && retainRecords != null) { //// changes for PACE
          //Dropping duplicate records which will have same value for surrogate key and latestEntryKey
           /*
            refLatestDf.select(col("*"), struct(naturalKey, latestEntryKey).as("tuple"))
            .drop(naturalKey)
            .drop(latestEntryKey)
            //.dropDuplicates("tuple")
            .select(col("*"), col(f"tuple.${naturalKey}"), col(f"tuple.${latestEntryKey}")) */
            refLatestDf.createOrReplaceTempView("temp_ref_latest_df")
            spark.sql(f"""
              select * from (select *,row_number() over (partition by ${groupByKeys} order by ${naturalKey} desc) as rn
              from  temp_ref_latest_df
              ) a 
              """).drop("rn")

          }
          else {
            

              
                          refLatestDf.createOrReplaceTempView("temp_ref_latest_df")
            spark.sql(f"""
              select * from (select *,row_number() over (partition by ${naturalKey} order by ${latestEntryKey} desc) as rn
              from  temp_ref_latest_df
              ) a 
              """).drop("rn")
            }

          logger.info("finalrefLatestDf------>" + finalrefLatestDf.count)
          
          logger.info("Final Ref DF Record for Single SurrKey------>" + finalrefLatestDf.show(2))


        }
        //**************Entering into Multiple Surrogate Key scenario*****************************//
        
        else {

          println("-------------->>>>>>>>Multiple Surrogate Key<<<<<<<<<<<<<<----------------" + surrKey)

          var multiplesurrKey = ""
          if (naturalKey.contains("#")) {
            println("################## Multiple Surrogate Key Multiple Natural Key Logic ##################")
            
            logger.info("#############Natural Key Column List##############"+keyCols.toString())
            
            refBatchIdListDf.createOrReplaceTempView("ref_tbl_without_ntrl_ky")
           
            keyCols.foreach(a =>
            sql = sql + "COALESCE(" + a + ",\"\")" + ",")
            
            sql = "concat_ws('#'," + sql.dropRight(1) + ")" 
           
            logger.info("################## Filter Criteria ##################"+sql.toString() );
           
            val refLatestDfWithNaturalKey =
            if (keyCols.length > 1) {
              var str = ""
              for (s <- 1 to keyCols.length - 1) {
                str = str + "#"
              }
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_ntrl_ky")
                .filter(col("natural_ky") =!= "str")
            } else {
              spark.sql(f"select *,${sql} as natural_ky from ref_tbl_without_ntrl_ky")
               .filter(col("natural_ky") =!= "")
            }
            
             refLatestDfWithNaturalKey.drop("natural_ky").createOrReplaceTempView("ref_tbl_without_surr_ky")

            val tempsurrkey = surrKey.split(",", -1).toList
            tempsurrkey.foreach {
              a =>
                var tempNk = surrogatekeyMap.get(a)
                //val crc32StringMultiple = sourceSystemCheck(sourceSystem)
                if (tempNk.contains(",")) {
                  val temp1 = tempNk.split(",").toList
                  val temp = temp1.foldLeft("")(_ + "coalesce(cast(" + _ + " as string),\"\"),")
                  
                  println("################## tempsurrkey ##################" + temp.dropRight(1))
                  val crc32StringMultiple = sourceSystemCheck(sourceSystem,true)
                  multiplesurrKey = multiplesurrKey + crc32StringMultiple + temp.dropRight(1) + ")))))" + " as " + a + ","
                  
                } else {
                  val crc32StringMultiple = sourceSystemCheck(sourceSystem,false)
                  multiplesurrKey = multiplesurrKey + crc32StringMultiple+ "cast(" + tempNk + " as string),\"\"))))" + " as " + a + ","
                }
                
                
            }
             
            multiplesurrKey = multiplesurrKey.dropRight(1)
            println("################## Multiple Surrogate Key Multiple Natural Key ##################" + multiplesurrKey)

          } else {
            val crc32StringMultiple = sourceSystemCheck(sourceSystem,false)
            surrKey.foreach { a =>
              multiplesurrKey = multiplesurrKey + crc32StringMultiple + surrogatekeyMap.get(a) + ",\"\"))))" + " as " + a + ","
            }
            multiplesurrKey = multiplesurrKey.dropRight(1)
          }

          logger.info("################## Multiple Surrogate Key ##################" + multiplesurrKey)

          val refLatestDfWithSurrKey = spark.sql(f"""select *,${multiplesurrKey},COALESCE(${latestEntryKey},cast("1999-12-31" as date)) as latestEntryKey  from ref_tbl_without_surr_ky""")

          logger.info("################## Count Without NULL ##################" + refLatestDfWithSurrKey.count())

          refLatestDfWithSurrKey.createOrReplaceTempView("surr_ky_tbl")
          var refLatestDF = spark.emptyDataFrame
          
          // logic to handle surrogate key granularity 
          finalrefLatestDf = if (groupByKeys != null && groupByKeys.length() > 0) {
            refLatestDF= spark.sql(
            f"""Select ${groupByKeys},MAX(COALESCE(${latestEntryKey},cast("1999-12-31" as date))) as latestEntryKey
                                     from surr_ky_tbl group by ${groupByKeys}""")
            val groupByKeyList = groupByKeys.split(",").toList
            val joinColumnList = latestEntryKey :: groupByKeyList
            var joinList = List[String]()
            /*joinColumnList.foreach{
              a=> joinList = "COALESCE(" + a + ",\"\")" :: joinList
            }
            
            joinList.foreach(println)
            
            refLatestDF.withColumn(colName, col)
            */
            refLatestDfWithSurrKey.createTempView("final_view")
            var group_natural_key = naturalKey.split("#").mkString(",")
            
            
            if (retainRecords.equalsIgnoreCase("Y") && retainRecords != null){//// changes for PACE ////
            
              val srrKey_1 = "latestEntryKey" :: surrKeyList
              
              refLatestDF= spark.sql(
            f"""Select ${surrKey},MAX(COALESCE(${latestEntryKey},cast("1999-12-31" as date))) as latestEntryKey
                                     from surr_ky_tbl group by ${surrKey}""")
                                     
              refLatestDfWithSurrKey.join(broadcast(refLatestDF), srrKey_1.toSeq)
              .select(col("*")).createOrReplaceTempView("temp_ref_latest_df")
              
              spark.sql(f"""
              select * from (select *,row_number() over (partition by ${groupByKeys} order by ${surrKey} desc) as rn
              from  temp_ref_latest_df ) a
              """).drop("rn").drop("latestEntryKey")
            }
            else {
              
            spark.sql(f"""
                  WITH ranked_final AS (
                  SELECT *, ROW_NUMBER() OVER (PARTITION BY ${groupByKeys} ORDER BY ${latestEntryKey} DESC) AS rn
                  FROM final_view
                  )
                  SELECT * FROM ranked_final              
              """).drop("rn").dropDuplicates(joinColumnList.toSeq)
            }
            //refLatestDfWithSurrKey.join(broadcast(refLatestDF), joinList.toSeq)
            //.select(col("*")).dropDuplicates(joinList.toSeq) 
 
          }else {
            
            var group_natural_key = naturalKey.split("#").mkString(",")
            
            refLatestDF = spark.sql(
            f"""Select ${group_natural_key},MAX(COALESCE(${latestEntryKey})) as ${latestEntryKey}
                                     from surr_ky_tbl group by ${group_natural_key}""")
                                     
          val ntrlKeyList = group_natural_key.split(",").toList
          val ntrlKey_1 = latestEntryKey :: ntrlKeyList

          if (retainRecords.equalsIgnoreCase("Y") && retainRecords != null){ //// changes for PACE
            
           refLatestDfWithSurrKey.join(broadcast(refLatestDF), ntrlKey_1.toSeq)
            .select(col("*")).createOrReplaceTempView("temp_ref_latest_df")
            
            spark.sql(f"""
              select * from ( select *,row_number() over (partition by ${groupByKeys} order by ${surrKey} desc) as rn
              from  temp_ref_latest_df ) a
              """).drop("rn")
            
          }
          else {
 
              refLatestDfWithSurrKey.createOrReplaceTempView("final_ref_temp")
              ///refLatestDfWithSurrKey.join(broadcast(refLatestDF), ntrlKey_1.toSeq).select(col("*")).dropDuplicates(ntrlKey_1.toSeq)
            
              spark.sql(s"""
              select * from (select *,row_number() over (partition by ${group_natural_key} order by ${latestEntryKey} desc) as rn
              from final_ref_temp ) a
              """).drop("rn")
            
            
          }
          }                           
          logger.info("################## Ref Latest DF Count for Multiple Surrogate Key  ##################" + refLatestDF.count())

          val srrKey_1 = latestEntryKey :: surrKeyList

          /*finalrefLatestDf = refLatestDfWithSurrKey.join(broadcast(refLatestDF), srrKey_1.toSeq)
            .select(col("*")).dropDuplicates(srrKey_1.toSeq)*/
          /*
      */
          logger.info("Record to validat------>" + finalrefLatestDf.show(2))

        }

        //Getting Consumption table records
        val consumptionDF = spark.sql(f"""select * from ${dbNameConsmtn}.${consmptnTable}""").drop("src_dlt_ind")

        logger.info("Final Ref Count------>" + finalrefLatestDf.count())
        
        logger.info("schema of final ref latest df"+finalrefLatestDf.printSchema)
        
        logger.info("Consumption count----->"+countConsumptionDF.count())

        //initialize audit
        
        auditObj.setAudBatchId(auditBatchId)
        auditObj.setAudDataLayerName("ref_cnsmptn")
        auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
        auditObj.setAudObjectName(propertiesObject.getObjName())
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        //auditObj.setAudJobStatusCode("success")
        //auditObj.setAudSrcRowCount(src_count)
        //auditObj.setAudTgtRowCount(tgt_count)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
        auditObj.setFlNm("")
        auditObj.setSysBtchNr(ld_jb_nr)
        //auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        //auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        //Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        
        //If consumption table is empty then the dataframe will be inserted into consumption table
        
        countConsumptionDF.count match {
        
          case 0 =>
            //If consumption table is empty then the dataframe will be inserted into consumption table
            logger.info("Counsumption Count------>" + consumptionDF.count())
            tgt_count = finalrefLatestDf.count().toInt
            
            finalrefLatestDf = finalrefLatestDf.withColumn("ins_ts", from_unixtime(unix_timestamp())).select(colList.head, colList.tail: _*)
            //************Delete Indicator Code
            if(!deleteflag.isEmpty() ){
              if (deleteflag.equalsIgnoreCase("y")){
            
              
              val apijoinColNm =joinCol.split("\\|")(0)
              val deletetablejoinColNm =joinCol.split("\\|")(1)
              
              logger.info("#########Starting Delete Mechanism for First Time Load########## ")
              
              val deletetableDF = spark.sql(f"""select * from ${deletetableName} where obj_nm ='${apiName}' """)
              
              logger.info("#########Delete Table DF ########## "+deletetableDF.count())
              
              logger.info("#########Final Ref Latest Df ########## "+apijoinColNm)
              
              logger.info("#########deletetableDF########## "+deletetablejoinColNm)

            
              var deleteindicatorDF = finalrefLatestDf.as("d1")
              .join(deletetableDF.as("d2"),finalrefLatestDf(apijoinColNm) === deletetableDF(deletetablejoinColNm),"left")
              .withColumn("src_dlt_ind", when(deletetableDF(deletetablejoinColNm).isNull,0).otherwise(1))
              .select("d1.*","src_dlt_ind")
              
              logger.info("#########Checking records post joining with Delete table########## "+deleteindicatorDF.show(2))
              
              finalrefLatestDf = deleteindicatorDF
              logger.info("#########Records for final DF after delete indicator ########## "+finalrefLatestDf.show(2))
              
             }
       }
            //
            
            val status = Utilities.storeDataFrame(finalrefLatestDf, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable,configObject)
           
            if(!status){
              logger.error("Switching of Consumption table location failed!")
              auditObj.setAudJobStatusCode("failed")
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
              System.exit(1)
            }
            
          case _ =>
            //Applying CDC when there is already some data in the Consumption Table
            logger.info("Counsumption Count------>" + consumptionDF.count())
            val temp_NewRecordsRef = finalrefLatestDf.select(surrKeyList.map(c => col(c).alias(c + "_tmp")).toList: _*)
            logger.info("###########################Temp DF Columns################" + temp_NewRecordsRef.columns.toList)
            val newcolList = surrKeyList.map(c => (c + "_tmp")).toList
            val joinExpr = surrKeyList
              .zip(newcolList)
              .map { case (c1, c2) => consumptionDF(c1) === temp_NewRecordsRef(c2) }
              .reduce(_ && _)
            logger.info("###########################Joining Expression################" + joinExpr.toString())

            val joinDfUpdatedFinalRecords = consumptionDF.join(temp_NewRecordsRef, joinExpr, "left")

            logger.info("###########################Count of Records Post JOining condition################" + joinDfUpdatedFinalRecords.count())
            logger.info("###########################Joining completed################")
            logger.info("###########################Insert Update starting################")

            val nullablecol = newcolList(0);
            val nonUpdatedRecords = joinDfUpdatedFinalRecords.filter(f"${nullablecol} is null").drop(temp_NewRecordsRef.columns: _*)

            logger.info("###########################Non Updated Records################" + nonUpdatedRecords.count())
            logger.info("###########################Non Updated Records################" + nonUpdatedRecords.columns.toList.length)
            logger.info("###########################finalrefLatestDf################" + finalrefLatestDf.columns.toList.length)

            var finalDf = finalrefLatestDf.withColumn("ins_ts", from_unixtime(unix_timestamp()))
              .select(colList.head, colList.tail: _*)
              .union(nonUpdatedRecords)

            if(!deleteflag.isEmpty()){
                if (deleteflag.equalsIgnoreCase("y")){
              
              val apijoinColNm =joinCol.split("\\|")(0)
              val deletetablejoinColNm =joinCol.split("\\|")(1)
              
              logger.info("#########Starting Delete Mechanism for CDC logic########## ")
              
              val deletetableDF = spark.sql(f"""select * from ${deletetableName} where obj_nm ='${apiName}' """)
              
              logger.info("#########Delete Table DF ########## "+deletetableDF.count())
              
              logger.info("#########Final Ref Latest Df ########## "+apijoinColNm)
              
              logger.info("#########deletetableDF########## "+deletetablejoinColNm)
              
            
              var deleteindicatorDF1 = finalDf.as("d1")
              .join(deletetableDF.as("d2"),finalDf(apijoinColNm) === deletetableDF(deletetablejoinColNm),"left")
              .withColumn("src_dlt_ind", when(deletetableDF(deletetablejoinColNm).isNull,0).otherwise(1))
              .select("d1.*","src_dlt_ind")
              
              logger.info("#########Checking records post joining with Delete table########## "+deleteindicatorDF1.show(2))
              
              finalDf = deleteindicatorDF1//.withColumn("src_dlt_ind", when(col(deletetablejoinColNm).isNull,0).otherwise(1)).drop(col(deletetablejoinColNm))  
             
              logger.info("#########Records for final DF after delete indicator ########## "+finalDf.show(2))
              
            }
        }
              
            logger.info("###########################final DF count for Insert Update################" + finalDf.count())

            tgt_count = finalDf.count().toInt
            val status = Utilities.storeDataFrame(finalDf, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable,configObject)
            if(!status){
              logger.error("Switching of Consumption table location failed!")
              auditObj.setAudJobStatusCode("failed")
              auditObj.setAudSrcRowCount(src_count)
              auditObj.setAudTgtRowCount(tgt_count)
              val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
              auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
              auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
              Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
              System.exit(1)
            }
        }
        /*          }*/

        /*auditObj.setAudBatchId(auditBatchId)
        auditObj.setAudDataLayerName("ref_cnsmptn")
        auditObj.setAudApplicationName("job_EA_loadNonConfigJSON")
        auditObj.setAudObjectName(propertiesObject.getObjName())
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))*/
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(src_count)
        auditObj.setAudTgtRowCount(tgt_count)
        /*auditObj.setAudErrorRecords(0)
        auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
        auditObj.setFlNm("")
        auditObj.setSysBtchNr(ld_jb_nr)*/
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      } catch {
        
        case sslException: InterruptedException => {
          logger.error("Interrupted Exception")
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          System.exit(1)
        }
        case nseException: NoSuchElementException => {
          logger.error("No Such element found: " + nseException.printStackTrace())
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          System.exit(1)
        }
        case anaException: AnalysisException => {
          logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          System.exit(1)
        } 
       case connException: ConnectException => {
          logger.error("Connection Exception: " + connException.printStackTrace())
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
          sqlCon.close()
          System.exit(1)
        } 
      } 
    } else {
      spark.close()
      sqlCon.close()
    }
  }
}
package main.scala.com.hpe.refconsumption.config

import org.apache.hadoop.mapreduce.lib.input.TextInputFormat
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import kafka.serializer.StringDecoder
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.DataFrame
import main.scala.com.hpe.refconsumption.utils.Utilities
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructType
import java.math.BigInteger
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.Subscribe
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.kafka010._
import org.apache.spark.sql.catalyst.plans.logical.With

object SetUpConfiguration extends ConfigurationDetails {


  /**
   * Function to set the Spark Context objects
   *
   * @return Configuration Object
   */	
  def getSparkStreamingContext(pollingWindow:Long,maxRatePerPartition:String):ConfigObject={
  		try{
  		      val sparkConf=new SparkConf()//.setAppName(APPLICATION_NAME).setMaster("yarn")
						SetUpConfiguration.Setproperties(sparkConf,maxRatePerPartition)
  		      val spark = SparkSession.builder().enableHiveSupport().config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").config("spark.sql.hive.convertMetastoreOrc", "false").config(sparkConf).getOrCreate()
						val ssc = new StreamingContext(spark.sparkContext,Seconds(pollingWindow))
  		      val configObject=new ConfigObject(sparkConf,spark,ssc)
      			return configObject
  		} 
  		catch {
  		case textError: Throwable => textError.printStackTrace() // TODO: handle error
  				//logger.error("Could Not create the sparkConf,sparkContext,sqlContext,hiveContext")
  				//logger.debug(textError)
  				sys.exit(1)
  		}
  	}


  /**
   * Function to set the Spark related properties
   *
   * @param configObject		: Configuration Object   
   */
	def Setproperties(sparkConf: SparkConf,maxRatePerPartition:String)
	{
	   // logger.info("Setting up the properties for SparkContext")
	    /*sparkConf.set("spark.executor.cores", SPARK_EXECUTOR_CORES)
	    sparkConf.set("spark.executor.memory", SPARK_EXECUTOR_MEMORY)*/
	    sparkConf.set("spark.network.timeout", SPARK_NETWORK_TIMOUT_TS)
	    sparkConf.set("spark.sql.broadcastTimeout", SPARK_SQL_BROADCAST_TIMEOUT)
	    sparkConf.set("spark.sql.tungsten.enabled", "true")
	    sparkConf.set("spark.eventLog.enabled", "true")
	    sparkConf.set("spark.io.compression.codec", "snappy")
	    sparkConf.set("spark.rdd.compress", "true")
	    sparkConf.set("spark.dynamicAllocation.enabled", "true")
	    sparkConf.set("spark.shuffle.service.enabled", "true")
      sparkConf.set("spark.streaming.kafka.maxRatePerPartition",maxRatePerPartition)
   //   sparkConf.set("spark.streaming.concurrentJobs","6")
      sparkConf.set("spark.streaming.unpersist","true")
      sparkConf.set("spark.streaming.backpressure.enabled","true")
      /*sparkConf.set("spark.cores.max", "50")
      sparkConf.set("spark.executor.instances", "4")
      sparkConf.set("spark.executor.cores", "10")*/
      sparkConf.set("spark.serializer","org.apache.spark.serializer.KryoSerializer")
      sparkConf.set("spark.driver.extraJavaOptions", "-XX:+UseG1GC")
      sparkConf.set("spark.executor.extraJavaOptions", "-XX:+UseG1GC")
      sparkConf.set("spark.yarn.historyServer.allowTracking", "true")
      sparkConf.set("spark.shuffle.memoryFraction", "1")
	}
	
	/**
	 * setup method invokes other methods for setup before job processing starts
	 * @return : Configuration Object
	 */
	def setup(pollingWindow:Long,maxRatePerPartition:String):ConfigObject = {
	  val config=SetUpConfiguration.getSparkStreamingContext(pollingWindow,maxRatePerPartition)
		return config	  
	}

}
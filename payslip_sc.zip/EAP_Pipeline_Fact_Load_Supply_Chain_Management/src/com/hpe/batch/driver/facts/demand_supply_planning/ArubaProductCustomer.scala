package com.hpe.batch.driver.facts.demand_supply_planning

import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import java.util.Calendar
import java.text.SimpleDateFormat
import org.apache.spark.sql.{DataFrame, SparkSession}

object ArubaProductCustomer extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
   val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  
try {
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val transformeSrcdDF = spark.sql("""select * from """ + propertiesObject.getSrcTblConsmtn() )
  var src_count = transformeSrcdDF.count().toInt
  

    //****************************Fact Code****************************************//

var aruba_mthly_prod_cust_all_rgn_dmnsn="aruba_mthly_prod_cust_all_rgn_dmnsn"

var transformedDF_1 = spark.sql("""select
aruba_mthly_prod_cust_ams_ky as aruba_mthly_prod_cust_all_rgn_ky
,prod_id
,cust_id
,Keyfigure_dt
,LVO_Quantities_cd
from
"""+ dbNameConsmtn + """.aruba_mthly_prod_cust_ams_dmnsn
union all
select
aruba_mthly_prod_cust_emea_ky as aruba_mthly_prod_cust_all_rgn_ky
,prod_id
,cust_id
,Keyfigure_dt
,LVO_Quantities_cd
from
"""+ dbNameConsmtn + """.aruba_mthly_prod_cust_emea_dmnsn
union all
select
aruba_mthly_prod_cust_apj_ky as aruba_mthly_prod_cust_all_rgn_ky
,prod_id
,cust_id
,Keyfigure_dt
,LVO_Quantities_cd
from
"""+ dbNameConsmtn + """.aruba_mthly_prod_cust_apj_dmnsn""")

var loadStatus = Utilities.storeDataFrame(transformedDF_1, "overwrite", "ORC", dbNameConsmtn + "." + aruba_mthly_prod_cust_all_rgn_dmnsn)


var aruba_mthly_prod_cust_all_rgn_joined_dmnsn="aruba_mthly_prod_cust_all_rgn_joined_dmnsn"

var transformedDF_2 = spark.sql("""select 
CASE WHEN t1.prod_id is NULL then t2.prod_id else t1.prod_id end as prod_id
,CASE WHEN t1.cust_id is NULL then t2.cust_id else t1.cust_id end as cust_id
,CASE WHEN t1.Keyfigure_dt is NULL then t2.Keyfigure_dt else t1.Keyfigure_dt end as Keyfigure_dt
,CASE WHEN t1.LVO_Quantities_cd is NULL then 0 else t1.LVO_Quantities_cd end as LVO_Quantities_cd
,CASE WHEN t2.Consensus_frcst_POR__Quarterly_cd is NULL then 0 else t2.Consensus_frcst_POR__Quarterly_cd end as Consensus_frcst_POR__Quarterly_cd
from
"""+ dbNameConsmtn + """.""" + aruba_mthly_prod_cust_all_rgn_dmnsn+""" t1
full outer join
"""+ dbNameConsmtn + """.aruba_mthly_prod_cust_wkly_dmnsn t2
on
t1.prod_id=t2.prod_id
and
t1.cust_id=t2.cust_id
and
t1.Keyfigure_dt=t2.Keyfigure_dt""")

loadStatus = Utilities.storeDataFrame(transformedDF_2, "overwrite", "ORC", dbNameConsmtn + "." + aruba_mthly_prod_cust_all_rgn_joined_dmnsn)


var aruba_tchnl_wk_prod_cust_all_rgn_dmnsn="aruba_tchnl_wk_prod_cust_all_rgn_dmnsn"

var transformedDF_3 = spark.sql("""select
prod_id
,cust_id
,Keyfigure_dt
,Consensus_dmnd_pln_qty_cd
,atch_rate_frcst_lwr_prio_cd
,fnl_frcst_qty_cd
,lnkd_idpt_h_cd
,atch_rate_h_cd
,atch_rate_fnl_cd
from """+ dbNameConsmtn + """.aruba_tchnl_wk_prod_cust_ams_dmnsn
UNION ALL
select
prod_id
,cust_id
,Keyfigure_dt
,Consensus_dmnd_pln_qty_cd
,atch_rate_frcst_lwr_prio_cd
,fnl_frcst_qty_cd
,lnkd_idpt_h_cd
,atch_rate_h_cd
,atch_rate_fnl_cd
from """+ dbNameConsmtn + """.aruba_tchnl_wk_prod_cust_emea_dmnsn
union all
select
prod_id
,cust_id
,Keyfigure_dt
,Consensus_dmnd_pln_qty_cd
,atch_rate_frcst_lwr_prio_cd
,fnl_frcst_qty_cd
,lnkd_idpt_h_cd
,atch_rate_h_cd
,atch_rate_fnl_cd
from """+ dbNameConsmtn + """.aruba_tchnl_wk_prod_cust_apj_dmnsn""")

loadStatus = Utilities.storeDataFrame(transformedDF_3, "overwrite", "ORC", dbNameConsmtn + "." + aruba_tchnl_wk_prod_cust_all_rgn_dmnsn)


var aruba_tchnl_wk_prod_cust_fnl_joined_dmnsn="aruba_tchnl_wk_prod_cust_fnl_joined_dmnsn"

var transformedDF_4 = spark.sql("""select 
prod_id
,cust_id
,Keyfigure_dt
,month(keyfigure_dt) as keyfigure_mnth
,year(keyfigure_dt) as keyfigure_yr
,CASE WHEN month(keyfigure_dt) in ("11","12") then year(keyfigure_dt)+1 else year(keyfigure_dt) end as fiscal_yr
,CASE WHEN month(keyfigure_dt) in ("11","12","1") THEN "Q1" 
WHEN month(keyfigure_dt) in ("2","3","4") THEN "Q2"
WHEN month(keyfigure_dt) in ("5","6","7") THEN "Q3"
ELSE "Q4" END AS qtr 
,Consensus_dmnd_pln_qty_cd
,atch_rate_frcst_lwr_prio_cd
,fnl_frcst_qty_cd
,lnkd_idpt_h_cd
,atch_rate_h_cd
,atch_rate_fnl_cd
,LVO_Quantities_cd
,Consensus_frcst_POR__Quarterly_cd
from (select CASE WHEN t1.prod_id is NULL then t2.prod_id else t1.prod_id end as prod_id,CASE WHEN t1.cust_id is NULL then t2.cust_id else t1.cust_id end as cust_id,CASE WHEN t1.Keyfigure_dt is NULL then t2.Keyfigure_dt else t1.Keyfigure_dt end as Keyfigure_dt,CASE WHEN t1.Consensus_dmnd_pln_qty_cd  is NULL then 0 else t1.Consensus_dmnd_pln_qty_cd end as Consensus_dmnd_pln_qty_cd,CASE WHEN t1.atch_rate_frcst_lwr_prio_cd is NULL then 0 else t1.atch_rate_frcst_lwr_prio_cd end as atch_rate_frcst_lwr_prio_cd,CASE WHEN t1.fnl_frcst_qty_cd is NULL then 0 else t1.fnl_frcst_qty_cd end as fnl_frcst_qty_cd,CASE WHEN t1.lnkd_idpt_h_cd is NULL then 0 else t1.lnkd_idpt_h_cd end as lnkd_idpt_h_cd,CASE WHEN t1.atch_rate_h_cd is NULL then 0 else t1.atch_rate_h_cd end as atch_rate_h_cd,CASE WHEN t1.atch_rate_fnl_cd is NULL then 0 else t1.atch_rate_fnl_cd end as atch_rate_fnl_cd,CASE WHEN t2.LVO_Quantities_cd is NULL then 0 else t2.LVO_Quantities_cd end as LVO_Quantities_cd,CASE WHEN t2.Consensus_frcst_POR__Quarterly_cd is NULL then 0 else t2.Consensus_frcst_POR__Quarterly_cd end as Consensus_frcst_POR__Quarterly_cd from """+ dbNameConsmtn + """."""+aruba_tchnl_wk_prod_cust_all_rgn_dmnsn +""" t1
full outer join """+ dbNameConsmtn + """."""+ aruba_mthly_prod_cust_all_rgn_joined_dmnsn +""" t2
ON
t1.prod_id=t2.prod_id
and
t1.cust_id=t2.cust_id
and
month(t1.Keyfigure_dt)=month(t2.Keyfigure_dt)
and 
year(t1.Keyfigure_dt)=year(t2.Keyfigure_dt)) A""")

loadStatus = Utilities.storeDataFrame(transformedDF_4, "overwrite", "ORC", dbNameConsmtn + "." + aruba_tchnl_wk_prod_cust_fnl_joined_dmnsn)



var aruba_tchnl_wk_prod_cust_fnl_mnthly_dmnsn="aruba_tchnl_wk_prod_cust_fnl_mnthly_dmnsn"

var transformedDF_5 = spark.sql("""select 
prod_id
,cust_id
,keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr 
,sum(COALESCE(Consensus_dmnd_pln_qty_cd,0L)) as Consensus_dmnd_pln_qty_cd_mnthly
,sum(COALESCE(atch_rate_frcst_lwr_prio_cd,0L)) as atch_rate_frcst_lwr_prio_cd_mnthly
,sum(COALESCE(fnl_frcst_qty_cd,0L)) as fnl_frcst_qty_cd_mnthly
,sum(COALESCE(lnkd_idpt_h_cd,0L)) as lnkd_idpt_h_cd_mnthly
,sum(COALESCE(atch_rate_h_cd,0L)) as atch_rate_h_cd_mnthly
,sum(COALESCE(atch_rate_fnl_cd,0L)) as atch_rate_fnl_cd_mnthly
from """+ dbNameConsmtn + """."""+ aruba_tchnl_wk_prod_cust_fnl_joined_dmnsn +""" t1
group by
prod_id
,cust_id
,keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr""")

loadStatus = Utilities.storeDataFrame(transformedDF_5, "overwrite", "ORC", dbNameConsmtn + "." + aruba_tchnl_wk_prod_cust_fnl_mnthly_dmnsn)


var aruba_tchnl_wk_prod_cust_fnl_qtrly_dmnsn="aruba_tchnl_wk_prod_cust_fnl_qtrly_dmnsn"

var transformedDF_6 = spark.sql("""select 
prod_id
,cust_id
,fiscal_yr
,qtr
,COALESCE(max(m1),0L) as Consensus_dmnd_pln_qty_cd_m1
,COALESCE(max(m2),0L) as Consensus_dmnd_pln_qty_cd_m2
,COALESCE(max(m3),0L) as Consensus_dmnd_pln_qty_cd_m3
,COALESCE(max(fnl_frcst_qty_cd_m1),0L) as fnl_frcst_qty_cd_m1
,COALESCE(max(fnl_frcst_qty_cd_m2),0L) as fnl_frcst_qty_cd_m2
,COALESCE(max(fnl_frcst_qty_cd_m3),0L) as fnl_frcst_qty_cd_m3
from
(select 
prod_id
,cust_id
,Keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr 
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.group_map[Keyfigure_mnth]) END as m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.group_map[Keyfigure_mnth]) END as m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.group_map[Keyfigure_mnth]) END as m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.group_map_fnl_frcst_qty_cd[Keyfigure_mnth]) END as fnl_frcst_qty_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.group_map_fnl_frcst_qty_cd[Keyfigure_mnth]) END as fnl_frcst_qty_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.group_map_fnl_frcst_qty_cd[Keyfigure_mnth]) END as fnl_frcst_qty_cd_m3
from
( 
select 
prod_id
,cust_id 
,Keyfigure_mnth
,Keyfigure_yr
,fiscal_yr
,qtr
,map(Keyfigure_mnth,Consensus_dmnd_pln_qty_cd_mnthly) as group_map
,map(Keyfigure_mnth,fnl_frcst_qty_cd_mnthly) as group_map_fnl_frcst_qty_cd
from """+ dbNameConsmtn + """."""+ aruba_tchnl_wk_prod_cust_fnl_mnthly_dmnsn +""" ) a 
group by
prod_id
,cust_id 
,Keyfigure_mnth
,Keyfigure_yr
,fiscal_yr
,qtr  ) a
group by
prod_id
,cust_id
,fiscal_yr
,qtr""")

loadStatus = Utilities.storeDataFrame(transformedDF_6, "overwrite", "ORC", dbNameConsmtn + "." + aruba_tchnl_wk_prod_cust_fnl_qtrly_dmnsn)


var aruba_tchnl_wk_prod_cust_fnl_qtrly_joined_dmnsn="aruba_tchnl_wk_prod_cust_fnl_qtrly_joined_dmnsn"

var transformedDF_7 = spark.sql("""select 
t1.prod_id
,t1.cust_id
,t1.Keyfigure_dt
,t1.keyfigure_mnth
,t1.Keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,t1.Consensus_dmnd_pln_qty_cd
,t1.atch_rate_frcst_lwr_prio_cd
,t1.fnl_frcst_qty_cd 
,t1.lnkd_idpt_h_cd
,t1.atch_rate_h_cd
,t1.atch_rate_fnl_cd
,t1.LVO_Quantities_cd
,t1.Consensus_frcst_POR__Quarterly_cd
,t2.Consensus_dmnd_pln_qty_cd_mnthly
,t2.atch_rate_frcst_lwr_prio_cd_mnthly
,t2.fnl_frcst_qty_cd_mnthly 
,t2.lnkd_idpt_h_cd_mnthly
,t2.atch_rate_h_cd_mnthly
,t2.atch_rate_fnl_cd_mnthly
,t3.Consensus_dmnd_pln_qty_cd_m1
,t3.Consensus_dmnd_pln_qty_cd_m2
,t3.Consensus_dmnd_pln_qty_cd_m3
,t3.fnl_frcst_qty_cd_m1
,t3.fnl_frcst_qty_cd_m2
,t3.fnl_frcst_qty_cd_m3
from """+ dbNameConsmtn + """."""+ aruba_tchnl_wk_prod_cust_fnl_joined_dmnsn +""" t1
left join """+ dbNameConsmtn + """."""+ aruba_tchnl_wk_prod_cust_fnl_mnthly_dmnsn +""" t2
on 
t1.prod_id=t2.prod_id
and
t1.cust_id=t2.cust_id
and 
t1.keyfigure_mnth=t2.keyfigure_mnth
and 
t1.keyfigure_yr=t2.keyfigure_yr
left join """+ dbNameConsmtn + """."""+ aruba_tchnl_wk_prod_cust_fnl_qtrly_dmnsn +""" t3
on
t1.prod_id=t3.prod_id
and
t1.cust_id=t3.cust_id
and 
t1.qtr=t3.qtr
and 
t1.fiscal_yr=t3.fiscal_yr""")

loadStatus = Utilities.storeDataFrame(transformedDF_7, "overwrite", "ORC", dbNameConsmtn + "." + aruba_tchnl_wk_prod_cust_fnl_qtrly_joined_dmnsn)


var snapshot_type= spark.sql("""select monthly_snapshot_date_dt from """+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn where monthly_snapshot_date_dt = current_date""")

val now = Calendar.getInstance.getTime
val dowInt = new SimpleDateFormat("u")

var transformedTgtDF:DataFrame = null

// Here dataframe will hold existing data from Fact Table for monthly snapshot creation
if (snapshot_type.count().toInt!=0)
{
transformedTgtDF = spark.sql("""select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from (select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" and snpsht_dt <> to_date(CURRENT_DATE)  and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) Wkly  union all
select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from (select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 11)) Mnthly""")
}
// Here dataframe will hold existing data from Fact Table for weekly snapshot creation
else if (dowInt.format(now) == "7")
{
transformedTgtDF = spark.sql("""select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from (select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" and snpsht_dt <> to_date(CURRENT_DATE)  and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 25)) Wkly  union all
select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from (select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) Mnthly""")
}
// Here dataframe will hold existing data from Fact Table for daily snapshot creation
else 
{
transformedTgtDF = spark.sql("""select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from (select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" and snpsht_dt <> to_date(CURRENT_DATE)  and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) Wkly  union all
select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from (select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) Mnthly""")
}

transformedTgtDF.createOrReplaceTempView("transformedTgtDF_table")

var transformedDF = spark.sql("""select hpn_prod_cust_ky,prod_id,cust_id,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,consensus_dmnd_pln_qty_cd,atch_rate_frcst_lwr_prio_cd,fnl_frcst_qty_cd,lnkd_idpt_h_cd,atch_rate_h_cd,atch_rate_fnl_cd,lvo_quantities_cd,consensus_frcst_por__quarterly_cd,consensus_dmnd_pln_qty_cd_mnthly,atch_rate_frcst_lwr_prio_cd_mnthly,fnl_frcst_qty_cd_mnthly,lnkd_idpt_h_cd_mnthly,atch_rate_h_cd_mnthly,atch_rate_fnl_cd_mnthly,consensus_dmnd_pln_qty_cd_m1,consensus_dmnd_pln_qty_cd_m2,consensus_dmnd_pln_qty_cd_m3,totl_ord_actuals_rsd_cd,totl_ord_actuals_rsd_cd_mnthly,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,consensus_dmnd_pln_qty,fnl_frcst_qty_cd_qtr,actl_fnl_frcst_qty_cd,ld_to_dp_prcnt,ld_to_dp_por_quarterly_cd,pln_accry_consensus_dmnd_pln_qty_cd,pln_accry_fnl_frcst_qty_cd,actl_consensus_dmnd_pln_qty_cd,actl_atch_rate_fnl_cd,consensus_pln_to_go,snpsht_dt,snpsht_typ from  transformedTgtDF_table union all
select
CASE WHEN t2.prod_id is NULL then crc32(lower(concat(COALESCE(t1.prod_id,""),COALESCE(t1.cust_id,"")))) 
else crc32(lower(concat(COALESCE(t2.prod_id,""),COALESCE(t2.cust_id,""))))  end as hpn_prod_cust_ky
,CASE WHEN t1.prod_id is NULL then t2.prod_id else t1.prod_id end as prod_id
,CASE WHEN t1.cust_id is NULL then t2.cust_id else t1.cust_id end as cust_id
,CASE WHEN t1.Keyfigure_dt is NULL then date(t2.Keyfigure_dt) else date(t1.Keyfigure_dt) end as Keyfigure_dt
,CASE WHEN t1.Keyfigure_mnth is NULL then t2.Keyfigure_mnth else t1.Keyfigure_mnth end as Keyfigure_mnth
,CASE WHEN t1.Keyfigure_yr is NULL then t2.Keyfigure_yr else t1.Keyfigure_yr end as Keyfigure_yr
,CASE WHEN t1.fiscal_yr is NULL then t2.fiscal_yr else t1.fiscal_yr end as fiscal_yr
,CASE WHEN t1.qtr is NULL then t2.qtr else t1.qtr end as qtr
,CASE WHEN t1.Consensus_dmnd_pln_qty_cd  is NULL then 0 else t1.Consensus_dmnd_pln_qty_cd end as Consensus_dmnd_pln_qty_cd
,CASE WHEN t1.atch_rate_frcst_lwr_prio_cd is NULL then 0 else t1.atch_rate_frcst_lwr_prio_cd end as atch_rate_frcst_lwr_prio_cd
,CASE WHEN t1.fnl_frcst_qty_cd is NULL then 0 else t1.fnl_frcst_qty_cd end as fnl_frcst_qty_cd
,CASE WHEN t1.lnkd_idpt_h_cd is NULL then 0 else t1.lnkd_idpt_h_cd end as lnkd_idpt_h_cd
,CASE WHEN t1.atch_rate_h_cd is NULL then 0 else t1.atch_rate_h_cd end as atch_rate_h_cd
,CASE WHEN t1.atch_rate_fnl_cd is NULL then 0 else t1.atch_rate_fnl_cd end as atch_rate_fnl_cd
,CASE WHEN t1.LVO_Quantities_cd is NULL then 0 else t1.LVO_Quantities_cd end as LVO_Quantities_cd
,CASE WHEN t1.Consensus_frcst_POR__Quarterly_cd is NULL then 0 else t1.Consensus_frcst_POR__Quarterly_cd end as Consensus_frcst_POR__Quarterly_cd
,CASE WHEN t1.Consensus_dmnd_pln_qty_cd_mnthly  is NULL then 0 else t1.Consensus_dmnd_pln_qty_cd_mnthly end as Consensus_dmnd_pln_qty_cd_mnthly
,CASE WHEN t1.atch_rate_frcst_lwr_prio_cd_mnthly is NULL then 0 else t1.atch_rate_frcst_lwr_prio_cd_mnthly end as atch_rate_frcst_lwr_prio_cd_mnthly
,CASE WHEN t1.fnl_frcst_qty_cd_mnthly is NULL then 0 else t1.fnl_frcst_qty_cd_mnthly end as fnl_frcst_qty_cd_mnthly
,CASE WHEN t1.lnkd_idpt_h_cd_mnthly is NULL then 0 else t1.lnkd_idpt_h_cd_mnthly end as lnkd_idpt_h_cd_mnthly
,CASE WHEN t1.atch_rate_h_cd_mnthly is NULL then 0 else t1.atch_rate_h_cd_mnthly end as atch_rate_h_cd_mnthly
,CASE WHEN t1.atch_rate_fnl_cd_mnthly is NULL then 0 else t1.atch_rate_fnl_cd_mnthly end as atch_rate_fnl_cd_mnthly
,CASE WHEN t1.Consensus_dmnd_pln_qty_cd_m1 is NULL THEN 0 ELSE Consensus_dmnd_pln_qty_cd_m1 end as Consensus_dmnd_pln_qty_cd_m1
,CASE WHEN t1.Consensus_dmnd_pln_qty_cd_m2 is NULL THEN 0 ELSE Consensus_dmnd_pln_qty_cd_m2 end as Consensus_dmnd_pln_qty_cd_m2
,CASE WHEN t1.Consensus_dmnd_pln_qty_cd_m3 is NULL THEN 0 ELSE Consensus_dmnd_pln_qty_cd_m3 end as Consensus_dmnd_pln_qty_cd_m3
,CASE WHEN t2.totl_ord_actuals_rsd_cd is NULL THEN 0 ELSE totl_ord_actuals_rsd_cd end as totl_ord_actuals_rsd_cd
,CASE WHEN t2.totl_ord_actuals_rsd_cd_mnthly is NULL THEN 0 ELSE totl_ord_actuals_rsd_cd_mnthly end as totl_ord_actuals_rsd_cd_mnthly
,CASE WHEN t2.totl_ord_actuals_rsd_cd_m1 is NULL THEN 0 ELSE totl_ord_actuals_rsd_cd_m1 end as totl_ord_actuals_rsd_cd_m1
,CASE WHEN t2.totl_ord_actuals_rsd_cd_m2 is NULL THEN 0 ELSE totl_ord_actuals_rsd_cd_m2 end as totl_ord_actuals_rsd_cd_m2
,CASE WHEN t2.totl_ord_actuals_rsd_cd_m3 is NULL THEN 0 ELSE totl_ord_actuals_rsd_cd_m3 end as totl_ord_actuals_rsd_cd_m3
,CASE WHEN t1.keyfigure_yr < year(current_timestamp) or  month(current_timestamp) in ("4","5","6") and t1.qtr in ("Q1") OR month(current_timestamp) in ("7","8","9") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("10","11","12") and t1.qtr in ("Q1","Q2","Q3") THEN coalesce(totl_ord_actuals_rsd_cd_m1,0L)+coalesce(totl_ord_actuals_rsd_cd_m2,0L)+coalesce(totl_ord_actuals_rsd_cd_m3,0L)
WHEN t1.keyfigure_yr > year(current_timestamp) or month(current_timestamp) in ("1","2","3") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("4","5","6") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("7","8","9") and t1.qtr in ("Q4") THEN  (Consensus_dmnd_pln_qty_cd_m1+Consensus_dmnd_pln_qty_cd_m2+Consensus_dmnd_pln_qty_cd_m3)
WHEN  month(current_timestamp) in ("1") and  t1.keyfigure_mnth  in ("1","2","3") or month(current_timestamp) in ("4") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("7") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("10") and t1.keyfigure_mnth in ("10","11","12") THEN  (Consensus_dmnd_pln_qty_cd_m1+Consensus_dmnd_pln_qty_cd_m2+Consensus_dmnd_pln_qty_cd_m3)
WHEN  month(current_timestamp) in ("2") and t1.keyfigure_mnth in ("1","2","3") or month(current_timestamp) in ("5") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("8") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("11") and t1.keyfigure_mnth in ("10","11","12") THEN  (coalesce(totl_ord_actuals_rsd_cd_m1,0L)+Consensus_dmnd_pln_qty_cd_m2+Consensus_dmnd_pln_qty_cd_m3)
WHEN  month(current_timestamp) in ("3") and t1.keyfigure_mnth in ("1","2","3") or month(current_timestamp) in ("6") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("9") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("12") and t1.keyfigure_mnth in ("10","11","12") THEN  (coalesce(totl_ord_actuals_rsd_cd_m1,0L)+coalesce(totl_ord_actuals_rsd_cd_m2,0L)+Consensus_dmnd_pln_qty_cd_m3)
END as Consensus_dmnd_pln_qty
,CASE WHEN t1.keyfigure_yr < year(current_timestamp) or  month(current_timestamp) in ("4","5","6") and t1.qtr in ("Q1") OR month(current_timestamp) in ("7","8","9") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("10","11","12") and t1.qtr in ("Q1","Q2","Q3") THEN coalesce(totl_ord_actuals_rsd_cd_m1,0L)+coalesce(totl_ord_actuals_rsd_cd_m2,0L)+coalesce(totl_ord_actuals_rsd_cd_m3,0L)
WHEN t1.keyfigure_yr > year(current_timestamp) or month(current_timestamp) in ("1","2","3") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("4","5","6") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("7","8","9") and t1.qtr in ("Q4") THEN  (fnl_frcst_qty_cd_m1+fnl_frcst_qty_cd_m2+fnl_frcst_qty_cd_m3)
WHEN  month(current_timestamp) in ("1") and  t1.keyfigure_mnth  in ("1","2","3") or month(current_timestamp) in ("4") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("7") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("10") and t1.keyfigure_mnth in ("10","11","12") THEN  (fnl_frcst_qty_cd_m1+fnl_frcst_qty_cd_m2+fnl_frcst_qty_cd_m3)
WHEN  month(current_timestamp) in ("2") and t1.keyfigure_mnth in ("1","2","3") or month(current_timestamp) in ("5") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("8") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("11") and t1.keyfigure_mnth in ("10","11","12") THEN  (coalesce(totl_ord_actuals_rsd_cd_m1,0L)+fnl_frcst_qty_cd_m2+fnl_frcst_qty_cd_m3)
WHEN  month(current_timestamp) in ("3") and t1.keyfigure_mnth in ("1","2","3") or month(current_timestamp) in ("6") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("9") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("12") and t1.keyfigure_mnth in ("10","11","12") THEN  (coalesce(totl_ord_actuals_rsd_cd_m1,0L)+coalesce(totl_ord_actuals_rsd_cd_m2,0L)+fnl_frcst_qty_cd_m3)
END as fnl_frcst_qty_cd_qtr
,CASE WHEN t1.keyfigure_mnth < month(current_timestamp) and t1.keyfigure_yr = year(current_timestamp) or t1.keyfigure_yr < year(current_timestamp) THEN coalesce(totl_ord_actuals_rsd_cd_mnthly,0L)
ELSE t1.fnl_frcst_qty_cd_mnthly END as actl_fnl_frcst_qty_cd
,CASE WHEN t1.keyfigure_mnth < month(current_timestamp) and t1.keyfigure_yr = year(current_timestamp) or t1.keyfigure_yr < year(current_timestamp) THEN coalesce(totl_ord_actuals_rsd_cd_mnthly,0L)
ELSE t1.Consensus_dmnd_pln_qty_cd_mnthly END as actl_Consensus_dmnd_pln_qty_cd
,CASE WHEN t1.keyfigure_mnth < month(current_timestamp) and t1.keyfigure_yr = year(current_timestamp) or t1.keyfigure_yr < year(current_timestamp) THEN coalesce(totl_ord_actuals_rsd_cd_mnthly,0L)
ELSE t1.atch_rate_fnl_cd_mnthly END as actl_atch_rate_fnl_cd
,coalesce(totl_ord_actuals_rsd_cd_mnthly,0L)/t1.Consensus_dmnd_pln_qty_cd_mnthly as ld_to_dp_prcnt
,coalesce(totl_ord_actuals_rsd_cd,0L)/t1.Consensus_frcst_POR__Quarterly_cd as ld_to_dp_POR_Quarterly_cd
,t1.Consensus_dmnd_pln_qty_cd/coalesce(totl_ord_actuals_rsd_cd,0L) as pln_accry_Consensus_dmnd_pln_qty_cd
,t1.fnl_frcst_qty_cd/coalesce(totl_ord_actuals_rsd_cd,0L) as pln_accry_fnl_frcst_qty_cd
,t1.Consensus_dmnd_pln_qty_cd-coalesce(totl_ord_actuals_rsd_cd,0L) as Consensus_pln_to_go
,CURRENT_DATE as snpsht_dt
,Case WHEN X.monthly_snapshot_date_dt is NOT NULL then "MONTHLY" 
when date_format(current_date, 'u') = "7" then "WEEKLY" 
else "DAILY" END AS snpsht_typ
from """+ dbNameConsmtn + """."""+ aruba_tchnl_wk_prod_cust_fnl_qtrly_joined_dmnsn +""" t1
left join
(select
t1.prod_id
,t1.cust_id
,t1.keyfigure_dt
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,sum(t1.totl_ord_actuals_rsd_cd) as totl_ord_actuals_rsd_cd
,sum(t1.lctn_splt_consensus_dmnd_pln_cd) as lctn_splt_consensus_dmnd_pln_cd
,sum(t1.totl_shp_actl_pgi_cd) as totl_shp_actl_pgi_cd
,sum(t1.bsln_dmnd_frcst_stat_cd) as bsln_dmnd_frcst_stat_cd
,sum(t1.dmnd_frcst_ovr_1_id) as dmnd_frcst_ovr_1_id
,sum(t1.idpt_ord_actuals_rsd_cd) as idpt_ord_actuals_rsd_cd
,sum(t1.dpndt_ord_actuals_rsd_cd) as dpndt_ord_actuals_rsd_cd
,sum(t1.shp_actuals_qty_cd) as shp_actuals_qty_cd
,sum(t1.totl_ord_actuals_rsd_mnl_adjmt_cd) as totl_ord_actuals_rsd_mnl_adjmt_cd
,sum(t1.totl_crctd_ord_actuals_rsd_cd) as totl_crctd_ord_actuals_rsd_cd
,sum(t1.opn_ord_qty_cd) as opn_ord_qty_cd
,sum(t1.chnl_invy_cd) as chnl_invy_cd
,sum(t1.chnl_sl_through_cd) as chnl_sl_through_cd
,sum(t1.cust_frcst_cd) as cust_frcst_cd
,sum(t1.ststcl_frcst_usr_dfnd_cd) as ststcl_frcst_usr_dfnd_cd
,sum(t1.ststcl_frcst_btch_cd) as ststcl_frcst_btch_cd
,sum(t1.consensus_dp_ovrd_id) as consensus_dp_ovrd_id
,sum(t1.cfrd_cust_sply_cd) as cfrd_cust_sply_cd
,sum(t1.customer_idpt_ord_Actuals_RSD_cd) as customer_idpt_ord_Actuals_RSD_cd
,sum(t1.totl_ord_actuals_rsd_cd_mnthly) as totl_ord_actuals_rsd_cd_mnthly
,sum(t1.lctn_splt_consensus_dmnd_pln_cd_mnthly) as lctn_splt_consensus_dmnd_pln_cd_mnthly
,sum(t1.totl_shp_actl_pgi_cd_mnthly) as totl_shp_actl_pgi_cd_mnthly
,sum(t1.bsln_dmnd_frcst_stat_cd_mnthly) as bsln_dmnd_frcst_stat_cd_mnthly
,sum(t1.dmnd_frcst_ovr_1_id_mnthly) as dmnd_frcst_ovr_1_id_mnthly
,sum(t1.idpt_ord_actuals_rsd_cd_mnthly) as idpt_ord_actuals_rsd_cd_mnthly
,sum(t1.dpndt_ord_actuals_rsd_cd_mnthly) as dpndt_ord_actuals_rsd_cd_mnthly
,sum(t1.shp_actuals_qty_cd_mnthly) as shp_actuals_qty_cd_mnthly
,sum(t1.totl_ord_actuals_rsd_mnl_adjmt_cd_mnthly) as totl_ord_actuals_rsd_mnl_adjmt_cd_mnthly
,sum(t1.totl_crctd_ord_actuals_rsd_cd_mnthly) as totl_crctd_ord_actuals_rsd_cd_mnthly
,sum(t1.opn_ord_qty_cd_mnthly) as opn_ord_qty_cd_mnthly
,sum(t1.chnl_invy_cd_mnthly) as chnl_invy_cd_mnthly
,sum(t1.chnl_sl_through_cd_mnthly) as chnl_sl_through_cd_mnthly
,sum(t1.cust_frcst_cd_mnthly) as cust_frcst_cd_mnthly
,sum(t1.ststcl_frcst_usr_dfnd_cd_mnthly) as ststcl_frcst_usr_dfnd_cd_mnthly
,sum(t1.ststcl_frcst_btch_cd_mnthly) as ststcl_frcst_btch_cd_mnthly
,sum(t1.consensus_dp_ovrd_id_mnthly) as consensus_dp_ovrd_id_mnthly
,sum(t1.cfrd_cust_sply_cd_mnthly) as cfrd_cust_sply_cd_mnthly
,sum(t1.customer_idpt_ord_Actuals_RSD_cd_mnthly) as customer_idpt_ord_Actuals_RSD_cd_mnthly
,sum(t1.totl_ord_actuals_rsd_cd_m1) as totl_ord_actuals_rsd_cd_m1
,sum(t1.totl_ord_actuals_rsd_cd_m2) as totl_ord_actuals_rsd_cd_m2
,sum(t1.totl_ord_actuals_rsd_cd_m3) as totl_ord_actuals_rsd_cd_m3
,sum(t1.lctn_splt_consensus_dmnd_pln_cd_m1) as lctn_splt_consensus_dmnd_pln_cd_m1
,sum(t1.lctn_splt_consensus_dmnd_pln_cd_m2) as lctn_splt_consensus_dmnd_pln_cd_m2
,sum(t1.lctn_splt_consensus_dmnd_pln_cd_m3) as lctn_splt_consensus_dmnd_pln_cd_m3
,sum(t1.totl_shp_actl_pgi_cd_m1) as totl_shp_actl_pgi_cd_m1
,sum(t1.totl_shp_actl_pgi_cd_m2) as totl_shp_actl_pgi_cd_m2
,sum(t1.totl_shp_actl_pgi_cd_m3) as totl_shp_actl_pgi_cd_m3
,sum(t1.bsln_dmnd_frcst_stat_cd_m1) as bsln_dmnd_frcst_stat_cd_m1
,sum(t1.bsln_dmnd_frcst_stat_cd_m2) as bsln_dmnd_frcst_stat_cd_m2
,sum(t1.bsln_dmnd_frcst_stat_cd_m3) as bsln_dmnd_frcst_stat_cd_m3
,sum(t1.dmnd_frcst_ovr_1_id_m1) as dmnd_frcst_ovr_1_id_m1
,sum(t1.dmnd_frcst_ovr_1_id_m2) as dmnd_frcst_ovr_1_id_m2
,sum(t1.dmnd_frcst_ovr_1_id_m3) as dmnd_frcst_ovr_1_id_m3
,sum(t1.ststcl_frcst_usr_dfnd_cd_m1) as ststcl_frcst_usr_dfnd_cd_m1
,sum(t1.ststcl_frcst_usr_dfnd_cd_m2) as ststcl_frcst_usr_dfnd_cd_m2
,sum(t1.ststcl_frcst_usr_dfnd_cd_m3) as ststcl_frcst_usr_dfnd_cd_m3
,sum(t1.ststcl_frcst_btch_cd_m1) as ststcl_frcst_btch_cd_m1
,sum(t1.ststcl_frcst_btch_cd_m2) as ststcl_frcst_btch_cd_m2
,sum(t1.ststcl_frcst_btch_cd_m3) as ststcl_frcst_btch_cd_m3
,sum(t1.consensus_dp_ovrd_id_m1) as consensus_dp_ovrd_id_m1
,sum(t1.consensus_dp_ovrd_id_m2) as consensus_dp_ovrd_id_m2
,sum(t1.consensus_dp_ovrd_id_m3) as consensus_dp_ovrd_id_m3
from """+ dbNameConsmtn + """.aruba_prod_lctn_cust_fact t1
group by
t1.prod_id
,t1.cust_id
,t1.keyfigure_dt
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr) t2
on
t1.prod_id = t2.prod_id
and
t1.cust_id = t2.cust_id
and
t1.keyfigure_dt=t2.keyfigure_dt
LEFT join
"""+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn X
on current_date()=X.monthly_snapshot_date_dt""")

loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable)
spark.catalog.dropTempView("transformedTgtDF_table")

//************************Completion Audit Entries*******************************//

    var tgt_count = transformedDF.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("cnsmptn_fact")
    auditObj.setAudApplicationName("ArubaProductCustomer")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)     
    }
    case allException: IllegalArgumentException => {
      logger.error("Illegal Argument")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  }
  finally {
    sqlCon.close()
    spark.close()
  }
}
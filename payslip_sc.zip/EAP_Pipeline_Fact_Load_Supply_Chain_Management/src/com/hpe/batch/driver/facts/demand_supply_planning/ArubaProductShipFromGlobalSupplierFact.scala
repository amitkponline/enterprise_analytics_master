package com.hpe.batch.driver.facts.demand_supply_planning

import java.util.Calendar
import java.text.SimpleDateFormat
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import java.util.Calendar
import java.text.SimpleDateFormat
import org.apache.spark.sql.{DataFrame, SparkSession}

object ArubaProductShipFromGlobalSupplierFact extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  
  try {
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  
  val transformeSrcdDF = spark.sql("""select * from """ + propertiesObject.getSrcTblConsmtn() )

  var src_count = transformeSrcdDF.count().toInt

    //****************************Fact Code****************************************//

val now = Calendar.getInstance.getTime
val dowInt = new SimpleDateFormat("u")
var transformedTgtDF:DataFrame = null
var aruba_prod_shipfromglobalsupplier_jn_dmnsn="aruba_prod_shipfromglobalsupplier_jn_dmnsn"

var transformedDF_1 = spark.sql("""select
CASE WHEN a.ky_fgr_dt is not NULL then a.ky_fgr_dt
WHEN b.ky_fg_1_dt is not NULL then b.ky_fg_1_dt
WHEN c.ky_fg_2_dt is not NULL then c.ky_fg_2_dt
else d.ky_fgr_dt end as ky_fgr_dt
,CASE WHEN b.prod_i_1_id is not NULL then b.prod_i_1_id
WHEN c.prod_i_2_id is not NULL then c.prod_i_2_id
else a.prod_id end as prod_id
,CASE WHEN b.shipfrom_gbl_splyr_i_1_id is not NULL then b.shipfrom_gbl_splyr_i_1_id
WHEN c.shipfrom_gbl_splyr_i_2_id is not NULL then c.shipfrom_gbl_splyr_i_2_id
else a.shipfrom_gbl_splyr_id end as shipfrom_gbl_splyr_id
,coalesce(A.ww_frpfinal_to_splyr_cd,0L) as ww_frpfinal_to_splyr_cd
,coalesce(D.ww_frpfinal_to_splyr_cd,0L) as ww_frpfinal_to_splyr_cd_wk
,coalesce(ww_frp_fnl_qtr_por_cd,0L) as ww_frp_fnl_qtr_por_cd
,coalesce(cntrl_stk_tgt_cd,0L) as cntrl_stk_tgt_cd
from """+ dbNameConsmtn + "." + """aruba_tchnl_wk_prod_shipfromglobalsupplier_dmnsn A
FULL JOIN """+ dbNameConsmtn + "." + """aruba_mthly_prod_shipfromglobalsupplier_da_dmnsn B
on A.prod_id=B.prod_i_1_id
and month(A.ky_fgr_dt)=month(B.ky_fg_1_dt)
and year(A.ky_fgr_dt)=year(B.ky_fg_1_dt)
and A.shipfrom_gbl_splyr_id =B.shipfrom_gbl_splyr_i_1_id
FULL JOIN """+ dbNameConsmtn + "." + """aruba_mthly_prod_shipfromglobalsupplier_qa_dmnsn C  
on A.prod_id=C.prod_i_2_id
and month(A.ky_fgr_dt)=month(C.ky_fg_2_dt)
and year(A.ky_fgr_dt)=year(C.ky_fg_2_dt)
and A.shipfrom_gbl_splyr_id =C.shipfrom_gbl_splyr_i_2_id
FULL JOIN """+ dbNameConsmtn + "." + """aruba_tchnl_wk_prod_shipfromglobalsupplier_wk_dmnsn D  
on A.prod_id=D.prod_id
and A.ky_fgr_dt=D.ky_fgr_dt
and A.shipfrom_gbl_splyr_id =D.ShipFrom_gbl_splyr_id""")

var loadStatus = Utilities.storeDataFrame(transformedDF_1, "overwrite", "ORC", dbNameConsmtn + "." + aruba_prod_shipfromglobalsupplier_jn_dmnsn)



var aruba_prod_shipfromglobalsupplier_mnthly_dmnsn="aruba_prod_shipfromglobalsupplier_mnthly_dmnsn"

var transformedDF_2 = spark.sql("""select
month(ky_fgr_dt) as ky_fgr_mnth
,year(ky_fgr_dt) as ky_fgr_yr
,CASE WHEN month(ky_fgr_dt) in ("11","12") then year(ky_fgr_dt)+1 else year(ky_fgr_dt) end as fiscal_yr
,CASE WHEN month(ky_fgr_dt) in ("11","12","1") THEN "Q1" 
WHEN month(ky_fgr_dt) in ("2","3","4") THEN "Q2"
WHEN month(ky_fgr_dt) in ("5","6","7") THEN "Q3"
ELSE "Q4" END AS qtr 
,prod_id
,sum(ww_frpfinal_to_splyr_cd) as ww_frpfinal_to_splyr_cd_mnthly
,sum(ww_frpfinal_to_splyr_cd_wk) as ww_frpfinal_to_splyr_cd_wk_mnthly
from """+ dbNameConsmtn + "." + """aruba_prod_shipfromglobalsupplier_jn_dmnsn
group by
month(ky_fgr_dt)
,year(ky_fgr_dt)
,prod_id""")

loadStatus = Utilities.storeDataFrame(transformedDF_2, "overwrite", "ORC", dbNameConsmtn + "." + aruba_prod_shipfromglobalsupplier_mnthly_dmnsn)


var aruba_prod_shipfromglobalsupplier_qtrly_dmnsn="aruba_prod_shipfromglobalsupplier_qtrly_dmnsn"

var transformedDF_3 = spark.sql("""select 
prod_id
,ky_fgr_yr
,qtr 
,COALESCE(max(ww_frpfinal_to_splyr_cd_wk_m1),0L) as ww_frpfinal_to_splyr_cd_m1
,COALESCE(max(ww_frpfinal_to_splyr_cd_wk_m2),0L) as ww_frpfinal_to_splyr_cd_m2
,COALESCE(max(ww_frpfinal_to_splyr_cd_wk_m3),0L) as ww_frpfinal_to_splyr_cd_m3
,COALESCE(max(ww_frpfinal_to_splyr_cd_wk_m1),0L) as ww_frpfinal_to_splyr_cd_wk_m1
,COALESCE(max(ww_frpfinal_to_splyr_cd_wk_m2),0L) as ww_frpfinal_to_splyr_cd_wk_m2
,COALESCE(max(ww_frpfinal_to_splyr_cd_wk_m3),0L) as ww_frpfinal_to_splyr_cd_wk_m3
from
(select 
prod_id
,ky_fgr_mnth
,ky_fgr_yr
,qtr 
,CASE WHEN ky_fgr_mnth in ("11","2","5","8")then  sum(a.ww_frpfinal_to_splyr_cd_map[ky_fgr_mnth]) END as ww_frpfinal_to_splyr_cd_m1
,CASE WHEN ky_fgr_mnth in ("12","3","6","9")then  sum(a.ww_frpfinal_to_splyr_cd_map[ky_fgr_mnth]) END as ww_frpfinal_to_splyr_cd_m2
,CASE WHEN ky_fgr_mnth in ("1","4","7","10")then  sum(a.ww_frpfinal_to_splyr_cd_map[ky_fgr_mnth]) END as ww_frpfinal_to_splyr_cd_m3
,CASE WHEN ky_fgr_mnth in ("11","2","5","8")then  sum(a.ww_frpfinal_to_splyr_cd_wk_map[ky_fgr_mnth]) END as ww_frpfinal_to_splyr_cd_wk_m1
,CASE WHEN ky_fgr_mnth in ("12","3","6","9")then  sum(a.ww_frpfinal_to_splyr_cd_wk_map[ky_fgr_mnth]) END as ww_frpfinal_to_splyr_cd_wk_m2
,CASE WHEN ky_fgr_mnth in ("1","4","7","10")then  sum(a.ww_frpfinal_to_splyr_cd_wk_map[ky_fgr_mnth]) END as ww_frpfinal_to_splyr_cd_wk_m3
from
( 
select 
prod_id
,ky_fgr_mnth
,ky_fgr_yr
,qtr 
,map(ky_fgr_mnth,ww_frpfinal_to_splyr_cd_mnthly) as ww_frpfinal_to_splyr_cd_map
,map(ky_fgr_mnth,ww_frpfinal_to_splyr_cd_wk_mnthly) as ww_frpfinal_to_splyr_cd_wk_map
from """+dbNameConsmtn + "." + aruba_prod_shipfromglobalsupplier_mnthly_dmnsn+""") a 
group by
prod_id
,ky_fgr_mnth
,ky_fgr_yr
,qtr ) b
group by
prod_id
,ky_fgr_yr
,qtr""")


loadStatus = Utilities.storeDataFrame(transformedDF_3, "overwrite", "ORC", dbNameConsmtn + "." + aruba_prod_shipfromglobalsupplier_qtrly_dmnsn)

var snapshot_type= spark.sql("""select monthly_snapshot_date_dt from """+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn where monthly_snapshot_date_dt = current_date""")

// Here dataframe will hold existing data from Fact Table for monthly snapshot creation
if (snapshot_type.count().toInt!=0)
{
transformedTgtDF = spark.sql("""select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) Wkly  union all
select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 11)) Mnthly""")
}
// Here dataframe will hold existing data from Fact Table for weekly snapshot creation
else if (dowInt.format(now) == "7")
{
transformedTgtDF = spark.sql("""select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 25)) Wkly  union all
select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) Mnthly""")
}
// Here dataframe will hold existing data from Fact Table for daily snapshot creation
else 
{
transformedTgtDF = spark.sql("""select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select * from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) Wkly  union all
select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) Mnthly""")
}

transformedTgtDF.createOrReplaceTempView("transformedTgtDF_table")

var aruba_prod_shipfromglobalsupplier_fact="aruba_prod_shipfromglobalsupplier_fact"

var transformedDF = spark.sql("""select aruba_prod_shipfromglobalsupplier_fact_ky	, ky_fgr_dt	, prod_id	, shipfrom_gbl_splyr_id	, ww_frpfinal_to_splyr_cd	, ww_frp_fnl_qtr_por_cd	, cntrl_stk_tgt_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  transformedTgtDF_table union all
select
crc32(upper(trim(CONCAT(coalesce(ky_fgr_dt,""),coalesce(prod_id,""),coalesce(shipfrom_gbl_splyr_id,""),coalesce(CAST(CURRENT_DATE as string),""))))) 
,date(ky_fgr_dt)
,prod_id
,shipfrom_gbl_splyr_id
,coalesce(ww_frpfinal_to_splyr_cd,0L) as ww_frpfinal_to_splyr_cd
,coalesce(ww_frp_fnl_qtr_por_cd,0L) as ww_frp_fnl_qtr_por_cd
,coalesce(cntrl_stk_tgt_cd,0L) as cntrl_stk_tgt_cd
,current_timestamp as ins_ts
,CURRENT_DATE as snpsht_dt
,Case WHEN X.monthly_snapshot_date_dt is NOT NULL then "MONTHLY" 
when date_format(current_date, 'u') = "7" then "WEEKLY" 
else "DAILY" END AS snpsht_typ
from """+ dbNameConsmtn + "." + aruba_prod_shipfromglobalsupplier_jn_dmnsn + """ A
LEFT join
"""+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn X
on current_date()=X.monthly_snapshot_date_dt""")

loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable)
spark.catalog.dropTempView("transformedTgtDF_table")

//************************Completion Audit Entries*******************************//

    var tgt_count = transformedDF.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("cnsmptn_fact")
    auditObj.setAudApplicationName("ArubaProductShipFromGlobalSupplierFact")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)     
    }
    case allException: IllegalArgumentException => {
      logger.error("Illegal Argument")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  }
  finally {
    sqlCon.close()
    spark.close()
  }
}
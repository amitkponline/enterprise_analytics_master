package com.hpe.batch.driver.facts.pdm

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.functions.row_number

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object PdmMtrlMstrGrp extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  var pdm_max_btch_id = ld_jb_nr + "_" + "19000101000000"
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val tgtTblRef = propertiesObject.getTgtTblRef()
  val audittable = propertiesObject.getAuditTbl()
  val numPartitions = propertiesObject.getNumPartitions_bref().trim().toInt
  val hive_ref_pdm_mtrl_mstr_grp_ref = propertiesObject.getHive_ref_table_pdm_mtrl_mstr_grp_ref()
  var src_count = 0
  var tgt_count = 0
  var loadStatus = true
  var ins_gmt_date=""

//************************Set Audit Entries*******************************//

  auditObj.setAudBatchId(pdm_max_btch_id)
  auditObj.setAudDataLayerName("rw_ref")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(hive_ref_pdm_mtrl_mstr_grp_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(src_count)
  auditObj.setAudTgtRowCount(tgt_count)

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, "prod_mtrl_mstr")

  try {

    var pdm_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, "prod_mtrl_mstr")

    logger.info("Bifurication Load of PDM Started!!!!!!!!!!!!!")

    logger.info("Max batch id of PDM ref table " + pdm_max_btch_id.toString())

    //**********PDM Material Master group**************************//

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********pdm_mtrl_mstr_grp_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")


    val hive_ref_pdm_mtrl_lng_join_ref = propertiesObject.getHive_ref_table_pdm_mtrl_lng_ref()

    val Keys_table_pdm_mtrl_mstr_grp_ref = propertiesObject.getKeys_table_pdm_mtrl_mstr_grp_ref()

    val pdm_mtrl_mstr_grp_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_pdm_mtrl_mstr_grp_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of PDM Material Master group table " + pdm_mtrl_mstr_grp_max_btch_id.toString())
	
	  if(pdm_mtrl_mstr_grp_max_btch_id=="19001231000000") 	 
	  {
		  ins_gmt_date=pdm_mtrl_mstr_grp_max_btch_id.substring(0,4)+'-'+pdm_mtrl_mstr_grp_max_btch_id.substring(4,6)+'-'+pdm_mtrl_mstr_grp_max_btch_id.substring(6,8)
		} 
		else
		{
			ins_gmt_date=pdm_mtrl_mstr_grp_max_btch_id.substring(19,23)+'-'+pdm_mtrl_mstr_grp_max_btch_id.substring(23,25)+'-'+pdm_mtrl_mstr_grp_max_btch_id.substring(25,27)
		}
		
    var transformeSrcdDF = spark.sql("""select count(1) from """ + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr > '" + pdm_mtrl_mstr_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "'")

	logger.info("""select count(1) from """ + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr > '" + pdm_mtrl_mstr_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "'")
	
    src_count = transformeSrcdDF.first.getLong(0).toInt

    if (src_count != 0) {
	
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudBatchId(pdm_max_btch_id)

      var hiveRefSelect = spark.sql("select " + Keys_table_pdm_mtrl_mstr_grp_ref + ",'" + pdm_max_btch_id + "' as ld_jb_nr,idoc_nr, idoc_crtd_ts, ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr > '" + pdm_mtrl_mstr_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "'").drop("mtrl_lng_mtrl_dn")

	logger.info("select " + Keys_table_pdm_mtrl_mstr_grp_ref + ",'" + pdm_max_btch_id + "' as ld_jb_nr,idoc_nr, idoc_crtd_ts, ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr > '" + pdm_mtrl_mstr_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "'")
	
      val filterRow = hiveRefSelect.filter(col("mtrl_mstr_mtrl_id").isNotNull)

      val windowSpec = Window.partitionBy("mtrl_mstr_mtrl_id").orderBy(desc("idoc_crtd_ts"), desc("mtrl_mstr_src_sys_upd_ts"), desc("ins_gmt_ts"))

      val addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm")

      val pdm_mtrl_lng_join_field = spark.sql("select mtrl_lng_mtrl_id, mtrl_lng_mtrl_dn,mtrl_lng_iso_lng_cd,mtrl_mstr_src_sys_upd_ts as b_mtrl_mstr_src_sys_upd_ts ,mtrl_mstr_src_sys_crt_ts as b_mtrl_mstr_src_sys_crt_ts,ins_gmt_ts as b_ins_gmt_ts from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + pdm_mtrl_mstr_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "' and mtrl_lng_iso_lng_cd = 'EN' and mtrl_lng_mtrl_id is not null ")

	logger.info("select mtrl_lng_mtrl_id, mtrl_lng_mtrl_dn,mtrl_lng_iso_lng_cd,mtrl_mstr_src_sys_upd_ts as b_mtrl_mstr_src_sys_upd_ts ,mtrl_mstr_src_sys_crt_ts as b_mtrl_mstr_src_sys_crt_ts,ins_gmt_ts as b_ins_gmt_ts from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + pdm_mtrl_mstr_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "' and mtrl_lng_iso_lng_cd = 'EN' and mtrl_lng_mtrl_id is not null ")
	
      var windowSpec_lng = Window.partitionBy("mtrl_lng_mtrl_id", "mtrl_lng_iso_lng_cd").orderBy(desc("b_mtrl_mstr_src_sys_crt_ts"), desc("b_mtrl_mstr_src_sys_upd_ts"), desc("b_ins_gmt_ts"))

      var addRowNo_lng = pdm_mtrl_lng_join_field.withColumn("row_nm", row_number() over windowSpec_lng).where(col("row_nm").equalTo(1)).drop("row_nm")

      val join_pdm_mtrl_mstr_grp = addRowNo.join(addRowNo_lng, addRowNo.col("mtrl_mstr_mtrl_id") === addRowNo_lng.col("mtrl_lng_mtrl_id") && addRowNo.col("mtrl_mstr_src_sys_upd_ts") === addRowNo_lng.col("b_mtrl_mstr_src_sys_upd_ts") && addRowNo.col("mtrl_mstr_src_sys_crt_ts") === addRowNo_lng.col("b_mtrl_mstr_src_sys_crt_ts") && addRowNo.col("ins_gmt_ts") === addRowNo_lng.col("b_ins_gmt_ts"), "left").drop("mtrl_lng_mtrl_id", "mtrl_lng_iso_lng_cd", "b_mtrl_mstr_src_sys_upd_ts", "b_mtrl_mstr_src_sys_crt_ts", "b_ins_gmt_ts")

      val pdm_mtrl_mstr_grp_ref_final = join_pdm_mtrl_mstr_grp.select("mtrl_mstr_src_sys_cd", "mtrl_mstr_mtrl_id", "mtrl_lng_mtrl_dn", "mtrl_mstr_mtrl_grp_cd", "mtrl_mstr_bs_unt_of_msr_cd", "mtrl_mstr_old_mtrl_id", "mtrl_mstr_trns_grp_cd", "mtrl_mstr_unspsc_xtrn_mtrl_grp_cd", "mtrl_mstr_sls_dvsn_cd", "mtrl_mstr_lb_dsgn_cd", "mtrl_mstr_prod_hrchy_cd", "mtrl_mstr_pkgg_mtrl_grp_cd", "mtrl_mstr_mtrl_typ_cd", "mtrl_mstr_indy_sctr_cd", "mtrl_mstr_dngrs_gds_cd", "mtrl_mstr_grs_wght_qty", "mtrl_mstr_nt_wght_qty", "mtrl_mstr_wght_unt_of_msr_cd", "mtrl_mstr_mtrl_vol_qty", "mtrl_mstr_vol_unt_of_msr_cd", "mtrl_mstr_mtrl_dcmt_typ_cd", "mtrl_mstr_crss_sls_mtrl_stts_cd", "mtrl_mstr_crss_plnt_mtrl_stts_cd", "mtrl_mstr_crss_plnt_mtrl_stts_eff_dt", "mtrl_mstr_crss_sls_mtrl_stts_eff_dt", "mtrl_mstr_mtrl_dcmt_pg_frmt_cd", "mtrl_mstr_mtrl_dcmt_chg_id", "mtrl_mstr_mtrl_dcmt_pg_id", "mtrl_mstr_mtrl_dcmt_pg_cnt_qty", "mtrl_mstr_mtrl_inspn_dcmt_id", "mtrl_mstr_mtrl_inspn_pg_frmt_cd", "mtrl_mstr_mtrl_sz_txt", "mtrl_mstr_indy_std_cd", "mtrl_mstr_intl_artcl_id", "mtrl_mstr_mtrl_dcmt_id", "mtrl_mstr_cad_ind", "mtrl_mstr_cnfgl_mtrl_ind", "mtrl_mstr_mtrl_dcmt_vrsn_id", "mtrl_mstr_athzn_grp_cd", "mtrl_mstr_env_rlvnt_ind", "mtrl_mstr_hgly_vscs_ind", "mtrl_mstr_blk_ind", "mtrl_mstr_cn_mdm_cd", "mtrl_mstr_mfrr_prt_id", "mtrl_mstr_mfrr_vndr_prty_id", "mtrl_mstr_crss_plnt_cnfgl_mtrl_id", "mtrl_mstr_gnrl_mtrl_itm_cgy_grp_cd", "mtrl_mstr_updd_by_usr_id", "mtrl_mstr_crtd_by_usr_id", "mtrl_mstr_src_sys_crt_ts", "mtrl_mstr_src_sys_upd_ts", "mtrl_typ_cd", "mtrl_typ_dn", "mtrl_grp_cd", "mtrl_grp_dn", "mtrl_grp_lg_dn", "prod_hrchy_cd", "prod_hrchy_dn", "prod_hrchy_lvl", "prod_hrchy_prod_typ_cd", "prod_hrchy_prod_typ_dn", "prod_hrchy_prod_cgy_cd", "prod_hrchy_prod_cgy_dn", "prod_hrchy_prod_sb_cgy_cd", "prod_hrchy_prod_sb_cgy_dn", "prod_hrchy_prod_fmly_cd", "prod_hrchy_prod_fmly_dn", "prod_hrchy_prod_srs_cd", "prod_hrchy_prod_srs_dn", "prod_hrchy_prod_mdl_cd", "prod_hrchy_prod_mdl_dn", "dngrs_gds_cd", "dngrs_gds_dn", "xtrn_mtrl_grp_cd", "xtrn_mtrl_grp_dn", "indy_sctr_cd", "indy_sctr_dn", "lb_dsgn_cd", "lb_dsgn_dn", "pkgg_mtrl_grp_cd", "pkgg_mtrl_grp_dn", "sls_dvsn_cd", "sls_dvsn_dn", "mtrl_wdth_id", "fscl_yr_vrnt_cd", "prchg_vl_cd", "pkgg_allwd_wght_unt_msrmt_cd", "pkgg_allwd_wght_qty_cd", "src_sys_crtd_dt", "pkgg_allwd_vol_unt_msrmt_cd", "pkgg_allwd_vol_qty_cd", "excess_wght_tlnc_nr", "gbl_trd_itm_nr", "harzardous_sbstc_rlvnt_ind_cd", "mtrl_hgt_cd", "prod_allctn_dtrmn_prcgr_cd", "cmpt_cd", "clsd_pkgg_mtrl_ind_cd", "last_chg_dt", "mtrl_lgt_cd", "mtrl_locked_ind_cd", "unt_dmnsn_qty_cd", "mtrl_frgt_grp_cd", "mfrr_prt_pfl_cd", "crss_dbn_chn_mtrl_stts_cd", "gnrl_itm_cgy_grp_cd", "mtrl_dscnt_ind_cd", "intl_article_cgy_cd", "qlty_mtrl_prcmt_actv_ind_cd", "ctlg_pfl_cd", "crss_plnt_mtrl_id", "srl_pfl_cd", "srl_explicitness_ind_nr", "stacking_fctr_nr", "prch_ord_unt_actv_ind_cd", "pkgg_mtrl_typ_cd", "vol_unt_cd", "excess_vol_tlnc_nr", "bsc_mtrl_dn_cd", "btch_mgmt_rqmt_ind_cd", "btch_rec_rqrd_aprvd_ind_cd", "invy_mngd_mtrl_id", "mtrl_mstr_ins_ts", "mtrl_mstr_upd_ts", "mtrl_mstr_lgcl_dlt_ind", "intgtn_fbrc_msg_id", "src_sys_upd_ts", "src_sys_ky", "lgcl_dlt_ind", "ins_gmt_ts", "upd_gmt_ts", "src_sys_extrc_gmt_ts", "src_sys_btch_nr", "fl_nm", "ld_jb_nr", "idoc_nr","idoc_crtd_ts","ins_gmt_dt").coalesce(numPartitions)

	   pdm_mtrl_mstr_grp_ref_final.write.mode("Append").format("ORC").insertInto(hive_ref_pdm_mtrl_mstr_grp_ref.trim())

	  var transformeTgtdDF = spark.sql("""select count(1) from """ + hive_ref_pdm_mtrl_mstr_grp_ref + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr = '" + pdm_max_btch_id + "'")
	  
	  logger.info("""select count(1) from """ + hive_ref_pdm_mtrl_mstr_grp_ref + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr = '" + pdm_max_btch_id + "'")

      tgt_count = transformeTgtdDF.first.getLong(0).toInt

      logger.info("+++++++++++############# Target Count: " + tgt_count + " #############+++++++++++")

      logger.info("Data has been loaded to: " + hive_ref_pdm_mtrl_mstr_grp_ref + " Table")
	
      //************************Completion Audit Entries*******************************//

      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudJobStatusCode("success")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("success")
    }
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
      toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    logger.info("************PDM Refine Bifurication completed*************************")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
  } finally {
    if (loadStatus == false) {
      sqlCon.close()
      spark.close()
      System.exit(1)
    } else {
      sqlCon.close()
      spark.close()
    }
  }
}
package com.hpe.batch.driver.facts.deliveryshipment

import main.scala.com.hpe.config._
import org.apache.spark.storage.StorageLevel
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{ StringType, StructField, StructType }
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import main.scala.com.hpe.config._
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.types.DateType
import scala.concurrent.ExecutionContext.Implicits.global
import org.joda.time.DateTime
import org.joda.time.DateTimeZone
import org.joda.time.Days
import org.joda.time.format.DateTimeFormat
import org.joda.time._
import org.joda.time.format.PeriodFormatterBuilder
import java.text.SimpleDateFormat
import java.util.{ Calendar, Date }
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._

  object ShipmentFact extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj:AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"  
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  
  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())
  val transformeSrcdDF = spark.sql("""select * from """ + propertiesObject.getSrcTblConsmtn() )
  val src_count = transformeSrcdDF.count().toInt
  try {    
  val hive_metrics_name = consmptnTable
      
println("*******************creating sm dmnsn df ************************") 

val vw_ship_Header_DF = spark.sql(s""" with `vw_ship_Header` as   (select sm.sm_ky, sm.sm_fncn_ky, crc32(cast(sm.sm_dlvry_dt as string)) as sm_dlvry_dt_ky, crc32(cast(sm.sm_prf_dlvry_cfrn_dt as string)) as sm_dlvry_cr_dt_ky  , crc32(lower(trim(COALESCE(sm.sm_shp_to_prty_id,"0")))) as sm_shp_to_prty_ky, sm.sm_storg_lctn_chg_ind_cd, sm.sm_rte_cd, sm.sm_ord_id  , sm.sm_dlvry_typ_cd, sm.sm_prf_dlvry_cfrn_dt, sm.sm_src_sys_cd, sm.sm_sm_id, sm.sm_crtd_by_usr_id, sm.sm_sm_pnt_cd, sm.sm_sls_org_cd  , sm.sm_sls_dstc_cd, sm.sm_cmplt_dlvry_ind_cd, sm.sm_ord_cmbn_ind_cd, sm.sm_plnd_gds_mvmt_dt, sm.sm_Loading_dt, sm.sm_trns_plng_dt, sm.sm_dlvry_dt  , sm.sm_pckng_dt, sm.sm_unldg_pnt_dn_cd, sm.sm_Incoterm_prt_1_cd, sm.sm_Incoterm_prt_2_cd, sm.sm_xprt_ind_cd, sm.sm_dlvry_blck_rsn_cd  , sm.sm_dcmt_cgy_cd, sm.sm_dlvry_pri_cd, sm.sm_shp_to_prty_id, sm.sm_sld_to_prty_id, sm.sm_cust_grp_cd, sm.sm_totl_sm_wght_cd, sm.sm_nt_sm_wght_cd  , sm.sm_wght_unt_msr_cd, sm.sm_sm_cndn_cd, sm.sm_sm_itm_vol_cd, sm.sm_vol_unt_msr_cd, sm.sm_totl_pkg_qty_cd, sm.sm_Picked_itm_lctn_cd, sm.sm_dlvry_ts_cd  , sm.sm_wght_grp_cd, sm.sm_Loading_pnt_cd, sm.sm_trns_grp_cd, sm.sm_prpsd_blng_typ_cd, sm.sm_Printout_blng_dt, sm.sm_inv_clndr_cd  , sm.shipment_sm_dlvry_rt_1_cd, sm.sm_curr_cd, sm.sm_sls_ofc_cd, sm.sm_sm_prsng_durtn_qty_cd, sm.sm_dlvry_cmbn_crtr_cd, sm.sm_dbn_dlvry_dn_cd  , sm.sm_Statistics_curr_cd, sm.sm_frn_trd_dta_inrn_id, sm.sm_updd_by_usr_id_dt, sm.sm_wh_cmplx_cd, sm.sm_sls_Organisation_cd, sm.sm_dbn_chnl_cd  , sm.sm_sls_dvsn_cd, sm.sm_ic_blng_typ_cd,sm.shipment_sm_ic_bln_1_dt_cd, sm.shipment_sm_ic_bln_1_dt, sm.sm_ic_blng_prty_id, sm.sm_crdt_ctrl_ar_cd  , sm.sm_cust_crdt_grp_cd, sm.sm_crdt_ctrl_ar_curr_cd, sm.sm_dcmt_rlsd_crdt_amt_cd, sm.sm_bll_ldg_nr, sm.sm_vndr_acct_id, sm.sm_trns_mtd_cd  , sm.sm_trns_mtd_id, sm.sm_crdt_dcmt_rlsd_dt, sm.sm_nxt_dt, sm.sm_dcmt_dt, sm.sm_actl_gds_mvmt_dt, sm.sm_sm_blck_rsn_cd, sm.sm_xtrn_trns_sys_id  , sm.sm_dlvry_note_xtrn_id, sm.sm_crctn_dlvry_ind_cd, sm.sm_sm_prcg_prcgr_cd, sm.sm_ord_itm_nt_amt_cd, sm.sm_rte_schdl_id, sm.sm_rcvg_plnt_cd  , sm.sm_fncl_dcmt_inrn_id, sm.sm_pmnt_grnt_prcgr_cd, sm.sm_plnt_pckng_ts_cd, sm.sm_trns_plng_ts_cd, sm.sm_Loading_ts_cd, sm.sm_gds_iss_ts_cd  , sm.sm_wh_cmplx_stgg_ar_cd, sm.sm_prty_rfnc_dcmt_id, sm.sm_evt_grp_tm_sgm_cd, sm.sm_Delivering_lctn_tm_zn_cd, sm.sm_rcpnt_lctn_tm_zn_cd  , sm.sm_Dangerous_gds_ind_cd, sm.sm_dbn_dlvry_orgl_sys_cd, sm.sm_gds_mvmt_ctrl_cd, sm.sm_dlvry_prsng_stts_cd, sm.sm_trsn_cd, sm.sm_shpg_typ_cd  , sm.sm_Means_trns_cd, sm.sm_spcl_prsng_cd, sm.sm_co_id, sm.sm_opn_vl_cltn_ind_cd, sm.sm_prdn_sply_ar_cd, sm.sm_prf_dlvry_cfrn_ts_cd  , sm.sm_otr_sys_prdcsr_itms_qty_cd, sm.sm_dlvry_plnt_ind_cd, sm.sm_gbl_trd_srvs_rte_cd, sm.sm_rls_ts_cd, sm.sm_ptnr_bll_id  , sm.sm_advd_rtns_mgmt_actv_cd, sm.sm_dcmt_trnsfr_ctrl_cd, sm.sm_Handover_lctn_cd, sm.sm_Handover_dt, sm.sm_Handover_ts_cd  , sm.sm_Handover_tm_zn_cd, sm.sm_src_sys_crt_ts_cd, sm.sm_src_sys_upd_dt, sm.sm_ins_ts_cd, sm.sm_upd_ts_dt, sm.sm_lgcl_dlt_ind_cd  , sm.sm_estmd_dlvry_arvl_1_dt,sm.sm_estmd_dlvry_arvl_2_dt,sm.sm_estmd_dlvry_arvl_3_dt,sm.sm_estmd_dlvry_arvl_4_dt,sm.sm_estmd_dlvry_arvl_5_dt  ,sm.sm_estmd_dlvry_arvl_Tiime_1_txt_cd,sm.sm_estmd_dlvry_arvl_tm_2_txt_cd,sm.sm_estmd_dlvry_arvl_tm_3_txt_cd,sm.sm_estmd_dlvry_arvl_tm_4_txt_cd  ,sm.sm_estmd_dlvry_arvl_tm_5_txt_cd,sm.sm_ETA_upd_rsn_dt,sm.sm_ETA_upd_rsn_txt_dt,sm.sm_trkg_id, sm.std_crr_acss_cd, sm.gds_issue_ts as gds_issue_ts_cal, sm.ptnr_fncn_cd,collective_nr,shp_to_attn_cd,sls_ord_crtn_dt,sls_dcmt_typ_cd,lng_ky_cd,sls_dcmt_typ_nm,sls_dcmt_typ_dn_cd,sm.intgtn_fbrc_msg_id, sm.src_sys_upd_ts, sm.src_sys_ky, sm.lgcl_dlt_ind, sm.ins_gmt_ts  ,sm.upd_gmt_ts, sm.src_sys_extrc_gmt_ts, sm.src_sys_btch_nr, sm.fl_nm, sm.ld_jb_nr, sm.ins_ts from ${dbNameConsmtn}.sm_dmnsn sm )   select * from `vw_ship_Header` """)

val vw_shp_cust_DF = spark.sql(s"""with `vw_shp_cust` as  (select sm_sm_id as sm_sm_id_cust ,shp_to_prty_cust_nm_1,shp_to_prty_cust_nm_2,shp_to_prty_cust_strt_nm,shp_to_prty_cust_strt_2_nm,shp_to_prty_cust_strt_3_nm,shp_to_prty_cust_house_nr,shp_to_prty_cust_cty_nm,shp_to_prty_cust_ctry_cd,shp_to_prty_cust_ctry_nm,shp_to_prty_cust_rgn_cd,shp_to_prty_cust_pstl_cd,shp_to_prty_cust_eml_nm,shp_to_prty_cust_ph_nr,shp_to_prty_cust_trns_zn_nm,shp_to_prty_cust_addr_nr from ${dbNameConsmtn}.sm_cust_dmnsn ) select * from `vw_shp_cust`""")

val ship_Header_Cust_DF = vw_ship_Header_DF.join(vw_shp_cust_DF, vw_ship_Header_DF("sm_sm_id") === vw_shp_cust_DF("sm_sm_id_cust"), "left_outer")
 logger.info("*******************sm dmnsn df created************************") 

val vw_pm_DF = spark.sql(s"""with `vw_pm` as  (select pm.plnt_mstr_cd, pm.plnt_mstr_nm, pm.ctry_cd  from ${dbNameConsmtn}.plnt_mstr_dmnsn pm) select * from `vw_pm`""")
 vw_pm_DF.createOrReplaceTempView("PlantView")

logger.info("*******************Plant master df created************************") 

val vw_ship_Line_DF = spark.sql(s""" with `vw_ship_Line` as (select sm_dtl_jn_sm_ky, crc32(concat(lower(trim(COALESCE(smdt.sm_dtl_plnt_cd,""))), lower(trim(COALESCE(smdt.sm_dtl_storg_lctn_cd,""))))) as sm_plnt_storg_lctn_cd_ky , crc32(lower(trim(COALESCE(smdt.sm_dtl_mtrl_id,"")))) as sm_dtl_mtrl_ky, crc32(lower(trim(COALESCE(smdt.sm_dtl_plnt_cd,"0")))) as sm_dtl_plnt_ky, crc32(lower(trim(COALESCE(smdt.sm_dtl_pft_cntr_cd,"0")))) as sm_dtl_pft_cntr_ky, crc32(concat(lower(trim(COALESCE(smdt.sm_dtl_src_sys_cd,""))),lower(trim(COALESCE(smdt.sm_dtl_sm_id,""))), lower(trim(COALESCE(smdt.sm_dtl_sm_itm_nr,""))))) as sm_srl_nr_ky , smdt.sm_dtl_pft_cntr_cd, smdt.sm_dtl_sm_id, smdt.sm_dtl_sm_itm_nr, smdt.sm_dtl_sls_dcmt_itm_cgy_cd, smdt.sm_dtl_crtd_by_usr_id, smdt.sm_dtl_mtrl_grp_cd, smdt.sm_dtl_plnt_cd, smdt.sm_dtl_storg_lctn_cd, smdt.sm_dtl_vndr_btch_id, smdt.sm_dtl_cust_mtrl_id, smdt.sm_dtl_prod_hrchy_cd, smdt.sm_dtl_sm_qty_cd, smdt.sm_dtl_bs_unt_msr_cd, smdt.sm_dtl_sls_unt_msr_cd, smdt.sm_dtl_Numerator_cnvrsn_nr, smdt.sm_dtl_dnmntr_cnvrsn_nr, smdt.sm_dtl_nt_wght_cd, smdt.sm_dtl_grs_wght_cd, smdt.sm_dtl_wght_unt_msr_cd, smdt.sm_dtl_sm_itm_vol_cd, smdt.sm_dtl_vol_unt_msr_cd, smdt.sm_dtl_prtl_itm_dlvry_ind_cd, smdt.sm_dtl_ulmt_ovr_dlvry_ind_cd, smdt.sm_dtl_ovr_dlvry_tlnc_lmt_pct_cd, smdt.sm_dtl_undr_dlvry_tlnc_lmt_pct_cd, smdt.sm_dtl_mtrl_Availabilty_dt, smdt.sm_dtl_actl_dlvry_qty_cd, smdt.sm_dtl_sls_ord_itm_dn_cd, smdt.sm_dtl_orgntg_dcmt_id, smdt.sm_dtl_orgntg_itm_nr, smdt.sm_dtl_sls_dcmt_cgy_cd, smdt.sm_dtl_Preceding_dcmt_lgcl_sys_cd, smdt.sm_dtl_rfnc_dcmt_cd, smdt.sm_dtl_rfnc_itm_nr, smdt.sm_dtl_upd_dcmt_fw_ind_dt, smdt.sm_dtl_blng_rlvnt_ind_cd, smdt.sm_dtl_Loading_grp_cd, smdt.sm_dtl_trns_grp_cd, smdt.sm_dtl_wh_cmplx_cd, smdt.sm_dtl_wh_typ_cd, smdt.sm_dtl_invy_mgmt_mvmt_typ_cd, smdt.sm_dtl_wh_mgmt_mvmt_typ_cd, smdt.sm_dtl_plng_typ_ind_cd, smdt.sm_dtl_mtrl_typ_cd, smdt.sm_dtl_sls_ord_itm_typ_cd, smdt.sm_dtl_bsn_ar_cd, smdt.sm_dtl_sls_ofc_cd, smdt.sm_dtl_sls_grp_cd, smdt.sm_dtl_sls_dvsn_cd, smdt.sm_dtl_dlvry_grp_nr, smdt.sm_dtl_fx_shpg_prsng_tm_cd, smdt.sm_dtl_vrbl_shpg_prsng_tm_cd, smdt.sm_dtl_itm_cst_amt_cd, smdt.sm_dtl_Subtotal_1_amt_cd, smdt.sm_dtl_Subtotal_2_amt_cd, smdt.sm_dtl_Subtotal_3_amt_cd, smdt.sm_dtl_Subtotal_4_amt_cd, smdt.sm_dtl_Subtotal_5_amt_cd, smdt.sm_dtl_Subtotal_6_amt_cd, smdt.sm_dtl_intl_Article_nr, smdt.sm_dtl_mtrl_grp_1_cd, smdt.sm_dtl_mtrl_grp_2_cd, smdt.sm_dtl_mtrl_grp_3_cd, smdt.sm_dtl_mtrl_grp_4_cd, smdt.sm_dtl_mtrl_grp_5_cd, smdt.sm_dtl_cst_cntr_cd, smdt.sm_dtl_ctrlng_ar_cd, smdt.sm_dtl_ord_id, smdt.sm_dtl_ord_itm_nr, smdt.sm_dtl_entrd_mtrl_id, smdt.sm_dtl_mtrl_id, smdt.sm_dtl_plng_plnt_cd, smdt.sm_dtl_prod_grp_bs_unt_msr_cd, smdt.sm_dtl_sale_cnvrsn_fctr_qty_cd, smdt.sm_dtl_acct_asngmt_cgy_cd, smdt.sm_dtl_cnsmpn_pstg_cd, smdt.sm_dtl_fnd_cntr_cd, smdt.sm_dtl_fnd_cd, smdt.sm_dtl_cnfgn_id, smdt.sm_dtl_srl_qty_nr, smdt.sm_dtl_srl_pfl_cd, smdt.sm_dtl_bom_explsn_cd, smdt.sm_dtl_inrn_dlvry_schdl_nr, smdt.sm_dtl_usg_cd, smdt.sm_dtl_prtl_lt_nr, smdt.sm_dtl_pkgg_mtrl_grp_cd, smdt.sm_dtl_frn_trd_bsn_trsn_typ_cd, smdt.sm_dtl_inrn_clss_nr, smdt.sm_dtl_nt_prc_amt_cd, smdt.sm_dtl_ord_itm_nt_amt_cd, smdt.sm_dtl_mtrl_frgt_grp_cd, smdt.sm_dtl_mtrl_stgg_ts_cd, smdt.sm_dtl_cntrct_id, smdt.sm_dtl_cntrct_itm_nr, smdt.sm_dtl_Situation_cd, smdt.sm_dtl_rsrvtn_nr, smdt.sm_dtl_Dangerous_gds_cd, smdt.sm_dtl_spcl_stk_valtn_typ_cd, smdt.sm_dtl_prj_dfn_nr, smdt.sm_dtl_invy_mgmt_actv_ind_cd, smdt.sm_dtl_mfrr_prt_pfl_cd, smdt.sm_dtl_mfrr_prt_mtrl_id, smdt.sm_dtl_wh_cmplx_stgg_ar_cd, smdt.sm_dtl_xtrn_itm_nr, smdt.sm_dtl_pckng_not_rlvnt_ind_cd, smdt.sm_dtl_rfnc_mvmt_typ_nr, smdt.sm_dtl_MRP_ar_cd, smdt.sm_dtl_stk_cgy_cd, smdt.sm_dtl_rcvg_mtrl_cd, smdt.sm_dtl_rcvg_plnt_cd, smdt.sm_dtl_rcvg_storg_lctn_cd, smdt.sm_dtl_phy_stk_trnsfr_ind_cd, smdt.sm_dtl_curr_exch_rate_cd, smdt.sm_dtl_qty_clsfn_cd, smdt.sm_dtl_rpr_prsng_itm_clsfn_cd, smdt.sm_dtl_mn_pstg_ind_cd, smdt.sm_dtl_mtrl_stgg_mtd_cd, smdt.sm_dtl_gds_mvmt_not_rlvnt_ind_cd, smdt.sm_dtl_gnrl_ldgr_acct_id, smdt.sm_dtl_mfr_dt, smdt.sm_dtl_fscl_yr_nr, smdt.sm_dtl_rfnc_dcmt_itm_nr, smdt.sm_dtl_sbsqnt_mvmt_typ_cd, smdt.sm_dtl_dlvry_cgy_cd, smdt.sm_dtl_xtrn_pstg_lcl_curr_amt_cd, smdt.sm_dtl_prch_ord_prc_unt_qty_cd, smdt.sm_dtl_xtrn_sls_vl_lcl_curr_amt_cd, smdt.sm_dtl_crdt_itm_prc_amt_cd, smdt.sm_dtl_prf_dlvry_expctd_ind_cd, smdt.sm_dtl_dlvry_cnvrsn_fctr_qty_cd, smdt.sm_dtl_prf_dlvry_rlvnc_cd, smdt.sm_dtl_stk_trnsfr_ind_cd, smdt.sm_dtl_fnctl_ar_cd, smdt.sm_dtl_gnt_cd, smdt.sm_dtl_usg_unt_msr_ind_cd, smdt.sm_dtl_gds_mvmt_cgy_cd, smdt.sm_dtl_src_sys_crt_ts_cd, smdt.sm_dtl_src_sys_upd_dt, smdt.sm_dtl_ins_ts_cd, smdt.sm_dtl_upd_ts_dt, smdt.sm_dtl_lgcl_dlt_ind_cd, smdt.sm_dtl_sls_ord_itm_bndl_dn_cd,smdt.sm_dtl_sls_ord_itm_bndl_id,smdt.sm_dtl_Late_tm_dlvry_dt,smdt.sm_dtl_tm_dlvry_dt,bdl_qty,obj_individual_stts_cd,sls_dstbn_dcmt_nr,sls_dstbn_dcmt_itm_nr,counter_nr,obj_indvl_stts_cd,ord_nr,stts_qty,stts_ts from ${dbNameConsmtn}.sm_dtl_dmnsn smdt) select * from `vw_ship_Line`""")
       
logger.info("*******************sm dtl dmnsn df created************************") 

val shiptransformDF = ship_Header_Cust_DF.join(vw_ship_Line_DF, ship_Header_Cust_DF("sm_ky") === vw_ship_Line_DF("sm_dtl_jn_sm_ky"), "left_outer").join(vw_pm_DF, vw_ship_Line_DF("sm_dtl_plnt_cd") === vw_pm_DF("plnt_mstr_cd"), "left_outer")


logger.info("******************* shipment df created************************") 
 

val vw_sdsl_DF = spark.sql(s"""with `vw_sdsl` as  (select sdsl.sls_dcmt_schl_ln_ky,sdsl.schdl_ln_clnt_nr,sdsl.sls_dcmt_nm,sdsl.sls_dcmt_itm_nr,sdsl.schdl_ln_nr,sdsl.sls_unt_ord_qty,sdsl.cnfrmd_qty,sdsl.dlvrd_qty,sdsl.gds_issue_dt,sdsl.schdl_ln_dt,sdsl.itm_stts_dn  from ${dbNameConsmtn}.sls_dcmt_schl_ln_dmnsn sdsl) select * from `vw_sdsl`""")
   
  logger.info("*******************sm Sales Document Schedule Line Data df created ************************")
  
val shipsalesorderDF = shiptransformDF.join(vw_sdsl_DF, shiptransformDF("sm_dtl_orgntg_dcmt_id")===vw_sdsl_DF("sls_dcmt_nm") and shiptransformDF("sm_dtl_orgntg_itm_nr")===vw_sdsl_DF("sls_dcmt_itm_nr"), "left_outer")

val vw_dlvry_Dtl_DF = spark.sql(s""" with `vw_dlvry_Dtl` as   (select smdldt.sm_dlvry_dtl_ky, smdldt.sm_dlvry_dtl_jn_sm_dlvry_ky, smdldt.sm_dlvry_dtl_jn_sm_ky, smdldt.sm_dlvry_dtl_sm_dlvry_id, smdldt.sm_dlvry_dtl_sm_dlvry_itm_nr, smdldt.sm_dlvry_dtl_sm_id   , smdldt.sm_dlvry_dtl_sm_itm_Itinerary_cd, smdldt.sm_dlvry_dtl_crtd_by_usr_id,smdldt.sm_dlvry_dtl_src_sys_crt_ts_cd   , smdldt.sm_dlvry_dtl_ins_ts_cd, smdldt.sm_dlvry_dtl_upd_ts_dt, smdldt.sm_dlvry_dtl_lgcl_dlt_ind_cd   from ${dbNameConsmtn}.sm_dlvry_dtl_dmnsn smdldt) select * from `vw_dlvry_Dtl`""")

logger.info("*******************sm dlvry dtl df created************************")     
  
val vw_dlvry_DF = spark.sql(s"""with `vw_dlvry` as   (select sm_dlvry_ky, crc32(cast(smdl.sm_dlvry_plnd_sm_end_ts_cd as string)) as sm_shp_dt_ky, smdl.sm_dlvry_sm_dlvry_id, smdl.sm_dlvry_dcmt_cgy_cd   , smdl.sm_dlvry_sm_typ_cd, smdl.sm_dlvry_trns_plng_pnt_cd, smdl.sm_dlvry_crtd_by_usr_id, smdl.sm_dlvry_src_sys_crt_ts_cd, smdl.sm_dlvry_updd_by_usr_id_dt   , smdl.sm_dlvry_src_sys_upd_ts_dt, smdl.sm_dlvry_leg_dtrmn_cd, smdl.sm_dlvry_sm_cmpltn_typ_cd, smdl.sm_dlvry_srv_lvl_cd   , smdl.sm_dlvry_shpg_typ_cd, smdl.sm_dlvry_pmnry_leg_shpg_typ_cd, smdl.sm_dlvry_sbsqnt_leg_shpg_typ_cd, smdl.sm_dlvry_dlvry_leg_cd   , smdl.sm_dlvry_sm_cndn_cd, smdl.sm_dlvry_cntnr_id, smdl.sm_dlvry_xtrn_1_id, smdl.sm_dlvry_xtrn_2_id, smdl.sm_dlvry_sm_dn_cd   , smdl.sm_dlvry_plng_end_ts_cd, smdl.sm_dlvry_plnd_chk_ts_cd, smdl.sm_dlvry_actl_chk_ts_cd, smdl.sm_dlvry_Loading_strt_ind_cd   , smdl.sm_dlvry_plnd_Loading_strt_ts_cd, smdl.sm_dlvry_actl_Loading_strt_ts_cd, smdl.sm_dlvry_plnd_Loading_end_ts_cd   , smdl.sm_dlvry_actl_Loading_end_ts_cd, smdl.sm_dlvry_sm_cmpltn_ind_cd, smdl.sm_dlvry_plnd_cmpltn_ts_cd, smdl.sm_dlvry_actl_cmpltn_ts_cd   , smdl.sm_dlvry_sm_strt_ind_cd, smdl.sm_dlvry_plnd_sm_strt_ts_cd, smdl.sm_dlvry_actl_sm_strt_ts_cd, smdl.sm_dlvry_sm_end_ind_cd   , smdl.sm_dlvry_plnd_sm_end_ts_cd, smdl.sm_dlvry_actl_sm_end_ts_cd, smdl.sm_dlvry_wght_unt_msr_cd, smdl.sm_dlvry_trns_stts_cd   , smdl.sm_dlvry_vol_unt_msr_cd, smdl.sm_dlvry_trns_prty_id, smdl.sm_dlvry_ord_id, smdl.sm_dlvry_Distance_unt_msr_cd   , smdl.sm_dlvry_Distance_qty_cd, smdl.sm_dlvry_trns_durtn_qty_cd, smdl.sm_dlvry_sm_cltn_stts_cd, smdl.sm_dlvry_ovrl_sm_cltn_stts_cd   , smdl.sm_dlvry_stlmnt_sm_cltn_stts_cd, smdl.sm_dlvry_totl_sm_cltn_stts_cd, smdl.sm_dlvry_leg_dtrmn_ind_cd, smdl.sm_dlvry_sm_prcg_prcgr_cd   , smdl.sm_dlvry_sm_rlvnc_cst_ind_cd,cast(regexp_replace(smdl.sm_dlvry_plnd_sm_dys_dt,',','.')as double) as sm_dlvry_plnd_sm_dys_dt, smdl.sm_dlvry_plnd_sm_hrs_cd, smdl.sm_dlvry_actl_sm_dys_dt   , smdl.sm_dlvry_actl_sm_hrs_cd, smdl.sm_dlvry_rte_cp_ind_cd, smdl.sm_dlvry_Dangerous_gds_cd, smdl.sm_dlvry_Dangerous_gds_slctn_dt   , smdl.sm_dlvry_Dangerous_gds_ind_cd, smdl.sm_dlvry_rte_schdl_id, smdl.sm_dlvry_actl_sm_amt_cd, smdl.sm_dlvry_actl_sm_curr_cd   , smdl.sm_dlvry_agt_trkg_id, smdl.sm_dlvry_earlst_pup_ts_cd, smdl.sm_dlvry_ltst_pup_ts_cd, smdl.sm_dlvry_earlst_dlvry_ts_cd   , smdl.sm_dlvry_ltst_dlvry_ts_cd, smdl.sm_dlvry_ins_ts_cd,smdl.sm_dlvry_upd_ts_dt,smdl.sm_dlvry_lgcl_dlt_ind_cd,smdl.sm_dlvry_spcl_1_cd   , smdl.sm_dlvry_spcl_2_cd,smdl.sm_dlvry_spcl_3_cd,smdl.sm_dlvry_spcl_4_cd,smdl.sm_dlvry_spcl_5_cd,smdl.sm_dlvry_spcl_6_cd   , smdl.sm_dlvry_spcl_7_cd,smdl.sm_dlvry_spcl_8_cd,smdl.shipment_sm_dlvry_rt_2_cd,ins_gmt_ts as sm_ins_gmt_ts
   from ${dbNameConsmtn}.sm_dlvry_dmnsn smdl) select * from `vw_dlvry`""")

logger.info("*******************sm dlvry df created************************")   

println("**************R2.3*****************")

val vw_smstg_DF = spark.sql(s"""with `vw_smstg` as   (select crc32(COALESCE(smstg.sm_nr,"")) as sm_stg_ky,smstg.clnt_cd,smstg.sm_nr,smstg.stg_trnsp_nr,smstg.stg_cgy_cd,smstg.stg_trnsp_sqn_cd,smstg.chg_ind_cd,smstg.pers_rspnsbl_creating_obj_nm,smstg.rec_crtd_dt,smstg.etry_tm_cd  ,smstg.pers_who_chgd_obj_nm,smstg.last_chg_dt,smstg.tm_last_chg_made_cd,smstg.rte_sm_stg_cd,smstg.shpg_typ_sm_stg_cd,smstg.inctrms_printout_cd,smstg.leg_ind_sm_stg_cd  ,smstg.dptr_pnt_addr_cd,smstg.dptr_pnt_cd,smstg.shpg_pnt_at_pnt_dptr_cd,smstg.pnt_dptr_loading_pnt_at_shpg_pnt_cd,smstg.plnt_at_pnt_dptr_cd  ,smstg.dptr_pnt_storg_lctn_plnt_cd,smstg.dptr_pnt_cust_cd,smstg.vndr_dptr_pnt_nr,smstg.pnt_dptr_addnl_info_cd,smstg.dstn_addr_cd,smstg.dstn_pnt_cd,smstg.shpg_pnt_at_dstn_cd  ,smstg.dstn_loading_pnt_at_shpg_pnt_cd,smstg.plnt_at_dstn_pnt_cd,smstg.dstn_storg_lctn_plnt_cd,smstg.cust_dstn_pnt_nr,smstg.vndr_dstn_pnt_nr,smstg.dstn_addnl_inf_cd,smstg.stg_plnd_strt_sm_dt  ,smstg.stg_plnd_sm_strt_tm_cd,smstg.stg_ct_strt_sm_dt,smstg.stg_ct_sm_strt_tm_cd,smstg.stg_plnd_end_sm_dt,smstg.stg_plnd_shipemnt_end_tm_cd,smstg.stg_actl_end_sm_dt,smstg.stg_actl_sm_end_tm_cd,smstg.forwarding_agt_sm_stg_nr  ,smstg.distance_cd,smstg.unt_msr_distance_cd,smstg.travelling_tm_only_btwn_two_locations_cd,smstg.totl_travelling_tm_btwn_two_locations_incl_breaks_cd,smstg.unt_msr_travelling_times_cd,smstg.pnt_dptr_wh_nr  ,smstg.pnt_dptr_gate_wh_nr,smstg.pnt_dptr_orgn_ind_addr_cd,smstg.pnt_dptr_cust_unldg_pnt_cd,smstg.dstn_wh_nr,smstg.dstn_gate_wh_nr,smstg.dstn_orgn_ind_addr_cd  ,smstg.dstn_cust_unldg_pnt_cd,smstg.plnd_totl_tm_at_stg_lvl_dys_dt,smstg.pln_actl_durtn_at_stg_lvl_hrs_mnts_cd,smstg.actl_totl_tm_at_stg_sm_dys_dt  ,smstg.actl_durtn_sm_stg_hrs_mnts_cd,smstg.spcl_prsng_ind_cd,smstg.sm_costs_rlvnc_cd,smstg.prcg_prcgr_stg_sm_cd,smstg.stts_sm_costs_cltn_cd,smstg.stts_sm_costs_stlmnt_cd  ,smstg.upd_grp_statistics_upd_dt,smstg.ind_sctn_contains_dangerous_gds_cd,smstg.plnd_waiting_tm_sm_stg_hrsmin_cd,smstg.ct_waiting_tm_sm_stg_hrsmin_cd,smstg.ctry_dptr_cd,smstg.dptr_pstl_cd,smstg.pnt_dptr_cd,smstg.dstn_ctry_cd,smstg.dstn_pstl_cd,smstg.dstn_cd,route_cd,route_stg_nr,dprtr_pt_nm,dst_pt_nm,ttl_duration_tm,srvc_agnt_nm,sls_dcmt_typ_fctry_clndr_cd,shpg_typ_cd   from ${dbNameConsmtn}.sm_stg_dmnsn smstg) select * from `vw_smstg`""")
   
logger.info("*******************sm stage df ************************") 
  
val vw_smvs_DF = spark.sql(s"""with `vw_smvs` as   (select crc32(COALESCE(smvs.sm_id,"")) as vsblty_the_stts_ky,smvs.sm_id,smvs.obj_i_2_id ,smvs.obj_dn_cd,smvs.crtd_by_cd,smvs.crtd_cd,smvs.hyper_lnk_cd   from ${dbNameConsmtn}.vsblty_the_stts_dmnsn smvs) select * from `vw_smvs`""")
  
logger.info("*******************sm visibility the status df created ************************")
 
println("*******************sm stage,text,visibility the status join condition************************")

val dlvrytransformDF = vw_dlvry_DF.join(vw_dlvry_Dtl_DF, vw_dlvry_DF("sm_dlvry_sm_dlvry_id") === vw_dlvry_Dtl_DF("sm_dlvry_dtl_sm_dlvry_id"), "left_outer").join(vw_smstg_DF, vw_dlvry_DF("sm_dlvry_sm_dlvry_id") === vw_smstg_DF("sm_nr"), "left_outer").join(vw_smvs_DF, vw_dlvry_DF("sm_dlvry_sm_dlvry_id") === vw_smvs_DF("sm_id"), "left_outer")

println("*******************dlvry df created************************") 
  
val shipjndlvrytempDF = shipsalesorderDF.join(dlvrytransformDF, shipsalesorderDF("sm_ky")===dlvrytransformDF("sm_dlvry_dtl_jn_sm_ky"), "full_outer")

shipjndlvrytempDF.createOrReplaceTempView("shipjndlvryView")

println("*******************shipjvdlvryDF created************************") 

/*************************************Register UDF***********************************************/
    def getPreviousWorkDay(d: DateTime): DateTime = {    d.withDayOfWeek(Math.min(d.getDayOfWeek, DateTimeConstants.FRIDAY)).withTimeAtStartOfDay()  }

/************************************Calculate Business Date***************************************************/
def businessDaysBetween(startTimestamp: String, endTimestamp: String): String = {
var businessTS = ""
var  endDateNewTS: DateTime = null
var  startDateNewTS: DateTime = null
try {
  val timeStampFormater = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss")
  val startDateTS = timeStampFormater.parseDateTime(startTimestamp)
  val endDateTS = timeStampFormater.parseDateTime(endTimestamp)
  startDateNewTS = startDateTS.getDayOfWeek match {
  case 6 => startDateTS.plusDays(2).withTimeAtStartOfDay
  case 7 => startDateTS.plusDays(1).withTimeAtStartOfDay
  case 1 | 2 | 3 | 4 | 5 => startDateTS
}
endDateNewTS = endDateTS.getDayOfWeek match {
case 6 => endDateTS.plusDays(2).withTimeAtStartOfDay
case 7 => endDateTS.plusDays(1).withTimeAtStartOfDay
case 1 | 2 | 3 | 4 | 5 => endDateTS
}
val diff = endDateNewTS.getMillis - startDateNewTS.getMillis
      if (diff < 0) {
        val workDayStart = getPreviousWorkDay(endDateNewTS)
        val workDayEnd = getPreviousWorkDay(startDateNewTS)
        val daysBetween = Days.daysBetween(workDayStart, workDayEnd).getDays
        val weekendDaysBetween = daysBetween / 7 * 2
        val additionalWeekend = if (workDayStart.getDayOfWeek > workDayEnd.getDayOfWeek) 2 else 0
        val businessDays = (daysBetween - weekendDaysBetween - additionalWeekend)
        val newdiff = Math.abs(diff).toLong
        val diffSeconds = newdiff / 1000 % 60;
        val diffMinutes = newdiff / (60 * 1000) % 60;
        val diffHours = 0 - (newdiff / (60 * 60 * 1000) % 24).+(businessDays * 24);
        businessTS = (diffHours + ":" + Math.abs(diffMinutes) + ":" + Math.abs(diffSeconds))
      } else {

        val workDayStart = getPreviousWorkDay(startDateNewTS)
        val workDayEnd = getPreviousWorkDay(endDateNewTS)
        val daysBetween = Days.daysBetween(workDayStart, workDayEnd).getDays
        val weekendDaysBetween = daysBetween / 7 * 2
        val additionalWeekend = if (workDayStart.getDayOfWeek > workDayEnd.getDayOfWeek) 2 else 0
        val businessDays = (daysBetween - weekendDaysBetween - additionalWeekend)
        val diffSeconds = diff / 1000 % 60;
        val diffMinutes = diff / (60 * 1000) % 60;
        val diffHours = (diff / (60 * 60 * 1000) % 24).+(businessDays * 24);
        businessTS = (diffHours + ":" + Math.abs(diffMinutes) + ":" + Math.abs(diffSeconds))
      }
    } 
      catch {
      case e: Exception => {
      }
      case ex: java.lang.IllegalArgumentException => {
      }
    }
    businessTS
  }

/*************************************Register UDF***********************************************/
import spark.implicits._
   val calculateBusinessDaysUDF: UserDefinedFunction = udf(businessDaysBetween _)

//new after CR changes -- moved to Qlik
      
    var tat_otps_whole_bus_dayDF = spark.sql(s"SELECT DATEDIFF(TO_DATE(sm_dlvry_actl_sm_end_ts_cd),sm_dlvry_dt) - COUNT(1) as TBD, ctry_cd ,sm_sm_id FROM ${dbNameConsmtn}.pblc_hldy_clndr_dmnsn pc JOIN shipjndlvryView sm ON pc.pblc_hldy_clnd_cd = sm.ctry_cd WHERE pc.pblc_hld_dt BETWEEN  sm.sm_dlvry_dt AND TO_DATE(sm.sm_dlvry_actl_sm_end_ts_cd) group by sm.sm_dlvry_actl_sm_end_ts_cd,sm.sm_dlvry_dt,ctry_cd,sm_sm_id")
    tat_otps_whole_bus_dayDF.createOrReplaceTempView("tat_otps_bs")

     //var tat_ship_to_delv_whole_bus_dDF = spark.sql(s"SELECT ROUND( DATEDIFF (TO_DATE(sm_dlvry_actl_sm_end_ts_cd),sm_actl_gds_mvmt_dt) - ((DATEDIFF (TO_DATE(sm_dlvry_actl_sm_end_ts_cd),sm_actl_gds_mvmt_dt))/7)*2) as TSB, ctry_cd,sm_sm_id,sm.sm_dlvry_actl_sm_end_ts_cd, sm.sm_actl_gds_mvmt_dt,sm.sm_sm_id FROM ${dbNameConsmtn}.pblc_hldy_clndr_dmnsn pc JOIN   (select distinct ctry_cd,sm_dlvry_actl_sm_end_ts_cd,sm_actl_gds_mvmt_dt,sm_sm_id from  shipjndlvryView ) sm ON pc.pblc_hldy_clnd_cd = sm.ctry_cd WHERE pc.pblc_hld_dt BETWEEN sm.sm_actl_gds_mvmt_dt AND TO_DATE(sm_dlvry_actl_sm_end_ts_cd) group by sm.sm_actl_gds_mvmt_dt,ctry_cd,sm_dlvry_actl_sm_end_ts_cd,sm_sm_id")
     //tat_ship_to_delv_whole_bus_dDF.createOrReplaceTempView("tats_ship_bus")

    //var tat_ship_to_delv_whole_cal_dDF = spark.sql(s"SELECT DATEDIFF (TO_DATE(sm_dlvry_actl_sm_end_ts_cd),sm_actl_gds_mvmt_dt) AS TSD, sm_sm_id FROM shipjndlvryView group by sm_dlvry_actl_sm_end_ts_cd,sm_actl_gds_mvmt_dt,sm_sm_id")
    //tat_ship_to_delv_whole_cal_dDF.createOrReplaceTempView("ship_delv_cal_d")
   
   //var tat_intransitDF = spark.sql(s"SELECT DATEDIFF(current_date(),sm_actl_gds_mvmt_dt) as TIT, ctry_cd,sm_sm_id,sm_actl_gds_mvmt_dt FROM shipjndlvryView where sm_dlvry_actl_sm_end_ts_cd is NULL  group by sm_actl_gds_mvmt_dt,ctry_cd,sm_sm_id")
   //tat_intransitDF.createOrReplaceTempView("tat_intrans")

println("*******************DerivedMeasuresDF created************************")

val shipjndlvryDF = spark.sql("""select crc32(coalesce(v.sm_sm_id,v.sm_dlvry_sm_dlvry_id)) as sm_fact_ky,sm_ky,sm_fncn_ky,sm_dtl_mtrl_ky,sm_dlvry_dt_ky,sm_dlvry_cr_dt_ky,sm_dtl_plnt_ky, sm_plnt_storg_lctn_cd_ky as sm_storg_lctn_chg_ind_ky  , sm_shp_to_prty_ky,sm_dtl_pft_cntr_ky,sm_srl_nr_ky,vsblty_the_stts_ky,sm_stg_ky,sls_dcmt_schl_ln_ky,sm_src_sys_crt_ts_cd,v.sm_sm_id,sm_storg_lctn_chg_ind_cd,sm_dtl_pft_cntr_cd,sm_rte_cd,sm_ord_id,sm_dlvry_typ_cd  ,sm_prf_dlvry_cfrn_dt,sm_src_sys_cd,sm_crtd_by_usr_id,sm_sm_pnt_cd,sm_sls_org_cd,sm_sls_dstc_cd,sm_cmplt_dlvry_ind_cd,sm_ord_cmbn_ind_cd  ,sm_plnd_gds_mvmt_dt,sm_loading_dt,sm_trns_plng_dt,sm_dlvry_dt,sm_pckng_dt,sm_unldg_pnt_dn_cd,sm_incoterm_prt_1_cd,sm_incoterm_prt_2_cd  ,sm_xprt_ind_cd,sm_dlvry_blck_rsn_cd,sm_dcmt_cgy_cd,sm_dlvry_pri_cd,sm_shp_to_prty_id,sm_sld_to_prty_id,sm_cust_grp_cd,sm_totl_sm_wght_cd  ,sm_nt_sm_wght_cd,sm_wght_unt_msr_cd,sm_sm_cndn_cd,sm_sm_itm_vol_cd,sm_vol_unt_msr_cd,sm_totl_pkg_qty_cd,sm_picked_itm_lctn_cd,sm_dlvry_ts_cd  ,sm_wght_grp_cd,sm_loading_pnt_cd,sm_trns_grp_cd,sm_prpsd_blng_typ_cd,sm_printout_blng_dt,sm_inv_clndr_cd,shipment_sm_dlvry_rt_1_cd,sm_curr_cd  ,sm_sls_ofc_cd,sm_sm_prsng_durtn_qty_cd,sm_dlvry_cmbn_crtr_cd,sm_dbn_dlvry_dn_cd,sm_statistics_curr_cd,sm_frn_trd_dta_inrn_id  ,sm_updd_by_usr_id_dt,sm_wh_cmplx_cd,sm_sls_organisation_cd,sm_dbn_chnl_cd,sm_sls_dvsn_cd,sm_ic_blng_typ_cd,shipment_sm_ic_bln_1_dt_cd  ,shipment_sm_ic_bln_1_dt,sm_ic_blng_prty_id,sm_crdt_ctrl_ar_cd,sm_cust_crdt_grp_cd,sm_crdt_ctrl_ar_curr_cd,sm_dcmt_rlsd_crdt_amt_cd  ,sm_bll_ldg_nr,sm_vndr_acct_id,sm_trns_mtd_cd,sm_trns_mtd_id,sm_crdt_dcmt_rlsd_dt,sm_nxt_dt,sm_dcmt_dt,sm_actl_gds_mvmt_dt,sm_sm_blck_rsn_cd  ,sm_xtrn_trns_sys_id,sm_dlvry_note_xtrn_id,sm_crctn_dlvry_ind_cd,sm_sm_prcg_prcgr_cd,sm_ord_itm_nt_amt_cd,sm_rte_schdl_id,sm_rcvg_plnt_cd  ,sm_fncl_dcmt_inrn_id,sm_pmnt_grnt_prcgr_cd,sm_plnt_pckng_ts_cd,sm_trns_plng_ts_cd,sm_loading_ts_cd,sm_gds_iss_ts_cd,sm_wh_cmplx_stgg_ar_cd  ,sm_prty_rfnc_dcmt_id,sm_evt_grp_tm_sgm_cd,sm_delivering_lctn_tm_zn_cd,sm_rcpnt_lctn_tm_zn_cd,sm_dangerous_gds_ind_cd,sm_dbn_dlvry_orgl_sys_cd  ,sm_gds_mvmt_ctrl_cd,sm_dlvry_prsng_stts_cd,sm_trsn_cd,sm_shpg_typ_cd,sm_means_trns_cd,sm_spcl_prsng_cd,sm_co_id,sm_opn_vl_cltn_ind_cd  ,sm_prdn_sply_ar_cd,sm_prf_dlvry_cfrn_ts_cd,sm_otr_sys_prdcsr_itms_qty_cd,sm_dlvry_plnt_ind_cd,sm_gbl_trd_srvs_rte_cd,sm_rls_ts_cd  ,sm_ptnr_bll_id,sm_advd_rtns_mgmt_actv_cd,sm_dcmt_trnsfr_ctrl_cd,sm_handover_lctn_cd,sm_handover_dt,sm_handover_ts_cd  ,sm_handover_tm_zn_cd,sm_src_sys_upd_dt,sm_ins_ts_cd,sm_upd_ts_dt,sm_lgcl_dlt_ind_cd,sm_estmd_dlvry_arvl_1_dt  ,sm_estmd_dlvry_arvl_2_dt,sm_estmd_dlvry_arvl_3_dt,sm_estmd_dlvry_arvl_4_dt,sm_estmd_dlvry_arvl_5_dt,sm_estmd_dlvry_arvl_tiime_1_txt_cd  ,sm_estmd_dlvry_arvl_tm_2_txt_cd,sm_estmd_dlvry_arvl_tm_3_txt_cd,sm_estmd_dlvry_arvl_tm_4_txt_cd,sm_estmd_dlvry_arvl_tm_5_txt_cd  ,sm_eta_upd_rsn_dt,sm_eta_upd_rsn_txt_dt,sm_trkg_id,std_crr_acss_cd, intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,
CASE WHEN  v.sm_sm_id is NULL THEN sm_ins_gmt_ts ELSE ins_gmt_ts END as ins_gmt_ts,
upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_ts,sm_dtl_sm_id,sm_dtl_sm_itm_nr,sm_dtl_sls_dcmt_itm_cgy_cd,sm_dtl_crtd_by_usr_id,sm_dtl_mtrl_grp_cd,v.sm_dtl_plnt_cd,sm_dtl_storg_lctn_cd,sm_dtl_vndr_btch_id,sm_dtl_cust_mtrl_id,sm_dtl_prod_hrchy_cd,sm_dtl_sm_qty_cd  ,sm_dtl_bs_unt_msr_cd,sm_dtl_sls_unt_msr_cd,sm_dtl_numerator_cnvrsn_nr,sm_dtl_dnmntr_cnvrsn_nr,sm_dtl_nt_wght_cd,sm_dtl_grs_wght_cd  ,sm_dtl_wght_unt_msr_cd,sm_dtl_sm_itm_vol_cd,sm_dtl_vol_unt_msr_cd,sm_dtl_prtl_itm_dlvry_ind_cd,sm_dtl_ulmt_ovr_dlvry_ind_cd  ,sm_dtl_ovr_dlvry_tlnc_lmt_pct_cd,sm_dtl_undr_dlvry_tlnc_lmt_pct_cd,sm_dtl_mtrl_availabilty_dt,sm_dtl_actl_dlvry_qty_cd  ,sm_dtl_sls_ord_itm_dn_cd,sm_dtl_orgntg_dcmt_id,sm_dtl_orgntg_itm_nr,sm_dtl_sls_dcmt_cgy_cd,sm_dtl_preceding_dcmt_lgcl_sys_cd  ,sm_dtl_rfnc_dcmt_cd,sm_dtl_rfnc_itm_nr,sm_dtl_upd_dcmt_fw_ind_dt,sm_dtl_blng_rlvnt_ind_cd,sm_dtl_loading_grp_cd  ,sm_dtl_trns_grp_cd,sm_dtl_wh_cmplx_cd,sm_dtl_wh_typ_cd,sm_dtl_invy_mgmt_mvmt_typ_cd,sm_dtl_wh_mgmt_mvmt_typ_cd,sm_dtl_plng_typ_ind_cd  ,sm_dtl_mtrl_typ_cd,sm_dtl_sls_ord_itm_typ_cd,sm_dtl_bsn_ar_cd,sm_dtl_sls_ofc_cd,sm_dtl_sls_grp_cd,sm_dtl_sls_dvsn_cd,sm_dtl_dlvry_grp_nr  ,sm_dtl_fx_shpg_prsng_tm_cd,sm_dtl_vrbl_shpg_prsng_tm_cd,sm_dtl_itm_cst_amt_cd,sm_dtl_subtotal_1_amt_cd,sm_dtl_subtotal_2_amt_cd  ,sm_dtl_subtotal_3_amt_cd,sm_dtl_subtotal_4_amt_cd,sm_dtl_subtotal_5_amt_cd,sm_dtl_subtotal_6_amt_cd,sm_dtl_intl_article_nr  ,sm_dtl_mtrl_grp_1_cd,sm_dtl_mtrl_grp_2_cd,sm_dtl_mtrl_grp_3_cd,sm_dtl_mtrl_grp_4_cd,sm_dtl_mtrl_grp_5_cd,sm_dtl_cst_cntr_cd  ,sm_dtl_ctrlng_ar_cd,sm_dtl_ord_id,sm_dtl_ord_itm_nr,sm_dtl_entrd_mtrl_id,sm_dtl_mtrl_id,sm_dtl_plng_plnt_cd,sm_dtl_prod_grp_bs_unt_msr_cd,sm_dtl_sale_cnvrsn_fctr_qty_cd  ,sm_dtl_acct_asngmt_cgy_cd,sm_dtl_cnsmpn_pstg_cd,sm_dtl_fnd_cntr_cd,sm_dtl_fnd_cd,sm_dtl_cnfgn_id,sm_dtl_srl_qty_nr,sm_dtl_srl_pfl_cd  ,sm_dtl_bom_explsn_cd,sm_dtl_inrn_dlvry_schdl_nr,sm_dtl_usg_cd,sm_dtl_prtl_lt_nr,sm_dtl_pkgg_mtrl_grp_cd,sm_dtl_frn_trd_bsn_trsn_typ_cd  ,sm_dtl_inrn_clss_nr,sm_dtl_nt_prc_amt_cd,sm_dtl_ord_itm_nt_amt_cd,sm_dtl_mtrl_frgt_grp_cd,sm_dtl_mtrl_stgg_ts_cd,sm_dtl_cntrct_id  ,sm_dtl_cntrct_itm_nr,sm_dtl_situation_cd,sm_dtl_rsrvtn_nr,sm_dtl_dangerous_gds_cd,sm_dtl_spcl_stk_valtn_typ_cd,sm_dtl_prj_dfn_nr  ,sm_dtl_invy_mgmt_actv_ind_cd,sm_dtl_mfrr_prt_pfl_cd,sm_dtl_mfrr_prt_mtrl_id,sm_dtl_wh_cmplx_stgg_ar_cd,sm_dtl_xtrn_itm_nr  ,sm_dtl_pckng_not_rlvnt_ind_cd,sm_dtl_rfnc_mvmt_typ_nr,sm_dtl_mrp_ar_cd,sm_dtl_stk_cgy_cd,sm_dtl_rcvg_mtrl_cd,sm_dtl_rcvg_plnt_cd  ,sm_dtl_rcvg_storg_lctn_cd,sm_dtl_phy_stk_trnsfr_ind_cd,sm_dtl_curr_exch_rate_cd,sm_dtl_qty_clsfn_cd,sm_dtl_rpr_prsng_itm_clsfn_cd  ,sm_dtl_mn_pstg_ind_cd,sm_dtl_mtrl_stgg_mtd_cd,sm_dtl_gds_mvmt_not_rlvnt_ind_cd,sm_dtl_gnrl_ldgr_acct_id,sm_dtl_mfr_dt  ,sm_dtl_fscl_yr_nr,sm_dtl_rfnc_dcmt_itm_nr,sm_dtl_sbsqnt_mvmt_typ_cd,sm_dtl_dlvry_cgy_cd,sm_dtl_xtrn_pstg_lcl_curr_amt_cd  ,sm_dtl_prch_ord_prc_unt_qty_cd,sm_dtl_xtrn_sls_vl_lcl_curr_amt_cd,sm_dtl_crdt_itm_prc_amt_cd,sm_dtl_prf_dlvry_expctd_ind_cd  ,sm_dtl_dlvry_cnvrsn_fctr_qty_cd,sm_dtl_prf_dlvry_rlvnc_cd,sm_dtl_stk_trnsfr_ind_cd,sm_dtl_fnctl_ar_cd,sm_dtl_gnt_cd  ,sm_dtl_usg_unt_msr_ind_cd,sm_dtl_gds_mvmt_cgy_cd,sm_dtl_src_sys_crt_ts_cd,sm_dtl_src_sys_upd_dt,sm_dtl_ins_ts_cd,sm_dtl_upd_ts_dt  ,sm_dtl_lgcl_dlt_ind_cd,sm_dtl_sls_ord_itm_bndl_dn_cd,sm_dtl_sls_ord_itm_bndl_id,sm_dtl_late_tm_dlvry_dt,sm_dtl_tm_dlvry_dt ,schdl_ln_clnt_nr,sls_dcmt_nm,sls_dcmt_itm_nr,schdl_ln_nr,sls_unt_ord_qty,cnfrmd_qty,dlvrd_qty,gds_issue_dt,schdl_ln_dt,itm_stts_dn  ,sm_shp_dt_ky,sm_dlvry_dtl_jn_sm_ky,sm_dlvry_sm_dlvry_id,sm_dlvry_dcmt_cgy_cd,sm_dlvry_sm_typ_cd,sm_dlvry_trns_plng_pnt_cd,sm_dlvry_crtd_by_usr_id  ,sm_dlvry_src_sys_crt_ts_cd,sm_dlvry_updd_by_usr_id_dt,sm_dlvry_src_sys_upd_ts_dt,sm_dlvry_leg_dtrmn_cd,sm_dlvry_sm_cmpltn_typ_cd  ,sm_dlvry_srv_lvl_cd,sm_dlvry_shpg_typ_cd,sm_dlvry_pmnry_leg_shpg_typ_cd,sm_dlvry_sbsqnt_leg_shpg_typ_cd,sm_dlvry_dlvry_leg_cd  ,sm_dlvry_sm_cndn_cd,sm_dlvry_cntnr_id,sm_dlvry_xtrn_1_id,sm_dlvry_xtrn_2_id,sm_dlvry_sm_dn_cd,sm_dlvry_plng_end_ts_cd,sm_dlvry_plnd_chk_ts_cd  ,sm_dlvry_actl_chk_ts_cd,sm_dlvry_loading_strt_ind_cd,sm_dlvry_plnd_loading_strt_ts_cd,sm_dlvry_actl_loading_strt_ts_cd  ,sm_dlvry_plnd_loading_end_ts_cd,sm_dlvry_actl_loading_end_ts_cd,sm_dlvry_sm_cmpltn_ind_cd,sm_dlvry_plnd_cmpltn_ts_cd  ,sm_dlvry_actl_cmpltn_ts_cd,sm_dlvry_sm_strt_ind_cd,sm_dlvry_plnd_sm_strt_ts_cd,sm_dlvry_actl_sm_strt_ts_cd,sm_dlvry_sm_end_ind_cd  ,sm_dlvry_plnd_sm_end_ts_cd,sm_dlvry_actl_sm_end_ts_cd,sm_dlvry_wght_unt_msr_cd,sm_dlvry_trns_stts_cd,sm_dlvry_vol_unt_msr_cd  ,sm_dlvry_trns_prty_id,sm_dlvry_ord_id,sm_dlvry_distance_unt_msr_cd,sm_dlvry_distance_qty_cd,sm_dlvry_trns_durtn_qty_cd  ,sm_dlvry_sm_cltn_stts_cd,sm_dlvry_ovrl_sm_cltn_stts_cd,sm_dlvry_stlmnt_sm_cltn_stts_cd,sm_dlvry_totl_sm_cltn_stts_cd,sm_dlvry_leg_dtrmn_ind_cd  ,sm_dlvry_sm_prcg_prcgr_cd,sm_dlvry_sm_rlvnc_cst_ind_cd,sm_dlvry_plnd_sm_dys_dt,sm_dlvry_plnd_sm_hrs_cd,sm_dlvry_actl_sm_dys_dt  ,sm_dlvry_actl_sm_hrs_cd,sm_dlvry_rte_cp_ind_cd,sm_dlvry_dangerous_gds_cd,sm_dlvry_dangerous_gds_slctn_dt,sm_dlvry_dangerous_gds_ind_cd  ,sm_dlvry_rte_schdl_id,sm_dlvry_actl_sm_amt_cd,sm_dlvry_actl_sm_curr_cd,sm_dlvry_agt_trkg_id,sm_dlvry_earlst_pup_ts_cd,sm_dlvry_ltst_pup_ts_cd  ,sm_dlvry_earlst_dlvry_ts_cd,sm_dlvry_ltst_dlvry_ts_cd,sm_dlvry_ins_ts_cd,sm_dlvry_upd_ts_dt,sm_dlvry_lgcl_dlt_ind_cd,sm_dlvry_dtl_sm_dlvry_id  ,sm_dlvry_dtl_sm_dlvry_itm_nr,sm_dlvry_dtl_sm_id,sm_dlvry_dtl_sm_itm_itinerary_cd,sm_dlvry_dtl_crtd_by_usr_id,collective_nr,sm_dlvry_dtl_src_sys_crt_ts_cd  ,sm_dlvry_dtl_ins_ts_cd,sm_dlvry_dtl_upd_ts_dt,sm_dlvry_dtl_lgcl_dlt_ind_cd,sm_dlvry_spcl_1_cd,sm_dlvry_spcl_2_cd,sm_dlvry_spcl_3_cd  ,sm_dlvry_spcl_4_cd,sm_dlvry_spcl_5_cd,sm_dlvry_spcl_6_cd,sm_dlvry_spcl_7_cd,sm_dlvry_spcl_8_cd ,shipment_sm_dlvry_rt_2_cd ,clnt_cd,sm_nr,stg_trnsp_nr,stg_cgy_cd,stg_trnsp_sqn_cd,chg_ind_cd,pers_rspnsbl_creating_obj_nm,rec_crtd_dt,concat(SUBSTRING (etry_tm_cd, 1, 2),':',SUBSTRING (etry_tm_cd, 3, 2),':',SUBSTRING (etry_tm_cd, 5, 2)) as etry_tm_cd  ,pers_who_chgd_obj_nm,last_chg_dt,tm_last_chg_made_cd,rte_sm_stg_cd,shpg_typ_sm_stg_cd,inctrms_printout_cd,leg_ind_sm_stg_cd  ,dptr_pnt_addr_cd,dptr_pnt_cd,shpg_pnt_at_pnt_dptr_cd,pnt_dptr_loading_pnt_at_shpg_pnt_cd,plnt_at_pnt_dptr_cd  ,dptr_pnt_storg_lctn_plnt_cd,dptr_pnt_cust_cd,vndr_dptr_pnt_nr,pnt_dptr_addnl_info_cd,dstn_addr_cd,dstn_pnt_cd,shpg_pnt_at_dstn_cd  ,dstn_loading_pnt_at_shpg_pnt_cd,plnt_at_dstn_pnt_cd,dstn_storg_lctn_plnt_cd,cust_dstn_pnt_nr,vndr_dstn_pnt_nr,dstn_addnl_inf_cd,stg_plnd_strt_sm_dt  ,stg_plnd_sm_strt_tm_cd,stg_ct_strt_sm_dt,stg_ct_sm_strt_tm_cd,stg_plnd_end_sm_dt,stg_plnd_shipemnt_end_tm_cd,stg_actl_end_sm_dt,stg_actl_sm_end_tm_cd,forwarding_agt_sm_stg_nr  ,distance_cd,unt_msr_distance_cd,travelling_tm_only_btwn_two_locations_cd,totl_travelling_tm_btwn_two_locations_incl_breaks_cd,unt_msr_travelling_times_cd,pnt_dptr_wh_nr  ,pnt_dptr_gate_wh_nr,pnt_dptr_orgn_ind_addr_cd,pnt_dptr_cust_unldg_pnt_cd,dstn_wh_nr,dstn_gate_wh_nr,dstn_orgn_ind_addr_cd  ,dstn_cust_unldg_pnt_cd,plnd_totl_tm_at_stg_lvl_dys_dt,pln_actl_durtn_at_stg_lvl_hrs_mnts_cd,actl_totl_tm_at_stg_sm_dys_dt,actl_durtn_sm_stg_hrs_mnts_cd,spcl_prsng_ind_cd,sm_costs_rlvnc_cd,prcg_prcgr_stg_sm_cd,stts_sm_costs_cltn_cd,stts_sm_costs_stlmnt_cd,upd_grp_statistics_upd_dt,ind_sctn_contains_dangerous_gds_cd,plnd_waiting_tm_sm_stg_hrsmin_cd,ct_waiting_tm_sm_stg_hrsmin_cd,ctry_dptr_cd,dptr_pstl_cd,pnt_dptr_cd,v.dstn_ctry_cd,dstn_pstl_cd,dstn_cd,sm_id,obj_i_2_id,obj_dn_cd,crtd_by_cd,crtd_cd,hyper_lnk_cd,shp_to_attn_cd,sls_ord_crtn_dt,sls_dcmt_typ_cd,lng_ky_cd,sls_dcmt_typ_nm,sls_dcmt_typ_dn_cd,gds_issue_ts_cal,concat(SUBSTRING (gds_issue_ts_cal, 1, 2),':',SUBSTRING (gds_issue_ts_cal, 3, 2),':',SUBSTRING (gds_issue_ts_cal, 5, 2)) as gds_issue_ts,bdl_qty,ptnr_fncn_cd,obj_individual_stts_cd,sls_dstbn_dcmt_nr,sls_dstbn_dcmt_itm_nr,counter_nr,obj_indvl_stts_cd,ord_nr,stts_qty,stts_ts,shp_to_prty_cust_nm_1,shp_to_prty_cust_nm_2,shp_to_prty_cust_strt_nm,shp_to_prty_cust_strt_2_nm,shp_to_prty_cust_strt_3_nm,shp_to_prty_cust_house_nr,shp_to_prty_cust_cty_nm,shp_to_prty_cust_ctry_cd,shp_to_prty_cust_ctry_nm,shp_to_prty_cust_rgn_cd,shp_to_prty_cust_pstl_cd,shp_to_prty_cust_eml_nm,shp_to_prty_cust_ph_nr,shp_to_prty_cust_trns_zn_nm,shp_to_prty_cust_addr_nr,ctry_cd,route_cd,route_stg_nr,dprtr_pt_nm,dst_pt_nm,ttl_duration_tm,srvc_agnt_nm,sls_dcmt_typ_fctry_clndr_cd,shpg_typ_cd,DATEDIFF(to_date(sm_dlvry_plnd_sm_end_ts_cd),sm_dlvry_dt) as tat_sp_to_dlv_whl_cal_dys  ,b.tat_otps_whole_bus_day  ,NULL as tat_ship_to_delv_whole_bus_d  ,NULL as tat_ship_to_delv_whole_cal_d  , NULL as tat_intransit from shipjndlvryView v   left join   (select sm_sm_id,collect_set(tat_otps_whole_bus_day)[0] as tat_otps_whole_bus_day  from( select bs.sm_sm_id, bs.TBD AS tat_otps_whole_bus_day  from tat_otps_bs bs ) a group by sm_sm_id) b on v.sm_sm_id = b.sm_sm_id """).withColumn("tat_dlvry_excn", calculateBusinessDaysUDF(col("sm_src_sys_crt_ts_cd").cast(StringType),expr("from_unixtime(UNIX_TIMESTAMP(concat(cast(date_format(sm_actl_gds_mvmt_dt,'yyyyMMdd') as string),gds_issue_ts_cal),'yyyyMMddHHmmss'))").cast(StringType)))

logger.info("*******************final df created************************")    

val numOfWritePartitions = ((spark.conf.get("spark.sql.shuffle.partitions")).toInt)/10

val tgt_count = shipjndlvryDF.count().toInt 
val loadStatus = Utilities.storeDataFrame(shipjndlvryDF, "overwrite", "ORC", dbNameConsmtn + "." + hive_metrics_name,tgt_count,numOfWritePartitions)

logger.info("sm_fact object has been loaded") 

//************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("cnsmptn_fact")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
   case connException: ConnectException => {

      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case ex: Exception => {
      logger.error("Exception: " + ex.printStackTrace())
      sqlCon.close()
      spark.close()
      System.exit(1)
    }  
  }
 finally {
    sqlCon.close()
    spark.close()
  }
  }
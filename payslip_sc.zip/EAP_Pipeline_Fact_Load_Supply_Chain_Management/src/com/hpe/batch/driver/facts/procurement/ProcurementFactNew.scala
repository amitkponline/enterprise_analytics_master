package com.hpe.batch.driver.facts.procurement

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObjectEnhanced
import main.scala.com.hpe.utils.Utilities

object ProcurementFactNew extends App {

  //**************************Driver properties******************************//
  val logger = Logger.getLogger(getClass.getName)
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObjectEnhanced = Utilities.getStreamingPropertiesObjectEnhanced(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val dbName = propertiesObject.getDbName()
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val numPartitions = propertiesObject.getNumPartitions().toInt

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  var src_count = 0
  var tgt_count = 0
  var jobStatusFlag = true

  try {
    //****************************Fact Code****************************************//

    //Maximum timestamp of fact table
    val maxtgttimestamp = "'" + spark.sql(f"""select coalesce(max(ins_gmt_ts),'1900-01-01 00:00:01.000') as txn_timestamp from ${dbNameConsmtn}.${consmptnTable} """).collect().map(_.getString(0)).mkString("") + "'"
    //Logic for Open_Ir_Quantity measure
    val Open_IR_qty_dDF = spark.sql(s"""select distinct sch.gds_Recieved_qty_cd as opn_ir_qty,prchg_ord_nr,unq_prch_dcmt_itm_cd from ${dbNameConsmtn}.edm_prch_doc_htry_dmnsn doc_h inner join ${dbNameConsmtn}.edm_prch_ord_schdl_itm_dmnsn sch on doc_h.prchg_ord_nr=sch.prch_ord_schdl_itm_prch_ord_id and doc_h.unq_prch_dcmt_itm_cd=sch.prch_ord_schdl_itm_prch_ord_itm_nr and doc_h.trsn_evt_typ_cd!=2""")
    logger.info("select distinct sch.gds_Recieved_qty_cd as opn_ir_qty,prchg_ord_nr,unq_prch_dcmt_itm_cd from ${dbNameConsmtn}.edm_prch_doc_htry_dmnsn doc_h inner join ${dbNameConsmtn}.edm_prch_ord_schdl_itm_dmnsn sch on doc_h.prchg_ord_nr=sch.prch_ord_schdl_itm_prch_ord_id and doc_h.unq_prch_dcmt_itm_cd=sch.prch_ord_schdl_itm_prch_ord_itm_nr and doc_h.trsn_evt_typ_cd!=2")
    Open_IR_qty_dDF.write.mode("Overwrite").format("ORC").saveAsTable(dbName + ".opn_ir_qty_doc")

    //Df for Purchase order data

    val PurchaseOrder_DF = spark.sql(s"""select po.prch_ord_src_sys_cd,po.prch_ord_prch_ord_id,po.vrsn_id,po.lgl_co_cd,po.prchg_dcmt_typ_cd,po.prch_stts_cd,po.irvl_nr,po.prch_ord_vndr_prty_id,po.prch_ord_lng_cd,po.pmnt_trm_cd,po.prch_ord_prch_org_cd,po.prch_ord_prchg_grp_cd,po.prch_ord_curr_cd,po.exch_rate_cd,po.fx_exch_ind_cd,po.prch_dt,po.xtrn_rfnc_txt_cd,po.prch_ord_sls_pers_nm,po.gds_vndr_prty_id,po.prch_ord_Incoterm_prt_1_cd,po.prch_ord_Incoterm_prt_2_cd,po.Invoicing_vndr_prty_id,po.inrn_rfnc_txt_cd,po.rls_st_txt_cd,po.incmplt_ind_cd,po.prch_ord_ins_ts_cd,po.prch_ord_upd_ts_dt,po.prch_ord_src_sys_crt_ts_cd,po.prch_ord_lgcl_dlt_ind_cd,po.src_sys_crtd_by_usr_id,po.rls_ind_cd,po.prcg_prcgr_cd,po.dcmt_cndn_id,po.prch_ord_prncpl_prch_agrmnt_id,po.src_ctry_cd,po.intgtn_fbrc_msg_id,po.src_sys_upd_ts,po.src_sys_ky,po.lgcl_dlt_ind,po.ins_gmt_ts,po.upd_gmt_ts,po.src_sys_extrc_gmt_ts,po.src_sys_btch_nr,po.fl_nm,po.ld_jb_nr,po.ins_gmt_dt,pod.prch_ord_dtl_prch_inf_rec_id,pod.prch_ord_dtl_plnt_cd,pod.prch_ord_dtl_mtrl_id,pod.prch_ord_dtl_dmnsn_ky,pod.prch_ord_dtl_src_sys_cd,pod.prch_ord_dtl_prch_ord_id,pod.prch_ord_dtl_prch_ord_itm_nr,pod.tx_cd,pod.mfrr_prt_id,pod.prch_ord_shrt_txt_cd,pod.prch_ord_dtl_prncpl_prch_agrmnt_id,pod.prch_ord_dtl_prncpl_prch_agrmnt_itm_nr,pod.crss_plnt_mtrl_id,pod.rqst_qtn_id,pod.rqst_qtn_itm_nr,pod.prch_ord_dtl_rqstn_itm_nr,pod.prch_itm_dlt_ind_cd,pod.prch_ord_dtl_rqstn_id,pod.storg_lctn_cd,pod.rqmt_trkg_nr,pod.prch_ord_dtl_vndr_mtrl_id,pod.prch_ord_dtl_prch_ord_qty_cd,pod.prch_ord_unt_msr_cd,pod.prch_ord_dtl_ord_prc_unt_msr_cd,pod.prch_ord_dtl_nt_prc_amt_cd,pod.prch_ord_dtl_unt_prc_amt_cd,pod.gds_rcpt_prsng_dys_dt,pod.dlvry_cmpltn_ind_cd,pod.fnl_inv_ind_cd,pod.prch_ord_itm_cgy_cd,pod.acct_asngmt_cgy_cd,pod.mltpl_acct_asngmt_cd,pod.inv_rcpt_ind_cd,pod.prch_ord_dtl_inv_vrfctn_ind_cd,pod.prch_ord_dtl_ord_ackgmt_ind_cd,pod.prch_ord_dtl_shpg_inst_cd,pod.prch_ord_dtl_cust_prty_id,pod.prch_ord_dtl_vndr_cndn_grp_cd,pod.wght_unt_msr_cd,pod.tx_jrstc_cd,pod.prch_ord_dtl_cfrn_ctrl_cd,pod.vol_unt_msr_cd,pod.prch_ord_dtl_Incoterm_prt_1_cd,pod.prch_ord_dtl_Incoterm_prt_2_cd,pod.prr_vndr_prty_id,pod.hghr_lvl_itm_cd,pod.rtn_itm_ind_cd,pod.orgn_mtrl_cd,pod.prch_ord_dtl_ins_ts_cd,pod.prch_ord_dtl_upd_ts_dt,pod.prch_ord_dtl_lgcl_dlt_ind_cd,pod.rqstr_usr_id,pod.grs_wght_cd,pod.grs_amt_cd,pod.rfnc_cnfgn_id,pod.itm_amt_cd,pod.schdl_ln_print_ind_cd,pod.stk_typ_cd,pod.tgt_qty_cd,pod.spcl_stk_valtn_typ_cd,pod.cnfgl_mtrl_ind_cd,pod.expeditor_frst_reminder_qty_cd,pod.expeditor_scnd_reminder_qty_cd,pod.expeditor_thrd_reminder_qty_cd,pod.mtrl_typ_cd,pod.prch_ord_dtl_mtrl_grp,pod.blng_itm_nt_amt_cd,pod.spcl_stk_ind_cd,pod.rec_upd_ind_dt,pod.ststcl_ind_cd,pod.ulmt_ovr_dlvry_ind_cd,pod.zzbuild_hld,pod.trst_ts_cd,pod.zzship_hld,pod.prch_ord_dtls_prty_id,pod.shp_tup_cd,pod.pp_dlvdys,pod.frcst_dt,pod.ord_ack,po.prch_ord_prch_ord_id_ky,pod.prch_ord_dtl_prch_ord_id_ky,pod.prch_ord_dtl_prch_ord_id_itm_nr_ky,pod.prch_ord_dtl_rqstn_id_itm_nr_ky,po.prch_ord_dmnsn_ky from ${dbNameConsmtn}.edm_prch_ord_dmnsn po left join ${dbNameConsmtn}.edm_prch_ord_dtl_dmnsn pod on po.prch_ord_prch_ord_id_ky=pod.prch_ord_dtl_prch_ord_id_ky""")
    logger.info("select po.prch_ord_src_sys_cd,po.prch_ord_prch_ord_id,po.vrsn_id,po.lgl_co_cd,po.prchg_dcmt_typ_cd,po.prch_stts_cd,po.irvl_nr,po.prch_ord_vndr_prty_id,po.prch_ord_lng_cd,po.pmnt_trm_cd,po.prch_ord_prch_org_cd,po.prch_ord_prchg_grp_cd,po.prch_ord_curr_cd,po.exch_rate_cd,po.fx_exch_ind_cd,po.prch_dt,po.xtrn_rfnc_txt_cd,po.prch_ord_sls_pers_nm,po.gds_vndr_prty_id,po.prch_ord_Incoterm_prt_1_cd,po.prch_ord_Incoterm_prt_2_cd,po.Invoicing_vndr_prty_id,po.inrn_rfnc_txt_cd,po.rls_st_txt_cd,po.incmplt_ind_cd,po.prch_ord_ins_ts_cd,po.prch_ord_upd_ts_dt,po.prch_ord_src_sys_crt_ts_cd,po.prch_ord_lgcl_dlt_ind_cd,po.src_sys_crtd_by_usr_id,po.rls_ind_cd,po.prcg_prcgr_cd,po.dcmt_cndn_id,po.prch_ord_prncpl_prch_agrmnt_id,po.src_ctry_cd,po.intgtn_fbrc_msg_id,po.src_sys_upd_ts,po.src_sys_ky,po.lgcl_dlt_ind,po.ins_gmt_ts,po.upd_gmt_ts,po.src_sys_extrc_gmt_ts,po.src_sys_btch_nr,po.fl_nm,po.ld_jb_nr,po.ins_gmt_dt,pod.prch_ord_dtl_prch_inf_rec_id,pod.prch_ord_dtl_plnt_cd,pod.prch_ord_dtl_mtrl_id,pod.prch_ord_dtl_dmnsn_ky,pod.prch_ord_dtl_src_sys_cd,pod.prch_ord_dtl_prch_ord_id,pod.prch_ord_dtl_prch_ord_itm_nr,pod.tx_cd,pod.mfrr_prt_id,pod.prch_ord_shrt_txt_cd,pod.prch_ord_dtl_prncpl_prch_agrmnt_id,pod.prch_ord_dtl_prncpl_prch_agrmnt_itm_nr,pod.crss_plnt_mtrl_id,pod.rqst_qtn_id,pod.rqst_qtn_itm_nr,pod.prch_ord_dtl_rqstn_itm_nr,pod.prch_itm_dlt_ind_cd,pod.prch_ord_dtl_rqstn_id,pod.storg_lctn_cd,pod.rqmt_trkg_nr,pod.prch_ord_dtl_vndr_mtrl_id,pod.prch_ord_dtl_prch_ord_qty_cd,pod.prch_ord_unt_msr_cd,pod.prch_ord_dtl_ord_prc_unt_msr_cd,pod.prch_ord_dtl_nt_prc_amt_cd,pod.prch_ord_dtl_unt_prc_amt_cd,pod.gds_rcpt_prsng_dys_dt,pod.dlvry_cmpltn_ind_cd,pod.fnl_inv_ind_cd,pod.prch_ord_itm_cgy_cd,pod.acct_asngmt_cgy_cd,pod.mltpl_acct_asngmt_cd,pod.inv_rcpt_ind_cd,pod.prch_ord_dtl_inv_vrfctn_ind_cd,pod.prch_ord_dtl_ord_ackgmt_ind_cd,pod.prch_ord_dtl_shpg_inst_cd,pod.prch_ord_dtl_cust_prty_id,pod.prch_ord_dtl_vndr_cndn_grp_cd,pod.wght_unt_msr_cd,pod.tx_jrstc_cd,pod.prch_ord_dtl_cfrn_ctrl_cd,pod.vol_unt_msr_cd,pod.prch_ord_dtl_Incoterm_prt_1_cd,pod.prch_ord_dtl_Incoterm_prt_2_cd,pod.prr_vndr_prty_id,pod.hghr_lvl_itm_cd,pod.rtn_itm_ind_cd,pod.orgn_mtrl_cd,pod.prch_ord_dtl_ins_ts_cd,pod.prch_ord_dtl_upd_ts_dt,pod.prch_ord_dtl_lgcl_dlt_ind_cd,pod.rqstr_usr_id,pod.grs_wght_cd,pod.grs_amt_cd,pod.rfnc_cnfgn_id,pod.itm_amt_cd,pod.schdl_ln_print_ind_cd,pod.stk_typ_cd,pod.tgt_qty_cd,pod.spcl_stk_valtn_typ_cd,pod.cnfgl_mtrl_ind_cd,pod.expeditor_frst_reminder_qty_cd,pod.expeditor_scnd_reminder_qty_cd,pod.expeditor_thrd_reminder_qty_cd,pod.mtrl_typ_cd,pod.prch_ord_dtl_mtrl_grp,pod.blng_itm_nt_amt_cd,pod.spcl_stk_ind_cd,pod.rec_upd_ind_dt,pod.ststcl_ind_cd,pod.ulmt_ovr_dlvry_ind_cd,pod.zzbuild_hld,pod.trst_ts_cd,pod.zzship_hld,pod.prch_ord_dtls_prty_id,pod.shp_tup_cd,pod.pp_dlvdys,pod.frcst_dt,pod.ord_ack,po.prch_ord_prch_ord_id_ky,pod.prch_ord_dtl_prch_ord_id_ky,pod.prch_ord_dtl_prch_ord_id_itm_nr_ky,pod.prch_ord_dtl_rqstn_id_itm_nr_ky,po.prch_ord_dmnsn_ky from ${dbNameConsmtn}.edm_prch_ord_dmnsn po left join ${dbNameConsmtn}.edm_prch_ord_dtl_dmnsn pod on po.prch_ord_prch_ord_id_ky=pod.prch_ord_dtl_prch_ord_id_ky")
    PurchaseOrder_DF.write.mode("Overwrite").format("ORC").saveAsTable(dbName + ".PurchaseOrder_tmp")

    //Df for Purchase Requisition data
    val PurchaseRequistion_DF = spark.sql(s"""select prd.prch_rqstn_dtl_dmnsn_ky,prd.prch_rqstn_dtl_src_sys_cd,prd.prch_rqstn_dtl_rqstn_id,prd.prch_rqstn_dtl_rqstn_itm_nr,prd.prch_rqstn_dtl_prch_ord_id,prd.prch_rqstn_dtl_mtrl_id,prd.mfrr_mtrl_id,prd.rqstn_rls_dt,prd.prch_rqstn_dtl_prncpl_prch_agrmnt_id,prd.prch_rqstn_dtl_prncpl_prch_agrmnt_itm_nr,prd.prch_rqstn_dtl_prch_ord_itm_nr,prd.prch_rqstn_dtl_ins_ts_cd,prd.prch_rqstn_dtl_upd_ts_dt,prd.prch_rqstn_dtl_src_sys_upd_ts_dt,prd.prch_rqstn_dtl_lgcl_dlt_ind_cd,prd.prch_dcmt_typ_cd,prd.dlvry_rqst_dt,prd.prch_ord_dt,prd.schdld_qty_cd,prd.last_mfyd_dt,prd.mtrl_rcvd_qty_cd,prd.rqstd_mtrl_prc_amt_cd,prd.rqstd_status_cd,prd.prch_rqstn_dtl_plnt_code,prd.prch_rqstn_dtl_prch_req_qty,prd.prch_rqstn_dtl_itm_catg_cd,prd.prch_rqstn_dtl_sup_plnt_cd,prd.prch_rqstn_dtl_fxd_vndr_cd,prd.prch_rqstn_dtl_prch_req_dt,pod.prch_ord_dtl_rqstn_id_itm_nr_ky from  ${dbName}.PurchaseOrder_tmp pod inner join ${dbNameConsmtn}.edm_prch_rqstn_dtl_dmnsn prd on pod.prch_ord_dtl_rqstn_id_itm_nr_ky=prd.prch_rqstn_dtl_dmnsn_ky""")
    logger.info("select prd.prch_rqstn_dtl_dmnsn_ky,prd.prch_rqstn_dtl_src_sys_cd,prd.prch_rqstn_dtl_rqstn_id,prd.prch_rqstn_dtl_rqstn_itm_nr,prd.prch_rqstn_dtl_prch_ord_id,prd.prch_rqstn_dtl_mtrl_id,prd.mfrr_mtrl_id,prd.rqstn_rls_dt,prd.prch_rqstn_dtl_prncpl_prch_agrmnt_id,prd.prch_rqstn_dtl_prncpl_prch_agrmnt_itm_nr,prd.prch_rqstn_dtl_prch_ord_itm_nr,prd.prch_rqstn_dtl_ins_ts_cd,prd.prch_rqstn_dtl_upd_ts_dt,prd.prch_rqstn_dtl_src_sys_upd_ts_dt,prd.prch_rqstn_dtl_lgcl_dlt_ind_cd,prd.prch_dcmt_typ_cd,prd.dlvry_rqst_dt,prd.prch_ord_dt,prd.schdld_qty_cd,prd.last_mfyd_dt,prd.mtrl_rcvd_qty_cd,prd.rqstd_mtrl_prc_amt_cd,prd.rqstd_status_cd,prd.prch_rqstn_dtl_plnt_code,prd.prch_rqstn_dtl_prch_req_qty,prd.prch_rqstn_dtl_itm_catg_cd,prd.prch_rqstn_dtl_sup_plnt_cd,prd.prch_rqstn_dtl_fxd_vndr_cd,prd.prch_rqstn_dtl_prch_req_dt,pod.prch_ord_dtl_rqstn_id_itm_nr_ky from  ${dbName}.PurchaseOrder_tmp pod inner join ${dbNameConsmtn}.edm_prch_rqstn_dtl_dmnsn prd on pod.prch_ord_dtl_rqstn_id_itm_nr_ky=prd.prch_rqstn_dtl_dmnsn_ky")
    PurchaseRequistion_DF.write.mode("Overwrite").format("ORC").saveAsTable(dbName + ".PurchaseRequistion_tmp")

    //Logic for fact load
    val edm_prch_ord_dmnsn_inc = spark.sql(s"""select crc32(lower(trim(concat(coalesce(prch_acct_asngmt_dmnsn_ky,""),coalesce(prch_ord_dmnsn_ky,""),coalesce(prch_ord_dtl_dmnsn_ky,""),coalesce(prch_ord_itm_cfrn_dmnsn_ky,""),coalesce(prch_ord_schdl_itm_dmnsn_ky,""),coalesce(prch_ord_sm_dmnsn_ky,""),coalesce(prch_rqstn_dtl_dmnsn_ky,""))))) as po_pr_mstr_fact_ky
,crc32(lower(trim(coalesce(pod.prch_ord_dtl_prch_inf_rec_id,"")))) as prchg_inf_rec_prch_inf_rec_id_ky           
,crc32(lower(trim(coalesce(pod.prch_ord_prchg_grp_cd,""))))  as prch_ord_prchg_grp_cd_ky
,crc32(lower(trim(coalesce(pod.prch_ord_dtl_plnt_cd,"")))) as prch_ord_dtl_plnt_cd_ky
,crc32(lower(trim(coalesce(pod.prch_ord_dtl_mtrl_id,"")))) as prch_ord_dtl_mtrl_id_ky
,crc32(lower(trim(coalesce(pod.prch_ord_prch_org_cd,"")))) as prch_ord_prch_org_cd_ky
,paa.prch_acct_asngmt_dmnsn_ky,
pod.prch_ord_dmnsn_ky,
pod.prch_ord_dtl_dmnsn_ky,
poic.prch_ord_itm_cfrn_dmnsn_ky,
posi.prch_ord_schdl_itm_dmnsn_ky,
pos.prch_ord_sm_dmnsn_ky,
prd.prch_rqstn_dtl_dmnsn_ky,
paa.prch_acct_asngmt_src_sys_cd,
paa.prch_acct_asngmt_prch_ord_id,
paa.prch_acct_asngmt_prch_ord_itm_nr,
paa.acct_asngmt_sqn_nr,
paa.nt_amt_cd,
paa.prch_acct_asngmt_prch_ord_qty_cd,
paa.sls_ord_id,
paa.sls_ord_itm_nr,
paa.schdl_ln_nr,
paa.mn_asst_id,
paa.ord_id,
paa.unldg_pnt_dn_cd,
paa.ctrlng_ar_cd,
paa.prch_acct_asngmt_ins_ts_cd,
paa.prch_acct_asngmt_upd_ts_dt,
paa.prch_acct_asngmt_src_sys_crt_ts_cd,
paa.prch_acct_asngmt_lgcl_dlt_ind_cd,
pod.prch_ord_src_sys_cd,
pod.prch_ord_prch_ord_id,
pod.vrsn_id,
pod.lgl_co_cd,
pod.prchg_dcmt_typ_cd,
pod.prch_stts_cd,
pod.irvl_nr,
pod.prch_ord_vndr_prty_id,
pod.prch_ord_lng_cd,
pod.pmnt_trm_cd,
pod.prch_ord_prch_org_cd,
pod.prch_ord_prchg_grp_cd,
pod.prch_ord_curr_cd,
pod.exch_rate_cd,
pod.fx_exch_ind_cd,
pod.prch_dt,
pod.xtrn_rfnc_txt_cd,
pod.prch_ord_sls_pers_nm,
pod.gds_vndr_prty_id,
pod.prch_ord_Incoterm_prt_1_cd,
pod.prch_ord_Incoterm_prt_2_cd,
pod.Invoicing_vndr_prty_id,
pod.inrn_rfnc_txt_cd,
pod.rls_st_txt_cd,
pod.incmplt_ind_cd,
pod.prch_ord_ins_ts_cd,
pod.prch_ord_upd_ts_dt,
pod.prch_ord_src_sys_crt_ts_cd,
pod.prch_ord_lgcl_dlt_ind_cd,
pod.prch_ord_dtl_src_sys_cd,
pod.prch_ord_dtl_prch_ord_id,
pod.prch_ord_dtl_prch_ord_itm_nr,
pod.tx_cd,
pod.mfrr_prt_id,
pod.prch_ord_dtl_plnt_cd,
pod.prch_ord_shrt_txt_cd,
pod.prch_ord_dtl_prncpl_prch_agrmnt_id,
pod.prch_ord_dtl_prncpl_prch_agrmnt_itm_nr,
pod.crss_plnt_mtrl_id,
pod.rqst_qtn_id,
pod.rqst_qtn_itm_nr,
pod.prch_ord_dtl_rqstn_itm_nr,
pod.prch_itm_dlt_ind_cd,
pod.prch_ord_dtl_mtrl_id,
pod.prch_ord_dtl_rqstn_id,
pod.storg_lctn_cd,
pod.rqmt_trkg_nr,
pod.prch_ord_dtl_vndr_mtrl_id,
pod.prch_ord_dtl_prch_ord_qty_cd,
pod.prch_ord_unt_msr_cd,
pod.prch_ord_dtl_ord_prc_unt_msr_cd,
pod.prch_ord_dtl_nt_prc_amt_cd,
pod.prch_ord_dtl_unt_prc_amt_cd,
pod.gds_rcpt_prsng_dys_dt,
pod.dlvry_cmpltn_ind_cd,
pod.fnl_inv_ind_cd,
pod.prch_ord_itm_cgy_cd,
pod.acct_asngmt_cgy_cd,
pod.mltpl_acct_asngmt_cd,
pod.inv_rcpt_ind_cd,
pod.prch_ord_dtl_inv_vrfctn_ind_cd,
pod.prch_ord_dtl_ord_ackgmt_ind_cd,
pod.prch_ord_dtl_shpg_inst_cd,
pod.prch_ord_dtl_cust_prty_id,
pod.prch_ord_dtl_vndr_cndn_grp_cd,
pod.wght_unt_msr_cd,
pod.tx_jrstc_cd,
pod.prch_ord_dtl_cfrn_ctrl_cd,
pod.vol_unt_msr_cd,
pod.prch_ord_dtl_Incoterm_prt_1_cd,
pod.prch_ord_dtl_Incoterm_prt_2_cd,
pod.prr_vndr_prty_id,
pod.hghr_lvl_itm_cd,
pod.rtn_itm_ind_cd,
pod.orgn_mtrl_cd,
pod.prch_ord_dtl_ins_ts_cd,
pod.prch_ord_dtl_upd_ts_dt,
pod.prch_ord_dtl_lgcl_dlt_ind_cd,
poic.prch_ord_itm_cfrn_src_sys_cd,
poic.prch_ord_itm_cfrn_prch_ord_itm_nr,
poic.prch_ord_itm_cfrn_prch_ord_id,
poic.itm_cfrn_sqn_nr,
poic.cfrn_cgy_cd,
poic.prch_ord_itm_cfrn_cgy_dlvry_cd,
poic.cfrd_qty_cd,
poic.dlvry_dt,
poic.prch_ord_itm_cfrn_Reduced_qty_cd,
poic.prch_ord_itm_cfrn_Reminder_qty_cd,
poic.cfrn_crt_cd,
poic.prch_ord_itm_cfrn_src_sys_crt_ts_cd,
poic.prch_ord_itm_cfrn_ins_ts_cd,
poic.prch_ord_itm_cfrn_upd_ts_dt,
poic.prch_ord_itm_cfrn_lgcl_dlt_ind_cd,
posi.prch_ord_schdl_itm_src_sys_cd,
posi.prch_ord_schdl_itm_prch_ord_id,
posi.prch_ord_schdl_itm_prch_ord_itm_nr,
posi.schdl_ln_itm_nr,
posi.prch_ord_schdl_itm_cgy_dlvry_cd,
posi.Fixing_ind_cd,
posi.itm_dlvry_dt,
posi.rlvnt_dlvry_dt,
posi.schdl_ln_ord_dt,
posi.schdl_ln_crtn_cd,
posi.gds_rcpt_ts_cd,
posi.dlvry_ts_cd,
posi.mtrl_stgg_ts_cd,
posi.Loading_ts_cd,
posi.trnsp_pln_ts_cd,
posi.gds_iss_ts_cd,
posi.Handover_ts_cd,
posi.Reminder_ts_cd,
posi.srl_qty_nr,
posi.prch_ord_schdl_itm_prch_ord_qty_cd,
posi.prv_qty_cd,
posi.gds_Recieved_qty_cd,
posi.issd_qty_cd,
posi.dlvrd_qty_cd,
posi.prch_ord_schdl_itm_Reduced_qty_cd,
posi.cmmtd_qty_cd,
posi.prch_ord_schdl_itm_rqstn_id,
posi.prch_ord_schdl_itm_rqstn_itm_nr,
posi.prch_ord_schdl_itm_Reminder_qty_cd,
posi.cmpnnt_ind_cd,
posi.cmmtd_dt,
posi.prv_dlvry_dt,
posi.rte_schdl_id,
posi.crr_prty_id,
posi.prch_ord_schdl_itm_ins_ts_cd,
posi.prch_ord_schdl_itm_upd_ts_dt,
posi.prch_ord_schdl_itm_lgcl_dlt_ind_cd,
pos.prch_ord_sm_src_sys_cd,
pos.prch_ord_sm_prch_ord_id,
pos.prch_ord_sm_prch_ord_itm_nr,
pos.shpg_typ_cd,
pos.sm_pnt_cd,
pos.rte_cd,
pos.prch_ord_sm_cust_prty_id,
pos.sls_org_cd,
pos.dbn_chnl_cd,
pos.dvsn_cd,
pos.prch_ord_sm_lng_cd,
pos.sm_cndn_cd,
pos.Loading_grp_cd,
pos.trns_grp_cd,
pos.ord_cmbn_ind_cd,
pos.prch_ord_sm_ins_ts_cd,
pos.prch_ord_sm_upd_ts_dt,
pos.prch_ord_sm_src_sys_crt_ts_cd,
pos.prch_ord_sm_lgcl_dlt_ind_cd,
pos.dl_ctr_dt,
prd.prch_rqstn_dtl_src_sys_cd,
prd.prch_rqstn_dtl_rqstn_id,
prd.prch_rqstn_dtl_rqstn_itm_nr,
prd.prch_rqstn_dtl_prch_ord_id,
prd.prch_rqstn_dtl_mtrl_id,
prd.mfrr_mtrl_id,
prd.rqstn_rls_dt,
prd.prch_rqstn_dtl_prncpl_prch_agrmnt_id,
prd.prch_rqstn_dtl_prncpl_prch_agrmnt_itm_nr,
prd.prch_rqstn_dtl_prch_ord_itm_nr,
prd.prch_rqstn_dtl_ins_ts_cd,
prd.prch_rqstn_dtl_upd_ts_dt,
prd.prch_rqstn_dtl_src_sys_upd_ts_dt,
prd.prch_rqstn_dtl_lgcl_dlt_ind_cd,
case when dlvry_cmpltn_ind_cd="X" then "Complete"
when prch_itm_dlt_ind_cd="X" then "Cancelled"
when (dlvry_cmpltn_ind_cd is null and prch_itm_dlt_ind_cd is null) then "Open" end
as po_status,
(coalesce(prch_ord_dtl_prch_ord_qty_cd,0) - coalesce(dlvrd_qty_cd,0)) as opn_qty
,pod.src_sys_crtd_by_usr_id          
,pod.rls_ind_cd                       
,pod.prcg_prcgr_cd                    
,pod.dcmt_cndn_id                     
,pod.prch_ord_prncpl_prch_agrmnt_id   
,pod.src_ctry_cd                      
,prd.prch_dcmt_typ_cd                            
,prd.dlvry_rqst_dt                              
,prd.prch_ord_dt                                
,prd.schdld_qty_cd                              
,prd.last_mfyd_dt                               
,prd.mtrl_rcvd_qty_cd                           
,prd.rqstd_mtrl_prc_amt_cd                      
,prd.rqstd_status_cd                            
,prd.prch_rqstn_dtl_plnt_code, 
prd.prch_rqstn_dtl_prch_req_qty,
prd.prch_rqstn_dtl_itm_catg_cd,
prd.prch_rqstn_dtl_sup_plnt_cd,
prd.prch_rqstn_dtl_fxd_vndr_cd,
prd.prch_rqstn_dtl_prch_req_dt, 
pod.rqstr_usr_id                    
,pod.grs_wght_cd                     
,pod.grs_amt_cd     
,pod.rfnc_cnfgn_id  
,pod.itm_amt_cd     
,pod.schdl_ln_print_ind_cd          
,pod.stk_typ_cd                     
,pod.tgt_qty_cd                     
,pod.spcl_stk_valtn_typ_cd          
,pod.cnfgl_mtrl_ind_cd              
,pod.expeditor_frst_reminder_qty_cd 
,pod.expeditor_scnd_reminder_qty_cd 
,pod.expeditor_thrd_reminder_qty_cd 
,pod.mtrl_typ_cd                    
,pod.prch_ord_dtl_mtrl_grp          
,pod.blng_itm_nt_amt_cd             
,pod.spcl_stk_ind_cd                
,pod.rec_upd_ind_dt                 
,pod.ststcl_ind_cd                  
,pod.ulmt_ovr_dlvry_ind_cd          
,pod.zzbuild_hld                    
,pod.trst_ts_cd                     
,pod.zzship_hld                      
,pod.prch_ord_dtls_prty_id           
,pod.shp_tup_cd                      
,pod.pp_dlvdys                       
,pod.frcst_dt                        
,poic.rfnc_dcmt_id                
,poic.po_itm_cfrn_sls_ord_itm_nr
,paa.bsn_ar_cd  ,
poic.inbnd_dlvry ,
pod.ord_ack ,
paa.gnld_accno ,
  ir.opn_ir_qty as opn_ir_qty,
datediff(poic.dlvry_dt,pod.prch_dt) as turnarnd_tm_dys,
pod.intgtn_fbrc_msg_id,   
pod.src_sys_upd_ts,        
pod.src_sys_ky,            
pod.lgcl_dlt_ind,          
pod.ins_gmt_ts,           
pod.upd_gmt_ts,           
pod.src_sys_extrc_gmt_ts, 
pod.src_sys_btch_nr,    
pod.fl_nm,              
pod.ld_jb_nr,
current_timestamp as ins_ts,
pod.ins_gmt_dt 
from  
${dbName}.PurchaseOrder_tmp pod
left join ${dbNameConsmtn}.edm_prch_acct_asngmt_dmnsn paa on
pod.prch_ord_dtl_prch_ord_id_itm_nr_ky=paa.prch_acct_asngmt_prch_ord_id_itm_nr_ky
left join ${dbNameConsmtn}.edm_prch_ord_schdl_itm_dmnsn posi on
pod.prch_ord_dtl_prch_ord_id_itm_nr_ky=posi.prch_ord_schdl_itm_prch_ord_id_itm_nr_ky
left join ${dbNameConsmtn}.edm_prch_ord_itm_cfrn_dmnsn poic on 
pod.prch_ord_dtl_prch_ord_id_itm_nr_ky=poic.prch_ord_itm_cfrn_prch_ord_id_itm_nr_ky
left join ${dbNameConsmtn}.edm_prch_ord_sm_dmnsn pos on 
pod.prch_ord_dtl_prch_ord_id_itm_nr_ky=pos.prch_ord_sm_prch_ord_id_itm_nr_ky
left join ${dbName}.PurchaseRequistion_tmp prd on
pod.prch_ord_dtl_rqstn_id_itm_nr_ky=prd.prch_rqstn_dtl_dmnsn_ky
left outer join ${dbName}.opn_ir_qty_doc ir on ir.prchg_ord_nr=pod.prch_ord_dtl_prch_ord_id and pod.prch_ord_dtl_prch_ord_itm_nr= ir.unq_prch_dcmt_itm_cd where pod.ins_gmt_ts > $maxtgttimestamp""")

    edm_prch_ord_dmnsn_inc.persist(StorageLevel.MEMORY_AND_DISK_SER)
    // Source count
    var src_count = edm_prch_ord_dmnsn_inc.count()
    logger.info("Source table count" + src_count)
    if (src_count != 0) {
      edm_prch_ord_dmnsn_inc.createOrReplaceTempView("edm_prch_ord_dmnsn_inc")

      //Fact increment logic
      val existingcnsmpDF = spark.sql(f"""select * from ${dbNameConsmtn}.${consmptnTable}""")

      if (existingcnsmpDF.count > 0) {
        val overWritePrtition = existingcnsmpDF.join(edm_prch_ord_dmnsn_inc, existingcnsmpDF("prch_ord_prch_ord_id") === edm_prch_ord_dmnsn_inc("prch_ord_prch_ord_id")).select(existingcnsmpDF("ins_gmt_dt").cast(StringType)).distinct.collect.map(row => row.getString(0).toString()).toSeq

        val edm_prch_ord_dmnsn_nonmatch = existingcnsmpDF.where(existingcnsmpDF("ins_gmt_dt").isin(overWritePrtition: _*)).join(edm_prch_ord_dmnsn_inc, existingcnsmpDF("prch_ord_prch_ord_id") === edm_prch_ord_dmnsn_inc("prch_ord_prch_ord_id"), "left_anti").drop(edm_prch_ord_dmnsn_inc("prch_ord_prch_ord_id"))

        val po_pr_mstr_fact_final = edm_prch_ord_dmnsn_inc.union(edm_prch_ord_dmnsn_nonmatch)

        po_pr_mstr_fact_final.coalesce(numPartitions).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)
        logger.info("==================== Po_pr_mstr_fact fact load Complete =======================")
        //Total no of records in fact table

        tgt_count = po_pr_mstr_fact_final.count().toInt
        //************************Completion Audit Entries*******************************//
        if (tgt_count <= 0) {
          logger.error("No records to process !")
          auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
          auditObj.setAudDataLayerName("ref_cnsmptn")
          auditObj.setAudApplicationName("job_EA_FactloadConsumption")
          auditObj.setAudObjectName(propertiesObject.getObjName())
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(0)
          auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
          auditObj.setFlNm("")
          auditObj.setSysBtchNr(ld_jb_nr)
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

        } else {
          logger.info("Incremental records processed!")
          auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
          auditObj.setAudDataLayerName("ref_cnsmptn")
          auditObj.setAudApplicationName("job_EA_FactloadConsumption")
          auditObj.setAudObjectName(propertiesObject.getObjName())
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(0)
          auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
          auditObj.setFlNm("")
          auditObj.setSysBtchNr(ld_jb_nr)
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        }

      } else {

        edm_prch_ord_dmnsn_inc.coalesce(numPartitions).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)
        logger.info("==================== Po_pr_mstr_fact fact load Complete =======================")
        tgt_count = edm_prch_ord_dmnsn_inc.count().toInt
        //************************Completion Audit Entries*******************************//
        if (tgt_count <= 0) {
          logger.error("No records to process !")
          auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
          auditObj.setAudDataLayerName("ref_cnsmptn")
          auditObj.setAudApplicationName("job_EA_FactloadConsumption")
          auditObj.setAudObjectName(propertiesObject.getObjName())
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(0)
          auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
          auditObj.setFlNm("")
          auditObj.setSysBtchNr(ld_jb_nr)
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

        } else {
          logger.info("Records processed!")
          auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
          auditObj.setAudDataLayerName("ref_cnsmptn")
          auditObj.setAudApplicationName("job_EA_FactloadConsumption")
          auditObj.setAudObjectName(propertiesObject.getObjName())
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudErrorRecords(0)
          auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
          auditObj.setFlNm("")
          auditObj.setSysBtchNr(ld_jb_nr)
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        }

      }

      Utilities.insert_last_refresh_timestamp("Procurement-Data_Model", "edm_prch_ord_ref", edm_prch_ord_dmnsn_inc, "ins_gmt_ts", dbNameConsmtn)
      edm_prch_ord_dmnsn_inc.unpersist()
    } else logger.error("No records in source table")
  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
    case ex: Exception => {
      logger.error("Exception: " + ex.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
  } finally {
    spark.sql(s"drop table ${dbName}.PurchaseOrder_tmp")
    spark.sql(s"drop table ${dbName}.PurchaseRequistion_tmp")
    logger.info("jobStatusFlag:" + jobStatusFlag)
    sqlCon.close()
    spark.close()

  }
}
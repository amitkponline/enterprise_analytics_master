package com.hpe.batch.driver.facts.deliveryshipment

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import scala.collection.JavaConversions._
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import org.apache.spark.sql.expressions.Window

object Shipment extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj:AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var ld_jb_nr_ref = (ld_jb_nr + "_" + batchId)
  val sourceTable =propertiesObject.getSrcTblConsmtn()
  val targetTable =propertiesObject.getTgtTblConsmtn()
  var dbNameConsmtn: String = null
  var ref2: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    ref2 = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  var dbNameConsmtnmainref: String = null 
  var mainref: String = null
  if (propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtnmainref = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0)
     mainref = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(1)
     
     logger.info("main ref tabel name and schema name "+ dbNameConsmtnmainref + mainref)
     
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  
   try {    

  val shipmentMaxInsertTimestamp = "'"+spark.sql(f""" select coalesce(max(ins_gmt_ts),'1900-01-01 00:00:01') from $targetTable""").collect.map(row => row.getString(0)).mkString("")+"'" 
  
  logger.info("************* Inside if Table Write Status : loadStatus -->*********")
   
val keys_sm_ref="""    sm_src_sys_cd,sm_sm_id,sm_crtd_by_usr_id,sm_sm_pnt_cd,sm_sls_org_cd,sm_sls_dstc_cd,sm_cmplt_dlvry_ind_cd,sm_ord_cmbn_ind_cd,sm_plnd_gds_mvmt_dt,sm_loading_dt,sm_trns_plng_dt,sm_dlvry_dt,sm_pckng_dt,sm_unldg_pnt_dn_cd,sm_incoterm_prt_1_cd,sm_incoterm_prt_2_cd,sm_xprt_ind_cd,sm_rte_cd,sm_blng_blck_rsn_cd,sm_dlvry_blck_rsn_cd,sm_dcmt_cgy_cd,sm_dlvry_pri_cd,sm_shp_to_prty_id,sm_sld_to_prty_id,sm_cust_grp_cd,sm_totl_sm_wght_cd,sm_nt_sm_wght_cd,sm_wght_unt_msr_cd,sm_sm_cndn_cd,sm_sm_itm_vol_cd,sm_vol_unt_msr_cd,sm_totl_pkg_qty_cd,sm_picked_itm_lctn_cd,sm_dlvry_ts_cd,sm_wght_grp_cd,sm_loading_pnt_cd,sm_trns_grp_cd,sm_prpsd_blng_typ_cd,sm_printout_blng_dt,sm_inv_clndr_cd,shipment_sm_dlvry_rt_1_cd,sm_upd_grp_dt,sm_acctng_prcgr_cd,sm_dcmt_cndn_id,sm_curr_cd,sm_sls_ofc_cd,sm_sm_prsng_durtn_qty_cd,sm_dlvry_cmbn_crtr_cd,sm_dbn_dlvry_dn_cd,sm_cmnn_nr,sm_statistics_curr_cd,sm_statistics_curr_exch_rate_cd,sm_frn_trd_dta_inrn_id,sm_updd_by_usr_id_dt,sm_wh_cmplx_cd,sm_wh_dlvry_splt_ind_cd,sm_sls_organisation_cd,sm_dbn_chnl_cd,sm_sls_dvsn_cd,sm_ic_blng_typ_cd,shipment_sm_ic_bln_1_dt_cd,shipment_sm_ic_bln_1_dt,sm_ic_blng_prty_id,sm_crdt_ctrl_ar_cd,sm_crdt_lmt_cust_acct_cd,sm_cust_crdt_grp_cd,sm_crdt_rep_grp_cd,sm_crdt_risk_cgy_cd,sm_crdt_ctrl_ar_curr_cd,sm_dcmt_rlsd_crdt_amt_cd,sm_bll_ldg_nr,sm_vndr_acct_id,sm_trns_mtd_cd,sm_trns_mtd_id,sm_crdt_dcmt_rlsd_dt,sm_nxt_dt,sm_gds_rcpt_iss_sp_nr,sm_dcmt_dt,sm_actl_gds_mvmt_dt,sm_sm_blck_rsn_cd,sm_xtrn_trns_sys_id,sm_dlvry_note_xtrn_id,sm_ord_id,sm_srch_prcgr_cd,sm_crctn_dlvry_ind_cd,sm_sm_prcg_prcgr_cd,sm_prcg_dcmt_cndn_id,sm_ord_itm_nt_amt_cd,sm_rte_schdl_id,sm_rcvg_plnt_cd,sm_fncl_dcmt_inrn_id,sm_pmnt_grnt_prcgr_cd,sm_plnt_pckng_ts_cd,sm_trns_plng_ts_cd,sm_loading_ts_cd,sm_gds_iss_ts_cd,sm_wh_door_nr,sm_wh_cmplx_stgg_ar_cd,sm_dangerous_gds_mgmt_pfl_cd,sm_prty_rfnc_dcmt_id,sm_tm_sgm_exist_ind_cd,sm_evt_grp_tm_sgm_cd,sm_delivering_lctn_tm_zn_cd,sm_rcpnt_lctn_tm_zn_cd,sm_dangerous_gds_ind_cd,sm_dbn_dlvry_orgl_sys_cd,sm_gds_mvmt_ctrl_cd,sm_dlvry_prsng_stts_cd,sm_trsn_cd,sm_shpg_typ_cd,sm_means_trns_cd,sm_spcl_prsng_cd,sm_co_id,sm_opn_vl_cltn_ind_cd,sm_atmtc_trnsfr_ord_gnrt_ind_cd,sm_prdn_sply_ar_cd,sm_dlvry_typ_cd,sm_prf_dlvry_cfrn_dt,sm_prf_dlvry_cfrn_ts_cd,sm_otr_sys_prdcsr_itms_qty_cd,sm_dlvry_plnt_ind_cd,sm_gbl_trd_srvs_rte_cd,sm_rls_ts_cd,sm_msrmt_unt_sys_cd,sm_ptnr_bll_id,sm_print_pfl_dn_cd,sm_advd_rtns_mgmt_actv_cd,sm_cfrn_id,sm_storg_lctn_chg_ind_cd,sm_dcmt_trnsfr_ctrl_cd,sm_dlvry_splt_initiation_cd,sm_dlvry_vrsn_id,sm_handover_lctn_cd,sm_handover_dt,sm_handover_ts_cd,sm_handover_tm_zn_cd,sm_mlt_lvl_gds_rcpt_id,sm_kanban_ind_cd,sm_src_sys_crt_ts_cd,sm_src_sys_upd_dt,sm_ovrl_prsng_stts_cd,sm_estmd_dlvry_arvl_1_dt,sm_estmd_dlvry_arvl_2_dt,sm_estmd_dlvry_arvl_3_dt,sm_estmd_dlvry_arvl_4_dt,sm_estmd_dlvry_arvl_5_dt,sm_estmd_dlvry_arvl_tiime_1_txt_cd,sm_estmd_dlvry_arvl_tm_2_txt_cd,sm_estmd_dlvry_arvl_tm_3_txt_cd,sm_estmd_dlvry_arvl_tm_4_txt_cd,sm_estmd_dlvry_arvl_tm_5_txt_cd,sm_eta_upd_rsn_dt,sm_eta_upd_rsn_txt_dt,sm_trkg_id,std_crr_acss_cd,sm_ins_ts_cd,sm_upd_ts_dt,sm_lgcl_dlt_ind_cd,gds_issue_ts,ptnr_fncn_cd,collective_nr,shp_to_attn_cd,sls_ord_crtn_dt,sls_dcmt_typ_cd, lng_ky_cd,sls_dcmt_typ_cd as sls_dcmt_typ_nm,sls_dcmt_typ_dn_cd
, intgtn_fbrc_msg_id , src_sys_upd_ts, src_sys_ky
                    ,  lgcl_dlt_ind, ins_gmt_ts, upd_gmt_ts, src_sys_extrc_gmt_ts, src_sys_btch_nr
                    ,  fl_nm ,'""" + ld_jb_nr_ref + """' as ld_jb_nr , to_date(ins_gmt_ts) as ins_gmt_dt"""

val hive_ref_select = spark.sql(f"""select $keys_sm_ref from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp) and sm_sm_id is not null and sm_src_sys_cd is not null""")

val query_hive_Ref_select = s"""select $keys_sm_ref from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp) and sm_sm_id is not null and sm_src_sys_cd is not null"""

logger.info("*************** query_hive_Ref_select  ************ "  +  query_hive_Ref_select)

val windowSpec = Window.partitionBy("sm_src_sys_cd", "sm_sm_id").orderBy(desc("sm_upd_ts_dt"))

val finalDataset = hive_ref_select.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm")

finalDataset.persist(StorageLevel.MEMORY_AND_DISK_SER)
val src_count = finalDataset.count
val tgt_count = src_count 

val numOfWritePartitions = if((shipmentMaxInsertTimestamp.contains("1900-"))) ((spark.conf.get("spark.sql.shuffle.partitions")).toInt)/5 else {((spark.conf.get("spark.sql.shuffle.partitions")).toInt)/30}

val loadStatus = Utilities.storeDataFrame(finalDataset, "Append", "ORC", targetTable,tgt_count,numOfWritePartitions) 

   //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ld_jb_nr_ref)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
      logger.info("************* Inside if Table Write Status : loadStatus -->*********" + loadStatus)
    } else {
      auditObj.setAudJobStatusCode("failed")
      logger.info("************* Inside else Table Write Status : loadStatus -->*********" + loadStatus)
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}
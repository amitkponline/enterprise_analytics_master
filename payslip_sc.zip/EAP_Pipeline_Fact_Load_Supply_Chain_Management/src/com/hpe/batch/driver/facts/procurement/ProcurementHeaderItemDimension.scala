package com.hpe.batch.driver.facts.procurement

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import org.apache.spark.sql.types._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.DataFrame

import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import org.apache.spark.storage.StorageLevel

object ProcurementHeaderItemDimension extends App {
   //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj:AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val auditObj1:AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val propertiesObject: StreamingPropertiesObjectEnhanced = Utilities.getStreamingPropertiesObjectEnhanced(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
auditObj1.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val mtrl_qta_hddr_itm = propertiesObject.getMasterDataFields().split(",", -1)(5)
  val pir_hddr_itm = propertiesObject.getMasterDataFields().split(",", -1)(6)

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

  val transformeSrcdDF = spark.sql("""select * from """ + propertiesObject.getSrcTblConsmtn() )

  val src_count = transformeSrcdDF.count().toInt
  
   val transformeSrcdDF1 = spark.sql("""select * from """ + propertiesObject.getSrcTblConsmtn1() )

  val src_count1 = transformeSrcdDF1.count().toInt
  
  var jobStatusFlag = true
   var tgt_count = 0
     var tgt_count1 = 0

  try {
  
  /********** Loading Material Quota Header Item Dimension*********************/
    
		val hive_mtrl_qta_arngmnt_hdr_itm = {mtrl_qta_hddr_itm}
		
//Maximum timestamp of material quota header table
    val maxtgttimestamp = "'"+spark.sql(f"""select coalesce(max(ins_gmt_ts),'1900-01-01 00:00:01.000') as txn_timestamp from ${dbNameConsmtn}.${hive_mtrl_qta_arngmnt_hdr_itm} """).collect().map(_.getString(0)).mkString("")+"'"
	
		println("**************************" + hive_mtrl_qta_arngmnt_hdr_itm + "*******************************")
		val edm_mtrl_qta_arr_hdr_df  = spark.sql(s"""select
crc32(lower(trim(concat(coalesce(mqa.mtrl_qta_Arrangement_dmnsn_ky,""),coalesce(mqai.mtrl_qta_Arrangement_itm_dmnsn_ky,""))))),
mqa.mtrl_qta_Arrangement_dmnsn_ky,
mqa.mtrl_qta_Arrangement_mtrl_id_ky,
mqa.mtrl_qta_Arrangement_plnt_cd_ky,
mqa.mtrl_qta_Arrangement_mtrl_qta_Arrangement_id_ky,
mqai.mtrl_qta_Arrangement_itm_dmnsn_ky,
mqai.mtrl_qta_Arrangement_itm_mtrl_qta_Arrangement_id_ky,
mqa.mtrl_qta_Arrangement_src_sys_cd,
mqa.mtrl_qta_Arrangement_mtrl_id,
mqa.mtrl_qta_Arrangement_vld_end_dt,
mqa.mtrl_qta_Arrangement_plnt_cd,
mqa.mtrl_qta_Arrangement_mtrl_qta_Arrangement_id,
mqa.mtrl_qta_Arrangement_vld_strt_dt,
mqa.mtrl_qta_Arrangement_crtd_by_usr_id,
mqa.mnm_lt_qty_cd,
mqa.mtrl_qta_Arrangement_src_sys_crt_dt,
mqa.mtrl_qta_Arrangement_src_sys_upd_ts_dt,
mqa.mtrl_qta_Arrangement_ins_ts_cd,
mqa.mtrl_qta_Arrangement_upd_ts_dt,
mqa.mtrl_qta_Arrangement_lgcl_dlt_ind_cd,
mqai.mtrl_qta_Arrangement_itm_src_sys_cd,
mqai.mtrl_qta_Arrangement_itm_mtrl_qta_Arrangement_id,
mqai.mtrl_qta_Arrangement_itm_mtrl_qta_Arrangement_itm_nr,
mqai.mtrl_qta_Arrangement_itm_vndr_prty_id,
mqai.mtrl_qta_Arrangement_itm_prcmt_plnt_cd,
mqai.qta_qty_cd,
mqai.bs_qty_cd,
mqai.alct_qty_cd,
mqai.mxm_qty_cd,
mqai.prcmt_typ_ind_cd,
mqai.mtrl_qta_Arrangement_itm_ins_ts_cd,
mqai.mtrl_qta_Arrangement_itm_upd_ts_dt,
mqai.mtrl_qta_arrangement_itm_lgcl_dlt_ind_cd,
mqa.intgtn_fbrc_msg_id,   
mqa.src_sys_upd_ts,        
mqa.src_sys_ky,            
mqa.lgcl_dlt_ind,          
mqa.ins_gmt_ts,           
mqa.upd_gmt_ts,           
mqa.src_sys_extrc_gmt_ts, 
mqa.src_sys_btch_nr,    
mqa.fl_nm,              
mqa.ld_jb_nr,
current_timestamp,
mqa.ins_gmt_dt
from ${dbNameConsmtn}.edm_mtrl_qta_arr_dmnsn mqa left join ${dbNameConsmtn}.edm_mtrl_qta_arr_itm_dmnsn mqai
on mqa.mtrl_qta_Arrangement_mtrl_qta_Arrangement_id_ky=mqai.mtrl_qta_Arrangement_itm_mtrl_qta_Arrangement_id_ky where mqa.ins_gmt_ts > $maxtgttimestamp""")  

edm_mtrl_qta_arr_hdr_df.persist(StorageLevel.MEMORY_ONLY_SER)
edm_mtrl_qta_arr_hdr_df.count()
edm_mtrl_qta_arr_hdr_df.createOrReplaceTempView("edm_mtrl_qta_arr_hdr_df")	

//material quota header dimension table increment logic
val existingcnsmpDF = spark.sql(f"""select * from ${dbNameConsmtn}.${hive_mtrl_qta_arngmnt_hdr_itm}""")

 if(existingcnsmpDF.count>0)
      {
val overWritePrtition = existingcnsmpDF.join(edm_mtrl_qta_arr_hdr_df, existingcnsmpDF("mtrl_qta_Arrangement_mtrl_qta_Arrangement_id_ky")===edm_mtrl_qta_arr_hdr_df("mtrl_qta_Arrangement_mtrl_qta_Arrangement_id_ky")).select(existingcnsmpDF("ins_gmt_dt").cast(StringType)).distinct.collect.map(row => row.getString(0).toString()).toSeq

val edm_prch_ord_dmnsn_nonmatch = existingcnsmpDF.where(existingcnsmpDF("ins_gmt_dt").isin(overWritePrtition: _*)).join(edm_mtrl_qta_arr_hdr_df,existingcnsmpDF("mtrl_qta_Arrangement_mtrl_qta_Arrangement_id_ky")===edm_mtrl_qta_arr_hdr_df("mtrl_qta_Arrangement_mtrl_qta_Arrangement_id_ky"),"left_anti").drop(edm_mtrl_qta_arr_hdr_df("mtrl_qta_Arrangement_mtrl_qta_Arrangement_id_ky"))

val edm_mtrl_qta_arr_hdr_df_final = edm_mtrl_qta_arr_hdr_df.unionAll(edm_prch_ord_dmnsn_nonmatch)

 edm_mtrl_qta_arr_hdr_df_final.coalesce(20).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + hive_mtrl_qta_arngmnt_hdr_itm)
logger.info("==================== edm_mtrl_qta_arr_hdr_df fact load Complete =======================")
 //Total no of records in material quota header dimension table
 
 tgt_count = edm_mtrl_qta_arr_hdr_df_final.count().toInt
  //************************Completion Audit Entries for material quota *******************************//
		 if (tgt_count <=0)
 {
     logger.error("No records to process !")
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
		auditObj.setAudDataLayerName("ref_cnsmptn")
		auditObj.setAudApplicationName("job_EA_loadConsumption")
		auditObj.setAudObjectName(propertiesObject.getObjName())
		auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
				auditObj.setAudJobStatusCode("success")
				auditObj.setAudSrcRowCount(src_count)
		auditObj.setAudTgtRowCount(tgt_count)
		auditObj.setAudErrorRecords(0)
		auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
		auditObj.setFlNm("")
		auditObj.setSysBtchNr(ld_jb_nr)
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl) 
   
 } else 
 {logger.error("Incremental records processed!")
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
		auditObj.setAudDataLayerName("ref_cnsmptn")
		auditObj.setAudApplicationName("job_EA_loadConsumption")
		auditObj.setAudObjectName(propertiesObject.getObjName())
		auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
				auditObj.setAudJobStatusCode("success")
				auditObj.setAudSrcRowCount(src_count)
		auditObj.setAudTgtRowCount(tgt_count)
		auditObj.setAudErrorRecords(0)
		auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
		auditObj.setFlNm("")
		auditObj.setSysBtchNr(ld_jb_nr)
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl) }
      }				
else 
{
  
  edm_mtrl_qta_arr_hdr_df.coalesce(20).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + hive_mtrl_qta_arngmnt_hdr_itm)
logger.info("==================== Po_pr_mstr_fact fact load Complete =======================")
  tgt_count = edm_mtrl_qta_arr_hdr_df.count().toInt
 //************************Completion Audit Entries*******************************//
if (tgt_count <=0)
 {
     logger.error("No records to process !")
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
		auditObj.setAudDataLayerName("ref_cnsmptn")
		auditObj.setAudApplicationName("job_EA_loadConsumption")
		auditObj.setAudObjectName(propertiesObject.getObjName())
		auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
				auditObj.setAudJobStatusCode("success")
				auditObj.setAudSrcRowCount(src_count)
		auditObj.setAudTgtRowCount(tgt_count)
		auditObj.setAudErrorRecords(0)
		auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
		auditObj.setFlNm("")
		auditObj.setSysBtchNr(ld_jb_nr)
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl) 
   
 } else 
 {logger.error("Records processed!")
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
		auditObj.setAudDataLayerName("ref_cnsmptn")
		auditObj.setAudApplicationName("job_EA_loadConsumption")
		auditObj.setAudObjectName(propertiesObject.getObjName())
		auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
				auditObj.setAudJobStatusCode("success")
				auditObj.setAudSrcRowCount(src_count)
		auditObj.setAudTgtRowCount(tgt_count)
		auditObj.setAudErrorRecords(0)
		auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
		auditObj.setFlNm("")
		auditObj.setSysBtchNr(ld_jb_nr)
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl) }

}
		val hive_prchg_inf_rec_hdr_itm = {pir_hddr_itm}
		//Maximum timestamp of purchase information record header table
    val maxtgttimestamp1 = "'"+spark.sql(f"""select coalesce(max(ins_gmt_ts),'1900-01-01 00:00:01.000') as txn_timestamp from ${dbNameConsmtn}.${hive_prchg_inf_rec_hdr_itm} """).collect().map(_.getString(0)).mkString("")+"'"
		 
		println("**************************" + hive_prchg_inf_rec_hdr_itm + "*******************************")
		
/********** Loading Purchase Info Record Header Item Dimension*********************/
		val edm_prchg_inf_rec_hdr_df  = spark.sql(s"""select
crc32(lower(trim(concat(coalesce(pir.prchg_inf_rec_dmnsn_ky,""),coalesce(pird.prchg_inf_rec_dtl_dmnsn_ky,""))))),
pir.prchg_inf_rec_dmnsn_ky,
pir.prchg_inf_rec_prch_inf_rec_id_ky,
pir.prchg_inf_rec_mtrl_id_ky,
pird.prchg_inf_rec_dtl_dmnsn_ky,
pir.prchg_inf_rec_prch_inf_rec_id,
pir.prchg_inf_rec_src_sys_cd,
pir.prchg_inf_rec_mtrl_id,
pir.prchg_inf_rec_vndr_prty_id,
pir.prchg_inf_rec_Numerator_cnvrsn_nr,
pir.prchg_inf_rec_dnmntr_cnvrsn_nr,
pir.prchg_inf_rec_vndr_mtrl_id,
pir.prchg_inf_rec_sls_pers_nm,
pir.vndr_tel_nr,
pir.frst_Reminder_dys_dt,
pir.scnd_Reminder_dys_dt,
pir.thrd_Reminder_dys_dt,
pir.vndr_Subrange_cd,
pir.avl_frm_dt,
pir.avl_Until_dt,
pir.mfrr_nm,
pir.prchg_inf_rec_1_txt_cd,
pir.prchg_inf_rec_2_txt_cd,
pir.prchg_inf_rec_3_txt_cd,
pir.prchg_inf_rec_4_txt_cd,
pir.prchg_inf_rec_5_txt_cd,
pir.prchg_inf_rec_src_sys_crt_ts_cd,
pir.prchg_inf_rec_ins_ts_cd,
pir.prchg_inf_rec_upd_ts_dt,
pir.prchg_inf_rec_lgcl_dlt_ind_cd,
pir.prchg_inf_rec_crtd_by_usr_id,
pird.prch_inf_rec_dtl_src_sys_cd,
pird.prch_inf_rec_dtl_prch_inf_rec_id,
pird.prch_inf_rec_dtl_prch_org_cd,
pird.prchg_inf_rec_cgy_cd,
pird.prch_inf_rec_dtl_plnt_cd,
pird.prch_inf_rec_dtl_curr_cd,
pird.mnm_qty_cd,
pird.std_qty_cd,
pird.dlvry_plnd_dys_dt,
pird.prch_inf_rec_dtl_nt_prc_amt_cd,
pird.prch_inf_rec_dtl_unt_prc_amt_cd,
pird.prch_inf_rec_dtl_ord_prc_unt_msr_cd,
pird.prch_inf_rec_dtl_Numerator_cnvrsn_nr,
pird.prch_inf_rec_dtl_dnmntr_cnvrsn_nr,
pird.prch_inf_rec_dtl_inv_vrfctn_ind_cd,
pird.eff_prc_amt_cd,
pird.prch_inf_rec_dtl_vndr_cndn_grp_cd,
pird.prch_inf_rec_dtl_ord_ackgmt_ind_cd,
pird.prch_tx_cd,
pird.prch_inf_rec_dtl_shpg_inst_cd,
pird.prch_inf_rec_dtl_cfrn_ctrl_cd,
pird.prc_dtrmn_cd,
pird.prch_inf_rec_dtl_Incoterm_prt_1_cd,
pird.prch_inf_rec_dtl_Incoterm_prt_2_cd,
pird.evltn_stlmnt_ind_cd,
pird.prch_inf_rec_dtl_src_sys_crt_ts_cd,
pird.prch_inf_rec_dtl_prchg_grp_cd,
pird.prch_inf_rec_dtl_ins_ts_cd,
pird.prch_inf_rec_dtl_upd_ts_dt,
pird.prch_inf_rec_dtl_lgcl_dlt_ind_cd,
pird.Mn_rm_shlf  ,
pird.Prd_Ind_shlf,
pir.intgtn_fbrc_msg_id,   
pir.src_sys_upd_ts,        
pir.src_sys_ky,            
pir.lgcl_dlt_ind,          
pir.ins_gmt_ts,           
pir.upd_gmt_ts,           
pir.src_sys_extrc_gmt_ts, 
pir.src_sys_btch_nr,    
pir.fl_nm,              
pir.ld_jb_nr,
current_timestamp,
pir.ins_gmt_dt
from ${dbNameConsmtn}.edm_prchg_inf_rec_dmnsn pir left join ${dbNameConsmtn}.edm_prch_inf_rec_dtl_dmnsn pird
on pir.prchg_inf_rec_prch_inf_rec_id=pird.prch_inf_rec_dtl_prch_inf_rec_id and pird.prch_inf_rec_dtl_plnt_cd is not null where pir.ins_gmt_ts >  $maxtgttimestamp1 """).persist(StorageLevel.MEMORY_AND_DISK_SER) 

 
edm_prchg_inf_rec_hdr_df.persist(StorageLevel.MEMORY_ONLY_SER)
edm_prchg_inf_rec_hdr_df.count()
edm_prchg_inf_rec_hdr_df.createOrReplaceTempView("edm_prchg_inf_rec_hdr_df")	

//purchase information record header dimension increment logic
val existingcnsmpDF1 = spark.sql(f"""select * from ${dbNameConsmtn}.${hive_prchg_inf_rec_hdr_itm}""")

 if(existingcnsmpDF1.count>0)
      {
val overWritePrtition1 = existingcnsmpDF1.join(edm_prchg_inf_rec_hdr_df, existingcnsmpDF1("prchg_inf_rec_prch_inf_rec_id")===edm_prchg_inf_rec_hdr_df("prchg_inf_rec_prch_inf_rec_id") &&     existingcnsmpDF1("prchg_inf_rec_mtrl_id")===edm_prchg_inf_rec_hdr_df("prchg_inf_rec_mtrl_id")   &&  existingcnsmpDF1("prch_inf_rec_dtl_prch_org_cd")===edm_prchg_inf_rec_hdr_df("prch_inf_rec_dtl_prch_org_cd")  &&   existingcnsmpDF1("prchg_inf_rec_cgy_cd")===edm_prchg_inf_rec_hdr_df("prchg_inf_rec_cgy_cd")).select(existingcnsmpDF1("ins_gmt_dt").cast(StringType)).distinct.collect.map(row => row.getString(0).toString()).toSeq

val edm_prch_ord_dmnsn_nonmatch1 = existingcnsmpDF1.where(existingcnsmpDF1("ins_gmt_dt").isin(overWritePrtition1: _*)).join(edm_prchg_inf_rec_hdr_df,(existingcnsmpDF1("prchg_inf_rec_prch_inf_rec_id")===edm_prchg_inf_rec_hdr_df("prchg_inf_rec_prch_inf_rec_id") && existingcnsmpDF1("prchg_inf_rec_mtrl_id")===edm_prchg_inf_rec_hdr_df("prchg_inf_rec_mtrl_id")   &&  existingcnsmpDF1("prch_inf_rec_dtl_prch_org_cd")===edm_prchg_inf_rec_hdr_df("prch_inf_rec_dtl_prch_org_cd")),"left_anti").drop(edm_prchg_inf_rec_hdr_df("prchg_inf_rec_prch_inf_rec_id"))

val edm_prchg_inf_rec_hdr_df_final = edm_prchg_inf_rec_hdr_df.unionAll(edm_prch_ord_dmnsn_nonmatch1)

 edm_prchg_inf_rec_hdr_df_final.coalesce(20).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + hive_prchg_inf_rec_hdr_itm)
logger.info("==================== edm_prchg_inf_rec_hdr_df header load Complete =======================")
 //Total no of records in edm_prchg_inf_rec_hdr_df table
  tgt_count1 = edm_prchg_inf_rec_hdr_df_final.count().toInt
  //************************Completion Audit Entries*******************************//
if (tgt_count1 <=0)
 {
     logger.error("No records to process !")
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
		auditObj.setAudDataLayerName("ref_cnsmptn")
		auditObj.setAudApplicationName("job_EA_loadConsumption")
		auditObj.setAudObjectName(propertiesObject.getObjName())
		auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
				auditObj.setAudJobStatusCode("success")
				auditObj.setAudSrcRowCount(src_count1)
		auditObj.setAudTgtRowCount(tgt_count1)
		auditObj.setAudErrorRecords(0)
		auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
		auditObj.setFlNm("")
		auditObj.setSysBtchNr(ld_jb_nr)
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl) 
   
 } else 
 {logger.error("Incremental records processed!")
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
		auditObj.setAudDataLayerName("ref_cnsmptn")
		auditObj.setAudApplicationName("job_EA_loadConsumption")
		auditObj.setAudObjectName(propertiesObject.getObjName())
		auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
				auditObj.setAudJobStatusCode("success")
				auditObj.setAudSrcRowCount(src_count1)
		auditObj.setAudTgtRowCount(tgt_count1)
		auditObj.setAudErrorRecords(0)
		auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
		auditObj.setFlNm("")
		auditObj.setSysBtchNr(ld_jb_nr)
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl) }
      }
 		else
{
  
  edm_prchg_inf_rec_hdr_df.coalesce(20).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + hive_prchg_inf_rec_hdr_itm)
logger.info("==================== edm_prchg_inf_rec_hdr_df header load Complete =======================")
  tgt_count1 = edm_prchg_inf_rec_hdr_df.count().toInt
  //************************Completion Audit Entries*******************************//
if (tgt_count1 <=0)
 {
     logger.error("No records to process !")
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
		auditObj.setAudDataLayerName("ref_cnsmptn")
		auditObj.setAudApplicationName("job_EA_loadConsumption")
		auditObj.setAudObjectName(propertiesObject.getObjName())
		auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
				auditObj.setAudJobStatusCode("success")
				auditObj.setAudSrcRowCount(src_count1)
		auditObj.setAudTgtRowCount(tgt_count1)
		auditObj.setAudErrorRecords(0)
		auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
		auditObj.setFlNm("")
		auditObj.setSysBtchNr(ld_jb_nr)
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl) 
   
 } else 
 {logger.error("Incremental records processed!")
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
		auditObj.setAudDataLayerName("ref_cnsmptn")
		auditObj.setAudApplicationName("job_EA_loadConsumption")
		auditObj.setAudObjectName(propertiesObject.getObjName())
		auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
				auditObj.setAudJobStatusCode("success")
				auditObj.setAudSrcRowCount(src_count1)
		auditObj.setAudTgtRowCount(tgt_count1)
		auditObj.setAudErrorRecords(0)
		auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
		auditObj.setFlNm("")
		auditObj.setSysBtchNr(ld_jb_nr)
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl) }
  
  
 }}
 catch {

    case sslException: InterruptedException => {
		logger.error("Interrupted Exception")
		auditObj.setAudJobStatusCode("failed")
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
			logger.error("Interrupted Exception")
		auditObj1.setAudJobStatusCode("failed")
		auditObj1.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj1.setAudJobDuration((((format.parse(auditObj1.getAudJobEndTimestamp()).getTime - format.parse(auditObj1.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj1, auditTbl)
		jobStatusFlag = false
		sqlCon.close()
		System.exit(1)
    }
    case nseException: NoSuchElementException => {
		logger.error("No Such element found: " + nseException.printStackTrace())
		auditObj.setAudJobStatusCode("failed")
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
		logger.error("No Such element found: " + nseException.printStackTrace())
		auditObj1.setAudJobStatusCode("failed")
		auditObj1.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj1.setAudJobDuration((((format.parse(auditObj1.getAudJobEndTimestamp()).getTime - format.parse(auditObj1.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj1, auditTbl)
		jobStatusFlag = false
		sqlCon.close()
		System.exit(1)
    }
    case anaException: AnalysisException => {
		logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
		auditObj.setAudJobStatusCode("failed")
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
		logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
		auditObj1.setAudJobStatusCode("failed")
		auditObj1.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj1.setAudJobDuration((((format.parse(auditObj1.getAudJobEndTimestamp()).getTime - format.parse(auditObj1.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj1, auditTbl)
		jobStatusFlag = false
		sqlCon.close()
		System.exit(1)
    }
    case connException: ConnectException => {
		logger.error("Connection Exception: " + connException.printStackTrace())
		auditObj.setAudJobStatusCode("failed")
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
		logger.error("Connection Exception: " + connException.printStackTrace())
		auditObj1.setAudJobStatusCode("failed")
		auditObj1.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj1.setAudJobDuration((((format.parse(auditObj1.getAudJobEndTimestamp()).getTime - format.parse(auditObj1.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj1, auditTbl)
		jobStatusFlag = false
		sqlCon.close()
		System.exit(1)
    }
 case ex: Exception => {
		logger.error("Exception: " + ex.printStackTrace())
		auditObj.setAudJobStatusCode("failed")
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
		logger.error("Exception: " + ex.printStackTrace())
		auditObj1.setAudJobStatusCode("failed")
		auditObj1.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
		auditObj1.setAudJobDuration((((format.parse(auditObj1.getAudJobEndTimestamp()).getTime - format.parse(auditObj1.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj1, auditTbl)
		jobStatusFlag = false
		sqlCon.close()
		System.exit(1)
    } 
  }
   finally{
		sqlCon.close()
		spark.close()
		logger.error("jobStatusFlag:"+jobStatusFlag)
    
	}
}

package com.hpe.batch.driver.facts.demand_supply_planning

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.functions.current_date
import org.apache.spark.sql.functions.lit

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object HybridProductLocationShipFromLocationSourceFact extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

  var src_count: Long = 0
  var tgt_count: Long = 0
  var loadStatus = true

  try {
    //****************************Fact Code****************************************//

    import java.util.Calendar
    import java.text.SimpleDateFormat
    val now = Calendar.getInstance.getTime
    val dowInt = new SimpleDateFormat("u")
    import org.apache.spark.sql.{ DataFrame, SparkSession }

    val hybrid_tchnl_wk_comp_srcid_all_rgn_da_df = spark.sql("""select
ky_fgr_dt
,prod_id
,lctn_id
,shipfrom_loc_id
,src_id
,prdn_sply_cd
from """ + dbNameConsmtn + """.hybrid_tchnl_wk_comp_srcid_ams_da_dmnsn
UNION ALL
select
ky_fgr_dt
,prod_id
,lctn_id
,shipfrom_loc_id
,src_id
,prdn_sply_cd
from """ + dbNameConsmtn + """.hybrid_tchnl_wk_comp_srcid_apj_da_dmnsn
union all
select
ky_fgr_dt
,prod_id
,lctn_id
,shipfrom_loc_id
,src_id
,prdn_sply_cd
from """ + dbNameConsmtn + """.hybrid_tchnl_wk_comp_srcid_emea_da_dmnsn""")

    hybrid_tchnl_wk_comp_srcid_all_rgn_da_df.repartition(22).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + ".hybrid_tchnl_wk_comp_srcid_all_rgn_da_dmnsn")
    logger.info("Table hybrid_tchnl_wk_comp_srcid_all_rgn_da_dmnsn is refreshed")

    val hybrid_tchnl_wk_comp_srcid_all_rgn_wk_df = spark.sql("""select
ky_fgr_dt
,prod_id
,lctn_id
,shipfrom_loc_id
,src_id
,cmpnnt_coefficient_inbnd_cd
from """ + dbNameConsmtn + """.hybrid_tchnl_wk_comp_srcid_ams_wk_dmnsn
UNION ALL
select
ky_fgr_dt
,prod_id
,lctn_id
,shipfrom_loc_id
,src_id
,cmpnnt_coefficient_inbnd_cd
from """ + dbNameConsmtn + """.hybrid_tchnl_wk_comp_srcid_apj_wk_dmnsn
union all
select
ky_fgr_dt
,prod_id
,lctn_id
,shipfrom_loc_id
,src_id
,cmpnnt_coefficient_inbnd_cd
from """ + dbNameConsmtn + """.hybrid_tchnl_wk_comp_srcid_emea_wk_dmnsn""")

    hybrid_tchnl_wk_comp_srcid_all_rgn_wk_df.repartition(22).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + ".hybrid_tchnl_wk_comp_srcid_all_rgn_wk_dmnsn")
    logger.info("Table hybrid_tchnl_wk_comp_srcid_all_rgn_wk_dmnsn is refreshed")

    val hybrid_tchnl_wk_comp_srcid_all_rgn_jn_df = spark.sql(s"""select
CASE WHEN b.ky_fgr_dt is not NULL then b.ky_fgr_dt 
else a.ky_fgr_dt end as ky_fgr_dt
,CASE WHEN b.prod_id is not NULL then b.prod_id 
else a.prod_id end as prod_id
,CASE WHEN b.lctn_id is not NULL then b.lctn_id 
else a.lctn_id end as lctn_id
,CASE WHEN b.shipfrom_loc_id is not NULL then b.shipfrom_loc_id 
else a.shipfrom_loc_id end as shipfrom_loc_id
,CASE WHEN b.src_id is not NULL then b.src_id 
else a.src_id end as src_id
,coalesce(prdn_sply_cd,0L) as prdn_sply_cd
,coalesce(cmpnnt_coefficient_inbnd_cd,0L) as cmpnnt_coefficient_inbnd_cd
from $dbNameConsmtn.hybrid_tchnl_wk_comp_srcid_all_rgn_da_dmnsn  A
FULL JOIN $dbNameConsmtn.hybrid_tchnl_wk_comp_srcid_all_rgn_wk_dmnsn B 
on A.prod_id=B.prod_id
and A.lctn_id=B.lctn_id
and A.shipfrom_loc_id =B.shipfrom_loc_id
and A.src_id=B.src_id
and A.ky_fgr_dt=B.ky_fgr_dt""")

    hybrid_tchnl_wk_comp_srcid_all_rgn_jn_df.repartition(22).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + ".hybrid_tchnl_wk_comp_srcid_all_rgn_jn_dmnsn")
    logger.info("Table hybrid_tchnl_wk_comp_srcid_all_rgn_jn_dmnsn is refreshed")

    val sdf = new SimpleDateFormat("yyyy-MM-dd")

    def deletePartitions(tbl_name: String = s"${dbNameConsmtn}.${consmptnTable}", snapshot_type: String) {

      val limits = Map("daily" -> 1, "weekly" -> 182, "monthly" -> 365)

      def daysAgo(days: Int): String = {
        val calender = Calendar.getInstance()
        calender.add(Calendar.DAY_OF_YEAR, -days)
        sdf.format(calender.getTime())
      }

      val all_partitions = spark.sql(s"show partitions ${tbl_name}").collect().map(_.getString(0))
      case class partitions(snpsht_typ: String, snpsht_dt: String)
      val partition_list = all_partitions.map(x => x.split("/").map(_.split("=")(1)).toList).map(x => partitions(x(0), x(1))).toList

      val filter_date = daysAgo(limits(snapshot_type))
      val drop_partition_filter = partition_list.filter(x => x.snpsht_typ == snapshot_type.toUpperCase()).filter(x => x.snpsht_dt <= filter_date)
      val drop_partition_list = drop_partition_filter.map(_.snpsht_dt)

      drop_partition_list.foreach(perPartition => {
        spark.sql(s"ALTER TABLE ${tbl_name} DROP PARTITION(snpsht_typ='${snapshot_type.toUpperCase()}',snpsht_dt='${perPartition}')")
        logger.info(s"PARTITION DROPPED with snapshot type = $snapshot_type, snapshot_date = $perPartition")
      })

      // MSCK repair throw exception if repair fails
      val tbl_repair_stts = try {
        spark.sql(s"msck repair table $tbl_name")
        logger.info("Table repair successful")
        true
      } catch {
        case e: Exception =>
          logger.info("Table repair failed. Terminating job: " + e.printStackTrace())
          false
      }

      if (!tbl_repair_stts) throw new Exception("Table repair failed.")

    }

    val bmt_monthly_snapshot = broadcast(spark.sql("""select monthly_snapshot_dt from """ + dbNameConsmtn + """.bmt_hybrid_mthly_snpsht_dmnsn where monthly_snapshot_dt = current_date"""))

    val hybrid_techincal_selectExpr_list = List(
      "crc32(upper(trim(CONCAT(coalesce(cast(ky_fgr_dt as string),''),coalesce(prod_id,''),coalesce(lctn_id,''),coalesce(shipfrom_loc_id,''),coalesce(src_id,''),coalesce(CAST(CURRENT_DATE as string),''))))) as hybrid_it_prod_lctn_shpfrmlctn_src_fact_ky",
      "date(ky_fgr_dt) as ky_fgr_dt",
      "prod_id",
      "lctn_id",
      "shipfrom_loc_id",
      "src_id",
      "coalesce(prdn_sply_cd,0L) as prdn_sply_cd",
      "coalesce(cmpnnt_coefficient_inbnd_cd,0L) as cmpnnt_coefficient_inbnd_cd",
      "current_timestamp as ins_ts",
      "Case when date_format(current_date, 'u') = '7' then 'WEEKLY' else 'DAILY' END AS snpsht_typ",
      "CURRENT_DATE as snpsht_dt")

    val hybrid_techincal = spark.table(s"${dbNameConsmtn}.hybrid_tchnl_wk_comp_srcid_all_rgn_jn_dmnsn").withColumn("snpsht_dt", current_date())
    val column_list = spark.table(s"${dbNameConsmtn}.${consmptnTable}").columns

    // basically if its not monthly neither weekly run. i.e daily run delete old daily partitions file .and then delete old weekly and monthly partitions
    val final_df = if (bmt_monthly_snapshot.count().toInt != 0) {
      deletePartitions(snapshot_type = "weekly")
      deletePartitions(snapshot_type = "monthly")
      hybrid_techincal.selectExpr(hybrid_techincal_selectExpr_list: _*).withColumn("snpsht_typ", lit("MONTHLY")).selectExpr(column_list: _*)
    } else if (dowInt.format(now) == "7") {
      deletePartitions(snapshot_type = "weekly")
      deletePartitions(snapshot_type = "monthly")
      hybrid_techincal.selectExpr(hybrid_techincal_selectExpr_list: _*).selectExpr(column_list: _*)
    } else {
      deletePartitions(snapshot_type = "daily")
      deletePartitions(snapshot_type = "weekly")
      deletePartitions(snapshot_type = "monthly")
      hybrid_techincal.selectExpr(hybrid_techincal_selectExpr_list: _*).selectExpr(column_list: _*)
    }

    //************************Completion Audit Entries*******************************//

    loadStatus = try {
      // spark.sql(s"msck repair table ${dbNameConsmtn}.${consmptnTable}")
      final_df.repartition(30).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)
      src_count = spark.table(s"${dbNameConsmtn}.hybrid_tchnl_wk_comp_srcid_all_rgn_wk_dmnsn").count.toLong
      tgt_count = spark.table(s"${dbNameConsmtn}.hybrid_tchnl_wk_comp_srcid_all_rgn_jn_dmnsn").count.toLong
      true

    } catch {
      case e: Exception =>
        logger.info("ERROR: " + e.printStackTrace())
        false
    }

    logger.info(s"Table $consmptnTable is refreshed with status $loadStatus")

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case e: Exception => {
      logger.error("Generic Exception: " + e.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } finally {
    sqlCon.close()
    spark.close()
    // if (!runstatus) System.exit(1)
  }
}
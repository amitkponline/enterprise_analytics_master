package com.hpe.batch.driver.facts.mtrl_mvmt_inventory

import java.net.ConnectException
import java.text.SimpleDateFormat
import java.util.Calendar

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.functions.col
import org.apache.spark.storage.StorageLevel

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object MaterialMovementInventorySnapshotFactAPJ extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  var auditBatchId = ld_jb_nr + "_" + "19000101000000"
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val numPartitions = propertiesObject.getNumPartitions().trim().toInt
  val dailyLimit = propertiesObject.getDaysLimit().toInt
  val weeklyLimit = propertiesObject.getWeeklyDaysLimit().toInt
  val monthlyLimit = propertiesObject.getMonthlyDaysLimit().toInt
  val bufferDays = propertiesObject.getBufferDays().toInt
  var src_count = 0
  var tgt_count = 0
  var loadStatus = true
  val srcTblConsmtn = propertiesObject.getSrcTblConsmtn()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn()
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (tgtTblConsmtn.trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = tgtTblConsmtn.trim().split("\\.", -1)(0)
    consmptnTable = tgtTblConsmtn.trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  var snpshtFlag = propertiesObject.getCtrl_doc_num().toInt
  logger.info("Snapshot Flag : " + snpshtFlag)
  if (snpshtFlag < 0) {
    logger.error("+++++++++++############# Invalid Snapshot Flag #############+++++++++++")
    spark.close()
    System.exit(1)
  }
  val sdf = new SimpleDateFormat("yyyy-MM-dd")
  def daysAgo(days: Int): String = {
    val calender = Calendar.getInstance()
    calender.add(Calendar.DAY_OF_YEAR, -days)
    sdf.format(calender.getTime())
  }
  var invyJoinDF = spark.emptyDataFrame

  //************************Set Audit Entries*******************************//

  auditObj.setAudBatchId(auditBatchId)
  auditObj.setAudDataLayerName("fact_load")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(objName)
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(src_count)
  auditObj.setAudTgtRowCount(tgt_count)

  try {

    //****************Dropping Older Partitions in Fact table*****************//

    for (i <- dailyLimit to dailyLimit + bufferDays) {
      var dateDaily = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + tgtTblConsmtn + " DROP IF EXISTS PARTITION(snpsht_typ='D',snpsht_ins_ts='" + dateDaily + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for dropping Daily partitions")
        }
      }
    }

    for (i <- weeklyLimit to weeklyLimit + bufferDays) {
      var dateWeekly = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + tgtTblConsmtn + " DROP IF EXISTS PARTITION(snpsht_typ='W',snpsht_ins_ts='" + dateWeekly + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for dropping Weekly partitions")
        }
      }
    }

    for (i <- monthlyLimit to monthlyLimit + bufferDays) {
      var dateMonthly = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + tgtTblConsmtn + " DROP IF EXISTS PARTITION(snpsht_typ='M',snpsht_ins_ts='" + dateMonthly + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for dropping Monthly partitions")
        }
      }
    }

    //*******************set source count and batch id*********************//

    var transformeSrcCountdDF = spark.sql("""select count(*) from """ + dbNameConsmtn + """.mtrl_mvmt_invy_normalised_ref 
      where ins_gmt_dt='""" + daysAgo(1) + """'""")

    logger.info("""select count(*) from """ + dbNameConsmtn + """.mtrl_mvmt_invy_normalised_ref where ins_gmt_dt='""" + daysAgo(1) + """'""")

    src_count = transformeSrcCountdDF.first.getLong(0).toInt
    auditObj.setAudSrcRowCount(src_count)

    logger.info("********* Source Count: " + src_count + " ***********")

    var dmnsn_max_btch_id = Utilities.readMaxCnsmptnBatchId(sqlCon, "mtrl_mvmt_invy_normalised", auditTbl)
    auditObj.setAudBatchId(dmnsn_max_btch_id)

    logger.info("Max batch id of mtrl_mvmt_invy_dmnsn table " + dmnsn_max_btch_id.toString())

    //******************fact load start*************************//

    val transformeSrcdDF = spark.sql("""select ins_gmt_ts from """ + srcTblConsmtn)

    if (!transformeSrcdDF.head(1).isEmpty) {

      do {

        var pdmDF = spark.sql("""select mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd,mtrl_valtn_std_prc_amt as mtrl_valtn_std_prc_amt 
        from """ + dbNameConsmtn + """.pdm_mtrl_valtn_grp_dmnsn""")

        logger.info("""select mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd,mtrl_valtn_std_prc_amt as mtrl_valtn_std_prc_amt 
        from """ + dbNameConsmtn + """.pdm_mtrl_valtn_grp_dmnsn""")

        var invyDF = spark.sql("""select * from  (select
invy.mtrl_mvmt_invy_ky 
,invy.mtrl_storg_lctn_mtrl_id
,invy.mtrl_storg_lctn_plnt_cd
,invy.mtrl_storg_lctn_mtrl_storg_lctn_cd
,invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,invy.mtrl_storg_lctn_trnsfr_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_qty_cd
,invy.mtrl_storg_lctn_rstd_btch_qty_cd
,invy.mtrl_storg_lctn_blckd_qty_cd
,invy.mtrl_storg_lctn_blckd_rtn_qty_cd
,invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_stk_vl_amt_cd
,invy.mtrl_storg_lctn_stk_trnsfr_amt_cd
,invy.vndr_spcl_stk_mtrl_id
,invy.vndr_spcl_stk_plnt_cd
,invy.vndr_spcl_stk_mtrl_storg_lctn_cd
,invy.vndr_spcl_stk_spcl_stk_cd
,invy.vndr_spcl_stk_vndr_prty_id
,invy.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_blckd_Consigment_qty_cd
,invy.sls_ord_stk_src_sys_cd
,invy.sls_ord_stk_mtrl_id
,invy.sls_ord_stk_plnt_cd
,invy.sls_ord_stk_mtrl_storg_lctn_cd
,invy.sls_ord_stk_spcl_stk_cd
,invy.sls_ord_stk_sls_ord_id
,invy.sls_ord_stk_sls_ord_itm_nr
,invy.sls_ord_stk_Valuated_Unrestricted_qty_cd
,invy.sls_ord_stk_qlty_inspn_qty_cd
,invy.sls_ord_stk_blck_qty_cd
,invy.totl_vndr_spcl_stk_mtrl_id
,invy.totl_vndr_spcl_stk_plnt_cd
,invy.totl_vndr_spcl_stk_spcl_stk_cd
,invy.totl_vndr_spcl_stk_vndr_prty_id
,invy.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd
,invy.totl_vndr_spcl_stk_totl_rstd_qty_cd
,invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,invy.mtrl_storg_lctn_last_pstd_dt
,invy.vndr_spcl_stk_mnm_ord_qty_cd
,invy.vndr_spcl_stk_rplnshmt_qty_cd
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd	
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd	
,invy.mtrl_mvmt_bs_unt_msr_cd	
,invy.mtrl_mvmt_qty_cd	
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd	
,invy.mtrl_mvmt_etry_unt_msr_cd	
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd	
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_mtrl_dcmt_id	
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,row_number() over (partition by mtrl_mvmt_mtrl_id,mtrl_mvmt_plnt_cd,mtrl_mvmt_storg_lctn_cd order by mtrl_mvmt_ins_ts_cd desc,mtrl_mvmt_upd_ts_dt desc) as rn
from (select 
mtrl_mvmt_invy_ky 
,mtrl_storg_lctn_mtrl_id
,mtrl_storg_lctn_plnt_cd
,mtrl_storg_lctn_mtrl_storg_lctn_cd
,mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,mtrl_storg_lctn_trnsfr_qty_cd
,mtrl_storg_lctn_qlty_inspn_qty_cd
,mtrl_storg_lctn_rstd_btch_qty_cd
,mtrl_storg_lctn_blckd_qty_cd
,mtrl_storg_lctn_blckd_rtn_qty_cd
,mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_stk_vl_amt_cd
,mtrl_storg_lctn_stk_trnsfr_amt_cd
,vndr_spcl_stk_mtrl_id
,vndr_spcl_stk_plnt_cd
,vndr_spcl_stk_mtrl_storg_lctn_cd
,vndr_spcl_stk_spcl_stk_cd
,vndr_spcl_stk_vndr_prty_id
,vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,vndr_spcl_stk_blckd_Consigment_qty_cd
,sls_ord_stk_src_sys_cd
,sls_ord_stk_mtrl_id
,sls_ord_stk_plnt_cd
,sls_ord_stk_mtrl_storg_lctn_cd
,sls_ord_stk_spcl_stk_cd
,sls_ord_stk_sls_ord_id
,sls_ord_stk_sls_ord_itm_nr
,sls_ord_stk_Valuated_Unrestricted_qty_cd
,sls_ord_stk_qlty_inspn_qty_cd
,sls_ord_stk_blck_qty_cd
,totl_vndr_spcl_stk_mtrl_id
,totl_vndr_spcl_stk_plnt_cd
,totl_vndr_spcl_stk_spcl_stk_cd
,totl_vndr_spcl_stk_vndr_prty_id
,totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,totl_vndr_spcl_stk_qlty_inspn_qty_cd
,totl_vndr_spcl_stk_totl_rstd_qty_cd
,totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,mtrl_storg_lctn_last_pstd_dt
,vndr_spcl_stk_mnm_ord_qty_cd
,vndr_spcl_stk_rplnshmt_qty_cd
,mtrl_mvmt_plnt_cd
,mtrl_mvmt_curr_cd
,mtrl_mvmt_lcl_curr_amt_cd
,mtrl_mvmt_lcl_curr_dlvry_amt_cd	
,mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd	
,mtrl_mvmt_bs_unt_msr_cd	
,mtrl_mvmt_qty_cd	
,mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,mtrl_mvmt_stk_qty_cd
,mtrl_mvmt_cnsmpn_qty_cd	
,mtrl_mvmt_etry_unt_msr_cd	
,mtrl_mvmt_rcvd_qty_cd
,mtrl_mvmt_ord_prc_unt_msr_cd
,mtrl_mvmt_prch_ord_prc_unt_qty_cd
,mtrl_mvmt_prch_ord_unt_msr_cd
,mtrl_mvmt_gd_rcpt_qty_cd	
,mtrl_mvmt_dcmt_pstg_dt
,mtrl_mvmt_dcmt_iss_dt
,mtrl_mvmt_mtrl_dcmt_id	
,mtrl_mvmt_mtrl_dcmt_yr_nr
,mtrl_mvmt_mtrl_dcmt_itm_nr
,mtrl_mvmt_xtrn_dcmt_id
,mtrl_mvmt_rvrsl_mvmt_typ_cd
,mtrl_mvmt_mvmt_typ_cd
,mtrl_mvmt_mtrl_id
,mtrl_mvmt_storg_lctn_cd
,mtrl_mvmt_valtn_typ_cd
,mtrl_mvmt_stk_typ_cd
,mtrl_mvmt_vndr_prty_id
,mtrl_mvmt_cust_prty_id
,mtrl_mvmt_itm_txt_cd
,mtrl_mvmt_shp_to_prty_id
,mtrl_mvmt_mvmt_cd
,mtrl_mvmt_rcpt_cd
,mtrl_mvmt_dcmt_typ_cd
,mtrl_mvmt_storg_bn_id
,mtrl_mvmt_ins_ts_cd
,mtrl_mvmt_upd_ts_dt
from """ + srcTblConsmtn + """
union all
select 
mtrl_mvmt_invy_hstl_ky 
,mtrl_storg_lctn_mtrl_id
,mtrl_storg_lctn_plnt_cd
,mtrl_storg_lctn_mtrl_storg_lctn_cd
,mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,mtrl_storg_lctn_trnsfr_qty_cd
,mtrl_storg_lctn_qlty_inspn_qty_cd
,mtrl_storg_lctn_rstd_btch_qty_cd
,mtrl_storg_lctn_blckd_qty_cd
,mtrl_storg_lctn_blckd_rtn_qty_cd
,mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_stk_vl_amt_cd
,mtrl_storg_lctn_stk_trnsfr_amt_cd
,vndr_spcl_stk_mtrl_id
,vndr_spcl_stk_plnt_cd
,vndr_spcl_stk_mtrl_storg_lctn_cd
,vndr_spcl_stk_spcl_stk_cd
,vndr_spcl_stk_vndr_prty_id
,vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,vndr_spcl_stk_blckd_Consigment_qty_cd
,NULL as sls_ord_stk_src_sys_cd
,sls_ord_stk_mtrl_id
,sls_ord_stk_plnt_cd
,sls_ord_stk_mtrl_storg_lctn_cd
,sls_ord_stk_spcl_stk_cd
,sls_ord_stk_sls_ord_id
,sls_ord_stk_sls_ord_itm_nr
,sls_ord_stk_Valuated_Unrestricted_qty_cd
,sls_ord_stk_qlty_inspn_qty_cd
,sls_ord_stk_blck_qty_cd
,totl_vndr_spcl_stk_mtrl_id
,totl_vndr_spcl_stk_plnt_cd
,totl_vndr_spcl_stk_spcl_stk_cd
,totl_vndr_spcl_stk_vndr_prty_id
,totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,totl_vndr_spcl_stk_qlty_inspn_qty_cd
,totl_vndr_spcl_stk_totl_rstd_qty_cd
,totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,mtrl_storg_lctn_last_pstd_dt
,vndr_spcl_stk_mnm_ord_qty_cd
,vndr_spcl_stk_rplnshmt_qty_cd
,mtrl_storg_lctn_plnt_cd as mtrl_mvmt_plnt_cd
,mtrl_mvmt_curr_cd
,mtrl_mvmt_lcl_curr_amt_cd
,mtrl_mvmt_lcl_curr_dlvry_amt_cd	
,mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd	
,mtrl_mvmt_bs_unt_msr_cd	
,mtrl_mvmt_qty_cd	
,mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,mtrl_mvmt_stk_qty_cd
,mtrl_mvmt_cnsmpn_qty_cd	
,mtrl_mvmt_etry_unt_msr_cd	
,mtrl_mvmt_rcvd_qty_cd
,mtrl_mvmt_ord_prc_unt_msr_cd
,mtrl_mvmt_prch_ord_prc_unt_qty_cd
,mtrl_mvmt_prch_ord_unt_msr_cd
,mtrl_mvmt_gd_rcpt_qty_cd	
,mtrl_mvmt_dcmt_pstg_dt
,mtrl_mvmt_dcmt_iss_dt
,mtrl_mvmt_mtrl_dcmt_id	
,mtrl_mvmt_mtrl_dcmt_yr_nr
,mtrl_mvmt_mtrl_dcmt_itm_nr
,mtrl_mvmt_xtrn_dcmt_id
,mtrl_mvmt_rvrsl_mvmt_typ_cd
,mtrl_mvmt_mvmt_typ_cd
,mtrl_storg_lctn_mtrl_id as mtrl_mvmt_mtrl_id
,mtrl_storg_lctn_mtrl_storg_lctn_cd as mtrl_mvmt_storg_lctn_cd
,if(trim(mtrl_mvmt_valtn_typ_cd)='', NULL, mtrl_mvmt_valtn_typ_cd) as mtrl_mvmt_valtn_typ_cd
,mtrl_mvmt_stk_typ_cd
,mtrl_mvmt_vndr_prty_id
,mtrl_mvmt_cust_prty_id
,mtrl_mvmt_itm_txt_cd
,mtrl_mvmt_shp_to_prty_id
,mtrl_mvmt_mvmt_cd
,mtrl_mvmt_rcpt_cd
,mtrl_mvmt_dcmt_typ_cd
,mtrl_mvmt_storg_bn_id
,CASE WHEN mtrl_mvmt_src_upd_ts is NULL then CAST("1900-01-01 00:00:00" as timestamp) ELSE mtrl_mvmt_src_upd_ts END as mtrl_mvmt_ins_ts_cd
,NULL as mtrl_mvmt_upd_ts_dt
from """ + dbNameConsmtn + """.mtrl_mvmt_invy_hstl_dmnsn)  invy
where invy.mtrl_mvmt_mtrl_id is not NULL and (mtrl_mvmt_ins_ts_cd < from_unixtime(unix_timestamp(Date_sub(current_date,""" + snpshtFlag + """),'yyyy-MM-dd'),
  "yyyy-MM-dd 01:00:00") or mtrl_mvmt_ins_ts_cd is NULL))A where  rn=1""")

        logger.info("""select * from  (select
invy.mtrl_mvmt_invy_ky 
,invy.mtrl_storg_lctn_mtrl_id
,invy.mtrl_storg_lctn_plnt_cd
,invy.mtrl_storg_lctn_mtrl_storg_lctn_cd
,invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,invy.mtrl_storg_lctn_trnsfr_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_qty_cd
,invy.mtrl_storg_lctn_rstd_btch_qty_cd
,invy.mtrl_storg_lctn_blckd_qty_cd
,invy.mtrl_storg_lctn_blckd_rtn_qty_cd
,invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_stk_vl_amt_cd
,invy.mtrl_storg_lctn_stk_trnsfr_amt_cd
,invy.vndr_spcl_stk_mtrl_id
,invy.vndr_spcl_stk_plnt_cd
,invy.vndr_spcl_stk_mtrl_storg_lctn_cd
,invy.vndr_spcl_stk_spcl_stk_cd
,invy.vndr_spcl_stk_vndr_prty_id
,invy.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_blckd_Consigment_qty_cd
,invy.sls_ord_stk_src_sys_cd
,invy.sls_ord_stk_mtrl_id
,invy.sls_ord_stk_plnt_cd
,invy.sls_ord_stk_mtrl_storg_lctn_cd
,invy.sls_ord_stk_spcl_stk_cd
,invy.sls_ord_stk_sls_ord_id
,invy.sls_ord_stk_sls_ord_itm_nr
,invy.sls_ord_stk_Valuated_Unrestricted_qty_cd
,invy.sls_ord_stk_qlty_inspn_qty_cd
,invy.sls_ord_stk_blck_qty_cd
,invy.totl_vndr_spcl_stk_mtrl_id
,invy.totl_vndr_spcl_stk_plnt_cd
,invy.totl_vndr_spcl_stk_spcl_stk_cd
,invy.totl_vndr_spcl_stk_vndr_prty_id
,invy.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd
,invy.totl_vndr_spcl_stk_totl_rstd_qty_cd
,invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,invy.mtrl_storg_lctn_last_pstd_dt
,invy.vndr_spcl_stk_mnm_ord_qty_cd
,invy.vndr_spcl_stk_rplnshmt_qty_cd
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd	
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd	
,invy.mtrl_mvmt_bs_unt_msr_cd	
,invy.mtrl_mvmt_qty_cd	
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd	
,invy.mtrl_mvmt_etry_unt_msr_cd	
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd	
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_mtrl_dcmt_id	
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,row_number() over (partition by mtrl_mvmt_mtrl_id,mtrl_mvmt_plnt_cd,mtrl_mvmt_storg_lctn_cd order by mtrl_mvmt_ins_ts_cd desc,mtrl_mvmt_upd_ts_dt desc) as rn
from (select 
mtrl_mvmt_invy_ky 
,mtrl_storg_lctn_mtrl_id
,mtrl_storg_lctn_plnt_cd
,mtrl_storg_lctn_mtrl_storg_lctn_cd
,mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,mtrl_storg_lctn_trnsfr_qty_cd
,mtrl_storg_lctn_qlty_inspn_qty_cd
,mtrl_storg_lctn_rstd_btch_qty_cd
,mtrl_storg_lctn_blckd_qty_cd
,mtrl_storg_lctn_blckd_rtn_qty_cd
,mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_stk_vl_amt_cd
,mtrl_storg_lctn_stk_trnsfr_amt_cd
,vndr_spcl_stk_mtrl_id
,vndr_spcl_stk_plnt_cd
,vndr_spcl_stk_mtrl_storg_lctn_cd
,vndr_spcl_stk_spcl_stk_cd
,vndr_spcl_stk_vndr_prty_id
,vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,vndr_spcl_stk_blckd_Consigment_qty_cd
,sls_ord_stk_src_sys_cd
,sls_ord_stk_mtrl_id
,sls_ord_stk_plnt_cd
,sls_ord_stk_mtrl_storg_lctn_cd
,sls_ord_stk_spcl_stk_cd
,sls_ord_stk_sls_ord_id
,sls_ord_stk_sls_ord_itm_nr
,sls_ord_stk_Valuated_Unrestricted_qty_cd
,sls_ord_stk_qlty_inspn_qty_cd
,sls_ord_stk_blck_qty_cd
,totl_vndr_spcl_stk_mtrl_id
,totl_vndr_spcl_stk_plnt_cd
,totl_vndr_spcl_stk_spcl_stk_cd
,totl_vndr_spcl_stk_vndr_prty_id
,totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,totl_vndr_spcl_stk_qlty_inspn_qty_cd
,totl_vndr_spcl_stk_totl_rstd_qty_cd
,totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,mtrl_storg_lctn_last_pstd_dt
,vndr_spcl_stk_mnm_ord_qty_cd
,vndr_spcl_stk_rplnshmt_qty_cd
,mtrl_mvmt_plnt_cd
,mtrl_mvmt_curr_cd
,mtrl_mvmt_lcl_curr_amt_cd
,mtrl_mvmt_lcl_curr_dlvry_amt_cd	
,mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd	
,mtrl_mvmt_bs_unt_msr_cd	
,mtrl_mvmt_qty_cd	
,mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,mtrl_mvmt_stk_qty_cd
,mtrl_mvmt_cnsmpn_qty_cd	
,mtrl_mvmt_etry_unt_msr_cd	
,mtrl_mvmt_rcvd_qty_cd
,mtrl_mvmt_ord_prc_unt_msr_cd
,mtrl_mvmt_prch_ord_prc_unt_qty_cd
,mtrl_mvmt_prch_ord_unt_msr_cd
,mtrl_mvmt_gd_rcpt_qty_cd	
,mtrl_mvmt_dcmt_pstg_dt
,mtrl_mvmt_dcmt_iss_dt
,mtrl_mvmt_mtrl_dcmt_id	
,mtrl_mvmt_mtrl_dcmt_yr_nr
,mtrl_mvmt_mtrl_dcmt_itm_nr
,mtrl_mvmt_xtrn_dcmt_id
,mtrl_mvmt_rvrsl_mvmt_typ_cd
,mtrl_mvmt_mvmt_typ_cd
,mtrl_mvmt_mtrl_id
,mtrl_mvmt_storg_lctn_cd
,mtrl_mvmt_valtn_typ_cd
,mtrl_mvmt_stk_typ_cd
,mtrl_mvmt_vndr_prty_id
,mtrl_mvmt_cust_prty_id
,mtrl_mvmt_itm_txt_cd
,mtrl_mvmt_shp_to_prty_id
,mtrl_mvmt_mvmt_cd
,mtrl_mvmt_rcpt_cd
,mtrl_mvmt_dcmt_typ_cd
,mtrl_mvmt_storg_bn_id
,mtrl_mvmt_ins_ts_cd
,mtrl_mvmt_upd_ts_dt
from """ + srcTblConsmtn + """
union all
select 
mtrl_mvmt_invy_hstl_ky 
,mtrl_storg_lctn_mtrl_id
,mtrl_storg_lctn_plnt_cd
,mtrl_storg_lctn_mtrl_storg_lctn_cd
,mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,mtrl_storg_lctn_trnsfr_qty_cd
,mtrl_storg_lctn_qlty_inspn_qty_cd
,mtrl_storg_lctn_rstd_btch_qty_cd
,mtrl_storg_lctn_blckd_qty_cd
,mtrl_storg_lctn_blckd_rtn_qty_cd
,mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_stk_vl_amt_cd
,mtrl_storg_lctn_stk_trnsfr_amt_cd
,vndr_spcl_stk_mtrl_id
,vndr_spcl_stk_plnt_cd
,vndr_spcl_stk_mtrl_storg_lctn_cd
,vndr_spcl_stk_spcl_stk_cd
,vndr_spcl_stk_vndr_prty_id
,vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,vndr_spcl_stk_blckd_Consigment_qty_cd
,NULL as sls_ord_stk_src_sys_cd
,sls_ord_stk_mtrl_id
,sls_ord_stk_plnt_cd
,sls_ord_stk_mtrl_storg_lctn_cd
,sls_ord_stk_spcl_stk_cd
,sls_ord_stk_sls_ord_id
,sls_ord_stk_sls_ord_itm_nr
,sls_ord_stk_Valuated_Unrestricted_qty_cd
,sls_ord_stk_qlty_inspn_qty_cd
,sls_ord_stk_blck_qty_cd
,totl_vndr_spcl_stk_mtrl_id
,totl_vndr_spcl_stk_plnt_cd
,totl_vndr_spcl_stk_spcl_stk_cd
,totl_vndr_spcl_stk_vndr_prty_id
,totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,totl_vndr_spcl_stk_qlty_inspn_qty_cd
,totl_vndr_spcl_stk_totl_rstd_qty_cd
,totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,mtrl_storg_lctn_last_pstd_dt
,vndr_spcl_stk_mnm_ord_qty_cd
,vndr_spcl_stk_rplnshmt_qty_cd
,mtrl_storg_lctn_plnt_cd as mtrl_mvmt_plnt_cd
,mtrl_mvmt_curr_cd
,mtrl_mvmt_lcl_curr_amt_cd
,mtrl_mvmt_lcl_curr_dlvry_amt_cd	
,mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd	
,mtrl_mvmt_bs_unt_msr_cd	
,mtrl_mvmt_qty_cd	
,mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,mtrl_mvmt_stk_qty_cd
,mtrl_mvmt_cnsmpn_qty_cd	
,mtrl_mvmt_etry_unt_msr_cd	
,mtrl_mvmt_rcvd_qty_cd
,mtrl_mvmt_ord_prc_unt_msr_cd
,mtrl_mvmt_prch_ord_prc_unt_qty_cd
,mtrl_mvmt_prch_ord_unt_msr_cd
,mtrl_mvmt_gd_rcpt_qty_cd	
,mtrl_mvmt_dcmt_pstg_dt
,mtrl_mvmt_dcmt_iss_dt
,mtrl_mvmt_mtrl_dcmt_id	
,mtrl_mvmt_mtrl_dcmt_yr_nr
,mtrl_mvmt_mtrl_dcmt_itm_nr
,mtrl_mvmt_xtrn_dcmt_id
,mtrl_mvmt_rvrsl_mvmt_typ_cd
,mtrl_mvmt_mvmt_typ_cd
,mtrl_storg_lctn_mtrl_id as mtrl_mvmt_mtrl_id
,mtrl_storg_lctn_mtrl_storg_lctn_cd as mtrl_mvmt_storg_lctn_cd
,if(trim(mtrl_mvmt_valtn_typ_cd)='', NULL, mtrl_mvmt_valtn_typ_cd) as mtrl_mvmt_valtn_typ_cd
,mtrl_mvmt_stk_typ_cd
,mtrl_mvmt_vndr_prty_id
,mtrl_mvmt_cust_prty_id
,mtrl_mvmt_itm_txt_cd
,mtrl_mvmt_shp_to_prty_id
,mtrl_mvmt_mvmt_cd
,mtrl_mvmt_rcpt_cd
,mtrl_mvmt_dcmt_typ_cd
,mtrl_mvmt_storg_bn_id
,CASE WHEN mtrl_mvmt_src_upd_ts is NULL then CAST("1900-01-01 00:00:00" as timestamp) ELSE mtrl_mvmt_src_upd_ts END as mtrl_mvmt_ins_ts_cd
,NULL as mtrl_mvmt_upd_ts_dt
from """ + dbNameConsmtn + """.mtrl_mvmt_invy_hstl_dmnsn)  invy
where invy.mtrl_mvmt_mtrl_id is not NULL and (mtrl_mvmt_ins_ts_cd < from_unixtime(unix_timestamp(Date_sub(current_date,""" + snpshtFlag + """),'yyyy-MM-dd'),
  "yyyy-MM-dd 01:00:00") or mtrl_mvmt_ins_ts_cd is NULL))A where  rn=1""")

        invyDF.createOrReplaceTempView("invy_table")

        var invyJoinDF = spark.sql("""select invy.*,plnt.ctry_cd,plnt.valtn_ar_cd,plnt.rgn_cd as s4_rgn_cd,plnt.plnt_mstr_nm,plnt_trckr.rgn_cd from invy_table 
          invy INNER JOIN """ + dbNameConsmtn + """.bmt_plant_tracker_dmnsn plnt_trckr ON invy.mtrl_mvmt_plnt_cd = plnt_trckr.s4_plnt_cd LEFT JOIN (select 
            distinct ctry_cd,valtn_ar_cd,rgn_cd,plnt_mstr_nm,plnt_mstr_cd from """ + dbNameConsmtn + """.plnt_mstr_dmnsn) plnt ON invy.mtrl_mvmt_plnt_cd = 
              plnt.plnt_mstr_cd where invy.mtrl_mvmt_mtrl_id is not NULL and plnt_trckr.rgn_cd like "%APJ%"""").persist(StorageLevel.MEMORY_AND_DISK_SER)

        logger.info("""select invy.*,plnt.ctry_cd,plnt.valtn_ar_cd,plnt.rgn_cd as s4_rgn_cd,plnt.plnt_mstr_nm,plnt_trckr.rgn_cd from invy_table 
          invy INNER JOIN """ + dbNameConsmtn + """.bmt_plant_tracker_dmnsn plnt_trckr ON invy.mtrl_mvmt_plnt_cd = plnt_trckr.s4_plnt_cd LEFT JOIN (select 
            distinct ctry_cd,valtn_ar_cd,rgn_cd,plnt_mstr_nm,plnt_mstr_cd from """ + dbNameConsmtn + """.plnt_mstr_dmnsn) plnt ON invy.mtrl_mvmt_plnt_cd = 
              plnt.plnt_mstr_cd where invy.mtrl_mvmt_mtrl_id is not NULL and plnt_trckr.rgn_cd like "%APJ%"""")

        var pdmJoinDF = pdmDF.as("a").join(broadcast(invyJoinDF).as("b"), col("a.mtrl_valtn_mtrl_id") === col("b.mtrl_mvmt_mtrl_id")
          && col("a.mtrl_valtn_ar_cd") === col("b.valtn_ar_cd")).select("a.*")

        pdmJoinDF.createOrReplaceTempView("pdm_mtrl_valtn_grp_dmnsn_table")

        invyJoinDF.createOrReplaceTempView("invyJoin_table")

        var incrementalDF = spark.sql("""select inventory.mtrl_mvmt_invy_ky,inventory.pdm_mtrl_mstr_grp_ky,inventory.wrld_rgn_ky,inventory.cldr_rpt_ky,
          inventory.hpn_lctn_prod_ky,inventory.Bmt_qrnt_aruba_sply_chn_ky,inventory.mtrl_storg_lctn_mtrl_id,inventory.mtrl_storg_lctn_plnt_cd,
          inventory.mtrl_storg_lctn_mtrl_storg_lctn_cd,inventory.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,inventory.mtrl_storg_lctn_trnsfr_qty_cd,
          inventory.mtrl_storg_lctn_qlty_inspn_qty_cd,inventory.mtrl_storg_lctn_rstd_btch_qty_cd,inventory.mtrl_storg_lctn_blckd_qty_cd,
          inventory.mtrl_storg_lctn_blckd_rtn_qty_cd,inventory.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,
          inventory.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,inventory.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd,inventory.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,
          inventory.mtrl_storg_lctn_stk_vl_amt_cd,inventory.mtrl_storg_lctn_stk_trnsfr_amt_cd,inventory.vndr_spcl_stk_mtrl_id,inventory.vndr_spcl_stk_plnt_cd,
          inventory.vndr_spcl_stk_mtrl_storg_lctn_cd,inventory.vndr_spcl_stk_spcl_stk_cd,inventory.vndr_spcl_stk_vndr_prty_id,
          inventory.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd,inventory.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd,inventory.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd,
          inventory.vndr_spcl_stk_blckd_Consigment_qty_cd,inventory.sls_ord_stk_src_sys_cd,inventory.sls_ord_stk_mtrl_id,inventory.sls_ord_stk_plnt_cd,
          inventory.sls_ord_stk_mtrl_storg_lctn_cd,inventory.sls_ord_stk_spcl_stk_cd,inventory.sls_ord_stk_sls_ord_id,inventory.sls_ord_stk_sls_ord_itm_nr,
          inventory.sls_ord_stk_Valuated_Unrestricted_qty_cd,inventory.sls_ord_stk_qlty_inspn_qty_cd,inventory.sls_ord_stk_blck_qty_cd,
          inventory.totl_vndr_spcl_stk_mtrl_id,inventory.totl_vndr_spcl_stk_plnt_cd,inventory.totl_vndr_spcl_stk_spcl_stk_cd,
          inventory.totl_vndr_spcl_stk_vndr_prty_id,inventory.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd,inventory.totl_vndr_spcl_stk_qlty_inspn_qty_cd,
          inventory.totl_vndr_spcl_stk_totl_rstd_qty_cd,inventory.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd,inventory.mtrl_storg_lctn_last_pstd_dt,
          inventory.vndr_spcl_stk_mnm_ord_qty_cd,inventory.vndr_spcl_stk_rplnshmt_qty_cd,inventory.mtrl_mvmt_plnt_cd,inventory.mtrl_mvmt_curr_cd,
          inventory.mtrl_mvmt_lcl_curr_amt_cd,inventory.mtrl_mvmt_lcl_curr_dlvry_amt_cd,inventory.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd,
          inventory.mtrl_mvmt_bs_unt_msr_cd,inventory.mtrl_mvmt_qty_cd,inventory.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd,inventory.mtrl_mvmt_stk_qty_cd,
          inventory.mtrl_mvmt_cnsmpn_qty_cd,inventory.mtrl_mvmt_etry_unt_msr_cd,inventory.mtrl_mvmt_rcvd_qty_cd,inventory.mtrl_mvmt_ord_prc_unt_msr_cd,
          inventory.mtrl_mvmt_prch_ord_prc_unt_qty_cd,inventory.mtrl_mvmt_prch_ord_unt_msr_cd,inventory.mtrl_mvmt_gd_rcpt_qty_cd,
          inventory.mtrl_mvmt_dcmt_pstg_dt,inventory.mtrl_mvmt_dcmt_iss_dt,inventory.mtrl_mvmt_mtrl_dcmt_id,inventory.mtrl_mvmt_mtrl_dcmt_yr_nr,
          inventory.mtrl_mvmt_mtrl_dcmt_itm_nr,inventory.mtrl_mvmt_xtrn_dcmt_id,inventory.mtrl_mvmt_rvrsl_mvmt_typ_cd,inventory.mtrl_mvmt_mvmt_typ_cd,
          inventory.mtrl_mvmt_mtrl_id,inventory.mtrl_mvmt_storg_lctn_cd,inventory.mtrl_mvmt_valtn_typ_cd,inventory.mtrl_mvmt_stk_typ_cd,
          inventory.mtrl_mvmt_vndr_prty_id,inventory.mtrl_mvmt_cust_prty_id,inventory.mtrl_mvmt_itm_txt_cd,inventory.mtrl_mvmt_shp_to_prty_id,
          inventory.mtrl_mvmt_mvmt_cd,inventory.mtrl_mvmt_rcpt_cd,inventory.mtrl_mvmt_dcmt_typ_cd,inventory.mtrl_mvmt_storg_bn_id,inventory.stk_on_hnd_invy_qty,
          inventory.cnsgnmnt_frm_supplier_invy_qty,inventory.totl_invy_qty,inventory.ctry_cd,inventory.valtn_ar_cd,inventory.rgn_cd,inventory.s4_rgn_cd,
          inventory.plnt_mstr_nm,inventory.ind_cd,inventory.snpsht_nr,inventory.rfrnc_dt
,mbew.mtrl_valtn_std_prc_amt
,(COALESCE(inventory.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L)+COALESCE(inventory.mtrl_storg_lctn_blckd_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_qlty_inspn_qty_cd,0L)) *  COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as hpe_dllr_vl_exstng_invy_qty
,(COALESCE(inventory.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L)+COALESCE(inventory.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L)) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as cnsgmnt_dllr_vl_exstng_invy_qty
,(COALESCE(inventory.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L)+COALESCE(inventory.mtrl_storg_lctn_blckd_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_qlty_inspn_qty_cd,0L)+COALESCE(inventory.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L)) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as totl_vl_exstng_invy_qty
,mbew.mtrl_valtn_std_prc_amt as entrprs_std_cst
,COALESCE(stk_on_hnd_invy_qty,0L) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as totl_on_hnd_amt
,COALESCE(mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as totl_avl_amt
,current_timestamp()
,md5(UPPER(concat(COALESCE(mtrl_mvmt_mtrl_id,""),COALESCE(mtrl_mvmt_plnt_cd,""),COALESCE(mtrl_mvmt_storg_lctn_cd,""),
COALESCE(cast(current_timestamp() as string),"")))) as mtrl_mvmt_invy_snpsht_ky
,inventory.snpsht_typ
,inventory.snpsht_ins_ts
from (Select
invy.mtrl_mvmt_invy_ky 
,md5(UPPER(concat(COALESCE(trim(invy.mtrl_mvmt_mtrl_id),"")))) as pdm_mtrl_mstr_grp_ky
,md5(UPPER(concat(COALESCE(trim(invy.s4_rgn_cd),"")))) as wrld_rgn_ky
,md5(CAST(CURRENT_DATE AS STRING)) as cldr_rpt_ky
,md5(UPPER(concat(COALESCE(trim(invy.mtrl_mvmt_storg_lctn_cd),""),COALESCE(trim(invy.mtrl_mvmt_mtrl_id),"")))) as hpn_lctn_prod_ky
,md5(UPPER(concat(COALESCE(trim(invy.mtrl_mvmt_mtrl_id),""),COALESCE(trim(invy.mtrl_mvmt_plnt_cd),"")))) as Bmt_qrnt_aruba_sply_chn_ky
,invy.mtrl_storg_lctn_mtrl_id
,invy.mtrl_storg_lctn_plnt_cd
,invy.mtrl_storg_lctn_mtrl_storg_lctn_cd
,invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,invy.mtrl_storg_lctn_trnsfr_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_qty_cd
,invy.mtrl_storg_lctn_rstd_btch_qty_cd
,invy.mtrl_storg_lctn_blckd_qty_cd
,invy.mtrl_storg_lctn_blckd_rtn_qty_cd
,invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_stk_vl_amt_cd
,invy.mtrl_storg_lctn_stk_trnsfr_amt_cd
,invy.vndr_spcl_stk_mtrl_id
,invy.vndr_spcl_stk_plnt_cd
,invy.vndr_spcl_stk_mtrl_storg_lctn_cd
,invy.vndr_spcl_stk_spcl_stk_cd
,invy.vndr_spcl_stk_vndr_prty_id
,invy.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_blckd_Consigment_qty_cd
,invy.sls_ord_stk_src_sys_cd
,invy.sls_ord_stk_mtrl_id
,invy.sls_ord_stk_plnt_cd
,invy.sls_ord_stk_mtrl_storg_lctn_cd
,invy.sls_ord_stk_spcl_stk_cd
,invy.sls_ord_stk_sls_ord_id
,invy.sls_ord_stk_sls_ord_itm_nr
,invy.sls_ord_stk_Valuated_Unrestricted_qty_cd
,invy.sls_ord_stk_qlty_inspn_qty_cd
,invy.sls_ord_stk_blck_qty_cd
,invy.totl_vndr_spcl_stk_mtrl_id
,invy.totl_vndr_spcl_stk_plnt_cd
,invy.totl_vndr_spcl_stk_spcl_stk_cd
,invy.totl_vndr_spcl_stk_vndr_prty_id
,invy.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd
,invy.totl_vndr_spcl_stk_totl_rstd_qty_cd
,invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,invy.mtrl_storg_lctn_last_pstd_dt
,invy.vndr_spcl_stk_mnm_ord_qty_cd
,invy.vndr_spcl_stk_rplnshmt_qty_cd
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd	
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd	
,invy.mtrl_mvmt_bs_unt_msr_cd	
,invy.mtrl_mvmt_qty_cd	
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd	
,invy.mtrl_mvmt_etry_unt_msr_cd	
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd	
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_mtrl_dcmt_id	
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,COALESCE(invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L)+COALESCE(invy.mtrl_storg_lctn_blckd_qty_cd,0L)+
COALESCE(invy.mtrl_storg_lctn_qlty_inspn_qty_cd,0L) as stk_on_hnd_invy_qty
,COALESCE(invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L)+COALESCE(invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)+
COALESCE(invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L) as cnsgnmnt_frm_supplier_invy_qty
,COALESCE(invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) + COALESCE(invy.mtrl_storg_lctn_blckd_qty_cd,0L) + 
COALESCE(invy.mtrl_storg_lctn_qlty_inspn_qty_cd,0L) + COALESCE(invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L) + 
COALESCE(invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L) + COALESCE(invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L) as totl_invy_qty
,invy.ctry_cd
,invy.valtn_ar_cd
,invy.s4_rgn_cd
,invy.rgn_cd
,invy.plnt_mstr_nm
,"HPE owned" as ind_cd
,cast(Date_sub(current_date,""" + snpshtFlag + """) as date) as snpsht_ins_ts
,2 as snpsht_nr
,Case when last_day(cast(Date_sub(current_date,""" + snpshtFlag + """) as date)) = current_date then "MONTHLY" 
when  date_format(cast(Date_sub(current_date,""" + snpshtFlag + """) as date), 'u') = "7" then "WEEKLY" 
else "DAILY" END AS snpsht_typ
,cast(Date_sub(current_date,""" + snpshtFlag + """+1) as date) as rfrnc_dt
from invyJoin_table invy) inventory
LEFT JOIN
(select mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd,sum(mtrl_valtn_std_prc_amt) as mtrl_valtn_std_prc_amt from 
pdm_mtrl_valtn_grp_dmnsn_table group by mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd) mbew
ON
inventory.mtrl_mvmt_mtrl_id=mbew.mtrl_valtn_mtrl_id
and 
COALESCE(mtrl_mvmt_valtn_typ_cd,"#")=COALESCE(mbew.mtrl_valtn_typ_cd,"#")
and inventory.valtn_ar_cd=mbew.mtrl_valtn_ar_cd""").coalesce(numPartitions)

        logger.info("""select inventory.mtrl_mvmt_invy_ky,inventory.pdm_mtrl_mstr_grp_ky,inventory.wrld_rgn_ky,inventory.cldr_rpt_ky,
          inventory.hpn_lctn_prod_ky,inventory.Bmt_qrnt_aruba_sply_chn_ky,inventory.mtrl_storg_lctn_mtrl_id,inventory.mtrl_storg_lctn_plnt_cd,
          inventory.mtrl_storg_lctn_mtrl_storg_lctn_cd,inventory.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,inventory.mtrl_storg_lctn_trnsfr_qty_cd,
          inventory.mtrl_storg_lctn_qlty_inspn_qty_cd,inventory.mtrl_storg_lctn_rstd_btch_qty_cd,inventory.mtrl_storg_lctn_blckd_qty_cd,
          inventory.mtrl_storg_lctn_blckd_rtn_qty_cd,inventory.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,
          inventory.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,inventory.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd,inventory.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,
          inventory.mtrl_storg_lctn_stk_vl_amt_cd,inventory.mtrl_storg_lctn_stk_trnsfr_amt_cd,inventory.vndr_spcl_stk_mtrl_id,inventory.vndr_spcl_stk_plnt_cd,
          inventory.vndr_spcl_stk_mtrl_storg_lctn_cd,inventory.vndr_spcl_stk_spcl_stk_cd,inventory.vndr_spcl_stk_vndr_prty_id,
          inventory.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd,inventory.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd,inventory.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd,
          inventory.vndr_spcl_stk_blckd_Consigment_qty_cd,inventory.sls_ord_stk_src_sys_cd,inventory.sls_ord_stk_mtrl_id,inventory.sls_ord_stk_plnt_cd,
          inventory.sls_ord_stk_mtrl_storg_lctn_cd,inventory.sls_ord_stk_spcl_stk_cd,inventory.sls_ord_stk_sls_ord_id,inventory.sls_ord_stk_sls_ord_itm_nr,
          inventory.sls_ord_stk_Valuated_Unrestricted_qty_cd,inventory.sls_ord_stk_qlty_inspn_qty_cd,inventory.sls_ord_stk_blck_qty_cd,
          inventory.totl_vndr_spcl_stk_mtrl_id,inventory.totl_vndr_spcl_stk_plnt_cd,inventory.totl_vndr_spcl_stk_spcl_stk_cd,
          inventory.totl_vndr_spcl_stk_vndr_prty_id,inventory.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd,inventory.totl_vndr_spcl_stk_qlty_inspn_qty_cd,
          inventory.totl_vndr_spcl_stk_totl_rstd_qty_cd,inventory.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd,inventory.mtrl_storg_lctn_last_pstd_dt,
          inventory.vndr_spcl_stk_mnm_ord_qty_cd,inventory.vndr_spcl_stk_rplnshmt_qty_cd,inventory.mtrl_mvmt_plnt_cd,inventory.mtrl_mvmt_curr_cd,
          inventory.mtrl_mvmt_lcl_curr_amt_cd,inventory.mtrl_mvmt_lcl_curr_dlvry_amt_cd,inventory.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd,
          inventory.mtrl_mvmt_bs_unt_msr_cd,inventory.mtrl_mvmt_qty_cd,inventory.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd,inventory.mtrl_mvmt_stk_qty_cd,
          inventory.mtrl_mvmt_cnsmpn_qty_cd,inventory.mtrl_mvmt_etry_unt_msr_cd,inventory.mtrl_mvmt_rcvd_qty_cd,inventory.mtrl_mvmt_ord_prc_unt_msr_cd,
          inventory.mtrl_mvmt_prch_ord_prc_unt_qty_cd,inventory.mtrl_mvmt_prch_ord_unt_msr_cd,inventory.mtrl_mvmt_gd_rcpt_qty_cd,
          inventory.mtrl_mvmt_dcmt_pstg_dt,inventory.mtrl_mvmt_dcmt_iss_dt,inventory.mtrl_mvmt_mtrl_dcmt_id,inventory.mtrl_mvmt_mtrl_dcmt_yr_nr,
          inventory.mtrl_mvmt_mtrl_dcmt_itm_nr,inventory.mtrl_mvmt_xtrn_dcmt_id,inventory.mtrl_mvmt_rvrsl_mvmt_typ_cd,inventory.mtrl_mvmt_mvmt_typ_cd,
          inventory.mtrl_mvmt_mtrl_id,inventory.mtrl_mvmt_storg_lctn_cd,inventory.mtrl_mvmt_valtn_typ_cd,inventory.mtrl_mvmt_stk_typ_cd,
          inventory.mtrl_mvmt_vndr_prty_id,inventory.mtrl_mvmt_cust_prty_id,inventory.mtrl_mvmt_itm_txt_cd,inventory.mtrl_mvmt_shp_to_prty_id,
          inventory.mtrl_mvmt_mvmt_cd,inventory.mtrl_mvmt_rcpt_cd,inventory.mtrl_mvmt_dcmt_typ_cd,inventory.mtrl_mvmt_storg_bn_id,inventory.stk_on_hnd_invy_qty,
          inventory.cnsgnmnt_frm_supplier_invy_qty,inventory.totl_invy_qty,inventory.ctry_cd,inventory.valtn_ar_cd,inventory.rgn_cd,inventory.s4_rgn_cd,
          inventory.plnt_mstr_nm,inventory.ind_cd,inventory.snpsht_nr,inventory.rfrnc_dt
,mbew.mtrl_valtn_std_prc_amt
,(COALESCE(inventory.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L)+COALESCE(inventory.mtrl_storg_lctn_blckd_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_qlty_inspn_qty_cd,0L)) *  COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as hpe_dllr_vl_exstng_invy_qty
,(COALESCE(inventory.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L)+COALESCE(inventory.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L)) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as cnsgmnt_dllr_vl_exstng_invy_qty
,(COALESCE(inventory.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L)+COALESCE(inventory.mtrl_storg_lctn_blckd_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_qlty_inspn_qty_cd,0L)+COALESCE(inventory.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)+
COALESCE(inventory.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L)) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as totl_vl_exstng_invy_qty
,mbew.mtrl_valtn_std_prc_amt as entrprs_std_cst
,COALESCE(stk_on_hnd_invy_qty,0L) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as totl_on_hnd_amt
,COALESCE(mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as totl_avl_amt
,current_timestamp()
,md5(UPPER(concat(COALESCE(mtrl_mvmt_mtrl_id,""),COALESCE(mtrl_mvmt_plnt_cd,""),COALESCE(mtrl_mvmt_storg_lctn_cd,""),
COALESCE(cast(current_timestamp() as string),"")))) as mtrl_mvmt_invy_snpsht_ky
,inventory.snpsht_typ
,inventory.snpsht_ins_ts
from (Select
invy.mtrl_mvmt_invy_ky 
,md5(UPPER(concat(COALESCE(trim(invy.mtrl_mvmt_mtrl_id),"")))) as pdm_mtrl_mstr_grp_ky
,md5(UPPER(concat(COALESCE(trim(invy.s4_rgn_cd),"")))) as wrld_rgn_ky
,md5(CAST(CURRENT_DATE AS STRING)) as cldr_rpt_ky
,md5(UPPER(concat(COALESCE(trim(invy.mtrl_mvmt_storg_lctn_cd),""),COALESCE(trim(invy.mtrl_mvmt_mtrl_id),"")))) as hpn_lctn_prod_ky
,md5(UPPER(concat(COALESCE(trim(invy.mtrl_mvmt_mtrl_id),""),COALESCE(trim(invy.mtrl_mvmt_plnt_cd),"")))) as Bmt_qrnt_aruba_sply_chn_ky
,invy.mtrl_storg_lctn_mtrl_id
,invy.mtrl_storg_lctn_plnt_cd
,invy.mtrl_storg_lctn_mtrl_storg_lctn_cd
,invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,invy.mtrl_storg_lctn_trnsfr_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_qty_cd
,invy.mtrl_storg_lctn_rstd_btch_qty_cd
,invy.mtrl_storg_lctn_blckd_qty_cd
,invy.mtrl_storg_lctn_blckd_rtn_qty_cd
,invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_stk_vl_amt_cd
,invy.mtrl_storg_lctn_stk_trnsfr_amt_cd
,invy.vndr_spcl_stk_mtrl_id
,invy.vndr_spcl_stk_plnt_cd
,invy.vndr_spcl_stk_mtrl_storg_lctn_cd
,invy.vndr_spcl_stk_spcl_stk_cd
,invy.vndr_spcl_stk_vndr_prty_id
,invy.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_blckd_Consigment_qty_cd
,invy.sls_ord_stk_src_sys_cd
,invy.sls_ord_stk_mtrl_id
,invy.sls_ord_stk_plnt_cd
,invy.sls_ord_stk_mtrl_storg_lctn_cd
,invy.sls_ord_stk_spcl_stk_cd
,invy.sls_ord_stk_sls_ord_id
,invy.sls_ord_stk_sls_ord_itm_nr
,invy.sls_ord_stk_Valuated_Unrestricted_qty_cd
,invy.sls_ord_stk_qlty_inspn_qty_cd
,invy.sls_ord_stk_blck_qty_cd
,invy.totl_vndr_spcl_stk_mtrl_id
,invy.totl_vndr_spcl_stk_plnt_cd
,invy.totl_vndr_spcl_stk_spcl_stk_cd
,invy.totl_vndr_spcl_stk_vndr_prty_id
,invy.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd
,invy.totl_vndr_spcl_stk_totl_rstd_qty_cd
,invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,invy.mtrl_storg_lctn_last_pstd_dt
,invy.vndr_spcl_stk_mnm_ord_qty_cd
,invy.vndr_spcl_stk_rplnshmt_qty_cd
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd	
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd	
,invy.mtrl_mvmt_bs_unt_msr_cd	
,invy.mtrl_mvmt_qty_cd	
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd	
,invy.mtrl_mvmt_etry_unt_msr_cd	
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd	
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_mtrl_dcmt_id	
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,COALESCE(invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L)+COALESCE(invy.mtrl_storg_lctn_blckd_qty_cd,0L)+
COALESCE(invy.mtrl_storg_lctn_qlty_inspn_qty_cd,0L) as stk_on_hnd_invy_qty
,COALESCE(invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L)+COALESCE(invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)+
COALESCE(invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L) as cnsgnmnt_frm_supplier_invy_qty
,COALESCE(invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) + COALESCE(invy.mtrl_storg_lctn_blckd_qty_cd,0L) + 
COALESCE(invy.mtrl_storg_lctn_qlty_inspn_qty_cd,0L) + COALESCE(invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L) + 
COALESCE(invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L) + COALESCE(invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L) as totl_invy_qty
,invy.ctry_cd
,invy.valtn_ar_cd
,invy.s4_rgn_cd
,invy.rgn_cd
,invy.plnt_mstr_nm
,"HPE owned" as ind_cd
,cast(Date_sub(current_date,""" + snpshtFlag + """) as date) as snpsht_ins_ts
,2 as snpsht_nr
,Case when last_day(cast(Date_sub(current_date,""" + snpshtFlag + """) as date)) = current_date then "MONTHLY" 
when  date_format(cast(Date_sub(current_date,""" + snpshtFlag + """) as date), 'u') = "7" then "WEEKLY" 
else "DAILY" END AS snpsht_typ
,cast(Date_sub(current_date,""" + snpshtFlag + """+1) as date) as rfrnc_dt
from invyJoin_table invy) inventory
LEFT JOIN
(select mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd,sum(mtrl_valtn_std_prc_amt) as mtrl_valtn_std_prc_amt from 
pdm_mtrl_valtn_grp_dmnsn_table group by mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd) mbew
ON
inventory.mtrl_mvmt_mtrl_id=mbew.mtrl_valtn_mtrl_id
and 
COALESCE(mtrl_mvmt_valtn_typ_cd,"#")=COALESCE(mbew.mtrl_valtn_typ_cd,"#")
and inventory.valtn_ar_cd=mbew.mtrl_valtn_ar_cd""")

        incrementalDF.write.mode("append").format("ORC").insertInto(dbNameConsmtn + "." + consmptnTable)

        snpshtFlag = snpshtFlag - 1
      } while (snpshtFlag != -1)

      spark.catalog.dropTempView("pdm_mtrl_valtn_grp_dmnsn_table")
      spark.catalog.dropTempView("invy_table")
      spark.catalog.dropTempView("invyJoin_table")

      logger.info("Data has been loaded to: " + consmptnTable + " Table")

      val transformeDestdDF = spark.sql("""select count(*) from """ + dbNameConsmtn + """.""" + consmptnTable + """ 
        where snpsht_ins_ts ='""" + daysAgo(0) + """'""")

      tgt_count = transformeDestdDF.first.getLong(0).toInt

      logger.info("+++++++++++############# Target Count=" + tgt_count + " #############+++++++++++")

      //************************Completion Audit Entries*******************************//

      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudJobStatusCode("success")
    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("success")
    }
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
      toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
  } finally {
    if (loadStatus) {
      invyJoinDF.unpersist()
      sqlCon.close()
      spark.close()
    } else {
      invyJoinDF.unpersist()
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
  }
}
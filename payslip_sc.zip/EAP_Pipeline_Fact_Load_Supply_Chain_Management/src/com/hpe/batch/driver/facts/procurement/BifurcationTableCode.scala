package com.hpe.batch.driver.facts.procurement

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.functions.row_number

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObjectEnhanced
import main.scala.com.hpe.utils.Utilities

object BifurcationTableCode extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val logger = Logger.getLogger(getClass.getName)
  logger.info("propertiesFilePath" + propertiesFilePath)
  val propertiesObject: StreamingPropertiesObjectEnhanced = Utilities.getStreamingPropertiesObjectEnhanced(propertiesFilePath)
  logger.info(propertiesObject.getObjName())
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path>")
    spark.close()
    System.exit(1)
  }
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  logger.info(" propertiesObject.getMasterDataFields()" + propertiesObject.getMasterDataFields())
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var ld_jb_nr_ref = (ld_jb_nr + "_" + batchId)
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val tgtTblRef = propertiesObject.getTgtTblRef()
  val obj_tgt = propertiesObject.getTgtTblRef().trim().replace("_ref", "")
  val audittable = propertiesObject.getAuditTbl()
  auditObj.setAudObjectName(propertiesObject.getObjName())

  val hive_ref_table = propertiesObject.getHive_ref_table()
  val Keys_ref_table = propertiesObject.getKeys_ref_table()
  val filterKey = propertiesObject.getFilterKey().trim
  val numPartitions = propertiesObject.getNumPartitions().toInt
  val naturalKeys = propertiesObject.getNaturalKeys().trim

  try {

    var ref1_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, obj_tgt, auditTbl)

    logger.info("Bifurication Load of Procurement Started!!!!!!!!!!!!!")

    logger.info("Max batch id of first ref table " + ref1_max_btch_id.toString())

    //**********Procurement bifurcation logic**************************//
    var ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table.trim().split("\\.", -1)(1).replace("_ref", ""), auditTbl)

    logger.info("Max batch id of ref2 table " + ref2_max_btch_id.toString())

    var ins_gmt_date = ""

    // Birfurcatedref is running for 1st time//

    if (ref2_max_btch_id == "19001231000000") {
      ins_gmt_date = ref2_max_btch_id.substring(0, 4) + '-' + ref2_max_btch_id.substring(4, 6) + '-' + ref2_max_btch_id.substring(6, 8)
    } else {
      ins_gmt_date = ref2_max_btch_id.substring(19, 23) + '-' + ref2_max_btch_id.substring(23, 25) + '-' + ref2_max_btch_id.substring(25, 27)
    }

    var transformeSrcdDF = spark.sql("""select ins_gmt_ts from """ + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='" + ins_gmt_date + "' and ld_jb_nr > '" + ref2_max_btch_id + "' and ld_jb_nr <= '" + ref1_max_btch_id + "'")

    logger.info("""select ins_gmt_ts from """ + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='" + ins_gmt_date + "' and ld_jb_nr > '" + ref2_max_btch_id + "' and ld_jb_nr <= '" + ref1_max_btch_id + "'")

    //Source Count

    var src_count = transformeSrcdDF.count().toInt

    logger.info("Source Record Count:" + src_count)

    if (src_count != 0) {

      var hive_ref_select = spark.sql("select " + Keys_ref_table + ",'" + ref1_max_btch_id + "' as ld_jb_nr ,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='" + ins_gmt_date + "' and ld_jb_nr > '" + ref2_max_btch_id + "' and ld_jb_nr <= '" + ref1_max_btch_id + "'")

      logger.info("select " + Keys_ref_table + ",'" + ref1_max_btch_id + "' as ld_jb_nr ,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='" + ins_gmt_date + "' and ld_jb_nr > '" + ref2_max_btch_id + "' and ld_jb_nr <= '" + ref1_max_btch_id + "'")

      //************* Filter Key Logic *******************************//
      val filterKeyList = filterKey.split('|').toList
      var str = filterKeyList(0)

      if (filterKeyList.length > 1) {
        for (i <- 1 to filterKeyList.length - 1) {
          str = str + " is not null and " + filterKeyList(i)

        }
      }
      str = str + " is not null"

      logger.info("filter keys" + str)

      val naturalKeysList = naturalKeys.split(',').toList

      logger.info("Rank keys" + naturalKeys)

      hive_ref_select.createOrReplaceTempView("hiveRefSelect")

      val filter_row = spark.sql("select * from hiveRefSelect where " + str).coalesce(numPartitions)
      logger.info("filter query: " + "select * from hiveRefSelect where " + str)

      val windowSpec = Window.partitionBy(naturalKeysList.head,naturalKeysList.tail: _*).orderBy(desc("ins_gmt_ts"))

      val addRowNo = filter_row.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(numPartitions)

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table)

      var transformeTgtdDF = spark.sql("""select ins_gmt_ts from """ + hive_ref_table + " where date_sub(ins_gmt_dt,-1)>='" + ins_gmt_date + "' and ld_jb_nr > '" + ref2_max_btch_id + "' and ld_jb_nr <= '" + ref1_max_btch_id + "'")

      logger.info("""select ins_gmt_ts from """ + hive_ref_table + " where date_sub(ins_gmt_dt,-1)>='" + ins_gmt_date + "' and ld_jb_nr > '" + ref2_max_btch_id + "' and ld_jb_nr <= '" + ref1_max_btch_id + "'")

      //Target Count
      var tgt_count = transformeTgtdDF.count().toInt

      logger.info("Filtered Record Count:" + tgt_count)
      spark.catalog.dropTempView("hiveRefSelect")

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(ref1_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) { auditObj.setAudJobStatusCode("failed") } else { auditObj.setAudJobStatusCode("success") }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table)

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("************Procurement Refine Bifurication completed*************************")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
      System.exit(1)

    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
      System.exit(1)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
      System.exit(1)

    }
  } finally {
    sqlCon.close()
    spark.close()
  }
}
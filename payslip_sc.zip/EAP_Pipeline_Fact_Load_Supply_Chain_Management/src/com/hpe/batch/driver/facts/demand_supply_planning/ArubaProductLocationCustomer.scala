package com.hpe.batch.driver.facts.demand_supply_planning

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import java.util.Calendar
import java.text.SimpleDateFormat
import java.util.Calendar
import java.text.SimpleDateFormat
import org.apache.spark.sql.{DataFrame, SparkSession}

object ArubaProductLocationCustomer extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  
  try {
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val transformeSrcdDF = spark.sql("""select * from """ + propertiesObject.getSrcTblConsmtn() )

  var src_count = transformeSrcdDF.count().toInt

    //****************************Fact Code****************************************//

val now = Calendar.getInstance.getTime
val dowInt = new SimpleDateFormat("u")
var transformedTgtDF:DataFrame = null
var transformedDF:DataFrame = null

var aruba_prod_lctn_cust_all_rgn_dmnsn="aruba_prod_lctn_cust_all_rgn_dmnsn"

var transformedDF_1 = spark.sql("""select
aruba_tchnl_wk_prod_lctn_cust_ams_ky as aruba_prod_lctn_cust_all_rgn_ky
,prod_id
,lctn_id
,cust_id
,prd_id
,keyfigure_dt
,totl_ord_actuals_rsd_cd
,lctn_splt_consensus_dmnd_pln_cd
,totl_shp_actl_pgi_cd
,bsln_dmnd_frcst_stat_cd
,dmnd_frcst_ovr_1_id
,idpt_ord_actuals_rsd_cd
,dpndt_ord_actuals_rsd_cd
,shp_actuals_qty_cd
,totl_ord_actuals_rsd_mnl_adjmt_cd
,totl_crctd_ord_actuals_rsd_cd
,opn_ord_qty_cd
,chnl_invy_cd
,chnl_sl_through_cd
,cust_frcst_cd
,ststcl_frcst_usr_dfnd_cd
,ststcl_frcst_btch_cd
,consensus_dp_ovrd_id
,src_sys_upd_ts
,src_sys_ky
,lgcl_dlt_ind
,ins_gmt_ts
,upd_gmt_ts
,src_sys_extrc_gmt_ts
,src_sys_btch_nr
,fl_nm
,ld_jb_nr
,ins_ts
from """+ dbNameConsmtn + """.aruba_tchnl_wk_prod_lctn_cust_ams_dmnsn
UNION ALL
Select 
aruba_tchnl_wk_prod_lctn_cust_apj_ky as aruba_prod_lctn_cust_all_rgn_ky
,prod_id
,lctn_id
,cust_id
,prd_id
,keyfigure_dt
,totl_ord_actuals_rsd_cd
,lctn_splt_consensus_dmnd_pln_cd
,totl_shp_actl_pgi_cd
,bsln_dmnd_frcst_stat_cd
,dmnd_frcst_ovr_1_id
,idpt_ord_actuals_rsd_cd
,dpndt_ord_actuals_rsd_cd
,shp_actuals_qty_cd
,totl_ord_actuals_rsd_mnl_adjmt_cd
,totl_crctd_ord_actuals_rsd_cd
,opn_ord_qty_cd
,chnl_invy_cd
,chnl_sl_through_cd
,cust_frcst_cd
,ststcl_frcst_usr_dfnd_cd
,ststcl_frcst_btch_cd
,consensus_dp_ovrd_id
,src_sys_upd_ts
,src_sys_ky
,lgcl_dlt_ind
,ins_gmt_ts
,upd_gmt_ts
,src_sys_extrc_gmt_ts
,src_sys_btch_nr
,fl_nm
,ld_jb_nr
,ins_ts
from """+ dbNameConsmtn + """.aruba_tchnl_wk_prod_lctn_cust_apj_dmnsn
UNION ALL
Select
aruba_tchnl_wk_prod_lctn_cust_emea_ky as aruba_prod_lctn_cust_all_rgn_ky
,prod_id
,lctn_id
,cust_id
,prd_id
,keyfigure_dt
,totl_ord_actuals_rsd_cd
,lctn_splt_consensus_dmnd_pln_cd
,totl_shp_actl_pgi_cd
,bsln_dmnd_frcst_stat_cd
,dmnd_frcst_ovr_1_id
,idpt_ord_actuals_rsd_cd
,dpndt_ord_actuals_rsd_cd
,shp_actuals_qty_cd
,totl_ord_actuals_rsd_mnl_adjmt_cd
,totl_crctd_ord_actuals_rsd_cd
,opn_ord_qty_cd
,chnl_invy_cd
,chnl_sl_through_cd
,cust_frcst_cd
,ststcl_frcst_usr_dfnd_cd
,ststcl_frcst_btch_cd
,consensus_dp_ovrd_id
,src_sys_upd_ts
,src_sys_ky
,lgcl_dlt_ind
,ins_gmt_ts
,upd_gmt_ts
,src_sys_extrc_gmt_ts
,src_sys_btch_nr
,fl_nm
,ld_jb_nr
,ins_ts
from """+ dbNameConsmtn + """.aruba_tchnl_wk_prod_lctn_cust_emea_dmnsn""")

var loadStatus = Utilities.storeDataFrame(transformedDF_1, "overwrite", "ORC", dbNameConsmtn + "." + aruba_prod_lctn_cust_all_rgn_dmnsn)


var aruba_twk_prod_lctn_cust_fnl_dmnsn="aruba_twk_prod_lctn_cust_fnl_dmnsn"

var transformedDF_2 = spark.sql("""select
prod_id
,lctn_id
,cust_id
,keyfigure_dt
,month(keyfigure_dt) as keyfigure_mnth
,year(keyfigure_dt) as keyfigure_yr
,CASE WHEN month(keyfigure_dt) in ("11","12") then year(keyfigure_dt)+1 else year(keyfigure_dt) end as fiscal_yr
,CASE WHEN month(keyfigure_dt) in ("11","12","1") THEN "Q1" 
WHEN month(keyfigure_dt) in ("2","3","4") THEN "Q2"
WHEN month(keyfigure_dt) in ("5","6","7") THEN "Q3"
ELSE "Q4" END AS qtr 
,totl_ord_actuals_rsd_cd
,lctn_splt_consensus_dmnd_pln_cd
,totl_shp_actl_pgi_cd
,bsln_dmnd_frcst_stat_cd
,dmnd_frcst_ovr_1_id
,idpt_ord_actuals_rsd_cd
,dpndt_ord_actuals_rsd_cd
,shp_actuals_qty_cd
,totl_ord_actuals_rsd_mnl_adjmt_cd
,totl_crctd_ord_actuals_rsd_cd
,opn_ord_qty_cd
,chnl_invy_cd
,chnl_sl_through_cd
,cust_frcst_cd
,ststcl_frcst_usr_dfnd_cd
,ststcl_frcst_btch_cd
,consensus_dp_ovrd_id
,cfrd_cust_sply_cd
,customer_idpt_ord_Actuals_RSD_cd
,dpndt_cust_dmnd_cd
,sls_ord_qty_idpt_cd
,sls_ord_bcklo_1_cd
,sls_ord_bcklo_2_cd
,frcst_por_mthly_cd
,frcst_por_quarterly_cd
,sls_ord_pgi_cd
,sm_pgi_qty_cd
,sm_qty_cd
,vrtl_theater_cd
,dmnd_typ_cd
,bs_prod_cd
,prod_cgy_p_2_cd
,prod_cgy_Desc_cd
from (Select
CASE WHEN t1.prod_id is not NULL then t1.prod_id 
WHEN t2.customer_prod_id is not NULL then t2.customer_prod_id
else t3.prod_id end as prod_id
,CASE WHEN t1.lctn_id is not NULL then t1.lctn_id 
WHEN t2.customer_lctn_id is not NULL then t2.customer_lctn_id
else t3.lctn_id end as lctn_id
,CASE WHEN t1.cust_id is not NULL then t1.cust_id 
WHEN t2.customer_cust_id is not NULL then t2.customer_cust_id
else t3.cust_id end as cust_id
,CASE WHEN t1.keyfigure_dt is not NULL then t1.keyfigure_dt 
WHEN t2.customer_keyfigure_dt is not NULL then t2.customer_keyfigure_dt
else t3.ky_fgr_dt end as keyfigure_dt
,CASE WHEN t1.totl_ord_actuals_rsd_cd is not NULL then t1.totl_ord_actuals_rsd_cd
else COALESCE(t3.totl_ord_actuals_cd,0L) end as totl_ord_actuals_rsd_cd
,COALESCE(t1.lctn_splt_consensus_dmnd_pln_cd,0L) as lctn_splt_consensus_dmnd_pln_cd
,COALESCE(t1.totl_shp_actl_pgi_cd,0L) as totl_shp_actl_pgi_cd
,COALESCE(t1.bsln_dmnd_frcst_stat_cd,0L) as bsln_dmnd_frcst_stat_cd
,COALESCE(t1.dmnd_frcst_ovr_1_id,0L) as dmnd_frcst_ovr_1_id
,COALESCE(t1.idpt_ord_actuals_rsd_cd,0L) as idpt_ord_actuals_rsd_cd
,COALESCE(t1.dpndt_ord_actuals_rsd_cd,0L) as dpndt_ord_actuals_rsd_cd
,COALESCE(t1.shp_actuals_qty_cd,0L) as shp_actuals_qty_cd
,COALESCE(t1.totl_ord_actuals_rsd_mnl_adjmt_cd,0L) as totl_ord_actuals_rsd_mnl_adjmt_cd
,COALESCE(t1.totl_crctd_ord_actuals_rsd_cd,0L) as totl_crctd_ord_actuals_rsd_cd
,COALESCE(t1.opn_ord_qty_cd,0L) as opn_ord_qty_cd
,COALESCE(t1.chnl_invy_cd,0L) as chnl_invy_cd
,COALESCE(t1.chnl_sl_through_cd,0L) as chnl_sl_through_cd
,COALESCE(t1.cust_frcst_cd,0L) as cust_frcst_cd
,COALESCE(t1.ststcl_frcst_usr_dfnd_cd,0L) as ststcl_frcst_usr_dfnd_cd
,COALESCE(t1.ststcl_frcst_btch_cd,0L) as ststcl_frcst_btch_cd
,COALESCE(t1.consensus_dp_ovrd_id,0L) as consensus_dp_ovrd_id
,COALESCE(t2.cfrd_cust_sply_cd,0L) as cfrd_cust_sply_cd
,COALESCE(t2.customer_idpt_ord_Actuals_RSD_cd,0L) as customer_idpt_ord_Actuals_RSD_cd
,COALESCE(t3.dpndt_cust_dmnd_cd,0L) as dpndt_cust_dmnd_cd
,COALESCE(t3.sls_ord_qty_idpt_cd,0L) as sls_ord_qty_idpt_cd
,COALESCE(t3.sls_ord_bcklo_1_cd,0L) as sls_ord_bcklo_1_cd
,COALESCE(t3.sls_ord_bcklo_2_cd,0L) as sls_ord_bcklo_2_cd
,COALESCE(t3.frcst_por_mthly_cd,0L) as frcst_por_mthly_cd
,COALESCE(t3.frcst_por_quarterly_cd,0L) as frcst_por_quarterly_cd
,COALESCE(t3.sls_ord_pgi_cd,0L) as sls_ord_pgi_cd
,COALESCE(t3.sm_pgi_qty_cd,0L) as sm_pgi_qty_cd
,COALESCE(t3.sm_qty_cd,0L) as sm_qty_cd
,t4.vrtl_theater_cd
,t4.dmnd_typ_cd
,t5.bs_prod_cd
,t5.prod_cgy_p_2_cd
,t5.prod_cgy_Desc_cd
from
"""+dbNameConsmtn + "." + aruba_prod_lctn_cust_all_rgn_dmnsn+""" t1
FULL OUTER JOIN
"""+dbNameConsmtn +""".aruba_tchnl_wk_prod_lctn_cust_dmnsn t2
ON
t1.prod_id = t2.customer_prod_id and t1.lctn_id = t2.customer_lctn_id and t1.cust_id = t2.customer_cust_id and 
t1.keyfigure_dt = t2.customer_keyfigure_dt
FULL OUTER JOIN
"""+dbNameConsmtn +""".aruba_tchnl_wk_prod_lctn_cust_da_dmnsn t3
ON
t1.prod_id = t3.prod_id 
and t1.lctn_id = t3.lctn_id 
and t1.cust_id = t3.cust_id and 
t1.keyfigure_dt = t3.ky_fgr_dt
left join
"""+dbNameConsmtn +""".hpn_prod_dmnsn t5
on
t1.prod_id=t5.prod_id
left join
"""+dbNameConsmtn +""".hpn_cust_dmnsn t4
on
t1.cust_id=t4.cust_id) A""")

loadStatus = Utilities.storeDataFrame(transformedDF_2, "overwrite", "ORC", dbNameConsmtn + "." + aruba_twk_prod_lctn_cust_fnl_dmnsn)


var aruba_twk_prod_lctn_cust_mnthly_dmnsn="aruba_twk_prod_lctn_cust_mnthly_dmnsn"

var transformedDF_3 = spark.sql("""select
prod_id
,lctn_id
,cust_id
,keyfigure_mnth
,keyfigure_yr
,fiscal_yr  
,qtr 
,sum(COALESCE(totl_ord_actuals_rsd_cd,0L)) as totl_ord_actuals_rsd_cd_mnthly
,sum(COALESCE(lctn_splt_consensus_dmnd_pln_cd,0L)) as lctn_splt_consensus_dmnd_pln_cd_mnthly
,sum(COALESCE(totl_shp_actl_pgi_cd,0L)) as totl_shp_actl_pgi_cd_mnthly
,sum(COALESCE(bsln_dmnd_frcst_stat_cd,0L)) as bsln_dmnd_frcst_stat_cd_mnthly
,sum(COALESCE(dmnd_frcst_ovr_1_id,0L)) as dmnd_frcst_ovr_1_id_mnthly
,sum(COALESCE(idpt_ord_actuals_rsd_cd,0L)) as idpt_ord_actuals_rsd_cd_mnthly
,sum(COALESCE(dpndt_ord_actuals_rsd_cd,0L)) as dpndt_ord_actuals_rsd_cd_mnthly
,sum(COALESCE(shp_actuals_qty_cd,0L)) as shp_actuals_qty_cd_mnthly
,sum(COALESCE(totl_ord_actuals_rsd_mnl_adjmt_cd,0L)) as totl_ord_actuals_rsd_mnl_adjmt_cd_mnthly
,sum(COALESCE(totl_crctd_ord_actuals_rsd_cd,0L)) as totl_crctd_ord_actuals_rsd_cd_mnthly
,sum(COALESCE(opn_ord_qty_cd,0L)) as opn_ord_qty_cd_mnthly
,sum(COALESCE(chnl_invy_cd,0L)) as chnl_invy_cd_mnthly
,sum(COALESCE(chnl_sl_through_cd,0L)) as chnl_sl_through_cd_mnthly
,sum(COALESCE(cust_frcst_cd,0L)) as cust_frcst_cd_mnthly
,sum(COALESCE(ststcl_frcst_usr_dfnd_cd,0L)) as ststcl_frcst_usr_dfnd_cd_mnthly
,sum(COALESCE(ststcl_frcst_btch_cd,0L)) as ststcl_frcst_btch_cd_mnthly
,sum(COALESCE(consensus_dp_ovrd_id,0L)) as consensus_dp_ovrd_id_mnthly
,sum(COALESCE(cfrd_cust_sply_cd,0L)) as cfrd_cust_sply_cd_mnthly
,sum(COALESCE(customer_idpt_ord_Actuals_RSD_cd,0L)) as customer_idpt_ord_Actuals_RSD_cd_mnthly
,COALESCE(frcst_por_mthly_cd,0L) as frcst_por_mthly_cd 
,vrtl_theater_cd
,dmnd_typ_cd
,bs_prod_cd
,prod_cgy_p_2_cd
,prod_cgy_Desc_cd
from 
"""+dbNameConsmtn + """.aruba_twk_prod_lctn_cust_fnl_dmnsn
group by
prod_id
,lctn_id
,cust_id
,keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr
,COALESCE(frcst_por_mthly_cd,0L)
,vrtl_theater_cd
,dmnd_typ_cd
,bs_prod_cd
,prod_cgy_p_2_cd
,prod_cgy_Desc_cd""")

loadStatus = Utilities.storeDataFrame(transformedDF_3, "overwrite", "ORC", dbNameConsmtn + "." + aruba_twk_prod_lctn_cust_mnthly_dmnsn)


var aruba_twk_prod_lctn_cust_qtrly_dmnsn="aruba_twk_prod_lctn_cust_qtrly_dmnsn"

var transformedDF_4 = spark.sql("""select 
prod_id
,lctn_id
,cust_id
,fiscal_yr
,qtr 
,COALESCE(max(totl_ord_actuals_rsd_cd_m1),0L) as totl_ord_actuals_rsd_cd_m1
,COALESCE(max(totl_ord_actuals_rsd_cd_m2),0L) as totl_ord_actuals_rsd_cd_m2
,COALESCE(max(totl_ord_actuals_rsd_cd_m3),0L) as totl_ord_actuals_rsd_cd_m3
,COALESCE(max(lctn_splt_consensus_dmnd_pln_cd_m1),0L) as lctn_splt_consensus_dmnd_pln_cd_m1
,COALESCE(max(lctn_splt_consensus_dmnd_pln_cd_m2),0L) as lctn_splt_consensus_dmnd_pln_cd_m2
,COALESCE(max(lctn_splt_consensus_dmnd_pln_cd_m3),0L) as lctn_splt_consensus_dmnd_pln_cd_m3
,COALESCE(max(totl_shp_actl_pgi_cd_m1),0L) as totl_shp_actl_pgi_cd_m1
,COALESCE(max(totl_shp_actl_pgi_cd_m2),0L) as totl_shp_actl_pgi_cd_m2
,COALESCE(max(totl_shp_actl_pgi_cd_m3),0L) as totl_shp_actl_pgi_cd_m3
,COALESCE(max(bsln_dmnd_frcst_stat_cd_m1),0L) as bsln_dmnd_frcst_stat_cd_m1
,COALESCE(max(bsln_dmnd_frcst_stat_cd_m2),0L) as bsln_dmnd_frcst_stat_cd_m2
,COALESCE(max(bsln_dmnd_frcst_stat_cd_m3),0L) as bsln_dmnd_frcst_stat_cd_m3
,COALESCE(max(dmnd_frcst_ovr_1_id_m1),0L) as dmnd_frcst_ovr_1_id_m1
,COALESCE(max(dmnd_frcst_ovr_1_id_m2),0L) as dmnd_frcst_ovr_1_id_m2
,COALESCE(max(dmnd_frcst_ovr_1_id_m3),0L) as dmnd_frcst_ovr_1_id_m3
,COALESCE(max(ststcl_frcst_btch_cd_m1),0L) as ststcl_frcst_btch_cd_m1
,COALESCE(max(ststcl_frcst_btch_cd_m2),0L) as ststcl_frcst_btch_cd_m2
,COALESCE(max(ststcl_frcst_btch_cd_m3),0L) as ststcl_frcst_btch_cd_m3
,COALESCE(max(ststcl_frcst_usr_dfnd_cd_m1),0L) as ststcl_frcst_usr_dfnd_cd_m1
,COALESCE(max(ststcl_frcst_usr_dfnd_cd_m2),0L) as ststcl_frcst_usr_dfnd_cd_m2
,COALESCE(max(ststcl_frcst_usr_dfnd_cd_m3),0L) as ststcl_frcst_usr_dfnd_cd_m3
,COALESCE(max(consensus_dp_ovrd_id_m1),0L) as consensus_dp_ovrd_id_m1
,COALESCE(max(consensus_dp_ovrd_id_m2),0L) as consensus_dp_ovrd_id_m2
,COALESCE(max(consensus_dp_ovrd_id_m3),0L) as consensus_dp_ovrd_id_m3
,COALESCE(max(opn_ord_qty_cd_m1),0L) as opn_ord_qty_cd_m1
,COALESCE(max(opn_ord_qty_cd_m2),0L) as opn_ord_qty_cd_m2
,COALESCE(max(opn_ord_qty_cd_m3),0L) as opn_ord_qty_cd_m3
,COALESCE(max(frcst_por_mthly_cd_m1),0L) as frcst_por_mthly_cd_m1 
,COALESCE(max(frcst_por_mthly_cd_m2),0L) as frcst_por_mthly_cd_m2
,COALESCE(max(frcst_por_mthly_cd_m3),0L) as frcst_por_mthly_cd_m3
from
(select 
prod_id
,lctn_id
,cust_id
,Keyfigure_mnth
,fiscal_yr
,qtr 
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.lctn_splt_consensus_dmnd_pln_cd_map[Keyfigure_mnth]) END as lctn_splt_consensus_dmnd_pln_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.lctn_splt_consensus_dmnd_pln_cd_map[Keyfigure_mnth]) END as lctn_splt_consensus_dmnd_pln_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.lctn_splt_consensus_dmnd_pln_cd_map[Keyfigure_mnth]) END as lctn_splt_consensus_dmnd_pln_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.totl_shp_actl_pgi_cd_map[Keyfigure_mnth]) END as totl_shp_actl_pgi_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.totl_shp_actl_pgi_cd_map[Keyfigure_mnth]) END as totl_shp_actl_pgi_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.totl_shp_actl_pgi_cd_map[Keyfigure_mnth]) END as totl_shp_actl_pgi_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.bsln_dmnd_frcst_stat_cd_map[Keyfigure_mnth]) END as bsln_dmnd_frcst_stat_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.bsln_dmnd_frcst_stat_cd_map[Keyfigure_mnth]) END as bsln_dmnd_frcst_stat_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.bsln_dmnd_frcst_stat_cd_map[Keyfigure_mnth]) END as bsln_dmnd_frcst_stat_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.dmnd_frcst_ovr_1_id_map[Keyfigure_mnth]) END as dmnd_frcst_ovr_1_id_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.dmnd_frcst_ovr_1_id_map[Keyfigure_mnth]) END as dmnd_frcst_ovr_1_id_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.dmnd_frcst_ovr_1_id_map[Keyfigure_mnth]) END as dmnd_frcst_ovr_1_id_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.ststcl_frcst_btch_cd_map[Keyfigure_mnth]) END as ststcl_frcst_btch_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.ststcl_frcst_btch_cd_map[Keyfigure_mnth]) END as ststcl_frcst_btch_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.ststcl_frcst_btch_cd_map[Keyfigure_mnth]) END as ststcl_frcst_btch_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.ststcl_frcst_usr_dfnd_cd_map[Keyfigure_mnth]) END as ststcl_frcst_usr_dfnd_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.ststcl_frcst_usr_dfnd_cd_map[Keyfigure_mnth]) END as ststcl_frcst_usr_dfnd_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.ststcl_frcst_usr_dfnd_cd_map[Keyfigure_mnth]) END as ststcl_frcst_usr_dfnd_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.consensus_dp_ovrd_id_map[Keyfigure_mnth]) END as consensus_dp_ovrd_id_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.consensus_dp_ovrd_id_map[Keyfigure_mnth]) END as consensus_dp_ovrd_id_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.consensus_dp_ovrd_id_map[Keyfigure_mnth]) END as consensus_dp_ovrd_id_m3
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.opn_ord_qty_cd_map[Keyfigure_mnth]) END as opn_ord_qty_cd_m1
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.opn_ord_qty_cd_map[Keyfigure_mnth]) END as opn_ord_qty_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.opn_ord_qty_cd_map[Keyfigure_mnth]) END as opn_ord_qty_cd_m3
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.frcst_por_mthly_cd_map[Keyfigure_mnth]) END as frcst_por_mthly_cd_m1
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.frcst_por_mthly_cd_map[Keyfigure_mnth]) END as frcst_por_mthly_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.frcst_por_mthly_cd_map[Keyfigure_mnth]) END as frcst_por_mthly_cd_m3
from
( 
select 
prod_id
,lctn_id
,cust_id
,Keyfigure_mnth
,fiscal_yr
,qtr 
,map(Keyfigure_mnth,totl_ord_actuals_rsd_cd_mnthly) as totl_ord_actuals_rsd_cd_map
,map(Keyfigure_mnth,lctn_splt_consensus_dmnd_pln_cd_mnthly) as lctn_splt_consensus_dmnd_pln_cd_map
,map(Keyfigure_mnth,totl_shp_actl_pgi_cd_mnthly) as totl_shp_actl_pgi_cd_map
,map(Keyfigure_mnth,bsln_dmnd_frcst_stat_cd_mnthly) as bsln_dmnd_frcst_stat_cd_map
,map(Keyfigure_mnth,dmnd_frcst_ovr_1_id_mnthly) as dmnd_frcst_ovr_1_id_map
,map(Keyfigure_mnth,idpt_ord_actuals_rsd_cd_mnthly) as idpt_ord_actuals_rsd_cd_map
,map(Keyfigure_mnth,dpndt_ord_actuals_rsd_cd_mnthly) as dpndt_ord_actuals_rsd_cd_map
,map(Keyfigure_mnth,shp_actuals_qty_cd_mnthly) as shp_actuals_qty_cd_map
,map(Keyfigure_mnth,totl_ord_actuals_rsd_mnl_adjmt_cd_mnthly) as totl_ord_actuals_rsd_mnl_adjmt_cd_map
,map(Keyfigure_mnth,totl_crctd_ord_actuals_rsd_cd_mnthly) as totl_crctd_ord_actuals_rsd_cd_map
,map(Keyfigure_mnth,opn_ord_qty_cd_mnthly) as opn_ord_qty_cd_map
,map(Keyfigure_mnth,chnl_invy_cd_mnthly) as chnl_invy_cd_map
,map(Keyfigure_mnth,chnl_sl_through_cd_mnthly) as chnl_sl_through_cd_map
,map(Keyfigure_mnth,cust_frcst_cd_mnthly) as cust_frcst_cd_map
,map(Keyfigure_mnth,ststcl_frcst_usr_dfnd_cd_mnthly) as ststcl_frcst_usr_dfnd_cd_map
,map(Keyfigure_mnth,ststcl_frcst_btch_cd_mnthly) as ststcl_frcst_btch_cd_map
,map(Keyfigure_mnth,consensus_dp_ovrd_id_mnthly) as consensus_dp_ovrd_id_map
,map(Keyfigure_mnth,cfrd_cust_sply_cd_mnthly) as cfrd_cust_sply_cd_map
,map(Keyfigure_mnth,customer_idpt_ord_Actuals_RSD_cd_mnthly) as customer_idpt_ord_Actuals_RSD_cd_map
,map(Keyfigure_mnth,frcst_por_mthly_cd) as frcst_por_mthly_cd_map
from """+dbNameConsmtn + """.aruba_twk_prod_lctn_cust_mnthly_dmnsn) a 
group by
prod_id
,lctn_id
,cust_id
,Keyfigure_mnth
,fiscal_yr
,qtr ) b
group by
prod_id
,lctn_id
,cust_id
,fiscal_yr
,qtr""")

loadStatus = Utilities.storeDataFrame(transformedDF_4, "overwrite", "ORC", dbNameConsmtn + "." + aruba_twk_prod_lctn_cust_qtrly_dmnsn)



var aruba_twk_prod_lctn_cust_all_vlue_dmnsn="aruba_twk_prod_lctn_cust_all_vlue_dmnsn"

var transformedDF_5 = spark.sql("""select
t1.prod_id
,t1.lctn_id
,t1.cust_id
,t1.keyfigure_dt
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,t1.totl_ord_actuals_rsd_cd
,t1.lctn_splt_consensus_dmnd_pln_cd
,t1.totl_shp_actl_pgi_cd
,t1.bsln_dmnd_frcst_stat_cd
,t1.dmnd_frcst_ovr_1_id
,t1.idpt_ord_actuals_rsd_cd
,t1.dpndt_ord_actuals_rsd_cd
,t1.shp_actuals_qty_cd
,t1.totl_ord_actuals_rsd_mnl_adjmt_cd
,t1.totl_crctd_ord_actuals_rsd_cd
,t1.opn_ord_qty_cd
,t1.chnl_invy_cd
,t1.chnl_sl_through_cd
,t1.cust_frcst_cd
,t1.ststcl_frcst_usr_dfnd_cd
,t1.ststcl_frcst_btch_cd
,t1.consensus_dp_ovrd_id
,t1.cfrd_cust_sply_cd
,t1.customer_idpt_ord_Actuals_RSD_cd
,t2.totl_ord_actuals_rsd_cd_mnthly
,t2.lctn_splt_consensus_dmnd_pln_cd_mnthly
,t2.totl_shp_actl_pgi_cd_mnthly
,t2.bsln_dmnd_frcst_stat_cd_mnthly
,t2.dmnd_frcst_ovr_1_id_mnthly
,t2.idpt_ord_actuals_rsd_cd_mnthly
,t2.dpndt_ord_actuals_rsd_cd_mnthly
,t2.shp_actuals_qty_cd_mnthly
,t2.totl_ord_actuals_rsd_mnl_adjmt_cd_mnthly
,t2.totl_crctd_ord_actuals_rsd_cd_mnthly
,t2.opn_ord_qty_cd_mnthly
,t2.chnl_invy_cd_mnthly
,t2.chnl_sl_through_cd_mnthly
,t2.cust_frcst_cd_mnthly
,t2.ststcl_frcst_usr_dfnd_cd_mnthly
,t2.ststcl_frcst_btch_cd_mnthly
,t2.consensus_dp_ovrd_id_mnthly
,t2.cfrd_cust_sply_cd_mnthly
,t2.customer_idpt_ord_Actuals_RSD_cd_mnthly
,t3.totl_ord_actuals_rsd_cd_m1
,t3.totl_ord_actuals_rsd_cd_m2
,t3.totl_ord_actuals_rsd_cd_m3
,t3.lctn_splt_consensus_dmnd_pln_cd_m1
,t3.lctn_splt_consensus_dmnd_pln_cd_m2
,t3.lctn_splt_consensus_dmnd_pln_cd_m3
,t3.totl_shp_actl_pgi_cd_m1
,t3.totl_shp_actl_pgi_cd_m2
,t3.totl_shp_actl_pgi_cd_m3
,t3.bsln_dmnd_frcst_stat_cd_m1
,t3.bsln_dmnd_frcst_stat_cd_m2
,t3.bsln_dmnd_frcst_stat_cd_m3
,t3.dmnd_frcst_ovr_1_id_m1
,t3.dmnd_frcst_ovr_1_id_m2
,t3.dmnd_frcst_ovr_1_id_m3
,t3.ststcl_frcst_usr_dfnd_cd_m1
,t3.ststcl_frcst_usr_dfnd_cd_m2
,t3.ststcl_frcst_usr_dfnd_cd_m3
,t3.ststcl_frcst_btch_cd_m1
,t3.ststcl_frcst_btch_cd_m2
,t3.ststcl_frcst_btch_cd_m3
,t3.consensus_dp_ovrd_id_m1
,t3.consensus_dp_ovrd_id_m2
,t3.consensus_dp_ovrd_id_m3
,dpndt_cust_dmnd_cd
,sls_ord_qty_idpt_cd
,sls_ord_bcklo_1_cd
,sls_ord_bcklo_2_cd
,t1.frcst_por_mthly_cd
,frcst_por_quarterly_cd
,sls_ord_pgi_cd
,sm_pgi_qty_cd
,sm_qty_cd
,opn_ord_qty_cd_m1
,opn_ord_qty_cd_m2
,opn_ord_qty_cd_m3
,lag(t3.opn_ord_qty_cd_m1,1,0) over (partition by t1.prod_id,t1.lctn_id,t1.cust_id,t1.keyfigure_yr order by t1.qtr ) as lag_opn_ord_qty_cd_m1
,lag(t3.opn_ord_qty_cd_m2,1,0) over (partition by t1.prod_id,t1.lctn_id,t1.cust_id,t1.keyfigure_yr order by t1.qtr ) as lag_opn_ord_qty_cd_m2
,lag(t3.opn_ord_qty_cd_m3,1,0) over (partition by t1.prod_id,t1.lctn_id,t1.cust_id,t1.keyfigure_yr order by t1.qtr ) as lag_opn_ord_qty_cd_m3
,frcst_por_mthly_cd_m1
,frcst_por_mthly_cd_m2
,frcst_por_mthly_cd_m3
,lag(frcst_por_quarterly_cd,1,0) over (partition by t1.prod_id,t1.lctn_id,t1.cust_id,t1.keyfigure_yr order by t1.qtr ) as lag_frcst_por_quarterly_prev_cd
,t1.vrtl_Theater_cd
,t1.dmnd_typ_cd
,t1.bs_prod_cd
,t1.prod_cgy_p_2_cd
,t1.prod_cgy_Desc_cd
from
"""+dbNameConsmtn + """.aruba_twk_prod_lctn_cust_fnl_dmnsn t1
Left join
"""+dbNameConsmtn + """.aruba_twk_prod_lctn_cust_mnthly_dmnsn t2
on 
t1.prod_id = t2.prod_id
and
t1.lctn_id = t2.lctn_id
and
t1.cust_id = t2.cust_id
and 
t1.keyfigure_yr = t2.keyfigure_yr 
and 
t1.keyfigure_mnth=t2.keyfigure_mnth
LEFT join
"""+dbNameConsmtn + """.aruba_twk_prod_lctn_cust_qtrly_dmnsn t3
on 
t1.prod_id = t3.prod_id
and
t1.lctn_id = t3.lctn_id
and
t1.cust_id = t3.cust_id
and
t1.qtr=t3.qtr
and 
t1.fiscal_yr = t3.fiscal_yr""")

loadStatus = Utilities.storeDataFrame(transformedDF_5, "overwrite", "ORC", dbNameConsmtn + "." + aruba_twk_prod_lctn_cust_all_vlue_dmnsn)


var aruba_twk_prod_lctn_cust_qtrly_frcst_dmnsn="aruba_twk_prod_lctn_cust_qtrly_frcst_dmnsn"

var transformedDF_6 = spark.sql("""select 
fiscal_yr
,qtr 
,COALESCE(max(totl_ord_actuals_rsd_cd_ttl_m1),0L) as totl_ord_actuals_rsd_cd_ttl_m1
,COALESCE(max(totl_ord_actuals_rsd_cd_ttl_m2),0L) as totl_ord_actuals_rsd_cd_ttl_m2
,COALESCE(max(totl_ord_actuals_rsd_cd_ttl_m3),0L) as totl_ord_actuals_rsd_cd_ttl_m3
,COALESCE(max(dmnd_frcst_ovr_1_id_ttl_m1),0L) as dmnd_frcst_ovr_1_id_ttl_m1
,COALESCE(max(dmnd_frcst_ovr_1_id_ttl_m2),0L) as dmnd_frcst_ovr_1_id_ttl_m2
,COALESCE(max(dmnd_frcst_ovr_1_id_ttl_m3),0L) as dmnd_frcst_ovr_1_id_ttl_m3
from
(select 
Keyfigure_mnth
,fiscal_yr
,qtr 
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_ttl_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_ttl_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_ttl_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.dmnd_frcst_ovr_1_id_map[Keyfigure_mnth]) END as dmnd_frcst_ovr_1_id_ttl_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.dmnd_frcst_ovr_1_id_map[Keyfigure_mnth]) END as dmnd_frcst_ovr_1_id_ttl_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.dmnd_frcst_ovr_1_id_map[Keyfigure_mnth]) END as dmnd_frcst_ovr_1_id_ttl_m3
from
( 
select 
Keyfigure_mnth
,fiscal_yr
,qtr 
,map(Keyfigure_mnth,totl_ord_actuals_rsd_cd_ttl) as totl_ord_actuals_rsd_cd_map
,map(Keyfigure_mnth,dmnd_frcst_ovr_1_id_ttl) as dmnd_frcst_ovr_1_id_map
from (
select 
Keyfigure_mnth
,fiscal_yr
,qtr 
,sum(totl_ord_actuals_rsd_cd_mnthly) as totl_ord_actuals_rsd_cd_ttl
,sum(dmnd_frcst_ovr_1_id_mnthly) as dmnd_frcst_ovr_1_id_ttl
from """+dbNameConsmtn + """.aruba_twk_prod_lctn_cust_mnthly_dmnsn
group by
Keyfigure_mnth
,fiscal_yr
,qtr)t ) a 
group by
Keyfigure_mnth
,fiscal_yr
,qtr ) b
group by
fiscal_yr
,qtr """)

loadStatus = Utilities.storeDataFrame(transformedDF_6, "overwrite", "ORC", dbNameConsmtn + "." + aruba_twk_prod_lctn_cust_qtrly_frcst_dmnsn)

var snapshot_type= spark.sql("""select monthly_snapshot_date_dt from """+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn where monthly_snapshot_date_dt = current_date""")
    val bufferDays = 32
    val dailyLimit = 1
    val weeklyLimit = 182
    val monthlyLimit = 366
    val sdf = new SimpleDateFormat("yyyy-MM-dd")

    def daysAgo(days: Int): String = {
      val calender = Calendar.getInstance()
      calender.add(Calendar.DAY_OF_YEAR, -days)
      sdf.format(calender.getTime())
    }

// Here dataframe will hold existing data from Fact Table for monthly snapshot creation
if (snapshot_type.count().toInt!=0)
{
transformedDF = spark.sql("""select
crc32(lower(concat(COALESCE(lctn_id,""),COALESCE(prod_id,"")))) as hpn_lctn_prod_ky
,crc32(lower(concat(coalesce(cust_id,""),coalesce(lctn_id,""),coalesce(prod_id,"")))) as hpn_cust_src_ky
,crc32(upper(concat(coalesce(cust_id,""),coalesce(lctn_id,""),coalesce(prod_id,""),coalesce(cast(keyfigure_dt as string),""),coalesce(cast(current_timestamp() as string),"")))) as aruba_twk_prod_lctn_cust_fact_ky
,t1.prod_id
,t1.lctn_id
,t1.cust_id
,t1.vrtl_theater_cd
,t1.dmnd_typ_cd
,t1.bs_prod_cd
,t1.prod_cgy_p_2_cd
,t1.prod_cgy_Desc_cd
,date(t1.keyfigure_dt)
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,t1.totl_ord_actuals_rsd_cd
,t1.lctn_splt_consensus_dmnd_pln_cd
,t1.totl_shp_actl_pgi_cd
,t1.bsln_dmnd_frcst_stat_cd
,t1.dmnd_frcst_ovr_1_id
,t1.idpt_ord_actuals_rsd_cd
,t1.dpndt_ord_actuals_rsd_cd
,t1.shp_actuals_qty_cd
,t1.totl_ord_actuals_rsd_mnl_adjmt_cd
,t1.totl_crctd_ord_actuals_rsd_cd
,t1.opn_ord_qty_cd
,t1.chnl_invy_cd
,t1.chnl_sl_through_cd
,t1.cust_frcst_cd
,t1.ststcl_frcst_usr_dfnd_cd
,t1.ststcl_frcst_btch_cd
,t1.consensus_dp_ovrd_id
,t1.cfrd_cust_sply_cd
,t1.customer_idpt_ord_Actuals_RSD_cd
,t1.totl_ord_actuals_rsd_cd_mnthly
,t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
,t1.totl_shp_actl_pgi_cd_mnthly
,t1.bsln_dmnd_frcst_stat_cd_mnthly
,t1.dmnd_frcst_ovr_1_id_mnthly
,t1.idpt_ord_actuals_rsd_cd_mnthly
,t1.dpndt_ord_actuals_rsd_cd_mnthly
,t1.shp_actuals_qty_cd_mnthly
,t1.totl_ord_actuals_rsd_mnl_adjmt_cd_mnthly
,t1.totl_crctd_ord_actuals_rsd_cd_mnthly
,t1.opn_ord_qty_cd_mnthly
,t1.chnl_invy_cd_mnthly
,t1.chnl_sl_through_cd_mnthly
,t1.cust_frcst_cd_mnthly
,t1.ststcl_frcst_usr_dfnd_cd_mnthly
,t1.ststcl_frcst_btch_cd_mnthly
,t1.consensus_dp_ovrd_id_mnthly
,t1.cfrd_cust_sply_cd_mnthly
,t1.customer_idpt_ord_Actuals_RSD_cd_mnthly
,totl_ord_actuals_rsd_cd_m1
,lctn_splt_consensus_dmnd_pln_cd_m1
,totl_shp_actl_pgi_cd_m1
,bsln_dmnd_frcst_stat_cd_m1
,dmnd_frcst_ovr_1_id_m1
,ststcl_frcst_usr_dfnd_cd_m1
,ststcl_frcst_btch_cd_m1
,consensus_dp_ovrd_id_m1
,totl_ord_actuals_rsd_cd_m2
,lctn_splt_consensus_dmnd_pln_cd_m2
,totl_shp_actl_pgi_cd_m2
,bsln_dmnd_frcst_stat_cd_m2
,dmnd_frcst_ovr_1_id_m2
,ststcl_frcst_usr_dfnd_cd_m2
,ststcl_frcst_btch_cd_m2
,consensus_dp_ovrd_id_m2
,totl_ord_actuals_rsd_cd_m3
,lctn_splt_consensus_dmnd_pln_cd_m3
,totl_shp_actl_pgi_cd_m3
,bsln_dmnd_frcst_stat_cd_m3
,dmnd_frcst_ovr_1_id_m3
,ststcl_frcst_usr_dfnd_cd_m3
,ststcl_frcst_btch_cd_m3
,consensus_dp_ovrd_id_m3
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) or month(current_timestamp) in ("11","12","1") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q4") THEN  (bsln_dmnd_frcst_stat_cd_m1+bsln_dmnd_frcst_stat_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (bsln_dmnd_frcst_stat_cd_m1+bsln_dmnd_frcst_stat_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+bsln_dmnd_frcst_stat_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
END as bsln_mtrl_frcst
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) and keyfigure_mnth not in ("11","12") or month(current_timestamp) in ("11","12","1") and t1.qtr not in ("Q1") or month(current_timestamp) in ("2","3","4") and t1.qtr not in ("Q1","Q2") OR month(current_timestamp) in ("5","6","7") and t1.qtr not in ("Q1","Q2","Q3") THEN  (lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3+lctn_splt_consensus_dmnd_pln_cd_m3)
END as lctn_splt_consensus_dmnd_pln_cd_qtr
,t1.opn_ord_qty_cd_mnthly + t1.totl_shp_actl_pgi_cd_mnthly - t1.totl_ord_actuals_rsd_cd_mnthly as bcklog_cryovr_cd
,t1.bsln_dmnd_frcst_stat_cd_mnthly - t1.totl_ord_actuals_rsd_cd_mnthly as consensus_pln_to_go_cd
,t1.totl_ord_actuals_rsd_cd_mnthly/t1.bsln_dmnd_frcst_stat_cd_mnthly  as mtd_qtd_attnmnt_bsln_pln_cd
,t1.bsln_dmnd_frcst_stat_cd_mnthly/t1.totl_ord_actuals_rsd_cd_mnthly  as pln_accry_bsln_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.dmnd_frcst_ovr_1_id_mnthly END as actl_bsln_mtrl_frcst_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
WHEN keyfigure_mnth = month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) THEN t1.shp_actuals_qty_cd_mnthly + t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
ELSE t1.lctn_splt_consensus_dmnd_pln_cd_mnthly END as actl_lctn_splt_consensus_dmnd_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_usr_dfnd_cd_mnthly END as actl_ststcl_frcst_usr_dfnd_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_btch_cd_mnthly END as actl_ststcl_frcst_btch_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.bsln_dmnd_frcst_stat_cd_mnthly END as actl_bsln_dmnd_frcst_stat_cd
,t1.totl_ord_actuals_rsd_cd_mnthly/(t1.totl_ord_actuals_rsd_cd_m1+t1.totl_ord_actuals_rsd_cd_m2+t1.totl_ord_actuals_rsd_cd_m3) as lnarty_fr_qtr
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,dmnd_typ_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_dmnd_typ_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by prod_cgy_Desc_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_prod_cgy_Desc_cd
,t2.totl_ord_actuals_rsd_cd_ttl_m1
,t2.totl_ord_actuals_rsd_cd_ttl_m2
,t2.totl_ord_actuals_rsd_cd_ttl_m3
,t2.dmnd_frcst_ovr_1_id_ttl_m1
,t2.dmnd_frcst_ovr_1_id_ttl_m2
,t2.dmnd_frcst_ovr_1_id_ttl_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
else 0
END as abs_err_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) else 0 end as abs_err_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
else 0 end as abs_err_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3) else 0 end as MAPE_quartr_prcnt
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1 else 0 end as frcst_mape_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) /totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2 else 0 end as frcst_mape_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3) else 0 end as frcst_mape_prcnt_m3
,totl_ord_actuals_rsd_cd_ttl_m1-dmnd_frcst_ovr_1_id_ttl_m1/dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m1 as frcst_bias_nrmlzd_m1
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2-dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2/dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2 as frcst_bias_nrmlzd_m2
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3-dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+dmnd_frcst_ovr_1_id_ttl_m3/dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3+dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+dmnd_frcst_ovr_1_id_ttl_m3 as frcst_bias_nrmlzd_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) else 0 end as frcst_vltalty_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) else 0 end as frcst_vltalty_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3) else 0 end as frcst_vltalty_prcnt_m3
,stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3) as frcst_vltalty_prcnt_qtr
,dpndt_cust_dmnd_cd
,sls_ord_qty_idpt_cd
,sls_ord_bcklo_1_cd
,sls_ord_bcklo_2_cd
,t1.frcst_por_mthly_cd
,frcst_por_quarterly_cd
,sls_ord_pgi_cd
,sm_pgi_qty_cd
,sm_qty_cd
,opn_ord_qty_cd_m1
,opn_ord_qty_cd_m2
,opn_ord_qty_cd_m3
,COALESCE(lag_opn_ord_qty_cd_m1,0L) as lag_opn_ord_qty_cd_m1
,COALESCE(lag_opn_ord_qty_cd_m2,0L) as lag_opn_ord_qty_cd_m2
,COALESCE(lag_opn_ord_qty_cd_m3,0L) as lag_opn_ord_qty_cd_m3
,frcst_por_mthly_cd_m1
,frcst_por_mthly_cd_m2
,frcst_por_mthly_cd_m3
,lag_frcst_por_quarterly_prev_cd
,COALESCE(lag_opn_ord_qty_cd_m1,0L)+COALESCE(lag_opn_ord_qty_cd_m2,0L)+COALESCE(lag_opn_ord_qty_cd_m3,0L) as rlld_bcklg_cd
,Case when month(current_date) in ("2","5","8","11") then totl_ord_actuals_rsd_cd_m1/lag_frcst_por_quarterly_prev_cd
when month(current_date) in ("3","6","7","12") then totl_ord_actuals_rsd_cd_m2/frcst_por_mthly_cd_m1
else totl_ord_actuals_rsd_cd_m2/frcst_por_mthly_cd_m1+frcst_por_mthly_cd_m2 end as ordr_mo_forecast_cd
,totl_ord_actuals_rsd_cd/frcst_por_mthly_cd as qtrly_forecast_attainmnt_cd
,current_timestamp() as ins_ts
,0 as lag_totl_ord_actuals_rsd_cd
,0 as lag_lctn_splt_consensus_dmnd_pln_cd
,0 as wk_ovr_wk_chng_totl_ord_actuals_rsd_cd
,0 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_cd
,0 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_prcnt_cd
,Case WHEN X.monthly_snapshot_date_dt is NOT NULL then "MONTHLY" 
when date_format(current_date, 'u') = "7" then "WEEKLY" 
else "DAILY" END AS snpsht_typ
,CURRENT_DATE as snpsht_dt
from
"""+dbNameConsmtn + """.""" + aruba_twk_prod_lctn_cust_all_vlue_dmnsn + """ t1
left join
"""+dbNameConsmtn + "." +aruba_twk_prod_lctn_cust_qtrly_frcst_dmnsn +""" t2
on t1.qtr=t2.qtr and
t1.fiscal_yr=t2.fiscal_yr
LEFT join
"""+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn X
on current_date()=X.monthly_snapshot_date_dt""")

    for (i <- monthlyLimit to monthlyLimit + bufferDays) {
      var dateMonthly = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + dbNameConsmtn + "."+ consmptnTable +" DROP PARTITION(snpsht_typ='MONTHLY',snpsht_dt='" + dateMonthly + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for all possible monthly partitions")
        }
      }
    }

}
// Here dataframe will hold existing data from Fact Table for weekly snapshot creation
else if (dowInt.format(now) == "7")
{
var aruba_prdt_loc_cust_fact_cal_dmnsn="aruba_prdt_loc_cust_fact_cal_dmnsn"

var transformedDF_7 = spark.sql("""select *,
lag(totl_ord_actuals_rsd_cd,1,0) over (partition by keyfigure_dt,prod_id,lctn_id,cust_id order by snpsht_dt ) as lag_totl_ord_actuals_rsd_cd
,lag(lctn_splt_consensus_dmnd_pln_cd,1,0) over (partition by keyfigure_dt,prod_id,lctn_id,cust_id order by snpsht_dt ) as lag_lctn_splt_consensus_dmnd_pln_cd
from 
(select
,prod_id
,lctn_id
,cust_id
,keyfigure_dt
,coalesce(totl_ord_actuals_rsd_cd,0L) as totl_ord_actuals_rsd_cd
,coalesce(lctn_splt_consensus_dmnd_pln_cd,0L) as lctn_splt_consensus_dmnd_pln_cd
,current_date() as snpsht_dt
from """+ dbNameConsmtn + "." + """aruba_twk_prod_lctn_cust_all_vlue_dmnsn
union all
select
,prod_id
,lctn_id
,cust_id
,keyfigure_dt
,coalesce(totl_ord_actuals_rsd_cd,0L) as totl_ord_actuals_rsd_cd
,coalesce(lctn_splt_consensus_dmnd_pln_cd,0L) as lctn_splt_consensus_dmnd_pln_cd
,coalesce(sply_cmmt_cd,0L) as sply_cmmt_cd
,snpsht_dt
from """+ dbNameConsmtn + "." + consmptnTable + """ where snpsht_typ ='WEEKLY' and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ ='WEEKLY' order by snpsht_dt desc limit 1))A""")

loadStatus = Utilities.storeDataFrame(transformedDF_7, "overwrite", "ORC", dbNameConsmtn + "." + aruba_prdt_loc_cust_fact_cal_dmnsn)


transformedDF = spark.sql("""select
crc32(lower(concat(COALESCE(lctn_id,""),COALESCE(prod_id,"")))) as hpn_lctn_prod_ky
,crc32(lower(concat(coalesce(cust_id,""),coalesce(lctn_id,""),coalesce(prod_id,"")))) as hpn_cust_src_ky
,crc32(upper(concat(coalesce(cust_id,""),coalesce(lctn_id,""),coalesce(prod_id,""),coalesce(cast(keyfigure_dt as string),""),coalesce(cast(current_timestamp() as string),"")))) as aruba_twk_prod_lctn_cust_fact_ky
,t1.prod_id
,t1.lctn_id
,t1.cust_id
,t1.vrtl_theater_cd
,t1.dmnd_typ_cd
,t1.bs_prod_cd
,t1.prod_cgy_p_2_cd
,t1.prod_cgy_Desc_cd
,date(t1.keyfigure_dt)
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,t1.totl_ord_actuals_rsd_cd
,t1.lctn_splt_consensus_dmnd_pln_cd
,t1.totl_shp_actl_pgi_cd
,t1.bsln_dmnd_frcst_stat_cd
,t1.dmnd_frcst_ovr_1_id
,t1.idpt_ord_actuals_rsd_cd
,t1.dpndt_ord_actuals_rsd_cd
,t1.shp_actuals_qty_cd
,t1.totl_ord_actuals_rsd_mnl_adjmt_cd
,t1.totl_crctd_ord_actuals_rsd_cd
,t1.opn_ord_qty_cd
,t1.chnl_invy_cd
,t1.chnl_sl_through_cd
,t1.cust_frcst_cd
,t1.ststcl_frcst_usr_dfnd_cd
,t1.ststcl_frcst_btch_cd
,t1.consensus_dp_ovrd_id
,t1.cfrd_cust_sply_cd
,t1.customer_idpt_ord_Actuals_RSD_cd
,t1.totl_ord_actuals_rsd_cd_mnthly
,t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
,t1.totl_shp_actl_pgi_cd_mnthly
,t1.bsln_dmnd_frcst_stat_cd_mnthly
,t1.dmnd_frcst_ovr_1_id_mnthly
,t1.idpt_ord_actuals_rsd_cd_mnthly
,t1.dpndt_ord_actuals_rsd_cd_mnthly
,t1.shp_actuals_qty_cd_mnthly
,t1.totl_ord_actuals_rsd_mnl_adjmt_cd_mnthly
,t1.totl_crctd_ord_actuals_rsd_cd_mnthly
,t1.opn_ord_qty_cd_mnthly
,t1.chnl_invy_cd_mnthly
,t1.chnl_sl_through_cd_mnthly
,t1.cust_frcst_cd_mnthly
,t1.ststcl_frcst_usr_dfnd_cd_mnthly
,t1.ststcl_frcst_btch_cd_mnthly
,t1.consensus_dp_ovrd_id_mnthly
,t1.cfrd_cust_sply_cd_mnthly
,t1.customer_idpt_ord_Actuals_RSD_cd_mnthly
,totl_ord_actuals_rsd_cd_m1
,lctn_splt_consensus_dmnd_pln_cd_m1
,totl_shp_actl_pgi_cd_m1
,bsln_dmnd_frcst_stat_cd_m1
,dmnd_frcst_ovr_1_id_m1
,ststcl_frcst_usr_dfnd_cd_m1
,ststcl_frcst_btch_cd_m1
,consensus_dp_ovrd_id_m1
,totl_ord_actuals_rsd_cd_m2
,lctn_splt_consensus_dmnd_pln_cd_m2
,totl_shp_actl_pgi_cd_m2
,bsln_dmnd_frcst_stat_cd_m2
,dmnd_frcst_ovr_1_id_m2
,ststcl_frcst_usr_dfnd_cd_m2
,ststcl_frcst_btch_cd_m2
,consensus_dp_ovrd_id_m2
,totl_ord_actuals_rsd_cd_m3
,lctn_splt_consensus_dmnd_pln_cd_m3
,totl_shp_actl_pgi_cd_m3
,bsln_dmnd_frcst_stat_cd_m3
,dmnd_frcst_ovr_1_id_m3
,ststcl_frcst_usr_dfnd_cd_m3
,ststcl_frcst_btch_cd_m3
,consensus_dp_ovrd_id_m3
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) or month(current_timestamp) in ("11","12","1") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q4") THEN  (bsln_dmnd_frcst_stat_cd_m1+bsln_dmnd_frcst_stat_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (bsln_dmnd_frcst_stat_cd_m1+bsln_dmnd_frcst_stat_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+bsln_dmnd_frcst_stat_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
END as bsln_mtrl_frcst
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) and keyfigure_mnth not in ("11","12") or month(current_timestamp) in ("11","12","1") and t1.qtr not in ("Q1") or month(current_timestamp) in ("2","3","4") and t1.qtr not in ("Q1","Q2") OR month(current_timestamp) in ("5","6","7") and t1.qtr not in ("Q1","Q2","Q3") THEN  (lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3+lctn_splt_consensus_dmnd_pln_cd_m3)
END as lctn_splt_consensus_dmnd_pln_cd_qtr
,t1.opn_ord_qty_cd_mnthly + t1.totl_shp_actl_pgi_cd_mnthly - t1.totl_ord_actuals_rsd_cd_mnthly as bcklog_cryovr_cd
,t1.bsln_dmnd_frcst_stat_cd_mnthly - t1.totl_ord_actuals_rsd_cd_mnthly as consensus_pln_to_go_cd
,t1.totl_ord_actuals_rsd_cd_mnthly/t1.bsln_dmnd_frcst_stat_cd_mnthly  as mtd_qtd_attnmnt_bsln_pln_cd
,t1.bsln_dmnd_frcst_stat_cd_mnthly/t1.totl_ord_actuals_rsd_cd_mnthly  as pln_accry_bsln_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.dmnd_frcst_ovr_1_id_mnthly END as actl_bsln_mtrl_frcst_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
WHEN keyfigure_mnth = month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) THEN t1.shp_actuals_qty_cd_mnthly + t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
ELSE t1.lctn_splt_consensus_dmnd_pln_cd_mnthly END as actl_lctn_splt_consensus_dmnd_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_usr_dfnd_cd_mnthly END as actl_ststcl_frcst_usr_dfnd_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_btch_cd_mnthly END as actl_ststcl_frcst_btch_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.bsln_dmnd_frcst_stat_cd_mnthly END as actl_bsln_dmnd_frcst_stat_cd
,t1.totl_ord_actuals_rsd_cd_mnthly/(t1.totl_ord_actuals_rsd_cd_m1+t1.totl_ord_actuals_rsd_cd_m2+t1.totl_ord_actuals_rsd_cd_m3) as lnarty_fr_qtr
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,dmnd_typ_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_dmnd_typ_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by prod_cgy_Desc_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_prod_cgy_Desc_cd
,t2.totl_ord_actuals_rsd_cd_ttl_m1
,t2.totl_ord_actuals_rsd_cd_ttl_m2
,t2.totl_ord_actuals_rsd_cd_ttl_m3
,t2.dmnd_frcst_ovr_1_id_ttl_m1
,t2.dmnd_frcst_ovr_1_id_ttl_m2
,t2.dmnd_frcst_ovr_1_id_ttl_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
else 0
END as abs_err_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) else 0 end as abs_err_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
else 0 end as abs_err_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3) else 0 end as MAPE_quartr_prcnt
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1 else 0 end as frcst_mape_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) /totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2 else 0 end as frcst_mape_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3) else 0 end as frcst_mape_prcnt_m3
,totl_ord_actuals_rsd_cd_ttl_m1-dmnd_frcst_ovr_1_id_ttl_m1/dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m1 as frcst_bias_nrmlzd_m1
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2-dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2/dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2 as frcst_bias_nrmlzd_m2
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3-dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+dmnd_frcst_ovr_1_id_ttl_m3/dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3+dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+dmnd_frcst_ovr_1_id_ttl_m3 as frcst_bias_nrmlzd_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) else 0 end as frcst_vltalty_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) else 0 end as frcst_vltalty_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3) else 0 end as frcst_vltalty_prcnt_m3
,stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3) as frcst_vltalty_prcnt_qtr
,dpndt_cust_dmnd_cd
,sls_ord_qty_idpt_cd
,sls_ord_bcklo_1_cd
,sls_ord_bcklo_2_cd
,t1.frcst_por_mthly_cd
,frcst_por_quarterly_cd
,sls_ord_pgi_cd
,sm_pgi_qty_cd
,sm_qty_cd
,opn_ord_qty_cd_m1
,opn_ord_qty_cd_m2
,opn_ord_qty_cd_m3
,COALESCE(lag_opn_ord_qty_cd_m1,0L) as lag_opn_ord_qty_cd_m1
,COALESCE(lag_opn_ord_qty_cd_m2,0L) as lag_opn_ord_qty_cd_m2
,COALESCE(lag_opn_ord_qty_cd_m3,0L) as lag_opn_ord_qty_cd_m3
,frcst_por_mthly_cd_m1
,frcst_por_mthly_cd_m2
,frcst_por_mthly_cd_m3
,lag_frcst_por_quarterly_prev_cd
,COALESCE(lag_opn_ord_qty_cd_m1,0L)+COALESCE(lag_opn_ord_qty_cd_m2,0L)+COALESCE(lag_opn_ord_qty_cd_m3,0L) as rlld_bcklg_cd
,Case when month(current_date) in ("2","5","8","11") then totl_ord_actuals_rsd_cd_m1/lag_frcst_por_quarterly_prev_cd
when month(current_date) in ("3","6","7","12") then totl_ord_actuals_rsd_cd_m2/frcst_por_mthly_cd_m1
else totl_ord_actuals_rsd_cd_m2/frcst_por_mthly_cd_m1+frcst_por_mthly_cd_m2 end as ordr_mo_forecast_cd
,totl_ord_actuals_rsd_cd/frcst_por_mthly_cd as qtrly_forecast_attainmnt_cd
,current_timestamp() as ins_ts
,lag_totl_ord_actuals_rsd_cd
,lag_lctn_splt_consensus_dmnd_pln_cd
,totl_ord_actuals_rsd_cd-lag_totl_ord_actuals_rsd_cd as wk_ovr_wk_chng_totl_ord_actuals_rsd_cd
,lctn_splt_consensus_dmnd_pln_cd-lag_lctn_splt_consensus_dmnd_pln_cd as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_cd
,(lctn_splt_consensus_dmnd_pln_cd-lag_lctn_splt_consensus_dmnd_pln_cd)/100 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_prcnt_cd
,"WEEKLY" AS snpsht_typ
,CURRENT_DATE as snpsht_dt
from
"""+dbNameConsmtn + """.""" + aruba_twk_prod_lctn_cust_all_vlue_dmnsn + """ t1
left join
"""+dbNameConsmtn + "." +aruba_twk_prod_lctn_cust_qtrly_frcst_dmnsn +""" t2
on t1.qtr=t2.qtr and
t1.fiscal_yr=t2.fiscal_yr
left join """+dbNameConsmtn + "." +aruba_prdt_loc_cust_fact_cal_dmnsn +"""t3
on
t1.prod_id=t3.prod_id
and t1.lctn_id=t3.lctn_id
and t1.cust_id=t3.cust_id
and t1.keyfigure_dt=t3.keyfigure_dt
and current_date=t3.snpsht_dt""")

    for (i <- weeklyLimit to weeklyLimit + bufferDays) {
      var dateWeekly = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + dbNameConsmtn + "."+ consmptnTable +" DROP PARTITION(snpsht_typ='WEEKLY',snpsht_dt='" + dateWeekly + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for all possible weekly partitions")
        }
      }
    }

}
// Here dataframe will hold existing data from Fact Table for daily snapshot creation
else 
{
transformedDF = spark.sql("""select
crc32(lower(concat(COALESCE(lctn_id,""),COALESCE(prod_id,"")))) as hpn_lctn_prod_ky
,crc32(lower(concat(coalesce(cust_id,""),coalesce(lctn_id,""),coalesce(prod_id,"")))) as hpn_cust_src_ky
,crc32(upper(concat(coalesce(cust_id,""),coalesce(lctn_id,""),coalesce(prod_id,""),coalesce(cast(keyfigure_dt as string),""),coalesce(cast(current_timestamp() as string),"")))) as aruba_twk_prod_lctn_cust_fact_ky
,t1.prod_id
,t1.lctn_id
,t1.cust_id
,t1.vrtl_theater_cd
,t1.dmnd_typ_cd
,t1.bs_prod_cd
,t1.prod_cgy_p_2_cd
,t1.prod_cgy_Desc_cd
,date(t1.keyfigure_dt)
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,t1.totl_ord_actuals_rsd_cd
,t1.lctn_splt_consensus_dmnd_pln_cd
,t1.totl_shp_actl_pgi_cd
,t1.bsln_dmnd_frcst_stat_cd
,t1.dmnd_frcst_ovr_1_id
,t1.idpt_ord_actuals_rsd_cd
,t1.dpndt_ord_actuals_rsd_cd
,t1.shp_actuals_qty_cd
,t1.totl_ord_actuals_rsd_mnl_adjmt_cd
,t1.totl_crctd_ord_actuals_rsd_cd
,t1.opn_ord_qty_cd
,t1.chnl_invy_cd
,t1.chnl_sl_through_cd
,t1.cust_frcst_cd
,t1.ststcl_frcst_usr_dfnd_cd
,t1.ststcl_frcst_btch_cd
,t1.consensus_dp_ovrd_id
,t1.cfrd_cust_sply_cd
,t1.customer_idpt_ord_Actuals_RSD_cd
,t1.totl_ord_actuals_rsd_cd_mnthly
,t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
,t1.totl_shp_actl_pgi_cd_mnthly
,t1.bsln_dmnd_frcst_stat_cd_mnthly
,t1.dmnd_frcst_ovr_1_id_mnthly
,t1.idpt_ord_actuals_rsd_cd_mnthly
,t1.dpndt_ord_actuals_rsd_cd_mnthly
,t1.shp_actuals_qty_cd_mnthly
,t1.totl_ord_actuals_rsd_mnl_adjmt_cd_mnthly
,t1.totl_crctd_ord_actuals_rsd_cd_mnthly
,t1.opn_ord_qty_cd_mnthly
,t1.chnl_invy_cd_mnthly
,t1.chnl_sl_through_cd_mnthly
,t1.cust_frcst_cd_mnthly
,t1.ststcl_frcst_usr_dfnd_cd_mnthly
,t1.ststcl_frcst_btch_cd_mnthly
,t1.consensus_dp_ovrd_id_mnthly
,t1.cfrd_cust_sply_cd_mnthly
,t1.customer_idpt_ord_Actuals_RSD_cd_mnthly
,totl_ord_actuals_rsd_cd_m1
,lctn_splt_consensus_dmnd_pln_cd_m1
,totl_shp_actl_pgi_cd_m1
,bsln_dmnd_frcst_stat_cd_m1
,dmnd_frcst_ovr_1_id_m1
,ststcl_frcst_usr_dfnd_cd_m1
,ststcl_frcst_btch_cd_m1
,consensus_dp_ovrd_id_m1
,totl_ord_actuals_rsd_cd_m2
,lctn_splt_consensus_dmnd_pln_cd_m2
,totl_shp_actl_pgi_cd_m2
,bsln_dmnd_frcst_stat_cd_m2
,dmnd_frcst_ovr_1_id_m2
,ststcl_frcst_usr_dfnd_cd_m2
,ststcl_frcst_btch_cd_m2
,consensus_dp_ovrd_id_m2
,totl_ord_actuals_rsd_cd_m3
,lctn_splt_consensus_dmnd_pln_cd_m3
,totl_shp_actl_pgi_cd_m3
,bsln_dmnd_frcst_stat_cd_m3
,dmnd_frcst_ovr_1_id_m3
,ststcl_frcst_usr_dfnd_cd_m3
,ststcl_frcst_btch_cd_m3
,consensus_dp_ovrd_id_m3
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) or month(current_timestamp) in ("11","12","1") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q4") THEN  (bsln_dmnd_frcst_stat_cd_m1+bsln_dmnd_frcst_stat_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (bsln_dmnd_frcst_stat_cd_m1+bsln_dmnd_frcst_stat_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+bsln_dmnd_frcst_stat_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_dmnd_frcst_stat_cd_m3)
END as bsln_mtrl_frcst
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) and keyfigure_mnth not in ("11","12") or month(current_timestamp) in ("11","12","1") and t1.qtr not in ("Q1") or month(current_timestamp) in ("2","3","4") and t1.qtr not in ("Q1","Q2") OR month(current_timestamp) in ("5","6","7") and t1.qtr not in ("Q1","Q2","Q3") THEN  (lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3+lctn_splt_consensus_dmnd_pln_cd_m3)
END as lctn_splt_consensus_dmnd_pln_cd_qtr
,t1.opn_ord_qty_cd_mnthly + t1.totl_shp_actl_pgi_cd_mnthly - t1.totl_ord_actuals_rsd_cd_mnthly as bcklog_cryovr_cd
,t1.bsln_dmnd_frcst_stat_cd_mnthly - t1.totl_ord_actuals_rsd_cd_mnthly as consensus_pln_to_go_cd
,t1.totl_ord_actuals_rsd_cd_mnthly/t1.bsln_dmnd_frcst_stat_cd_mnthly  as mtd_qtd_attnmnt_bsln_pln_cd
,t1.bsln_dmnd_frcst_stat_cd_mnthly/t1.totl_ord_actuals_rsd_cd_mnthly  as pln_accry_bsln_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.dmnd_frcst_ovr_1_id_mnthly END as actl_bsln_mtrl_frcst_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
WHEN keyfigure_mnth = month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) THEN t1.shp_actuals_qty_cd_mnthly + t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
ELSE t1.lctn_splt_consensus_dmnd_pln_cd_mnthly END as actl_lctn_splt_consensus_dmnd_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_usr_dfnd_cd_mnthly END as actl_ststcl_frcst_usr_dfnd_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_btch_cd_mnthly END as actl_ststcl_frcst_btch_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) and t1.fiscal_yr = year(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.bsln_dmnd_frcst_stat_cd_mnthly END as actl_bsln_dmnd_frcst_stat_cd
,t1.totl_ord_actuals_rsd_cd_mnthly/(t1.totl_ord_actuals_rsd_cd_m1+t1.totl_ord_actuals_rsd_cd_m2+t1.totl_ord_actuals_rsd_cd_m3) as lnarty_fr_qtr
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,dmnd_typ_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_dmnd_typ_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by prod_cgy_Desc_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_prod_cgy_Desc_cd
,t2.totl_ord_actuals_rsd_cd_ttl_m1
,t2.totl_ord_actuals_rsd_cd_ttl_m2
,t2.totl_ord_actuals_rsd_cd_ttl_m3
,t2.dmnd_frcst_ovr_1_id_ttl_m1
,t2.dmnd_frcst_ovr_1_id_ttl_m2
,t2.dmnd_frcst_ovr_1_id_ttl_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1
else 0
END as abs_err_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) else 0 end as abs_err_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
else 0 end as abs_err_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3) else 0 end as MAPE_quartr_prcnt
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1 else 0 end as frcst_mape_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) /totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2 else 0 end as frcst_mape_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3) else 0 end as frcst_mape_prcnt_m3
,totl_ord_actuals_rsd_cd_ttl_m1-dmnd_frcst_ovr_1_id_ttl_m1/dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m1 as frcst_bias_nrmlzd_m1
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2-dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2/dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2 as frcst_bias_nrmlzd_m2
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3-dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+dmnd_frcst_ovr_1_id_ttl_m3/dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3+dmnd_frcst_ovr_1_id_ttl_m1+dmnd_frcst_ovr_1_id_ttl_m2+dmnd_frcst_ovr_1_id_ttl_m3 as frcst_bias_nrmlzd_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) else 0 end as frcst_vltalty_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) else 0 end as frcst_vltalty_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3) else 0 end as frcst_vltalty_prcnt_m3
,stddev(dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+dmnd_frcst_ovr_1_id_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+dmnd_frcst_ovr_1_id_m2+dmnd_frcst_ovr_1_id_m3+totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+dmnd_frcst_ovr_1_id_m3) as frcst_vltalty_prcnt_qtr
,dpndt_cust_dmnd_cd
,sls_ord_qty_idpt_cd
,sls_ord_bcklo_1_cd
,sls_ord_bcklo_2_cd
,t1.frcst_por_mthly_cd
,frcst_por_quarterly_cd
,sls_ord_pgi_cd
,sm_pgi_qty_cd
,sm_qty_cd
,opn_ord_qty_cd_m1
,opn_ord_qty_cd_m2
,opn_ord_qty_cd_m3
,COALESCE(lag_opn_ord_qty_cd_m1,0L) as lag_opn_ord_qty_cd_m1
,COALESCE(lag_opn_ord_qty_cd_m2,0L) as lag_opn_ord_qty_cd_m2
,COALESCE(lag_opn_ord_qty_cd_m3,0L) as lag_opn_ord_qty_cd_m3
,frcst_por_mthly_cd_m1
,frcst_por_mthly_cd_m2
,frcst_por_mthly_cd_m3
,lag_frcst_por_quarterly_prev_cd
,COALESCE(lag_opn_ord_qty_cd_m1,0L)+COALESCE(lag_opn_ord_qty_cd_m2,0L)+COALESCE(lag_opn_ord_qty_cd_m3,0L) as rlld_bcklg_cd
,Case when month(current_date) in ("2","5","8","11") then totl_ord_actuals_rsd_cd_m1/lag_frcst_por_quarterly_prev_cd
when month(current_date) in ("3","6","7","12") then totl_ord_actuals_rsd_cd_m2/frcst_por_mthly_cd_m1
else totl_ord_actuals_rsd_cd_m2/frcst_por_mthly_cd_m1+frcst_por_mthly_cd_m2 end as ordr_mo_forecast_cd
,totl_ord_actuals_rsd_cd/frcst_por_mthly_cd as qtrly_forecast_attainmnt_cd
,current_timestamp() as ins_ts
,0 as lag_totl_ord_actuals_rsd_cd
,0 as lag_lctn_splt_consensus_dmnd_pln_cd
,0 as wk_ovr_wk_chng_totl_ord_actuals_rsd_cd
,0 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_cd
,0 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_prcnt_cd
,Case WHEN X.monthly_snapshot_date_dt is NOT NULL then "MONTHLY" 
when date_format(current_date, 'u') = "7" then "WEEKLY" 
else "DAILY" END AS snpsht_typ
,CURRENT_DATE as snpsht_dt
from
"""+dbNameConsmtn + """.""" + aruba_twk_prod_lctn_cust_all_vlue_dmnsn + """ t1
left join
"""+dbNameConsmtn + "." +aruba_twk_prod_lctn_cust_qtrly_frcst_dmnsn +""" t2
on t1.qtr=t2.qtr and
t1.fiscal_yr=t2.fiscal_yr
LEFT join
"""+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn X
on current_date()=X.monthly_snapshot_date_dt""")

    for (i <- dailyLimit to dailyLimit + bufferDays) {
      var dateDaily = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + dbNameConsmtn + "."+ consmptnTable +" DROP PARTITION(snpsht_typ='DAILY',snpsht_dt='" + dateDaily + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for all possible daily partitions")
        }
      }
    }

}

    loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable)
	spark.catalog.dropTempView("transformedTgtDF_table")

//************************Completion Audit Entries*******************************//
     var tgt_count = transformedDF.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)     
    }
    case allException: IllegalArgumentException => {
      logger.error("Illegal Argument")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  }
  finally {
    sqlCon.close()
    spark.close()
  }
}
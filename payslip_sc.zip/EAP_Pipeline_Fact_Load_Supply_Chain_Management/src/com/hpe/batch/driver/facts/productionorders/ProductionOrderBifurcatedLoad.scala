package com.hpe.batch.driver.facts.productionorders

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import scala.collection.JavaConversions._
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.DataFrame

  object ProductionOrderBifurcatedLoad extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj:AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val propertiesObject: StreamingPropertiesObjectEnhanced = Utilities.getStreamingPropertiesObjectEnhanced(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var ld_jb_nr_ref = (ld_jb_nr + "_" + batchId)
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  println ("******************** Database is : " + dbName)
  //val dbName = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
  val tgtTblRef = propertiesObject.getTgtTblRef()
  val audittable = propertiesObject.getAuditTbl()
  
  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, "prdn_orders")
  
   try {    
  
  val hive_ref_table = propertiesObject.getHive_ref_table()
  println ("************************* Main ref table " + hive_ref_table)
  val hive_ref_table_capty_lookup_ref = propertiesObject.getHive_ref_table_capty_lookup_ref()
  val hive_ref_table_capty_rqmt_ref = propertiesObject.getHive_ref_table_capty_rqmt_ref()
  val hive_ref_table_capty_rqmt_dtl_ref = propertiesObject.getHive_ref_table_capty_rqmt_dtl_ref()
  val hive_ref_table_capty_rqmt_hdr_ref = propertiesObject.getHive_ref_table_capty_rqmt_hdr_ref()
  val hive_ref_table_hrchy_srtr_ref = propertiesObject.getHive_ref_table_hrchy_srtr_ref()
  val hive_ref_table_inrn_pstg_cst_ref = propertiesObject.getHive_ref_table_inrn_pstg_cst_ref()
  val hive_ref_table_inspn_pln_chrc_ref = propertiesObject.getHive_ref_table_inspn_pln_chrc_ref()
  val hive_ref_table_itm_allctn_ref = propertiesObject.getHive_ref_table_itm_allctn_ref()
  val hive_ref_table_mtrl_dcmt_sgm_ref = propertiesObject.getHive_ref_table_mtrl_dcmt_sgm_ref()
  val hive_ref_table_mtrl_tsk_lst_ref = propertiesObject.getHive_ref_table_mtrl_tsk_lst_ref()
  val hive_ref_table_obj_hrchy_ref = propertiesObject.getHive_ref_table_obj_hrchy_ref()
  val hive_ref_table_po_obj_stts_ref = propertiesObject.getHive_ref_table_po_obj_stts_ref()
  val hive_ref_table_oprnl_lvl_frcst_ref = propertiesObject.getHive_ref_table_oprnl_lvl_frcst_ref()
  val hive_ref_table_ord_cfrn_ref = propertiesObject.getHive_ref_table_ord_cfrn_ref()
  val hive_ref_table_ord_mstr_ref = propertiesObject.getHive_ref_table_ord_mstr_ref()
  val hive_ref_table_ord_oprn_ref = propertiesObject.getHive_ref_table_ord_oprn_ref()
  val hive_ref_table_plnd_ord_ref = propertiesObject.getHive_ref_table_plnd_ord_ref()
  val hive_ref_table_plng_capty_sgm_ref = propertiesObject.getHive_ref_table_plng_capty_sgm_ref()
  val hive_ref_table_plng_capty_sgm_irvl_ref = propertiesObject.getHive_ref_table_plng_capty_sgm_irvl_ref()
  val hive_ref_table_prch_ord_dtl_ref = propertiesObject.getHive_ref_table_prch_ord_dtl_ref()
  val hive_ref_table_prch_rqstn_acct_asngmt_ref = propertiesObject.getHive_ref_table_prch_rqstn_acct_asngmt_ref()
  val hive_ref_table_prdn_mtrl_vrsn_ref = propertiesObject.getHive_ref_table_prdn_mtrl_vrsn_ref()
  val hive_ref_table_prdn_ord_ref = propertiesObject.getHive_ref_table_prdn_ord_ref()
  val hive_ref_table_prdn_ord_itm_ref = propertiesObject.getHive_ref_table_prdn_ord_itm_ref()
  val hive_ref_table_prdn_ord_tsk_ref = propertiesObject.getHive_ref_table_prdn_ord_tsk_ref()
  val hive_ref_table_prdn_ord_tsk_actvy_ref = propertiesObject.getHive_ref_table_prdn_ord_tsk_actvy_ref()
  val hive_ref_table_prdn_ord_tsk_lst_ref = propertiesObject.getHive_ref_table_prdn_ord_tsk_lst_ref()
  val hive_ref_table_prdn_wrk_cntr_ref = propertiesObject.getHive_ref_table_prdn_wrk_cntr_ref()
  val hive_ref_table_prdn_wrk_cntr_capty_ref = propertiesObject.getHive_ref_table_prdn_wrk_cntr_capty_ref()
  val hive_ref_table_prdn_wrk_cntr_cst_cntr_ref = propertiesObject.getHive_ref_table_prdn_wrk_cntr_cst_cntr_ref()
  val hive_ref_table_rsrvtn_rqmt_ref = propertiesObject.getHive_ref_table_rsrvtn_rqmt_ref()
  val hive_ref_table_sb_oprn_ref = propertiesObject.getHive_ref_table_sb_oprn_ref()
  val hive_ref_table_tsk_lst_ref = propertiesObject.getHive_ref_table_tsk_lst_ref()
  val hive_ref_table_tsk_lst_oprns_ref = propertiesObject.getHive_ref_table_tsk_lst_oprns_ref()
  val hive_ref_table_tsk_phs_rltn_ref = propertiesObject.getHive_ref_table_tsk_phs_rltn_ref()
  val hive_ref_table_wrk_cntr_ref = propertiesObject.getHive_ref_table_wrk_cntr_ref()
  val hive_ref_table_wrk_ord_sqn_ref = propertiesObject.getHive_ref_table_wrk_ord_sqn_ref()
  val keys_capty_lookup_ref = propertiesObject.getKeys_capty_lookup_ref()
  val keys_capty_rqmt_ref = propertiesObject.getKeys_capty_rqmt_ref()
  val keys_capty_rqmt_dtl_ref = propertiesObject.getKeys_capty_rqmt_dtl_ref()
  val keys_capty_rqmt_hdr_ref = propertiesObject.getKeys_capty_rqmt_hdr_ref()
  val keys_hrchy_srtr_ref = propertiesObject.getKeys_hrchy_srtr_ref()
  val keys_inrn_pstg_cst_ref = propertiesObject.getKeys_inrn_pstg_cst_ref()
  val keys_inspn_pln_chrc_ref = propertiesObject.getKeys_inspn_pln_chrc_ref()
  val keys_itm_allctn_ref = propertiesObject.getKeys_itm_allctn_ref()
  val keys_mtrl_dcmt_sgm_ref = propertiesObject.getKeys_mtrl_dcmt_sgm_ref()
  val keys_mtrl_tsk_lst_ref = propertiesObject.getKeys_mtrl_tsk_lst_ref()
  val keys_obj_hrchy_ref = propertiesObject.getKeys_obj_hrchy_ref()
  val keys_po_obj_stts_ref = propertiesObject.getKeys_po_obj_stts_ref()
  val keys_oprnl_lvl_frcst_ref = propertiesObject.getKeys_oprnl_lvl_frcst_ref()
  val keys_ord_cfrn_ref = propertiesObject.getKeys_ord_cfrn_ref()
  val keys_ord_mstr_ref = propertiesObject.getKeys_ord_mstr_ref()
  val keys_ord_oprn_ref = propertiesObject.getKeys_ord_oprn_ref()
  val keys_plnd_ord_ref = propertiesObject.getKeys_plnd_ord_ref()
  val keys_plng_capty_sgm_ref = propertiesObject.getKeys_plng_capty_sgm_ref()
  val keys_plng_capty_sgm_irvl_ref = propertiesObject.getKeys_plng_capty_sgm_irvl_ref()
  val keys_prch_ord_dtl_ref = propertiesObject.getKeys_prch_ord_dtl_ref()
  val keys_prch_rqstn_acct_asngmt_ref = propertiesObject.getKeys_prch_rqstn_acct_asngmt_ref()
  val keys_prdn_mtrl_vrsn_ref = propertiesObject.getKeys_prdn_mtrl_vrsn_ref()
  val keys_prdn_ord_ref = propertiesObject.getKeys_prdn_ord_ref()
  val keys_prdn_ord_itm_ref = propertiesObject.getKeys_prdn_ord_itm_ref()
  val keys_prdn_ord_tsk_ref = propertiesObject.getKeys_prdn_ord_tsk_ref()
  val keys_prdn_ord_tsk_actvy_ref = propertiesObject.getKeys_prdn_ord_tsk_actvy_ref()
  val keys_prdn_ord_tsk_lst_ref = propertiesObject.getKeys_prdn_ord_tsk_lst_ref()
  val keys_prdn_wrk_cntr_ref = propertiesObject.getKeys_prdn_wrk_cntr_ref()
  val keys_prdn_wrk_cntr_capty_ref = propertiesObject.getKeys_prdn_wrk_cntr_capty_ref()
  val keys_prdn_wrk_cntr_cst_cntr_ref = propertiesObject.getKeys_prdn_wrk_cntr_cst_cntr_ref()
  val keys_rsrvtn_rqmt_ref = propertiesObject.getKeys_rsrvtn_rqmt_ref()
  val keys_sb_oprn_ref = propertiesObject.getKeys_sb_oprn_ref()
  val keys_tsk_lst_ref = propertiesObject.getKeys_tsk_lst_ref()
  val keys_tsk_lst_oprns_ref = propertiesObject.getKeys_tsk_lst_oprns_ref()
  val keys_tsk_phs_rltn_ref = propertiesObject.getKeys_tsk_phs_rltn_ref()
  val keys_wrk_cntr_ref = propertiesObject.getKeys_wrk_cntr_ref()
  val keys_wrk_ord_sqn_ref = propertiesObject.getKeys_wrk_ord_sqn_ref()
 
println("!!!!!!!!!!!!!!!!!!!!!!! Starting Bifurcated Load of Production Orders !!!!!!!!!!!!!")
  var ref1_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, "prdn_orders" )
  
  println("Max batch id of main ref table "+ ref1_max_btch_id.toString())
 println("***************************************************" + hive_ref_table)
 println("***************************************************" + hive_ref_table_capty_lookup_ref)
  var ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_capty_lookup_ref.trim().split("\\.", -1)(1).replace("_ref",""))
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
  var hive_ref_select = spark.sql("select " + keys_capty_lookup_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_capty_lookup_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row1 = hive_ref_select.distinct.repartition(200)
       
  var loadStatus = Utilities.storeDataFrame(filter_row1, "Append", "ORC", hive_ref_table_capty_lookup_ref)
  var tgt_count = filter_row1.count().toInt  
  println("Filtered Record Count:" + tgt_count)
  var transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

  var src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_capty_lookup_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_capty_lookup_ref)
   
  ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_capty_rqmt_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
  hive_ref_select = spark.sql("select " + keys_capty_rqmt_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_capty_rqmt_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row2 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row2, "Append", "ORC", hive_ref_table_capty_rqmt_ref)
   tgt_count = filter_row2.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_capty_rqmt_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_capty_rqmt_ref)
     
  ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_capty_rqmt_dtl_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_capty_rqmt_dtl_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_capty_rqmt_dtl_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row3 = hive_ref_select.distinct.repartition(200)
    
   loadStatus = Utilities.storeDataFrame(filter_row3, "Append", "ORC", hive_ref_table_capty_rqmt_dtl_ref)
   tgt_count = filter_row3.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_capty_rqmt_dtl_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_capty_rqmt_dtl_ref)
     
  
  ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_capty_rqmt_hdr_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
  hive_ref_select = spark.sql("select " + keys_capty_rqmt_hdr_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_capty_rqmt_hdr_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row4 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row4, "Append", "ORC", hive_ref_table_capty_rqmt_hdr_ref)
   tgt_count = filter_row4.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_capty_rqmt_hdr_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_capty_rqmt_hdr_ref)
  
ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_hrchy_srtr_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_hrchy_srtr_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_hrchy_srtr_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row5 = hive_ref_select.distinct.repartition(200)
    
   loadStatus = Utilities.storeDataFrame(filter_row5, "Append", "ORC", hive_ref_table_hrchy_srtr_ref)
   tgt_count = filter_row5.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_hrchy_srtr_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_hrchy_srtr_ref)
     
  
ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_inrn_pstg_cst_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_inrn_pstg_cst_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_inrn_pstg_cst_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row6 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row6, "Append", "ORC", hive_ref_table_inrn_pstg_cst_ref)
   tgt_count = filter_row6.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_inrn_pstg_cst_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_inrn_pstg_cst_ref)
     
   
ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_inspn_pln_chrc_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_inspn_pln_chrc_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_inspn_pln_chrc_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row7 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row7, "Append", "ORC", hive_ref_table_inspn_pln_chrc_ref)
   tgt_count = filter_row7.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_inspn_pln_chrc_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_inspn_pln_chrc_ref)
     
ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_itm_allctn_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_itm_allctn_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_itm_allctn_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row8 = hive_ref_select.distinct.repartition(200)
   
   loadStatus = Utilities.storeDataFrame(filter_row8, "Append", "ORC", hive_ref_table_itm_allctn_ref)
   tgt_count = filter_row8.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_itm_allctn_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_itm_allctn_ref)
     
  
  ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_mtrl_dcmt_sgm_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_mtrl_dcmt_sgm_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_mtrl_dcmt_sgm_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row9 = hive_ref_select.distinct.repartition(200)
    
  
   loadStatus = Utilities.storeDataFrame(filter_row9, "Append", "ORC", hive_ref_table_mtrl_dcmt_sgm_ref)
   tgt_count = filter_row9.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_mtrl_dcmt_sgm_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_mtrl_dcmt_sgm_ref)
     
  
  ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_mtrl_tsk_lst_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_mtrl_tsk_lst_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_mtrl_tsk_lst_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row10 = hive_ref_select.distinct.repartition(200)
   
   loadStatus = Utilities.storeDataFrame(filter_row10, "Append", "ORC", hive_ref_table_mtrl_tsk_lst_ref)
   tgt_count = filter_row10.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_mtrl_tsk_lst_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_mtrl_tsk_lst_ref)
  
   ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_obj_hrchy_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_obj_hrchy_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_obj_hrchy_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row11 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row11, "Append", "ORC", hive_ref_table_obj_hrchy_ref)
   tgt_count = filter_row11.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_obj_hrchy_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_obj_hrchy_ref)
     
  
   ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_po_obj_stts_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_po_obj_stts_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_po_obj_stts_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row12 = hive_ref_select.distinct.repartition(200)

   loadStatus = Utilities.storeDataFrame(filter_row12, "Append", "ORC", hive_ref_table_po_obj_stts_ref)
   tgt_count = filter_row12.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_po_obj_stts_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_po_obj_stts_ref)
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_oprnl_lvl_frcst_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_oprnl_lvl_frcst_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_oprnl_lvl_frcst_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row13 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row13, "Append", "ORC", hive_ref_table_oprnl_lvl_frcst_ref)
   tgt_count = filter_row13.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_oprnl_lvl_frcst_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_oprnl_lvl_frcst_ref)
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_ord_cfrn_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_ord_cfrn_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_ord_cfrn_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row14 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row14, "Append", "ORC", hive_ref_table_ord_cfrn_ref)
   tgt_count = filter_row14.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_ord_cfrn_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_ord_cfrn_ref)
  
       ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_ord_mstr_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_ord_mstr_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_ord_mstr_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row15 = hive_ref_select.distinct.repartition(200)
    
   loadStatus = Utilities.storeDataFrame(filter_row15, "Append", "ORC", hive_ref_table_ord_mstr_ref)
   tgt_count = filter_row15.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_ord_mstr_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_ord_mstr_ref)
  
           ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_ord_oprn_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_ord_oprn_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_ord_oprn_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row16 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row16, "Append", "ORC", hive_ref_table_ord_oprn_ref)
   tgt_count = filter_row16.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_ord_oprn_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_ord_oprn_ref)
  
          ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_plnd_ord_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_plnd_ord_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_plnd_ord_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row17 = hive_ref_select.distinct.repartition(200)
 
  
   loadStatus = Utilities.storeDataFrame(filter_row17, "Append", "ORC", hive_ref_table_plnd_ord_ref)
   tgt_count = filter_row17.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_plnd_ord_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_plnd_ord_ref)
  
      ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_plng_capty_sgm_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_plng_capty_sgm_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_plng_capty_sgm_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row18 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row18, "Append", "ORC", hive_ref_table_plng_capty_sgm_ref)
   tgt_count = filter_row18.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_plng_capty_sgm_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_plng_capty_sgm_ref)
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_plng_capty_sgm_irvl_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_plng_capty_sgm_irvl_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_plng_capty_sgm_irvl_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row19 = hive_ref_select.distinct.repartition(200)
   
   loadStatus = Utilities.storeDataFrame(filter_row19, "Append", "ORC", hive_ref_table_plng_capty_sgm_irvl_ref)
   tgt_count = filter_row19.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_plng_capty_sgm_irvl_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_plng_capty_sgm_irvl_ref)
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prch_ord_dtl_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prch_ord_dtl_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prch_ord_dtl_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row20 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row20, "Append", "ORC", hive_ref_table_prch_ord_dtl_ref)
   tgt_count = filter_row20.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prch_ord_dtl_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prch_ord_dtl_ref)
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prch_rqstn_acct_asngmt_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prch_rqstn_acct_asngmt_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prch_rqstn_acct_asngmt_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row21 = hive_ref_select.distinct.repartition(200)
    
  
   loadStatus = Utilities.storeDataFrame(filter_row21, "Append", "ORC", hive_ref_table_prch_rqstn_acct_asngmt_ref)
   tgt_count = filter_row21.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prch_rqstn_acct_asngmt_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prch_rqstn_acct_asngmt_ref)
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prdn_mtrl_vrsn_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prdn_mtrl_vrsn_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prdn_mtrl_vrsn_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row22 = hive_ref_select.distinct.repartition(200)
    
   loadStatus = Utilities.storeDataFrame(filter_row22, "Append", "ORC", hive_ref_table_prdn_mtrl_vrsn_ref)
   tgt_count = filter_row22.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prdn_mtrl_vrsn_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prdn_mtrl_vrsn_ref)
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prdn_ord_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prdn_ord_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prdn_ord_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row23 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row23, "Append", "ORC", hive_ref_table_prdn_ord_ref)
   tgt_count = filter_row23.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prdn_ord_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prdn_ord_ref)
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prdn_ord_itm_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prdn_ord_itm_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prdn_ord_itm_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row24 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row24, "Append", "ORC", hive_ref_table_prdn_ord_itm_ref)
   tgt_count = filter_row24.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prdn_ord_itm_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prdn_ord_itm_ref)
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prdn_ord_tsk_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prdn_ord_tsk_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prdn_ord_tsk_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row25 = hive_ref_select.distinct.repartition(200) 
   loadStatus = Utilities.storeDataFrame(filter_row25, "Append", "ORC", hive_ref_table_prdn_ord_tsk_ref)
   tgt_count = filter_row25.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prdn_ord_tsk_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prdn_ord_tsk_ref)
  
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prdn_ord_tsk_actvy_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prdn_ord_tsk_actvy_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prdn_ord_tsk_actvy_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row26 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row26, "Append", "ORC", hive_ref_table_prdn_ord_tsk_actvy_ref)
   tgt_count = filter_row26.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prdn_ord_tsk_actvy_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prdn_ord_tsk_actvy_ref)
  
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prdn_ord_tsk_lst_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prdn_ord_tsk_lst_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prdn_ord_tsk_lst_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row27 = hive_ref_select.distinct.repartition(200)
   
   loadStatus = Utilities.storeDataFrame(filter_row27, "Append", "ORC", hive_ref_table_prdn_ord_tsk_lst_ref)
   tgt_count = filter_row27.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prdn_ord_tsk_lst_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prdn_ord_tsk_lst_ref)
  
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prdn_wrk_cntr_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prdn_wrk_cntr_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prdn_wrk_cntr_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row28 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row28, "Append", "ORC", hive_ref_table_prdn_wrk_cntr_ref)
   tgt_count = filter_row28.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prdn_wrk_cntr_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prdn_wrk_cntr_ref)
  
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prdn_wrk_cntr_capty_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prdn_wrk_cntr_capty_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prdn_wrk_cntr_capty_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row29 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row29, "Append", "ORC", hive_ref_table_prdn_wrk_cntr_capty_ref)
   tgt_count = filter_row29.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prdn_wrk_cntr_capty_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prdn_wrk_cntr_capty_ref)
  
  
     ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prdn_wrk_cntr_cst_cntr_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_prdn_wrk_cntr_cst_cntr_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_prdn_wrk_cntr_cst_cntr_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row30 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row30, "Append", "ORC", hive_ref_table_prdn_wrk_cntr_cst_cntr_ref)
   tgt_count = filter_row30.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_prdn_wrk_cntr_cst_cntr_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_prdn_wrk_cntr_cst_cntr_ref)
  
   ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_rsrvtn_rqmt_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_rsrvtn_rqmt_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_rsrvtn_rqmt_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row31 = hive_ref_select.distinct.repartition(200)
 
   loadStatus = Utilities.storeDataFrame(filter_row31, "Append", "ORC", hive_ref_table_rsrvtn_rqmt_ref)
   tgt_count = filter_row31.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_rsrvtn_rqmt_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_rsrvtn_rqmt_ref)
  
   ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_sb_oprn_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_sb_oprn_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_sb_oprn_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row32 = hive_ref_select.distinct.repartition(200)

   loadStatus = Utilities.storeDataFrame(filter_row32, "Append", "ORC", hive_ref_table_sb_oprn_ref)
   tgt_count = filter_row32.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_sb_oprn_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_sb_oprn_ref)
  
   ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_tsk_lst_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_tsk_lst_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_tsk_lst_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row33 = hive_ref_select.distinct.repartition(200)
   loadStatus = Utilities.storeDataFrame(filter_row33, "Append", "ORC", hive_ref_table_tsk_lst_ref)
   tgt_count = filter_row33.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_tsk_lst_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_tsk_lst_ref)
  
   ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_tsk_lst_oprns_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_tsk_lst_oprns_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_tsk_lst_oprns_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row34 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row34, "Append", "ORC", hive_ref_table_tsk_lst_oprns_ref)
   tgt_count = filter_row34.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_tsk_lst_oprns_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_tsk_lst_oprns_ref)
  
   ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_tsk_phs_rltn_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_tsk_phs_rltn_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_tsk_phs_rltn_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row35 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row35, "Append", "ORC", hive_ref_table_tsk_phs_rltn_ref)
   tgt_count = filter_row35.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_tsk_phs_rltn_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_tsk_phs_rltn_ref)
  
   ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_wrk_cntr_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_wrk_cntr_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_wrk_cntr_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row36 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row36, "Append", "ORC", hive_ref_table_wrk_cntr_ref)
   tgt_count = filter_row36.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_wrk_cntr_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_wrk_cntr_ref)
  
   ref2_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_wrk_ord_sqn_ref.trim().split("\\.", -1)(1).replace("_ref","") )
  
  println("Max batch id of ref2 table "+ ref2_max_btch_id.toString())
  
   hive_ref_select = spark.sql("select " + keys_wrk_ord_sqn_ref +",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'").persist(StorageLevel.MEMORY_AND_DISK_SER)
  
  println("select " + keys_wrk_ord_sqn_ref + ",'" + ref1_max_btch_id + "' as ld_jb_nr , ins_gmt_dt   from " + dbName+"""."""+tgtTblRef + " where ld_jb_nr >= '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'")
  
   val filter_row37 = hive_ref_select.distinct.repartition(200)
  
   loadStatus = Utilities.storeDataFrame(filter_row37, "Append", "ORC", hive_ref_table_wrk_ord_sqn_ref)
   tgt_count = filter_row37.count().toInt  
  println("Filtered Record Count:" + tgt_count)
   transformeSrcdDF = spark.sql("""select * from """ + dbName+"""."""+tgtTblRef + " where ld_jb_nr > '" + ref2_max_btch_id +"' and ld_jb_nr <= '" + ref1_max_btch_id +"'" )

   src_count = transformeSrcdDF.count().toInt
  
  //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ref1_max_btch_id)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadRefined")
    auditObj.setAudObjectName(hive_ref_table_wrk_ord_sqn_ref.trim().split("\\.", -1)(1).replace("_ref",""))
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
  println("Data has been loaded to:" + hive_ref_table_wrk_ord_sqn_ref)
  
  
  }

   catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
       case connException: ConnectException => {

      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case ex: Exception => {
      logger.error("Exception: " + ex.printStackTrace())
      sqlCon.close()
      spark.close()
      System.exit(1)
    }  
  }
 finally {
    sqlCon.close()
    spark.close()
  }
  }
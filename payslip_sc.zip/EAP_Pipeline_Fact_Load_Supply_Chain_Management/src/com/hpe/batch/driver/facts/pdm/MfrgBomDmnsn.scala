package com.hpe.batch.driver.facts.pdm

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object MfrgBomDmnsn extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  var bom_max_btch_id = ld_jb_nr + "_" + "19000101000000"
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val numPartitions = propertiesObject.getNumPartitions().trim().toInt
  var src_count = 0
  var tgt_count = 0
  var loadStatus = true
  val srcTblConsmtn = propertiesObject.getSrcTblConsmtn()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn()
  var dbNameRef: String = null
  var refTable: String = null
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (srcTblConsmtn.trim().split("\\.", -1).size == 2) {
    dbNameRef = srcTblConsmtn.trim().split("\\.", -1)(0)
    refTable = srcTblConsmtn.trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update srcTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  if (tgtTblConsmtn.trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = tgtTblConsmtn.trim().split("\\.", -1)(0)
    consmptnTable = tgtTblConsmtn.trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  var bomIncrementalFinalDf = spark.emptyDataFrame
  var ins_gmt_date = ""
  var bom_min_btch_id = ""
  val Keys_table_mfrg_bom_ref = propertiesObject.getUnqKeyCols().trim()

  //************************Set Audit Entries*******************************//

  auditObj.setAudBatchId(bom_max_btch_id)
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName("mfrg_bom")
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(src_count)
  auditObj.setAudTgtRowCount(tgt_count)

  try {

    //****************** Method to get delta batch id  *********************\\

    val refBatchIdList: List[String] = Utilities.readRefBatchIdListNew(sqlCon, propertiesObject.getObjName(), auditTbl)

    if (refBatchIdList.length != 0) {

      logger.info("-------------->>>>>>>>Got List<<<<<<<<<<<<<<----------------" + refBatchIdList)

      bom_max_btch_id = refBatchIdList.map(x => (x, x.reverse.slice(0, 14).reverse)).maxBy(_._2)._1

      bom_min_btch_id = refBatchIdList.map(x => (x, x.reverse.slice(0, 14).reverse)).minBy(_._2)._2

      logger.info("-------------->>>>>>>>bom_min_btch_id<<<<<<<<<<<<<<----------------" + bom_min_btch_id)

      ins_gmt_date = bom_min_btch_id.substring(0, 4) + '-' + bom_min_btch_id.substring(4, 6) + '-' + bom_min_btch_id.substring(6, 8)

      logger.info("-------------->>>>>>>>ins_gmt_date<<<<<<<<<<<<<<----------------" + ins_gmt_date)

      //***************** Selecting the incremental records to be processed **********************\\

      var bomIncrementalDfSrcCnt = spark.sql(f"""select ld_jb_nr from ${dbNameRef}.${refTable} where date_sub(ins_gmt_dt,-1)>='""" + ins_gmt_date + """'""").filter(col("ld_jb_nr").isin(refBatchIdList: _*))

      src_count = bomIncrementalDfSrcCnt.count.toInt

      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudBatchId(bom_max_btch_id)

      val bomIncrementalDf = spark.sql(f"""select ${Keys_table_mfrg_bom_ref} ,ins_gmt_dt from ${dbNameRef}.${refTable} where date_sub(ins_gmt_dt,-1)>='""" + ins_gmt_date + """'""").filter(col("ld_jb_nr").isin(refBatchIdList: _*))

      bomIncrementalDf.createOrReplaceTempView("mfrg_bom_ref_incremental")

      logger.info("""-------------->>>>>>>>Select query to read from source<<<<<<<<<<<<<<---------------- select * from """ + dbNameRef + """.""" + refTable + """ where date_sub(ins_gmt_dt,-1)>='""" + ins_gmt_date + """'""")

      //***************** Putting the data in the left table **********************\\

      val bomIncrementalDfLeft = bomIncrementalDf.filter(col("e1mastm_mtrl_18_characters_nr").isNotNull)

      bomIncrementalDfLeft.createOrReplaceTempView("mfrg_bom_ref_left")

      //***************** Putting the data in the right table **********************\\

      val bomIncrementalDfRight = spark.sql("""select * from mfrg_bom_ref_incremental A where A.e1mastm_mtrl_18_characters_nr is null and (A.e1stpom_bom_cmpnnt_nm is not null or A.e1stpom_bom_itm_txt_ln_1_nm is not null)""")

      bomIncrementalDfRight.createOrReplaceTempView("mfrg_bom_ref_right")

      //***************** Aligning the data as per case statements to being plant and component at the same row **********************\\

      val bomIncrementalJoinDf = spark.sql("""select
lf.idoc_nr 
,lf.e1stzum_e1stzum_fnctn_cd                    
,lf.e1stzum_bom_cgy_cd                          
,lf.e1stzum_bll_mtrl_cd                         
,lf.e1stzum_bom_usg_cd                          
,lf.e1stzum_bom_gr_2_nm                         
,lf.e1stzum_in_1_cd                             
,lf.e1stzum_in_4_cd                             
,lf.e1stzum_in_2_cd                             
,lf.e1stzum_lng_ind                             
,lf.athzn_grp_bills_mtrl_cd                     
,lf.bom_txt_nm                                  
,lf.last_chg_nr                                 
,lf.bom_last_chgd_dt                            
,lf.tm_when_bom_last_chgd_ts                    
,lf.e1stzum_2character_sap_lng_cd               
,lf.e1stzum_bom_gr_1_nm                         
,lf.zstzu_ext_plnt_whr_vrnt_crtd_cd             
,lf.zstzu_ext_hisdt_ind_cd                      
,lf.zstzu_ext_hissr_ind_cd                      
,lf.zstzu_ext_histk_ind_cd                      
,lf.mxm_counters_nr                             
,lf.mxm_nodes_within_nr                         
,lf.zstzu_ext_kzpln_ind_cd                      
,lf.mxm_clsfn_nr                                
,lf.mxm_edge_nr                                 
,lf.tm_stamp_nr                                 
,lf.zstzu_ext_versnind_ind_cd                   
,lf.e1szuth_e1szuth_fnctn_cd                    
,lf.e1szut_1_nm                                 
,lf.e1szuth_txt_id_id                           
,lf.e1szuth_lng_ky_ind                          
,lf.e1szuth_2character_sap_lng_cd               
,lf.e1szutl_tg_cl_cd                            
,lf.e1szutl_txt_ln_nm                           
,lf.e1mastm_e1mastm_fnctn_cd                    
,lf.e1mastm_mtrl_18_characters_nr               
,lf.e1mastm_plnt_cd                             
,lf.e1mastm_bom_usg_cd                          
,lf.e1mastm_bll_mtrl_cd                         
,lf.e1mastm_altv_bom_cd                         
,lf.e1mastm_frm_lt_s_1                          
,lf.e1mastm_to_lt_s_1                           
,lf.e1mastm_ind_cd                              
,lf.e1mastm_mtr_3_nr                            
,lf.e1mastm_vrsn_matnr_fl_1_nr                  
,lf.e1mastm_xtrn_guid_matnr_fld_nm              
,lf.e1mastm_mtr_5_nr                            
,lf.zmast_ext_rec_crtd_by                       
,lf.zmast_ext_rec_upd_by                        
,lf.zmast_ext_rec_crtd_dt                       
,lf.zmast_ext_rec_upd_dt   
,lf.zmast_ext_dltn_ind_cd                     
,lf.e1t415b_e1t415b_fnctn_cd                    
,lf.e1t415b_mtrl_18_characters_nr               
,lf.e1t415b_bom_usg_cd                          
,lf.e1t415b_bs_unt_msr_bom                      
,lf.e1t415b_altv_bom_cd                         
,lf.e1t415b_mtr_1_nr                            
,lf.e1t415b_vrsn_matnr_fl_3_nr                  
,lf.e1t415b_xtrn_guid_matnr_fld_nm              
,lf.e1t415b_mtr_3_nr                            
,lf.e1stkom_e1stkom_fnctn_cd                    
,lf.e1stkom_altv_bom_cd                         
,lf.e1stkom_validfrom_dt                        
,lf.e1stkom_chg_nr                              
,lf.e1stkom_dltn_flg_boms_cd                    
,lf.e1stkom_unt_msr_bs_qty                      
,lf.e1stkom_cfrd_qt_1                           
,lf.e1stkom_cad_ind_cd                          
,lf.e1stkom_laboratorydesign_ofc_cd             
,lf.e1stkom_lng_ind                             
,lf.e1stkom_altv_bom_txt_nm                     
,lf.e1stkom_bom_stts                            
,lf.e1stkom_2character_sap_lng_cd               
,lf.e1stkom_bs_qty_nm                           
,lf.e1stkom_guid_xtrn_dsply_char32_nm           
,lf.zstko_ext_bll_mtrl_cd                       
,lf.zstko_ext_bom_cgy_cd                        
,lf.zstko_ext_inrn_cntr_nr                      
,lf.zstko_ext_valid_to_dt                       
,lf.zstko_ext_rec_crtd_by                       
,lf.zstko_ext_rec_upd_by                        
,lf.zstko_ext_plnt_whr_vrnt_crtd_cd             
,lf.bom_vrsn_cd                                 
,lf.bom_vrsn_stts_cd                            
,lf.zstko_ext_versnlastind_ind_cd               
,lf.zstko_ext_rec_crtd_dt                       
,lf.zstko_ext_rec_upd_dt                        
,lf.zstko_ext_tchnl_stts_frm_cd                 
,lf.prv_hdr_cnter_nr                            
,lf.zstko_ext_last_shft_dt                      
,lf.zstko_last_shft_dt_crrd_out_by              
,lf.zstko_ext_shft_hrchy_ind_nr                 
,lf.zstko_ext_ale_ind_cd                        
,lf.zstko_ext_chg_nr_to_cd                      
,lf.dta_elmt_extensibility_mnt_hdr_cd           
,lf.e1skoth_e1skoth_fnctn_cd                    
,lf.e1skot_1_nm                                 
,lf.e1skoth_txt_id_id                           
,lf.e1skoth_lng_ky_ind                          
,lf.e1skoth_2character_sap_lng_cd               
,lf.e1skotl_tg_cl_cd                            
,lf.e1skotl_txt_ln_nm                           
,lf.e1stasm_e1stasm_fnctn_cd                    
,lf.e1stasm_altv_bom_cd                         
,lf.e1stasm_bom_itm_nde_nr                      
,lf.e1stasm_validfrom_dt                        
,lf.e1stasm_chg_nr                              
,lf.e1stasm_dltn_ind_cd                         
,lf.inherited_nde_bom_itm_nr                    
,coalesce(lf.e1stpom_e1stpom_fnctn_cd, rt.e1stpom_e1stpom_fnctn_cd) as e1stpom_e1stpom_fnctn_cd 
,coalesce(lf.e1stpom_bom_itm_nde_nr, rt.e1stpom_bom_itm_nde_nr) as e1stpom_bom_itm_nde_nr  
,coalesce(lf.e1stpom_itm_cgy_bll_mtr_1_cd, rt.e1stpom_itm_cgy_bll_mtr_1_cd) as e1stpom_itm_cgy_bll_mtr_1_cd                
,coalesce(lf.e1stpom_bom_it_1_nr, rt.e1stpom_bom_it_1_nr) as e1stpom_bom_it_1_nr     
,coalesce(lf.e1stpom_mtrl_18_characters_nr, rt.e1stpom_mtrl_18_characters_nr) as e1stpom_mtrl_18_characters_nr               
,coalesce(lf.e1stpom_cls_2_nr,rt.e1stpom_cls_2_nr) as e1stpom_cls_2_nr        
,coalesce(lf.e1stpom_clss_ty_1_cd, rt.e1stpom_clss_ty_1_cd) as e1stpom_clss_ty_1_cd    
,coalesce(lf.e1stpom_dcm_2_nr, rt.e1stpom_dcm_2_nr) as e1stpom_dcm_2_nr        
,coalesce(lf.e1stpom_dcmt_ty_2_cd, rt.e1stpom_dcmt_ty_2_cd) as e1stpom_dcmt_ty_2_cd    
,coalesce(lf.e1stpom_dcmt_pr_2_cd, rt.e1stpom_dcmt_pr_2_cd) as e1stpom_dcmt_pr_2_cd    
,coalesce(lf.e1stpom_dcmt_vrs_2_cd, rt.e1stpom_dcmt_vrs_2_cd) as e1stpom_dcmt_vrs_2_cd   
,coalesce(lf.e1stpom_srt_str_6_nm, rt.e1stpom_srt_str_6_nm) as e1stpom_srt_str_6_nm    
,coalesce(lf.e1stpom_validfrom_dt, rt.e1stpom_validfrom_dt) as e1stpom_validfrom_dt    
,coalesce(lf.e1stpom_chg_nr, rt.e1stpom_chg_nr) as e1stpom_chg_nr          
,coalesce(lf.e1stpom_dltn_ind_cd, rt.e1stpom_dltn_ind_cd) as e1stpom_dltn_ind_cd     
,coalesce(lf.e1stpom_bom_cmpnnt_nm, rt.e1stpom_bom_cmpnnt_nm) as e1stpom_bom_cmpnnt_nm   
,coalesce(lf.e1stpom_itm_cgy_bll_mtr_2_cd, rt.e1stpom_itm_cgy_bll_mtr_2_cd) as e1stpom_itm_cgy_bll_mtr_2_cd 
,coalesce(lf.e1stpom_bom_it_2_nr, rt.e1stpom_bom_it_2_nr) as e1stpom_bom_it_2_nr     
,coalesce(lf.e1stpom_srt_str_5_nm, rt.e1stpom_srt_str_5_nm) as e1stpom_srt_str_5_nm    
,coalesce(lf.e1stpom_bs_unt_msr, rt.e1stpom_bs_unt_msr) as e1stpom_bs_unt_msr      
,coalesce(lf.e1stpom_qt_1, rt.e1stpom_qt_1) as e1stpom_qt_1            
,coalesce(lf.e1stpom_fx_qty_cd, rt.e1stpom_fx_qty_cd) as e1stpom_fx_qty_cd       
,coalesce(lf.e1stpom_cmpnnt_scrp_prct, rt.e1stpom_cmpnnt_scrp_prct) as e1stpom_cmpnnt_scrp_prct 
,coalesce(lf.e1stpom_oprn_scrp, rt.e1stpom_oprn_scrp) as e1stpom_oprn_scrp       
,coalesce(lf.e1stpom_nt_scrp_ind_cd, rt.e1stpom_nt_scrp_ind_cd) as e1stpom_nt_scrp_ind_cd  
,coalesce(lf.e1stpom_in_9_cd, rt.e1stpom_in_9_cd) as e1stpom_in_9_cd         
,coalesce(lf.e1stpom_mtrl_prvn_ind_cd, rt.e1stpom_mtrl_prvn_ind_cd) as e1stpom_mtrl_prvn_ind_cd 
,coalesce(lf.e1stpom_in_3_cd, rt.e1stpom_in_3_cd) as e1stpom_in_3_cd         
,coalesce(lf.e1stpom_in_5_cd, rt.e1stpom_in_5_cd) as e1stpom_in_5_cd         
,coalesce(lf.e1stpom_in_4_cd, rt.e1stpom_in_4_cd) as e1stpom_in_4_cd         
,coalesce(lf.e1stpom_in_18_cd, rt.e1stpom_in_18_cd) as e1stpom_in_18_cd        
,coalesce(lf.e1stpom_in_6_cd, rt.e1stpom_in_6_cd) as e1stpom_in_6_cd         
,coalesce(lf.e1stpom_in_7_cd, rt.e1stpom_in_7_cd) as e1stpom_in_7_cd         
,coalesce(lf.e1stpom_in_8_cd, rt.e1stpom_in_8_cd) as e1stpom_in_8_cd         
,coalesce(lf.e1stpom_pm_asmy_ind_cd, rt.e1stpom_pm_asmy_ind_cd) as e1stpom_pm_asmy_ind_cd  
,coalesce(lf.e1stpom_in_19_cd, rt.e1stpom_in_19_cd) as e1stpom_in_19_cd        
,coalesce(lf.e1stpom_in_20_cd, rt.e1stpom_in_20_cd) as e1stpom_in_20_cd        
,coalesce(lf.e1stpom_cad_ind_cd, rt.e1stpom_cad_ind_cd) as e1stpom_cad_ind_cd      
,coalesce(lf.e1stpom_leadtime_ofst_ts, rt.e1stpom_leadtime_ofst_ts) as e1stpom_leadtime_ofst_ts 
,coalesce(lf.e1stpom_dbn_ky_cmpnnt_cnsmpn_cd, rt.e1stpom_dbn_ky_cmpnnt_cnsmpn_cd) as e1stpom_dbn_ky_cmpnnt_cnsmpn_cd             
,coalesce(lf.e1stpom_in_17_cd, rt.e1stpom_in_17_cd) as e1stpom_in_17_cd        
,coalesce(lf.e1stpom_usg_prblty__altv_itm, rt.e1stpom_usg_prblty__altv_itm) as e1stpom_usg_prblty__altv_itm 
,coalesce(lf.e1stpom_prchg_grp_cd, rt.e1stpom_prchg_grp_cd) as e1stpom_prchg_grp_cd    
,coalesce(lf.e1stpom_dlvry_tm_dys_dt, rt.e1stpom_dlvry_tm_dys_dt) as e1stpom_dlvry_tm_dys_dt 
,coalesce(lf.e1stpom_e1stpom_acct_vndr_crdt_3_nr, rt.e1stpom_e1stpom_acct_vndr_crdt_3_nr) as e1stpom_e1stpom_acct_vndr_crdt_3_nr         
,coalesce(lf.e1stpom_pr_1, rt.e1stpom_pr_1) as e1stpom_pr_1            
,coalesce(lf.e1stpom_prc_unt, rt.e1stpom_prc_unt) as e1stpom_prc_unt         
,coalesce(lf.e1stpom_threedigit_chr_fld_idocs_id, rt.e1stpom_threedigit_chr_fld_idocs_id) as e1stpom_threedigit_chr_fld_idocs_id         
,coalesce(lf.e1stpom_cst_elmt_nm , rt.e1stpom_cst_elmt_nm) as e1stpom_cst_elmt_nm     
,coalesce(lf.e1stpom_variablesize_itm_1_nr, rt.e1stpom_variablesize_itm_1_nr) as e1stpom_variablesize_itm_1_nr               
,coalesce(lf.e1stpom_sz__1, rt.e1stpom_sz__1) as e1stpom_sz__1           
,coalesce(lf.e1stpom_sz__3, rt.e1stpom_sz__3) as e1stpom_sz__3           
,coalesce(lf.e1stpom_sz__2, rt.e1stpom_sz__2) as e1stpom_sz__2           
,coalesce(lf.e1stpom_unt_msr_sizes_1_to_3, rt.e1stpom_unt_msr_sizes_1_to_3) as e1stpom_unt_msr_sizes_1_to_3 
,coalesce(lf.e1stpom_qty_variablesize_it_3, rt.e1stpom_qty_variablesize_it_3) as e1stpom_qty_variablesize_it_3               
,coalesce(lf.e1stpom_fml_ky_cd, rt.e1stpom_fml_ky_cd) as e1stpom_fml_ky_cd       
,coalesce(lf.e1stpom_in_13_cd, rt.e1stpom_in_13_cd) as e1stpom_in_13_cd        
,coalesce(lf.e1stpom_lng_ind, rt.e1stpom_lng_ind) as e1stpom_lng_ind         
,coalesce(lf.e1stpom_bom_itm_txt_ln_1_nm, rt.e1stpom_bom_itm_txt_ln_1_nm) as e1stpom_bom_itm_txt_ln_1_nm 
,coalesce(lf.e1stpom_bom_itm_txt_ln_2_nm, rt.e1stpom_bom_itm_txt_ln_2_nm) as e1stpom_bom_itm_txt_ln_2_nm 
,coalesce(lf.e1stpom_obj_typ_bom_itm_cd, rt.e1stpom_obj_typ_bom_itm_cd) as e1stpom_obj_typ_bom_itm_cd  
,coalesce(lf.e1stpom_mtrl_grp_cd, rt.e1stpom_mtrl_grp_cd) as e1stpom_mtrl_grp_cd     
,coalesce(lf.e1stpom_gds_rcpt_prsng_tm_dys_dt, rt.e1stpom_gds_rcpt_prsng_tm_dys_dt) as e1stpom_gds_rcpt_prsng_tm_dys_dt            
,coalesce(lf.e1stpom_dcmt_ty_1_cd, rt.e1stpom_dcmt_ty_1_cd) as e1stpom_dcmt_ty_1_cd    
,coalesce(lf.e1stpom_dcm_1_nr, rt.e1stpom_dcm_1_nr) as e1stpom_dcm_1_nr        
,coalesce(lf.e1stpom_dcmt_vrs_1_cd, rt.e1stpom_dcmt_vrs_1_cd) as e1stpom_dcmt_vrs_1_cd   
,coalesce(lf.e1stpom_dcmt_pr_1_cd, rt.e1stpom_dcmt_pr_1_cd) as e1stpom_dcmt_pr_1_cd    
,coalesce(lf.e1stpom_avg_mtrl_purity_, rt.e1stpom_avg_mtrl_purity_) as e1stpom_avg_mtrl_purity_ 
,coalesce(lf.e1stpom_plng_prm_clss_cd, rt.e1stpom_plng_prm_clss_cd) as e1stpom_plng_prm_clss_cd 
,coalesce(lf.e1stpom_clss_ty_2_cd, rt.e1stpom_clss_ty_2_cd) as e1stpom_clss_ty_2_cd    
,coalesce(lf.e1stpom_resulting_itm_cgy_cd, rt.e1stpom_resulting_itm_cgy_cd) as e1stpom_resulting_itm_cgy_cd 
,coalesce(lf.e1stpom_slctn_ind_cnfgl_boms_cd, rt.e1stpom_slctn_ind_cnfgl_boms_cd) as e1stpom_slctn_ind_cnfgl_boms_cd             
,coalesce(lf.e1stpom_insn_ind_cd, rt.e1stpom_insn_ind_cd) as e1stpom_insn_ind_cd     
,coalesce(lf.e1stpom_in_15_cd, rt.e1stpom_in_15_cd) as e1stpom_in_15_cd        
,coalesce(lf.e1stpom_in_16_cd, rt.e1stpom_in_16_cd) as e1stpom_in_16_cd        
,coalesce(lf.e1stpom_in_14_cd, rt.e1stpom_in_14_cd) as e1stpom_in_14_cd        
,coalesce(lf.e1stpom_prchg_org_cd, rt.e1stpom_prchg_org_cd) as e1stpom_prchg_org_cd    
,coalesce(lf.e1stpom_rqrd_cmpnnt_cd, rt.e1stpom_rqrd_cmpnnt_cd) as e1stpom_rqrd_cmpnnt_cd  
,coalesce(lf.e1stpom_mltpl_slctn_allwd_cd, rt.e1stpom_mltpl_slctn_allwd_cd) as e1stpom_mltpl_slctn_allwd_cd 
,coalesce(lf.e1stpom_altv_dsply_frmt_cd, rt.e1stpom_altv_dsply_frmt_cd) as e1stpom_altv_dsply_frmt_cd  
,coalesce(lf.e1stpom_orgnl_ar_nm, rt.e1stpom_orgnl_ar_nm) as e1stpom_orgnl_ar_nm     
,coalesce(lf.e1stpom_obj_wth_asngd_dpncs_nr, rt.e1stpom_obj_wth_asngd_dpncs_nr) as e1stpom_obj_wth_asngd_dpncs_nr              
,coalesce(lf.e1stpom_iss_lctn_prdn_ord_cd, rt.e1stpom_iss_lctn_prdn_ord_cd) as e1stpom_iss_lctn_prdn_ord_cd 
,coalesce(lf.e1stpom_in_21_cd, rt.e1stpom_in_21_cd) as e1stpom_in_21_cd        
,coalesce(lf.e1stpom_intra_mtrl_nm, rt.e1stpom_intra_mtrl_nm) as e1stpom_intra_mtrl_nm   
,coalesce(lf.e1stpom_in_10_cd, rt.e1stpom_in_10_cd) as e1stpom_in_10_cd        
,coalesce(lf.e1stpom_explsn_typ_cd, rt.e1stpom_explsn_typ_cd) as e1stpom_explsn_typ_cd   
,coalesce(lf.e1stpom_altv_it_2_cd, rt.e1stpom_altv_it_2_cd) as e1stpom_altv_it_2_cd    
,coalesce(lf.e1stpom_altv_itm, rt.e1stpom_altv_itm) as e1stpom_altv_itm        
,coalesce(lf.e1stpom_altv_it_1_cd, rt.e1stpom_altv_it_1_cd) as e1stpom_altv_it_1_cd    
,coalesce(lf.e1stpom_followup_grp_cd, rt.e1stpom_followup_grp_cd) as e1stpom_followup_grp_cd 
,coalesce(lf.e1stpom_discontinuation_grp_cd, rt.e1stpom_discontinuation_grp_cd) as e1stpom_discontinuation_grp_cd              
,coalesce(lf.e1stpom_clsfn_nr, rt.e1stpom_clsfn_nr) as e1stpom_clsfn_nr        
,coalesce(lf.e1stpom_in_22_cd, rt.e1stpom_in_22_cd) as e1stpom_in_22_cd        
,coalesce(lf.e1stpom_2character_sap_lng_cd, rt.e1stpom_2character_sap_lng_cd) as e1stpom_2character_sap_lng_cd               
,coalesce(lf.e1stpom_leadtime_ofst_oprn_ts, rt.e1stpom_leadtime_ofst_oprn_ts) as e1stpom_leadtime_ofst_oprn_ts               
,coalesce(lf.e1stpom_unt_leadtime_ofst_oprn_ts, rt.e1stpom_unt_leadtime_ofst_oprn_ts) as e1stpom_unt_leadtime_ofst_oprn_ts           
,coalesce(lf.e1stpom_cls_3_nr, rt.e1stpom_cls_3_nr) as e1stpom_cls_3_nr        
,coalesce(lf.e1stpom_cmpnnt_qty_nm, rt.e1stpom_cmpnnt_qty_nm) as e1stpom_cmpnnt_qty_nm   
,coalesce(lf.e1stpom_cls_1_nr, rt.e1stpom_cls_1_nr) as e1stpom_cls_1_nr        
,coalesce(lf.e1stpom_qty_variablesize_it_1, rt.e1stpom_qty_variablesize_it_1) as e1stpom_qty_variablesize_it_1               
,coalesce(lf.e1stpom_prdn_sply_ar_nm, rt.e1stpom_prdn_sply_ar_nm) as e1stpom_prdn_sply_ar_nm 
,coalesce(lf.e1stpom_xtrn_idn_itm_id, rt.e1stpom_xtrn_idn_itm_id) as e1stpom_xtrn_idn_itm_id 
,coalesce(lf.e1stpom_guid_xtrn_dsply_char32_nm, rt.e1stpom_guid_xtrn_dsply_char32_nm) as e1stpom_guid_xtrn_dsply_char32_nm           
,coalesce(lf.e1stpom_spcl_prcmt_typ_bom_itm_cd, rt.e1stpom_spcl_prcmt_typ_bom_itm_cd) as e1stpom_spcl_prcmt_typ_bom_itm_cd           
,coalesce(lf.e1stpom_rfnc_pnt_bom_trnsfr_nm, rt.e1stpom_rfnc_pnt_bom_trnsfr_nm) as e1stpom_rfnc_pnt_bom_trnsfr_nm              
,coalesce(lf.e1stpom_lg_mtrl_fld_idnr_1_nr, rt.e1stpom_lg_mtrl_fld_idnr_1_nr) as e1stpom_lg_mtrl_fld_idnr_1_nr               
,coalesce(lf.e1stpom_vrsn_fld_idnr_1_nr, rt.e1stpom_vrsn_fld_idnr_1_nr) as e1stpom_vrsn_fld_idnr_1_nr  
,coalesce(lf.e1stpom_xtrn_guid_fld_idnrk_nm, rt.e1stpom_xtrn_guid_fld_idnrk_nm) as e1stpom_xtrn_guid_fld_idnrk_nm              
,coalesce(lf.e1stpom_lg_mtrl_fld_id_com_1_nr, rt.e1stpom_lg_mtrl_fld_id_com_1_nr) as e1stpom_lg_mtrl_fld_id_com_1_nr             
,coalesce(lf.e1stpom_vrsn_fld_id_com_1_nr, rt.e1stpom_vrsn_fld_id_com_1_nr) as e1stpom_vrsn_fld_id_com_1_nr 
,coalesce(lf.e1stpom_xtrn_guid_fld_id_comp_nm, rt.e1stpom_xtrn_guid_fld_id_comp_nm) as e1stpom_xtrn_guid_fld_id_comp_nm            
,coalesce(lf.e1stpom_lg_mtrl_fld_intr_1_nr, rt.e1stpom_lg_mtrl_fld_intr_1_nr) as e1stpom_lg_mtrl_fld_intr_1_nr               
,coalesce(lf.e1stpom_vrsn_fld_intr_1_nr, rt.e1stpom_vrsn_fld_intr_1_nr) as e1stpom_vrsn_fld_intr_1_nr  
,coalesce(lf.e1stpom_xtrn_guid_fld_intrm_nm, rt.e1stpom_xtrn_guid_fld_intrm_nm) as e1stpom_xtrn_guid_fld_intrm_nm              
,coalesce(lf.e1stpom_sgmtn_vl_nm, rt.e1stpom_sgmtn_vl_nm) as e1stpom_sgmtn_vl_nm     
,coalesce(lf.e1stpom_crtcl_cmpnnt_ind_cd, rt.e1stpom_crtcl_cmpnnt_ind_cd) as e1stpom_crtcl_cmpnnt_ind_cd 
,coalesce(lf.e1stpom_crtical_lvl_cmpnnt_bom, rt.e1stpom_crtical_lvl_cmpnnt_bom) as e1stpom_crtical_lvl_cmpnnt_bom              
,coalesce(lf.zstpo_ext_bom_cgy_cd, rt.zstpo_ext_bom_cgy_cd) as zstpo_ext_bom_cgy_cd    
,coalesce(lf.zstpo_ext_inrn_cntr_nr, rt.zstpo_ext_inrn_cntr_nr) as zstpo_ext_inrn_cntr_nr  
,coalesce(lf.zstpo_ext_valid_to_dt, rt.zstpo_ext_valid_to_dt) as zstpo_ext_valid_to_dt   
,coalesce(lf.zstpo_ext_bll_mtrl_cd, rt.zstpo_ext_bll_mtrl_cd) as zstpo_ext_bll_mtrl_cd   
,coalesce(lf.usr_who_crtd_re_3_cd, rt.usr_who_crtd_re_3_cd) as usr_who_crtd_re_3_cd    
,coalesce(lf.zstpo_ext_rec_upd_by, rt.zstpo_ext_rec_upd_by) as zstpo_ext_rec_upd_by    
,coalesce(lf.zstpo_ext_valkz_ind_cd, rt.zstpo_ext_valkz_ind_cd) as zstpo_ext_valkz_ind_cd  
,coalesce(lf.zstpo_ext_kznfp_ind_cd, rt.zstpo_ext_kznfp_ind_cd) as zstpo_ext_kznfp_ind_cd  
,coalesce(lf.itm_grp_cd, rt.itm_grp_cd) as itm_grp_cd              
,coalesce(lf.cmpnnt_vrnt_cd, rt.cmpnnt_vrnt_cd) as cmpnnt_vrnt_cd          
,coalesce(lf.zstpo_ext_rec_crtd_dt, rt.zstpo_ext_rec_crtd_dt) as zstpo_ext_rec_crtd_dt   
,coalesce(lf.zstpo_ext_rec_upd_dt, rt.zstpo_ext_rec_upd_dt) as zstpo_ext_rec_upd_dt    
,coalesce(lf.zstpo_ext_tchnl_stts_frm_cd, rt.zstpo_ext_tchnl_stts_frm_cd) as zstpo_ext_tchnl_stts_frm_cd 
,coalesce(lf.prdcsr_nde_nr, rt.prdcsr_nde_nr) as prdcsr_nde_nr           
,coalesce(lf.prv_itm_cnter_nr, rt.prv_itm_cnter_nr) as prv_itm_cnter_nr        
,coalesce(lf.issg_plnt_cd, rt.issg_plnt_cd) as issg_plnt_cd            
,coalesce(lf.followup_mtrl_bom_itm_not_use_cd, rt.followup_mtrl_bom_itm_not_use_cd) as followup_mtrl_bom_itm_not_use_cd            
,coalesce(lf.ztspo_ext_stvkn_inhrtd_nde_bom_itm_nr, rt.ztspo_ext_stvkn_inhrtd_nde_bom_itm_nr) as ztspo_ext_stvkn_inhrtd_nde_bom_itm_nr       
,coalesce(lf.zstpo_ext_last_shft_dt, rt.zstpo_ext_last_shft_dt) as zstpo_ext_last_shft_dt  
,coalesce(lf.zstpo_last_shft_dt_crrd_out_by, rt.zstpo_last_shft_dt_crrd_out_by) as zstpo_last_shft_dt_crrd_out_by              
,coalesce(lf.zstpo_ext_kndvb_ind_cd, rt.zstpo_ext_kndvb_ind_cd) as zstpo_ext_kndvb_ind_cd  
,coalesce(lf.zstpo_ext_kndbz_ind_cd, rt.zstpo_ext_kndbz_ind_cd) as zstpo_ext_kndbz_ind_cd  
,coalesce(lf.bom_cgy_orgl_sls_ord_itm_cd, rt.bom_cgy_orgl_sls_ord_itm_cd) as bom_cgy_orgl_sls_ord_itm_cd 
,coalesce(lf.bll_mtrl_orgl_sls_ord_itm_cd, rt.bll_mtrl_orgl_sls_ord_itm_cd) as bll_mtrl_orgl_sls_ord_itm_cd 
,coalesce(lf.nde_orgl_sls_ord_bom_itm_nr, rt.nde_orgl_sls_ord_bom_itm_nr) as nde_orgl_sls_ord_bom_itm_nr 
,coalesce(lf.cnter_orgl_sls_ord_itm_cd, rt.cnter_orgl_sls_ord_itm_cd) as cnter_orgl_sls_ord_itm_cd   
,coalesce(lf.zstpo_ext_shft_hrchy_ind_nr, rt.zstpo_ext_shft_hrchy_ind_nr) as zstpo_ext_shft_hrchy_ind_nr 
,coalesce(lf.h_cnter_nr, rt.h_cnter_nr) as h_cnter_nr              
,coalesce(lf.zstpo_ext_ale_ind_cd, rt.zstpo_ext_ale_ind_cd) as zstpo_ext_ale_ind_cd    
,coalesce(lf.temporarily_not_used_cd, rt.temporarily_not_used_cd) as temporarily_not_used_cd 
,coalesce(lf.sgmtn_mntd_components_cd, rt.sgmtn_mntd_components_cd) as sgmtn_mntd_components_cd 
,coalesce(lf.zstpo_ext_sgmtn_vl_cd, rt.zstpo_ext_sgmtn_vl_cd) as zstpo_ext_sgmtn_vl_cd   
,coalesce(lf.zstpo_ext_valid_to_rkey_dt, rt.zstpo_ext_valid_to_rkey_dt) as zstpo_ext_valid_to_rkey_dt  
,coalesce(lf.zstpo_ext_chg_nr_to_cd, rt.zstpo_ext_chg_nr_to_cd) as zstpo_ext_chg_nr_to_cd  
,coalesce(lf.zstpo_ext_chg_nr_to_1_cd, rt.zstpo_ext_chg_nr_to_1_cd) as zstpo_ext_chg_nr_to_1_cd 
,coalesce(lf.ztspo_ext_stvkn_vrsn_inhrtd_nde_bom_itm_nr, rt.ztspo_ext_stvkn_vrsn_inhrtd_nde_bom_itm_nr) as ztspo_ext_stvkn_vrsn_inhrtd_nde_bom_itm_nr  
,coalesce(lf.dta_elmt_extensibility_mnt_itm_cd, rt.dta_elmt_extensibility_mnt_itm_cd) as dta_elmt_extensibility_mnt_itm_cd           
,coalesce(lf.cu_cd, rt.cu_cd) as cu_cd   
,coalesce(lf.lgt_cltn_mtd_cd, rt.lgt_cltn_mtd_cd) as lgt_cltn_mtd_cd         
,coalesce(lf.mxm_prdn_lgth_nr, rt.mxm_prdn_lgth_nr) as mxm_prdn_lgth_nr        
,coalesce(lf.fx_scrp_any_lgt_nr, rt.fx_scrp_any_lgt_nr) as fx_scrp_any_lgt_nr      
,coalesce(lf.fx_scrp_frst_lgt_nr, rt.fx_scrp_frst_lgt_nr) as fx_scrp_frst_lgt_nr     
,coalesce(lf.fx_scrp_last_lgt_nr, rt.fx_scrp_last_lgt_nr) as fx_scrp_last_lgt_nr     
,coalesce(lf.runin_lgth_nr, rt.runin_lgth_nr) as runin_lgth_nr           
,coalesce(lf.rndg_vl_nr, rt.rndg_vl_nr) as rndg_vl_nr              
,coalesce(lf.dvt_vl_mntd_cmpnnt_at_vrnt_lvl_cd, rt.dvt_vl_mntd_cmpnnt_at_vrnt_lvl_cd) as dvt_vl_mntd_cmpnnt_at_vrnt_lvl_cd           
,coalesce(lf.qty_dbn_pfl_cd, rt.qty_dbn_pfl_cd) as qty_dbn_pfl_cd          
,coalesce(lf.rfnc_to_qty_dbn_pfl_cd, rt.rfnc_to_qty_dbn_pfl_cd) as rfnc_to_qty_dbn_pfl_cd  
,coalesce(lf.zstpo_ext_crtcl_cmpnnt_in_cd, rt.zstpo_ext_crtcl_cmpnnt_in_cd) as zstpo_ext_crtcl_cmpnnt_in_cd 
,coalesce(lf.zstpo_ext_crtcl_lvl_cmpnnt_bom_cd, rt.zstpo_ext_crtcl_lvl_cmpnnt_bom_cd) as zstpo_ext_crtcl_lvl_cmpnnt_bom_cd           
,coalesce(lf.fnctn_id, rt.fnctn_id) as fnctn_id 
,coalesce(lf.tbl_id_obj_id, rt.tbl_id_obj_id) as tbl_id_obj_id           
,coalesce(lf.zcuob_ext_obj_wth_asngd_dpnc_nr, rt.zcuob_ext_obj_wth_asngd_dpnc_nr) as zcuob_ext_obj_wth_asngd_dpnc_nr             
,coalesce(lf.zcuob_ext_inrn_kndg_elm_nr, rt.zcuob_ext_inrn_kndg_elm_nr) as zcuob_ext_inrn_kndg_elm_nr  
,coalesce(lf.zcuob_ext_inrn_cnter_archvng_obj_by_ec_nr, rt.zcuob_ext_inrn_cnter_archvng_obj_by_ec_nr) as zcuob_ext_inrn_cnter_archvng_obj_by_ec_nr   
,coalesce(lf.zcuob_ext_cnter_srtg_obj_alloc_cd, rt.zcuob_ext_cnter_srtg_obj_alloc_cd) as zcuob_ext_cnter_srtg_obj_alloc_cd           
,coalesce(lf.zcuob_ext_chg_nr_cd, rt.zcuob_ext_chg_nr_cd) as zcuob_ext_chg_nr_cd     
,coalesce(lf.zcuob_ext_valid_frm_dt, rt.zcuob_ext_valid_frm_dt) as zcuob_ext_valid_frm_dt  
,coalesce(lf.e1stpom1_mtr_1_nr, rt.e1stpom1_mtr_1_nr) as e1stpom1_mtr_1_nr       
,coalesce(lf.e1stpom1_bom_cmpnnt_nm, rt.e1stpom1_bom_cmpnnt_nm) as e1stpom1_bom_cmpnnt_nm  
,coalesce(lf.e1stpom1_intra_mtrl_nm, rt.e1stpom1_intra_mtrl_nm) as e1stpom1_intra_mtrl_nm  
,coalesce(lf.e1stpom1_sgmtn_vl_nm, rt.e1stpom1_sgmtn_vl_nm) as e1stpom1_sgmtn_vl_nm    
,coalesce(lf.e1cukbm_e1cukbm_fnctn_cd, rt.e1cukbm_e1cukbm_fnctn_cd) as e1cukbm_e1cukbm_fnctn_cd 
,coalesce(lf.e1cukbm_inrn_dpnc_1_nm, rt.e1cukbm_inrn_dpnc_1_nm) as e1cukbm_inrn_dpnc_1_nm  
,coalesce(lf.e1cukbm_xtrn_dpnc_1_nm, rt.e1cukbm_xtrn_dpnc_1_nm) as e1cukbm_xtrn_dpnc_1_nm  
,coalesce(lf.e1cukbm_dpncy_typ_cd, rt.e1cukbm_dpncy_typ_cd) as e1cukbm_dpncy_typ_cd    
,coalesce(lf.dpncy_stts_cd, rt.dpncy_stts_cd) as dpncy_stts_cd           
,coalesce(lf.dpncy_grp_nm, rt.dpncy_grp_nm) as dpncy_grp_nm            
,coalesce(lf.athzn_to_mnt_obj_dpncs_objects_cd, rt.athzn_to_mnt_obj_dpncs_objects_cd) as athzn_to_mnt_obj_dpncs_objects_cd           
,coalesce(lf.cnter_srtg_obj_allocations_nr, rt.cnter_srtg_obj_allocations_nr) as cnter_srtg_obj_allocations_nr               
,coalesce(lf.e1cukbm_dltn_ind_cd, rt.e1cukbm_dltn_ind_cd) as e1cukbm_dltn_ind_cd     
,coalesce(lf.dpncy_typ_splmnt_cd, rt.dpncy_typ_splmnt_cd) as dpncy_typ_splmnt_cd     
,coalesce(lf.e1cukbm_ind_cd, rt.e1cukbm_ind_cd) as e1cukbm_ind_cd          
,coalesce(lf.zcukb_ext_inrn_kndg_elm_nr, rt.zcukb_ext_inrn_kndg_elm_nr) as zcukb_ext_inrn_kndg_elm_nr  
,coalesce(lf.zcukb_ext_inrn_cnter_archvng_obj_by_ec_nr, rt.zcukb_ext_inrn_cnter_archvng_obj_by_ec_nr) as zcukb_ext_inrn_cnter_archvng_obj_by_ec_nr   
,coalesce(lf.zcukb_ext_dpncy_typ_splmnt_cd, rt.zcukb_ext_dpncy_typ_splmnt_cd) as zcukb_ext_dpncy_typ_splmnt_cd               
,coalesce(lf.zstpo_ext_kzsoft_ind_cd, rt.zstpo_ext_kzsoft_ind_cd) as zstpo_ext_kzsoft_ind_cd 
,coalesce(lf.inrn_vrsn_obj_dpncy_nr, rt.inrn_vrsn_obj_dpncy_nr) as inrn_vrsn_obj_dpncy_nr  
,coalesce(lf.sfx_inrn_vrsn_asngmt_dpncy_cd, rt.sfx_inrn_vrsn_asngmt_dpncy_cd) as sfx_inrn_vrsn_asngmt_dpncy_cd               
,coalesce(lf.zstpo_ext_knsce_ind_cd, rt.zstpo_ext_knsce_ind_cd) as zstpo_ext_knsce_ind_cd  
,coalesce(lf.crtn_dt, rt.crtn_dt) as crtn_dt 
,coalesce(lf.dpndncy_crtd_by, rt.dpndncy_crtd_by) as dpndncy_crtd_by         
,coalesce(lf.zcukb_ext_rec_upd_dt, rt.zcukb_ext_rec_upd_dt) as zcukb_ext_rec_upd_dt    
,coalesce(lf.last_upd_by, rt.last_upd_by) as last_upd_by             
,coalesce(lf.zcukb_ext_chg_nr_cd, rt.zcukb_ext_chg_nr_cd)  as zcukb_ext_chg_nr_cd     
,coalesce(lf.zcukb_ext_valid_frm_dt, rt.zcukb_ext_valid_frm_dt) as zcukb_ext_valid_frm_dt  
,coalesce(lf.e1cukbt_e1cukbt_fnctn_cd, rt.e1cukbt_e1cukbt_fnctn_cd) as e1cukbt_e1cukbt_fnctn_cd 
,coalesce(lf.e1cukbt_lng_ky_ind, rt.e1cukbt_lng_ky_ind) as e1cukbt_lng_ky_ind      
,coalesce(lf.dpncy_dn_nm, rt.dpncy_dn_nm) as dpncy_dn_nm             
,coalesce(lf.e1cukbt_dltn_ind_cd, rt.e1cukbt_dltn_ind_cd) as e1cukbt_dltn_ind_cd     
,coalesce(lf.e1cukbt_2character_sap_lng_cd, rt.e1cukbt_2character_sap_lng_cd) as e1cukbt_2character_sap_lng_cd               
,coalesce(lf.e1cuknm_e1cuknm_fnctn_cd, rt.e1cuknm_e1cuknm_fnctn_cd) as e1cuknm_e1cuknm_fnctn_cd 
,coalesce(lf.ln_obj_dpncy_src_72_characters_nm, rt.ln_obj_dpncy_src_72_characters_nm) as ln_obj_dpncy_src_72_characters_nm           
,coalesce(lf.e1cutxm_e1cutxm_fnctn_cd, rt.e1cutxm_e1cutxm_fnctn_cd) as e1cutxm_e1cutxm_fnctn_cd 
,coalesce(lf.e1cutxm_lng_ky_ind, rt.e1cutxm_lng_ky_ind) as e1cutxm_lng_ky_ind      
,coalesce(lf.e1cutxm_tg_cl_cd, rt.e1cutxm_tg_cl_cd)   as e1cutxm_tg_cl_cd        
,coalesce(lf.e1cutxm_txt_ln_nm, rt.e1cutxm_txt_ln_nm)  as e1cutxm_txt_ln_nm       
,coalesce(lf.e1cutxm_2character_sap_lng_cd, rt.e1cutxm_2character_sap_lng_cd) as e1cutxm_2character_sap_lng_cd               
,coalesce(lf.e1spoth_e1spoth_fnctn_cd, rt.e1spoth_e1spoth_fnctn_cd) as e1spoth_e1spoth_fnctn_cd 
,coalesce(lf.e1spot_1_nm, rt.e1spot_1_nm) as e1spot_1_nm             
,coalesce(lf.e1spoth_txt_id_id, rt.e1spoth_txt_id_id) as e1spoth_txt_id_id       
,coalesce(lf.e1spoth_lng_ky_ind, rt.e1spoth_lng_ky_ind) as e1spoth_lng_ky_ind      
,coalesce(lf.e1spoth_2character_sap_lng_cd, rt.e1spoth_2character_sap_lng_cd) as e1spoth_2character_sap_lng_cd               
,coalesce(lf.e1spotl_tg_cl_cd, rt.e1spotl_tg_cl_cd) as e1spotl_tg_cl_cd        
,coalesce(lf.e1spotl_txt_ln_nm, rt.e1spotl_txt_ln_nm) as e1spotl_txt_ln_nm       
,coalesce(lf.e1stpum_e1stpum_fnctn_cd, rt.e1stpum_e1stpum_fnctn_cd) as e1stpum_e1stpum_fnctn_cd 
,coalesce(lf.e1stpum_bom_itm_nde_nr, rt.e1stpum_bom_itm_nde_nr) as e1stpum_bom_itm_nde_nr  
,coalesce(lf.e1stpum_subitem_qt_1, rt.e1stpum_subitem_qt_1) as e1stpum_subitem_qt_1    
,coalesce(lf.e1stpum_instln_pnt_subitem_nm, rt.e1stpum_instln_pnt_subitem_nm) as e1stpum_instln_pnt_subitem_nm               
,coalesce(lf.e1stpum_bom_subitem_txt_nm, rt.e1stpum_bom_subitem_txt_nm) as e1stpum_bom_subitem_txt_nm  
,coalesce(lf.subitem_qty_nm, rt.subitem_qty_nm) as subitem_qty_nm          
,coalesce(lf.e1sgtbom_e1sgtbom_fnctn_cd, rt.e1sgtbom_e1sgtbom_fnctn_cd) as e1sgtbom_e1sgtbom_fnctn_cd  
,coalesce(lf.e1sgtbom_sgmtn_vl_nm, rt.e1sgtbom_sgmtn_vl_nm) as e1sgtbom_sgmtn_vl_nm    
,coalesce(lf.e1sgtbom_sgmt_2_cd, rt.e1sgtbom_sgmt_2_cd) as e1sgtbom_sgmt_2_cd      
,coalesce(lf.e1sgtbom_sgmt_1_cd, rt.e1sgtbom_sgmt_1_cd) as e1sgtbom_sgmt_1_cd      
,coalesce(lf.e1sgtbom_sgmtn_vl_cd, rt.e1sgtbom_sgmtn_vl_cd) as e1sgtbom_sgmtn_vl_cd    
,coalesce(lf.e1fshbom_e1fshbom_fnctn_cd, rt.e1fshbom_e1fshbom_fnctn_cd) as e1fshbom_e1fshbom_fnctn_cd  
,coalesce(lf.e1fshbom_mtrl_18_characters_nr, rt.e1fshbom_mtrl_18_characters_nr) as e1fshbom_mtrl_18_characters_nr              
,coalesce(lf.e1fshbom_bom_cmpnnt_nm, rt.e1fshbom_bom_cmpnnt_nm) as e1fshbom_bom_cmpnnt_nm  
,coalesce(lf.e1fshbom_cmpnnt_qty, rt.e1fshbom_cmpnnt_qty) as e1fshbom_cmpnnt_qty     
,coalesce(lf.e1fshbom_crtcl_cmpnnt_ind_cd, rt.e1fshbom_crtcl_cmpnnt_ind_cd) as e1fshbom_crtcl_cmpnnt_ind_cd 
,coalesce(lf.e1fshbom_crtical_lvl_cmpnnt_bom, rt.e1fshbom_crtical_lvl_cmpnnt_bom) as e1fshbom_crtical_lvl_cmpnnt_bom             
,coalesce(lf.e1fshbom_lg_mtrl_mtrl_fld_nr, rt.e1fshbom_lg_mtrl_mtrl_fld_nr) as e1fshbom_lg_mtrl_mtrl_fld_nr 
,coalesce(lf.e1fshbom_vrsn_mtrl_fld_nr, rt.e1fshbom_vrsn_mtrl_fld_nr) as e1fshbom_vrsn_mtrl_fld_nr   
,coalesce(lf.e1fshbom_xtrn_guid_mtrl_fld_nm, rt.e1fshbom_xtrn_guid_mtrl_fld_nm) as e1fshbom_xtrn_guid_mtrl_fld_nm              
,coalesce(lf.lg_mtrl_cmpnnt_fld_nr, rt.lg_mtrl_cmpnnt_fld_nr) as lg_mtrl_cmpnnt_fld_nr   
,coalesce(lf.vrsn_cmpnnt_fld_nr, rt.vrsn_cmpnnt_fld_nr) as vrsn_cmpnnt_fld_nr      
,coalesce(lf.xtrn_guid_cmpnnt_fld_nm, rt.xtrn_guid_cmpnnt_fld_nm) as xtrn_guid_cmpnnt_fld_nm 
,coalesce(lf.e1fshbom_mtrl_nr, rt.e1fshbom_mtrl_nr) as e1fshbom_mtrl_nr        
,coalesce(lf.e1fshbom_bom_cmpnnt_cd, rt.e1fshbom_bom_cmpnnt_cd) as e1fshbom_bom_cmpnnt_cd  
,coalesce(lf.e1upslink_ale_dbn_packe_5_nm, rt.e1upslink_ale_dbn_packe_5_nm) as e1upslink_ale_dbn_packe_5_nm 
,coalesce(lf.e1upslink_ale_dbn_packe_3_nm, rt.e1upslink_ale_dbn_packe_3_nm) as e1upslink_ale_dbn_packe_3_nm 
,coalesce(lf.e1upslink_msg_typ_nm, rt.e1upslink_msg_typ_nm) as e1upslink_msg_typ_nm    
,coalesce(lf.e1upslink_ale_dbn_packe_1_nm, rt.e1upslink_ale_dbn_packe_1_nm) as e1upslink_ale_dbn_packe_1_nm 
,coalesce(lf.ale_dbn_pkg_nm,rt.ale_dbn_pkg_nm) as ale_dbn_pkg_nm          
,lf.intgtn_fbrc_msg_id
,lf.src_sys_upd_ts
,lf.src_sys_ky
,lf.lgcl_dlt_ind
,lf.ins_gmt_ts
,lf.upd_gmt_ts
,lf.src_sys_extrc_gmt_ts
,lf.src_sys_btch_nr
,lf.fl_nm
,lf.ld_jb_nr 
,lf.ins_gmt_dt
from mfrg_bom_ref_left lf 
left join mfrg_bom_ref_right rt
on lf.e1stzum_bll_mtrl_cd=rt.e1stzum_bll_mtrl_cd and lf.idoc_nr=rt.idoc_nr""")

      bomIncrementalJoinDf.createOrReplaceTempView("mfrg_bom_ref_temp")

      val bomIncrementalRankDf = spark.sql("""select a.*, case when a.zcukb_ext_inrn_kndg_elm_nr is not null and a.zcuob_ext_inrn_kndg_elm_nr is null then '1' else '0' end as extra_record from 
(select * , 
row_number() over (partition by e1mastm_mtrl_18_Characters_nr, 
e1mastm_plnt_cd, 
e1mastm_bom_usg_cd, 
e1mastm_bll_mtrl_cd,
e1stpom_bom_itm_nde_nr, 
e1stpom_bom_cmpnnt_nm, 
e1stpom_bom_itm_txt_ln_1_nm ,
e1mastm_altv_bom_cd, 
e1stpom_ValidFrom_dt,
e1stpom_bom_it_2_nr,
e1cukbm_inrn_dpnc_1_nm,
zcuob_ext_inrn_kndg_elm_nr,
zcukb_ext_inrn_kndg_elm_nr order by src_sys_btch_nr desc,upd_gmt_ts desc,ins_gmt_ts desc) as rownum
from mfrg_bom_ref_temp ) a
where a.rownum = 1 and e1mastm_mtrl_18_Characters_nr is not null and e1mastm_plnt_cd is not null and e1stpom_bom_itm_nde_nr is not null""")

      bomIncrementalRankDf.createOrReplaceTempView("mfrg_bom_ref_rnk_temp")

      val bomIncrementalCUKBDf = spark.sql("""SELECT 
idoc_nr,
e1mastm_mtrl_18_Characters_nr, 
e1mastm_plnt_cd, 
e1mastm_bom_usg_cd, 
e1mastm_bll_mtrl_cd,
e1stzum_bll_mtrl_cd,
e1mastm_altv_bom_cd, 
e1stpom_bom_itm_nde_nr,
e1stpom_bom_cmpnnt_nm,
e1stpom_bom_itm_txt_ln_1_nm,
e1cukbm_e1cukbm_fnctn_cd,
e1cukbm_inrn_dpnc_1_nm,
e1cukbm_xtrn_dpnc_1_nm,
e1cukbm_dpncy_typ_cd,
dpncy_stts_cd,
dpncy_grp_nm,
athzn_to_mnt_obj_dpncs_objects_cd,
cnter_srtg_obj_allocations_nr,
e1cukbm_dltn_ind_cd,
dpncy_typ_splmnt_cd,
e1cukbm_ind_cd,
zcukb_ext_inrn_kndg_elm_nr,
zcukb_ext_inrn_cnter_archvng_obj_by_ec_nr,
zcukb_ext_dpncy_typ_splmnt_cd,
zstpo_ext_kzsoft_ind_cd,
inrn_vrsn_obj_dpncy_nr,
sfx_inrn_vrsn_asngmt_dpncy_cd,
zstpo_ext_knsce_ind_cd,
crtn_dt,
dpndncy_crtd_by,
zcukb_ext_rec_upd_dt,
last_upd_by,
zcukb_ext_chg_nr_cd,
zcukb_ext_valid_frm_dt,
e1cukbt_e1cukbt_fnctn_cd,
e1cukbt_lng_ky_ind,
dpncy_dn_nm,
e1cukbt_dltn_ind_cd,
e1cukbt_2character_sap_lng_cd
from mfrg_bom_ref_rnk_temp where zcukb_ext_inrn_kndg_elm_nr is not null""").distinct()

      bomIncrementalCUKBDf.createOrReplaceTempView("mfrg_bom_ref_cukb_temp")

      bomIncrementalFinalDf = spark.sql("""SELECT md5(concat(upper(coalesce(a.e1mastm_mtrl_18_Characters_nr,'')), 
upper(coalesce(a.e1mastm_plnt_cd,'')), 
upper(coalesce(a.e1mastm_bom_usg_cd,'')), 
upper(coalesce(a.e1mastm_bll_mtrl_cd,'')),
upper(coalesce(a.e1mastm_altv_bom_cd,'')),
upper(coalesce(cast(a.e1stpom_bom_itm_nde_nr as string),'')), 
upper(coalesce(a.e1stpom_bom_cmpnnt_nm,'')), 
upper(coalesce(a.e1stpom_bom_itm_txt_ln_1_nm,'')),
upper(coalesce(cast(a.e1stpom_ValidFrom_dt as string),'')), 
upper(coalesce(a.e1stpom_bom_it_2_nr,'')),
upper(coalesce(a.e1cukbm_inrn_dpnc_1_nm,'')),
upper(coalesce(a.zcuob_ext_inrn_kndg_elm_nr,'')),
upper(coalesce(b.zcukb_ext_inrn_kndg_elm_nr,'')))) as mfrg_bom_md5_ky,
crc32(concat(upper(coalesce(a.e1mastm_mtrl_18_Characters_nr,'')), 
upper(coalesce(a.e1mastm_plnt_cd,'')), 
upper(coalesce(a.e1mastm_bom_usg_cd,'')), 
upper(coalesce(a.e1mastm_bll_mtrl_cd,'')),
upper(coalesce(a.e1mastm_altv_bom_cd,'')),
upper(coalesce(cast(a.e1stpom_bom_itm_nde_nr as string),'')), 
upper(coalesce(a.e1stpom_bom_cmpnnt_nm,'')), 
upper(coalesce(a.e1stpom_bom_itm_txt_ln_1_nm,'')),
upper(coalesce(cast(a.e1stpom_ValidFrom_dt as string),'')), 
upper(coalesce(a.e1stpom_bom_it_2_nr,'')),
upper(coalesce(a.e1cukbm_inrn_dpnc_1_nm,'')),
upper(coalesce(a.zcuob_ext_inrn_kndg_elm_nr,'')),
upper(coalesce(b.zcukb_ext_inrn_kndg_elm_nr,'')))) as mfrg_bom_ky,
a.idoc_nr,
a.e1stzum_e1stzum_fnctn_cd,
a.e1stzum_bom_cgy_cd,
a.e1stzum_bll_mtrl_cd,
a.e1stzum_bom_usg_cd,
a.e1stzum_bom_gr_2_nm,
a.e1stzum_in_1_cd,
a.e1stzum_in_4_cd,
a.e1stzum_in_2_cd,
a.e1stzum_lng_ind,
a.athzn_grp_bills_mtrl_cd,
a.bom_txt_nm,
a.last_chg_nr,
a.bom_last_chgd_dt,
a.tm_when_bom_last_chgd_ts,
a.e1stzum_2character_sap_lng_cd,
a.e1stzum_bom_gr_1_nm,
a.zstzu_ext_plnt_whr_vrnt_crtd_cd,
a.zstzu_ext_hisdt_ind_cd,
a.zstzu_ext_hissr_ind_cd,
a.zstzu_ext_histk_ind_cd,
a.mxm_counters_nr,
a.mxm_nodes_within_nr,
a.zstzu_ext_kzpln_ind_cd,
a.mxm_clsfn_nr,
a.mxm_edge_nr,
a.tm_stamp_nr,
a.zstzu_ext_versnind_ind_cd,
a.e1szuth_e1szuth_fnctn_cd,
a.e1szut_1_nm,
a.e1szuth_txt_id_id,
a.e1szuth_lng_ky_ind,
a.e1szuth_2character_sap_lng_cd,
a.e1szutl_tg_cl_cd,
a.e1szutl_txt_ln_nm,
a.e1mastm_e1mastm_fnctn_cd,
coalesce(a.e1mastm_mtrl_18_characters_nr,'') as e1mastm_mtrl_18_characters_nr,
coalesce(a.e1mastm_plnt_cd,'') as e1mastm_plnt_cd,
coalesce(a.e1mastm_bom_usg_cd,'') as e1mastm_bom_usg_cd,
coalesce(a.e1mastm_bll_mtrl_cd,'') as e1mastm_bll_mtrl_cd,
coalesce(a.e1mastm_altv_bom_cd,'') as e1mastm_altv_bom_cd,
a.e1mastm_frm_lt_s_1,
a.e1mastm_to_lt_s_1,
a.e1mastm_ind_cd,
a.e1mastm_mtr_3_nr,
a.e1mastm_vrsn_matnr_fl_1_nr,
a.e1mastm_xtrn_guid_matnr_fld_nm,
a.e1mastm_mtr_5_nr,
a.zmast_ext_rec_crtd_by,
a.zmast_ext_rec_upd_by,
a.zmast_ext_rec_crtd_dt,
a.zmast_ext_rec_upd_dt,
a.zmast_ext_dltn_ind_cd,
a.e1t415b_e1t415b_fnctn_cd,
a.e1t415b_mtrl_18_characters_nr,
a.e1t415b_bom_usg_cd,
a.e1t415b_bs_unt_msr_bom,
a.e1t415b_altv_bom_cd,
a.e1t415b_mtr_1_nr,
a.e1t415b_vrsn_matnr_fl_3_nr,
a.e1t415b_xtrn_guid_matnr_fld_nm,
a.e1t415b_mtr_3_nr,
a.e1stkom_e1stkom_fnctn_cd,
a.e1stkom_altv_bom_cd,
a.e1stkom_validfrom_dt,
a.e1stkom_chg_nr,
a.e1stkom_dltn_flg_boms_cd,
a.e1stkom_unt_msr_bs_qty,
a.e1stkom_cfrd_qt_1,
a.e1stkom_cad_ind_cd,
a.e1stkom_laboratorydesign_ofc_cd,
a.e1stkom_lng_ind,
a.e1stkom_altv_bom_txt_nm,
a.e1stkom_bom_stts,
a.e1stkom_2character_sap_lng_cd,
a.e1stkom_bs_qty_nm,
a.e1stkom_guid_xtrn_dsply_char32_nm,
a.zstko_ext_bll_mtrl_cd,
a.zstko_ext_bom_cgy_cd,
a.zstko_ext_inrn_cntr_nr,
a.zstko_ext_valid_to_dt,
a.zstko_ext_rec_crtd_by,
a.zstko_ext_rec_upd_by,
a.zstko_ext_plnt_whr_vrnt_crtd_cd,
a.bom_vrsn_cd,
a.bom_vrsn_stts_cd,
a.zstko_ext_versnlastind_ind_cd,
a.zstko_ext_rec_crtd_dt,
a.zstko_ext_rec_upd_dt,
a.zstko_ext_tchnl_stts_frm_cd,
a.prv_hdr_cnter_nr,
a.zstko_ext_last_shft_dt,
a.zstko_last_shft_dt_crrd_out_by,
a.zstko_ext_shft_hrchy_ind_nr,
a.zstko_ext_ale_ind_cd,
a.zstko_ext_chg_nr_to_cd,
a.dta_elmt_extensibility_mnt_hdr_cd,
a.e1skoth_e1skoth_fnctn_cd,
a.e1skot_1_nm,
a.e1skoth_txt_id_id,
a.e1skoth_lng_ky_ind,
a.e1skoth_2character_sap_lng_cd,
a.e1skotl_tg_cl_cd,
a.e1skotl_txt_ln_nm,
a.e1stasm_e1stasm_fnctn_cd,
a.e1stasm_altv_bom_cd,
a.e1stasm_bom_itm_nde_nr,
a.e1stasm_validfrom_dt,
a.e1stasm_chg_nr,
a.e1stasm_dltn_ind_cd,
a.inherited_nde_bom_itm_nr,
a.e1stpom_e1stpom_fnctn_cd,
coalesce(a.e1stpom_bom_itm_nde_nr,'') as e1stpom_bom_itm_nde_nr,
a.e1stpom_itm_cgy_bll_mtr_1_cd,
a.e1stpom_bom_it_1_nr,
a.e1stpom_mtrl_18_characters_nr,
a.e1stpom_cls_2_nr,
a.e1stpom_clss_ty_1_cd,
a.e1stpom_dcm_2_nr,
a.e1stpom_dcmt_ty_2_cd,
a.e1stpom_dcmt_pr_2_cd,
a.e1stpom_dcmt_vrs_2_cd,
a.e1stpom_srt_str_6_nm,
coalesce(a.e1stpom_validfrom_dt,'') as e1stpom_validfrom_dt,
a.e1stpom_chg_nr,
a.e1stpom_dltn_ind_cd,
coalesce(a.e1stpom_bom_cmpnnt_nm,'') as e1stpom_bom_cmpnnt_nm,
a.e1stpom_itm_cgy_bll_mtr_2_cd,
coalesce(a.e1stpom_bom_it_2_nr,'') as e1stpom_bom_it_2_nr,
a.e1stpom_srt_str_5_nm,
a.e1stpom_bs_unt_msr,
a.e1stpom_qt_1,
a.e1stpom_fx_qty_cd,
a.e1stpom_cmpnnt_scrp_prct,
a.e1stpom_oprn_scrp,
a.e1stpom_nt_scrp_ind_cd,
a.e1stpom_in_9_cd,
a.e1stpom_mtrl_prvn_ind_cd,
a.e1stpom_in_3_cd,
a.e1stpom_in_5_cd,
a.e1stpom_in_4_cd,
a.e1stpom_in_18_cd,
a.e1stpom_in_6_cd,
a.e1stpom_in_7_cd,
a.e1stpom_in_8_cd,
a.e1stpom_pm_asmy_ind_cd,
a.e1stpom_in_19_cd,
a.e1stpom_in_20_cd,
a.e1stpom_cad_ind_cd,
a.e1stpom_leadtime_ofst_ts,
a.e1stpom_dbn_ky_cmpnnt_cnsmpn_cd,
a.e1stpom_in_17_cd,
a.e1stpom_usg_prblty__altv_itm,
a.e1stpom_prchg_grp_cd,
a.e1stpom_dlvry_tm_dys_dt,
a.e1stpom_e1stpom_acct_vndr_crdt_3_nr,
a.e1stpom_pr_1,
a.e1stpom_prc_unt,
a.e1stpom_threedigit_chr_fld_idocs_id,
a.e1stpom_cst_elmt_nm,
a.e1stpom_variablesize_itm_1_nr,
a.e1stpom_sz__1,
a.e1stpom_sz__3,
a.e1stpom_sz__2,
a.e1stpom_unt_msr_sizes_1_to_3,
a.e1stpom_qty_variablesize_it_3,
a.e1stpom_fml_ky_cd,
a.e1stpom_in_13_cd,
a.e1stpom_lng_ind,
coalesce(a.e1stpom_bom_itm_txt_ln_1_nm,'') as e1stpom_bom_itm_txt_ln_1_nm,
a.e1stpom_bom_itm_txt_ln_2_nm,
a.e1stpom_obj_typ_bom_itm_cd,
a.e1stpom_mtrl_grp_cd,
a.e1stpom_gds_rcpt_prsng_tm_dys_dt,
a.e1stpom_dcmt_ty_1_cd,
a.e1stpom_dcm_1_nr,
a.e1stpom_dcmt_vrs_1_cd,
a.e1stpom_dcmt_pr_1_cd,
a.e1stpom_avg_mtrl_purity_,
a.e1stpom_plng_prm_clss_cd,
a.e1stpom_clss_ty_2_cd,
a.e1stpom_resulting_itm_cgy_cd,
a.e1stpom_slctn_ind_cnfgl_boms_cd,
a.e1stpom_insn_ind_cd,
a.e1stpom_in_15_cd,
a.e1stpom_in_16_cd,
a.e1stpom_in_14_cd,
a.e1stpom_prchg_org_cd,
a.e1stpom_rqrd_cmpnnt_cd,
a.e1stpom_mltpl_slctn_allwd_cd,
a.e1stpom_altv_dsply_frmt_cd,
a.e1stpom_orgnl_ar_nm,
a.e1stpom_obj_wth_asngd_dpncs_nr,
a.e1stpom_iss_lctn_prdn_ord_cd,
a.e1stpom_in_21_cd,
a.e1stpom_intra_mtrl_nm,
a.e1stpom_in_10_cd,
a.e1stpom_explsn_typ_cd,
a.e1stpom_altv_it_2_cd,
a.e1stpom_altv_itm,
a.e1stpom_altv_it_1_cd,
a.e1stpom_followup_grp_cd,
a.e1stpom_discontinuation_grp_cd,
a.e1stpom_clsfn_nr,
a.e1stpom_in_22_cd,
a.e1stpom_2character_sap_lng_cd,
a.e1stpom_leadtime_ofst_oprn_ts,
a.e1stpom_unt_leadtime_ofst_oprn_ts,
a.e1stpom_cls_3_nr,
a.e1stpom_cmpnnt_qty_nm,
a.e1stpom_cls_1_nr,
a.e1stpom_qty_variablesize_it_1,
a.e1stpom_prdn_sply_ar_nm,
a.e1stpom_xtrn_idn_itm_id,
a.e1stpom_guid_xtrn_dsply_char32_nm,
a.e1stpom_spcl_prcmt_typ_bom_itm_cd,
a.e1stpom_rfnc_pnt_bom_trnsfr_nm,
a.e1stpom_lg_mtrl_fld_idnr_1_nr,
a.e1stpom_vrsn_fld_idnr_1_nr,
a.e1stpom_xtrn_guid_fld_idnrk_nm,
a.e1stpom_lg_mtrl_fld_id_com_1_nr,
a.e1stpom_vrsn_fld_id_com_1_nr,
a.e1stpom_xtrn_guid_fld_id_comp_nm,
a.e1stpom_lg_mtrl_fld_intr_1_nr,
a.e1stpom_vrsn_fld_intr_1_nr,
a.e1stpom_xtrn_guid_fld_intrm_nm,
a.e1stpom_sgmtn_vl_nm,
a.e1stpom_crtcl_cmpnnt_ind_cd,
a.e1stpom_crtical_lvl_cmpnnt_bom,
a.zstpo_ext_bom_cgy_cd,
a.zstpo_ext_inrn_cntr_nr,
a.zstpo_ext_valid_to_dt,
a.zstpo_ext_bll_mtrl_cd,
a.usr_who_crtd_re_3_cd,
a.zstpo_ext_rec_upd_by,
a.zstpo_ext_valkz_ind_cd,
a.zstpo_ext_kznfp_ind_cd,
a.itm_grp_cd,
a.cmpnnt_vrnt_cd,
a.zstpo_ext_rec_crtd_dt,
a.zstpo_ext_rec_upd_dt,
a.zstpo_ext_tchnl_stts_frm_cd,
a.prdcsr_nde_nr,
a.prv_itm_cnter_nr,
a.issg_plnt_cd,
a.followup_mtrl_bom_itm_not_use_cd,
a.ztspo_ext_stvkn_inhrtd_nde_bom_itm_nr,
a.zstpo_ext_last_shft_dt,
a.zstpo_last_shft_dt_crrd_out_by,
a.zstpo_ext_kndvb_ind_cd,
a.zstpo_ext_kndbz_ind_cd,
a.bom_cgy_orgl_sls_ord_itm_cd,
a.bll_mtrl_orgl_sls_ord_itm_cd,
a.nde_orgl_sls_ord_bom_itm_nr,
a.cnter_orgl_sls_ord_itm_cd,
a.zstpo_ext_shft_hrchy_ind_nr,
a.h_cnter_nr,
a.zstpo_ext_ale_ind_cd,
a.temporarily_not_used_cd,
a.sgmtn_mntd_components_cd,
a.zstpo_ext_sgmtn_vl_cd,
a.zstpo_ext_valid_to_rkey_dt,
a.zstpo_ext_chg_nr_to_cd,
a.zstpo_ext_chg_nr_to_1_cd,
a.ztspo_ext_stvkn_vrsn_inhrtd_nde_bom_itm_nr,
a.dta_elmt_extensibility_mnt_itm_cd,
a.cu_cd,
a.lgt_cltn_mtd_cd,
a.mxm_prdn_lgth_nr,
a.fx_scrp_any_lgt_nr,
a.fx_scrp_frst_lgt_nr,
a.fx_scrp_last_lgt_nr,
a.runin_lgth_nr,
a.rndg_vl_nr,
a.dvt_vl_mntd_cmpnnt_at_vrnt_lvl_cd,
a.qty_dbn_pfl_cd,
a.rfnc_to_qty_dbn_pfl_cd,
a.zstpo_ext_crtcl_cmpnnt_in_cd,
a.zstpo_ext_crtcl_lvl_cmpnnt_bom_cd,
a.fnctn_id,
a.tbl_id_obj_id,
a.zcuob_ext_obj_wth_asngd_dpnc_nr,
coalesce(a.zcuob_ext_inrn_kndg_elm_nr,'') as zcuob_ext_inrn_kndg_elm_nr,
a.zcuob_ext_inrn_cnter_archvng_obj_by_ec_nr,
a.zcuob_ext_cnter_srtg_obj_alloc_cd,
a.zcuob_ext_chg_nr_cd,
a.zcuob_ext_valid_frm_dt,
a.e1stpom1_mtr_1_nr,
a.e1stpom1_bom_cmpnnt_nm,
a.e1stpom1_intra_mtrl_nm,
a.e1stpom1_sgmtn_vl_nm,
b.e1cukbm_e1cukbm_fnctn_cd,
coalesce(b.e1cukbm_inrn_dpnc_1_nm,'') as e1cukbm_inrn_dpnc_1_nm,
b.e1cukbm_xtrn_dpnc_1_nm,
b.e1cukbm_dpncy_typ_cd,
b.dpncy_stts_cd,
b.dpncy_grp_nm,
b.athzn_to_mnt_obj_dpncs_objects_cd,
b.cnter_srtg_obj_allocations_nr,
b.e1cukbm_dltn_ind_cd,
b.dpncy_typ_splmnt_cd,
b.e1cukbm_ind_cd,
coalesce(b.zcukb_ext_inrn_kndg_elm_nr,'') as zcukb_ext_inrn_kndg_elm_nr,
b.zcukb_ext_inrn_cnter_archvng_obj_by_ec_nr,
b.zcukb_ext_dpncy_typ_splmnt_cd,
b.zstpo_ext_kzsoft_ind_cd,
b.inrn_vrsn_obj_dpncy_nr,
b.sfx_inrn_vrsn_asngmt_dpncy_cd,
b.zstpo_ext_knsce_ind_cd,
b.crtn_dt,
b.dpndncy_crtd_by,
b.zcukb_ext_rec_upd_dt,
b.last_upd_by,
b.zcukb_ext_chg_nr_cd,
b.zcukb_ext_valid_frm_dt,
b.e1cukbt_e1cukbt_fnctn_cd,
b.e1cukbt_lng_ky_ind,
b.dpncy_dn_nm,
b.e1cukbt_dltn_ind_cd,
b.e1cukbt_2character_sap_lng_cd,
a.e1cuknm_e1cuknm_fnctn_cd,
a.ln_obj_dpncy_src_72_characters_nm,
a.e1cutxm_e1cutxm_fnctn_cd,
a.e1cutxm_lng_ky_ind,
a.e1cutxm_tg_cl_cd,
a.e1cutxm_txt_ln_nm,
a.e1cutxm_2character_sap_lng_cd,
a.e1spoth_e1spoth_fnctn_cd,
a.e1spot_1_nm,
a.e1spoth_txt_id_id,
a.e1spoth_lng_ky_ind,
a.e1spoth_2character_sap_lng_cd,
a.e1spotl_tg_cl_cd,
a.e1spotl_txt_ln_nm,
a.e1stpum_e1stpum_fnctn_cd,
a.e1stpum_bom_itm_nde_nr,
a.e1stpum_subitem_qt_1,
a.e1stpum_instln_pnt_subitem_nm,
a.e1stpum_bom_subitem_txt_nm,
a.subitem_qty_nm,
a.e1sgtbom_e1sgtbom_fnctn_cd,
a.e1sgtbom_sgmtn_vl_nm,
a.e1sgtbom_sgmt_2_cd,
a.e1sgtbom_sgmt_1_cd,
a.e1sgtbom_sgmtn_vl_cd,
a.e1fshbom_e1fshbom_fnctn_cd,
a.e1fshbom_mtrl_18_characters_nr,
a.e1fshbom_bom_cmpnnt_nm,
a.e1fshbom_cmpnnt_qty,
a.e1fshbom_crtcl_cmpnnt_ind_cd,
a.e1fshbom_crtical_lvl_cmpnnt_bom,
a.e1fshbom_lg_mtrl_mtrl_fld_nr,
a.e1fshbom_vrsn_mtrl_fld_nr,
a.e1fshbom_xtrn_guid_mtrl_fld_nm,
a.lg_mtrl_cmpnnt_fld_nr,
a.vrsn_cmpnnt_fld_nr,
a.xtrn_guid_cmpnnt_fld_nm,
a.e1fshbom_mtrl_nr,
a.e1fshbom_bom_cmpnnt_cd,
a.e1upslink_ale_dbn_packe_5_nm,
a.e1upslink_ale_dbn_packe_3_nm,
a.e1upslink_msg_typ_nm,
a.e1upslink_ale_dbn_packe_1_nm,
a.ale_dbn_pkg_nm,
a.intgtn_fbrc_msg_id,
a.src_sys_upd_ts,
a.src_sys_ky,
a.lgcl_dlt_ind,
a.ins_gmt_ts,
a.upd_gmt_ts,
a.src_sys_extrc_gmt_ts,
a.src_sys_btch_nr,
a.fl_nm,
a.ld_jb_nr,
cast(concat(substr(a.ins_gmt_dt,0,7),"-01") as date) as ins_gmt_dt
from mfrg_bom_ref_rnk_temp a left outer join mfrg_bom_ref_cukb_temp b 
on a.zcuob_ext_inrn_kndg_elm_nr=b.zcukb_ext_inrn_kndg_elm_nr 
and a.e1stzum_bll_mtrl_cd=b.e1stzum_bll_mtrl_cd 
and a.idoc_nr=b.idoc_nr 
and a.e1mastm_mtrl_18_Characters_nr=b.e1mastm_mtrl_18_Characters_nr 
and a.e1mastm_plnt_cd=b.e1mastm_plnt_cd 
and a.e1mastm_bom_usg_cd=b.e1mastm_bom_usg_cd 
and a.e1mastm_bll_mtrl_cd=b.e1mastm_bll_mtrl_cd 
and a.e1mastm_altv_bom_cd=b.e1mastm_altv_bom_cd 
and a.e1stpom_bom_itm_nde_nr = b.e1stpom_bom_itm_nde_nr
and coalesce(a.e1stpom_bom_cmpnnt_nm,'') = coalesce(b.e1stpom_bom_cmpnnt_nm,'')
and coalesce(a.e1stpom_bom_itm_txt_ln_1_nm,'') = coalesce(b.e1stpom_bom_itm_txt_ln_1_nm,'')
where a.extra_record='0' and a.e1mastm_altv_bom_cd='01'""")

      bomIncrementalFinalDf = bomIncrementalFinalDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

      //***************************incremental CDC*********************************//

      val existingDmnsnDF = spark.sql(f"""select mfrg_bom_md5_ky,mfrg_bom_ky,idoc_nr,e1stzum_e1stzum_fnctn_cd,e1stzum_bom_cgy_cd,e1stzum_bll_mtrl_cd,e1stzum_bom_usg_cd,e1stzum_bom_gr_2_nm,e1stzum_in_1_cd,e1stzum_in_4_cd,e1stzum_in_2_cd,e1stzum_lng_ind,athzn_grp_bills_mtrl_cd,bom_txt_nm,last_chg_nr,bom_last_chgd_dt,tm_when_bom_last_chgd_ts,e1stzum_2character_sap_lng_cd,e1stzum_bom_gr_1_nm,zstzu_ext_plnt_whr_vrnt_crtd_cd,zstzu_ext_hisdt_ind_cd,zstzu_ext_hissr_ind_cd,zstzu_ext_histk_ind_cd,mxm_counters_nr,mxm_nodes_within_nr,zstzu_ext_kzpln_ind_cd,mxm_clsfn_nr,mxm_edge_nr,tm_stamp_nr,zstzu_ext_versnind_ind_cd,e1szuth_e1szuth_fnctn_cd,e1szut_1_nm,e1szuth_txt_id_id,e1szuth_lng_ky_ind,e1szuth_2character_sap_lng_cd,e1szutl_tg_cl_cd,e1szutl_txt_ln_nm,e1mastm_e1mastm_fnctn_cd,coalesce(e1mastm_mtrl_18_characters_nr,'') as e1mastm_mtrl_18_characters_nr,coalesce(e1mastm_plnt_cd,'') as e1mastm_plnt_cd,coalesce(e1mastm_bom_usg_cd,'') as e1mastm_bom_usg_cd,coalesce(e1mastm_bll_mtrl_cd,'') as e1mastm_bll_mtrl_cd,coalesce(e1mastm_altv_bom_cd,'') as e1mastm_altv_bom_cd,e1mastm_frm_lt_s_1,e1mastm_to_lt_s_1,e1mastm_ind_cd,e1mastm_mtr_3_nr,e1mastm_vrsn_matnr_fl_1_nr,e1mastm_xtrn_guid_matnr_fld_nm,e1mastm_mtr_5_nr,zmast_ext_rec_crtd_by,zmast_ext_rec_upd_by,zmast_ext_rec_crtd_dt,zmast_ext_rec_upd_dt,zmast_ext_dltn_ind_cd,e1t415b_e1t415b_fnctn_cd,e1t415b_mtrl_18_characters_nr,e1t415b_bom_usg_cd,e1t415b_bs_unt_msr_bom,e1t415b_altv_bom_cd,e1t415b_mtr_1_nr,e1t415b_vrsn_matnr_fl_3_nr,e1t415b_xtrn_guid_matnr_fld_nm,e1t415b_mtr_3_nr,e1stkom_e1stkom_fnctn_cd,e1stkom_altv_bom_cd,e1stkom_validfrom_dt,e1stkom_chg_nr,e1stkom_dltn_flg_boms_cd,e1stkom_unt_msr_bs_qty,e1stkom_cfrd_qt_1,e1stkom_cad_ind_cd,e1stkom_laboratorydesign_ofc_cd,e1stkom_lng_ind,e1stkom_altv_bom_txt_nm,e1stkom_bom_stts,e1stkom_2character_sap_lng_cd,e1stkom_bs_qty_nm,e1stkom_guid_xtrn_dsply_char32_nm,zstko_ext_bll_mtrl_cd,zstko_ext_bom_cgy_cd,zstko_ext_inrn_cntr_nr,zstko_ext_valid_to_dt,zstko_ext_rec_crtd_by,zstko_ext_rec_upd_by,zstko_ext_plnt_whr_vrnt_crtd_cd,bom_vrsn_cd,bom_vrsn_stts_cd,zstko_ext_versnlastind_ind_cd,zstko_ext_rec_crtd_dt,zstko_ext_rec_upd_dt,zstko_ext_tchnl_stts_frm_cd,prv_hdr_cnter_nr,zstko_ext_last_shft_dt,zstko_last_shft_dt_crrd_out_by,zstko_ext_shft_hrchy_ind_nr,zstko_ext_ale_ind_cd,zstko_ext_chg_nr_to_cd,dta_elmt_extensibility_mnt_hdr_cd,e1skoth_e1skoth_fnctn_cd,e1skot_1_nm,e1skoth_txt_id_id,e1skoth_lng_ky_ind,e1skoth_2character_sap_lng_cd,e1skotl_tg_cl_cd,e1skotl_txt_ln_nm,e1stasm_e1stasm_fnctn_cd,e1stasm_altv_bom_cd,e1stasm_bom_itm_nde_nr,e1stasm_validfrom_dt,e1stasm_chg_nr,e1stasm_dltn_ind_cd,inherited_nde_bom_itm_nr,e1stpom_e1stpom_fnctn_cd,coalesce(e1stpom_bom_itm_nde_nr,'') as e1stpom_bom_itm_nde_nr,e1stpom_itm_cgy_bll_mtr_1_cd,e1stpom_bom_it_1_nr,e1stpom_mtrl_18_characters_nr,e1stpom_cls_2_nr,e1stpom_clss_ty_1_cd,e1stpom_dcm_2_nr,e1stpom_dcmt_ty_2_cd,e1stpom_dcmt_pr_2_cd,e1stpom_dcmt_vrs_2_cd,e1stpom_srt_str_6_nm,coalesce(e1stpom_validfrom_dt,'') as e1stpom_validfrom_dt,e1stpom_chg_nr,e1stpom_dltn_ind_cd,coalesce(e1stpom_bom_cmpnnt_nm,'') as e1stpom_bom_cmpnnt_nm,e1stpom_itm_cgy_bll_mtr_2_cd,coalesce(e1stpom_bom_it_2_nr,'') as e1stpom_bom_it_2_nr,e1stpom_srt_str_5_nm,e1stpom_bs_unt_msr,e1stpom_qt_1,e1stpom_fx_qty_cd,e1stpom_cmpnnt_scrp_prct,e1stpom_oprn_scrp,e1stpom_nt_scrp_ind_cd,e1stpom_in_9_cd,e1stpom_mtrl_prvn_ind_cd,e1stpom_in_3_cd,e1stpom_in_5_cd,e1stpom_in_4_cd,e1stpom_in_18_cd,e1stpom_in_6_cd,e1stpom_in_7_cd,e1stpom_in_8_cd,e1stpom_pm_asmy_ind_cd,e1stpom_in_19_cd,e1stpom_in_20_cd,e1stpom_cad_ind_cd,e1stpom_leadtime_ofst_ts,e1stpom_dbn_ky_cmpnnt_cnsmpn_cd,e1stpom_in_17_cd,e1stpom_usg_prblty__altv_itm,e1stpom_prchg_grp_cd,e1stpom_dlvry_tm_dys_dt,e1stpom_e1stpom_acct_vndr_crdt_3_nr,e1stpom_pr_1,e1stpom_prc_unt,e1stpom_threedigit_chr_fld_idocs_id,e1stpom_cst_elmt_nm,e1stpom_variablesize_itm_1_nr,e1stpom_sz__1,e1stpom_sz__3,e1stpom_sz__2,e1stpom_unt_msr_sizes_1_to_3,e1stpom_qty_variablesize_it_3,e1stpom_fml_ky_cd,e1stpom_in_13_cd,e1stpom_lng_ind,coalesce(e1stpom_bom_itm_txt_ln_1_nm,'') as e1stpom_bom_itm_txt_ln_1_nm,e1stpom_bom_itm_txt_ln_2_nm,e1stpom_obj_typ_bom_itm_cd,e1stpom_mtrl_grp_cd,e1stpom_gds_rcpt_prsng_tm_dys_dt,e1stpom_dcmt_ty_1_cd,e1stpom_dcm_1_nr,e1stpom_dcmt_vrs_1_cd,e1stpom_dcmt_pr_1_cd,e1stpom_avg_mtrl_purity_,e1stpom_plng_prm_clss_cd,e1stpom_clss_ty_2_cd,e1stpom_resulting_itm_cgy_cd,e1stpom_slctn_ind_cnfgl_boms_cd,e1stpom_insn_ind_cd,e1stpom_in_15_cd,e1stpom_in_16_cd,e1stpom_in_14_cd,e1stpom_prchg_org_cd,e1stpom_rqrd_cmpnnt_cd,e1stpom_mltpl_slctn_allwd_cd,e1stpom_altv_dsply_frmt_cd,e1stpom_orgnl_ar_nm,e1stpom_obj_wth_asngd_dpncs_nr,e1stpom_iss_lctn_prdn_ord_cd,e1stpom_in_21_cd,e1stpom_intra_mtrl_nm,e1stpom_in_10_cd,e1stpom_explsn_typ_cd,e1stpom_altv_it_2_cd,e1stpom_altv_itm,e1stpom_altv_it_1_cd,e1stpom_followup_grp_cd,e1stpom_discontinuation_grp_cd,e1stpom_clsfn_nr,e1stpom_in_22_cd,e1stpom_2character_sap_lng_cd,e1stpom_leadtime_ofst_oprn_ts,e1stpom_unt_leadtime_ofst_oprn_ts,e1stpom_cls_3_nr,e1stpom_cmpnnt_qty_nm,e1stpom_cls_1_nr,e1stpom_qty_variablesize_it_1,e1stpom_prdn_sply_ar_nm,e1stpom_xtrn_idn_itm_id,e1stpom_guid_xtrn_dsply_char32_nm,e1stpom_spcl_prcmt_typ_bom_itm_cd,e1stpom_rfnc_pnt_bom_trnsfr_nm,e1stpom_lg_mtrl_fld_idnr_1_nr,e1stpom_vrsn_fld_idnr_1_nr,e1stpom_xtrn_guid_fld_idnrk_nm,e1stpom_lg_mtrl_fld_id_com_1_nr,e1stpom_vrsn_fld_id_com_1_nr,e1stpom_xtrn_guid_fld_id_comp_nm,e1stpom_lg_mtrl_fld_intr_1_nr,e1stpom_vrsn_fld_intr_1_nr,e1stpom_xtrn_guid_fld_intrm_nm,e1stpom_sgmtn_vl_nm,e1stpom_crtcl_cmpnnt_ind_cd,e1stpom_crtical_lvl_cmpnnt_bom,zstpo_ext_bom_cgy_cd,zstpo_ext_inrn_cntr_nr,zstpo_ext_valid_to_dt,zstpo_ext_bll_mtrl_cd,usr_who_crtd_re_3_cd,zstpo_ext_rec_upd_by,zstpo_ext_valkz_ind_cd,zstpo_ext_kznfp_ind_cd,itm_grp_cd,cmpnnt_vrnt_cd,zstpo_ext_rec_crtd_dt,zstpo_ext_rec_upd_dt,zstpo_ext_tchnl_stts_frm_cd,prdcsr_nde_nr,prv_itm_cnter_nr,issg_plnt_cd,followup_mtrl_bom_itm_not_use_cd,ztspo_ext_stvkn_inhrtd_nde_bom_itm_nr,zstpo_ext_last_shft_dt,zstpo_last_shft_dt_crrd_out_by,zstpo_ext_kndvb_ind_cd,zstpo_ext_kndbz_ind_cd,bom_cgy_orgl_sls_ord_itm_cd,bll_mtrl_orgl_sls_ord_itm_cd,nde_orgl_sls_ord_bom_itm_nr,cnter_orgl_sls_ord_itm_cd,zstpo_ext_shft_hrchy_ind_nr,h_cnter_nr,zstpo_ext_ale_ind_cd,temporarily_not_used_cd,sgmtn_mntd_components_cd,zstpo_ext_sgmtn_vl_cd,zstpo_ext_valid_to_rkey_dt,zstpo_ext_chg_nr_to_cd,zstpo_ext_chg_nr_to_1_cd,ztspo_ext_stvkn_vrsn_inhrtd_nde_bom_itm_nr,dta_elmt_extensibility_mnt_itm_cd,cu_cd,lgt_cltn_mtd_cd,mxm_prdn_lgth_nr,fx_scrp_any_lgt_nr,fx_scrp_frst_lgt_nr,fx_scrp_last_lgt_nr,runin_lgth_nr,rndg_vl_nr,dvt_vl_mntd_cmpnnt_at_vrnt_lvl_cd,qty_dbn_pfl_cd,rfnc_to_qty_dbn_pfl_cd,zstpo_ext_crtcl_cmpnnt_in_cd,zstpo_ext_crtcl_lvl_cmpnnt_bom_cd,fnctn_id,tbl_id_obj_id,zcuob_ext_obj_wth_asngd_dpnc_nr,coalesce(zcuob_ext_inrn_kndg_elm_nr,'') as zcuob_ext_inrn_kndg_elm_nr,zcuob_ext_inrn_cnter_archvng_obj_by_ec_nr,zcuob_ext_cnter_srtg_obj_alloc_cd,zcuob_ext_chg_nr_cd,zcuob_ext_valid_frm_dt,e1stpom1_mtr_1_nr,e1stpom1_bom_cmpnnt_nm,e1stpom1_intra_mtrl_nm,e1stpom1_sgmtn_vl_nm,e1cukbm_e1cukbm_fnctn_cd,coalesce(e1cukbm_inrn_dpnc_1_nm,'') as e1cukbm_inrn_dpnc_1_nm,e1cukbm_xtrn_dpnc_1_nm,e1cukbm_dpncy_typ_cd,dpncy_stts_cd,dpncy_grp_nm,athzn_to_mnt_obj_dpncs_objects_cd,cnter_srtg_obj_allocations_nr,e1cukbm_dltn_ind_cd,dpncy_typ_splmnt_cd,e1cukbm_ind_cd,coalesce(zcukb_ext_inrn_kndg_elm_nr,'') as zcukb_ext_inrn_kndg_elm_nr,zcukb_ext_inrn_cnter_archvng_obj_by_ec_nr,zcukb_ext_dpncy_typ_splmnt_cd,zstpo_ext_kzsoft_ind_cd,inrn_vrsn_obj_dpncy_nr,sfx_inrn_vrsn_asngmt_dpncy_cd,zstpo_ext_knsce_ind_cd,crtn_dt,dpndncy_crtd_by,zcukb_ext_rec_upd_dt,last_upd_by,zcukb_ext_chg_nr_cd,zcukb_ext_valid_frm_dt,e1cukbt_e1cukbt_fnctn_cd,e1cukbt_lng_ky_ind,dpncy_dn_nm,e1cukbt_dltn_ind_cd,e1cukbt_2character_sap_lng_cd,e1cuknm_e1cuknm_fnctn_cd,ln_obj_dpncy_src_72_characters_nm,e1cutxm_e1cutxm_fnctn_cd,e1cutxm_lng_ky_ind,e1cutxm_tg_cl_cd,e1cutxm_txt_ln_nm,e1cutxm_2character_sap_lng_cd,e1spoth_e1spoth_fnctn_cd,e1spot_1_nm,e1spoth_txt_id_id,e1spoth_lng_ky_ind,e1spoth_2character_sap_lng_cd,e1spotl_tg_cl_cd,e1spotl_txt_ln_nm,e1stpum_e1stpum_fnctn_cd,e1stpum_bom_itm_nde_nr,e1stpum_subitem_qt_1,e1stpum_instln_pnt_subitem_nm,e1stpum_bom_subitem_txt_nm,subitem_qty_nm,e1sgtbom_e1sgtbom_fnctn_cd,e1sgtbom_sgmtn_vl_nm,e1sgtbom_sgmt_2_cd,e1sgtbom_sgmt_1_cd,e1sgtbom_sgmtn_vl_cd,e1fshbom_e1fshbom_fnctn_cd,e1fshbom_mtrl_18_characters_nr,e1fshbom_bom_cmpnnt_nm,e1fshbom_cmpnnt_qty,e1fshbom_crtcl_cmpnnt_ind_cd,e1fshbom_crtical_lvl_cmpnnt_bom,e1fshbom_lg_mtrl_mtrl_fld_nr,e1fshbom_vrsn_mtrl_fld_nr,e1fshbom_xtrn_guid_mtrl_fld_nm,lg_mtrl_cmpnnt_fld_nr,vrsn_cmpnnt_fld_nr,xtrn_guid_cmpnnt_fld_nm,e1fshbom_mtrl_nr,e1fshbom_bom_cmpnnt_cd,e1upslink_ale_dbn_packe_5_nm,e1upslink_ale_dbn_packe_3_nm,e1upslink_msg_typ_nm,e1upslink_ale_dbn_packe_1_nm,ale_dbn_pkg_nm,intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_gmt_dt from ${dbNameConsmtn}.${consmptnTable}""")

      if (!existingDmnsnDF.head(1).isEmpty) {
        //************************For incremental load*****************************//
        var overWritePrtition = existingDmnsnDF.join(
          bomIncrementalFinalDf,
          existingDmnsnDF("e1mastm_mtrl_18_Characters_nr") === bomIncrementalFinalDf("e1mastm_mtrl_18_Characters_nr") &&
            existingDmnsnDF("e1mastm_plnt_cd") === bomIncrementalFinalDf("e1mastm_plnt_cd") &&
            existingDmnsnDF("e1mastm_bom_usg_cd") === bomIncrementalFinalDf("e1mastm_bom_usg_cd") &&
            existingDmnsnDF("e1mastm_bll_mtrl_cd") === bomIncrementalFinalDf("e1mastm_bll_mtrl_cd") &&
            existingDmnsnDF("e1stpom_bom_itm_nde_nr") === bomIncrementalFinalDf("e1stpom_bom_itm_nde_nr") &&
            existingDmnsnDF("e1stpom_bom_cmpnnt_nm") === bomIncrementalFinalDf("e1stpom_bom_cmpnnt_nm") &&
            existingDmnsnDF("e1stpom_bom_itm_txt_ln_1_nm") === bomIncrementalFinalDf("e1stpom_bom_itm_txt_ln_1_nm") &&
            existingDmnsnDF("e1mastm_altv_bom_cd") === bomIncrementalFinalDf("e1mastm_altv_bom_cd") &&
            existingDmnsnDF("e1stpom_ValidFrom_dt") === bomIncrementalFinalDf("e1stpom_ValidFrom_dt") &&
            existingDmnsnDF("e1stpom_bom_it_2_nr") === bomIncrementalFinalDf("e1stpom_bom_it_2_nr") &&
            existingDmnsnDF("e1cukbm_inrn_dpnc_1_nm") === bomIncrementalFinalDf("e1cukbm_inrn_dpnc_1_nm") &&
            existingDmnsnDF("zcuob_ext_inrn_kndg_elm_nr") === bomIncrementalFinalDf("zcuob_ext_inrn_kndg_elm_nr") &&
            existingDmnsnDF("zcukb_ext_inrn_kndg_elm_nr") === bomIncrementalFinalDf("zcukb_ext_inrn_kndg_elm_nr")).select(existingDmnsnDF("ins_gmt_dt").cast(StringType)).
          distinct.collect.map(row => row.getString(0).toString()).toList

        overWritePrtition = overWritePrtition ::: bomIncrementalFinalDf.select(bomIncrementalFinalDf("ins_gmt_dt").cast(StringType)).distinct.collect.map(row => row.getString(0).toString()).toList

        val dmnsnNonMatchDF = existingDmnsnDF.where(existingDmnsnDF("ins_gmt_dt").isin(overWritePrtition.distinct: _*)).join(
          bomIncrementalFinalDf,
          existingDmnsnDF("e1mastm_mtrl_18_Characters_nr") === bomIncrementalFinalDf("e1mastm_mtrl_18_Characters_nr") &&
            existingDmnsnDF("e1mastm_plnt_cd") === bomIncrementalFinalDf("e1mastm_plnt_cd") &&
            existingDmnsnDF("e1mastm_bom_usg_cd") === bomIncrementalFinalDf("e1mastm_bom_usg_cd") &&
            existingDmnsnDF("e1mastm_bll_mtrl_cd") === bomIncrementalFinalDf("e1mastm_bll_mtrl_cd") &&
            existingDmnsnDF("e1stpom_bom_itm_nde_nr") === bomIncrementalFinalDf("e1stpom_bom_itm_nde_nr") &&
            existingDmnsnDF("e1stpom_bom_cmpnnt_nm") === bomIncrementalFinalDf("e1stpom_bom_cmpnnt_nm") &&
            existingDmnsnDF("e1stpom_bom_itm_txt_ln_1_nm") === bomIncrementalFinalDf("e1stpom_bom_itm_txt_ln_1_nm") &&
            existingDmnsnDF("e1mastm_altv_bom_cd") === bomIncrementalFinalDf("e1mastm_altv_bom_cd") &&
            existingDmnsnDF("e1stpom_ValidFrom_dt") === bomIncrementalFinalDf("e1stpom_ValidFrom_dt") &&
            existingDmnsnDF("e1stpom_bom_it_2_nr") === bomIncrementalFinalDf("e1stpom_bom_it_2_nr") &&
            existingDmnsnDF("e1cukbm_inrn_dpnc_1_nm") === bomIncrementalFinalDf("e1cukbm_inrn_dpnc_1_nm") &&
            existingDmnsnDF("zcuob_ext_inrn_kndg_elm_nr") === bomIncrementalFinalDf("zcuob_ext_inrn_kndg_elm_nr") &&
            existingDmnsnDF("zcukb_ext_inrn_kndg_elm_nr") === bomIncrementalFinalDf("zcukb_ext_inrn_kndg_elm_nr"), "left_anti").drop(bomIncrementalFinalDf("e1mastm_mtrl_18_Characters_nr"))

        val finalDmnsnDF = bomIncrementalFinalDf.union(dmnsnNonMatchDF).coalesce(numPartitions)

        finalDmnsnDF.write.mode("Overwrite").format("ORC").insertInto(dbNameConsmtn + "." + consmptnTable)

      } else {
        //**************************For initial load*****************************//
        bomIncrementalFinalDf.write.mode("Overwrite").format("ORC").insertInto(dbNameConsmtn + "." + consmptnTable)
      }

      logger.info("Data has been loaded to: " + consmptnTable + " Table")

      tgt_count = bomIncrementalFinalDf.count().toInt
      auditObj.setAudTgtRowCount(tgt_count)

      logger.info("+++++++++++############# Target Count: " + tgt_count + " #############+++++++++++")

      //************************Completion Audit Entries*******************************//

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }
    auditObj.setAudJobStatusCode("success")
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
      toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    logger.info("************BOM Consumption Load Completed*************************")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
  } finally {
    bomIncrementalFinalDf.unpersist()
    spark.catalog.dropTempView("mfrg_bom_ref_incremental")
    spark.catalog.dropTempView("mfrg_bom_ref_left")
    spark.catalog.dropTempView("mfrg_bom_ref_right")
    spark.catalog.dropTempView("mfrg_bom_ref_temp")
    spark.catalog.dropTempView("mfrg_bom_ref_rnk_temp")
    spark.catalog.dropTempView("mfrg_bom_ref_cukb_temp")
    sqlCon.close()
    spark.close()
    if (loadStatus == false) {
      System.exit(1)
    }
  }
}
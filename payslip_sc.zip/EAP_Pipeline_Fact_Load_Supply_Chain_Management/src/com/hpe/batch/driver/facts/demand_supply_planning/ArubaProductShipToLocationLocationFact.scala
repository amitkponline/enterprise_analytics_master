package com.hpe.batch.driver.facts.demand_supply_planning

import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import java.util.Calendar
import java.text.SimpleDateFormat
import org.apache.spark.sql.{DataFrame, SparkSession}

object ArubaProductShipToLocationLocationFact extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  try {
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val transformeSrcdDF = spark.sql("""select * from """ + propertiesObject.getSrcTblConsmtn() )

  var src_count = transformeSrcdDF.count().toInt


    //****************************Fact Code****************************************//
val now = Calendar.getInstance.getTime
val dowInt = new SimpleDateFormat("u")
var transformedTgtDF:DataFrame = null

var snapshot_type= spark.sql("""select monthly_snapshot_date_dt from """+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn where monthly_snapshot_date_dt = current_date""")

// Here dataframe will hold existing data from Fact Table for monthly snapshot creation
if (snapshot_type.count().toInt!=0)
{
transformedTgtDF = spark.sql("""select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) Wkly  union all
select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 11)) Mnthly""")
}
// Here dataframe will hold existing data from Fact Table for weekly snapshot creation
else if (dowInt.format(now) == "7")
{
transformedTgtDF = spark.sql("""select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 25)) Wkly  union all
select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) Mnthly""")
}
// Here dataframe will hold existing data from Fact Table for daily snapshot creation
else 
{
transformedTgtDF = spark.sql("""select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) Wkly  union all
select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from (select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) Mnthly""")
}

transformedTgtDF.createOrReplaceTempView("transformedTgtDF_table")

var transformedDF = spark.sql("""select aruba_prod_shptolctn_lctn_fact_ky	, ky_fgr_dt	, prod_id	, shipto_lctn_id	, lctn_id	, dpndt_lctn_dmnd_cd	, icso_cd	, ins_ts	, snpsht_dt	, snpsht_typ	 from  transformedTgtDF_table union all
select
crc32(upper(trim(CONCAT(coalesce(ky_fgr_dt,""),coalesce(prod_id,""),coalesce(ShipTo_lctn_id,""),coalesce(lctn_id,""),coalesce(CAST(CURRENT_DATE as string),""))))) 
,date(ky_fgr_dt)
,prod_id
,ShipTo_lctn_id
,lctn_id
,coalesce(dpndt_lctn_dmnd_cd,0L) as dpndt_lctn_dmnd_cd
,coalesce(icso_cd,0L) as icso_cd
,current_timestamp as ins_ts
,CURRENT_DATE as snpsht_dt
,Case WHEN X.monthly_snapshot_date_dt is NOT NULL then "MONTHLY" 
when date_format(current_date, 'u') = "7" then "WEEKLY" 
else "DAILY" END AS snpsht_typ
from """+ propertiesObject.getSrcTblConsmtn() + """ A
LEFT join
"""+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn X
on current_date()=X.monthly_snapshot_date_dt""")


    var loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable)
	spark.catalog.dropTempView("transformedTgtDF_table")

//************************Completion Audit Entries*******************************//

    var tgt_count = transformedDF.count().toInt 

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)     
    }
    case allException: IllegalArgumentException => {
      logger.error("Illegal Argument")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  }
  finally {
    sqlCon.close()
    spark.close()
  }
}
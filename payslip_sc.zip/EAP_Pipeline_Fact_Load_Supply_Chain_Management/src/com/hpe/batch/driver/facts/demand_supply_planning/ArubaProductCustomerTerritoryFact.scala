package com.hpe.batch.driver.facts.demand_supply_planning

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import java.util.Calendar
import java.text.SimpleDateFormat
import org.apache.spark.sql.{DataFrame, SparkSession}

object ArubaProductCustomerTerritoryFact extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  
  try {
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val transformeSrcdDF = spark.sql("""select * from """ + propertiesObject.getSrcTblConsmtn() )

  var src_count = transformeSrcdDF.count()

    //****************************Fact Code****************************************//

var snapshot_type= spark.sql("""select monthly_snapshot_date_dt from """+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn where monthly_snapshot_date_dt = current_date""")

val now = Calendar.getInstance.getTime
val dowInt = new SimpleDateFormat("u")

var transformedTgtDF:DataFrame = null

// Here dataframe will hold existing data from Fact Table for monthly snapshot creation
if (snapshot_type.count().toInt!=0)
{
transformedTgtDF = spark.sql("""select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from (select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) U2  union all
select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from (select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 11)) U2""")
}
// Here dataframe will hold existing data from Fact Table for weekly snapshot creation
else if (dowInt.format(now) == "7")
{
transformedTgtDF = spark.sql("""select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from (select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" and snpsht_dt <> to_date(CURRENT_DATE)  and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 25)) U2  union all
select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from (select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) U2""")
}
// Here dataframe will hold existing data from Fact Table for daily snapshot creation
else 
{
transformedTgtDF = spark.sql("""select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from (select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) U2  union all
select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from (select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) U2""")
}

transformedTgtDF.createOrReplaceTempView("transformedTgtDF_table")

var transformedDF = spark.sql("""select aruba_mthly_prod_cust_tty_ky,prod_id,cust_tty_cd,keyfigure_dt,keyfigure_mnth,keyfigure_yr,fiscal_yr,qtr,aup__cd,aup_ct__cd,aup_ct__tgt_cd,fnl_dmnd_pln_rvn_cd,rvn_actuals_ct_cd,snpsht_dt,snpsht_typ from  transformedTgtDF_table union all
select
aruba_mthly_prod_cust_tty_ky
,prod_id
,cust_tty_cd
,date(Keyfigure_dt)
,month(keyfigure_dt) as keyfigure_mnth
,year(keyfigure_dt) as keyfigure_yr
,CASE WHEN month(keyfigure_dt) in ("11","12") then year(keyfigure_dt)+1 else year(keyfigure_dt) end as fiscal_yr
,CASE WHEN month(keyfigure_dt) in ("11","12","1") THEN "Q1" 
WHEN month(keyfigure_dt) in ("2","3","4") THEN "Q2"
WHEN month(keyfigure_dt) in ("5","6","7") THEN "Q3"
ELSE "Q4" END AS qtr 
,AUP__cd
,AUP_ct__cd
,AUP_ct__tgt_cd
,fnl_dmnd_pln_rvn_cd
,rvn_Actuals_ct_cd
,CURRENT_DATE as snpsht_dt
,"MONTHLY" AS snpsht_typ
from """+ propertiesObject.getSrcTblConsmtn())

var loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable)
spark.catalog.dropTempView("transformedTgtDF_table")
 
//************************Completion Audit Entries*******************************//

    var tgt_count = transformedDF.count().toInt
    
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("cnsmptn_fact")
    auditObj.setAudApplicationName("ArubaProductCustomerTerritoryFact")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)     
    }
    case allException: IllegalArgumentException => {
      logger.error("Illegal Argument")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  }
  finally {
    sqlCon.close()
    spark.close()
  }
}
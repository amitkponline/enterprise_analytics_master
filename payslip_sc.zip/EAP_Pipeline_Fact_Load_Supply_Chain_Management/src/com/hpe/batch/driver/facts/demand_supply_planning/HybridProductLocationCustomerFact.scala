package com.hpe.batch.driver.facts.demand_supply_planning

import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

object HybridProductLocationCustomerFact extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

  try {
    //****************************Fact Code****************************************//

    import java.util.Calendar
    import java.text.SimpleDateFormat
    val now = Calendar.getInstance.getTime
    val dowInt = new SimpleDateFormat("u")
    import org.apache.spark.sql.{ DataFrame, SparkSession }

    var transformedDF: DataFrame = null
    var transformedTgtDF: DataFrame = null
    var transformedCalDF: DataFrame = null

    var hybrid_it_tchnl_wk_prod_lctn_cust_all_rgn_dmnsn = "hybrid_it_tchnl_wk_prod_lctn_cust_all_rgn_dmnsn"

    transformedDF = spark.sql("""select
prod_id
,lctn_id
,cust_id
,keyfigure_dt
,totl_ord_actuals_rsd_cd
,lctn_splt_consensus_dmnd_pln_cd
,past_mth_bcklog_ord_bw_qty_cd
,idpt_ord_actuals_rsd_cd
,ststcl_frcst_usr_dfnd_cd
,ststcl_frcst_btch_cd
,totl_shp_actl_pgi_cd
,totl_shp_actl_rsd_cd
,sop_dmnd_plnr_ovrd_id
,bsln_mtrl_frcst_ovrd_id
,ord_backlogrsd_cd
,bsln_mtrl_frcst_lwr_prio_cd
,dpndt_ord_actuals_rsd_cd
from
""" + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_lctn_cust_ams_dmnsn
UNION ALL
Select 
prod_id
,lctn_id
,cust_id
,keyfigure_dt
,totl_ord_actuals_rsd_cd
,lctn_splt_consensus_dmnd_pln_cd
,past_mth_bcklog_ord_bw_qty_cd
,idpt_ord_actuals_rsd_cd
,ststcl_frcst_usr_dfnd_cd
,ststcl_frcst_btch_cd
,totl_shp_actl_pgi_cd
,totl_shp_actl_rsd_cd
,sop_dmnd_plnr_ovrd_id
,bsln_mtrl_frcst_ovrd_id
,ord_backlogrsd_cd
,bsln_mtrl_frcst_lwr_prio_cd
,dpndt_ord_actuals_rsd_cd
from
""" + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_lctn_cust_apj_dmnsn
UNION ALL
Select
prod_id
,lctn_id
,cust_id
,keyfigure_dt
,totl_ord_actuals_rsd_cd
,lctn_splt_consensus_dmnd_pln_cd
,past_mth_bcklog_ord_bw_qty_cd
,idpt_ord_actuals_rsd_cd
,ststcl_frcst_usr_dfnd_cd
,ststcl_frcst_btch_cd
,totl_shp_actl_pgi_cd
,totl_shp_actl_rsd_cd
,sop_dmnd_plnr_ovrd_id
,bsln_mtrl_frcst_ovrd_id
,ord_backlogrsd_cd
,bsln_mtrl_frcst_lwr_prio_cd
,dpndt_ord_actuals_rsd_cd
from
""" + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_lctn_cust_emea_dmnsn""")

    var loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_all_rgn_dmnsn)

    var hybrid_it_tchnl_wk_prod_lctn_cust_fnl_dmnsn = "hybrid_it_tchnl_wk_prod_lctn_cust_fnl_dmnsn"

    transformedDF = spark.sql("""select
prod_id
,lctn_id
,cust_id
,keyfigure_dt
,month(keyfigure_dt) as keyfigure_mnth
,year(keyfigure_dt) as keyfigure_yr
,CASE WHEN month(keyfigure_dt) in ("11","12") then year(keyfigure_dt)+1 else year(keyfigure_dt) end as fiscal_yr
,CASE WHEN month(keyfigure_dt) in ("11","12","1") THEN "Q1" 
WHEN month(keyfigure_dt) in ("2","3","4") THEN "Q2"
WHEN month(keyfigure_dt) in ("5","6","7") THEN "Q3"
ELSE "Q4" END AS qtr 
,totl_ord_actuals_rsd_cd
,lctn_splt_consensus_dmnd_pln_cd
,past_mth_bcklog_ord_bw_qty_cd
,idpt_ord_actuals_rsd_cd
,ststcl_frcst_usr_dfnd_cd
,ststcl_frcst_btch_cd
,totl_shp_actl_pgi_cd
,totl_shp_actl_rsd_cd
,sop_dmnd_plnr_ovrd_id
,bsln_mtrl_frcst_ovrd_id
,ord_backlogrsd_cd
,bsln_mtrl_frcst_lwr_prio_cd
,dpndt_ord_actuals_rsd_cd
,rvn_actuals_cd
,vrtl_theater_cd
,dmnd_typ_cd
,bs_prod_cd
,prod_cgy_desc_cd
from (select
CASE WHEN t1.prod_id is NULL then t2.prod_id else t1.prod_id end as prod_id
,CASE WHEN t1.lctn_id is NULL then t2.lctn_id else t1.lctn_id end as lctn_id
,CASE WHEN t1.cust_id is NULL then t2.cust_id else t1.cust_id end as cust_id
,CASE WHEN t1.keyfigure_dt is NULL then t2.keyfigure_dt else t1.keyfigure_dt end as keyfigure_dt
,COALESCE(t1.totl_ord_actuals_rsd_cd,0L) as totl_ord_actuals_rsd_cd
,COALESCE(t1.lctn_splt_consensus_dmnd_pln_cd,0L) as lctn_splt_consensus_dmnd_pln_cd
,COALESCE(t1.past_mth_bcklog_ord_bw_qty_cd,0L) as past_mth_bcklog_ord_bw_qty_cd
,COALESCE(t1.idpt_ord_actuals_rsd_cd,0L) as idpt_ord_actuals_rsd_cd
,COALESCE(t1.ststcl_frcst_usr_dfnd_cd,0L) as ststcl_frcst_usr_dfnd_cd
,COALESCE(t1.ststcl_frcst_btch_cd,0L) as ststcl_frcst_btch_cd
,COALESCE(t1.totl_shp_actl_pgi_cd,0L) as totl_shp_actl_pgi_cd
,COALESCE(t1.totl_shp_actl_rsd_cd,0L) as totl_shp_actl_rsd_cd
,COALESCE(t1.sop_dmnd_plnr_ovrd_id,0L) as sop_dmnd_plnr_ovrd_id
,COALESCE(t1.bsln_mtrl_frcst_ovrd_id,0L) as bsln_mtrl_frcst_ovrd_id
,COALESCE(t1.ord_backlogrsd_cd,0L) as ord_backlogrsd_cd
,COALESCE(t1.bsln_mtrl_frcst_lwr_prio_cd,0L) as bsln_mtrl_frcst_lwr_prio_cd
,COALESCE(t1.dpndt_ord_actuals_rsd_cd,0L) as dpndt_ord_actuals_rsd_cd
,COALESCE(t2.rvn_actuals_cd,0L) as rvn_actuals_cd
,t4.vrtl_theater_cd
,t4.dmnd_typ_cd
,t3.bs_prod_cd
,t3.prod_cgy_desc_cd
from
""" + dbNameConsmtn + """.""" + hybrid_it_tchnl_wk_prod_lctn_cust_all_rgn_dmnsn + """ t1
FULL OUTER JOIN
""" + dbNameConsmtn + """.hybrid_tchnl_wk_prod_lctn_cust_dmnsn t2
ON
t1.prod_id = t2.prod_id and t1.lctn_id = t2.lctn_id and t1.cust_id = t2.cust_id and 
t1.keyfigure_dt = t2.keyfigure_dt
left join
""" + dbNameConsmtn + """.hpe_prod_dmnsn t3
on
t1.prod_id=t3.prod_id
left join
""" + dbNameConsmtn + """.hpe_cust_hrchy_dmnsn t4
on
t1.cust_id=t4.cust_id) A""")

    loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_fnl_dmnsn)

    var hybrid_it_tchnl_wk_prod_lctn_cust_mnthly_dmnsn = "hybrid_it_tchnl_wk_prod_lctn_cust_mnthly_dmnsn"

    transformedDF = spark.sql("""select
prod_id
,lctn_id
,cust_id
,keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr 
,sum(COALESCE(totl_ord_actuals_rsd_cd,0L)) as totl_ord_actuals_rsd_cd_mnthly
,sum(COALESCE(lctn_splt_consensus_dmnd_pln_cd,0L)) as lctn_splt_consensus_dmnd_pln_cd_mnthly
,sum(COALESCE(past_mth_bcklog_ord_bw_qty_cd,0L)) as past_mth_bcklog_ord_bw_qty_cd_mnthly
,sum(COALESCE(idpt_ord_actuals_rsd_cd,0L)) as idpt_ord_actuals_rsd_cd_mnthly
,sum(COALESCE(ststcl_frcst_usr_dfnd_cd,0L)) as ststcl_frcst_usr_dfnd_cd_mnthly
,sum(COALESCE(ststcl_frcst_btch_cd,0L)) as ststcl_frcst_btch_cd_mnthly
,sum(COALESCE(totl_shp_actl_pgi_cd,0L)) as totl_shp_actl_pgi_cd_mnthly
,sum(COALESCE(totl_shp_actl_rsd_cd,0L)) as totl_shp_actl_rsd_cd_mnthly
,sum(COALESCE(sop_dmnd_plnr_ovrd_id,0L)) as sop_dmnd_plnr_ovrd_id_mnthly
,sum(COALESCE(bsln_mtrl_frcst_ovrd_id,0L)) as bsln_mtrl_frcst_ovrd_id_mnthly
,sum(COALESCE(ord_backlogrsd_cd,0L)) as ord_backlogrsd_cd_mnthly
,sum(COALESCE(bsln_mtrl_frcst_lwr_prio_cd,0L)) as bsln_mtrl_frcst_lwr_prio_cd_mnthly
,sum(COALESCE(dpndt_ord_actuals_rsd_cd,0L)) as dpndt_ord_actuals_rsd_cd_mnthly
,sum(COALESCE(rvn_actuals_cd,0L)) as rvn_actuals_cd_mnthly
from
""" + dbNameConsmtn + """.""" + hybrid_it_tchnl_wk_prod_lctn_cust_fnl_dmnsn + """ group by
prod_id
,lctn_id
,cust_id
,keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr""")

    loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_mnthly_dmnsn)

    var hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_dmnsn = "hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_dmnsn"

    transformedDF = spark.sql("""select 
prod_id
,lctn_id
,cust_id
,fiscal_yr
,qtr 
,COALESCE(max(totl_ord_actuals_rsd_cd_m1),0L) as totl_ord_actuals_rsd_cd_m1
,COALESCE(max(totl_ord_actuals_rsd_cd_m2),0L) as totl_ord_actuals_rsd_cd_m2
,COALESCE(max(totl_ord_actuals_rsd_cd_m3),0L) as totl_ord_actuals_rsd_cd_m3
,COALESCE(max(lctn_splt_consensus_dmnd_pln_cd_m1),0L) as lctn_splt_consensus_dmnd_pln_cd_m1
,COALESCE(max(lctn_splt_consensus_dmnd_pln_cd_m2),0L) as lctn_splt_consensus_dmnd_pln_cd_m2
,COALESCE(max(lctn_splt_consensus_dmnd_pln_cd_m3),0L) as lctn_splt_consensus_dmnd_pln_cd_m3
,COALESCE(max(past_mth_bcklog_ord_bw_qty_cd_m1),0L) as past_mth_bcklog_ord_bw_qty_cd_m1
,COALESCE(max(past_mth_bcklog_ord_bw_qty_cd_m2),0L) as past_mth_bcklog_ord_bw_qty_cd_m2
,COALESCE(max(past_mth_bcklog_ord_bw_qty_cd_m3),0L) as past_mth_bcklog_ord_bw_qty_cd_m3
,COALESCE(max(idpt_ord_actuals_rsd_cd_m1),0L) as idpt_ord_actuals_rsd_cd_m1
,COALESCE(max(idpt_ord_actuals_rsd_cd_m2),0L) as idpt_ord_actuals_rsd_cd_m2
,COALESCE(max(idpt_ord_actuals_rsd_cd_m3),0L) as idpt_ord_actuals_rsd_cd_m3
,COALESCE(max(ststcl_frcst_usr_dfnd_cd_m1),0L) as ststcl_frcst_usr_dfnd_cd_m1
,COALESCE(max(ststcl_frcst_usr_dfnd_cd_m2),0L) as ststcl_frcst_usr_dfnd_cd_m2
,COALESCE(max(ststcl_frcst_usr_dfnd_cd_m3),0L) as ststcl_frcst_usr_dfnd_cd_m3
,COALESCE(max(ststcl_frcst_btch_cd_m1),0L) as ststcl_frcst_btch_cd_m1
,COALESCE(max(ststcl_frcst_btch_cd_m2),0L) as ststcl_frcst_btch_cd_m2
,COALESCE(max(ststcl_frcst_btch_cd_m3),0L) as ststcl_frcst_btch_cd_m3
,COALESCE(max(totl_shp_actl_pgi_cd_m1),0L) as totl_shp_actl_pgi_cd_m1
,COALESCE(max(totl_shp_actl_pgi_cd_m2),0L) as totl_shp_actl_pgi_cd_m2
,COALESCE(max(totl_shp_actl_pgi_cd_m3),0L) as totl_shp_actl_pgi_cd_m3
,COALESCE(max(totl_shp_actl_rsd_cd_m1),0L) as totl_shp_actl_rsd_cd_m1
,COALESCE(max(totl_shp_actl_rsd_cd_m2),0L) as totl_shp_actl_rsd_cd_m2
,COALESCE(max(totl_shp_actl_rsd_cd_m3),0L) as totl_shp_actl_rsd_cd_m3
,COALESCE(max(sop_dmnd_plnr_ovrd_id_m1),0L) as sop_dmnd_plnr_ovrd_id_m1
,COALESCE(max(sop_dmnd_plnr_ovrd_id_m2),0L) as sop_dmnd_plnr_ovrd_id_m2
,COALESCE(max(sop_dmnd_plnr_ovrd_id_m3),0L) as sop_dmnd_plnr_ovrd_id_m3
,COALESCE(max(bsln_mtrl_frcst_ovrd_id_m1),0L) as bsln_mtrl_frcst_ovrd_id_m1
,COALESCE(max(bsln_mtrl_frcst_ovrd_id_m2),0L) as bsln_mtrl_frcst_ovrd_id_m2
,COALESCE(max(bsln_mtrl_frcst_ovrd_id_m3),0L) as bsln_mtrl_frcst_ovrd_id_m3
,COALESCE(max(ord_backlogrsd_cd_m1),0L) as ord_backlogrsd_cd_m1
,COALESCE(max(ord_backlogrsd_cd_m2),0L) as ord_backlogrsd_cd_m2
,COALESCE(max(ord_backlogrsd_cd_m3),0L) as ord_backlogrsd_cd_m3
,COALESCE(max(bsln_mtrl_frcst_lwr_prio_cd_m1),0L) as bsln_mtrl_frcst_lwr_prio_cd_m1
,COALESCE(max(bsln_mtrl_frcst_lwr_prio_cd_m2),0L) as bsln_mtrl_frcst_lwr_prio_cd_m2
,COALESCE(max(bsln_mtrl_frcst_lwr_prio_cd_m3),0L) as bsln_mtrl_frcst_lwr_prio_cd_m3
,COALESCE(max(dpndt_ord_actuals_rsd_cd_m1),0L) as dpndt_ord_actuals_rsd_cd_m1
,COALESCE(max(dpndt_ord_actuals_rsd_cd_m2),0L) as dpndt_ord_actuals_rsd_cd_m2
,COALESCE(max(dpndt_ord_actuals_rsd_cd_m3),0L) as dpndt_ord_actuals_rsd_cd_m3
,COALESCE(max(rvn_actuals_cd_m1),0L) as rvn_actuals_cd_m1
,COALESCE(max(rvn_actuals_cd_m2),0L) as rvn_actuals_cd_m2
,COALESCE(max(rvn_actuals_cd_m3),0L) as rvn_actuals_cd_m3
from
(select 
prod_id
,lctn_id
,cust_id
,Keyfigure_mnth
,fiscal_yr
,qtr 
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.lctn_splt_consensus_dmnd_pln_cd_map[Keyfigure_mnth]) END as lctn_splt_consensus_dmnd_pln_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.lctn_splt_consensus_dmnd_pln_cd_map[Keyfigure_mnth]) END as lctn_splt_consensus_dmnd_pln_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.lctn_splt_consensus_dmnd_pln_cd_map[Keyfigure_mnth]) END as lctn_splt_consensus_dmnd_pln_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.past_mth_bcklog_ord_bw_qty_cd_map[Keyfigure_mnth]) END as past_mth_bcklog_ord_bw_qty_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(past_mth_bcklog_ord_bw_qty_cd_map[Keyfigure_mnth]) END as past_mth_bcklog_ord_bw_qty_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.past_mth_bcklog_ord_bw_qty_cd_map[Keyfigure_mnth]) END as past_mth_bcklog_ord_bw_qty_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.idpt_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as idpt_ord_actuals_rsd_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.idpt_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as idpt_ord_actuals_rsd_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.idpt_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as idpt_ord_actuals_rsd_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.ststcl_frcst_usr_dfnd_cd_map[Keyfigure_mnth]) END as ststcl_frcst_usr_dfnd_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.ststcl_frcst_usr_dfnd_cd_map[Keyfigure_mnth]) END as ststcl_frcst_usr_dfnd_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.ststcl_frcst_usr_dfnd_cd_map[Keyfigure_mnth]) END as ststcl_frcst_usr_dfnd_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.ststcl_frcst_btch_cd_map[Keyfigure_mnth]) END as ststcl_frcst_btch_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.ststcl_frcst_btch_cd_map[Keyfigure_mnth]) END as ststcl_frcst_btch_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.ststcl_frcst_btch_cd_map[Keyfigure_mnth]) END as ststcl_frcst_btch_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.totl_shp_actl_pgi_cd_map[Keyfigure_mnth]) END as totl_shp_actl_pgi_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.totl_shp_actl_pgi_cd_map[Keyfigure_mnth]) END as totl_shp_actl_pgi_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.totl_shp_actl_pgi_cd_map[Keyfigure_mnth]) END as totl_shp_actl_pgi_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.totl_shp_actl_rsd_cd_map[Keyfigure_mnth]) END as totl_shp_actl_rsd_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.totl_shp_actl_rsd_cd_map[Keyfigure_mnth]) END as totl_shp_actl_rsd_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.totl_shp_actl_rsd_cd_map[Keyfigure_mnth]) END as totl_shp_actl_rsd_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.sop_dmnd_plnr_ovrd_id_map[Keyfigure_mnth]) END as sop_dmnd_plnr_ovrd_id_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.sop_dmnd_plnr_ovrd_id_map[Keyfigure_mnth]) END as sop_dmnd_plnr_ovrd_id_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.sop_dmnd_plnr_ovrd_id_map[Keyfigure_mnth]) END as sop_dmnd_plnr_ovrd_id_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.bsln_mtrl_frcst_ovrd_id_map[Keyfigure_mnth]) END as bsln_mtrl_frcst_ovrd_id_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.bsln_mtrl_frcst_ovrd_id_map[Keyfigure_mnth]) END as bsln_mtrl_frcst_ovrd_id_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.bsln_mtrl_frcst_ovrd_id_map[Keyfigure_mnth]) END as bsln_mtrl_frcst_ovrd_id_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.ord_backlogrsd_cd_map[Keyfigure_mnth]) END as ord_backlogrsd_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.ord_backlogrsd_cd_map[Keyfigure_mnth]) END as ord_backlogrsd_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.ord_backlogrsd_cd_map[Keyfigure_mnth]) END as ord_backlogrsd_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.bsln_mtrl_frcst_lwr_prio_cd_map[Keyfigure_mnth]) END as bsln_mtrl_frcst_lwr_prio_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.bsln_mtrl_frcst_lwr_prio_cd_map[Keyfigure_mnth]) END as bsln_mtrl_frcst_lwr_prio_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.bsln_mtrl_frcst_lwr_prio_cd_map[Keyfigure_mnth]) END as bsln_mtrl_frcst_lwr_prio_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.dpndt_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as dpndt_ord_actuals_rsd_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.dpndt_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as dpndt_ord_actuals_rsd_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.dpndt_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as dpndt_ord_actuals_rsd_cd_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.rvn_actuals_cd_map[Keyfigure_mnth]) END as rvn_actuals_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.rvn_actuals_cd_map[Keyfigure_mnth]) END as rvn_actuals_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.rvn_actuals_cd_map[Keyfigure_mnth]) END as rvn_actuals_cd_m3
from
( 
select 
prod_id
,lctn_id
,cust_id
,Keyfigure_mnth
,fiscal_yr
,qtr 
,map(Keyfigure_mnth,totl_ord_actuals_rsd_cd_mnthly) as totl_ord_actuals_rsd_cd_map
,map(Keyfigure_mnth,lctn_splt_consensus_dmnd_pln_cd_mnthly) as lctn_splt_consensus_dmnd_pln_cd_map
,map(Keyfigure_mnth,past_mth_bcklog_ord_bw_qty_cd_mnthly) as past_mth_bcklog_ord_bw_qty_cd_map
,map(Keyfigure_mnth,idpt_ord_actuals_rsd_cd_mnthly) as idpt_ord_actuals_rsd_cd_map
,map(Keyfigure_mnth,ststcl_frcst_usr_dfnd_cd_mnthly) as ststcl_frcst_usr_dfnd_cd_map
,map(Keyfigure_mnth,ststcl_frcst_btch_cd_mnthly) as ststcl_frcst_btch_cd_map
,map(Keyfigure_mnth,totl_shp_actl_pgi_cd_mnthly) as totl_shp_actl_pgi_cd_map
,map(Keyfigure_mnth,totl_shp_actl_rsd_cd_mnthly) as totl_shp_actl_rsd_cd_map
,map(Keyfigure_mnth,sop_dmnd_plnr_ovrd_id_mnthly) as sop_dmnd_plnr_ovrd_id_map
,map(Keyfigure_mnth,bsln_mtrl_frcst_ovrd_id_mnthly) as bsln_mtrl_frcst_ovrd_id_map
,map(Keyfigure_mnth,ord_backlogrsd_cd_mnthly) as ord_backlogrsd_cd_map
,map(Keyfigure_mnth,bsln_mtrl_frcst_lwr_prio_cd_mnthly) as bsln_mtrl_frcst_lwr_prio_cd_map
,map(Keyfigure_mnth,dpndt_ord_actuals_rsd_cd_mnthly) as dpndt_ord_actuals_rsd_cd_map
,map(Keyfigure_mnth,rvn_actuals_cd_mnthly) as rvn_actuals_cd_map
from """ + dbNameConsmtn + """.""" + hybrid_it_tchnl_wk_prod_lctn_cust_mnthly_dmnsn + """) a 
group by
prod_id
,lctn_id
,cust_id
,Keyfigure_mnth
,fiscal_yr
,qtr ) b
group by
prod_id
,lctn_id
,cust_id
,fiscal_yr
,qtr""")

    loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_dmnsn)

    var hybrid_it_tchnl_wk_prod_lctn_cust_all_vlue_dmnsn = "hybrid_it_tchnl_wk_prod_lctn_cust_all_vlue_dmnsn"

    transformedDF = spark.sql("""select
t1.prod_id
,t1.lctn_id
,t1.cust_id
,t1.keyfigure_dt
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,t1.totl_ord_actuals_rsd_cd
,t1.lctn_splt_consensus_dmnd_pln_cd
,t1.past_mth_bcklog_ord_bw_qty_cd
,t1.idpt_ord_actuals_rsd_cd
,t1.ststcl_frcst_usr_dfnd_cd
,t1.ststcl_frcst_btch_cd
,t1.totl_shp_actl_pgi_cd
,t1.totl_shp_actl_rsd_cd
,t1.sop_dmnd_plnr_ovrd_id
,t1.bsln_mtrl_frcst_ovrd_id
,t1.ord_backlogrsd_cd
,t1.bsln_mtrl_frcst_lwr_prio_cd
,t1.dpndt_ord_actuals_rsd_cd
,t1.rvn_actuals_cd
,t2.totl_ord_actuals_rsd_cd_mnthly
,t2.lctn_splt_consensus_dmnd_pln_cd_mnthly
,t2.past_mth_bcklog_ord_bw_qty_cd_mnthly
,t2.idpt_ord_actuals_rsd_cd_mnthly
,t2.ststcl_frcst_usr_dfnd_cd_mnthly
,t2.ststcl_frcst_btch_cd_mnthly
,t2.totl_shp_actl_pgi_cd_mnthly
,t2.totl_shp_actl_rsd_cd_mnthly
,t2.sop_dmnd_plnr_ovrd_id_mnthly
,t2.bsln_mtrl_frcst_ovrd_id_mnthly
,t2.ord_backlogrsd_cd_mnthly
,t2.bsln_mtrl_frcst_lwr_prio_cd_mnthly
,t2.dpndt_ord_actuals_rsd_cd_mnthly
,t2.rvn_actuals_cd_mnthly
,t3.totl_ord_actuals_rsd_cd_m1
,t3.totl_ord_actuals_rsd_cd_m2
,t3.totl_ord_actuals_rsd_cd_m3
,t3.lctn_splt_consensus_dmnd_pln_cd_m1
,t3.lctn_splt_consensus_dmnd_pln_cd_m2
,t3.lctn_splt_consensus_dmnd_pln_cd_m3
,t3.past_mth_bcklog_ord_bw_qty_cd_m1
,t3.past_mth_bcklog_ord_bw_qty_cd_m2
,t3.past_mth_bcklog_ord_bw_qty_cd_m3
,t3.idpt_ord_actuals_rsd_cd_m1
,t3.idpt_ord_actuals_rsd_cd_m2
,t3.idpt_ord_actuals_rsd_cd_m3
,t3.ststcl_frcst_usr_dfnd_cd_m1
,t3.ststcl_frcst_usr_dfnd_cd_m2
,t3.ststcl_frcst_usr_dfnd_cd_m3
,t3.ststcl_frcst_btch_cd_m1
,t3.ststcl_frcst_btch_cd_m2
,t3.ststcl_frcst_btch_cd_m3
,t3.totl_shp_actl_pgi_cd_m1
,t3.totl_shp_actl_pgi_cd_m2
,t3.totl_shp_actl_pgi_cd_m3
,t3.totl_shp_actl_rsd_cd_m1
,t3.totl_shp_actl_rsd_cd_m2
,t3.totl_shp_actl_rsd_cd_m3
,t3.sop_dmnd_plnr_ovrd_id_m1
,t3.sop_dmnd_plnr_ovrd_id_m2
,t3.sop_dmnd_plnr_ovrd_id_m3
,t3.bsln_mtrl_frcst_ovrd_id_m1
,t3.bsln_mtrl_frcst_ovrd_id_m2
,t3.bsln_mtrl_frcst_ovrd_id_m3
,t3.ord_backlogrsd_cd_m1
,t3.ord_backlogrsd_cd_m2
,t3.ord_backlogrsd_cd_m3
,t3.bsln_mtrl_frcst_lwr_prio_cd_m1
,t3.bsln_mtrl_frcst_lwr_prio_cd_m2
,t3.bsln_mtrl_frcst_lwr_prio_cd_m3
,t3.dpndt_ord_actuals_rsd_cd_m1
,t3.dpndt_ord_actuals_rsd_cd_m2
,t3.dpndt_ord_actuals_rsd_cd_m3
,t3.rvn_actuals_cd_m1
,t3.rvn_actuals_cd_m2
,t3.rvn_actuals_cd_m3
,t1.vrtl_Theater_cd
,t1.dmnd_typ_cd
,t1.bs_prod_cd
,t1.prod_cgy_Desc_cd
from
""" + dbNameConsmtn + """.""" + hybrid_it_tchnl_wk_prod_lctn_cust_fnl_dmnsn + """ t1
LEFT join
""" + dbNameConsmtn + """.""" + hybrid_it_tchnl_wk_prod_lctn_cust_mnthly_dmnsn + """ t2
on 
t1.prod_id = t2.prod_id
and
t1.lctn_id = t2.lctn_id
and
t1.cust_id = t2.cust_id
and 
t1.keyfigure_yr = t2.keyfigure_yr 
and 
t1.keyfigure_mnth=t2.keyfigure_mnth
LEFT join
""" + dbNameConsmtn + """.""" + hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_dmnsn + """ t3
on 
t1.prod_id = t3.prod_id
and
t1.lctn_id = t3.lctn_id
and
t1.cust_id = t3.cust_id
and
t1.qtr=t3.qtr
and 
t1.fiscal_yr = t3.fiscal_yr""")

    loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_all_vlue_dmnsn)

    var hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_frcst_dmnsn = "hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_frcst_dmnsn"

    transformedDF = spark.sql("""select 
fiscal_yr
,qtr 
,COALESCE(max(totl_ord_actuals_rsd_cd_ttl_m1),0L) as totl_ord_actuals_rsd_cd_ttl_m1
,COALESCE(max(totl_ord_actuals_rsd_cd_ttl_m2),0L) as totl_ord_actuals_rsd_cd_ttl_m2
,COALESCE(max(totl_ord_actuals_rsd_cd_ttl_m3),0L) as totl_ord_actuals_rsd_cd_ttl_m3
,COALESCE(max(bsln_mtrl_frcst_ovrd_id_ttl_m1),0L) as bsln_mtrl_frcst_ovrd_id_ttl_m1
,COALESCE(max(bsln_mtrl_frcst_ovrd_id_ttl_m2),0L) as bsln_mtrl_frcst_ovrd_id_ttl_m2
,COALESCE(max(bsln_mtrl_frcst_ovrd_id_ttl_m3),0L) as bsln_mtrl_frcst_ovrd_id_ttl_m3
from
(select 
Keyfigure_mnth
,fiscal_yr
,qtr 
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_ttl_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_ttl_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.totl_ord_actuals_rsd_cd_map[Keyfigure_mnth]) END as totl_ord_actuals_rsd_cd_ttl_m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.bsln_mtrl_frcst_ovrd_id_map[Keyfigure_mnth]) END as bsln_mtrl_frcst_ovrd_id_ttl_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.bsln_mtrl_frcst_ovrd_id_map[Keyfigure_mnth]) END as bsln_mtrl_frcst_ovrd_id_ttl_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.bsln_mtrl_frcst_ovrd_id_map[Keyfigure_mnth]) END as bsln_mtrl_frcst_ovrd_id_ttl_m3
from
( 
select 
Keyfigure_mnth
,fiscal_yr
,qtr 
,map(Keyfigure_mnth,totl_ord_actuals_rsd_cd_ttl) as totl_ord_actuals_rsd_cd_map
,map(Keyfigure_mnth,bsln_mtrl_frcst_ovrd_id_ttl) as bsln_mtrl_frcst_ovrd_id_map
from (
select 
Keyfigure_mnth
,fiscal_yr
,qtr 
,sum(totl_ord_actuals_rsd_cd_mnthly) as totl_ord_actuals_rsd_cd_ttl
,sum(bsln_mtrl_frcst_ovrd_id_mnthly) as bsln_mtrl_frcst_ovrd_id_ttl
from """ + dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_mnthly_dmnsn + """
group by
Keyfigure_mnth
,fiscal_yr
,qtr)t ) a 
group by
Keyfigure_mnth
,fiscal_yr
,qtr ) b
group by
fiscal_yr
,qtr """)

    loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_frcst_dmnsn)

    var snapshot_type = spark.sql("""select monthly_snapshot_dt from """ + dbNameConsmtn + """.bmt_hybrid_mthly_snpsht_dmnsn where monthly_snapshot_dt = current_date""")
    val bufferDays = 32
    val dailyLimit = 1
    val weeklyLimit = 182
    val monthlyLimit = 366
    val sdf = new SimpleDateFormat("yyyy-MM-dd")

    def daysAgo(days: Int): String = {
      val calender = Calendar.getInstance()
      calender.add(Calendar.DAY_OF_YEAR, -days)
      sdf.format(calender.getTime())
    }

    if (snapshot_type.count().toInt != 0) {

      transformedDF = spark.sql("""select
crc32(lower(trim(CONCAT(coalesce(cust_id,""),coalesce(prod_id,""))))) as hpn_cust_prod_ky
,crc32(lower(trim(CONCAT(coalesce(lctn_id,""),coalesce(prod_id,""))))) as hpn_lctn_prod_ky
,t1.prod_id
,t1.lctn_id
,t1.cust_id
,t1.vrtl_theater_cd
,t1.dmnd_typ_cd
,t1.bs_prod_cd
,t1.prod_cgy_Desc_cd
,date(t1.keyfigure_dt)
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,t1.totl_ord_actuals_rsd_cd
,t1.lctn_splt_consensus_dmnd_pln_cd
,t1.past_mth_bcklog_ord_bw_qty_cd
,t1.idpt_ord_actuals_rsd_cd
,t1.ststcl_frcst_usr_dfnd_cd
,t1.ststcl_frcst_btch_cd
,t1.totl_shp_actl_pgi_cd
,t1.totl_shp_actl_rsd_cd
,t1.sop_dmnd_plnr_ovrd_id
,t1.bsln_mtrl_frcst_ovrd_id
,t1.ord_backlogrsd_cd
,t1.bsln_mtrl_frcst_lwr_prio_cd
,t1.dpndt_ord_actuals_rsd_cd
,t1.rvn_actuals_cd
,t1.totl_ord_actuals_rsd_cd_mnthly
,t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
,t1.past_mth_bcklog_ord_bw_qty_cd_mnthly
,t1.idpt_ord_actuals_rsd_cd_mnthly
,t1.ststcl_frcst_usr_dfnd_cd_mnthly
,t1.ststcl_frcst_btch_cd_mnthly
,t1.totl_shp_actl_pgi_cd_mnthly
,t1.totl_shp_actl_rsd_cd_mnthly
,t1.sop_dmnd_plnr_ovrd_id_mnthly
,t1.bsln_mtrl_frcst_ovrd_id_mnthly
,t1.ord_backlogrsd_cd_mnthly
,t1.bsln_mtrl_frcst_lwr_prio_cd_mnthly
,t1.dpndt_ord_actuals_rsd_cd_mnthly
,t1.rvn_actuals_cd_mnthly
,t1.totl_ord_actuals_rsd_cd_m1
,t1.totl_ord_actuals_rsd_cd_m2
,t1.totl_ord_actuals_rsd_cd_m3
,t1.lctn_splt_consensus_dmnd_pln_cd_m1
,t1.lctn_splt_consensus_dmnd_pln_cd_m2
,t1.lctn_splt_consensus_dmnd_pln_cd_m3
,t1.past_mth_bcklog_ord_bw_qty_cd_m1
,t1.past_mth_bcklog_ord_bw_qty_cd_m2
,t1.past_mth_bcklog_ord_bw_qty_cd_m3
,t1.idpt_ord_actuals_rsd_cd_m1
,t1.idpt_ord_actuals_rsd_cd_m2
,t1.idpt_ord_actuals_rsd_cd_m3
,t1.ststcl_frcst_usr_dfnd_cd_m1
,t1.ststcl_frcst_usr_dfnd_cd_m2
,t1.ststcl_frcst_usr_dfnd_cd_m3
,t1.ststcl_frcst_btch_cd_m1
,t1.ststcl_frcst_btch_cd_m2
,t1.ststcl_frcst_btch_cd_m3
,t1.totl_shp_actl_pgi_cd_m1
,t1.totl_shp_actl_pgi_cd_m2
,t1.totl_shp_actl_pgi_cd_m3
,t1.totl_shp_actl_rsd_cd_m1
,t1.totl_shp_actl_rsd_cd_m2
,t1.totl_shp_actl_rsd_cd_m3
,t1.sop_dmnd_plnr_ovrd_id_m1
,t1.sop_dmnd_plnr_ovrd_id_m2
,t1.sop_dmnd_plnr_ovrd_id_m3
,t1.bsln_mtrl_frcst_ovrd_id_m1
,t1.bsln_mtrl_frcst_ovrd_id_m2
,t1.bsln_mtrl_frcst_ovrd_id_m3
,t1.ord_backlogrsd_cd_m1
,t1.ord_backlogrsd_cd_m2
,t1.ord_backlogrsd_cd_m3
,t1.bsln_mtrl_frcst_lwr_prio_cd_m1
,t1.bsln_mtrl_frcst_lwr_prio_cd_m2
,t1.bsln_mtrl_frcst_lwr_prio_cd_m3
,t1.dpndt_ord_actuals_rsd_cd_m1
,t1.dpndt_ord_actuals_rsd_cd_m2
,t1.dpndt_ord_actuals_rsd_cd_m3
,t1.rvn_actuals_cd_m1
,t1.rvn_actuals_cd_m2
,t1.rvn_actuals_cd_m3
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) or month(current_timestamp) in ("11","12","1") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q4") THEN  (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
END as bsln_mtrl_frcst
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) and keyfigure_mnth not in ("11","12") or month(current_timestamp) in ("11","12","1") and t1.qtr not in ("Q1") or month(current_timestamp) in ("2","3","4") and t1.qtr not in ("Q1","Q2") OR month(current_timestamp) in ("5","6","7") and t1.qtr not in ("Q1","Q2","Q3") THEN  (lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3+lctn_splt_consensus_dmnd_pln_cd_m3)
END as lctn_splt_consensus_dmnd_pln_cd_qtr
,t1.ord_backlogrsd_cd + t1.totl_shp_actl_pgi_cd - t1.totl_ord_actuals_rsd_cd as bcklog_cryovr_cd
,t1.bsln_mtrl_frcst_ovrd_id - t1.totl_ord_actuals_rsd_cd as consensus_pln_to_go_cd
,coalesce(t1.totl_ord_actuals_rsd_cd/t1.bsln_mtrl_frcst_lwr_prio_cd,0L) as mtd_qtd_attnmnt_bsln_pln_cd
,t1.bsln_mtrl_frcst_ovrd_id/t1.totl_ord_actuals_rsd_cd  as pln_accry_bsln_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.bsln_mtrl_frcst_ovrd_id_mnthly END as actl_bsln_mtrl_frcst_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
WHEN keyfigure_mnth = month(current_timestamp) THEN t1.totl_shp_actl_rsd_cd_mnthly + t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
ELSE t1.lctn_splt_consensus_dmnd_pln_cd_mnthly END as actl_lctn_splt_consensus_dmnd_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_usr_dfnd_cd_mnthly END as actl_ststcl_frcst_usr_dfnd_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_btch_cd_mnthly END as actl_ststcl_frcst_btch_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.bsln_mtrl_frcst_lwr_prio_cd_mnthly END as actl_bsln_dmnd_frcst_stat_cd
,t1.totl_ord_actuals_rsd_cd_mnthly/(t1.totl_ord_actuals_rsd_cd_m1+t1.totl_ord_actuals_rsd_cd_m2+t1.totl_ord_actuals_rsd_cd_m3) as lnarty_fr_qtr
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,dmnd_typ_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_dmnd_typ_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by prod_cgy_Desc_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_prod_cgy_Desc_cd
,t2.totl_ord_actuals_rsd_cd_ttl_m1
,t2.totl_ord_actuals_rsd_cd_ttl_m2
,t2.totl_ord_actuals_rsd_cd_ttl_m3
,t2.bsln_mtrl_frcst_ovrd_id_ttl_m1
,t2.bsln_mtrl_frcst_ovrd_id_ttl_m2
,t2.bsln_mtrl_frcst_ovrd_id_ttl_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
else 0
END as abs_err_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) else 0 end as abs_err_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
else 0 end as abs_err_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3) else 0 end as MAPE_quartr_prcnt
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1 else 0 end as frcst_mape_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) /totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2 else 0 end as frcst_mape_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3) else 0 end as frcst_mape_prcnt_m3
,totl_ord_actuals_rsd_cd_ttl_m1-bsln_mtrl_frcst_ovrd_id_ttl_m1/bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m1 as frcst_bias_nrmlzd_m1
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2-bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2/bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2 as frcst_bias_nrmlzd_m2
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3-bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+bsln_mtrl_frcst_ovrd_id_ttl_m3/bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3+bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+bsln_mtrl_frcst_ovrd_id_ttl_m3 as frcst_bias_nrmlzd_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) else 0 end as frcst_vltalty_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) else 0 end as frcst_vltalty_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3) else 0 end as frcst_vltalty_prcnt_m3
,stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3) as frcst_vltalty_prcnt_qtr
,current_timestamp as ins_ts
,0 as lag_totl_ord_actuals_rsd_cd
,0 as lag_lctn_splt_consensus_dmnd_pln_cd
,0 as wk_ovr_wk_chng_totl_ord_actuals_rsd_cd
,0 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_cd
,0 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_prcnt_cd
,"MONTHLY"
,CURRENT_DATE as snpsht_dt
from
""" + dbNameConsmtn + """.""" + hybrid_it_tchnl_wk_prod_lctn_cust_all_vlue_dmnsn + """ t1
  left join
""" + dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_frcst_dmnsn + """ t2
on 
t1.qtr=t2.qtr and
t1.fiscal_yr=t2.fiscal_yr""")

    for (i <- monthlyLimit to monthlyLimit + bufferDays) {
      var dateMonthly = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + dbNameConsmtn + "."+ consmptnTable +" DROP PARTITION(snpsht_typ='MONTHLY',snpsht_dt='" + dateMonthly + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for all possible monthly partitions")
        }
      }
    }
            
    } else if (dowInt.format(now) == "7") {
      
      
var hybrid_prdt_loc_cust_fact_cal_dmnsn="hybrid_prdt_loc_cust_fact_cal_dmnsn"

transformedDF = spark.sql("""select *,
lag(totl_ord_actuals_rsd_cd,1,0) over (partition by keyfigure_dt,prod_id,lctn_id,cust_id order by snpsht_dt ) as lag_totl_ord_actuals_rsd_cd
,lag(lctn_splt_consensus_dmnd_pln_cd,1,0) over (partition by keyfigure_dt,prod_id,lctn_id,cust_id order by snpsht_dt ) as lag_lctn_splt_consensus_dmnd_pln_cd
from 
(select
prod_id
,lctn_id
,cust_id
,keyfigure_dt
,coalesce(totl_ord_actuals_rsd_cd,0L) as totl_ord_actuals_rsd_cd
,coalesce(lctn_splt_consensus_dmnd_pln_cd,0L) as lctn_splt_consensus_dmnd_pln_cd
,current_date() as snpsht_dt
from """+ dbNameConsmtn + "." + """hybrid_it_tchnl_wk_prod_lctn_cust_all_vlue_dmnsn
union all
select
prod_id
,lctn_id
,cust_id
,keyfigure_dt
,coalesce(totl_ord_actuals_rsd_cd,0L) as totl_ord_actuals_rsd_cd
,coalesce(lctn_splt_consensus_dmnd_pln_cd,0L) as lctn_splt_consensus_dmnd_pln_cd
,snpsht_dt
from """+ dbNameConsmtn + "." + consmptnTable + """ t where snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ ='WEEKLY'order by snpsht_dt desc limit 1))A""")

loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + hybrid_prdt_loc_cust_fact_cal_dmnsn)

transformedDF = spark.sql("""select
crc32(lower(trim(CONCAT(coalesce(t1.cust_id,""),coalesce(t1.prod_id,""))))) as hpn_cust_prod_ky
,crc32(lower(trim(CONCAT(coalesce(t1.lctn_id,""),coalesce(t1.prod_id,""))))) as hpn_lctn_prod_ky
,t1.prod_id
,t1.lctn_id
,t1.cust_id
,t1.vrtl_theater_cd
,t1.dmnd_typ_cd
,t1.bs_prod_cd
,t1.prod_cgy_Desc_cd
,date(t1.keyfigure_dt)
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,t1.totl_ord_actuals_rsd_cd
,t1.lctn_splt_consensus_dmnd_pln_cd
,t1.past_mth_bcklog_ord_bw_qty_cd
,t1.idpt_ord_actuals_rsd_cd
,t1.ststcl_frcst_usr_dfnd_cd
,t1.ststcl_frcst_btch_cd
,t1.totl_shp_actl_pgi_cd
,t1.totl_shp_actl_rsd_cd
,t1.sop_dmnd_plnr_ovrd_id
,t1.bsln_mtrl_frcst_ovrd_id
,t1.ord_backlogrsd_cd
,t1.bsln_mtrl_frcst_lwr_prio_cd
,t1.dpndt_ord_actuals_rsd_cd
,t1.rvn_actuals_cd
,t1.totl_ord_actuals_rsd_cd_mnthly
,t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
,t1.past_mth_bcklog_ord_bw_qty_cd_mnthly
,t1.idpt_ord_actuals_rsd_cd_mnthly
,t1.ststcl_frcst_usr_dfnd_cd_mnthly
,t1.ststcl_frcst_btch_cd_mnthly
,t1.totl_shp_actl_pgi_cd_mnthly
,t1.totl_shp_actl_rsd_cd_mnthly
,t1.sop_dmnd_plnr_ovrd_id_mnthly
,t1.bsln_mtrl_frcst_ovrd_id_mnthly
,t1.ord_backlogrsd_cd_mnthly
,t1.bsln_mtrl_frcst_lwr_prio_cd_mnthly
,t1.dpndt_ord_actuals_rsd_cd_mnthly
,t1.rvn_actuals_cd_mnthly
,t1.totl_ord_actuals_rsd_cd_m1
,t1.totl_ord_actuals_rsd_cd_m2
,t1.totl_ord_actuals_rsd_cd_m3
,t1.lctn_splt_consensus_dmnd_pln_cd_m1
,t1.lctn_splt_consensus_dmnd_pln_cd_m2
,t1.lctn_splt_consensus_dmnd_pln_cd_m3
,t1.past_mth_bcklog_ord_bw_qty_cd_m1
,t1.past_mth_bcklog_ord_bw_qty_cd_m2
,t1.past_mth_bcklog_ord_bw_qty_cd_m3
,t1.idpt_ord_actuals_rsd_cd_m1
,t1.idpt_ord_actuals_rsd_cd_m2
,t1.idpt_ord_actuals_rsd_cd_m3
,t1.ststcl_frcst_usr_dfnd_cd_m1
,t1.ststcl_frcst_usr_dfnd_cd_m2
,t1.ststcl_frcst_usr_dfnd_cd_m3
,t1.ststcl_frcst_btch_cd_m1
,t1.ststcl_frcst_btch_cd_m2
,t1.ststcl_frcst_btch_cd_m3
,t1.totl_shp_actl_pgi_cd_m1
,t1.totl_shp_actl_pgi_cd_m2
,t1.totl_shp_actl_pgi_cd_m3
,t1.totl_shp_actl_rsd_cd_m1
,t1.totl_shp_actl_rsd_cd_m2
,t1.totl_shp_actl_rsd_cd_m3
,t1.sop_dmnd_plnr_ovrd_id_m1
,t1.sop_dmnd_plnr_ovrd_id_m2
,t1.sop_dmnd_plnr_ovrd_id_m3
,t1.bsln_mtrl_frcst_ovrd_id_m1
,t1.bsln_mtrl_frcst_ovrd_id_m2
,t1.bsln_mtrl_frcst_ovrd_id_m3
,t1.ord_backlogrsd_cd_m1
,t1.ord_backlogrsd_cd_m2
,t1.ord_backlogrsd_cd_m3
,t1.bsln_mtrl_frcst_lwr_prio_cd_m1
,t1.bsln_mtrl_frcst_lwr_prio_cd_m2
,t1.bsln_mtrl_frcst_lwr_prio_cd_m3
,t1.dpndt_ord_actuals_rsd_cd_m1
,t1.dpndt_ord_actuals_rsd_cd_m2
,t1.dpndt_ord_actuals_rsd_cd_m3
,t1.rvn_actuals_cd_m1
,t1.rvn_actuals_cd_m2
,t1.rvn_actuals_cd_m3
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) or month(current_timestamp) in ("11","12","1") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q4") THEN  (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
END as bsln_mtrl_frcst
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) and keyfigure_mnth not in ("11","12") or month(current_timestamp) in ("11","12","1") and t1.qtr not in ("Q1") or month(current_timestamp) in ("2","3","4") and t1.qtr not in ("Q1","Q2") OR month(current_timestamp) in ("5","6","7") and t1.qtr not in ("Q1","Q2","Q3") THEN  (lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3+lctn_splt_consensus_dmnd_pln_cd_m3)
END as lctn_splt_consensus_dmnd_pln_cd_qtr
,t1.ord_backlogrsd_cd + t1.totl_shp_actl_pgi_cd - t1.totl_ord_actuals_rsd_cd as bcklog_cryovr_cd
,t1.bsln_mtrl_frcst_ovrd_id - t1.totl_ord_actuals_rsd_cd as consensus_pln_to_go_cd
,coalesce(t1.totl_ord_actuals_rsd_cd/t1.bsln_mtrl_frcst_lwr_prio_cd,0L) as mtd_qtd_attnmnt_bsln_pln_cd
,t1.bsln_mtrl_frcst_ovrd_id/t1.totl_ord_actuals_rsd_cd  as pln_accry_bsln_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.bsln_mtrl_frcst_ovrd_id_mnthly END as actl_bsln_mtrl_frcst_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
WHEN keyfigure_mnth = month(current_timestamp) THEN t1.totl_shp_actl_rsd_cd_mnthly + t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
ELSE t1.lctn_splt_consensus_dmnd_pln_cd_mnthly END as actl_lctn_splt_consensus_dmnd_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_usr_dfnd_cd_mnthly END as actl_ststcl_frcst_usr_dfnd_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_btch_cd_mnthly END as actl_ststcl_frcst_btch_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.bsln_mtrl_frcst_lwr_prio_cd_mnthly END as actl_bsln_dmnd_frcst_stat_cd
,t1.totl_ord_actuals_rsd_cd_mnthly/(t1.totl_ord_actuals_rsd_cd_m1+t1.totl_ord_actuals_rsd_cd_m2+t1.totl_ord_actuals_rsd_cd_m3) as lnarty_fr_qtr
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by t1.cust_id,t1.Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,t1.Keyfigure_dt)*100 as prcnt_splt_by_cust_id_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by t1.cust_id,dmnd_typ_cd,t1.Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,t1.Keyfigure_dt)*100 as prcnt_splt_by_cust_id_dmnd_typ_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by prod_cgy_Desc_cd,t1.Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,t1.Keyfigure_dt)*100 as prcnt_splt_by_prod_cgy_Desc_cd
,t2.totl_ord_actuals_rsd_cd_ttl_m1
,t2.totl_ord_actuals_rsd_cd_ttl_m2
,t2.totl_ord_actuals_rsd_cd_ttl_m3
,t2.bsln_mtrl_frcst_ovrd_id_ttl_m1
,t2.bsln_mtrl_frcst_ovrd_id_ttl_m2
,t2.bsln_mtrl_frcst_ovrd_id_ttl_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
else 0
END as abs_err_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) else 0 end as abs_err_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
else 0 end as abs_err_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3) else 0 end as MAPE_quartr_prcnt
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1 else 0 end as frcst_mape_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) /totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2 else 0 end as frcst_mape_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3) else 0 end as frcst_mape_prcnt_m3
,totl_ord_actuals_rsd_cd_ttl_m1-bsln_mtrl_frcst_ovrd_id_ttl_m1/bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m1 as frcst_bias_nrmlzd_m1
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2-bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2/bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2 as frcst_bias_nrmlzd_m2
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3-bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+bsln_mtrl_frcst_ovrd_id_ttl_m3/bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3+bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+bsln_mtrl_frcst_ovrd_id_ttl_m3 as frcst_bias_nrmlzd_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) else 0 end as frcst_vltalty_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) else 0 end as frcst_vltalty_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3) else 0 end as frcst_vltalty_prcnt_m3
,stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3) as frcst_vltalty_prcnt_qtr
,current_timestamp as ins_ts
,COALESCE(lag_totl_ord_actuals_rsd_cd,0L) as lag_totl_ord_actuals_rsd_cd
,COALESCE(lag_lctn_splt_consensus_dmnd_pln_cd,0L) as lag_lctn_splt_consensus_dmnd_pln_cd
,t1.totl_ord_actuals_rsd_cd-COALESCE(lag_totl_ord_actuals_rsd_cd,0L) as wk_ovr_wk_chng_totl_ord_actuals_rsd_cd
,t1.lctn_splt_consensus_dmnd_pln_cd-COALESCE(lag_lctn_splt_consensus_dmnd_pln_cd,0L) as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_cd
,(t1.lctn_splt_consensus_dmnd_pln_cd-COALESCE(lag_lctn_splt_consensus_dmnd_pln_cd,0L))/100 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_prcnt_cd
,"WEEKLY"
,current_date() as snpsht_dt
from
""" + dbNameConsmtn + """.""" + hybrid_it_tchnl_wk_prod_lctn_cust_all_vlue_dmnsn + """ t1
left join
""" + dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_frcst_dmnsn + """ t2
on 
t1.qtr=t2.qtr and
t1.fiscal_yr=t2.fiscal_yr
left join """+dbNameConsmtn + "." +hybrid_prdt_loc_cust_fact_cal_dmnsn +""" t3
on
t1.prod_id=t3.prod_id
and t1.lctn_id=t3.lctn_id
and t1.cust_id=t3.cust_id
and t1.keyfigure_dt=t3.keyfigure_dt
and current_date=t3.snpsht_dt""")

    for (i <- weeklyLimit to weeklyLimit + bufferDays) {
      var dateWeekly = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + dbNameConsmtn + "."+ consmptnTable +" DROP PARTITION(snpsht_typ='WEEKLY',snpsht_dt='" + dateWeekly + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for all possible weekly partitions")
        }
      }
    }

    } else {
      transformedDF = spark.sql("""select
crc32(lower(trim(CONCAT(coalesce(cust_id,""),coalesce(prod_id,""))))) as hpn_cust_prod_ky
,crc32(lower(trim(CONCAT(coalesce(lctn_id,""),coalesce(prod_id,""))))) as hpn_lctn_prod_ky
,t1.prod_id
,t1.lctn_id
,t1.cust_id
,t1.vrtl_theater_cd
,t1.dmnd_typ_cd
,t1.bs_prod_cd
,t1.prod_cgy_Desc_cd
,date(t1.keyfigure_dt)
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,t1.totl_ord_actuals_rsd_cd
,t1.lctn_splt_consensus_dmnd_pln_cd
,t1.past_mth_bcklog_ord_bw_qty_cd
,t1.idpt_ord_actuals_rsd_cd
,t1.ststcl_frcst_usr_dfnd_cd
,t1.ststcl_frcst_btch_cd
,t1.totl_shp_actl_pgi_cd
,t1.totl_shp_actl_rsd_cd
,t1.sop_dmnd_plnr_ovrd_id
,t1.bsln_mtrl_frcst_ovrd_id
,t1.ord_backlogrsd_cd
,t1.bsln_mtrl_frcst_lwr_prio_cd
,t1.dpndt_ord_actuals_rsd_cd
,t1.rvn_actuals_cd
,t1.totl_ord_actuals_rsd_cd_mnthly
,t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
,t1.past_mth_bcklog_ord_bw_qty_cd_mnthly
,t1.idpt_ord_actuals_rsd_cd_mnthly
,t1.ststcl_frcst_usr_dfnd_cd_mnthly
,t1.ststcl_frcst_btch_cd_mnthly
,t1.totl_shp_actl_pgi_cd_mnthly
,t1.totl_shp_actl_rsd_cd_mnthly
,t1.sop_dmnd_plnr_ovrd_id_mnthly
,t1.bsln_mtrl_frcst_ovrd_id_mnthly
,t1.ord_backlogrsd_cd_mnthly
,t1.bsln_mtrl_frcst_lwr_prio_cd_mnthly
,t1.dpndt_ord_actuals_rsd_cd_mnthly
,t1.rvn_actuals_cd_mnthly
,t1.totl_ord_actuals_rsd_cd_m1
,t1.totl_ord_actuals_rsd_cd_m2
,t1.totl_ord_actuals_rsd_cd_m3
,t1.lctn_splt_consensus_dmnd_pln_cd_m1
,t1.lctn_splt_consensus_dmnd_pln_cd_m2
,t1.lctn_splt_consensus_dmnd_pln_cd_m3
,t1.past_mth_bcklog_ord_bw_qty_cd_m1
,t1.past_mth_bcklog_ord_bw_qty_cd_m2
,t1.past_mth_bcklog_ord_bw_qty_cd_m3
,t1.idpt_ord_actuals_rsd_cd_m1
,t1.idpt_ord_actuals_rsd_cd_m2
,t1.idpt_ord_actuals_rsd_cd_m3
,t1.ststcl_frcst_usr_dfnd_cd_m1
,t1.ststcl_frcst_usr_dfnd_cd_m2
,t1.ststcl_frcst_usr_dfnd_cd_m3
,t1.ststcl_frcst_btch_cd_m1
,t1.ststcl_frcst_btch_cd_m2
,t1.ststcl_frcst_btch_cd_m3
,t1.totl_shp_actl_pgi_cd_m1
,t1.totl_shp_actl_pgi_cd_m2
,t1.totl_shp_actl_pgi_cd_m3
,t1.totl_shp_actl_rsd_cd_m1
,t1.totl_shp_actl_rsd_cd_m2
,t1.totl_shp_actl_rsd_cd_m3
,t1.sop_dmnd_plnr_ovrd_id_m1
,t1.sop_dmnd_plnr_ovrd_id_m2
,t1.sop_dmnd_plnr_ovrd_id_m3
,t1.bsln_mtrl_frcst_ovrd_id_m1
,t1.bsln_mtrl_frcst_ovrd_id_m2
,t1.bsln_mtrl_frcst_ovrd_id_m3
,t1.ord_backlogrsd_cd_m1
,t1.ord_backlogrsd_cd_m2
,t1.ord_backlogrsd_cd_m3
,t1.bsln_mtrl_frcst_lwr_prio_cd_m1
,t1.bsln_mtrl_frcst_lwr_prio_cd_m2
,t1.bsln_mtrl_frcst_lwr_prio_cd_m3
,t1.dpndt_ord_actuals_rsd_cd_m1
,t1.dpndt_ord_actuals_rsd_cd_m2
,t1.dpndt_ord_actuals_rsd_cd_m3
,t1.rvn_actuals_cd_m1
,t1.rvn_actuals_cd_m2
,t1.rvn_actuals_cd_m3
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) or month(current_timestamp) in ("11","12","1") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q4") THEN  (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
END as bsln_mtrl_frcst
,CASE WHEN keyfigure_yr < year(current_timestamp) and keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN keyfigure_yr > year(current_timestamp) and keyfigure_mnth not in ("11","12") or month(current_timestamp) in ("11","12","1") and t1.qtr not in ("Q1") or month(current_timestamp) in ("2","3","4") and t1.qtr not in ("Q1","Q2") OR month(current_timestamp) in ("5","6","7") and t1.qtr not in ("Q1","Q2","Q3") THEN  (lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("11") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m1+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("12") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m2+lctn_splt_consensus_dmnd_pln_cd_m3)
WHEN  month(current_timestamp) in ("1") and keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and keyfigure_mnth in ("8","9","10") THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3+lctn_splt_consensus_dmnd_pln_cd_m3)
END as lctn_splt_consensus_dmnd_pln_cd_qtr
,t1.ord_backlogrsd_cd + t1.totl_shp_actl_pgi_cd - t1.totl_ord_actuals_rsd_cd as bcklog_cryovr_cd
,t1.bsln_mtrl_frcst_ovrd_id - t1.totl_ord_actuals_rsd_cd as consensus_pln_to_go_cd
,coalesce(t1.totl_ord_actuals_rsd_cd/t1.bsln_mtrl_frcst_lwr_prio_cd,0L) as mtd_qtd_attnmnt_bsln_pln_cd
,t1.bsln_mtrl_frcst_ovrd_id/t1.totl_ord_actuals_rsd_cd  as pln_accry_bsln_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.bsln_mtrl_frcst_ovrd_id_mnthly END as actl_bsln_mtrl_frcst_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
WHEN keyfigure_mnth = month(current_timestamp) THEN t1.totl_shp_actl_rsd_cd_mnthly + t1.lctn_splt_consensus_dmnd_pln_cd_mnthly
ELSE t1.lctn_splt_consensus_dmnd_pln_cd_mnthly END as actl_lctn_splt_consensus_dmnd_pln_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_usr_dfnd_cd_mnthly END as actl_ststcl_frcst_usr_dfnd_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.ststcl_frcst_btch_cd_mnthly END as actl_ststcl_frcst_btch_cd
,CASE WHEN keyfigure_mnth < month(current_timestamp) or keyfigure_yr < year(current_timestamp) THEN t1.totl_ord_actuals_rsd_cd_mnthly
ELSE t1.bsln_mtrl_frcst_lwr_prio_cd_mnthly END as actl_bsln_dmnd_frcst_stat_cd
,t1.totl_ord_actuals_rsd_cd_mnthly/(t1.totl_ord_actuals_rsd_cd_m1+t1.totl_ord_actuals_rsd_cd_m2+t1.totl_ord_actuals_rsd_cd_m3) as lnarty_fr_qtr
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by cust_id,dmnd_typ_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_cust_id_dmnd_typ_cd
,sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by prod_cgy_Desc_cd,Keyfigure_dt) / sum(totl_ord_actuals_rsd_cd_mnthly) over (partition by vrtl_Theater_cd,Keyfigure_dt)*100 as prcnt_splt_by_prod_cgy_Desc_cd
,t2.totl_ord_actuals_rsd_cd_ttl_m1
,t2.totl_ord_actuals_rsd_cd_ttl_m2
,t2.totl_ord_actuals_rsd_cd_ttl_m3
,t2.bsln_mtrl_frcst_ovrd_id_ttl_m1
,t2.bsln_mtrl_frcst_ovrd_id_ttl_m2
,t2.bsln_mtrl_frcst_ovrd_id_ttl_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1
else 0
END as abs_err_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) else 0 end as abs_err_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
else 0 end as abs_err_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3) else 0 end as MAPE_quartr_prcnt
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1-totl_ord_actuals_rsd_cd_m1)/totl_ord_actuals_rsd_cd_ttl_m1 else 0 end as frcst_mape_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2)/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2) /totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2 else 0 end as frcst_mape_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then (bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)-(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3/totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3) else 0 end as frcst_mape_prcnt_m3
,totl_ord_actuals_rsd_cd_ttl_m1-bsln_mtrl_frcst_ovrd_id_ttl_m1/bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m1 as frcst_bias_nrmlzd_m1
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2-bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2/bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2 as frcst_bias_nrmlzd_m2
,totl_ord_actuals_rsd_cd_ttl_m1+totl_ord_actuals_rsd_cd_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3-bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+bsln_mtrl_frcst_ovrd_id_ttl_m3/bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+totl_ord_actuals_rsd_cd_ttl_m3+bsln_mtrl_frcst_ovrd_id_ttl_m1+bsln_mtrl_frcst_ovrd_id_ttl_m2+bsln_mtrl_frcst_ovrd_id_ttl_m3 as frcst_bias_nrmlzd_m3
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) else 0 end as frcst_vltalty_prcnt_m1
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) else 0 end as frcst_vltalty_prcnt_m2
,case when month(current_date) in ("11","12") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("1") and t1.qtr = "Q4" and t1.fiscal_yr = year(current_date)-1 then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("2","3","4") and t1.qtr = "Q1" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("5","6","7") and t1.qtr = "Q2" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3)
when month(current_date) in ("8","9","10") and t1.qtr = "Q3" and t1.fiscal_yr = year(current_date) then stddev(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3) else 0 end as frcst_vltalty_prcnt_m3
,stddev(bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+bsln_mtrl_frcst_ovrd_id_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+bsln_mtrl_frcst_ovrd_id_m2+bsln_mtrl_frcst_ovrd_id_m3+totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3) over (partition by t1.qtr,t1.fiscal_yr)/(totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+bsln_mtrl_frcst_ovrd_id_m3) as frcst_vltalty_prcnt_qtr
,current_timestamp as ins_ts
,0 as lag_totl_ord_actuals_rsd_cd
,0 as lag_lctn_splt_consensus_dmnd_pln_cd
,0 as wk_ovr_wk_chng_totl_ord_actuals_rsd_cd
,0 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_cd
,0 as wk_ovr_wk_chng_lctn_splt_consensus_dmnd_pln_prcnt_cd
,"DAILY"
,CURRENT_DATE as snpsht_dt
from
""" + dbNameConsmtn + """.""" + hybrid_it_tchnl_wk_prod_lctn_cust_all_vlue_dmnsn + """ t1
  left join
""" + dbNameConsmtn + "." + hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_frcst_dmnsn + """ t2
on  
t1.qtr=t2.qtr and
t1.fiscal_yr=t2.fiscal_yr""")

    for (i <- dailyLimit to dailyLimit + bufferDays) {
      var dateDaily = daysAgo(i)
      try {
        spark.sql("ALTER TABLE " + dbNameConsmtn + "."+ consmptnTable +" DROP PARTITION(snpsht_typ='DAILY',snpsht_dt='" + dateDaily + "')")
      } catch {
        case allException: org.apache.spark.sql.AnalysisException => {
          logger.info("Running loop for all possible daily partitions")
        }
      }
    }

    }

    //************************Completion Audit Entries*******************************//

    loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable)
    var src_count = 0
    var tgt_count = 0

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    //Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
}
package com.hpe.batch.driver.facts.pdm

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.functions.row_number

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object PdmMtrlWhGrp extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  var pdm_max_btch_id = ld_jb_nr + "_" + "19000101000000"
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val tgtTblRef = propertiesObject.getTgtTblRef()
  val audittable = propertiesObject.getAuditTbl()
  val numPartitions = propertiesObject.getNumPartitions_bref().trim().toInt
  val hive_ref_pdm_mtrl_wh_grp_ref = propertiesObject.getHive_ref_table_pdm_mtrl_wh_grp_ref()
  var src_count = 0
  var tgt_count = 0
  var loadStatus = true
  var ins_gmt_date=""

//************************Set Audit Entries*******************************//

  auditObj.setAudBatchId(pdm_max_btch_id)
  auditObj.setAudDataLayerName("rw_ref")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(hive_ref_pdm_mtrl_wh_grp_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(src_count)
  auditObj.setAudTgtRowCount(tgt_count)

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, "prod_mtrl_mstr")

  try {

    var pdm_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, "prod_mtrl_mstr")

    logger.info("Bifurication Load of PDM Started!!!!!!!!!!!!!")

    logger.info("Max batch id of PDM ref table " + pdm_max_btch_id.toString())

    //**********PDM Material Warehouse Group **************************//
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********pdm_mtrl_wh_grp_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    val Keys_table_pdm_mtrl_wh_grp_ref = propertiesObject.getKeys_table_pdm_mtrl_wh_grp_ref()

    val pdm_mtrl_wh_grp_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_pdm_mtrl_wh_grp_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of PDM Material Warehouse Group  table " + pdm_mtrl_wh_grp_max_btch_id.toString())
	
	  if(pdm_mtrl_wh_grp_max_btch_id=="19001231000000") 	 
	  {
		  ins_gmt_date=pdm_mtrl_wh_grp_max_btch_id.substring(0,4)+'-'+pdm_mtrl_wh_grp_max_btch_id.substring(4,6)+'-'+pdm_mtrl_wh_grp_max_btch_id.substring(6,8)
		} 
		else
		{
			ins_gmt_date=pdm_mtrl_wh_grp_max_btch_id.substring(19,23)+'-'+pdm_mtrl_wh_grp_max_btch_id.substring(23,25)+'-'+pdm_mtrl_wh_grp_max_btch_id.substring(25,27)
		}

    var transformeSrcdDF = spark.sql("""select count(1) from """ + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr > '" + pdm_mtrl_wh_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "'")

    logger.info("""select count(1) from """ + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr > '" + pdm_mtrl_wh_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "'")

    src_count = transformeSrcdDF.first.getLong(0).toInt

    if (src_count != 0) {
	
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudBatchId(pdm_max_btch_id)
	  
      var hiveRefSelect = spark.sql("select " + Keys_table_pdm_mtrl_wh_grp_ref + ",'" + pdm_max_btch_id + "' as ld_jb_nr,idoc_nr, idoc_crtd_ts, ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr > '" + pdm_mtrl_wh_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "'")

      logger.info("select " + Keys_table_pdm_mtrl_wh_grp_ref + ",'" + pdm_max_btch_id + "' as ld_jb_nr,idoc_nr, idoc_crtd_ts, ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr > '" + pdm_mtrl_wh_grp_max_btch_id + "' and ld_jb_nr <= '" + pdm_max_btch_id + "'")

      val filterRow = hiveRefSelect.filter(col("mtrl_wh_mtrl_id").isNotNull.and(col("mtrl_wh_cmplx_cd").isNotNull).and(col("mtrl_wh_storg_mtrl_id").isNotNull).and(col("mtrl_wh_storg_wh_typ_cd").isNotNull))

      val windowSpec = Window.partitionBy("mtrl_wh_mtrl_id", "mtrl_wh_cmplx_cd", "mtrl_wh_storg_mtrl_id", "mtrl_wh_storg_wh_typ_cd", "mtrl_wh_storg_wh_cmplx_cd").orderBy(desc("idoc_crtd_ts"), desc("mtrl_mstr_src_sys_upd_ts"), desc("ins_gmt_ts"))

      val addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(numPartitions)
	  
	  addRowNo.write.mode("Append").format("ORC").insertInto(hive_ref_pdm_mtrl_wh_grp_ref.trim())

	  var transformeTgtdDF = spark.sql("""select count(1) from """ + hive_ref_pdm_mtrl_wh_grp_ref + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr = '" + pdm_max_btch_id + "'")
	  
	  logger.info("""select count(1) from """ + hive_ref_pdm_mtrl_wh_grp_ref + " where date_sub(ins_gmt_dt,-1)>='"+ins_gmt_date+"' and ld_jb_nr = '" + pdm_max_btch_id + "'")

      tgt_count = transformeTgtdDF.first.getLong(0).toInt

      logger.info("+++++++++++############# Target Count: " + tgt_count + " #############+++++++++++")
		
	  logger.info("Data has been loaded to: " + hive_ref_pdm_mtrl_wh_grp_ref + " Table")

      //************************Completion Audit Entries*******************************//

      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudJobStatusCode("success")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("success")
    }
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
      toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    logger.info("************PDM Refine Bifurication completed*************************")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
  } finally {
    if (loadStatus == false) {
      sqlCon.close()
      spark.close()
      System.exit(1)
    } else {
      sqlCon.close()
      spark.close()
    }
  }
}
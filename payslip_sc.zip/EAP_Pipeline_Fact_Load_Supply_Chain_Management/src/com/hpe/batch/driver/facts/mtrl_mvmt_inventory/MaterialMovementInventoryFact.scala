package com.hpe.batch.driver.facts.mtrl_mvmt_inventory

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object MaterialMovementInventoryFact extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  var auditBatchId = ld_jb_nr + "_" + "19000101000000"
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val numPartitions = propertiesObject.getNumPartitions().trim().toInt
  var src_count = 0
  var tgt_count = 0
  var loadStatus = true
  val srcTblConsmtn = propertiesObject.getSrcTblConsmtn()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn()
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (tgtTblConsmtn.trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = tgtTblConsmtn.trim().split("\\.", -1)(0)
    consmptnTable = tgtTblConsmtn.trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  var incrementalDF = spark.emptyDataFrame
  //************************Set Audit Entries*******************************//

  auditObj.setAudBatchId(auditBatchId)
  auditObj.setAudDataLayerName("fact_load")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(objName)
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(src_count)
  auditObj.setAudTgtRowCount(tgt_count)

  try {

    var dmnsn_max_btch_id = Utilities.readMaxCnsmptnBatchId(sqlCon, "mtrl_mvmt_invy_normalised", auditTbl)

    logger.info("Max batch id of dimension table " + dmnsn_max_btch_id.toString())

    var fact_max_btch_id = Utilities.readMaxFactBatchId(sqlCon, "mtrl_mvmt_invy_fact", auditTbl)

    logger.info("Max batch id of mtrl_mvmt_invy_fact table " + fact_max_btch_id.toString())

    //******************* Partition Calculation *******************//

    var ins_gmt_date = ""

    if (fact_max_btch_id == "19001231000000") {
      ins_gmt_date = fact_max_btch_id.substring(0, 4) + "-" + fact_max_btch_id.substring(4, 6) + "-" + fact_max_btch_id.substring(6, 8)
    } else {
      ins_gmt_date = fact_max_btch_id.substring(19, 23) + "-" + fact_max_btch_id.substring(23, 25) + "-01"
    }

    //********************Set Source Count **********************//

    val transformeSrcdDF = spark.sql("""select count(1) from """ + srcTblConsmtn + """ where 
      date_sub(ins_gmt_dt,-31)>='""" + ins_gmt_date + """' and ld_jb_nr > '""" + fact_max_btch_id + """' and ld_jb_nr  <= '""" + dmnsn_max_btch_id + """'""")

    logger.info("""select count(1) from """ + srcTblConsmtn + """ where 
      date_sub(ins_gmt_dt,-31)>='""" + ins_gmt_date + """' and ld_jb_nr > '""" + fact_max_btch_id + """' and ld_jb_nr  <= '""" + dmnsn_max_btch_id + """'""")

    src_count = transformeSrcdDF.first.getLong(0).toInt

    logger.info("+++++++++++############# Source Count: " + src_count + " #############+++++++++++")

    if (src_count != 0) {

      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudBatchId(dmnsn_max_btch_id)

      //****************************Fact Code****************************************//

      var pdmDF = spark.sql("""select mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd,mtrl_valtn_std_prc_amt as mtrl_valtn_std_prc_amt 
        from """ + dbNameConsmtn + """.pdm_mtrl_valtn_grp_dmnsn""")

      logger.info("""select mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd,mtrl_valtn_std_prc_amt as mtrl_valtn_std_prc_amt 
        from """ + dbNameConsmtn + """.pdm_mtrl_valtn_grp_dmnsn""")

      var invyDF = spark.sql("""select invy.mtrl_mvmt_invy_ky,invy.mtrl_mvmt_src_sys_cd,invy.mtrl_mvmt_mtrl_id,invy.mtrl_mvmt_mtrl_dcmt_yr_nr,
        invy.mtrl_mvmt_plnt_cd,invy.mtrl_mvmt_valuated_sls_ord_id,invy.mtrl_mvmt_valuated_sls_ord_itm_nr,invy.mtrl_mvmt_spcl_stk_cd,
        invy.mtrl_mvmt_gds_mvmt_stk_typ_cd,invy.mtrl_mvmt_lgl_co_cd,invy.mtrl_mvmt_qty_upd_ind_dt,invy.mtrl_mvmt_bs_unt_msr_cd,
        invy.mtrl_mvmt_vl_upd_ind_dt,invy.mtrl_mvmt_sls_dcmt_typ_cd,invy.mtrl_mvmt_spcl_stk_valtn_typ_cd,invy.mtrl_mvmt_stk_chrc_cd,
        invy.mtrl_mvmt_stk_cgy_cd,invy.mtrl_mvmt_mtrl_rsrc_plng_ar_cd,invy.mtrl_mvmt_curr_cd,invy.mtrl_mvmt_lcl_curr_amt_cd,
        invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd,invy.mtrl_mvmt_valuated_stk_pre_pstg_amt_cd,invy.mtrl_mvmt_qty_cd,invy.mtrl_mvmt_valuated_stk_pre_pstg_qty_cd,
        invy.mtrl_mvmt_stk_qty_cd,invy.mtrl_mvmt_cnsmpn_qty_cd,invy.mtrl_mvmt_etry_unt_msr_cd,invy.mtrl_mvmt_rcvd_qty_cd,invy.mtrl_mvmt_ord_prc_unt_msr_cd,
        invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd,invy.mtrl_mvmt_prch_ord_unt_msr_cd,invy.mtrl_mvmt_gd_rcpt_qty_cd,invy.mtrl_mvmt_dcmt_pstg_dt,
        invy.mtrl_mvmt_src_sys_crt_ts_cd,invy.mtrl_mvmt_dcmt_iss_dt,invy.mtrl_mvmt_src_sys_upd_dt,invy.mtrl_mvmt_mtrl_dcmt_id,invy.mtrl_mvmt_mtrl_dcmt_itm_nr,
        invy.mtrl_mvmt_sls_ord_id,invy.mtrl_mvmt_sls_ord_itm_nr,invy.mtrl_mvmt_sls_ord_schdl_itm_nr,invy.mtrl_mvmt_prch_ord_id,invy.mtrl_mvmt_prch_ord_itm_nr,
        invy.mtrl_mvmt_rfnc_dcmt_id,invy.mtrl_mvmt_rfnc_dcmt_itm_nr,invy.mtrl_mvmt_ord_id,invy.mtrl_mvmt_trnsfr_rqmt_nr,invy.mtrl_mvmt_trnsfr_rqmt_itm_nr,
        invy.mtrl_mvmt_pstg_chg_nr,invy.mtrl_mvmt_trnsfr_ord_nr,invy.mtrl_mvmt_xtrn_dcmt_id,invy.mtrl_mvmt_sm_dlvry_id,invy.mtrl_mvmt_sm_dlvry_itm_nr,
        invy.mtrl_mvmt_cnl_ind_cd,invy.mtrl_mvmt_cnln_typ_cd,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd,invy.mtrl_mvmt_mvmt_typ_cd,invy.mtrl_mvmt_ato_ind_cd,
        invy.mtrl_mvmt_storg_lctn_cd,invy.mtrl_mvmt_btch_id,invy.mtrl_mvmt_valtn_typ_cd,invy.mtrl_mvmt_stk_typ_cd,invy.mtrl_mvmt_vndr_prty_id,
        invy.mtrl_mvmt_cust_prty_id,invy.mtrl_mvmt_dbt_crdt_cd,invy.mtrl_mvmt_dlvry_cmplt_ind_cd,invy.mtrl_mvmt_itm_txt_cd,invy.mtrl_mvmt_shp_to_prty_id,
        invy.mtrl_mvmt_unldg_pnt_dn_cd,invy.mtrl_mvmt_rcvg_issg_mtrl_id,invy.mtrl_mvmt_rcvg_issg_storg_lctn_cd,invy.mtrl_mvmt_mvmt_cd,
        invy.mtrl_mvmt_cnsmpn_pstg_cd,invy.mtrl_mvmt_rcpt_cd,invy.mtrl_mvmt_nn_valuated_ind_cd,invy.mtrl_mvmt_wh_cmplx_cd,invy.mtrl_mvmt_wh_typ_cd,
        invy.mtrl_mvmt_storg_bn_id,invy.mtrl_mvmt_stk_cgy_code1_cd,invy.mtrl_mvmt_wm_mvmt_typ_cd,invy.mtrl_mvmt_pstg_ind_cd,invy.mtrl_mvmt_gds_mvmt_rsn_nr,
        invy.mtrl_mvmt_shpg_inst_cd,invy.mtrl_mvmt_shpg_inst_cmpln_cd,invy.mtrl_mvmt_pft_cntr_cd,invy.mtrl_mvmt_gds_rcpt_inspn_stts_cd,
        invy.mtrl_mvmt_rcvg_issg_mtrl_identifier1_id,invy.mtrl_mvmt_phy_stk_trnsfr_ind_cd,invy.mtrl_mvmt_itm_stk_sgm_id,invy.mtrl_mvmt_rcvg_issg_stk_sgm_id,
        invy.mtrl_mvmt_rqmt_stk_sgm_id,invy.mtrl_mvmt_acct_asngmt_cgy_cd,invy.mtrl_mvmt_dcmt_typ_cd,invy.mtrl_mvmt_rvaltn_dcmt_typ_cd,
        invy.mtrl_mvmt_trsn_evt_typ_cd,invy.mtrl_mvmt_crtd_by_usr_id,invy.mtrl_mvmt_ins_ts_cd,invy.mtrl_mvmt_upd_ts_dt,invy.mtrl_mvmt_lgcl_dlt_ind_cd,
        invy.mtrl_storg_lctn_src_sys_cd,invy.mtrl_storg_lctn_mtrl_id,invy.mtrl_storg_lctn_plnt_cd,invy.mtrl_storg_lctn_mtrl_storg_lctn_cd,
        invy.mtrl_storg_lctn_mntnc_stts_cd,invy.mtrl_storg_lctn_ct_prd_fscl_yr_nr,invy.mtrl_storg_lctn_ct_prd_pstg_prd_nr,
        invy.mtrl_storg_lctn_phy_invy_bkg_ind_cd,invy.mtrl_storg_lctn_valuated_unrestricted_qty_cd,invy.mtrl_storg_lctn_trnsfr_qty_cd,
        invy.mtrl_storg_lctn_qlty_inspn_qty_cd,invy.mtrl_storg_lctn_rstd_btch_qty_cd,invy.mtrl_storg_lctn_blckd_qty_cd,invy.mtrl_storg_lctn_blckd_rtn_qty_cd,
        invy.mtrl_storg_lctn_mrp_storg_lctn_ind_cd,invy.mtrl_storg_lctn_storg_lctn_prcmt_typ_cd,invy.mtrl_storg_lctn_mrp_storg_lctn_reorder_qty_cd,
        invy.mtrl_storg_lctn_mrp_storg_lctn_rplnshmt_qty_cd,invy.mtrl_storg_lctn_mtrl_orgn_ctry_cd,invy.mtrl_storg_lctn_storg_bn_cd,
        invy.mtrl_storg_lctn_unrestricted_cnsgnmnt_qty_cd,invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd,
        invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,invy.mtrl_storg_lctn_last_pstd_dt,invy.mtrl_storg_lctn_pft_cntr_cd,invy.mtrl_storg_lctn_src_sys_crt_dt,
        invy.mtrl_storg_lctn_stk_vl_amt_cd,invy.mtrl_storg_lctn_stk_trnsfr_amt_cd,invy.mtrl_storg_lctn_ins_ts_cd,invy.mtrl_storg_lctn_upd_ts_dt,
        invy.mtrl_storg_lctn_lgcl_dlt_ind_cd,invy.totl_vndr_spcl_stk_src_sys_cd,invy.totl_vndr_spcl_stk_mtrl_id,invy.totl_vndr_spcl_stk_plnt_cd,
        invy.totl_vndr_spcl_stk_spcl_stk_cd,invy.totl_vndr_spcl_stk_vndr_prty_id,invy.totl_vndr_spcl_stk_ct_fscl_yr_nr,invy.totl_vndr_spcl_stk_ct_pstg_prd_nr,
        invy.totl_vndr_spcl_stk_valuated_unrestricted_qty_cd,invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd,invy.totl_vndr_spcl_stk_totl_rstd_qty_cd,
        invy.totl_vndr_spcl_stk_src_sys_crt_dt,invy.totl_vndr_spcl_stk_vndr_stk_valtn_ind_cd,invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd,
        invy.totl_vndr_spcl_stk_ins_ts_cd,invy.totl_vndr_spcl_stk_upd_ts_dt,invy.totl_vndr_spcl_stk_lgcl_dlt_ind_cd,invy.vndr_spcl_stk_src_sys_cd,
        invy.vndr_spcl_stk_mtrl_id,invy.vndr_spcl_stk_plnt_cd,invy.vndr_spcl_stk_mtrl_storg_lctn_cd,invy.vndr_spcl_stk_btch_cd,invy.vndr_spcl_stk_spcl_stk_cd,
        invy.vndr_spcl_stk_vndr_prty_id,invy.vndr_spcl_stk_src_sys_crt_dt,invy.vndr_spcl_stk_crtd_by_usr_id,invy.vndr_spcl_stk_updd_by_usr_id_dt,
        invy.vndr_spcl_stk_src_systme_upd_dt,invy.vndr_spcl_stk_ct_fscl_yr_nr,invy.vndr_spcl_stk_ct_pstg_prd_nr,invy.vndr_spcl_stk_phy_invy_blck_ind_cd,
        invy.vndr_spcl_stk_unrestricted_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd,
        invy.vndr_spcl_stk_blckd_consigment_qty_cd,invy.vndr_spcl_stk_prv_unrestricted_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_prv_qlty_inspn_cnsgnmnt_qty_cd,
        invy.vndr_spcl_stk_prv_rstd_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_prv_blckd_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_mnm_ord_qty_cd,
        invy.vndr_spcl_stk_rplnshmt_qty_cd,invy.vndr_spcl_stk_last_pstd_dt,invy.vndr_spcl_stk_invy_fscl_yr_nr,invy.vndr_spcl_stk_ins_ts_cd,
        invy.vndr_spcl_stk_upd_ts_dt,invy.vndr_spcl_stk_lgcl_dlt_ind_cd,invy.sls_ord_stk_src_sys_cd,invy.sls_ord_stk_mtrl_id,invy.sls_ord_stk_plnt_cd,
        invy.sls_ord_stk_mtrl_storg_lctn_cd,invy.sls_ord_stk_btch_cd,invy.sls_ord_stk_spcl_stk_cd,invy.sls_ord_stk_sls_ord_id,invy.sls_ord_stk_sls_ord_itm_nr,
        invy.sls_ord_stk_fscl_yr_nr,invy.sls_ord_stk_pstg_prd_nr,invy.sls_ord_stk_blck_ind_cd,invy.sls_ord_stk_valuated_unrestricted_qty_cd,
        invy.sls_ord_stk_qlty_inspn_qty_cd,invy.sls_ord_stk_blck_qty_cd,invy.sls_ord_stk_prv_prd_valuated_unrestricted_qty_cd,
        invy.sls_ord_stk_prv_prd_qlty_inspn_qty_cd,invy.sls_ord_stk_prv_prd_blck_qty_cd,invy.sls_ord_stk_last_pstd_cnt_dt,invy.sls_ord_stk_rstd_btch_qty_cd,
        invy.sls_ord_stk_prv_prd_rstd_btch_qty_cd,invy.sls_ord_stk_src_sys_crt_dt,invy.sls_ord_stk_phy_invy_fscl_yr_nr,invy.sls_ord_stk_ins_ts_cd,
        invy.sls_ord_stk_upd_ts_dt,invy.sls_ord_stk_lgcl_dlt_ind_cd,invy.wh_mgmt_quant_src_sys_cd,invy.wh_mgmt_quant_wh_cmplx_cd,invy.wh_mgmt_quant_wh_qty_nr,
        invy.wh_mgmt_quant_mtrl_id,invy.wh_mgmt_quant_plnt_cd,invy.wh_mgmt_quant_btch_cd,invy.wh_mgmt_quant_stk_cgy_cd,invy.wh_mgmt_quant_spcl_stk_cd,
        invy.wh_mgmt_quant_spcl_stk_id,invy.wh_mgmt_quant_storg_typ_cd,invy.wh_mgmt_quant_storg_bn_id,invy.wh_mgmt_quant_storg_bn_psn_cd,
        invy.wh_mgmt_quant_mvmt_ts_cd,invy.wh_mgmt_quant_last_stk_dcmt_nr,invy.wh_mgmt_quant_last_stk_itm_nr,invy.wh_mgmt_quant_stk_placementtimestamp_cd,
        invy.wh_mgmt_quant_stk_removal_ts_cd,invy.wh_mgmt_quant_stk_addn_dt,invy.wh_mgmt_quant_gd_rcpt_dt,invy.wh_mgmt_quant_gd_rcpt_id,
        invy.wh_mgmt_quant_gd_rcpt_itm_nr,invy.wh_mgmt_quant_wh_unt_typ_cd,invy.wh_mgmt_quant_bs_unt_msr_cd,invy.wh_mgmt_quant_totl_qty_cd,
        invy.wh_mgmt_quant_avl_qty_cd,invy.wh_mgmt_quant_putaway_qty_cd,invy.wh_mgmt_quant_rmv_qty_cd,invy.wh_mgmt_quant_mtrl_wght_cd,
        invy.wh_mgmt_quant_wght_unt_msr_cd,invy.wh_mgmt_quant_trnsfr_rqmt_nr,invy.wh_mgmt_quant_rqmt_typ_cd,invy.wh_mgmt_quant_rqmt_id,
        invy.wh_mgmt_quant_storg_unt_id,invy.wh_mgmt_quant_storg_lctn_cd,invy.wh_mgmt_quant_hndl_unt_ind_cd,invy.wh_mgmt_quant_sm_dlvry_id,
        invy.wh_mgmt_quant_sm_dlvry_itm_nr,invy.wh_mgmt_quant_last_invy_quant_dt,invy.wh_mgmt_quant_ins_ts_cd,invy.wh_mgmt_quant_upd_ts_dt,
        invy.wh_mgmt_quant_lgcl_dlt_ind_cd,invy.valtn_typ_src_sys_cd,invy.valtn_typ_valtn_typ_cd,invy.valtn_typ_acct_cgy_rfnc_cd,
        invy.valtn_typ_xtrn_prch_ord_allwd_cd,invy.valtn_typ_inrn_prch_ord_allwd_cd,invy.valtn_typ_ins_ts_cd,invy.valtn_typ_upd_ts_dt,
        invy.valtn_typ_lgcl_dlt_ind_cd,invy.shpg_inst_src_sys_cd,invy.shpg_inst_shpg_inst_cd,invy.shpg_inst_shpg_inst_dn_cd,invy.shpg_inst_ins_ts_cd,
        invy.shpg_inst_upd_ts_dt,invy.shpg_inst_lgcl_dlt_ind_cd,invy.spcl_stk_src_sys_cd,invy.spcl_stk_spcl_stk_cd,invy.spcl_stk_spcl_stk_dn_cd,
        invy.spcl_stk_ins_ts_cd,invy.spcl_stk_upd_ts_dt,invy.spcl_stk_lgcl_dlt_ind_cd,invy.storg_lctn_src_sys_cd,invy.storg_lctn_plnt_cd,
        invy.storg_lctn_storg_lctn_cd,invy.storg_lctn_storg_lctn_dn_cd,invy.storg_lctn_dvsn_cd,invy.storg_lctn_ins_ts_cd,invy.storg_lctn_upd_ts_dt,
        invy.storg_lctn_lgcl_dlt_ind_cd,invy.intgtn_fbrc_msg_id,invy.src_sys_upd_ts,invy.src_sys_ky,invy.lgcl_dlt_ind,invy.ins_gmt_ts,invy.upd_gmt_ts,
        invy.src_sys_extrc_gmt_ts,invy.src_sys_btch_nr,invy.fl_nm,invy.ld_jb_nr,invy.ins_ts,invy.ins_gmt_dt,plnt.ctry_cd,plnt.valtn_ar_cd,plnt.rgn_cd,
        plnt.plnt_mstr_nm,plnt_trckr.rgn_cd as s4_rgn_cd 
        from """ + srcTblConsmtn + """ invy LEFT JOIN (select distinct ctry_cd,valtn_ar_cd,rgn_cd,plnt_mstr_nm,plnt_mstr_cd from """ + dbNameConsmtn +
        """.plnt_mstr_dmnsn) plnt ON invy.mtrl_mvmt_plnt_cd = plnt.plnt_mstr_cd LEFT JOIN """ + dbNameConsmtn + """.bmt_plant_tracker_dmnsn plnt_trckr 
             ON invy.mtrl_mvmt_plnt_cd = plnt_trckr.s4_plnt_cd where date_sub(invy.ins_gmt_dt,-31)>='""" + ins_gmt_date + """' and invy.mtrl_mvmt_mtrl_id 
               is not NULL and invy.ld_jb_nr > '""" + fact_max_btch_id + """' and invy.ld_jb_nr  <= '""" + dmnsn_max_btch_id + """'""")

      logger.info("""select invy.mtrl_mvmt_invy_ky,invy.mtrl_mvmt_src_sys_cd,invy.mtrl_mvmt_mtrl_id,invy.mtrl_mvmt_mtrl_dcmt_yr_nr,
        invy.mtrl_mvmt_plnt_cd,invy.mtrl_mvmt_valuated_sls_ord_id,invy.mtrl_mvmt_valuated_sls_ord_itm_nr,invy.mtrl_mvmt_spcl_stk_cd,
        invy.mtrl_mvmt_gds_mvmt_stk_typ_cd,invy.mtrl_mvmt_lgl_co_cd,invy.mtrl_mvmt_qty_upd_ind_dt,invy.mtrl_mvmt_bs_unt_msr_cd,
        invy.mtrl_mvmt_vl_upd_ind_dt,invy.mtrl_mvmt_sls_dcmt_typ_cd,invy.mtrl_mvmt_spcl_stk_valtn_typ_cd,invy.mtrl_mvmt_stk_chrc_cd,
        invy.mtrl_mvmt_stk_cgy_cd,invy.mtrl_mvmt_mtrl_rsrc_plng_ar_cd,invy.mtrl_mvmt_curr_cd,invy.mtrl_mvmt_lcl_curr_amt_cd,
        invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd,invy.mtrl_mvmt_valuated_stk_pre_pstg_amt_cd,invy.mtrl_mvmt_qty_cd,invy.mtrl_mvmt_valuated_stk_pre_pstg_qty_cd,
        invy.mtrl_mvmt_stk_qty_cd,invy.mtrl_mvmt_cnsmpn_qty_cd,invy.mtrl_mvmt_etry_unt_msr_cd,invy.mtrl_mvmt_rcvd_qty_cd,invy.mtrl_mvmt_ord_prc_unt_msr_cd,
        invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd,invy.mtrl_mvmt_prch_ord_unt_msr_cd,invy.mtrl_mvmt_gd_rcpt_qty_cd,invy.mtrl_mvmt_dcmt_pstg_dt,
        invy.mtrl_mvmt_src_sys_crt_ts_cd,invy.mtrl_mvmt_dcmt_iss_dt,invy.mtrl_mvmt_src_sys_upd_dt,invy.mtrl_mvmt_mtrl_dcmt_id,invy.mtrl_mvmt_mtrl_dcmt_itm_nr,
        invy.mtrl_mvmt_sls_ord_id,invy.mtrl_mvmt_sls_ord_itm_nr,invy.mtrl_mvmt_sls_ord_schdl_itm_nr,invy.mtrl_mvmt_prch_ord_id,invy.mtrl_mvmt_prch_ord_itm_nr,
        invy.mtrl_mvmt_rfnc_dcmt_id,invy.mtrl_mvmt_rfnc_dcmt_itm_nr,invy.mtrl_mvmt_ord_id,invy.mtrl_mvmt_trnsfr_rqmt_nr,invy.mtrl_mvmt_trnsfr_rqmt_itm_nr,
        invy.mtrl_mvmt_pstg_chg_nr,invy.mtrl_mvmt_trnsfr_ord_nr,invy.mtrl_mvmt_xtrn_dcmt_id,invy.mtrl_mvmt_sm_dlvry_id,invy.mtrl_mvmt_sm_dlvry_itm_nr,
        invy.mtrl_mvmt_cnl_ind_cd,invy.mtrl_mvmt_cnln_typ_cd,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd,invy.mtrl_mvmt_mvmt_typ_cd,invy.mtrl_mvmt_ato_ind_cd,
        invy.mtrl_mvmt_storg_lctn_cd,invy.mtrl_mvmt_btch_id,invy.mtrl_mvmt_valtn_typ_cd,invy.mtrl_mvmt_stk_typ_cd,invy.mtrl_mvmt_vndr_prty_id,
        invy.mtrl_mvmt_cust_prty_id,invy.mtrl_mvmt_dbt_crdt_cd,invy.mtrl_mvmt_dlvry_cmplt_ind_cd,invy.mtrl_mvmt_itm_txt_cd,invy.mtrl_mvmt_shp_to_prty_id,
        invy.mtrl_mvmt_unldg_pnt_dn_cd,invy.mtrl_mvmt_rcvg_issg_mtrl_id,invy.mtrl_mvmt_rcvg_issg_storg_lctn_cd,invy.mtrl_mvmt_mvmt_cd,
        invy.mtrl_mvmt_cnsmpn_pstg_cd,invy.mtrl_mvmt_rcpt_cd,invy.mtrl_mvmt_nn_valuated_ind_cd,invy.mtrl_mvmt_wh_cmplx_cd,invy.mtrl_mvmt_wh_typ_cd,
        invy.mtrl_mvmt_storg_bn_id,invy.mtrl_mvmt_stk_cgy_code1_cd,invy.mtrl_mvmt_wm_mvmt_typ_cd,invy.mtrl_mvmt_pstg_ind_cd,invy.mtrl_mvmt_gds_mvmt_rsn_nr,
        invy.mtrl_mvmt_shpg_inst_cd,invy.mtrl_mvmt_shpg_inst_cmpln_cd,invy.mtrl_mvmt_pft_cntr_cd,invy.mtrl_mvmt_gds_rcpt_inspn_stts_cd,
        invy.mtrl_mvmt_rcvg_issg_mtrl_identifier1_id,invy.mtrl_mvmt_phy_stk_trnsfr_ind_cd,invy.mtrl_mvmt_itm_stk_sgm_id,invy.mtrl_mvmt_rcvg_issg_stk_sgm_id,
        invy.mtrl_mvmt_rqmt_stk_sgm_id,invy.mtrl_mvmt_acct_asngmt_cgy_cd,invy.mtrl_mvmt_dcmt_typ_cd,invy.mtrl_mvmt_rvaltn_dcmt_typ_cd,
        invy.mtrl_mvmt_trsn_evt_typ_cd,invy.mtrl_mvmt_crtd_by_usr_id,invy.mtrl_mvmt_ins_ts_cd,invy.mtrl_mvmt_upd_ts_dt,invy.mtrl_mvmt_lgcl_dlt_ind_cd,
        invy.mtrl_storg_lctn_src_sys_cd,invy.mtrl_storg_lctn_mtrl_id,invy.mtrl_storg_lctn_plnt_cd,invy.mtrl_storg_lctn_mtrl_storg_lctn_cd,
        invy.mtrl_storg_lctn_mntnc_stts_cd,invy.mtrl_storg_lctn_ct_prd_fscl_yr_nr,invy.mtrl_storg_lctn_ct_prd_pstg_prd_nr,
        invy.mtrl_storg_lctn_phy_invy_bkg_ind_cd,invy.mtrl_storg_lctn_valuated_unrestricted_qty_cd,invy.mtrl_storg_lctn_trnsfr_qty_cd,
        invy.mtrl_storg_lctn_qlty_inspn_qty_cd,invy.mtrl_storg_lctn_rstd_btch_qty_cd,invy.mtrl_storg_lctn_blckd_qty_cd,invy.mtrl_storg_lctn_blckd_rtn_qty_cd,
        invy.mtrl_storg_lctn_mrp_storg_lctn_ind_cd,invy.mtrl_storg_lctn_storg_lctn_prcmt_typ_cd,invy.mtrl_storg_lctn_mrp_storg_lctn_reorder_qty_cd,
        invy.mtrl_storg_lctn_mrp_storg_lctn_rplnshmt_qty_cd,invy.mtrl_storg_lctn_mtrl_orgn_ctry_cd,invy.mtrl_storg_lctn_storg_bn_cd,
        invy.mtrl_storg_lctn_unrestricted_cnsgnmnt_qty_cd,invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd,
        invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,invy.mtrl_storg_lctn_last_pstd_dt,invy.mtrl_storg_lctn_pft_cntr_cd,invy.mtrl_storg_lctn_src_sys_crt_dt,
        invy.mtrl_storg_lctn_stk_vl_amt_cd,invy.mtrl_storg_lctn_stk_trnsfr_amt_cd,invy.mtrl_storg_lctn_ins_ts_cd,invy.mtrl_storg_lctn_upd_ts_dt,
        invy.mtrl_storg_lctn_lgcl_dlt_ind_cd,invy.totl_vndr_spcl_stk_src_sys_cd,invy.totl_vndr_spcl_stk_mtrl_id,invy.totl_vndr_spcl_stk_plnt_cd,
        invy.totl_vndr_spcl_stk_spcl_stk_cd,invy.totl_vndr_spcl_stk_vndr_prty_id,invy.totl_vndr_spcl_stk_ct_fscl_yr_nr,invy.totl_vndr_spcl_stk_ct_pstg_prd_nr,
        invy.totl_vndr_spcl_stk_valuated_unrestricted_qty_cd,invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd,invy.totl_vndr_spcl_stk_totl_rstd_qty_cd,
        invy.totl_vndr_spcl_stk_src_sys_crt_dt,invy.totl_vndr_spcl_stk_vndr_stk_valtn_ind_cd,invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd,
        invy.totl_vndr_spcl_stk_ins_ts_cd,invy.totl_vndr_spcl_stk_upd_ts_dt,invy.totl_vndr_spcl_stk_lgcl_dlt_ind_cd,invy.vndr_spcl_stk_src_sys_cd,
        invy.vndr_spcl_stk_mtrl_id,invy.vndr_spcl_stk_plnt_cd,invy.vndr_spcl_stk_mtrl_storg_lctn_cd,invy.vndr_spcl_stk_btch_cd,invy.vndr_spcl_stk_spcl_stk_cd,
        invy.vndr_spcl_stk_vndr_prty_id,invy.vndr_spcl_stk_src_sys_crt_dt,invy.vndr_spcl_stk_crtd_by_usr_id,invy.vndr_spcl_stk_updd_by_usr_id_dt,
        invy.vndr_spcl_stk_src_systme_upd_dt,invy.vndr_spcl_stk_ct_fscl_yr_nr,invy.vndr_spcl_stk_ct_pstg_prd_nr,invy.vndr_spcl_stk_phy_invy_blck_ind_cd,
        invy.vndr_spcl_stk_unrestricted_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd,
        invy.vndr_spcl_stk_blckd_consigment_qty_cd,invy.vndr_spcl_stk_prv_unrestricted_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_prv_qlty_inspn_cnsgnmnt_qty_cd,
        invy.vndr_spcl_stk_prv_rstd_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_prv_blckd_cnsgnmnt_qty_cd,invy.vndr_spcl_stk_mnm_ord_qty_cd,
        invy.vndr_spcl_stk_rplnshmt_qty_cd,invy.vndr_spcl_stk_last_pstd_dt,invy.vndr_spcl_stk_invy_fscl_yr_nr,invy.vndr_spcl_stk_ins_ts_cd,
        invy.vndr_spcl_stk_upd_ts_dt,invy.vndr_spcl_stk_lgcl_dlt_ind_cd,invy.sls_ord_stk_src_sys_cd,invy.sls_ord_stk_mtrl_id,invy.sls_ord_stk_plnt_cd,
        invy.sls_ord_stk_mtrl_storg_lctn_cd,invy.sls_ord_stk_btch_cd,invy.sls_ord_stk_spcl_stk_cd,invy.sls_ord_stk_sls_ord_id,invy.sls_ord_stk_sls_ord_itm_nr,
        invy.sls_ord_stk_fscl_yr_nr,invy.sls_ord_stk_pstg_prd_nr,invy.sls_ord_stk_blck_ind_cd,invy.sls_ord_stk_valuated_unrestricted_qty_cd,
        invy.sls_ord_stk_qlty_inspn_qty_cd,invy.sls_ord_stk_blck_qty_cd,invy.sls_ord_stk_prv_prd_valuated_unrestricted_qty_cd,
        invy.sls_ord_stk_prv_prd_qlty_inspn_qty_cd,invy.sls_ord_stk_prv_prd_blck_qty_cd,invy.sls_ord_stk_last_pstd_cnt_dt,invy.sls_ord_stk_rstd_btch_qty_cd,
        invy.sls_ord_stk_prv_prd_rstd_btch_qty_cd,invy.sls_ord_stk_src_sys_crt_dt,invy.sls_ord_stk_phy_invy_fscl_yr_nr,invy.sls_ord_stk_ins_ts_cd,
        invy.sls_ord_stk_upd_ts_dt,invy.sls_ord_stk_lgcl_dlt_ind_cd,invy.wh_mgmt_quant_src_sys_cd,invy.wh_mgmt_quant_wh_cmplx_cd,invy.wh_mgmt_quant_wh_qty_nr,
        invy.wh_mgmt_quant_mtrl_id,invy.wh_mgmt_quant_plnt_cd,invy.wh_mgmt_quant_btch_cd,invy.wh_mgmt_quant_stk_cgy_cd,invy.wh_mgmt_quant_spcl_stk_cd,
        invy.wh_mgmt_quant_spcl_stk_id,invy.wh_mgmt_quant_storg_typ_cd,invy.wh_mgmt_quant_storg_bn_id,invy.wh_mgmt_quant_storg_bn_psn_cd,
        invy.wh_mgmt_quant_mvmt_ts_cd,invy.wh_mgmt_quant_last_stk_dcmt_nr,invy.wh_mgmt_quant_last_stk_itm_nr,invy.wh_mgmt_quant_stk_placementtimestamp_cd,
        invy.wh_mgmt_quant_stk_removal_ts_cd,invy.wh_mgmt_quant_stk_addn_dt,invy.wh_mgmt_quant_gd_rcpt_dt,invy.wh_mgmt_quant_gd_rcpt_id,
        invy.wh_mgmt_quant_gd_rcpt_itm_nr,invy.wh_mgmt_quant_wh_unt_typ_cd,invy.wh_mgmt_quant_bs_unt_msr_cd,invy.wh_mgmt_quant_totl_qty_cd,
        invy.wh_mgmt_quant_avl_qty_cd,invy.wh_mgmt_quant_putaway_qty_cd,invy.wh_mgmt_quant_rmv_qty_cd,invy.wh_mgmt_quant_mtrl_wght_cd,
        invy.wh_mgmt_quant_wght_unt_msr_cd,invy.wh_mgmt_quant_trnsfr_rqmt_nr,invy.wh_mgmt_quant_rqmt_typ_cd,invy.wh_mgmt_quant_rqmt_id,
        invy.wh_mgmt_quant_storg_unt_id,invy.wh_mgmt_quant_storg_lctn_cd,invy.wh_mgmt_quant_hndl_unt_ind_cd,invy.wh_mgmt_quant_sm_dlvry_id,
        invy.wh_mgmt_quant_sm_dlvry_itm_nr,invy.wh_mgmt_quant_last_invy_quant_dt,invy.wh_mgmt_quant_ins_ts_cd,invy.wh_mgmt_quant_upd_ts_dt,
        invy.wh_mgmt_quant_lgcl_dlt_ind_cd,invy.valtn_typ_src_sys_cd,invy.valtn_typ_valtn_typ_cd,invy.valtn_typ_acct_cgy_rfnc_cd,
        invy.valtn_typ_xtrn_prch_ord_allwd_cd,invy.valtn_typ_inrn_prch_ord_allwd_cd,invy.valtn_typ_ins_ts_cd,invy.valtn_typ_upd_ts_dt,
        invy.valtn_typ_lgcl_dlt_ind_cd,invy.shpg_inst_src_sys_cd,invy.shpg_inst_shpg_inst_cd,invy.shpg_inst_shpg_inst_dn_cd,invy.shpg_inst_ins_ts_cd,
        invy.shpg_inst_upd_ts_dt,invy.shpg_inst_lgcl_dlt_ind_cd,invy.spcl_stk_src_sys_cd,invy.spcl_stk_spcl_stk_cd,invy.spcl_stk_spcl_stk_dn_cd,
        invy.spcl_stk_ins_ts_cd,invy.spcl_stk_upd_ts_dt,invy.spcl_stk_lgcl_dlt_ind_cd,invy.storg_lctn_src_sys_cd,invy.storg_lctn_plnt_cd,
        invy.storg_lctn_storg_lctn_cd,invy.storg_lctn_storg_lctn_dn_cd,invy.storg_lctn_dvsn_cd,invy.storg_lctn_ins_ts_cd,invy.storg_lctn_upd_ts_dt,
        invy.storg_lctn_lgcl_dlt_ind_cd,invy.intgtn_fbrc_msg_id,invy.src_sys_upd_ts,invy.src_sys_ky,invy.lgcl_dlt_ind,invy.ins_gmt_ts,invy.upd_gmt_ts,
        invy.src_sys_extrc_gmt_ts,invy.src_sys_btch_nr,invy.fl_nm,invy.ld_jb_nr,invy.ins_ts,invy.ins_gmt_dt,plnt.ctry_cd,plnt.valtn_ar_cd,plnt.rgn_cd,
        plnt.plnt_mstr_nm,plnt_trckr.rgn_cd as s4_rgn_cd 
        from """ + srcTblConsmtn + """ invy LEFT JOIN (select distinct ctry_cd,valtn_ar_cd,rgn_cd,plnt_mstr_nm,plnt_mstr_cd from """ + dbNameConsmtn +
        """.plnt_mstr_dmnsn) plnt ON invy.mtrl_mvmt_plnt_cd = plnt.plnt_mstr_cd LEFT JOIN """ + dbNameConsmtn + """.bmt_plant_tracker_dmnsn plnt_trckr 
             ON invy.mtrl_mvmt_plnt_cd = plnt_trckr.s4_plnt_cd where date_sub(invy.ins_gmt_dt,-31)>='""" + ins_gmt_date + """' and invy.mtrl_mvmt_mtrl_id 
               is not NULL and invy.ld_jb_nr > '""" + fact_max_btch_id + """' and invy.ld_jb_nr  <= '""" + dmnsn_max_btch_id + """'""")

      var pdmJoinDF = pdmDF.as("a").join(broadcast(invyDF).as("b"), col("a.mtrl_valtn_mtrl_id") === col("b.mtrl_mvmt_mtrl_id")
        && col("a.mtrl_valtn_ar_cd") === col("b.valtn_ar_cd")).select("a.*")

      pdmJoinDF.createOrReplaceTempView("pdm_mtrl_valtn_grp_dmnsn_table")

      invyDF.createOrReplaceTempView("invy_table")

      incrementalDF = spark.sql("""select
 mtrl_mvmt_invy_ky 
,pdm_mtrl_mstr_grp_ky
,wrld_rgn_ky
,cldr_rpt_ky
,hpn_lctn_prod_ky
,Bmt_qrnt_aruba_sply_chn_ky
,mtrl_storg_lctn_mtrl_id
,mtrl_storg_lctn_plnt_cd
,mtrl_storg_lctn_mtrl_storg_lctn_cd
,mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,mtrl_storg_lctn_trnsfr_qty_cd
,mtrl_storg_lctn_qlty_inspn_qty_cd
,mtrl_storg_lctn_rstd_btch_qty_cd
,mtrl_storg_lctn_blckd_qty_cd
,mtrl_storg_lctn_blckd_rtn_qty_cd
,mtrl_storg_lctn_MRP_storg_lctn_ind_cd
,mtrl_storg_lctn_mtrl_orgn_ctry_cd
,mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_last_pstd_dt
,mtrl_storg_lctn_stk_trnsfr_amt_cd
,mtrl_storg_lctn_lgcl_dlt_ind_cd
,vndr_spcl_stk_mtrl_id
,vndr_spcl_stk_plnt_cd
,vndr_spcl_stk_mtrl_storg_lctn_cd
,vndr_spcl_stk_spcl_stk_cd
,vndr_spcl_stk_vndr_prty_id
,vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,vndr_spcl_stk_blckd_Consigment_qty_cd
,vndr_spcl_stk_mnm_ord_qty_cd
,vndr_spcl_stk_rplnshmt_qty_cd
,vndr_spcl_stk_lgcl_dlt_ind_cd
,sls_ord_stk_mtrl_id
,sls_ord_stk_plnt_cd
,sls_ord_stk_mtrl_storg_lctn_cd
,sls_ord_stk_spcl_stk_cd
,sls_ord_stk_sls_ord_id
,sls_ord_stk_sls_ord_itm_nr
,sls_ord_stk_Valuated_Unrestricted_qty_cd
,sls_ord_stk_qlty_inspn_qty_cd
,sls_ord_stk_blck_qty_cd
,sls_ord_stk_lgcl_dlt_ind_cd
,totl_vndr_spcl_stk_mtrl_id
,totl_vndr_spcl_stk_plnt_cd
,totl_vndr_spcl_stk_spcl_stk_cd
,totl_vndr_spcl_stk_vndr_prty_id
,totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,totl_vndr_spcl_stk_qlty_inspn_qty_cd
,totl_vndr_spcl_stk_totl_rstd_qty_cd
,totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,totl_vndr_spcl_stk_lgcl_dlt_ind_cd
,shpg_inst_shpg_inst_cd
,shpg_inst_shpg_inst_dn_cd
,shpg_inst_lgcl_dlt_ind_cd
,storg_lctn_plnt_cd
,storg_lctn_storg_lctn_cd
,storg_lctn_storg_lctn_dn_cd
,storg_lctn_lgcl_dlt_ind_cd
,mtrl_mvmt_plnt_cd
,mtrl_mvmt_Valuated_sls_ord_id
,mtrl_mvmt_Valuated_sls_ord_itm_nr
,mtrl_mvmt_spcl_stk_cd
,mtrl_mvmt_gds_mvmt_stk_typ_cd
,mtrl_mvmt_qty_upd_ind_dt
,mtrl_mvmt_vl_upd_ind_dt
,mtrl_mvmt_sls_dcmt_typ_cd
,mtrl_mvmt_spcl_stk_valtn_typ_cd
,mtrl_mvmt_stk_chrc_cd
,mtrl_mvmt_stk_cgy_cd
,mtrl_mvmt_mtrl_rsrc_plng_ar_cd
,mtrl_mvmt_curr_cd
,mtrl_mvmt_lcl_curr_amt_cd
,mtrl_mvmt_lcl_curr_dlvry_amt_cd
,mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd
,mtrl_mvmt_bs_unt_msr_cd
,mtrl_mvmt_qty_cd
,mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,mtrl_mvmt_stk_qty_cd
,mtrl_mvmt_cnsmpn_qty_cd
,mtrl_mvmt_etry_unt_msr_cd
,mtrl_mvmt_rcvd_qty_cd
,mtrl_mvmt_ord_prc_unt_msr_cd
,mtrl_mvmt_prch_ord_prc_unt_qty_cd
,mtrl_mvmt_prch_ord_unt_msr_cd
,mtrl_mvmt_gd_rcpt_qty_cd
,mtrl_mvmt_dcmt_pstg_dt
,mtrl_mvmt_dcmt_iss_dt
,mtrl_mvmt_mtrl_dcmt_id
,mtrl_mvmt_mtrl_dcmt_yr_nr
,mtrl_mvmt_mtrl_dcmt_itm_nr
,mtrl_mvmt_sls_ord_id
,mtrl_mvmt_sls_ord_itm_nr
,mtrl_mvmt_sls_ord_schdl_itm_nr
,mtrl_mvmt_prch_ord_id
,mtrl_mvmt_prch_ord_itm_nr
,mtrl_mvmt_rfnc_dcmt_id
,mtrl_mvmt_rfnc_dcmt_itm_nr
,mtrl_mvmt_ord_id
,mtrl_mvmt_pstg_chg_nr
,mtrl_mvmt_trnsfr_ord_nr
,mtrl_mvmt_xtrn_dcmt_id
,mtrl_mvmt_sm_dlvry_id
,mtrl_mvmt_sm_dlvry_itm_nr
,mtrl_mvmt_cnl_ind_cd
,mtrl_mvmt_cnln_typ_cd
,mtrl_mvmt_rvrsl_mvmt_typ_cd
,mtrl_mvmt_mvmt_typ_cd
,mtrl_mvmt_mtrl_id
,mtrl_mvmt_storg_lctn_cd
,mtrl_mvmt_valtn_typ_cd
,mtrl_mvmt_stk_typ_cd
,mtrl_mvmt_vndr_prty_id
,mtrl_mvmt_cust_prty_id
,mtrl_mvmt_dbt_crdt_cd
,mtrl_mvmt_dlvry_cmplt_ind_cd
,mtrl_mvmt_itm_txt_cd
,mtrl_mvmt_shp_to_prty_id
,mtrl_mvmt_unldg_pnt_dn_cd
,mtrl_mvmt_rcvg_issg_mtrl_id
,mtrl_mvmt_rcvg_issg_storg_lctn_cd
,mtrl_mvmt_mvmt_cd
,mtrl_mvmt_cnsmpn_pstg_cd
,mtrl_mvmt_rcpt_cd
,mtrl_mvmt_nn_Valuated_ind_cd
,mtrl_mvmt_wh_cmplx_cd
,mtrl_mvmt_wh_typ_cd
,mtrl_mvmt_storg_bn_id
,mtrl_mvmt_stk_cgy_Code1_cd
,mtrl_mvmt_WM_mvmt_typ_cd
,mtrl_mvmt_gds_mvmt_rsn_nr
,mtrl_mvmt_shpg_inst_cd
,mtrl_mvmt_shpg_inst_cmpln_cd
,mtrl_mvmt_pft_cntr_cd
,mtrl_mvmt_gds_rcpt_inspn_stts_cd
,mtrl_mvmt_rcvg_issg_mtrl_Identifier1_id
,mtrl_mvmt_phy_stk_trnsfr_ind_cd
,mtrl_mvmt_acct_asngmt_cgy_cd
,mtrl_mvmt_dcmt_typ_cd
,mtrl_mvmt_trsn_evt_typ_cd
,mtrl_mvmt_crtd_by_usr_id
,mtrl_mvmt_lgcl_dlt_ind_cd
,totl_avl_qty
,inventory.ctry_cd
,inventory.s4_rgn_cd
,inventory.rgn_cd
,plnt_mstr_nm
,avl_qty
,cnsgnmnt_qty
,inspn_qty
,snpsht_ins_ts
,mvnt_dt
,inventory.storg_lctn_cd    
,mbew.mtrl_valtn_std_prc_amt as entrprs_std_cst
,(COALESCE(mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) + COALESCE(mtrl_storg_lctn_qlty_inspn_qty_cd,0L) + 
COALESCE(mtrl_storg_lctn_blckd_qty_cd,0L)+COALESCE(mtrl_storg_lctn_blckd_rtn_qty_cd,0L)+COALESCE(mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L) + 
COALESCE(mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L)+COALESCE(mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd,0L) + 
COALESCE(mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L)  as totl_hnd_qty_1
,COALESCE(mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as totl_avl_qty_1 
,inventory.ins_ts
,ins_gmt_dt from 
(SELECT invy.mtrl_mvmt_invy_ky 
,md5(LOWER(concat(COALESCE(trim(invy.mtrl_mvmt_mtrl_id),"")))) as pdm_mtrl_mstr_grp_ky
,md5(LOWER(concat(COALESCE(trim(invy.rgn_cd),"")))) as wrld_rgn_ky
,md5(CAST(CURRENT_DATE AS STRING)) as cldr_rpt_ky
,md5(LOWER(concat(COALESCE(trim(invy.mtrl_mvmt_storg_lctn_cd),""),COALESCE(trim(invy.mtrl_mvmt_mtrl_id),"")))) as hpn_lctn_prod_ky
,md5(LOWER(concat(COALESCE(trim(invy.mtrl_mvmt_mtrl_id),""),COALESCE(trim(invy.mtrl_mvmt_plnt_cd),"")))) as Bmt_qrnt_aruba_sply_chn_ky
,invy.mtrl_storg_lctn_mtrl_id
,invy.mtrl_storg_lctn_plnt_cd
,invy.mtrl_storg_lctn_mtrl_storg_lctn_cd
,invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,invy.mtrl_storg_lctn_trnsfr_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_qty_cd
,invy.mtrl_storg_lctn_rstd_btch_qty_cd
,invy.mtrl_storg_lctn_blckd_qty_cd
,invy.mtrl_storg_lctn_blckd_rtn_qty_cd
,invy.mtrl_storg_lctn_MRP_storg_lctn_ind_cd
,invy.mtrl_storg_lctn_mtrl_orgn_ctry_cd
,invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_last_pstd_dt
,invy.mtrl_storg_lctn_stk_trnsfr_amt_cd
,invy.mtrl_storg_lctn_lgcl_dlt_ind_cd
,invy.vndr_spcl_stk_mtrl_id
,invy.vndr_spcl_stk_plnt_cd
,invy.vndr_spcl_stk_mtrl_storg_lctn_cd
,invy.vndr_spcl_stk_spcl_stk_cd
,invy.vndr_spcl_stk_vndr_prty_id
,invy.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_blckd_Consigment_qty_cd
,invy.vndr_spcl_stk_mnm_ord_qty_cd
,invy.vndr_spcl_stk_rplnshmt_qty_cd
,invy.vndr_spcl_stk_lgcl_dlt_ind_cd
,invy.sls_ord_stk_mtrl_id
,invy.sls_ord_stk_plnt_cd
,invy.sls_ord_stk_mtrl_storg_lctn_cd
,invy.sls_ord_stk_spcl_stk_cd
,invy.sls_ord_stk_sls_ord_id
,invy.sls_ord_stk_sls_ord_itm_nr
,invy.sls_ord_stk_Valuated_Unrestricted_qty_cd
,invy.sls_ord_stk_qlty_inspn_qty_cd
,invy.sls_ord_stk_blck_qty_cd
,invy.sls_ord_stk_lgcl_dlt_ind_cd
,invy.totl_vndr_spcl_stk_mtrl_id
,invy.totl_vndr_spcl_stk_plnt_cd
,invy.totl_vndr_spcl_stk_spcl_stk_cd
,invy.totl_vndr_spcl_stk_vndr_prty_id
,invy.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd
,invy.totl_vndr_spcl_stk_totl_rstd_qty_cd
,invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,invy.totl_vndr_spcl_stk_lgcl_dlt_ind_cd
,invy.shpg_inst_shpg_inst_cd
,invy.shpg_inst_shpg_inst_dn_cd
,invy.shpg_inst_lgcl_dlt_ind_cd
,invy.storg_lctn_plnt_cd
,invy.storg_lctn_storg_lctn_cd
,invy.storg_lctn_storg_lctn_dn_cd
,invy.storg_lctn_lgcl_dlt_ind_cd
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_Valuated_sls_ord_id
,invy.mtrl_mvmt_Valuated_sls_ord_itm_nr
,invy.mtrl_mvmt_spcl_stk_cd
,invy.mtrl_mvmt_gds_mvmt_stk_typ_cd
,invy.mtrl_mvmt_qty_upd_ind_dt
,invy.mtrl_mvmt_vl_upd_ind_dt
,invy.mtrl_mvmt_sls_dcmt_typ_cd
,invy.mtrl_mvmt_spcl_stk_valtn_typ_cd
,invy.mtrl_mvmt_stk_chrc_cd
,invy.mtrl_mvmt_stk_cgy_cd
,invy.mtrl_mvmt_mtrl_rsrc_plng_ar_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd
,invy.mtrl_mvmt_bs_unt_msr_cd
,invy.mtrl_mvmt_qty_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd
,invy.mtrl_mvmt_etry_unt_msr_cd
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_mtrl_dcmt_id
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_sls_ord_id
,invy.mtrl_mvmt_sls_ord_itm_nr
,invy.mtrl_mvmt_sls_ord_schdl_itm_nr
,invy.mtrl_mvmt_prch_ord_id
,invy.mtrl_mvmt_prch_ord_itm_nr
,invy.mtrl_mvmt_rfnc_dcmt_id
,invy.mtrl_mvmt_rfnc_dcmt_itm_nr
,invy.mtrl_mvmt_ord_id
,invy.mtrl_mvmt_pstg_chg_nr
,invy.mtrl_mvmt_trnsfr_ord_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_sm_dlvry_id
,invy.mtrl_mvmt_sm_dlvry_itm_nr
,invy.mtrl_mvmt_cnl_ind_cd
,invy.mtrl_mvmt_cnln_typ_cd
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_dbt_crdt_cd
,invy.mtrl_mvmt_dlvry_cmplt_ind_cd
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_unldg_pnt_dn_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_id
,invy.mtrl_mvmt_rcvg_issg_storg_lctn_cd
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_cnsmpn_pstg_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_nn_Valuated_ind_cd
,invy.mtrl_mvmt_wh_cmplx_cd
,invy.mtrl_mvmt_wh_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,invy.mtrl_mvmt_stk_cgy_Code1_cd
,invy.mtrl_mvmt_WM_mvmt_typ_cd
,invy.mtrl_mvmt_gds_mvmt_rsn_nr
,invy.mtrl_mvmt_shpg_inst_cd
,invy.mtrl_mvmt_shpg_inst_cmpln_cd
,invy.mtrl_mvmt_pft_cntr_cd
,invy.mtrl_mvmt_gds_rcpt_inspn_stts_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_Identifier1_id
,invy.mtrl_mvmt_phy_stk_trnsfr_ind_cd
,invy.mtrl_mvmt_acct_asngmt_cgy_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_trsn_evt_typ_cd
,invy.mtrl_mvmt_crtd_by_usr_id
,invy.mtrl_mvmt_lgcl_dlt_ind_cd
,mtrl_storg_lctn_Valuated_Unrestricted_qty_cd as totl_avl_qty
,invy.ctry_cd as ctry_cd 
,invy.valtn_ar_cd as valtn_ar_cd
,invy.s4_rgn_cd
,invy.rgn_cd
,invy.plnt_mstr_nm as plnt_mstr_nm
,COALESCE(invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) as avl_qty
,(COALESCE(mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L) + COALESCE(mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L) + 
COALESCE(mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd,0L) + COALESCE(mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)) as cnsgnmnt_qty
,invy.mtrl_storg_lctn_qlty_inspn_qty_cd as inspn_qty
,CASE WHEN date(invy.mtrl_mvmt_ins_ts_cd) is NULL THEN date(invy.mtrl_mvmt_upd_ts_dt) else date(invy.mtrl_mvmt_ins_ts_cd) end as snpsht_ins_ts
,invy.mtrl_mvmt_dcmt_pstg_dt as mvnt_dt
,invy.mtrl_mvmt_storg_lctn_cd as storg_lctn_cd 
,current_timestamp() as ins_ts
,invy.ins_gmt_dt  
from invy_table invy) inventory 
LEFT JOIN
(select mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd,sum(mtrl_valtn_std_prc_amt) as mtrl_valtn_std_prc_amt from 
pdm_mtrl_valtn_grp_dmnsn_table group by mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd) mbew
ON
inventory.mtrl_mvmt_mtrl_id=mbew.mtrl_valtn_mtrl_id
and 
COALESCE(inventory.mtrl_mvmt_valtn_typ_cd,"#")=COALESCE(mbew.mtrl_valtn_typ_cd,"#")
and inventory.valtn_ar_cd=mbew.mtrl_valtn_ar_cd""")

      logger.info("""select
 mtrl_mvmt_invy_ky 
,pdm_mtrl_mstr_grp_ky
,wrld_rgn_ky
,cldr_rpt_ky
,hpn_lctn_prod_ky
,Bmt_qrnt_aruba_sply_chn_ky
,mtrl_storg_lctn_mtrl_id
,mtrl_storg_lctn_plnt_cd
,mtrl_storg_lctn_mtrl_storg_lctn_cd
,mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,mtrl_storg_lctn_trnsfr_qty_cd
,mtrl_storg_lctn_qlty_inspn_qty_cd
,mtrl_storg_lctn_rstd_btch_qty_cd
,mtrl_storg_lctn_blckd_qty_cd
,mtrl_storg_lctn_blckd_rtn_qty_cd
,mtrl_storg_lctn_MRP_storg_lctn_ind_cd
,mtrl_storg_lctn_mtrl_orgn_ctry_cd
,mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,mtrl_storg_lctn_last_pstd_dt
,mtrl_storg_lctn_stk_trnsfr_amt_cd
,mtrl_storg_lctn_lgcl_dlt_ind_cd
,vndr_spcl_stk_mtrl_id
,vndr_spcl_stk_plnt_cd
,vndr_spcl_stk_mtrl_storg_lctn_cd
,vndr_spcl_stk_spcl_stk_cd
,vndr_spcl_stk_vndr_prty_id
,vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,vndr_spcl_stk_blckd_Consigment_qty_cd
,vndr_spcl_stk_mnm_ord_qty_cd
,vndr_spcl_stk_rplnshmt_qty_cd
,vndr_spcl_stk_lgcl_dlt_ind_cd
,sls_ord_stk_mtrl_id
,sls_ord_stk_plnt_cd
,sls_ord_stk_mtrl_storg_lctn_cd
,sls_ord_stk_spcl_stk_cd
,sls_ord_stk_sls_ord_id
,sls_ord_stk_sls_ord_itm_nr
,sls_ord_stk_Valuated_Unrestricted_qty_cd
,sls_ord_stk_qlty_inspn_qty_cd
,sls_ord_stk_blck_qty_cd
,sls_ord_stk_lgcl_dlt_ind_cd
,totl_vndr_spcl_stk_mtrl_id
,totl_vndr_spcl_stk_plnt_cd
,totl_vndr_spcl_stk_spcl_stk_cd
,totl_vndr_spcl_stk_vndr_prty_id
,totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,totl_vndr_spcl_stk_qlty_inspn_qty_cd
,totl_vndr_spcl_stk_totl_rstd_qty_cd
,totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,totl_vndr_spcl_stk_lgcl_dlt_ind_cd
,shpg_inst_shpg_inst_cd
,shpg_inst_shpg_inst_dn_cd
,shpg_inst_lgcl_dlt_ind_cd
,storg_lctn_plnt_cd
,storg_lctn_storg_lctn_cd
,storg_lctn_storg_lctn_dn_cd
,storg_lctn_lgcl_dlt_ind_cd
,mtrl_mvmt_plnt_cd
,mtrl_mvmt_Valuated_sls_ord_id
,mtrl_mvmt_Valuated_sls_ord_itm_nr
,mtrl_mvmt_spcl_stk_cd
,mtrl_mvmt_gds_mvmt_stk_typ_cd
,mtrl_mvmt_qty_upd_ind_dt
,mtrl_mvmt_vl_upd_ind_dt
,mtrl_mvmt_sls_dcmt_typ_cd
,mtrl_mvmt_spcl_stk_valtn_typ_cd
,mtrl_mvmt_stk_chrc_cd
,mtrl_mvmt_stk_cgy_cd
,mtrl_mvmt_mtrl_rsrc_plng_ar_cd
,mtrl_mvmt_curr_cd
,mtrl_mvmt_lcl_curr_amt_cd
,mtrl_mvmt_lcl_curr_dlvry_amt_cd
,mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd
,mtrl_mvmt_bs_unt_msr_cd
,mtrl_mvmt_qty_cd
,mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,mtrl_mvmt_stk_qty_cd
,mtrl_mvmt_cnsmpn_qty_cd
,mtrl_mvmt_etry_unt_msr_cd
,mtrl_mvmt_rcvd_qty_cd
,mtrl_mvmt_ord_prc_unt_msr_cd
,mtrl_mvmt_prch_ord_prc_unt_qty_cd
,mtrl_mvmt_prch_ord_unt_msr_cd
,mtrl_mvmt_gd_rcpt_qty_cd
,mtrl_mvmt_dcmt_pstg_dt
,mtrl_mvmt_dcmt_iss_dt
,mtrl_mvmt_mtrl_dcmt_id
,mtrl_mvmt_mtrl_dcmt_yr_nr
,mtrl_mvmt_mtrl_dcmt_itm_nr
,mtrl_mvmt_sls_ord_id
,mtrl_mvmt_sls_ord_itm_nr
,mtrl_mvmt_sls_ord_schdl_itm_nr
,mtrl_mvmt_prch_ord_id
,mtrl_mvmt_prch_ord_itm_nr
,mtrl_mvmt_rfnc_dcmt_id
,mtrl_mvmt_rfnc_dcmt_itm_nr
,mtrl_mvmt_ord_id
,mtrl_mvmt_pstg_chg_nr
,mtrl_mvmt_trnsfr_ord_nr
,mtrl_mvmt_xtrn_dcmt_id
,mtrl_mvmt_sm_dlvry_id
,mtrl_mvmt_sm_dlvry_itm_nr
,mtrl_mvmt_cnl_ind_cd
,mtrl_mvmt_cnln_typ_cd
,mtrl_mvmt_rvrsl_mvmt_typ_cd
,mtrl_mvmt_mvmt_typ_cd
,mtrl_mvmt_mtrl_id
,mtrl_mvmt_storg_lctn_cd
,mtrl_mvmt_valtn_typ_cd
,mtrl_mvmt_stk_typ_cd
,mtrl_mvmt_vndr_prty_id
,mtrl_mvmt_cust_prty_id
,mtrl_mvmt_dbt_crdt_cd
,mtrl_mvmt_dlvry_cmplt_ind_cd
,mtrl_mvmt_itm_txt_cd
,mtrl_mvmt_shp_to_prty_id
,mtrl_mvmt_unldg_pnt_dn_cd
,mtrl_mvmt_rcvg_issg_mtrl_id
,mtrl_mvmt_rcvg_issg_storg_lctn_cd
,mtrl_mvmt_mvmt_cd
,mtrl_mvmt_cnsmpn_pstg_cd
,mtrl_mvmt_rcpt_cd
,mtrl_mvmt_nn_Valuated_ind_cd
,mtrl_mvmt_wh_cmplx_cd
,mtrl_mvmt_wh_typ_cd
,mtrl_mvmt_storg_bn_id
,mtrl_mvmt_stk_cgy_Code1_cd
,mtrl_mvmt_WM_mvmt_typ_cd
,mtrl_mvmt_gds_mvmt_rsn_nr
,mtrl_mvmt_shpg_inst_cd
,mtrl_mvmt_shpg_inst_cmpln_cd
,mtrl_mvmt_pft_cntr_cd
,mtrl_mvmt_gds_rcpt_inspn_stts_cd
,mtrl_mvmt_rcvg_issg_mtrl_Identifier1_id
,mtrl_mvmt_phy_stk_trnsfr_ind_cd
,mtrl_mvmt_acct_asngmt_cgy_cd
,mtrl_mvmt_dcmt_typ_cd
,mtrl_mvmt_trsn_evt_typ_cd
,mtrl_mvmt_crtd_by_usr_id
,mtrl_mvmt_lgcl_dlt_ind_cd
,totl_avl_qty
,inventory.ctry_cd
,inventory.s4_rgn_cd
,inventory.rgn_cd
,plnt_mstr_nm
,avl_qty
,cnsgnmnt_qty
,inspn_qty
,snpsht_ins_ts
,mvnt_dt
,inventory.storg_lctn_cd    
,mbew.mtrl_valtn_std_prc_amt as entrprs_std_cst
,(COALESCE(mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) + COALESCE(mtrl_storg_lctn_qlty_inspn_qty_cd,0L) + 
COALESCE(mtrl_storg_lctn_blckd_qty_cd,0L)+COALESCE(mtrl_storg_lctn_blckd_rtn_qty_cd,0L)+COALESCE(mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L) + 
COALESCE(mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L)+COALESCE(mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd,0L) + 
COALESCE(mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L)  as totl_hnd_qty_1
,COALESCE(mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) * COALESCE(mbew.mtrl_valtn_std_prc_amt,0L) as totl_avl_qty_1 
,inventory.ins_ts
,ins_gmt_dt from 
(SELECT invy.mtrl_mvmt_invy_ky 
,md5(LOWER(concat(COALESCE(trim(invy.mtrl_mvmt_mtrl_id),"")))) as pdm_mtrl_mstr_grp_ky
,md5(LOWER(concat(COALESCE(trim(invy.rgn_cd),"")))) as wrld_rgn_ky
,md5(CAST(CURRENT_DATE AS STRING)) as cldr_rpt_ky
,md5(LOWER(concat(COALESCE(trim(invy.mtrl_mvmt_storg_lctn_cd),""),COALESCE(trim(invy.mtrl_mvmt_mtrl_id),"")))) as hpn_lctn_prod_ky
,md5(LOWER(concat(COALESCE(trim(invy.mtrl_mvmt_mtrl_id),""),COALESCE(trim(invy.mtrl_mvmt_plnt_cd),"")))) as Bmt_qrnt_aruba_sply_chn_ky
,invy.mtrl_storg_lctn_mtrl_id
,invy.mtrl_storg_lctn_plnt_cd
,invy.mtrl_storg_lctn_mtrl_storg_lctn_cd
,invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,invy.mtrl_storg_lctn_trnsfr_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_qty_cd
,invy.mtrl_storg_lctn_rstd_btch_qty_cd
,invy.mtrl_storg_lctn_blckd_qty_cd
,invy.mtrl_storg_lctn_blckd_rtn_qty_cd
,invy.mtrl_storg_lctn_MRP_storg_lctn_ind_cd
,invy.mtrl_storg_lctn_mtrl_orgn_ctry_cd
,invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,invy.mtrl_storg_lctn_last_pstd_dt
,invy.mtrl_storg_lctn_stk_trnsfr_amt_cd
,invy.mtrl_storg_lctn_lgcl_dlt_ind_cd
,invy.vndr_spcl_stk_mtrl_id
,invy.vndr_spcl_stk_plnt_cd
,invy.vndr_spcl_stk_mtrl_storg_lctn_cd
,invy.vndr_spcl_stk_spcl_stk_cd
,invy.vndr_spcl_stk_vndr_prty_id
,invy.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,invy.vndr_spcl_stk_blckd_Consigment_qty_cd
,invy.vndr_spcl_stk_mnm_ord_qty_cd
,invy.vndr_spcl_stk_rplnshmt_qty_cd
,invy.vndr_spcl_stk_lgcl_dlt_ind_cd
,invy.sls_ord_stk_mtrl_id
,invy.sls_ord_stk_plnt_cd
,invy.sls_ord_stk_mtrl_storg_lctn_cd
,invy.sls_ord_stk_spcl_stk_cd
,invy.sls_ord_stk_sls_ord_id
,invy.sls_ord_stk_sls_ord_itm_nr
,invy.sls_ord_stk_Valuated_Unrestricted_qty_cd
,invy.sls_ord_stk_qlty_inspn_qty_cd
,invy.sls_ord_stk_blck_qty_cd
,invy.sls_ord_stk_lgcl_dlt_ind_cd
,invy.totl_vndr_spcl_stk_mtrl_id
,invy.totl_vndr_spcl_stk_plnt_cd
,invy.totl_vndr_spcl_stk_spcl_stk_cd
,invy.totl_vndr_spcl_stk_vndr_prty_id
,invy.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd
,invy.totl_vndr_spcl_stk_totl_rstd_qty_cd
,invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,invy.totl_vndr_spcl_stk_lgcl_dlt_ind_cd
,invy.shpg_inst_shpg_inst_cd
,invy.shpg_inst_shpg_inst_dn_cd
,invy.shpg_inst_lgcl_dlt_ind_cd
,invy.storg_lctn_plnt_cd
,invy.storg_lctn_storg_lctn_cd
,invy.storg_lctn_storg_lctn_dn_cd
,invy.storg_lctn_lgcl_dlt_ind_cd
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_Valuated_sls_ord_id
,invy.mtrl_mvmt_Valuated_sls_ord_itm_nr
,invy.mtrl_mvmt_spcl_stk_cd
,invy.mtrl_mvmt_gds_mvmt_stk_typ_cd
,invy.mtrl_mvmt_qty_upd_ind_dt
,invy.mtrl_mvmt_vl_upd_ind_dt
,invy.mtrl_mvmt_sls_dcmt_typ_cd
,invy.mtrl_mvmt_spcl_stk_valtn_typ_cd
,invy.mtrl_mvmt_stk_chrc_cd
,invy.mtrl_mvmt_stk_cgy_cd
,invy.mtrl_mvmt_mtrl_rsrc_plng_ar_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd
,invy.mtrl_mvmt_bs_unt_msr_cd
,invy.mtrl_mvmt_qty_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd
,invy.mtrl_mvmt_etry_unt_msr_cd
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_mtrl_dcmt_id
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_sls_ord_id
,invy.mtrl_mvmt_sls_ord_itm_nr
,invy.mtrl_mvmt_sls_ord_schdl_itm_nr
,invy.mtrl_mvmt_prch_ord_id
,invy.mtrl_mvmt_prch_ord_itm_nr
,invy.mtrl_mvmt_rfnc_dcmt_id
,invy.mtrl_mvmt_rfnc_dcmt_itm_nr
,invy.mtrl_mvmt_ord_id
,invy.mtrl_mvmt_pstg_chg_nr
,invy.mtrl_mvmt_trnsfr_ord_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_sm_dlvry_id
,invy.mtrl_mvmt_sm_dlvry_itm_nr
,invy.mtrl_mvmt_cnl_ind_cd
,invy.mtrl_mvmt_cnln_typ_cd
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_dbt_crdt_cd
,invy.mtrl_mvmt_dlvry_cmplt_ind_cd
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_unldg_pnt_dn_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_id
,invy.mtrl_mvmt_rcvg_issg_storg_lctn_cd
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_cnsmpn_pstg_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_nn_Valuated_ind_cd
,invy.mtrl_mvmt_wh_cmplx_cd
,invy.mtrl_mvmt_wh_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,invy.mtrl_mvmt_stk_cgy_Code1_cd
,invy.mtrl_mvmt_WM_mvmt_typ_cd
,invy.mtrl_mvmt_gds_mvmt_rsn_nr
,invy.mtrl_mvmt_shpg_inst_cd
,invy.mtrl_mvmt_shpg_inst_cmpln_cd
,invy.mtrl_mvmt_pft_cntr_cd
,invy.mtrl_mvmt_gds_rcpt_inspn_stts_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_Identifier1_id
,invy.mtrl_mvmt_phy_stk_trnsfr_ind_cd
,invy.mtrl_mvmt_acct_asngmt_cgy_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_trsn_evt_typ_cd
,invy.mtrl_mvmt_crtd_by_usr_id
,invy.mtrl_mvmt_lgcl_dlt_ind_cd
,mtrl_storg_lctn_Valuated_Unrestricted_qty_cd as totl_avl_qty
,invy.ctry_cd as ctry_cd 
,invy.valtn_ar_cd as valtn_ar_cd
,invy.s4_rgn_cd
,invy.rgn_cd
,invy.plnt_mstr_nm as plnt_mstr_nm
,COALESCE(invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd,0L) as avl_qty
,(COALESCE(mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd,0L) + COALESCE(mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd,0L) + 
COALESCE(mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd,0L) + COALESCE(mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd,0L)) as cnsgnmnt_qty
,invy.mtrl_storg_lctn_qlty_inspn_qty_cd as inspn_qty
,CASE WHEN date(invy.mtrl_mvmt_ins_ts_cd) is NULL THEN date(invy.mtrl_mvmt_upd_ts_dt) else date(invy.mtrl_mvmt_ins_ts_cd) end as snpsht_ins_ts
,invy.mtrl_mvmt_dcmt_pstg_dt as mvnt_dt
,invy.mtrl_mvmt_storg_lctn_cd as storg_lctn_cd 
,current_timestamp() as ins_ts
,invy.ins_gmt_dt  
from invy_table invy) inventory 
LEFT JOIN
(select mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd,sum(mtrl_valtn_std_prc_amt) as mtrl_valtn_std_prc_amt from 
pdm_mtrl_valtn_grp_dmnsn_table group by mtrl_valtn_mtrl_id,mtrl_valtn_ar_cd,mtrl_valtn_typ_cd) mbew
ON
inventory.mtrl_mvmt_mtrl_id=mbew.mtrl_valtn_mtrl_id
and 
COALESCE(inventory.mtrl_mvmt_valtn_typ_cd,"#")=COALESCE(mbew.mtrl_valtn_typ_cd,"#")
and inventory.valtn_ar_cd=mbew.mtrl_valtn_ar_cd""")

      incrementalDF = incrementalDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

      //***************************incremental CDC*********************************//

      val existingFactDF = spark.sql(f"""select * from ${dbNameConsmtn}.${consmptnTable}""")

      if (!existingFactDF.head(1).isEmpty) {
        //************************For incremental load*****************************//
        var overWritePrtition = existingFactDF.join(
          incrementalDF,
          existingFactDF("mtrl_mvmt_mtrl_dcmt_id") === incrementalDF("mtrl_mvmt_mtrl_dcmt_id")).select(existingFactDF("ins_gmt_dt").cast(StringType)).
          distinct.collect.map(row => row.getString(0).toString()).toList

        overWritePrtition = overWritePrtition ::: incrementalDF.select(incrementalDF("ins_gmt_dt").cast(StringType)).distinct.collect.map(row => row.getString(0).toString()).toList

        val factNonMatchDF = existingFactDF.where(existingFactDF("ins_gmt_dt").isin(overWritePrtition.distinct: _*)).join(
          incrementalDF,
          existingFactDF("mtrl_mvmt_mtrl_dcmt_id") === incrementalDF("mtrl_mvmt_mtrl_dcmt_id"), "left_anti").drop(incrementalDF("mtrl_mvmt_mtrl_dcmt_id"))

        val finalFactDF = incrementalDF.union(factNonMatchDF).coalesce(numPartitions)

        finalFactDF.write.mode("Overwrite").format("ORC").insertInto(dbNameConsmtn + "." + consmptnTable)

      } else {
        //**************************For initial load*****************************//
        incrementalDF.write.mode("Overwrite").format("ORC").insertInto(dbNameConsmtn + "." + consmptnTable)
      }

      logger.info("Data has been loaded to: " + consmptnTable + " Table")

      tgt_count = incrementalDF.count().toInt

      logger.info("+++++++++++############# Target Count: " + tgt_count + " #############+++++++++++")

      spark.catalog.dropTempView("pdm_mtrl_valtn_grp_dmnsn_table")
      spark.catalog.dropTempView("invy_table")

      //************************Completion Audit Entries*******************************//

      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudJobStatusCode("success")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("success")
    }
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
      toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
  } finally {
    if (loadStatus) {
      incrementalDF.unpersist()
      sqlCon.close()
      spark.close()
    } else {
      incrementalDF.unpersist()
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
  }
}
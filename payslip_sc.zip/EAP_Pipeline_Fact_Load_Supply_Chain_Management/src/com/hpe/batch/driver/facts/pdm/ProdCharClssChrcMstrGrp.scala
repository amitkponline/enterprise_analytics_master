package com.hpe.batch.driver.facts.pdm

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.functions.row_number

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object ProdCharClssChrcMstrGrp extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var ld_jb_nr_ref = (ld_jb_nr + "_" + batchId)
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val tgtTblRef = propertiesObject.getTgtTblRef()
  val audittable = propertiesObject.getAuditTbl()

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, "prod_char")

  try {

    var prod_char_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, "prod_char")

    logger.info("Bifurication Load of Prod Char Started!!!!!!!!!!!!!")

    logger.info("Max batch id of Prod Char ref table " + prod_char_max_btch_id.toString())

    //**********Prod Char Class Characteristic Master Group**************************//

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********prod_char_clss_chrc_mstr_grp_ref********||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    val hive_ref_table_prod_char_clss_chrc_mstr_grp_ref = propertiesObject.getHive_ref_table_prod_char_clss_chrc_mstr_grp_ref()

    val Keys_table_prod_char_clss_chrc_mstr_grp_ref = propertiesObject.getKeys_table_prod_char_clss_chrc_mstr_grp_ref()

    val prod_char_clss_chrc_mstr_grp_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_prod_char_clss_chrc_mstr_grp_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of Prod Char Class Characteristic Master Group table " + prod_char_clss_chrc_mstr_grp_max_btch_id.toString())

    var transformeSrcdDF = spark.sql("""select * from """ + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + prod_char_clss_chrc_mstr_grp_max_btch_id + "' and ld_jb_nr <= '" + prod_char_max_btch_id + "'")

    var src_count = transformeSrcdDF.count().toInt

    if (src_count != 0) {

      var hiveRefSelect = spark.sql("select " + Keys_table_prod_char_clss_chrc_mstr_grp_ref + ",'" + prod_char_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + prod_char_clss_chrc_mstr_grp_max_btch_id + "' and ld_jb_nr <= '" + prod_char_max_btch_id + "'")

      var filterRow = hiveRefSelect.filter(col("clss_chrc_mstr_inrn_chr_nr").isNotNull)

      var windowSpec = Window.partitionBy("chrc_mstr_mtrl_nr", "clss_chrc_mstr_inrn_chr_nr").orderBy(desc("chrc_mstr_src_sys_crt_ts"), desc("chrc_mstr_src_sys_upd_ts"), desc("ins_gmt_ts"))

      var addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(10)

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table_prod_char_clss_chrc_mstr_grp_ref)

      var tgt_count = addRowNo.count().toInt

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(prod_char_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table_prod_char_clss_chrc_mstr_grp_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) {
        auditObj.setAudJobStatusCode("failed")
      } else {
        auditObj.setAudJobStatusCode("success")
      }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table_prod_char_clss_chrc_mstr_grp_ref + " Table")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("************Prod Char Refine Bifurication completed*************************")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } finally {
    sqlCon.close()
    spark.close()
  }
}
package com.hpe.batch.driver.facts.deliveryshipment

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import scala.collection.JavaConversions._
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import org.apache.spark.sql.expressions.Window

object ShipmentDelivery extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj:AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var ld_jb_nr_ref = (ld_jb_nr + "_" + batchId)
  val sourceTable =propertiesObject.getSrcTblConsmtn()
  val targetTable =propertiesObject.getTgtTblConsmtn()
  var dbNameConsmtn: String = null
  var ref2: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    ref2 = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  var dbNameConsmtnmainref: String = null 
  var mainref: String = null
  if (propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtnmainref = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0)
     mainref = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(1)
     
     logger.info("main ref tabel name and schema name "+ dbNameConsmtnmainref + mainref)
     
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  
   try {    

  val shipmentMaxInsertTimestamp = "'"+spark.sql(f""" select coalesce(max(ins_gmt_ts),'1900-01-01 00:00:01') from $targetTable""").collect.map(row => row.getString(0)).mkString("")+"'" 
  
  
  //val transformeSrcdDF = spark.sql("""select * from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp)""")
  
  //val src_count = transformeSrcdDF.count().toInt
  
  logger.info("************* Inside if Table Write Status : loadStatus -->*********")
  
 
val keys_sm_ref="""    sm_dlvry_sm_dlvry_id,sm_dlvry_src_sys_cd,sm_dlvry_dcmt_cgy_cd,sm_dlvry_sm_typ_cd,sm_dlvry_trns_plng_pnt_cd,sm_dlvry_crtd_by_usr_id,sm_dlvry_src_sys_crt_ts_cd,sm_dlvry_updd_by_usr_id_dt,sm_dlvry_src_sys_upd_ts_dt,sm_dlvry_leg_dtrmn_cd,sm_dlvry_sm_cmpltn_typ_cd,sm_dlvry_prsng_ctrl_cd,sm_dlvry_srv_lvl_cd,sm_dlvry_shpg_typ_cd,sm_dlvry_pmnry_leg_shpg_typ_cd,sm_dlvry_sbsqnt_leg_shpg_typ_cd,sm_dlvry_dlvry_leg_cd,sm_dlvry_sm_cndn_cd,shipment_sm_dlvry_rt_2_cd,sm_dlvry_cntnr_id,sm_dlvry_xtrn_1_id,sm_dlvry_xtrn_2_id,sm_dlvry_sm_dn_cd,sm_dlvry_trns_plng_ind_cd,sm_dlvry_plng_end_ts_cd,sm_dlvry_chk_ind_cd,sm_dlvry_plnd_chk_ts_cd,sm_dlvry_actl_chk_ts_cd,sm_dlvry_loading_strt_ind_cd,sm_dlvry_plnd_loading_strt_ts_cd,sm_dlvry_actl_loading_strt_ts_cd,sm_dlvry_loading_end_ind_cd,sm_dlvry_plnd_loading_end_ts_cd,sm_dlvry_actl_loading_end_ts_cd,sm_dlvry_sm_cmpltn_ind_cd,sm_dlvry_plnd_cmpltn_ts_cd,sm_dlvry_actl_cmpltn_ts_cd,sm_dlvry_sm_strt_ind_cd,sm_dlvry_plnd_sm_strt_ts_cd,sm_dlvry_actl_sm_strt_ts_cd,sm_dlvry_sm_end_ind_cd,sm_dlvry_plnd_sm_end_ts_cd,sm_dlvry_actl_sm_end_ts_cd,sm_dlvry_wght_unt_msr_cd,sm_dlvry_trns_stts_cd,sm_dlvry_vol_unt_msr_cd,sm_dlvry_trns_prty_id,sm_dlvry_ord_id,sm_dlvry_distance_unt_msr_cd,sm_dlvry_hndl_unt_ind_cd,sm_dlvry_distance_qty_cd,sm_dlvry_trns_durtn_qty_cd,sm_dlvry_sm_cltn_stts_cd,sm_dlvry_ovrl_sm_cltn_stts_cd,sm_dlvry_stlmnt_sm_cltn_stts_cd,sm_dlvry_totl_sm_cltn_stts_cd,sm_dlvry_leg_dtrmn_ind_cd,sm_dlvry_sm_prcg_prcgr_cd,sm_dlvry_sm_rlvnc_cst_ind_cd,sm_dlvry_plnd_sm_dys_dt,sm_dlvry_plnd_sm_hrs_cd,sm_dlvry_actl_sm_dys_dt,sm_dlvry_actl_sm_hrs_cd,sm_dlvry_rte_cp_ind_cd,sm_dlvry_dangerous_gds_cd,sm_dlvry_dangerous_gds_blck_ind_cd,sm_dlvry_dangerous_gds_slctn_dt,sm_dlvry_dangerous_gds_ind_cd,sm_dlvry_rte_schdl_id,sm_dlvry_actl_sm_amt_cd,sm_dlvry_actl_sm_curr_cd,sm_dlvry_agt_trkg_id,sm_dlvry_earlst_pup_ts_cd,sm_dlvry_ltst_pup_ts_cd,sm_dlvry_earlst_dlvry_ts_cd,sm_dlvry_ltst_dlvry_ts_cd,sm_dlvry_loading_pltf_lgt_cd,sm_dlvry_spcl_1_cd,sm_dlvry_spcl_2_cd,sm_dlvry_spcl_3_cd,sm_dlvry_spcl_4_cd,sm_dlvry_spcl_5_cd,sm_dlvry_spcl_6_cd,sm_dlvry_spcl_7_cd,sm_dlvry_spcl_8_cd,sm_dlvry_ins_ts_cd,sm_dlvry_upd_ts_dt,sm_dlvry_lgcl_dlt_ind_cd,  sm_upd_ts_dt
, intgtn_fbrc_msg_id , src_sys_upd_ts, src_sys_ky
                    ,  lgcl_dlt_ind, ins_gmt_ts, upd_gmt_ts, src_sys_extrc_gmt_ts, src_sys_btch_nr
                    ,  fl_nm ,'""" + ld_jb_nr_ref + """' as ld_jb_nr , to_date(ins_gmt_ts) as ins_gmt_dt"""

val hive_ref_select = spark.sql(f"""select $keys_sm_ref from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp) and sm_dlvry_src_sys_cd is not null and sm_dlvry_sm_dlvry_id is not null""")

val query_hive_Ref_select = s"""select $keys_sm_ref from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp) and sm_dlvry_src_sys_cd is not null and sm_dlvry_sm_dlvry_id is not null"""

logger.info("*************** query_hive_Ref_select  ************ "  +  query_hive_Ref_select)

val windowSpec = Window.partitionBy("sm_dlvry_src_sys_cd", "sm_dlvry_sm_dlvry_id").orderBy(desc("sm_upd_ts_dt"))

val finalDataset = hive_ref_select.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm")

finalDataset.persist(StorageLevel.MEMORY_AND_DISK_SER)
val src_count = finalDataset.count
val tgt_count = src_count 

val numOfWritePartitions = if((shipmentMaxInsertTimestamp.contains("1900-"))) ((spark.conf.get("spark.sql.shuffle.partitions")).toInt)/5 else {((spark.conf.get("spark.sql.shuffle.partitions")).toInt)/30}

val loadStatus = Utilities.storeDataFrame(finalDataset, "Append", "ORC", targetTable,tgt_count,numOfWritePartitions) 

   //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ld_jb_nr_ref)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
      logger.info("************* Inside if Table Write Status : loadStatus -->*********" + loadStatus)
    } else {
      auditObj.setAudJobStatusCode("failed")
      logger.info("************* Inside else Table Write Status : loadStatus -->*********" + loadStatus)
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}
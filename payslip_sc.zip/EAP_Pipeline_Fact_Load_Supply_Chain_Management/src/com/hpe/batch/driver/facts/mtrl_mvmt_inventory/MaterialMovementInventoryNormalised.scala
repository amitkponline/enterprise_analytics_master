package com.hpe.batch.driver.facts.mtrl_mvmt_inventory

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object MaterialMovementInventoryNormalised extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  var auditBatchId = ld_jb_nr + "_" + "19000101000000"
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val numPartitions = propertiesObject.getNumPartitions().trim().toInt
  var src_count = 0
  var tgt_count = 0
  var loadStatus = true
  val srctbl = propertiesObject.getSrcTblConsmtn()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn()
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (tgtTblConsmtn.trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = tgtTblConsmtn.trim().split("\\.", -1)(0)
    consmptnTable = tgtTblConsmtn.trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  //************************Set Audit Entries*******************************//

  auditObj.setAudBatchId(auditBatchId)
  auditObj.setAudDataLayerName("rw_ref")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(objName)
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(src_count)
  auditObj.setAudTgtRowCount(tgt_count)

  try {

    logger.info("------------Load of Movement inventory normalized code Started-------------")

    var ref_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, "mtrl_mvmt_invy", auditTbl)

    logger.info("Max batch id of main ref table " + ref_max_btch_id.toString())

    var ref_normalised_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, "mtrl_mvmt_invy_normalised", auditTbl)

    logger.info("Max batch id of normalised ref table " + ref_normalised_max_btch_id.toString())

    //******************* Partition Calculation *******************//

    var ins_gmt_date = ""

    if (ref_normalised_max_btch_id == "19001231000000") {
      ins_gmt_date = ref_normalised_max_btch_id.substring(0, 4) + '-' + ref_normalised_max_btch_id.substring(4, 6) + '-' + ref_normalised_max_btch_id.
        substring(6, 8)
    } else {
      ins_gmt_date = ref_normalised_max_btch_id.substring(19, 23) + '-' + ref_normalised_max_btch_id.substring(23, 25) + '-' + ref_normalised_max_btch_id.
        substring(25, 27)
    }

    logger.info("Partition to be queried: " + ins_gmt_date)

    //********************Set Source Count **********************//

    var transformeSrcdDF = spark.sql("""select count(*) from """ + srctbl + " where date_sub(ins_gmt_dt,-1)>='" + ins_gmt_date + "' and ld_jb_nr > '" +
      ref_normalised_max_btch_id + "' and ld_jb_nr <= '" + ref_max_btch_id + "'")

    logger.info("""select ins_gmt_ts from """ + srctbl + " where date_sub(ins_gmt_dt,-1)>='" + ins_gmt_date + "' and ld_jb_nr > '" +
      ref_normalised_max_btch_id + "' and ld_jb_nr <= '" + ref_max_btch_id + "'")

    src_count = transformeSrcdDF.first.getLong(0).toInt

    logger.info("+++++++++++############# Source Count: " + src_count + " #############+++++++++++")

    if (src_count != 0) {

      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudBatchId(ref_max_btch_id)

      //************Merging parsed JSON rows into single row************//

      var transformedDF = spark.sql("""select 
invy.mtrl_mvmt_src_sys_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_Valuated_sls_ord_id
,invy.mtrl_mvmt_Valuated_sls_ord_itm_nr
,invy.mtrl_mvmt_spcl_stk_cd
,invy.mtrl_mvmt_gds_mvmt_stk_typ_cd
,invy.mtrl_mvmt_lgl_co_cd
,invy.mtrl_mvmt_qty_upd_ind_dt
,invy.mtrl_mvmt_bs_unt_msr_cd
,invy.mtrl_mvmt_vl_upd_ind_dt
,invy.mtrl_mvmt_sls_dcmt_typ_cd
,invy.mtrl_mvmt_spcl_stk_valtn_typ_cd
,invy.mtrl_mvmt_stk_chrc_cd
,invy.mtrl_mvmt_stk_cgy_cd
,invy.mtrl_mvmt_mtrl_rsrc_plng_ar_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd
,invy.mtrl_mvmt_qty_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd
,invy.mtrl_mvmt_etry_unt_msr_cd
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_src_sys_crt_ts_cd
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_src_sys_upd_dt
,invy.mtrl_mvmt_mtrl_dcmt_id
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_sls_ord_id
,invy.mtrl_mvmt_sls_ord_itm_nr
,invy.mtrl_mvmt_sls_ord_schdl_itm_nr
,invy.mtrl_mvmt_prch_ord_id
,invy.mtrl_mvmt_prch_ord_itm_nr
,invy.mtrl_mvmt_rfnc_dcmt_id
,invy.mtrl_mvmt_rfnc_dcmt_itm_nr
,invy.mtrl_mvmt_ord_id
,invy.mtrl_mvmt_trnsfr_rqmt_nr
,invy.mtrl_mvmt_trnsfr_rqmt_itm_nr
,invy.mtrl_mvmt_pstg_chg_nr
,invy.mtrl_mvmt_trnsfr_ord_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_sm_dlvry_id
,invy.mtrl_mvmt_sm_dlvry_itm_nr
,invy.mtrl_mvmt_cnl_ind_cd
,invy.mtrl_mvmt_cnln_typ_cd
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_ato_ind_cd
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_btch_id
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_dbt_crdt_cd
,invy.mtrl_mvmt_dlvry_cmplt_ind_cd
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_unldg_pnt_dn_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_id
,invy.mtrl_mvmt_rcvg_issg_storg_lctn_cd
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_cnsmpn_pstg_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_nn_Valuated_ind_cd
,invy.mtrl_mvmt_wh_cmplx_cd
,invy.mtrl_mvmt_wh_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,invy.mtrl_mvmt_stk_cgy_Code1_cd
,invy.mtrl_mvmt_WM_mvmt_typ_cd
,invy.mtrl_mvmt_pstg_ind_cd
,invy.mtrl_mvmt_gds_mvmt_rsn_nr
,invy.mtrl_mvmt_shpg_inst_cd
,invy.mtrl_mvmt_shpg_inst_cmpln_cd
,invy.mtrl_mvmt_pft_cntr_cd
,invy.mtrl_mvmt_gds_rcpt_inspn_stts_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_Identifier1_id
,invy.mtrl_mvmt_phy_stk_trnsfr_ind_cd
,invy.mtrl_mvmt_itm_stk_sgm_id
,invy.mtrl_mvmt_rcvg_issg_stk_sgm_id
,invy.mtrl_mvmt_rqmt_stk_sgm_id
,invy.mtrl_mvmt_acct_asngmt_cgy_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_rvaltn_dcmt_typ_cd
,invy.mtrl_mvmt_trsn_evt_typ_cd
,invy.mtrl_mvmt_crtd_by_usr_id
,invy.mtrl_mvmt_ins_ts_cd
,invy.mtrl_mvmt_upd_ts_dt
,invy.mtrl_mvmt_lgcl_dlt_ind_cd
,MAX(invy.mtrl_storg_lctn_src_sys_cd) as mtrl_storg_lctn_src_sys_cd
,MAX(invy.mtrl_storg_lctn_mtrl_id) as mtrl_storg_lctn_mtrl_id
,MAX(invy.mtrl_storg_lctn_plnt_cd) as mtrl_storg_lctn_plnt_cd
,MAX(invy.mtrl_storg_lctn_mtrl_storg_lctn_cd) as mtrl_storg_lctn_mtrl_storg_lctn_cd
,MAX(invy.mtrl_storg_lctn_mntnc_stts_cd) as mtrl_storg_lctn_mntnc_stts_cd
,MAX(invy.mtrl_storg_lctn_ct_prd_fscl_yr_nr) as mtrl_storg_lctn_ct_prd_fscl_yr_nr
,MAX(invy.mtrl_storg_lctn_ct_prd_pstg_prd_nr) as mtrl_storg_lctn_ct_prd_pstg_prd_nr
,MAX(invy.mtrl_storg_lctn_phy_invy_bkg_ind_cd) as mtrl_storg_lctn_phy_invy_bkg_ind_cd
,MAX(invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd) as mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,MAX(invy.mtrl_storg_lctn_trnsfr_qty_cd) as mtrl_storg_lctn_trnsfr_qty_cd
,MAX(invy.mtrl_storg_lctn_qlty_inspn_qty_cd) as mtrl_storg_lctn_qlty_inspn_qty_cd
,MAX(invy.mtrl_storg_lctn_rstd_btch_qty_cd) as mtrl_storg_lctn_rstd_btch_qty_cd
,MAX(invy.mtrl_storg_lctn_blckd_qty_cd) as mtrl_storg_lctn_blckd_qty_cd
,MAX(invy.mtrl_storg_lctn_blckd_rtn_qty_cd) as mtrl_storg_lctn_blckd_rtn_qty_cd
,MAX(invy.mtrl_storg_lctn_MRP_storg_lctn_ind_cd) as mtrl_storg_lctn_MRP_storg_lctn_ind_cd
,MAX(invy.mtrl_storg_lctn_storg_lctn_prcmt_typ_cd) as mtrl_storg_lctn_storg_lctn_prcmt_typ_cd
,MAX(invy.mtrl_storg_lctn_MRP_storg_lctn_Reorder_qty_cd) as mtrl_storg_lctn_MRP_storg_lctn_Reorder_qty_cd
,MAX(invy.mtrl_storg_lctn_MRP_storg_lctn_rplnshmt_qty_cd) as mtrl_storg_lctn_MRP_storg_lctn_rplnshmt_qty_cd
,MAX(invy.mtrl_storg_lctn_mtrl_orgn_ctry_cd) as mtrl_storg_lctn_mtrl_orgn_ctry_cd
,MAX(invy.mtrl_storg_lctn_storg_bn_cd) as mtrl_storg_lctn_storg_bn_cd
,MAX(invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd) as mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,MAX(invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd) as mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,MAX(invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd) as mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,MAX(invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd) as mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,MAX(invy.mtrl_storg_lctn_last_pstd_dt) as mtrl_storg_lctn_last_pstd_dt
,MAX(invy.mtrl_storg_lctn_pft_cntr_cd) as mtrl_storg_lctn_pft_cntr_cd
,MAX(invy.mtrl_storg_lctn_src_sys_crt_dt) as mtrl_storg_lctn_src_sys_crt_dt
,MAX(invy.mtrl_storg_lctn_stk_vl_amt_cd) as mtrl_storg_lctn_stk_vl_amt_cd
,MAX(invy.mtrl_storg_lctn_stk_trnsfr_amt_cd) as mtrl_storg_lctn_stk_trnsfr_amt_cd
,MAX(invy.mtrl_storg_lctn_ins_ts_cd) as mtrl_storg_lctn_ins_ts_cd
,MAX(invy.mtrl_storg_lctn_upd_ts_dt) as mtrl_storg_lctn_upd_ts_dt
,MAX(invy.mtrl_storg_lctn_lgcl_dlt_ind_cd) as mtrl_storg_lctn_lgcl_dlt_ind_cd
,MAX(invy.totl_vndr_spcl_stk_src_sys_cd) as totl_vndr_spcl_stk_src_sys_cd
,MAX(invy.totl_vndr_spcl_stk_mtrl_id) as totl_vndr_spcl_stk_mtrl_id
,MAX(invy.totl_vndr_spcl_stk_plnt_cd) as totl_vndr_spcl_stk_plnt_cd
,MAX(invy.totl_vndr_spcl_stk_spcl_stk_cd) as totl_vndr_spcl_stk_spcl_stk_cd
,MAX(invy.totl_vndr_spcl_stk_vndr_prty_id) as totl_vndr_spcl_stk_vndr_prty_id
,MAX(invy.totl_vndr_spcl_stk_ct_fscl_yr_nr) as totl_vndr_spcl_stk_ct_fscl_yr_nr
,MAX(invy.totl_vndr_spcl_stk_ct_pstg_prd_nr) as totl_vndr_spcl_stk_ct_pstg_prd_nr
,MAX(invy.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd) as totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,MAX(invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd) as totl_vndr_spcl_stk_qlty_inspn_qty_cd
,MAX(invy.totl_vndr_spcl_stk_totl_rstd_qty_cd) as totl_vndr_spcl_stk_totl_rstd_qty_cd
,MAX(invy.totl_vndr_spcl_stk_src_sys_crt_dt) as totl_vndr_spcl_stk_src_sys_crt_dt
,MAX(invy.totl_vndr_spcl_stk_vndr_stk_valtn_ind_cd) as totl_vndr_spcl_stk_vndr_stk_valtn_ind_cd
,MAX(invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd) as totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,MAX(invy.totl_vndr_spcl_stk_ins_ts_cd) as totl_vndr_spcl_stk_ins_ts_cd
,MAX(invy.totl_vndr_spcl_stk_upd_ts_dt) as totl_vndr_spcl_stk_upd_ts_dt
,MAX(invy.totl_vndr_spcl_stk_lgcl_dlt_ind_cd) as totl_vndr_spcl_stk_lgcl_dlt_ind_cd
,MAX(invy.vndr_spcl_stk_src_sys_cd) as vndr_spcl_stk_src_sys_cd
,MAX(invy.vndr_spcl_stk_mtrl_id) as vndr_spcl_stk_mtrl_id
,MAX(invy.vndr_spcl_stk_plnt_cd) as vndr_spcl_stk_plnt_cd
,MAX(invy.vndr_spcl_stk_mtrl_storg_lctn_cd) as vndr_spcl_stk_mtrl_storg_lctn_cd
,MAX(invy.vndr_spcl_stk_btch_cd) as vndr_spcl_stk_btch_cd
,MAX(invy.vndr_spcl_stk_spcl_stk_cd) as vndr_spcl_stk_spcl_stk_cd
,MAX(invy.vndr_spcl_stk_vndr_prty_id) as vndr_spcl_stk_vndr_prty_id
,MAX(invy.vndr_spcl_stk_src_sys_crt_dt) as vndr_spcl_stk_src_sys_crt_dt
,MAX(invy.vndr_spcl_stk_crtd_by_usr_id) as vndr_spcl_stk_crtd_by_usr_id
,MAX(invy.vndr_spcl_stk_updd_by_usr_id_dt) as vndr_spcl_stk_updd_by_usr_id_dt
,MAX(invy.vndr_spcl_stk_src_Systme_upd_dt) as vndr_spcl_stk_src_Systme_upd_dt
,MAX(invy.vndr_spcl_stk_ct_fscl_yr_nr) as vndr_spcl_stk_ct_fscl_yr_nr
,MAX(invy.vndr_spcl_stk_ct_pstg_prd_nr) as vndr_spcl_stk_ct_pstg_prd_nr
,MAX(invy.vndr_spcl_stk_phy_invy_blck_ind_cd) as vndr_spcl_stk_phy_invy_blck_ind_cd
,MAX(invy.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd) as vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd) as vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd) as vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_blckd_Consigment_qty_cd) as vndr_spcl_stk_blckd_Consigment_qty_cd
,MAX(invy.vndr_spcl_stk_prv_Unrestricted_cnsgnmnt_qty_cd) as vndr_spcl_stk_prv_Unrestricted_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_prv_qlty_inspn_cnsgnmnt_qty_cd) as vndr_spcl_stk_prv_qlty_inspn_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_prv_rstd_cnsgnmnt_qty_cd) as vndr_spcl_stk_prv_rstd_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_prv_blckd_cnsgnmnt_qty_cd) as vndr_spcl_stk_prv_blckd_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_mnm_ord_qty_cd) as vndr_spcl_stk_mnm_ord_qty_cd
,MAX(invy.vndr_spcl_stk_rplnshmt_qty_cd) as vndr_spcl_stk_rplnshmt_qty_cd
,MAX(invy.vndr_spcl_stk_last_pstd_dt) as vndr_spcl_stk_last_pstd_dt
,MAX(invy.vndr_spcl_stk_invy_fscl_yr_nr) as vndr_spcl_stk_invy_fscl_yr_nr
,MAX(invy.vndr_spcl_stk_ins_ts_cd) as vndr_spcl_stk_ins_ts_cd
,MAX(invy.vndr_spcl_stk_upd_ts_dt) as vndr_spcl_stk_upd_ts_dt
,MAX(invy.vndr_spcl_stk_lgcl_dlt_ind_cd) as vndr_spcl_stk_lgcl_dlt_ind_cd
,MAX(invy.sls_ord_stk_src_sys_cd) as sls_ord_stk_src_sys_cd
,MAX(invy.sls_ord_stk_mtrl_id) as sls_ord_stk_mtrl_id
,MAX(invy.sls_ord_stk_plnt_cd) as sls_ord_stk_plnt_cd
,MAX(invy.sls_ord_stk_mtrl_storg_lctn_cd) as sls_ord_stk_mtrl_storg_lctn_cd
,MAX(invy.sls_ord_stk_btch_cd) as sls_ord_stk_btch_cd
,MAX(invy.sls_ord_stk_spcl_stk_cd) as sls_ord_stk_spcl_stk_cd
,MAX(invy.sls_ord_stk_sls_ord_id) as sls_ord_stk_sls_ord_id
,MAX(invy.sls_ord_stk_sls_ord_itm_nr) as sls_ord_stk_sls_ord_itm_nr
,MAX(invy.sls_ord_stk_fscl_yr_nr) as sls_ord_stk_fscl_yr_nr
,MAX(invy.sls_ord_stk_pstg_prd_nr) as sls_ord_stk_pstg_prd_nr
,MAX(invy.sls_ord_stk_blck_ind_cd) as sls_ord_stk_blck_ind_cd
,MAX(invy.sls_ord_stk_Valuated_Unrestricted_qty_cd) as sls_ord_stk_Valuated_Unrestricted_qty_cd
,MAX(invy.sls_ord_stk_qlty_inspn_qty_cd) as sls_ord_stk_qlty_inspn_qty_cd
,MAX(invy.sls_ord_stk_blck_qty_cd) as sls_ord_stk_blck_qty_cd
,MAX(invy.sls_ord_stk_prv_prd_Valuated_Unrestricted_qty_cd) as sls_ord_stk_prv_prd_Valuated_Unrestricted_qty_cd
,MAX(invy.sls_ord_stk_prv_prd_qlty_inspn_qty_cd) as sls_ord_stk_prv_prd_qlty_inspn_qty_cd
,MAX(invy.sls_ord_stk_prv_prd_blck_qty_cd) as sls_ord_stk_prv_prd_blck_qty_cd
,MAX(invy.sls_ord_stk_last_pstd_cnt_dt) as sls_ord_stk_last_pstd_cnt_dt
,MAX(invy.sls_ord_stk_rstd_btch_qty_cd) as sls_ord_stk_rstd_btch_qty_cd
,MAX(invy.sls_ord_stk_prv_prd_rstd_btch_qty_cd) as sls_ord_stk_prv_prd_rstd_btch_qty_cd
,MAX(invy.sls_ord_stk_src_sys_crt_dt) as sls_ord_stk_src_sys_crt_dt
,MAX(invy.sls_ord_stk_phy_invy_fscl_yr_nr) as sls_ord_stk_phy_invy_fscl_yr_nr
,MAX(invy.sls_ord_stk_ins_ts_cd) as sls_ord_stk_ins_ts_cd
,MAX(invy.sls_ord_stk_upd_ts_dt) as sls_ord_stk_upd_ts_dt
,MAX(invy.sls_ord_stk_lgcl_dlt_ind_cd) as sls_ord_stk_lgcl_dlt_ind_cd
,MAX(invy.wh_mgmt_Quant_src_sys_cd) as wh_mgmt_Quant_src_sys_cd
,MAX(invy.wh_mgmt_Quant_wh_cmplx_cd) as wh_mgmt_Quant_wh_cmplx_cd
,MAX(invy.wh_mgmt_Quant_wh_qty_nr) as wh_mgmt_Quant_wh_qty_nr
,MAX(invy.wh_mgmt_Quant_mtrl_id) as wh_mgmt_Quant_mtrl_id
,MAX(invy.wh_mgmt_Quant_plnt_cd) as wh_mgmt_Quant_plnt_cd
,MAX(invy.wh_mgmt_Quant_btch_cd) as wh_mgmt_Quant_btch_cd
,MAX(invy.wh_mgmt_Quant_stk_cgy_cd) as wh_mgmt_Quant_stk_cgy_cd
,MAX(invy.wh_mgmt_Quant_spcl_stk_cd) as wh_mgmt_Quant_spcl_stk_cd
,MAX(invy.wh_mgmt_Quant_spcl_stk_id) as wh_mgmt_Quant_spcl_stk_id
,MAX(invy.wh_mgmt_Quant_storg_typ_cd) as wh_mgmt_Quant_storg_typ_cd
,MAX(invy.wh_mgmt_Quant_storg_bn_id) as wh_mgmt_Quant_storg_bn_id
,MAX(invy.wh_mgmt_Quant_storg_bn_psn_cd) as wh_mgmt_Quant_storg_bn_psn_cd
,MAX(invy.wh_mgmt_Quant_mvmt_ts_cd) as wh_mgmt_Quant_mvmt_ts_cd
,MAX(invy.wh_mgmt_Quant_last_stk_dcmt_nr) as wh_mgmt_Quant_last_stk_dcmt_nr
,MAX(invy.wh_mgmt_Quant_last_stk_itm_nr) as wh_mgmt_Quant_last_stk_itm_nr
,MAX(invy.wh_mgmt_Quant_stk_PlacementTimestamp_cd) as wh_mgmt_Quant_stk_PlacementTimestamp_cd
,MAX(invy.wh_mgmt_Quant_stk_Removal_ts_cd) as wh_mgmt_Quant_stk_Removal_ts_cd
,MAX(invy.wh_mgmt_Quant_stk_addn_dt) as wh_mgmt_Quant_stk_addn_dt
,MAX(invy.wh_mgmt_Quant_gd_rcpt_dt) as wh_mgmt_Quant_gd_rcpt_dt
,MAX(invy.wh_mgmt_Quant_gd_rcpt_id) as wh_mgmt_Quant_gd_rcpt_id
,MAX(invy.wh_mgmt_Quant_gd_rcpt_itm_nr) as wh_mgmt_Quant_gd_rcpt_itm_nr
,MAX(invy.wh_mgmt_Quant_wh_unt_typ_cd) as wh_mgmt_Quant_wh_unt_typ_cd
,MAX(invy.wh_mgmt_Quant_bs_unt_msr_cd) as wh_mgmt_Quant_bs_unt_msr_cd
,MAX(invy.wh_mgmt_Quant_totl_qty_cd) as wh_mgmt_Quant_totl_qty_cd
,MAX(invy.wh_mgmt_Quant_avl_qty_cd) as wh_mgmt_Quant_avl_qty_cd
,MAX(invy.wh_mgmt_Quant_Putaway_qty_cd) as wh_mgmt_Quant_Putaway_qty_cd
,MAX(invy.wh_mgmt_Quant_rmv_qty_cd) as wh_mgmt_Quant_rmv_qty_cd
,MAX(invy.wh_mgmt_Quant_mtrl_wght_cd) as wh_mgmt_Quant_mtrl_wght_cd
,MAX(invy.wh_mgmt_Quant_wght_unt_msr_cd) as wh_mgmt_Quant_wght_unt_msr_cd
,MAX(invy.wh_mgmt_Quant_trnsfr_rqmt_nr) as wh_mgmt_Quant_trnsfr_rqmt_nr
,MAX(invy.wh_mgmt_Quant_rqmt_typ_cd) as wh_mgmt_Quant_rqmt_typ_cd
,MAX(invy.wh_mgmt_Quant_rqmt_id) as wh_mgmt_Quant_rqmt_id
,MAX(invy.wh_mgmt_Quant_storg_unt_id) as wh_mgmt_Quant_storg_unt_id
,MAX(invy.wh_mgmt_Quant_storg_lctn_cd) as wh_mgmt_Quant_storg_lctn_cd
,MAX(invy.wh_mgmt_Quant_hndl_unt_ind_cd) as wh_mgmt_Quant_hndl_unt_ind_cd
,MAX(invy.wh_mgmt_Quant_sm_dlvry_id) as wh_mgmt_Quant_sm_dlvry_id
,MAX(invy.wh_mgmt_Quant_sm_dlvry_itm_nr) as wh_mgmt_Quant_sm_dlvry_itm_nr
,MAX(invy.wh_mgmt_Quant_last_invy_Quant_dt) as wh_mgmt_Quant_last_invy_Quant_dt
,MAX(invy.wh_mgmt_Quant_ins_ts_cd) as wh_mgmt_Quant_ins_ts_cd
,MAX(invy.wh_mgmt_Quant_upd_ts_dt) as wh_mgmt_Quant_upd_ts_dt
,MAX(invy.wh_mgmt_Quant_lgcl_dlt_ind_cd) as wh_mgmt_Quant_lgcl_dlt_ind_cd
,MAX(invy.valtn_typ_src_sys_cd) as valtn_typ_src_sys_cd
,MAX(invy.valtn_typ_valtn_typ_cd) as valtn_typ_valtn_typ_cd
,MAX(invy.valtn_typ_acct_cgy_rfnc_cd) as valtn_typ_acct_cgy_rfnc_cd
,MAX(invy.valtn_typ_xtrn_prch_ord_allwd_cd) as valtn_typ_xtrn_prch_ord_allwd_cd
,MAX(invy.valtn_typ_inrn_prch_ord_allwd_cd) as valtn_typ_inrn_prch_ord_allwd_cd
,MAX(invy.valtn_typ_ins_ts_cd) as valtn_typ_ins_ts_cd
,MAX(invy.valtn_typ_upd_ts_dt) as valtn_typ_upd_ts_dt
,MAX(invy.valtn_typ_lgcl_dlt_ind_cd) as valtn_typ_lgcl_dlt_ind_cd
,MAX(invy.shpg_inst_src_sys_cd) as shpg_inst_src_sys_cd
,MAX(invy.shpg_inst_shpg_inst_cd) as shpg_inst_shpg_inst_cd
,MAX(invy.shpg_inst_shpg_inst_dn_cd) as shpg_inst_shpg_inst_dn_cd
,MAX(invy.shpg_inst_ins_ts_cd) as shpg_inst_ins_ts_cd
,MAX(invy.shpg_inst_upd_ts_dt) as shpg_inst_upd_ts_dt
,MAX(invy.shpg_inst_lgcl_dlt_ind_cd) as shpg_inst_lgcl_dlt_ind_cd
,MAX(invy.spcl_stk_src_sys_cd) as spcl_stk_src_sys_cd
,MAX(invy.spcl_stk_spcl_stk_cd) as spcl_stk_spcl_stk_cd
,MAX(invy.spcl_stk_spcl_stk_dn_cd) as spcl_stk_spcl_stk_dn_cd
,MAX(invy.spcl_stk_ins_ts_cd) as spcl_stk_ins_ts_cd
,MAX(invy.spcl_stk_upd_ts_dt) as spcl_stk_upd_ts_dt
,MAX(invy.spcl_stk_lgcl_dlt_ind_cd) as spcl_stk_lgcl_dlt_ind_cd
,MAX(invy.storg_lctn_src_sys_cd) as storg_lctn_src_sys_cd
,MAX(invy.storg_lctn_plnt_cd) as storg_lctn_plnt_cd
,MAX(invy.storg_lctn_storg_lctn_cd) as storg_lctn_storg_lctn_cd
,MAX(invy.storg_lctn_storg_lctn_dn_cd) as storg_lctn_storg_lctn_dn_cd
,MAX(invy.storg_lctn_dvsn_cd) as storg_lctn_dvsn_cd
,MAX(invy.storg_lctn_ins_ts_cd) as storg_lctn_ins_ts_cd
,MAX(invy.storg_lctn_upd_ts_dt) as storg_lctn_upd_ts_dt
,MAX(invy.storg_lctn_lgcl_dlt_ind_cd) as storg_lctn_lgcl_dlt_ind_cd
,invy.intgtn_fbrc_msg_id
,invy.src_sys_upd_ts
,invy.src_sys_ky
,invy.lgcl_dlt_ind
,invy.ins_gmt_ts
,invy.upd_gmt_ts
,invy.src_sys_extrc_gmt_ts
,invy.src_sys_btch_nr
,invy.fl_nm
,'""" + ref_max_btch_id + """'
,invy.ins_gmt_dt
from """ + srctbl + """ invy 
where date_sub(ins_gmt_dt,-1)>='""" + ins_gmt_date + """' and ld_jb_nr > '""" + ref_normalised_max_btch_id + """' and ld_jb_nr  <= '""" + ref_max_btch_id + """'
group by
invy.mtrl_mvmt_src_sys_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_Valuated_sls_ord_id
,invy.mtrl_mvmt_Valuated_sls_ord_itm_nr
,invy.mtrl_mvmt_spcl_stk_cd
,invy.mtrl_mvmt_gds_mvmt_stk_typ_cd
,invy.mtrl_mvmt_lgl_co_cd
,invy.mtrl_mvmt_qty_upd_ind_dt
,invy.mtrl_mvmt_bs_unt_msr_cd
,invy.mtrl_mvmt_vl_upd_ind_dt
,invy.mtrl_mvmt_sls_dcmt_typ_cd
,invy.mtrl_mvmt_spcl_stk_valtn_typ_cd
,invy.mtrl_mvmt_stk_chrc_cd
,invy.mtrl_mvmt_stk_cgy_cd
,invy.mtrl_mvmt_mtrl_rsrc_plng_ar_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd
,invy.mtrl_mvmt_qty_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd
,invy.mtrl_mvmt_etry_unt_msr_cd
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_src_sys_crt_ts_cd
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_src_sys_upd_dt
,invy.mtrl_mvmt_mtrl_dcmt_id
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_sls_ord_id
,invy.mtrl_mvmt_sls_ord_itm_nr
,invy.mtrl_mvmt_sls_ord_schdl_itm_nr
,invy.mtrl_mvmt_prch_ord_id
,invy.mtrl_mvmt_prch_ord_itm_nr
,invy.mtrl_mvmt_rfnc_dcmt_id
,invy.mtrl_mvmt_rfnc_dcmt_itm_nr
,invy.mtrl_mvmt_ord_id
,invy.mtrl_mvmt_trnsfr_rqmt_nr
,invy.mtrl_mvmt_trnsfr_rqmt_itm_nr
,invy.mtrl_mvmt_pstg_chg_nr
,invy.mtrl_mvmt_trnsfr_ord_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_sm_dlvry_id
,invy.mtrl_mvmt_sm_dlvry_itm_nr
,invy.mtrl_mvmt_cnl_ind_cd
,invy.mtrl_mvmt_cnln_typ_cd
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_ato_ind_cd
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_btch_id
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_dbt_crdt_cd
,invy.mtrl_mvmt_dlvry_cmplt_ind_cd
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_unldg_pnt_dn_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_id
,invy.mtrl_mvmt_rcvg_issg_storg_lctn_cd
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_cnsmpn_pstg_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_nn_Valuated_ind_cd
,invy.mtrl_mvmt_wh_cmplx_cd
,invy.mtrl_mvmt_wh_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,invy.mtrl_mvmt_stk_cgy_Code1_cd
,invy.mtrl_mvmt_WM_mvmt_typ_cd
,invy.mtrl_mvmt_pstg_ind_cd
,invy.mtrl_mvmt_gds_mvmt_rsn_nr
,invy.mtrl_mvmt_shpg_inst_cd
,invy.mtrl_mvmt_shpg_inst_cmpln_cd
,invy.mtrl_mvmt_pft_cntr_cd
,invy.mtrl_mvmt_gds_rcpt_inspn_stts_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_Identifier1_id
,invy.mtrl_mvmt_phy_stk_trnsfr_ind_cd
,invy.mtrl_mvmt_itm_stk_sgm_id
,invy.mtrl_mvmt_rcvg_issg_stk_sgm_id
,invy.mtrl_mvmt_rqmt_stk_sgm_id
,invy.mtrl_mvmt_acct_asngmt_cgy_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_rvaltn_dcmt_typ_cd
,invy.mtrl_mvmt_trsn_evt_typ_cd
,invy.mtrl_mvmt_crtd_by_usr_id
,invy.mtrl_mvmt_ins_ts_cd
,invy.mtrl_mvmt_upd_ts_dt
,invy.mtrl_mvmt_lgcl_dlt_ind_cd
,invy.intgtn_fbrc_msg_id
,invy.src_sys_upd_ts
,invy.src_sys_ky
,invy.lgcl_dlt_ind
,invy.ins_gmt_ts
,invy.upd_gmt_ts
,invy.src_sys_extrc_gmt_ts
,invy.src_sys_btch_nr
,invy.fl_nm
,'""" + ref_max_btch_id + """'
,invy.ins_gmt_dt""").coalesce(numPartitions)

      logger.info("""select 
invy.mtrl_mvmt_src_sys_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_Valuated_sls_ord_id
,invy.mtrl_mvmt_Valuated_sls_ord_itm_nr
,invy.mtrl_mvmt_spcl_stk_cd
,invy.mtrl_mvmt_gds_mvmt_stk_typ_cd
,invy.mtrl_mvmt_lgl_co_cd
,invy.mtrl_mvmt_qty_upd_ind_dt
,invy.mtrl_mvmt_bs_unt_msr_cd
,invy.mtrl_mvmt_vl_upd_ind_dt
,invy.mtrl_mvmt_sls_dcmt_typ_cd
,invy.mtrl_mvmt_spcl_stk_valtn_typ_cd
,invy.mtrl_mvmt_stk_chrc_cd
,invy.mtrl_mvmt_stk_cgy_cd
,invy.mtrl_mvmt_mtrl_rsrc_plng_ar_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd
,invy.mtrl_mvmt_qty_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd
,invy.mtrl_mvmt_etry_unt_msr_cd
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_src_sys_crt_ts_cd
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_src_sys_upd_dt
,invy.mtrl_mvmt_mtrl_dcmt_id
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_sls_ord_id
,invy.mtrl_mvmt_sls_ord_itm_nr
,invy.mtrl_mvmt_sls_ord_schdl_itm_nr
,invy.mtrl_mvmt_prch_ord_id
,invy.mtrl_mvmt_prch_ord_itm_nr
,invy.mtrl_mvmt_rfnc_dcmt_id
,invy.mtrl_mvmt_rfnc_dcmt_itm_nr
,invy.mtrl_mvmt_ord_id
,invy.mtrl_mvmt_trnsfr_rqmt_nr
,invy.mtrl_mvmt_trnsfr_rqmt_itm_nr
,invy.mtrl_mvmt_pstg_chg_nr
,invy.mtrl_mvmt_trnsfr_ord_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_sm_dlvry_id
,invy.mtrl_mvmt_sm_dlvry_itm_nr
,invy.mtrl_mvmt_cnl_ind_cd
,invy.mtrl_mvmt_cnln_typ_cd
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_ato_ind_cd
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_btch_id
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_dbt_crdt_cd
,invy.mtrl_mvmt_dlvry_cmplt_ind_cd
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_unldg_pnt_dn_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_id
,invy.mtrl_mvmt_rcvg_issg_storg_lctn_cd
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_cnsmpn_pstg_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_nn_Valuated_ind_cd
,invy.mtrl_mvmt_wh_cmplx_cd
,invy.mtrl_mvmt_wh_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,invy.mtrl_mvmt_stk_cgy_Code1_cd
,invy.mtrl_mvmt_WM_mvmt_typ_cd
,invy.mtrl_mvmt_pstg_ind_cd
,invy.mtrl_mvmt_gds_mvmt_rsn_nr
,invy.mtrl_mvmt_shpg_inst_cd
,invy.mtrl_mvmt_shpg_inst_cmpln_cd
,invy.mtrl_mvmt_pft_cntr_cd
,invy.mtrl_mvmt_gds_rcpt_inspn_stts_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_Identifier1_id
,invy.mtrl_mvmt_phy_stk_trnsfr_ind_cd
,invy.mtrl_mvmt_itm_stk_sgm_id
,invy.mtrl_mvmt_rcvg_issg_stk_sgm_id
,invy.mtrl_mvmt_rqmt_stk_sgm_id
,invy.mtrl_mvmt_acct_asngmt_cgy_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_rvaltn_dcmt_typ_cd
,invy.mtrl_mvmt_trsn_evt_typ_cd
,invy.mtrl_mvmt_crtd_by_usr_id
,invy.mtrl_mvmt_ins_ts_cd
,invy.mtrl_mvmt_upd_ts_dt
,invy.mtrl_mvmt_lgcl_dlt_ind_cd
,MAX(invy.mtrl_storg_lctn_src_sys_cd) as mtrl_storg_lctn_src_sys_cd
,MAX(invy.mtrl_storg_lctn_mtrl_id) as mtrl_storg_lctn_mtrl_id
,MAX(invy.mtrl_storg_lctn_plnt_cd) as mtrl_storg_lctn_plnt_cd
,MAX(invy.mtrl_storg_lctn_mtrl_storg_lctn_cd) as mtrl_storg_lctn_mtrl_storg_lctn_cd
,MAX(invy.mtrl_storg_lctn_mntnc_stts_cd) as mtrl_storg_lctn_mntnc_stts_cd
,MAX(invy.mtrl_storg_lctn_ct_prd_fscl_yr_nr) as mtrl_storg_lctn_ct_prd_fscl_yr_nr
,MAX(invy.mtrl_storg_lctn_ct_prd_pstg_prd_nr) as mtrl_storg_lctn_ct_prd_pstg_prd_nr
,MAX(invy.mtrl_storg_lctn_phy_invy_bkg_ind_cd) as mtrl_storg_lctn_phy_invy_bkg_ind_cd
,MAX(invy.mtrl_storg_lctn_Valuated_Unrestricted_qty_cd) as mtrl_storg_lctn_Valuated_Unrestricted_qty_cd
,MAX(invy.mtrl_storg_lctn_trnsfr_qty_cd) as mtrl_storg_lctn_trnsfr_qty_cd
,MAX(invy.mtrl_storg_lctn_qlty_inspn_qty_cd) as mtrl_storg_lctn_qlty_inspn_qty_cd
,MAX(invy.mtrl_storg_lctn_rstd_btch_qty_cd) as mtrl_storg_lctn_rstd_btch_qty_cd
,MAX(invy.mtrl_storg_lctn_blckd_qty_cd) as mtrl_storg_lctn_blckd_qty_cd
,MAX(invy.mtrl_storg_lctn_blckd_rtn_qty_cd) as mtrl_storg_lctn_blckd_rtn_qty_cd
,MAX(invy.mtrl_storg_lctn_MRP_storg_lctn_ind_cd) as mtrl_storg_lctn_MRP_storg_lctn_ind_cd
,MAX(invy.mtrl_storg_lctn_storg_lctn_prcmt_typ_cd) as mtrl_storg_lctn_storg_lctn_prcmt_typ_cd
,MAX(invy.mtrl_storg_lctn_MRP_storg_lctn_Reorder_qty_cd) as mtrl_storg_lctn_MRP_storg_lctn_Reorder_qty_cd
,MAX(invy.mtrl_storg_lctn_MRP_storg_lctn_rplnshmt_qty_cd) as mtrl_storg_lctn_MRP_storg_lctn_rplnshmt_qty_cd
,MAX(invy.mtrl_storg_lctn_mtrl_orgn_ctry_cd) as mtrl_storg_lctn_mtrl_orgn_ctry_cd
,MAX(invy.mtrl_storg_lctn_storg_bn_cd) as mtrl_storg_lctn_storg_bn_cd
,MAX(invy.mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd) as mtrl_storg_lctn_Unrestricted_cnsgnmnt_qty_cd
,MAX(invy.mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd) as mtrl_storg_lctn_qlty_inspn_cnsgnmnt_qty_cd
,MAX(invy.mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd) as mtrl_storg_lctn_rstd_cnsgnmnt_qty_cd
,MAX(invy.mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd) as mtrl_storg_lctn_blckd_cnsgnmnt_qty_cd
,MAX(invy.mtrl_storg_lctn_last_pstd_dt) as mtrl_storg_lctn_last_pstd_dt
,MAX(invy.mtrl_storg_lctn_pft_cntr_cd) as mtrl_storg_lctn_pft_cntr_cd
,MAX(invy.mtrl_storg_lctn_src_sys_crt_dt) as mtrl_storg_lctn_src_sys_crt_dt
,MAX(invy.mtrl_storg_lctn_stk_vl_amt_cd) as mtrl_storg_lctn_stk_vl_amt_cd
,MAX(invy.mtrl_storg_lctn_stk_trnsfr_amt_cd) as mtrl_storg_lctn_stk_trnsfr_amt_cd
,MAX(invy.mtrl_storg_lctn_ins_ts_cd) as mtrl_storg_lctn_ins_ts_cd
,MAX(invy.mtrl_storg_lctn_upd_ts_dt) as mtrl_storg_lctn_upd_ts_dt
,MAX(invy.mtrl_storg_lctn_lgcl_dlt_ind_cd) as mtrl_storg_lctn_lgcl_dlt_ind_cd
,MAX(invy.totl_vndr_spcl_stk_src_sys_cd) as totl_vndr_spcl_stk_src_sys_cd
,MAX(invy.totl_vndr_spcl_stk_mtrl_id) as totl_vndr_spcl_stk_mtrl_id
,MAX(invy.totl_vndr_spcl_stk_plnt_cd) as totl_vndr_spcl_stk_plnt_cd
,MAX(invy.totl_vndr_spcl_stk_spcl_stk_cd) as totl_vndr_spcl_stk_spcl_stk_cd
,MAX(invy.totl_vndr_spcl_stk_vndr_prty_id) as totl_vndr_spcl_stk_vndr_prty_id
,MAX(invy.totl_vndr_spcl_stk_ct_fscl_yr_nr) as totl_vndr_spcl_stk_ct_fscl_yr_nr
,MAX(invy.totl_vndr_spcl_stk_ct_pstg_prd_nr) as totl_vndr_spcl_stk_ct_pstg_prd_nr
,MAX(invy.totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd) as totl_vndr_spcl_stk_Valuated_Unrestricted_qty_cd
,MAX(invy.totl_vndr_spcl_stk_qlty_inspn_qty_cd) as totl_vndr_spcl_stk_qlty_inspn_qty_cd
,MAX(invy.totl_vndr_spcl_stk_totl_rstd_qty_cd) as totl_vndr_spcl_stk_totl_rstd_qty_cd
,MAX(invy.totl_vndr_spcl_stk_src_sys_crt_dt) as totl_vndr_spcl_stk_src_sys_crt_dt
,MAX(invy.totl_vndr_spcl_stk_vndr_stk_valtn_ind_cd) as totl_vndr_spcl_stk_vndr_stk_valtn_ind_cd
,MAX(invy.totl_vndr_spcl_stk_plnt_trnsfr_qty_cd) as totl_vndr_spcl_stk_plnt_trnsfr_qty_cd
,MAX(invy.totl_vndr_spcl_stk_ins_ts_cd) as totl_vndr_spcl_stk_ins_ts_cd
,MAX(invy.totl_vndr_spcl_stk_upd_ts_dt) as totl_vndr_spcl_stk_upd_ts_dt
,MAX(invy.totl_vndr_spcl_stk_lgcl_dlt_ind_cd) as totl_vndr_spcl_stk_lgcl_dlt_ind_cd
,MAX(invy.vndr_spcl_stk_src_sys_cd) as vndr_spcl_stk_src_sys_cd
,MAX(invy.vndr_spcl_stk_mtrl_id) as vndr_spcl_stk_mtrl_id
,MAX(invy.vndr_spcl_stk_plnt_cd) as vndr_spcl_stk_plnt_cd
,MAX(invy.vndr_spcl_stk_mtrl_storg_lctn_cd) as vndr_spcl_stk_mtrl_storg_lctn_cd
,MAX(invy.vndr_spcl_stk_btch_cd) as vndr_spcl_stk_btch_cd
,MAX(invy.vndr_spcl_stk_spcl_stk_cd) as vndr_spcl_stk_spcl_stk_cd
,MAX(invy.vndr_spcl_stk_vndr_prty_id) as vndr_spcl_stk_vndr_prty_id
,MAX(invy.vndr_spcl_stk_src_sys_crt_dt) as vndr_spcl_stk_src_sys_crt_dt
,MAX(invy.vndr_spcl_stk_crtd_by_usr_id) as vndr_spcl_stk_crtd_by_usr_id
,MAX(invy.vndr_spcl_stk_updd_by_usr_id_dt) as vndr_spcl_stk_updd_by_usr_id_dt
,MAX(invy.vndr_spcl_stk_src_Systme_upd_dt) as vndr_spcl_stk_src_Systme_upd_dt
,MAX(invy.vndr_spcl_stk_ct_fscl_yr_nr) as vndr_spcl_stk_ct_fscl_yr_nr
,MAX(invy.vndr_spcl_stk_ct_pstg_prd_nr) as vndr_spcl_stk_ct_pstg_prd_nr
,MAX(invy.vndr_spcl_stk_phy_invy_blck_ind_cd) as vndr_spcl_stk_phy_invy_blck_ind_cd
,MAX(invy.vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd) as vndr_spcl_stk_Unrestricted_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd) as vndr_spcl_stk_qlty_inspn_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_rstd_cnsgnmnt_qty_cd) as vndr_spcl_stk_rstd_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_blckd_Consigment_qty_cd) as vndr_spcl_stk_blckd_Consigment_qty_cd
,MAX(invy.vndr_spcl_stk_prv_Unrestricted_cnsgnmnt_qty_cd) as vndr_spcl_stk_prv_Unrestricted_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_prv_qlty_inspn_cnsgnmnt_qty_cd) as vndr_spcl_stk_prv_qlty_inspn_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_prv_rstd_cnsgnmnt_qty_cd) as vndr_spcl_stk_prv_rstd_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_prv_blckd_cnsgnmnt_qty_cd) as vndr_spcl_stk_prv_blckd_cnsgnmnt_qty_cd
,MAX(invy.vndr_spcl_stk_mnm_ord_qty_cd) as vndr_spcl_stk_mnm_ord_qty_cd
,MAX(invy.vndr_spcl_stk_rplnshmt_qty_cd) as vndr_spcl_stk_rplnshmt_qty_cd
,MAX(invy.vndr_spcl_stk_last_pstd_dt) as vndr_spcl_stk_last_pstd_dt
,MAX(invy.vndr_spcl_stk_invy_fscl_yr_nr) as vndr_spcl_stk_invy_fscl_yr_nr
,MAX(invy.vndr_spcl_stk_ins_ts_cd) as vndr_spcl_stk_ins_ts_cd
,MAX(invy.vndr_spcl_stk_upd_ts_dt) as vndr_spcl_stk_upd_ts_dt
,MAX(invy.vndr_spcl_stk_lgcl_dlt_ind_cd) as vndr_spcl_stk_lgcl_dlt_ind_cd
,MAX(invy.sls_ord_stk_src_sys_cd) as sls_ord_stk_src_sys_cd
,MAX(invy.sls_ord_stk_mtrl_id) as sls_ord_stk_mtrl_id
,MAX(invy.sls_ord_stk_plnt_cd) as sls_ord_stk_plnt_cd
,MAX(invy.sls_ord_stk_mtrl_storg_lctn_cd) as sls_ord_stk_mtrl_storg_lctn_cd
,MAX(invy.sls_ord_stk_btch_cd) as sls_ord_stk_btch_cd
,MAX(invy.sls_ord_stk_spcl_stk_cd) as sls_ord_stk_spcl_stk_cd
,MAX(invy.sls_ord_stk_sls_ord_id) as sls_ord_stk_sls_ord_id
,MAX(invy.sls_ord_stk_sls_ord_itm_nr) as sls_ord_stk_sls_ord_itm_nr
,MAX(invy.sls_ord_stk_fscl_yr_nr) as sls_ord_stk_fscl_yr_nr
,MAX(invy.sls_ord_stk_pstg_prd_nr) as sls_ord_stk_pstg_prd_nr
,MAX(invy.sls_ord_stk_blck_ind_cd) as sls_ord_stk_blck_ind_cd
,MAX(invy.sls_ord_stk_Valuated_Unrestricted_qty_cd) as sls_ord_stk_Valuated_Unrestricted_qty_cd
,MAX(invy.sls_ord_stk_qlty_inspn_qty_cd) as sls_ord_stk_qlty_inspn_qty_cd
,MAX(invy.sls_ord_stk_blck_qty_cd) as sls_ord_stk_blck_qty_cd
,MAX(invy.sls_ord_stk_prv_prd_Valuated_Unrestricted_qty_cd) as sls_ord_stk_prv_prd_Valuated_Unrestricted_qty_cd
,MAX(invy.sls_ord_stk_prv_prd_qlty_inspn_qty_cd) as sls_ord_stk_prv_prd_qlty_inspn_qty_cd
,MAX(invy.sls_ord_stk_prv_prd_blck_qty_cd) as sls_ord_stk_prv_prd_blck_qty_cd
,MAX(invy.sls_ord_stk_last_pstd_cnt_dt) as sls_ord_stk_last_pstd_cnt_dt
,MAX(invy.sls_ord_stk_rstd_btch_qty_cd) as sls_ord_stk_rstd_btch_qty_cd
,MAX(invy.sls_ord_stk_prv_prd_rstd_btch_qty_cd) as sls_ord_stk_prv_prd_rstd_btch_qty_cd
,MAX(invy.sls_ord_stk_src_sys_crt_dt) as sls_ord_stk_src_sys_crt_dt
,MAX(invy.sls_ord_stk_phy_invy_fscl_yr_nr) as sls_ord_stk_phy_invy_fscl_yr_nr
,MAX(invy.sls_ord_stk_ins_ts_cd) as sls_ord_stk_ins_ts_cd
,MAX(invy.sls_ord_stk_upd_ts_dt) as sls_ord_stk_upd_ts_dt
,MAX(invy.sls_ord_stk_lgcl_dlt_ind_cd) as sls_ord_stk_lgcl_dlt_ind_cd
,MAX(invy.wh_mgmt_Quant_src_sys_cd) as wh_mgmt_Quant_src_sys_cd
,MAX(invy.wh_mgmt_Quant_wh_cmplx_cd) as wh_mgmt_Quant_wh_cmplx_cd
,MAX(invy.wh_mgmt_Quant_wh_qty_nr) as wh_mgmt_Quant_wh_qty_nr
,MAX(invy.wh_mgmt_Quant_mtrl_id) as wh_mgmt_Quant_mtrl_id
,MAX(invy.wh_mgmt_Quant_plnt_cd) as wh_mgmt_Quant_plnt_cd
,MAX(invy.wh_mgmt_Quant_btch_cd) as wh_mgmt_Quant_btch_cd
,MAX(invy.wh_mgmt_Quant_stk_cgy_cd) as wh_mgmt_Quant_stk_cgy_cd
,MAX(invy.wh_mgmt_Quant_spcl_stk_cd) as wh_mgmt_Quant_spcl_stk_cd
,MAX(invy.wh_mgmt_Quant_spcl_stk_id) as wh_mgmt_Quant_spcl_stk_id
,MAX(invy.wh_mgmt_Quant_storg_typ_cd) as wh_mgmt_Quant_storg_typ_cd
,MAX(invy.wh_mgmt_Quant_storg_bn_id) as wh_mgmt_Quant_storg_bn_id
,MAX(invy.wh_mgmt_Quant_storg_bn_psn_cd) as wh_mgmt_Quant_storg_bn_psn_cd
,MAX(invy.wh_mgmt_Quant_mvmt_ts_cd) as wh_mgmt_Quant_mvmt_ts_cd
,MAX(invy.wh_mgmt_Quant_last_stk_dcmt_nr) as wh_mgmt_Quant_last_stk_dcmt_nr
,MAX(invy.wh_mgmt_Quant_last_stk_itm_nr) as wh_mgmt_Quant_last_stk_itm_nr
,MAX(invy.wh_mgmt_Quant_stk_PlacementTimestamp_cd) as wh_mgmt_Quant_stk_PlacementTimestamp_cd
,MAX(invy.wh_mgmt_Quant_stk_Removal_ts_cd) as wh_mgmt_Quant_stk_Removal_ts_cd
,MAX(invy.wh_mgmt_Quant_stk_addn_dt) as wh_mgmt_Quant_stk_addn_dt
,MAX(invy.wh_mgmt_Quant_gd_rcpt_dt) as wh_mgmt_Quant_gd_rcpt_dt
,MAX(invy.wh_mgmt_Quant_gd_rcpt_id) as wh_mgmt_Quant_gd_rcpt_id
,MAX(invy.wh_mgmt_Quant_gd_rcpt_itm_nr) as wh_mgmt_Quant_gd_rcpt_itm_nr
,MAX(invy.wh_mgmt_Quant_wh_unt_typ_cd) as wh_mgmt_Quant_wh_unt_typ_cd
,MAX(invy.wh_mgmt_Quant_bs_unt_msr_cd) as wh_mgmt_Quant_bs_unt_msr_cd
,MAX(invy.wh_mgmt_Quant_totl_qty_cd) as wh_mgmt_Quant_totl_qty_cd
,MAX(invy.wh_mgmt_Quant_avl_qty_cd) as wh_mgmt_Quant_avl_qty_cd
,MAX(invy.wh_mgmt_Quant_Putaway_qty_cd) as wh_mgmt_Quant_Putaway_qty_cd
,MAX(invy.wh_mgmt_Quant_rmv_qty_cd) as wh_mgmt_Quant_rmv_qty_cd
,MAX(invy.wh_mgmt_Quant_mtrl_wght_cd) as wh_mgmt_Quant_mtrl_wght_cd
,MAX(invy.wh_mgmt_Quant_wght_unt_msr_cd) as wh_mgmt_Quant_wght_unt_msr_cd
,MAX(invy.wh_mgmt_Quant_trnsfr_rqmt_nr) as wh_mgmt_Quant_trnsfr_rqmt_nr
,MAX(invy.wh_mgmt_Quant_rqmt_typ_cd) as wh_mgmt_Quant_rqmt_typ_cd
,MAX(invy.wh_mgmt_Quant_rqmt_id) as wh_mgmt_Quant_rqmt_id
,MAX(invy.wh_mgmt_Quant_storg_unt_id) as wh_mgmt_Quant_storg_unt_id
,MAX(invy.wh_mgmt_Quant_storg_lctn_cd) as wh_mgmt_Quant_storg_lctn_cd
,MAX(invy.wh_mgmt_Quant_hndl_unt_ind_cd) as wh_mgmt_Quant_hndl_unt_ind_cd
,MAX(invy.wh_mgmt_Quant_sm_dlvry_id) as wh_mgmt_Quant_sm_dlvry_id
,MAX(invy.wh_mgmt_Quant_sm_dlvry_itm_nr) as wh_mgmt_Quant_sm_dlvry_itm_nr
,MAX(invy.wh_mgmt_Quant_last_invy_Quant_dt) as wh_mgmt_Quant_last_invy_Quant_dt
,MAX(invy.wh_mgmt_Quant_ins_ts_cd) as wh_mgmt_Quant_ins_ts_cd
,MAX(invy.wh_mgmt_Quant_upd_ts_dt) as wh_mgmt_Quant_upd_ts_dt
,MAX(invy.wh_mgmt_Quant_lgcl_dlt_ind_cd) as wh_mgmt_Quant_lgcl_dlt_ind_cd
,MAX(invy.valtn_typ_src_sys_cd) as valtn_typ_src_sys_cd
,MAX(invy.valtn_typ_valtn_typ_cd) as valtn_typ_valtn_typ_cd
,MAX(invy.valtn_typ_acct_cgy_rfnc_cd) as valtn_typ_acct_cgy_rfnc_cd
,MAX(invy.valtn_typ_xtrn_prch_ord_allwd_cd) as valtn_typ_xtrn_prch_ord_allwd_cd
,MAX(invy.valtn_typ_inrn_prch_ord_allwd_cd) as valtn_typ_inrn_prch_ord_allwd_cd
,MAX(invy.valtn_typ_ins_ts_cd) as valtn_typ_ins_ts_cd
,MAX(invy.valtn_typ_upd_ts_dt) as valtn_typ_upd_ts_dt
,MAX(invy.valtn_typ_lgcl_dlt_ind_cd) as valtn_typ_lgcl_dlt_ind_cd
,MAX(invy.shpg_inst_src_sys_cd) as shpg_inst_src_sys_cd
,MAX(invy.shpg_inst_shpg_inst_cd) as shpg_inst_shpg_inst_cd
,MAX(invy.shpg_inst_shpg_inst_dn_cd) as shpg_inst_shpg_inst_dn_cd
,MAX(invy.shpg_inst_ins_ts_cd) as shpg_inst_ins_ts_cd
,MAX(invy.shpg_inst_upd_ts_dt) as shpg_inst_upd_ts_dt
,MAX(invy.shpg_inst_lgcl_dlt_ind_cd) as shpg_inst_lgcl_dlt_ind_cd
,MAX(invy.spcl_stk_src_sys_cd) as spcl_stk_src_sys_cd
,MAX(invy.spcl_stk_spcl_stk_cd) as spcl_stk_spcl_stk_cd
,MAX(invy.spcl_stk_spcl_stk_dn_cd) as spcl_stk_spcl_stk_dn_cd
,MAX(invy.spcl_stk_ins_ts_cd) as spcl_stk_ins_ts_cd
,MAX(invy.spcl_stk_upd_ts_dt) as spcl_stk_upd_ts_dt
,MAX(invy.spcl_stk_lgcl_dlt_ind_cd) as spcl_stk_lgcl_dlt_ind_cd
,MAX(invy.storg_lctn_src_sys_cd) as storg_lctn_src_sys_cd
,MAX(invy.storg_lctn_plnt_cd) as storg_lctn_plnt_cd
,MAX(invy.storg_lctn_storg_lctn_cd) as storg_lctn_storg_lctn_cd
,MAX(invy.storg_lctn_storg_lctn_dn_cd) as storg_lctn_storg_lctn_dn_cd
,MAX(invy.storg_lctn_dvsn_cd) as storg_lctn_dvsn_cd
,MAX(invy.storg_lctn_ins_ts_cd) as storg_lctn_ins_ts_cd
,MAX(invy.storg_lctn_upd_ts_dt) as storg_lctn_upd_ts_dt
,MAX(invy.storg_lctn_lgcl_dlt_ind_cd) as storg_lctn_lgcl_dlt_ind_cd
,invy.intgtn_fbrc_msg_id
,invy.src_sys_upd_ts
,invy.src_sys_ky
,invy.lgcl_dlt_ind
,invy.ins_gmt_ts
,invy.upd_gmt_ts
,invy.src_sys_extrc_gmt_ts
,invy.src_sys_btch_nr
,invy.fl_nm
,'""" + ref_max_btch_id + """'
,invy.ins_gmt_dt
from """ + srctbl + """ invy 
where date_sub(ins_gmt_dt,-1)>='""" + ins_gmt_date + """' and ld_jb_nr > '""" + ref_normalised_max_btch_id + """' and ld_jb_nr  <= '""" + ref_max_btch_id + """'
group by
invy.mtrl_mvmt_src_sys_cd
,invy.mtrl_mvmt_mtrl_id
,invy.mtrl_mvmt_mtrl_dcmt_yr_nr
,invy.mtrl_mvmt_plnt_cd
,invy.mtrl_mvmt_Valuated_sls_ord_id
,invy.mtrl_mvmt_Valuated_sls_ord_itm_nr
,invy.mtrl_mvmt_spcl_stk_cd
,invy.mtrl_mvmt_gds_mvmt_stk_typ_cd
,invy.mtrl_mvmt_lgl_co_cd
,invy.mtrl_mvmt_qty_upd_ind_dt
,invy.mtrl_mvmt_bs_unt_msr_cd
,invy.mtrl_mvmt_vl_upd_ind_dt
,invy.mtrl_mvmt_sls_dcmt_typ_cd
,invy.mtrl_mvmt_spcl_stk_valtn_typ_cd
,invy.mtrl_mvmt_stk_chrc_cd
,invy.mtrl_mvmt_stk_cgy_cd
,invy.mtrl_mvmt_mtrl_rsrc_plng_ar_cd
,invy.mtrl_mvmt_curr_cd
,invy.mtrl_mvmt_lcl_curr_amt_cd
,invy.mtrl_mvmt_lcl_curr_dlvry_amt_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_amt_cd
,invy.mtrl_mvmt_qty_cd
,invy.mtrl_mvmt_Valuated_stk_pre_pstg_qty_cd
,invy.mtrl_mvmt_stk_qty_cd
,invy.mtrl_mvmt_cnsmpn_qty_cd
,invy.mtrl_mvmt_etry_unt_msr_cd
,invy.mtrl_mvmt_rcvd_qty_cd
,invy.mtrl_mvmt_ord_prc_unt_msr_cd
,invy.mtrl_mvmt_prch_ord_prc_unt_qty_cd
,invy.mtrl_mvmt_prch_ord_unt_msr_cd
,invy.mtrl_mvmt_gd_rcpt_qty_cd
,invy.mtrl_mvmt_dcmt_pstg_dt
,invy.mtrl_mvmt_src_sys_crt_ts_cd
,invy.mtrl_mvmt_dcmt_iss_dt
,invy.mtrl_mvmt_src_sys_upd_dt
,invy.mtrl_mvmt_mtrl_dcmt_id
,invy.mtrl_mvmt_mtrl_dcmt_itm_nr
,invy.mtrl_mvmt_sls_ord_id
,invy.mtrl_mvmt_sls_ord_itm_nr
,invy.mtrl_mvmt_sls_ord_schdl_itm_nr
,invy.mtrl_mvmt_prch_ord_id
,invy.mtrl_mvmt_prch_ord_itm_nr
,invy.mtrl_mvmt_rfnc_dcmt_id
,invy.mtrl_mvmt_rfnc_dcmt_itm_nr
,invy.mtrl_mvmt_ord_id
,invy.mtrl_mvmt_trnsfr_rqmt_nr
,invy.mtrl_mvmt_trnsfr_rqmt_itm_nr
,invy.mtrl_mvmt_pstg_chg_nr
,invy.mtrl_mvmt_trnsfr_ord_nr
,invy.mtrl_mvmt_xtrn_dcmt_id
,invy.mtrl_mvmt_sm_dlvry_id
,invy.mtrl_mvmt_sm_dlvry_itm_nr
,invy.mtrl_mvmt_cnl_ind_cd
,invy.mtrl_mvmt_cnln_typ_cd
,invy.mtrl_mvmt_rvrsl_mvmt_typ_cd
,invy.mtrl_mvmt_mvmt_typ_cd
,invy.mtrl_mvmt_ato_ind_cd
,invy.mtrl_mvmt_storg_lctn_cd
,invy.mtrl_mvmt_btch_id
,invy.mtrl_mvmt_valtn_typ_cd
,invy.mtrl_mvmt_stk_typ_cd
,invy.mtrl_mvmt_vndr_prty_id
,invy.mtrl_mvmt_cust_prty_id
,invy.mtrl_mvmt_dbt_crdt_cd
,invy.mtrl_mvmt_dlvry_cmplt_ind_cd
,invy.mtrl_mvmt_itm_txt_cd
,invy.mtrl_mvmt_shp_to_prty_id
,invy.mtrl_mvmt_unldg_pnt_dn_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_id
,invy.mtrl_mvmt_rcvg_issg_storg_lctn_cd
,invy.mtrl_mvmt_mvmt_cd
,invy.mtrl_mvmt_cnsmpn_pstg_cd
,invy.mtrl_mvmt_rcpt_cd
,invy.mtrl_mvmt_nn_Valuated_ind_cd
,invy.mtrl_mvmt_wh_cmplx_cd
,invy.mtrl_mvmt_wh_typ_cd
,invy.mtrl_mvmt_storg_bn_id
,invy.mtrl_mvmt_stk_cgy_Code1_cd
,invy.mtrl_mvmt_WM_mvmt_typ_cd
,invy.mtrl_mvmt_pstg_ind_cd
,invy.mtrl_mvmt_gds_mvmt_rsn_nr
,invy.mtrl_mvmt_shpg_inst_cd
,invy.mtrl_mvmt_shpg_inst_cmpln_cd
,invy.mtrl_mvmt_pft_cntr_cd
,invy.mtrl_mvmt_gds_rcpt_inspn_stts_cd
,invy.mtrl_mvmt_rcvg_issg_mtrl_Identifier1_id
,invy.mtrl_mvmt_phy_stk_trnsfr_ind_cd
,invy.mtrl_mvmt_itm_stk_sgm_id
,invy.mtrl_mvmt_rcvg_issg_stk_sgm_id
,invy.mtrl_mvmt_rqmt_stk_sgm_id
,invy.mtrl_mvmt_acct_asngmt_cgy_cd
,invy.mtrl_mvmt_dcmt_typ_cd
,invy.mtrl_mvmt_rvaltn_dcmt_typ_cd
,invy.mtrl_mvmt_trsn_evt_typ_cd
,invy.mtrl_mvmt_crtd_by_usr_id
,invy.mtrl_mvmt_ins_ts_cd
,invy.mtrl_mvmt_upd_ts_dt
,invy.mtrl_mvmt_lgcl_dlt_ind_cd
,invy.intgtn_fbrc_msg_id
,invy.src_sys_upd_ts
,invy.src_sys_ky
,invy.lgcl_dlt_ind
,invy.ins_gmt_ts
,invy.upd_gmt_ts
,invy.src_sys_extrc_gmt_ts
,invy.src_sys_btch_nr
,invy.fl_nm
,'""" + ref_max_btch_id + """'
,invy.ins_gmt_dt""")

      transformedDF.write.mode("append").format("ORC").insertInto(dbNameConsmtn + "." + consmptnTable)

      logger.info("Data has been loaded to: " + consmptnTable + " Table")

      val transformeDestdDF = spark.sql("""select count(*) from """ + dbNameConsmtn + """.""" + consmptnTable + """ where date_sub(ins_gmt_dt,-1)>='""" +
        ins_gmt_date + """' and ld_jb_nr  = '""" + ref_max_btch_id + """'""")

      tgt_count = transformeDestdDF.first.getLong(0).toInt

      logger.info("+++++++++++############# Target Count=" + tgt_count + " #############+++++++++++")

      //************************Completion Audit Entries*******************************//

      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudJobStatusCode("success")
    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("success")
    }
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
      toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).
        toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      loadStatus = false
    }
  } finally {
    if (loadStatus) {
      sqlCon.close()
      spark.close()
    } else {
      sqlCon.close()
      spark.close()
      System.exit(1)
    }
  }
}
package com.hpe.batch.driver.facts.demand_supply_planning



import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

object HybridProductLineCustomerTerritory extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

try {
    //****************************Fact Code****************************************//
import java.util.Calendar
import java.text.SimpleDateFormat
val now = Calendar.getInstance.getTime
val dowInt = new SimpleDateFormat("u")
import org.apache.spark.sql.{DataFrame, SparkSession}

var transformedDF:DataFrame = null

var hybrid_it_mthly_prod_ln_cust_tty_mnthly_dmnsn="hybrid_it_mthly_prod_ln_cust_tty_mnthly_dmnsn"

transformedDF = spark.sql("""select
prod_ln_pn_cd
,cust_tty_cd
,Keyfigure_dt
,month(keyfigure_dt) as keyfigure_mnth
,year(keyfigure_dt) as keyfigure_yr
,CASE WHEN month(keyfigure_dt) in ("11","12") then year(keyfigure_dt)+1 else year(keyfigure_dt) end as fiscal_yr
,CASE WHEN month(keyfigure_dt) in ("11","12","1") THEN "Q1" 
WHEN month(keyfigure_dt) in ("2","3","4") THEN "Q2"
WHEN month(keyfigure_dt) in ("5","6","7") THEN "Q3"
ELSE "Q4" END AS qtr 
,coalesce(t1.fncl_flsh__cd ,0L) as fncl_flsh__cd
,coalesce(t1.fnl_sls_pln_unts_cd ,0L) as fnl_sls_pln_unts_cd
,ins_gmt_ts
from
"""+ propertiesObject.getSrcTblConsmtn() +""" t1""")

var loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + hybrid_it_mthly_prod_ln_cust_tty_mnthly_dmnsn)


var hybrid_it_mthly_prod_ln_cust_tty_qtrly_dmnsn="hybrid_it_mthly_prod_ln_cust_tty_qtrly_dmnsn"

transformedDF = spark.sql("""select 
prod_ln_pn_cd
,cust_tty_cd
,fiscal_yr
,qtr
,COALESCE(max(m1),0L) as fnl_sls_pln_unts_cd_m1
,COALESCE(max(m2),0L) as fnl_sls_pln_unts_cd_m2
,COALESCE(max(m3),0L) as fnl_sls_pln_unts_cd_m3
from
(select 
prod_ln_pn_cd
,cust_tty_cd
,Keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr 
,CASE WHEN Keyfigure_mnth in ("11","2","5","8")then  sum(a.group_map[Keyfigure_mnth]) END as m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9")then  sum(a.group_map[Keyfigure_mnth]) END as m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10")then  sum(a.group_map[Keyfigure_mnth]) END as m3
from( select 
prod_ln_pn_cd
,cust_tty_cd 
,Keyfigure_dt
,Keyfigure_mnth
,Keyfigure_yr
,fiscal_yr
,qtr
,map(month(Keyfigure_dt),fnl_sls_pln_unts_cd) as group_map 
from """+ dbNameConsmtn + """."""+ hybrid_it_mthly_prod_ln_cust_tty_mnthly_dmnsn +""") a 
group by
prod_ln_pn_cd
,cust_tty_cd 
,Keyfigure_mnth
,Keyfigure_yr
,fiscal_yr
,qtr) a
group by
prod_ln_pn_cd
,cust_tty_cd
,fiscal_yr
,qtr""")

loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + hybrid_it_mthly_prod_ln_cust_tty_qtrly_dmnsn)


//var Hybrid_prdt_line_cust_territory_fact_temp ="Hybrid_prdt_line_cust_territory_fact_temp"

transformedDF = spark.sql("""select prod_ln_pn_cd	, cust_tty_cd	, keyfigure_dt	, keyfigure_mnth	, keyfigure_yr	, fiscal_yr	, qtr	, fnl_sls_pln_unts_cd	, fncl_flsh__cd	, fnl_sls_pln_unts_cd_m1	, fnl_sls_pln_unts_cd_m2	, fnl_sls_pln_unts_cd_m3	, totl_ord_actuals_rsd_cd_mnthly	, totl_ord_actuals_rsd_cd_m1	, totl_ord_actuals_rsd_cd_m2	, totl_ord_actuals_rsd_cd_m3	, fnl_sls_pln_unts_cd_qtr	, actl_fnl_sls_pln_unts_cd	, actl_fncl_flsh__cd	, pln_accrcy_fnl_sls_pln_unts_cd	, mtd_qtd_attnmnt_fnl_pln_cd	, ins_ts	, rvn_actuals_cd_mnthly	, snpsht_dt	, snpsht_typ from (
select
t1.prod_ln_pn_cd
,t1.cust_tty_cd
,date(t1.Keyfigure_dt) as keyfigure_dt
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr 
,t1.fnl_sls_pln_unts_cd
,t1.fncl_flsh__cd        
,t2.fnl_sls_pln_unts_cd_m1
,t2.fnl_sls_pln_unts_cd_m2
,t2.fnl_sls_pln_unts_cd_m3
,COALESCE(a.totl_ord_actuals_rsd_cd_mnthly,0L) as totl_ord_actuals_rsd_cd_mnthly
,COALESCE(a.totl_ord_actuals_rsd_cd_m1,0L) as totl_ord_actuals_rsd_cd_m1
,COALESCE(a.totl_ord_actuals_rsd_cd_m2,0L) as totl_ord_actuals_rsd_cd_m2
,COALESCE(a.totl_ord_actuals_rsd_cd_m3,0L) as totl_ord_actuals_rsd_cd_m3
,CASE WHEN t1.keyfigure_yr < year(current_timestamp) and t1.keyfigure_mnth not in ("11","12") or  month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and t1.qtr in ("Q1","Q2","Q3") THEN COALESCE(a.totl_ord_actuals_rsd_cd_m1,0L)+COALESCE(a.totl_ord_actuals_rsd_cd_m2,0L)+COALESCE(a.totl_ord_actuals_rsd_cd_m3,0L)
WHEN t1.keyfigure_yr > year(current_timestamp) or month(current_timestamp) in ("11","12","1") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("2","3","4") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("5","6","7") and t1.qtr in ("Q4") THEN  (fnl_sls_pln_unts_cd_m1+fnl_sls_pln_unts_cd_m2+fnl_sls_pln_unts_cd_m3)
WHEN  month(current_timestamp) in ("11") and t1.keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("2") and t1.keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("5") and t1.keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("8") and t1.keyfigure_mnth in ("8","9","10") THEN  (fnl_sls_pln_unts_cd_m1+fnl_sls_pln_unts_cd_m2+fnl_sls_pln_unts_cd_m3)
WHEN  month(current_timestamp) in ("12") and t1.keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("3") and t1.keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("6") and t1.keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("9") and t1.keyfigure_mnth in ("8","9","10") THEN  (COALESCE(a.totl_ord_actuals_rsd_cd_m1,0L)+fnl_sls_pln_unts_cd_m2+fnl_sls_pln_unts_cd_m3)
WHEN  month(current_timestamp) in ("1") and t1.keyfigure_mnth in ("11","12","1") or month(current_timestamp) in ("4") and t1.keyfigure_mnth in ("2","3","4") or month(current_timestamp) in ("7") and t1.keyfigure_mnth in ("5","6","7") or month(current_timestamp) in ("10") and t1.keyfigure_mnth in ("8","9","10") THEN  (COALESCE(a.totl_ord_actuals_rsd_cd_m1,0L)+COALESCE(a.totl_ord_actuals_rsd_cd_m2,0L)+fnl_sls_pln_unts_cd_m3)
END as fnl_sls_pln_unts_cd_qtr
,CASE WHEN year(t1.Keyfigure_dt) < year(current_timestamp) or year(t1.Keyfigure_dt) = year(current_timestamp) and month(t1.Keyfigure_dt) < month((current_timestamp)) 
then coalesce(totl_ord_actuals_rsd_cd_mnthly ,0L)
else COALESCE(fnl_sls_pln_unts_cd,0L) end as actl_fnl_sls_pln_unts_cd
,CASE WHEN year(t1.Keyfigure_dt) < year(current_timestamp) or year(t1.Keyfigure_dt) = year(current_timestamp) and month(t1.Keyfigure_dt) < month((current_timestamp)) 
then coalesce(rvn_actuals_cd_mnthly ,0L)
else COALESCE(fncl_flsh__cd,0L) end as actl_fncl_flsh__cd
,COALESCE(fnl_sls_pln_unts_cd,0L)/COALESCE(a.totl_ord_actuals_rsd_cd_mnthly,0L) as pln_accrcy_fnl_sls_pln_unts_cd
,coalesce(a.totl_ord_actuals_rsd_cd_mnthly,0L)/coalesce(fnl_sls_pln_unts_cd,0L)  as mtd_qtd_attnmnt_fnl_pln_cd
,current_timestamp as ins_ts
,coalesce(rvn_actuals_cd_mnthly ,0L) as rvn_actuals_cd_mnthly
,to_date(t1.ins_gmt_ts) as snpsht_dt
,"MONTHLY" AS snpsht_typ
from 
"""+ dbNameConsmtn + """."""+ hybrid_it_mthly_prod_ln_cust_tty_mnthly_dmnsn +""" t1
left join
"""+ dbNameConsmtn + """."""+ hybrid_it_mthly_prod_ln_cust_tty_qtrly_dmnsn +""" t2
on
t1.prod_ln_pn_cd=t2.prod_ln_pn_cd
and
t1.cust_tty_cd=t2.cust_tty_cd
and
t1.qtr=t2.qtr
and
t1.fiscal_yr=t2.fiscal_yr
left join
(select
t4.prod_ln_pn_cd
,t2.geo_cd
,c1.keyfigure_mnth
,c1.fiscal_yr
,c1.qtr
,sum(c1.rvn_actuals_cd_mnthly) as rvn_actuals_cd_mnthly
,sum(c1.totl_ord_actuals_rsd_cd_mnthly) as totl_ord_actuals_rsd_cd_mnthly
,sum(c3.totl_ord_actuals_rsd_cd_m1) as totl_ord_actuals_rsd_cd_m1
,sum(c3.totl_ord_actuals_rsd_cd_m2) as totl_ord_actuals_rsd_cd_m2
,sum(c3.totl_ord_actuals_rsd_cd_m3) as totl_ord_actuals_rsd_cd_m3
from """+ dbNameConsmtn + """. hybrid_it_tchnl_wk_prod_lctn_cust_mnthly_dmnsn c1
LEFT join
"""+ dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_lctn_cust_qtrly_dmnsn c3
on 
c1.prod_id = c3.prod_id
and
c1.lctn_id = c3.lctn_id
and
c1.cust_id = c3.cust_id
and
c1.qtr=c3.qtr
and 
c1.fiscal_yr = c3.fiscal_yr
left join
"""+ dbNameConsmtn + """.hpe_cust_hrchy_dmnsn t2
on 
c1.cust_id=t2.cust_id
left join
"""+ dbNameConsmtn + """.hpe_prod_dmnsn t4
on 
c1.prod_id=t4.prod_id
group by
t4.prod_ln_pn_cd
,t2.geo_cd
,c1.keyfigure_mnth
,c1.fiscal_yr
,c1.qtr) a
on
a.prod_ln_pn_cd=t1.prod_ln_pn_cd
and
a.geo_cd=t1.cust_tty_cd
and
a.fiscal_yr=t1.fiscal_yr
and
a.keyfigure_mnth=t1.keyfigure_mnth
and
a.qtr=t1.qtr) k
where to_date(k.snpsht_dt) >= date_sub(current_date,366)
""")



//************************Completion Audit Entries*******************************//
    loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable)
    var src_count = 0
    var tgt_count = 0

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    //Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
}
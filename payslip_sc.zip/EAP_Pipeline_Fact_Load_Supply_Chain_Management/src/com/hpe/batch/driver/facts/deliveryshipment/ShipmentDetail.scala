package com.hpe.batch.driver.facts.deliveryshipment

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import scala.collection.JavaConversions._
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import org.apache.spark.sql.expressions.Window

object ShipmentDetail extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj:AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var ld_jb_nr_ref = (ld_jb_nr + "_" + batchId)
  val sourceTable =propertiesObject.getSrcTblConsmtn()
  val targetTable =propertiesObject.getTgtTblConsmtn()
  var dbNameConsmtn: String = null
  var ref2: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    ref2 = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  var dbNameConsmtnmainref: String = null 
  var mainref: String = null
  if (propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtnmainref = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0)
     mainref = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(1)
     
     logger.info("main ref tabel name and schema name "+ dbNameConsmtnmainref + mainref)
     
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  
   try {    

  val shipmentMaxInsertTimestamp = "'"+spark.sql(f""" select coalesce(max(ins_gmt_ts),'1900-01-01 00:00:01') from $targetTable""").collect.map(row => row.getString(0)).mkString("")+"'" 
  
  
  //val transformeSrcdDF = spark.sql("""select * from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp)""")
  
  //val src_count = transformeSrcdDF.count().toInt
  
  logger.info("************* Inside if Table Write Status : loadStatus -->*********")
  
 
val keys_sm_ref="""    sm_dtl_sm_id,sm_dtl_sm_itm_nr,sm_dtl_src_sys_cd,sm_dtl_sls_dcmt_itm_cgy_cd,sm_dtl_crtd_by_usr_id,sm_dtl_mtrl_grp_cd,sm_dtl_plnt_cd,sm_dtl_storg_lctn_cd,sm_dtl_btch_cd,sm_dtl_vndr_btch_id,sm_dtl_cust_mtrl_id,sm_dtl_prod_hrchy_cd,sm_dtl_sm_qty_cd,sm_dtl_bs_unt_msr_cd,sm_dtl_sls_unt_msr_cd,sm_dtl_numerator_cnvrsn_nr,sm_dtl_dnmntr_cnvrsn_nr,sm_dtl_nt_wght_cd,sm_dtl_grs_wght_cd,sm_dtl_wght_unt_msr_cd,sm_dtl_sm_itm_vol_cd,sm_dtl_vol_unt_msr_cd,sm_dtl_prtl_itm_dlvry_ind_cd,sm_dtl_ulmt_ovr_dlvry_ind_cd,sm_dtl_ovr_dlvry_tlnc_lmt_pct_cd,sm_dtl_undr_dlvry_tlnc_lmt_pct_cd,sm_dtl_allw_btch_splt_ind_cd,sm_dtl_blng_blck_rsn_cd,sm_dtl_mtrl_availabilty_dt,sm_dtl_actl_dlvry_qty_cd,sm_dtl_sls_ord_itm_dn_cd,sm_dtl_storg_bn_cd,sm_dtl_orgntg_dcmt_id,sm_dtl_orgntg_itm_nr,sm_dtl_sls_dcmt_cgy_cd,sm_dtl_preceding_dcmt_lgcl_sys_cd,sm_dtl_rfnc_dcmt_cd,sm_dtl_rfnc_itm_nr,sm_dtl_upd_dcmt_fw_ind_dt,sm_dtl_hghr_lvl_itm_nr,sm_dtl_blng_rlvnt_ind_cd,sm_dtl_loading_grp_cd,sm_dtl_trns_grp_cd,sm_dtl_pckng_ctrl_cd,sm_dtl_wh_cmplx_cd,sm_dtl_wh_dlvry_splt_ind_cd,sm_dtl_wh_typ_cd,sm_dtl_seprt_valtn_ind_cd,sm_dtl_invy_mgmt_mvmt_typ_cd,sm_dtl_wh_mgmt_mvmt_typ_cd,sm_dtl_dyn_storg_bn_ind_cd,sm_dtl_rqmt_typ_cd,sm_dtl_plng_typ_ind_cd,sm_dtl_mtrl_typ_cd,sm_dtl_btch_mgmt_rqmt_ind_cd,sm_dtl_btch_mgmt_inrn_ind_cd,sm_dtl_rfnc_preceding_dcmt_ind_cd,sm_dtl_sls_ord_itm_typ_cd,sm_dtl_mtrl_valtn_typ_cd,sm_dtl_chk_avblty_grp_cd,sm_dtl_bsn_ar_cd,sm_dtl_sls_ofc_cd,sm_dtl_sls_grp_cd,sm_dtl_sls_dvsn_cd,sm_dtl_dlvry_grp_nr,sm_dtl_fx_qty_ind_cd,sm_dtl_mxm_prtl_dlvry_qty_cd,sm_dtl_fx_shpg_prsng_tm_cd,sm_dtl_vrbl_shpg_prsng_tm_cd,sm_dtl_upd_grp_dt,sm_dtl_itm_cst_amt_cd,sm_dtl_subtotal_1_amt_cd,sm_dtl_subtotal_2_amt_cd,sm_dtl_subtotal_3_amt_cd,sm_dtl_subtotal_4_amt_cd,sm_dtl_subtotal_5_amt_cd,sm_dtl_subtotal_6_amt_cd,sm_dtl_spcl_stk_cd,sm_dtl_intl_article_nr,sm_dtl_cust_grp_1_cd,sm_dtl_cust_grp_2_cd,sm_dtl_cust_grp_3_cd,sm_dtl_cust_grp_4_cd,sm_dtl_cust_grp_5_cd,sm_dtl_mtrl_grp_1_cd,sm_dtl_mtrl_grp_2_cd,sm_dtl_mtrl_grp_3_cd,sm_dtl_mtrl_grp_4_cd,sm_dtl_mtrl_grp_5_cd,sm_dtl_allctn_ind_cd,sm_dtl_preceding_dcmt_cgy_cd,sm_dtl_cst_cntr_cd,sm_dtl_ctrlng_ar_cd,sm_dtl_pftblty_sgm_nr,sm_dtl_pft_cntr_cd,sm_dtl_wrk_brkdwn_srtr_elmt_nr,sm_dtl_ord_id,sm_dtl_ord_itm_nr,sm_dtl_entrd_mtrl_id,sm_dtl_mtrl_id,sm_dtl_plng_plnt_cd,sm_dtl_prod_grp_bs_unt_msr_cd,sm_dtl_sale_cnvrsn_fctr_qty_cd,sm_dtl_acct_asngmt_cgy_cd,sm_dtl_cnsmpn_pstg_cd,sm_dtl_cmmtmnt_itm_cd,sm_dtl_fnd_cntr_cd,sm_dtl_fnd_cd,sm_dtl_rqmt_clss_cd,sm_dtl_cmltv_btch_stk_unt_qty_cd,sm_dtl_cmltv_btch_grs_wght_cd,sm_dtl_cmltv_btch_nt_wght_cd,sm_dtl_cmltv_btch_vol_cd,sm_dtl_hghr_lvl_btch_itm_nr,sm_dtl_cnfgn_id,sm_dtl_btch_cnfgn_id,sm_dtl_srl_qty_nr,sm_dtl_srl_pfl_cd,sm_dtl_bom_explsn_cd,sm_dtl_inrn_dlvry_schdl_nr,sm_dtl_usg_cd,sm_dtl_inspn_lt_nr,sm_dtl_prtl_lt_nr,sm_dtl_pkgg_mtrl_grp_cd,sm_dtl_btch_rec_cndn_cd,sm_dtl_frn_trd_bsn_trsn_typ_cd,sm_dtl_inrn_clss_nr,sm_dtl_btch_exit_prpsl_qty_cd,sm_dtl_allctn_tbl_id,sm_dtl_allctn_tbl_itm_nr,sm_dtl_cndn_unt_msr_cd,sm_dtl_nt_prc_amt_cd,sm_dtl_ord_itm_nt_amt_cd,sm_dtl_mtrl_frgt_grp_cd,sm_dtl_pmnt_grnt_cd,sm_dtl_grntd_fctr_nr,sm_dtl_mtrl_stgg_ts_cd,sm_dtl_cntrct_id,sm_dtl_cntrct_itm_nr,sm_dtl_situation_cd,sm_dtl_rsrvtn_nr,sm_dtl_rsrvtn_itm_nr,sm_dtl_sqn_nr,sm_dtl_dangerous_gds_cd,sm_dtl_cmltv_btch_sls_unt_qty_cd,sm_dtl_spcl_stk_valtn_typ_cd,sm_dtl_prj_dfn_nr,sm_dtl_wd_sqn_grp_cd,sm_dtl_stk_dtrmn_rl_cd,sm_dtl_invy_mgmt_actv_ind_cd,sm_dtl_mfrr_prt_pfl_cd,sm_dtl_mfrr_prt_mtrl_id,sm_dtl_wh_cmplx_stgg_ar_cd,sm_dtl_ww_unq_id,sm_dtl_orgl_itm_nr,sm_dtl_xtrn_itm_nr,sm_dtl_deactivate_avblty_chk_ind_cd,sm_dtl_pckng_not_rlvnt_ind_cd,sm_dtl_rfnc_mvmt_typ_nr,sm_dtl_mrp_ar_cd,sm_dtl_stk_cgy_cd,sm_dtl_rcvg_mtrl_cd,sm_dtl_rcvg_plnt_cd,sm_dtl_rcvg_storg_lctn_cd,sm_dtl_rcvg_btch_cd,sm_dtl_trnsfr_btch_valtn_typ_cd,sm_dtl_phy_stk_trnsfr_ind_cd,sm_dtl_spcl_stk_id,sm_dtl_curr_exch_rate_cd,sm_dtl_qty_clsfn_cd,sm_dtl_rpr_prsng_itm_clsfn_cd,sm_dtl_mn_pstg_ind_cd,sm_dtl_stk_typ_cd,sm_dtl_btch_etry_dtrmn_ind_cd,sm_dtl_mtrl_stgg_mtd_cd,sm_dtl_gds_mvmt_not_rlvnt_ind_cd,sm_dtl_gnrl_ldgr_acct_id,sm_dtl_rsrvtn_itm_fnl_iss_ind_cd,sm_dtl_mfr_dt,sm_dtl_bst_bfr_dt,sm_dtl_fscl_yr_nr,sm_dtl_rfnc_acctng_dcmt_id,sm_dtl_rfnc_dcmt_itm_nr,sm_dtl_gds_mvmt_rsn_nr,sm_dtl_sbsqnt_mvmt_typ_cd,sm_dtl_dlvry_cgy_cd,sm_dtl_xtrn_pstg_lcl_curr_amt_cd,sm_dtl_prch_ord_prc_unt_qty_cd,sm_dtl_xtrn_sls_vl_lcl_curr_amt_cd,sm_dtl_crdt_itm_prc_amt_cd,sm_dtl_prf_dlvry_expctd_ind_cd,sm_dtl_dbn_not_rlvnt_ind_cd,sm_dtl_dlvry_cnvrsn_fctr_qty_cd,sm_dtl_prf_dlvry_rlvnc_cd,sm_dtl_stk_trnsfr_ind_cd,sm_dtl_fnctl_ar_cd,sm_dtl_gnt_cd,sm_dtl_usg_unt_msr_ind_cd,sm_dtl_gds_mvmt_cgy_cd,sm_dtl_hndl_unt_gds_mvmt_cgy_cd,sm_dtl_kanban_ind_cd,sm_dtl_sls_ord_itm_bndl_dn_cd,sm_dtl_sls_ord_itm_bndl_id,sm_dtl_late_tm_dlvry_dt,sm_dtl_tm_dlvry_dt,sm_dtl_src_sys_crt_ts_cd,sm_dtl_src_sys_upd_dt,sm_dtl_ins_ts_cd,sm_dtl_upd_ts_dt,sm_dtl_lgcl_dlt_ind_cd,bdl_qty,obj_individual_stts_cd,
sls_dstbn_dcmt_nr,sls_dstbn_dcmt_itm_nr,counter_nr,obj_indvl_stts_cd,ord_nr,stts_qty,stts_ts,sm_upd_ts_dt
, intgtn_fbrc_msg_id , src_sys_upd_ts, src_sys_ky
                    ,  lgcl_dlt_ind, ins_gmt_ts, upd_gmt_ts, src_sys_extrc_gmt_ts, src_sys_btch_nr
                    ,  fl_nm ,'""" + ld_jb_nr_ref + """' as ld_jb_nr , to_date(ins_gmt_ts) as ins_gmt_dt"""

val hive_ref_select = spark.sql(f"""select $keys_sm_ref from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp) and sm_dtl_src_sys_cd is not null and sm_dtl_sm_id is not null and sm_dtl_sm_itm_nr is not null""")

val query_hive_Ref_select = s"""select $keys_sm_ref from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp) and  sm_dtl_src_sys_cd is not null and sm_dtl_sm_id is not null and sm_dtl_sm_itm_nr is not null"""

logger.info("*************** query_hive_Ref_select  ************ "  +  query_hive_Ref_select)

val windowSpec = Window.partitionBy("sm_dtl_src_sys_cd", "sm_dtl_sm_id","sm_dtl_sm_itm_nr").orderBy(desc("sm_upd_ts_dt"))

val finalDataset = hive_ref_select.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm")

finalDataset.persist(StorageLevel.MEMORY_AND_DISK_SER)
val src_count = finalDataset.count
val tgt_count = src_count 

val numOfWritePartitions = if((shipmentMaxInsertTimestamp.contains("1900-"))) ((spark.conf.get("spark.sql.shuffle.partitions")).toInt)/5 else {((spark.conf.get("spark.sql.shuffle.partitions")).toInt)/30}

val loadStatus = Utilities.storeDataFrame(finalDataset, "Append", "ORC", targetTable,tgt_count,numOfWritePartitions) 

   //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ld_jb_nr_ref)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
      logger.info("************* Inside if Table Write Status : loadStatus -->*********" + loadStatus)
    } else {
      auditObj.setAudJobStatusCode("failed")
      logger.info("************* Inside else Table Write Status : loadStatus -->*********" + loadStatus)
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}
package com.hpe.batch.driver.facts.pdm

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.functions.row_number

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object VariantConfigurationBifurcation extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var ld_jb_nr_ref = (ld_jb_nr + "_" + batchId)
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val tgtTblRef = propertiesObject.getTgtTblRef()
  val audittable = propertiesObject.getAuditTbl()

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, "vrnt_cnfgn")

  try {

    var vc_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, "vrnt_cnfgn")

    logger.info("Bifurication Load of VC Started!!!!!!!!!!!!!")

    logger.info("Max batch id of VC ref table " + vc_max_btch_id.toString())

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********vrnt_cnfgn_chrc_dta_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    //**********VC Header Level 1**************************//
    val hive_ref_table_vrnt_cnfgn_chrc_dta_ref = propertiesObject.getHive_ref_table_vrnt_cnfgn_chrc_dta_ref()

    val Keys_table_vrnt_cnfgn_chrc_dta_ref = propertiesObject.getKeys_table_vrnt_cnfgn_chrc_dta_ref()

    val vrnt_cnfgn_chrc_dta_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_vrnt_cnfgn_chrc_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of VC Header Level 1 table " + vrnt_cnfgn_chrc_dta_max_btch_id.toString())

    var transformeSrcdDF = spark.sql("""select * from """ + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_chrc_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

    var src_count = transformeSrcdDF.count().toInt

    if (src_count != 0) {

      var hiveRefSelect = spark.sql("select " + Keys_table_vrnt_cnfgn_chrc_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_chrc_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      logger.info("select " + Keys_table_vrnt_cnfgn_chrc_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_chrc_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      var filterRow = hiveRefSelect.filter((col("hdr_lvl_1_inrn_chrc_nr").isNotNull))

      var windowSpec = Window.partitionBy("hdr_lvl_1_inrn_chrc_nr", "itm_lvl_tru_cwn_inrn_chr_nr", "itm_lvl_tru_atzhl_inrn_cnter_vl_nr", "itm_lvl_tru_clss_typ_cd", "itm_lvl_tru_cwn_inrn_cnter_qty_nr").orderBy(desc("hdr_lvl_1_src_sys_crt_dt"), desc("hdr_lvl_1_src_sys_upd_dt"), desc("ins_gmt_ts"))

      var addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(10)

      //******verified

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table_vrnt_cnfgn_chrc_dta_ref)

      var tgt_count = addRowNo.count().toInt

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(vc_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table_vrnt_cnfgn_chrc_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) {
        auditObj.setAudJobStatusCode("failed")
      } else {
        auditObj.setAudJobStatusCode("success")
      }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table_vrnt_cnfgn_chrc_dta_ref + " Table")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********vrnt_cnfgn_obj_dpndncy_dta_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    //**********VC Header Level 3**************************//
    val hive_ref_table_vrnt_cnfgn_obj_dpndncy_dta_ref = propertiesObject.getHive_ref_table_vrnt_cnfgn_obj_dpndncy_dta_ref()

    val Keys_table_vrnt_cnfgn_obj_dpndncy_dta_ref = propertiesObject.getKeys_table_vrnt_cnfgn_obj_dpndncy_dta_ref()

    val vrnt_cnfgn_obj_dpndncy_dta_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_vrnt_cnfgn_obj_dpndncy_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of VC Header Level 3 table " + vrnt_cnfgn_obj_dpndncy_dta_max_btch_id.toString())

    transformeSrcdDF = spark.sql("""select * from """ + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_obj_dpndncy_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

    src_count = transformeSrcdDF.count().toInt

    if (src_count != 0) {

      var hiveRefSelect = spark.sql("select " + Keys_table_vrnt_cnfgn_obj_dpndncy_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_obj_dpndncy_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      logger.info("select " + Keys_table_vrnt_cnfgn_obj_dpndncy_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_obj_dpndncy_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      var filterRow = hiveRefSelect.filter((col("hdr_lvl_3_kndg_elmt_inrn_nr").isNotNull))

      var windowSpec = Window.partitionBy("hdr_lvl_3_kndg_elmt_inrn_nr", "itm_lvl_3_dpncy_cnter_qty_nr", "itm_lvl_3_lng_cd", "hdr_lvl_3_inrn_cnter_qty_nr", "itm_lvl_3_ckn_inrn_cnter_qty_nr", "itm_lvl_3_ckbt_inrn_cnter_qty_nr").orderBy(desc("hdr_lvl_3_src_sys_crt_dt"), desc("hdr_lvl_3_src_sys_upd_dt"), desc("ins_gmt_ts"))

      var addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(10)

      //******verified

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table_vrnt_cnfgn_obj_dpndncy_dta_ref)

      var tgt_count = addRowNo.count().toInt

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(vc_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table_vrnt_cnfgn_obj_dpndncy_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) {
        auditObj.setAudJobStatusCode("failed")
      } else {
        auditObj.setAudJobStatusCode("success")
      }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table_vrnt_cnfgn_obj_dpndncy_dta_ref + " Table")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********vrnt_cnfgn_dcmt_info_dta_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    //**********VC Header Level 8**************************//
    val hive_ref_table_vrnt_cnfgn_dcmt_info_dta_ref = propertiesObject.getHive_ref_table_vrnt_cnfgn_dcmt_info_dta_ref()

    val Keys_table_vrnt_cnfgn_dcmt_info_dta_ref = propertiesObject.getKeys_table_vrnt_cnfgn_dcmt_info_dta_ref()

    val vrnt_cnfgn_dcmt_info_dta_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_vrnt_cnfgn_dcmt_info_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of VC Header Level 8 table " + vrnt_cnfgn_dcmt_info_dta_max_btch_id.toString())

    transformeSrcdDF = spark.sql("""select * from """ + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_dcmt_info_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

    src_count = transformeSrcdDF.count().toInt

    if (src_count != 0) {

      var hiveRefSelect = spark.sql("select " + Keys_table_vrnt_cnfgn_dcmt_info_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_dcmt_info_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      logger.info("select " + Keys_table_vrnt_cnfgn_dcmt_info_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_dcmt_info_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      var filterRow = hiveRefSelect.filter((col("hdr_lvl_8_dcmt_id").isNotNull).and(col("hdr_lvl_8_dcmt_prt_cd").isNotNull).and(col("hdr_lvl_8_dcmt_vrsn_id").isNotNull))

      var windowSpec = Window.partitionBy("hdr_lvl_8_dcmt_id", "hdr_lvl_8_dcmt_prt_cd", "hdr_lvl_8_dcmt_vrsn_id", "hdr_lvl_8_dcmt_typ_cd").orderBy(desc("hdr_lvl_8_src_sys_crt_ts"), desc("hdr_lvl_8_src_sys_upd_ts"), desc("ins_gmt_ts"))

      var addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(10)

      //******verified

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table_vrnt_cnfgn_dcmt_info_dta_ref)

      var tgt_count = addRowNo.count().toInt

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(vc_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table_vrnt_cnfgn_dcmt_info_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) {
        auditObj.setAudJobStatusCode("failed")
      } else {
        auditObj.setAudJobStatusCode("success")
      }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table_vrnt_cnfgn_dcmt_info_dta_ref + " Table")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********vrnt_cnfgn_chg_mstr_dta_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    //**********VC Header Level 0**************************//
    val hive_ref_table_vrnt_cnfgn_chg_mstr_dta_ref = propertiesObject.getHive_ref_table_vrnt_cnfgn_chg_mstr_dta_ref()

    val Keys_table_vrnt_cnfgn_chg_mstr_dta_ref = propertiesObject.getKeys_table_vrnt_cnfgn_chg_mstr_dta_ref()

    val vrnt_cnfgn_chg_mstr_dta_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_vrnt_cnfgn_chg_mstr_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of VC Header Level 0 table " + vrnt_cnfgn_chg_mstr_dta_max_btch_id.toString())

    transformeSrcdDF = spark.sql("""select * from """ + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_chg_mstr_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

    src_count = transformeSrcdDF.count().toInt

    if (src_count != 0) {

      var hiveRefSelect = spark.sql("select " + Keys_table_vrnt_cnfgn_chg_mstr_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_chg_mstr_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      logger.info("select " + Keys_table_vrnt_cnfgn_chg_mstr_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_chg_mstr_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      var filterRow = hiveRefSelect.filter((col("hdr_lvl_0_engg_chg_id").isNotNull))

      var windowSpec = Window.partitionBy("hdr_lvl_0_engg_chg_id").orderBy(desc("hdr_lvl_0_src_sys_crt_ts"), desc("hdr_lvl_0_src_sys_upd_ts"), desc("ins_gmt_ts"))

      var addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(10)

      //******verified

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table_vrnt_cnfgn_chg_mstr_dta_ref)

      var tgt_count = addRowNo.count().toInt

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(vc_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table_vrnt_cnfgn_chg_mstr_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) {
        auditObj.setAudJobStatusCode("failed")
      } else {
        auditObj.setAudJobStatusCode("success")
      }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table_vrnt_cnfgn_chg_mstr_dta_ref + " Table")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********vrnt_cnfgn_clsfctn_dta_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    //**********VC Header Level 6**************************//
    val hive_ref_table_vrnt_cnfgn_clsfctn_dta_ref = propertiesObject.getHive_ref_table_vrnt_cnfgn_clsfctn_dta_ref()

    val Keys_table_vrnt_cnfgn_clsfctn_dta_ref = propertiesObject.getKeys_table_vrnt_cnfgn_clsfctn_dta_ref()

    val vrnt_cnfgn_clsfctn_dta_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_vrnt_cnfgn_clsfctn_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of VC Header Level 6 table " + vrnt_cnfgn_clsfctn_dta_max_btch_id.toString())

    transformeSrcdDF = spark.sql("""select * from """ + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_clsfctn_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

    src_count = transformeSrcdDF.count().toInt

    if (src_count != 0) {

      var hiveRefSelect = spark.sql("select " + Keys_table_vrnt_cnfgn_clsfctn_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_clsfctn_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      logger.info("select " + Keys_table_vrnt_cnfgn_clsfctn_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_clsfctn_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      var filterRow = hiveRefSelect.filter((col("hdr_lvl_6_inrn_clss_nr").isNotNull).and(col("hdr_lvl_6_clss_typ_cd").isNotNull).and(col("hdr_lvl_6_obj_clss_ind_dt").isNotNull).and(col("hdr_lvl_6_obj_nr").isNotNull).and(col("itm_lvl_6_inrn_chr_nr").isNotNull).and(col("itm_lvl_6_cnter_qty_nr").isNotNull).and(col("itm_lvl_6_clss_typ_cd").isNotNull).and(col("itm_lvl_6_obj_clss_ind").isNotNull).and(col("itm_lvl_6_obj_nr").isNotNull))

      var windowSpec = Window.partitionBy("hdr_lvl_6_inrn_clss_nr", "hdr_lvl_6_clss_typ_cd", "hdr_lvl_6_obj_clss_ind_dt", "hdr_lvl_6_obj_nr", "itm_lvl_6_inrn_chr_nr", "itm_lvl_6_cnter_qty_nr", "itm_lvl_6_clss_typ_cd", "itm_lvl_6_obj_clss_ind", "itm_lvl_6_obj_nr", "hdr_lvl_6_inrn_cnter_qty_nr", "itm_lvl_6_inrn_cnter_qty_nr").orderBy(desc("ins_gmt_ts"))

      var addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(10)

      //******verified

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table_vrnt_cnfgn_clsfctn_dta_ref)

      var tgt_count = addRowNo.count().toInt

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(vc_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table_vrnt_cnfgn_clsfctn_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) {
        auditObj.setAudJobStatusCode("failed")
      } else {
        auditObj.setAudJobStatusCode("success")
      }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table_vrnt_cnfgn_clsfctn_dta_ref + " Table")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********vrnt_cnfgn_cnfgrbl_dta_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    //**********VC Header Level 5**************************//
    val hive_ref_table_vrnt_cnfgn_cnfgrbl_dta_ref = propertiesObject.getHive_ref_table_vrnt_cnfgn_cnfgrbl_dta_ref()

    val Keys_table_vrnt_cnfgn_cnfgrbl_dta_ref = propertiesObject.getKeys_table_vrnt_cnfgn_cnfgrbl_dta_ref()

    val vrnt_cnfgn_cnfgrbl_dta_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_vrnt_cnfgn_cnfgrbl_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of VC Header Level 5 table " + vrnt_cnfgn_cnfgrbl_dta_max_btch_id.toString())

    transformeSrcdDF = spark.sql("""select * from """ + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_cnfgrbl_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

    src_count = transformeSrcdDF.count().toInt

    if (src_count != 0) {

      var hiveRefSelect = spark.sql("select " + Keys_table_vrnt_cnfgn_cnfgrbl_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_cnfgrbl_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      logger.info("select " + Keys_table_vrnt_cnfgn_cnfgrbl_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_cnfgrbl_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      var filterRow = hiveRefSelect.filter((col("hdr_lvl_5_cnfgl_obj_ind").isNotNull).and(col("hdr_lvl_5_tbl_ind").isNotNull).and(col("itm_lvl_5_cnfgn_pfl_stts_cd_ind").isNotNull))

      var windowSpec = Window.partitionBy("hdr_lvl_5_cnfgl_obj_ind", "hdr_lvl_5_tbl_ind", "itm_lvl_5_obj_tbl_id", "itm_lvl_5_asngd_obj_dpncs_qty_nr", "itm_lvl_5_kndg_elmt_inrn_nr", "itm_lvl_5_cnfgn_pfl_stts_cd_ind", "itm_lvl_5_archvng_ecm_objcts_qty_nr","hdr_lvl_5_inrn_cnter_ind").orderBy(desc("hdr_lvl_5_src_sys_upd_dt"), desc("ins_gmt_ts"))

      var addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(10)

      //******verified

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table_vrnt_cnfgn_cnfgrbl_dta_ref)

      var tgt_count = addRowNo.count().toInt

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(vc_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table_vrnt_cnfgn_cnfgrbl_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) {
        auditObj.setAudJobStatusCode("failed")
      } else {
        auditObj.setAudJobStatusCode("success")
      }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table_vrnt_cnfgn_cnfgrbl_dta_ref + " Table")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********vrnt_cnfgn_cls_dta_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    //**********VC Header Level 2**************************//
    val hive_ref_table_vrnt_cnfgn_cls_dta_ref = propertiesObject.getHive_ref_table_vrnt_cnfgn_cls_dta_ref()

    val Keys_table_vrnt_cnfgn_cls_dta_ref = propertiesObject.getKeys_table_vrnt_cnfgn_cls_dta_ref()

    val vrnt_cnfgn_cls_dta_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_vrnt_cnfgn_cls_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of VC Header Level 2 table " + vrnt_cnfgn_cls_dta_max_btch_id.toString())

    transformeSrcdDF = spark.sql("""select * from """ + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_cls_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

    src_count = transformeSrcdDF.count().toInt

    if (src_count != 0) {

      var hiveRefSelect = spark.sql("select " + Keys_table_vrnt_cnfgn_cls_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_cls_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      logger.info("select " + Keys_table_vrnt_cnfgn_cls_dta_ref + ",'" + vc_max_btch_id + "' as ld_jb_nr,ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + vrnt_cnfgn_cls_dta_max_btch_id + "' and ld_jb_nr <= '" + vc_max_btch_id + "'")

      var filterRow = hiveRefSelect.filter((col("hdr_lvl_2_inrn_clss_nr").isNotNull).and(col("itm_lvl_2_ksmt_itm_nr").isNotNull).and(col("itm_lvl_2_swr_itm_nr").isNotNull).and(col("itm_lvl_2_swr_lng_cd_ind").isNotNull))

      var windowSpec = Window.partitionBy("hdr_lvl_2_inrn_clss_nr", "itm_lvl_2_klt_lng_cd_ind", "itm_lvl_2_txt_id", "itm_lvl_2_ksmt_itm_nr", "itm_lvl_2_swr_itm_nr", "itm_lvl_2_swr_lng_cd_ind", "itm_lvl_2_ksml_inrn_cnter_qty_nr", "itm_lvl_2_cwnt_inrn_cnter_qty_nr").orderBy(desc("hdr_lvl_2_src_sys_crt_ts"), desc("hdr_lvl_2_src_sys_upd_ts"), desc("ins_gmt_ts"))

      var addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(10)

      //******verified

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table_vrnt_cnfgn_cls_dta_ref)

      var tgt_count = addRowNo.count().toInt

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(vc_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table_vrnt_cnfgn_cls_dta_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) {
        auditObj.setAudJobStatusCode("failed")
      } else {
        auditObj.setAudJobStatusCode("success")
      }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table_vrnt_cnfgn_cls_dta_ref + " Table")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("************VC Refine Bifurication completed*************************")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } finally {
    sqlCon.close()
    spark.close()
  }
}
package com.hpe.batch.driver.facts.pdm

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.functions.row_number
import org.joda.time.Days
import org.joda.time.format.DateTimeFormat

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object MtrlChgRqstPlnt extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  if (sqlCon == null) {
    logger.error("+++++++++++############# MYSQL Connection not established #############+++++++++++")
    spark.close()
    System.exit(1)
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var ld_jb_nr_ref = (ld_jb_nr + "_" + batchId)
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName()
  val tgtTblRef = propertiesObject.getTgtTblRef()
  val audittable = propertiesObject.getAuditTbl()

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, "mtrl_chg_rqst")

  def calculateDaysBetween(startTimestamp: String, endTimestamp: String): String = {
    var businessTS = ""
    try {
      val timeStampFormater = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss")
      val startDateTS = timeStampFormater.parseDateTime(startTimestamp)
      val endDateTS = timeStampFormater.parseDateTime(endTimestamp)
      val diff = endDateTS.getMillis - startDateTS.getMillis
      val daysBetween = Days.daysBetween(startDateTS, endDateTS).getDays
      val businessDays = (daysBetween)
      val diffSeconds = diff / 1000 % 60;
      val diffMinutes = diff / (60 * 1000) % 60;
      val diffHours = (diff / (60 * 60 * 1000) % 24);
      businessTS = (businessDays + "d " + Math.abs(diffHours) + ":" + Math.abs(diffMinutes) + ":" + Math.abs(diffSeconds))

    } catch {
      case e: Exception => {
      }
      case ex: java.lang.IllegalArgumentException => {
      }
    }
    businessTS
  }

  try {

    var mcr_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, "mtrl_chg_rqst")

    logger.info("Bifurication Load of MCR Started!!!!!!!!!!!!!")

    logger.info("Max batch id of MCR ref table " + mcr_max_btch_id.toString())

    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***********mtrl_chg_rqst_plnt_ref***************||||||||||||||||||||||||||||||")
    logger.info("||||||||||||||||||***************************************************||||||||||||||||||||||||||||||")

    //**********MCR Role Assignment Lab**************************//
    val hive_ref_table_mtrl_chg_rqst_plnt_ref = propertiesObject.getHive_ref_table_mtrl_chg_rqst_plnt_ref()

    val Keys_table_mtrl_chg_rqst_plnt_ref = propertiesObject.getKeys_table_mtrl_chg_rqst_plnt_ref()

    val mtrl_chg_rqst_plnt_max_btch_id = Utilities.readMaxRefBatchId(sqlCon, hive_ref_table_mtrl_chg_rqst_plnt_ref.trim().split("\\.", -1)(1).replace("_ref", ""))

    logger.info("Max batch id of MCR Role Assignment Lab " + mtrl_chg_rqst_plnt_max_btch_id.toString())

    var transformeSrcdDF = spark.sql("""select * from """ + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + mtrl_chg_rqst_plnt_max_btch_id + "' and ld_jb_nr <= '" + mcr_max_btch_id + "'")

    var src_count = transformeSrcdDF.count().toInt

    if (src_count != 0) {

      var hiveRefSelect = spark.sql("select " + Keys_table_mtrl_chg_rqst_plnt_ref + ",'" + mcr_max_btch_id + "' as ld_jb_nr, ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + mtrl_chg_rqst_plnt_max_btch_id + "' and ld_jb_nr <= '" + mcr_max_btch_id + "'")

      logger.info("select " + Keys_table_mtrl_chg_rqst_plnt_ref + ",'" + mcr_max_btch_id + "' as ld_jb_nr, ins_gmt_dt from " + dbName + """.""" + tgtTblRef + " where ld_jb_nr > '" + mtrl_chg_rqst_plnt_max_btch_id + "' and ld_jb_nr <= '" + mcr_max_btch_id + "'")

      var filterRow = hiveRefSelect.filter((col("mtrl_chg_rqst_id").isNotNull).and(col("mtrl_chg_rqst_plnt_usr_id").isNotNull))

      var windowSpec = Window.partitionBy("mtrl_chg_rqst_id", "mtrl_chg_rqst_plnt_usr_id").orderBy(desc("mtrl_chg_rqst_crtdt_ts"), desc("mtrl_chg_rqst_chngdt_ts"), desc("ins_gmt_ts"))

      var addRowNo = filterRow.withColumn("row_nm", row_number() over windowSpec).where(col("row_nm").equalTo(1)).drop("row_nm").coalesce(10)

      var loadStatus = Utilities.storeDataFrame(addRowNo, "Append", "ORC", hive_ref_table_mtrl_chg_rqst_plnt_ref)

      var tgt_count = addRowNo.count().toInt

      //************************Completion Audit Entries*******************************//
      auditObj.setAudBatchId(mcr_max_btch_id)
      auditObj.setAudDataLayerName("rw_ref")
      auditObj.setAudApplicationName("job_EA_loadConsumption")
      auditObj.setAudObjectName(hive_ref_table_mtrl_chg_rqst_plnt_ref.trim().split("\\.", -1)(1).replace("_ref", ""))
      auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      if (loadStatus == false & tgt_count > 0) {
        auditObj.setAudJobStatusCode("failed")
      } else {
        auditObj.setAudJobStatusCode("success")
      }
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudErrorRecords(0)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setFlNm("")
      auditObj.setSysBtchNr(ld_jb_nr)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      logger.info("Data has been loaded to:" + hive_ref_table_mtrl_chg_rqst_plnt_ref + " Table")

    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
    }

    logger.info("************MCR Refine Bifurication completed*************************")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      spark.close()
    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } finally {
    sqlCon.close()
    spark.close()
  }
}
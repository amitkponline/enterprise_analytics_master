package com.hpe.batch.driver.facts.demand_supply_planning

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import java.util.Calendar
import java.text.SimpleDateFormat
import org.apache.spark.sql.{DataFrame, SparkSession}

object ArubaProductFact extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  
try {
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val transformeSrcdDF = spark.sql("""select * from """ + propertiesObject.getSrcTblConsmtn() )
  var src_count = transformeSrcdDF.count().toInt
  

    //****************************Fact Code****************************************//

var aruba_prod_jn_dmnsn="aruba_prod_jn_dmnsn"
val now = Calendar.getInstance.getTime
val dowInt = new SimpleDateFormat("u")

var transformedDF_1 = spark.sql("""select
CASE WHEN b.ky_fgr_dt is not NULL then b.ky_fgr_dt
else a.ky_fgr_dt end as ky_fgr_dt
,CASE WHEN b.prod_id is not NULL then b.prod_id
else a.prod_id end as prod_id
,CASE WHEN b.ky_fgr_dt is not NULL and month(b.ky_fgr_dt) in ("11","12") then year(b.ky_fgr_dt)+1 
WHEN a.ky_fgr_dt is not NULL and month(a.ky_fgr_dt) in ("11","12") then year(a.ky_fgr_dt)+1
else year(b.ky_fgr_dt) end as fiscal_yr
,CASE WHEN month(b.ky_fgr_dt) in ("11","12","1") THEN "Q1" 
WHEN month(b.ky_fgr_dt) in ("2","3","4") THEN "Q2"
WHEN month(b.ky_fgr_dt) in ("5","6","7") THEN "Q3" 
ELSE "Q4" END AS qtr 
,coalesce(dsa_flg_cd,0L) as dsa_flg_cd
,coalesce(rebalancing_flg_cd,0L) as rebalancing_flg_cd
,coalesce(calcd_ww_frp_cd,0L) as calcd_ww_frp_cd
,coalesce(gbl_shrt_trm_horizon_cd,0L) as gbl_shrt_trm_horizon_cd
,coalesce(rebalancing_opty_ind_cd,0L) as rebalancing_opty_ind_cd
,coalesce(rebalancing_thrs_cd,0L) as rebalancing_thrs_cd
,coalesce(ww_dmnd_cd,0L) as ww_dmnd_cd
,coalesce(ww_frp_bsln_cd,0L) as ww_frp_bsln_cd
,coalesce(ww_frp_fnl_cd,0L) as ww_frp_fnl_cd
,coalesce(ww_frp_overide_id,0L) as ww_frp_overide_id
,coalesce(ww_invy_tgt_cd,0L) as ww_invy_tgt_cd
,coalesce(ww_hnd_invy_cd,0L) as ww_hnd_invy_cd
,coalesce(ww_receipts_cd,0L) as ww_receipts_cd
from """+ dbNameConsmtn + "." + """aruba_mthly_prod_da_dmnsn A
FULL JOIN """+ dbNameConsmtn + "." + """aruba_tchnl_wk_prod_da_dmnsn B
on A.prod_id=B.prod_id
and year(A.ky_fgr_dt)=year(B.ky_fgr_dt)
and month(A.ky_fgr_dt)=month(B.ky_fgr_dt)""")

var loadStatus = Utilities.storeDataFrame(transformedDF_1, "overwrite", "ORC", dbNameConsmtn + "." + aruba_prod_jn_dmnsn)

var snapshot_type= spark.sql("""select monthly_snapshot_date_dt from """+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn where monthly_snapshot_date_dt = current_date""")

var transformedTgtDF:DataFrame = null

// Here dataframe will hold existing data from Fact Table for monthly snapshot creation
if (snapshot_type.count().toInt!=0)
{
transformedTgtDF = spark.sql("""select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from (select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) U2  union all
select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from (select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 11)) U2""")
}
// Here dataframe will hold existing data from Fact Table for weekly snapshot creation
else if (dowInt.format(now) == "7")
{
transformedTgtDF = spark.sql("""select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "DAILY"  union all 
select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from (select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY"  and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 25)) U2  union all
select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from (select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) U2""")
}
// Here dataframe will hold existing data from Fact Table for daily snapshot creation
else 
{
transformedTgtDF = spark.sql("""select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from (select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" and snpsht_dt <> to_date(CURRENT_DATE)  and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "WEEKLY" order by snpsht_dt desc limit 26)) U2  union all
select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from (select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from  """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" and snpsht_dt <> to_date(CURRENT_DATE) and snpsht_dt in (select distinct snpsht_dt from """+dbNameConsmtn + "." + consmptnTable+""" where snpsht_typ = "MONTHLY" order by snpsht_dt desc limit 12)) U2""")
}

transformedTgtDF.createOrReplaceTempView("transformedTgtDF_table")

var aruba_prod_fact="aruba_prod_fact"

var transformedDF = spark.sql("""select aruba_prod_fact_ky,ky_fgr_dt,prod_id,dsa_flg_cd,rebalancing_flg_cd,calcd_ww_frp_cd,gbl_shrt_trm_horizon_cd,rebalancing_opty_ind_cd,rebalancing_thrs_cd,ww_dmnd_cd,ww_frp_bsln_cd,ww_frp_fnl_cd,ww_frp_overide_id,ww_invy_tgt_cd,ww_hnd_invy_cd,ww_receipts_cd,frp_qtrly_por_cd,totl_ord_actuals_rsd_cd_m1,totl_ord_actuals_rsd_cd_m2,totl_ord_actuals_rsd_cd_m3,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3,frp_dlta_cd,ins_ts,snpsht_dt,snpsht_typ from  transformedTgtDF_table union all
select
crc32(upper(trim(CONCAT(coalesce(cast(A.ky_fgr_dt as string),""),coalesce(A.prod_id,""),coalesce(CAST(CURRENT_DATE as string),""))))) 
,date(A.ky_fgr_dt)
,A.prod_id
,coalesce(dsa_flg_cd,0L) as dsa_flg_cd
,coalesce(rebalancing_flg_cd,0L) as rebalancing_flg_cd
,coalesce(calcd_ww_frp_cd,0L) as calcd_ww_frp_cd
,coalesce(gbl_shrt_trm_horizon_cd,0L) as gbl_shrt_trm_horizon_cd
,coalesce(rebalancing_opty_ind_cd,0L) as rebalancing_opty_ind_cd
,coalesce(rebalancing_thrs_cd,0L) as rebalancing_thrs_cd
,coalesce(ww_dmnd_cd,0L) as ww_dmnd_cd
,coalesce(ww_frp_bsln_cd,0L) as ww_frp_bsln_cd
,coalesce(ww_frp_fnl_cd,0L) as ww_frp_fnl_cd
,coalesce(ww_frp_overide_id,0L) as ww_frp_overide_id
,coalesce(ww_invy_tgt_cd,0L) as ww_invy_tgt_cd
,coalesce(ww_hnd_invy_cd,0L) as ww_hnd_invy_cd
,coalesce(ww_receipts_cd,0L) as ww_receipts_cd
,CASE WHEN year(A.ky_fgr_dt) < year(current_timestamp) and month(A.ky_fgr_dt) not in ("11","12") or  month(current_timestamp) in ("2","3","4") and A.qtr in ("Q1") OR month(current_timestamp) in ("5","6","7") and A.qtr in ("Q1","Q2") OR month(current_timestamp) in ("8","9","10") and A.qtr in ("Q1","Q2","Q3") 
THEN totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+totl_ord_actuals_rsd_cd_m3
WHEN year(A.ky_fgr_dt) > year(current_timestamp) or month(current_timestamp) in ("11","12","1") and A.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("2","3","4") and A.qtr in ("Q3","Q4") OR month(current_timestamp) in ("5","6","7") and A.qtr in ("Q4") 
and date_format(current_date, 'u') = "7" THEN  (ww_frpfinal_to_splyr_cd_wk_m1+ww_frpfinal_to_splyr_cd_wk_m2+ww_frpfinal_to_splyr_cd_wk_m3)
WHEN  month(current_timestamp) in ("11") and month(A.ky_fgr_dt) in ("11","12","1") or month(current_timestamp) in ("2") and month(A.ky_fgr_dt) in ("2","3","4") or month(current_timestamp) in ("5") and month(A.ky_fgr_dt) in ("5","6","7") or month(current_timestamp) in ("8") and month(A.ky_fgr_dt) in ("8","9","10") 
and date_format(current_date, 'u') = "7" THEN  (ww_frpfinal_to_splyr_cd_wk_m1+ww_frpfinal_to_splyr_cd_wk_m2+ww_frpfinal_to_splyr_cd_wk_m3)
WHEN  month(current_timestamp) in ("12") and month(A.ky_fgr_dt) in ("11","12","1") or month(current_timestamp) in ("3") and month(A.ky_fgr_dt) in ("2","3","4") or month(current_timestamp) in ("6") and month(A.ky_fgr_dt) in ("5","6","7") or month(current_timestamp) in ("9") and month(A.ky_fgr_dt) in ("8","9","10") 
and date_format(current_date, 'u') = "7" THEN  (totl_ord_actuals_rsd_cd_m1+ww_frpfinal_to_splyr_cd_wk_m2+ww_frpfinal_to_splyr_cd_wk_m3)
WHEN  month(current_timestamp) in ("1") and month(A.ky_fgr_dt) in ("11","12","1") or month(current_timestamp) in ("4") and month(A.ky_fgr_dt) in ("2","3","4") or month(current_timestamp) in ("7") and month(A.ky_fgr_dt) in ("5","6","7") or month(current_timestamp) in ("10") and month(A.ky_fgr_dt) in ("8","9","10") 
and date_format(current_date, 'u') = "7" THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+ww_frpfinal_to_splyr_cd_wk_m3)
WHEN year(A.ky_fgr_dt) > year(current_timestamp) or month(current_timestamp) in ("11","12","1") and A.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("2","3","4") and A.qtr in ("Q3","Q4") OR month(current_timestamp) in ("5","6","7") and A.qtr in ("Q4") 
THEN  (ww_frpfinal_to_splyr_cd_m1+ww_frpfinal_to_splyr_cd_m2+ww_frpfinal_to_splyr_cd_m3)
WHEN  month(current_timestamp) in ("11") and month(A.ky_fgr_dt) in ("11","12","1") or month(current_timestamp) in ("2") and month(A.ky_fgr_dt) in ("2","3","4") or month(current_timestamp) in ("5") and month(A.ky_fgr_dt) in ("5","6","7") or month(current_timestamp) in ("8") and month(A.ky_fgr_dt) in ("8","9","10") 
THEN  (ww_frpfinal_to_splyr_cd_m1+ww_frpfinal_to_splyr_cd_m2+ww_frpfinal_to_splyr_cd_m3)
WHEN  month(current_timestamp) in ("12") and month(A.ky_fgr_dt) in ("11","12","1") or month(current_timestamp) in ("3") and month(A.ky_fgr_dt) in ("2","3","4") or month(current_timestamp) in ("6") and month(A.ky_fgr_dt) in ("5","6","7") or month(current_timestamp) in ("9") and month(A.ky_fgr_dt) in ("8","9","10") 
THEN  (totl_ord_actuals_rsd_cd_m1+ww_frpfinal_to_splyr_cd_m2+ww_frpfinal_to_splyr_cd_m3)
WHEN  month(current_timestamp) in ("1") and month(A.ky_fgr_dt) in ("11","12","1") or month(current_timestamp) in ("4") and month(A.ky_fgr_dt) in ("2","3","4") or month(current_timestamp) in ("7") and month(A.ky_fgr_dt) in ("5","6","7") or month(current_timestamp) in ("10") and month(A.ky_fgr_dt) in ("8","9","10") 
THEN  (totl_ord_actuals_rsd_cd_m1+totl_ord_actuals_rsd_cd_m2+ww_frpfinal_to_splyr_cd_m3)
END as frp_qtrly_por_cd
,coalesce(totl_ord_actuals_rsd_cd_m1,0L) as totl_ord_actuals_rsd_cd_m1
,coalesce(totl_ord_actuals_rsd_cd_m2,0L) as totl_ord_actuals_rsd_cd_m2
,coalesce(totl_ord_actuals_rsd_cd_m3,0L) as totl_ord_actuals_rsd_cd_m3
,coalesce(C.ww_frpfinal_to_splyr_cd_m1,0L) as ww_frpfinal_to_splyr_cd_m1
,coalesce(C.ww_frpfinal_to_splyr_cd_m2,0L) as ww_frpfinal_to_splyr_cd_m2
,coalesce(C.ww_frpfinal_to_splyr_cd_m3,0L) as ww_frpfinal_to_splyr_cd_m3
,coalesce(C.ww_frpfinal_to_splyr_cd_wk_m1,0L) as ww_frpfinal_to_splyr_cd_wk_m1
,coalesce(C.ww_frpfinal_to_splyr_cd_wk_m2,0L) as ww_frpfinal_to_splyr_cd_wk_m2
,coalesce(C.ww_frpfinal_to_splyr_cd_wk_m3,0L) as ww_frpfinal_to_splyr_cd_wk_m3
,coalesce(ww_frp_overide_id,0L)-coalesce(ww_frp_fnl_cd,0L) as frp_dlta_cd 
,current_timestamp as ins_ts
,CURRENT_DATE as snpsht_dt
,Case WHEN X.monthly_snapshot_date_dt is NOT NULL then "MONTHLY" 
when date_format(current_date, 'u') = "7" then "WEEKLY" 
else "DAILY" END AS snpsht_typ
from """+ dbNameConsmtn + "." + aruba_prod_jn_dmnsn + """ A
left join (select prod_id,qtr,fiscal_yr,sum(totl_ord_actuals_rsd_cd_m1) as totl_ord_actuals_rsd_cd_m1,sum(totl_ord_actuals_rsd_cd_m2) as totl_ord_actuals_rsd_cd_m2
,sum(totl_ord_actuals_rsd_cd_m3) as totl_ord_actuals_rsd_cd_m3 from 
"""+ dbNameConsmtn + """.aruba_twk_prod_lctn_cust_all_vlue_dmnsn A group by prod_id,qtr,fiscal_yr) B
ON A.prod_id=B.prod_id and A.qtr=B.qtr and A.fiscal_yr=B.fiscal_yr
left join (select prod_id,qtr,ky_fgr_yr,ww_frpfinal_to_splyr_cd_m1,ww_frpfinal_to_splyr_cd_m2,ww_frpfinal_to_splyr_cd_m3,ww_frpfinal_to_splyr_cd_wk_m1,ww_frpfinal_to_splyr_cd_wk_m2,ww_frpfinal_to_splyr_cd_wk_m3  from 
"""+ dbNameConsmtn + """.aruba_prod_shipfromglobalsupplier_qtrly_dmnsn A) C
ON A.prod_id=C.prod_id and A.qtr=C.qtr and year(A.ky_fgr_dt)=C.ky_fgr_yr
LEFT join
"""+dbNameConsmtn + """.bmt_edge_mthly_dates_dmnsn X
on current_date()=X.monthly_snapshot_date_dt""")

    loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable)
    var tgt_count = transformedDF.count().toInt


//************************Completion Audit Entries*******************************//

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("cnsmptn_fact")
    auditObj.setAudApplicationName("ArubaProductFact")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)     
    }
    case allException: IllegalArgumentException => {
      logger.error("Illegal Argument")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  }
  finally {
    sqlCon.close()
    spark.close()
  }
}
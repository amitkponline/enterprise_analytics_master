package com.hpe.batch.driver.facts.demand_supply_planning

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.lit

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object HybridProductCustomerFact extends App {

  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  spark.conf.set("spark.sql.crossJoin.enabled", "true")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())
  var loadStatus = false
  var src_count: Long = 0
  var tgt_count: Long = 0

  try {
    //****************************Fact Code****************************************//
    import java.util.Calendar
    import java.text.SimpleDateFormat
    val now = Calendar.getInstance.getTime
    val dowInt = new SimpleDateFormat("u")
    import org.apache.spark.sql.{ DataFrame, SparkSession }

    val hybrid_it_tchnl_wk_prod_cust_all_rgn_df = spark.sql("""select
prod_id
,cust_id
,Keyfigure_dt
,fnl_mtrl_frcst_qty_cd
,consensus_dmnd_pln_qty_cd
,lnkd_srvr_h_cd
,atch_rate_frcst_lwr_prio_cd
,atch_rate_fnl_cd
from """ + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_ams_dmnsn
UNION ALL
select
prod_id
,cust_id
,Keyfigure_dt
,fnl_mtrl_frcst_qty_cd
,consensus_dmnd_pln_qty_cd
,lnkd_srvr_h_cd
,atch_rate_frcst_lwr_prio_cd
,atch_rate_fnl_cd
from """ + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_emea_dmnsn
union all
select
prod_id
,cust_id
,Keyfigure_dt
,fnl_mtrl_frcst_qty_cd
,consensus_dmnd_pln_qty_cd
,lnkd_srvr_h_cd
,atch_rate_frcst_lwr_prio_cd
,atch_rate_fnl_cd
from """ + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_apj_dmnsn""").distinct()

    hybrid_it_tchnl_wk_prod_cust_all_rgn_df.repartition(22).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + ".hybrid_it_tchnl_wk_prod_cust_all_rgn_dmnsn")
    logger.info("Table hybrid_it_tchnl_wk_prod_cust_all_rgn_dmnsn is refreshed")

    val hybrid_it_tchnl_wk_prod_cust_fnl_joined_df = spark.sql("""select 
prod_id
,cust_id
,Keyfigure_dt
,month(keyfigure_dt) as keyfigure_mnth
,year(keyfigure_dt) as keyfigure_yr
,CASE WHEN month(keyfigure_dt) in ("11","12") then year(keyfigure_dt)+1 else year(keyfigure_dt) end as fiscal_yr
,CASE WHEN month(keyfigure_dt) in ("11","12","1") THEN "Q1" 
WHEN month(keyfigure_dt) in ("2","3","4") THEN "Q2"
WHEN month(keyfigure_dt) in ("5","6","7") THEN "Q3"
ELSE "Q4" END AS qtr 
,fnl_mtrl_frcst_qty_cd
,consensus_dmnd_pln_qty_cd
,lnkd_srvr_h_cd
,atch_rate_frcst_lwr_prio_cd
,atch_rate_fnl_cd
,NULL as consensus_dmnd_pln_qty_lag2_cd
,NULL as consensus_dmnd_pln_qty_lag1_cd
from (select
prod_id
,cust_id
,Keyfigure_dt
,CASE WHEN t1.fnl_mtrl_frcst_qty_cd  is NULL then 0 else t1.fnl_mtrl_frcst_qty_cd end as fnl_mtrl_frcst_qty_cd
,CASE WHEN t1.consensus_dmnd_pln_qty_cd is NULL then 0 else t1.consensus_dmnd_pln_qty_cd end as consensus_dmnd_pln_qty_cd
,CASE WHEN t1.lnkd_srvr_h_cd is NULL then 0 else t1.lnkd_srvr_h_cd end as lnkd_srvr_h_cd
,CASE WHEN t1.atch_rate_frcst_lwr_prio_cd is NULL then 0 else t1.atch_rate_frcst_lwr_prio_cd end as atch_rate_frcst_lwr_prio_cd
,CASE WHEN t1.atch_rate_fnl_cd is NULL then 0 else t1.atch_rate_fnl_cd end as atch_rate_fnl_cd
from 
""" + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_all_rgn_dmnsn t1) A""")

    hybrid_it_tchnl_wk_prod_cust_fnl_joined_df.repartition(22).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + ".hybrid_it_tchnl_wk_prod_cust_fnl_joined_dmnsn")
    logger.info("Table hybrid_it_tchnl_wk_prod_cust_fnl_joined_dmnsn is refreshed")

    val hybrid_it_tchnl_wk_prod_cust_fnl_mnthly_df = spark.sql("""select 
prod_id
,cust_id
,keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr 
,sum(COALESCE(fnl_mtrl_frcst_qty_cd,0L)) as fnl_mtrl_frcst_qty_cd_mnthly
,sum(COALESCE(consensus_dmnd_pln_qty_cd,0L)) as consensus_dmnd_pln_qty_cd_mnthly
,sum(COALESCE(lnkd_srvr_h_cd,0L)) as lnkd_srvr_h_cd_mnthly
,sum(COALESCE(atch_rate_frcst_lwr_prio_cd,0L)) as atch_rate_frcst_lwr_prio_cd_mnthly
,sum(COALESCE(atch_rate_fnl_cd,0L)) as atch_rate_fnl_cd_mnthly
,NULL as consensus_dmnd_pln_qty_lag2_cd_mnthly
,NULL as consensus_dmnd_pln_qty_lag1_cd_mnthly
from 
""" + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_fnl_joined_dmnsn  t1
group by
prod_id
,cust_id
,keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr""")

    hybrid_it_tchnl_wk_prod_cust_fnl_mnthly_df.repartition(22).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + ".hybrid_it_tchnl_wk_prod_cust_fnl_mnthly_dmnsn")
    logger.info("Table hybrid_it_tchnl_wk_prod_cust_fnl_mnthly_dmnsn is refreshed")

    val hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_df = spark.sql("""select 
prod_id
,cust_id
,fiscal_yr
,qtr
,COALESCE(max(m1),0L) as Consensus_dmnd_pln_qty_cd_m1
,COALESCE(max(m2),0L) as Consensus_dmnd_pln_qty_cd_m2
,COALESCE(max(m3),0L) as Consensus_dmnd_pln_qty_cd_m3
,COALESCE(max(fnl_mtrl_frcst_qty_cd_m1),0L) as fnl_mtrl_frcst_qty_cd_m1
,COALESCE(max(fnl_mtrl_frcst_qty_cd_m2),0L) as fnl_mtrl_frcst_qty_cd_m2
,COALESCE(max(fnl_mtrl_frcst_qty_cd_m3),0L) as fnl_mtrl_frcst_qty_cd_m3
from
(select 
prod_id
,cust_id
,Keyfigure_mnth
,keyfigure_yr
,fiscal_yr
,qtr 
,CASE WHEN Keyfigure_mnth in ("11","2","5","8") then sum(a.group_map[Keyfigure_mnth]) END as m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9") then sum(a.group_map[Keyfigure_mnth]) END as m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10") then sum(a.group_map[Keyfigure_mnth]) END as m3
,CASE WHEN Keyfigure_mnth in ("11","2","5","8") then sum(a.group_map_fnl_mtrl_frcst_qty_cd[Keyfigure_mnth]) END as fnl_mtrl_frcst_qty_cd_m1
,CASE WHEN Keyfigure_mnth in ("12","3","6","9") then sum(a.group_map_fnl_mtrl_frcst_qty_cd[Keyfigure_mnth]) END as fnl_mtrl_frcst_qty_cd_m2
,CASE WHEN Keyfigure_mnth in ("1","4","7","10") then sum(a.group_map_fnl_mtrl_frcst_qty_cd[Keyfigure_mnth]) END as fnl_mtrl_frcst_qty_cd_m3
from
( 
select 
prod_id
,cust_id 
,Keyfigure_mnth
,Keyfigure_yr
,fiscal_yr
,qtr
,map(Keyfigure_mnth,Consensus_dmnd_pln_qty_cd_mnthly) as group_map 
,map(Keyfigure_mnth,fnl_mtrl_frcst_qty_cd_mnthly) as group_map_fnl_mtrl_frcst_qty_cd
from """ + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_fnl_mnthly_dmnsn) a 
group by
prod_id
,cust_id 
,Keyfigure_mnth
,Keyfigure_yr
,fiscal_yr
,qtr  ) a
group by
prod_id
,cust_id
,fiscal_yr
,qtr""")

    hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_df.repartition(22).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + ".hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_dmnsn")
    logger.info("Table hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_dmnsn is refreshed")

    val hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_joined_df = spark.sql("""select 
t1.prod_id
,t1.cust_id
,t1.Keyfigure_dt
,t1.keyfigure_mnth
,t1.Keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,coalesce(fnl_mtrl_frcst_qty_cd,0L) as fnl_mtrl_frcst_qty_cd
,coalesce(consensus_dmnd_pln_qty_cd,0L) as consensus_dmnd_pln_qty_cd
,coalesce(lnkd_srvr_h_cd,0L) as lnkd_srvr_h_cd
,coalesce(atch_rate_frcst_lwr_prio_cd,0L) as atch_rate_frcst_lwr_prio_cd
,coalesce(atch_rate_fnl_cd,0L) as atch_rate_fnl_cd
,NULL as consensus_dmnd_pln_qty_lag2_cd
,NULL as consensus_dmnd_pln_qty_lag1_cd
,coalesce(fnl_mtrl_frcst_qty_cd_mnthly,0L) as fnl_mtrl_frcst_qty_cd_mnthly
,coalesce(consensus_dmnd_pln_qty_cd_mnthly,0L) as consensus_dmnd_pln_qty_cd_mnthly
,coalesce(lnkd_srvr_h_cd_mnthly,0L) as lnkd_srvr_h_cd_mnthly
,coalesce(atch_rate_frcst_lwr_prio_cd_mnthly,0L) as atch_rate_frcst_lwr_prio_cd_mnthly
,coalesce(atch_rate_fnl_cd_mnthly,0L) as atch_rate_fnl_cd_mnthly
,NULL as consensus_dmnd_pln_qty_lag2_cd_mnthly
,NULL as consensus_dmnd_pln_qty_lag1_cd_mnthly
,coalesce(t3.Consensus_dmnd_pln_qty_cd_m1,0L) as Consensus_dmnd_pln_qty_cd_m1
,coalesce(t3.Consensus_dmnd_pln_qty_cd_m2,0L) as Consensus_dmnd_pln_qty_cd_m2
,coalesce(t3.Consensus_dmnd_pln_qty_cd_m3,0L) as Consensus_dmnd_pln_qty_cd_m3
,coalesce(t3.fnl_mtrl_frcst_qty_cd_m1,0L) as fnl_mtrl_frcst_qty_cd_m1
,coalesce(t3.fnl_mtrl_frcst_qty_cd_m2,0L) as fnl_mtrl_frcst_qty_cd_m2
,coalesce(t3.fnl_mtrl_frcst_qty_cd_m3,0L) as fnl_mtrl_frcst_qty_cd_m3
from
""" + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_fnl_joined_dmnsn t1
left join
""" + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_fnl_mnthly_dmnsn t2
on 
t1.prod_id=t2.prod_id
and
t1.cust_id=t2.cust_id
and 
t1.keyfigure_mnth=t2.keyfigure_mnth
and 
t1.keyfigure_yr=t2.keyfigure_yr
left join
""" + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_dmnsn t3
on
t1.prod_id=t3.prod_id
and
t1.cust_id=t3.cust_id
and 
t1.qtr=t3.qtr
and 
t1.fiscal_yr=t3.fiscal_yr""")

    hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_joined_df.repartition(22).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + ".hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_joined_dmnsn")
    logger.info("Table hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_joined_dmnsn is refreshed")

    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    //consumption name
    def deletePartitions(tbl_name: String = s"${dbNameConsmtn}.${consmptnTable}", snapshot_type: String) {
      // limits Daily as 1 day, weekly 6 months and monthly 1 year
      val limits = Map("daily" -> 1, "weekly" -> 182, "monthly" -> 365)

      // Function - Returns
      def daysAgo(days: Int): String = {
        val calender = Calendar.getInstance()
        calender.add(Calendar.DAY_OF_YEAR, -days)
        sdf.format(calender.getTime())
      }

      val all_partitions = spark.sql(s"show partitions ${tbl_name}").collect().map(_.getString(0))
      case class partitions(snpsht_typ: String, snpsht_dt: String)
      // List of objects partitions which will store all partition in table
      val partition_list = all_partitions.map(x => x.split("/").map(_.split("=")(1)).toList).map(x => partitions(x(0), x(1))).toList

      // Give last date before which all partitions need to be dropped
      val filter_date = daysAgo(limits(snapshot_type))
      val drop_partition_filter = partition_list.filter(x => x.snpsht_typ == snapshot_type.toUpperCase()).filter(x => x.snpsht_dt <= filter_date) // Filter and get older partitions
      val drop_partition_list = drop_partition_filter.map(_.snpsht_dt) // List of partitions to drop

      drop_partition_list.foreach(perPartition => {
        spark.sql(s"ALTER TABLE ${tbl_name} DROP PARTITION(snpsht_typ='${snapshot_type.toUpperCase()}',snpsht_dt='${perPartition}')")
        logger.info(s"PARTITION DROPPED with snapshot type = $snapshot_type, snapshot_date = $perPartition")
      })
      // MSCK repair throw exception if repair fails
      val tbl_repair_stts = try {
        spark.sql(s"msck repair table $tbl_name")
        logger.info("Table repair successful")
        true
      } catch {
        case e: Exception =>
          logger.info("Table repair failed. Terminating job: " + e.printStackTrace())
          false
      }

      if (!tbl_repair_stts) throw new Exception("Table repair failed.")

    }

    val bmt_monthly_snapshot = spark.sql("""select monthly_snapshot_dt from """ + dbNameConsmtn + """.bmt_hybrid_mthly_snpsht_dmnsn where monthly_snapshot_dt = current_date""")

    val snpsht_typ = if (bmt_monthly_snapshot.count().toInt != 0) {
      deletePartitions(snapshot_type = "weekly")
      deletePartitions(snapshot_type = "monthly")
      lit("MONTHLY")
    } else if (dowInt.format(now) == "7") {
      deletePartitions(snapshot_type = "weekly")
      deletePartitions(snapshot_type = "monthly")
      lit("WEEKLY")
    } else {
      deletePartitions(snapshot_type = "daily")
      deletePartitions(snapshot_type = "weekly")
      deletePartitions(snapshot_type = "monthly")
      lit("DAILY")
    }

    val column_list = spark.table(s"${dbNameConsmtn}.${consmptnTable}").columns

    val hybrid_prdt_cust_fact_df = spark.sql("""
select
CASE WHEN t1.prod_id is NULL then crc32(lower(trim(CONCAT(coalesce(t2.cust_id,""),coalesce(t2.prod_id,""))))) 
else crc32(lower(trim(CONCAT(coalesce(t1.cust_id,""),coalesce(t1.prod_id,""))))) end as hpe_cust_prod_ky

,COALESCE(t1.prod_id,t2.prod_id ) AS prod_id       
,COALESCE(t1.cust_id,t2.cust_id ) AS cust_id       
,COALESCE(date(t1.Keyfigure_dt),date(t2.Keyfigure_dt)) AS Keyfigure_dt
,COALESCE(t1.Keyfigure_mnth,t2.Keyfigure_mnth ) AS Keyfigure_mnth      
,COALESCE(t1.Keyfigure_yr,t2.Keyfigure_yr ) AS Keyfigure_yr      
,COALESCE(t1.fiscal_yr,t2.fiscal_yr ) AS fiscal_yr       
,COALESCE(t1.qtr,t2.qtr ) AS qtr       

,fnl_mtrl_frcst_qty_cd
,consensus_dmnd_pln_qty_cd
,lnkd_srvr_h_cd
,atch_rate_frcst_lwr_prio_cd
,atch_rate_fnl_cd
,consensus_dmnd_pln_qty_lag2_cd
,consensus_dmnd_pln_qty_lag1_cd
,fnl_mtrl_frcst_qty_cd_mnthly
,consensus_dmnd_pln_qty_cd_mnthly
,lnkd_srvr_h_cd_mnthly
,atch_rate_frcst_lwr_prio_cd_mnthly
,atch_rate_fnl_cd_mnthly
,consensus_dmnd_pln_qty_lag2_cd_mnthly
,consensus_dmnd_pln_qty_lag1_cd_mnthly
,COALESCE(t1.Consensus_dmnd_pln_qty_cd_m1,0) AS Consensus_dmnd_pln_qty_cd_m1  
,COALESCE(t1.Consensus_dmnd_pln_qty_cd_m2,0) AS Consensus_dmnd_pln_qty_cd_m2  
,COALESCE(t1.Consensus_dmnd_pln_qty_cd_m3,0) AS Consensus_dmnd_pln_qty_cd_m3  
,COALESCE(t2.totl_ord_actuals_rsd_cd,0) AS totl_ord_actuals_rsd_cd 
,COALESCE(t2.totl_ord_actuals_rsd_cd_mnthly,0) AS totl_ord_actuals_rsd_mnthly  
,COALESCE(t2.totl_ord_actuals_rsd_cd_m1,0) AS totl_ord_actuals_rsd_cd_m1  
,COALESCE(t2.totl_ord_actuals_rsd_cd_m2,0) AS totl_ord_actuals_rsd_cd_m2  
,COALESCE(t2.totl_ord_actuals_rsd_cd_m3,0) AS totl_ord_actuals_rsd_cd_m3 
,CASE WHEN t1.keyfigure_yr < year(current_timestamp) or  month(current_timestamp) in ("4","5","6") and t1.qtr in ("Q1") OR month(current_timestamp) in ("7","8","9") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("10","11","12") and t1.qtr in ("Q1","Q2","Q3") THEN COALESCE(totl_ord_actuals_rsd_cd_m1,0L)+COALESCE(totl_ord_actuals_rsd_cd_m2,0L)+COALESCE(totl_ord_actuals_rsd_cd_m3,0L)
WHEN t1.keyfigure_yr >= year(current_timestamp) or month(current_timestamp) in ("1","2","3") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("4","5","6") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("7","8","9") and t1.qtr in ("Q4") THEN  (COALESCE(Consensus_dmnd_pln_qty_cd_m1,0L)+COALESCE(Consensus_dmnd_pln_qty_cd_m2,0L)+COALESCE(Consensus_dmnd_pln_qty_cd_m3,0L))
WHEN  month(current_timestamp) in ("1") and  t1.keyfigure_mnth  in ("1","2","3") or month(current_timestamp) in ("4") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("7") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("10") and t1.keyfigure_mnth in ("10","11","12") THEN  (COALESCE(Consensus_dmnd_pln_qty_cd_m1,0L)+COALESCE(Consensus_dmnd_pln_qty_cd_m2,0L)+COALESCE(Consensus_dmnd_pln_qty_cd_m3,0L))
WHEN  month(current_timestamp) in ("2") and t1.keyfigure_mnth in ("1","2","3") or month(current_timestamp) in ("5") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("8") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("11") and t1.keyfigure_mnth in ("10","11","12") THEN  (COALESCE(totl_ord_actuals_rsd_cd_m1,0L)+COALESCE(Consensus_dmnd_pln_qty_cd_m2,0L)+COALESCE(Consensus_dmnd_pln_qty_cd_m3,0L))
WHEN  month(current_timestamp) in ("3") and t1.keyfigure_mnth in ("1","2","3") or month(current_timestamp) in ("6") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("9") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("12") and t1.keyfigure_mnth in ("10","11","12") THEN  (COALESCE(totl_ord_actuals_rsd_cd_m1,0L)+COALESCE(totl_ord_actuals_rsd_cd_m2,0L)+COALESCE(Consensus_dmnd_pln_qty_cd_m3,0L)) END as Consensus_dmnd_pln_qty
,CASE WHEN t1.keyfigure_yr < year(current_timestamp) or  month(current_timestamp) in ("4","5","6") and t1.qtr in ("Q1") OR month(current_timestamp) in ("7","8","9") and t1.qtr in ("Q1","Q2") OR month(current_timestamp) in ("10","11","12") and t1.qtr in ("Q1","Q2","Q3") THEN COALESCE(totl_ord_actuals_rsd_cd_m1,0L)+COALESCE(totl_ord_actuals_rsd_cd_m2,0L)+COALESCE(totl_ord_actuals_rsd_cd_m3,0L)
WHEN t1.keyfigure_yr >= year(current_timestamp) or month(current_timestamp) in ("1","2","3") and t1.qtr in ("Q2","Q3","Q4") or month(current_timestamp) in ("4","5","6") and t1.qtr in ("Q3","Q4") OR month(current_timestamp) in ("7","8","9") and t1.qtr in ("Q4") THEN  (COALESCE(fnl_mtrl_frcst_qty_cd_m1,0L)+COALESCE(fnl_mtrl_frcst_qty_cd_m2,0L)+COALESCE(fnl_mtrl_frcst_qty_cd_m3,0L))
WHEN  month(current_timestamp) in ("1") and  t1.keyfigure_mnth  in ("1","2","3") or month(current_timestamp) in ("4") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("7") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("10") and t1.keyfigure_mnth in ("10","11","12") THEN  (COALESCE(fnl_mtrl_frcst_qty_cd_m1,0L)+COALESCE(fnl_mtrl_frcst_qty_cd_m2,0L)+COALESCE(fnl_mtrl_frcst_qty_cd_m3,0L))
WHEN  month(current_timestamp) in ("2") and t1.keyfigure_mnth in ("1","2","3") or month(current_timestamp) in ("5") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("8") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("11") and t1.keyfigure_mnth in ("10","11","12") THEN  (COALESCE(totl_ord_actuals_rsd_cd_m1,0L)+COALESCE(fnl_mtrl_frcst_qty_cd_m2,0L)+COALESCE(fnl_mtrl_frcst_qty_cd_m3,0L))
WHEN  month(current_timestamp) in ("3") and t1.keyfigure_mnth in ("1","2","3") or month(current_timestamp) in ("6") and t1.keyfigure_mnth in ("4","5","6") or month(current_timestamp) in ("9") and t1.keyfigure_mnth in ("7","8","9") or month(current_timestamp) in ("12") and t1.keyfigure_mnth in ("10","11","12") THEN  (COALESCE(totl_ord_actuals_rsd_cd_m1,0L)+COALESCE(totl_ord_actuals_rsd_cd_m2,0L)+COALESCE(fnl_mtrl_frcst_qty_cd_m3,0L)) 
END as fnl_frcst_qty_cd_qtr
,CASE WHEN t1.keyfigure_mnth < month(current_timestamp) and t1.keyfigure_yr = year(current_timestamp) or t1.keyfigure_yr < year(current_timestamp) THEN COALESCE(t2.totl_ord_actuals_rsd_cd_mnthly,0L)
ELSE t1.fnl_mtrl_frcst_qty_cd_mnthly END as actl_fnl_frcst_qty_cd
,CASE WHEN t1.keyfigure_mnth < month(current_timestamp) and t1.keyfigure_yr = year(current_timestamp) or t1.keyfigure_yr < year(current_timestamp) THEN COALESCE(t2.totl_ord_actuals_rsd_cd_mnthly,0L)
ELSE t1.Consensus_dmnd_pln_qty_cd_mnthly END as actl_Consensus_dmnd_pln_qty_cd
,CASE WHEN t1.keyfigure_mnth < month(current_timestamp) and t1.keyfigure_yr = year(current_timestamp) or t1.keyfigure_yr < year(current_timestamp) THEN COALESCE(t2.totl_ord_actuals_rsd_cd_mnthly,0L)
ELSE t1.atch_rate_fnl_cd_mnthly END as actl_atch_rate_fnl_cd
,CASE WHEN t1.keyfigure_mnth < month(current_timestamp) and t1.keyfigure_yr = year(current_timestamp) or t1.keyfigure_yr < year(current_timestamp) THEN COALESCE(t2.totl_ord_actuals_rsd_cd_mnthly,0L)/COALESCE(t2.totl_ord_actuals_rsd_cd_mnthly,0L)
ELSE COALESCE(t2.totl_ord_actuals_rsd_cd_mnthly,0L)/COALESCE(t1.fnl_mtrl_frcst_qty_cd_mnthly,0L) END as ld_to_dp_prcnt
,(COALESCE(t2.totl_ord_actuals_rsd_cd,0L))/(COALESCE(t1.Consensus_dmnd_pln_qty_cd_m1,0L)+COALESCE(t1.Consensus_dmnd_pln_qty_cd_m2,0L)+COALESCE(t1.Consensus_dmnd_pln_qty_cd_m3,0L)) as ld_to_dp_POR_Quarterly_cd
,t1.Consensus_dmnd_pln_qty_cd/COALESCE(t2.totl_ord_actuals_rsd_cd,0L) as pln_accry_Consensus_dmnd_pln_qty_cd
,t1.fnl_mtrl_frcst_qty_cd/COALESCE(t2.totl_ord_actuals_rsd_cd,0L) as pln_accry_fnl_frcst_qty_cd
,t1.Consensus_dmnd_pln_qty_cd-COALESCE(t2.totl_ord_actuals_rsd_cd,0L) as Consensus_pln_to_go
,current_timestamp as ins_ts
,CURRENT_DATE as snpsht_dt
--,Case WHEN X.monthly_snapshot_dt is NOT NULL then "MONTHLY" when date_format(current_date, 'u') = "7" then "WEEKLY" else "DAILY" END AS snpsht_typ
from
""" + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_joined_dmnsn t1
left join
(select
t1.prod_id
,t1.cust_id
,t1.keyfigure_dt
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr
,sum(t1.totl_ord_actuals_rsd_cd) as totl_ord_actuals_rsd_cd
,sum(t1.totl_ord_actuals_rsd_cd_mnthly) as totl_ord_actuals_rsd_cd_mnthly
,sum(t1.totl_ord_actuals_rsd_cd_m1) as totl_ord_actuals_rsd_cd_m1
,sum(t1.totl_ord_actuals_rsd_cd_m2) as totl_ord_actuals_rsd_cd_m2
,sum(t1.totl_ord_actuals_rsd_cd_m3) as totl_ord_actuals_rsd_cd_m3
from
(select prod_id, cust_id, keyfigure_dt, keyfigure_mnth, keyfigure_yr, fiscal_yr, qtr, totl_ord_actuals_rsd_cd, totl_ord_actuals_rsd_cd_mnthly, totl_ord_actuals_rsd_cd_m1, totl_ord_actuals_rsd_cd_m2, totl_ord_actuals_rsd_cd_m3,snpsht_typ from """ + dbNameConsmtn + """.Hybrid_prdt_loc_cust_fact where snpsht_typ="DAILY") t1 
inner join  """ + dbNameConsmtn + """.hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_joined_dmnsn cust_fnl_dmnsn on 
cust_fnl_dmnsn.prod_id = t1.prod_id and cust_fnl_dmnsn.cust_id = t1.cust_id and cust_fnl_dmnsn.keyfigure_dt = t1.keyfigure_dt
group by
t1.prod_id
,t1.cust_id
,t1.keyfigure_dt
,t1.keyfigure_mnth
,t1.keyfigure_yr
,t1.fiscal_yr
,t1.qtr) t2
on t1.prod_id = t2.prod_id
and t1.cust_id = t2.cust_id
and t1.keyfigure_dt=t2.keyfigure_dt
  """).withColumn("snpsht_typ", snpsht_typ).selectExpr(column_list: _*)

    loadStatus = try {

      hybrid_prdt_cust_fact_df.repartition(30).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)
      src_count = spark.table(s"${dbNameConsmtn}.hybrid_it_tchnl_wk_prod_cust_all_rgn_dmnsn").count.toLong
      tgt_count = spark.table(s"${dbNameConsmtn}.hybrid_it_tchnl_wk_prod_cust_fnl_qtrly_joined_dmnsn").count.toLong
      true

    } catch {
      case e: Exception =>
        logger.info("ERROR: " + e.printStackTrace())
        false
    }

    logger.info(s"Table $consmptnTable is refreshed with status $loadStatus")

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case e: Exception => {
      logger.error("Generic Exception: " + e.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } finally {
    sqlCon.close()
    spark.close()
    // if (!runstatus) System.exit(1)
  }
}
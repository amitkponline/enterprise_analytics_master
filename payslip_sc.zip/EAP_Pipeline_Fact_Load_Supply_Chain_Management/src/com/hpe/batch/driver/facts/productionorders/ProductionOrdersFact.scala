package com.hpe.batch.driver.facts.productionorders
import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._


import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

object ProductionOrdersFact extends App{
  //**************************Driver properties******************************//

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj:AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  val dbName = propertiesObject.getDbName()
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  try {
      
   import spark.implicits._ 
   
   val maxtgttimestamp = "'"+spark.sql(f"""select coalesce(max(ins_gmt_ts),'1900-01-01 00:00:01.000') as po_max_timestamp from ${dbNameConsmtn}.${consmptnTable} """).collect().map(_.getString(0)).mkString("")+"'"
	 logger.info("*** Max ins_gmt_ts of fact table is : "+maxtgttimestamp)
	  
val ProdOrderFact = spark.sql(s"""select 
crc32(COALESCE(g.ord_id,"0")) as prdn_ord_ky,
a.wrk_cntr_id
,b.totl_prdn_cst_cd
,c.gds_rcvd_qty_cd
,d.obj_stts_cd
,d.stts_ind_cd
,e.actvy_Anticipated_strt_dt
,e.actl_oprn_strt_dt
,e.actvy_Anticipated_end_dt
,e.actl_oprn_end_dt
,e.plnd_oprn_qty_cd
,e.totl_cfrd_yld_qty_cd
,f.oprn_cmpltn_cfrn_nr
,g.ord_id
,g.ord_typ_cd
,g.plnt_cd
,g.sls_ord_id
,g.sls_ord_itm_nr
,g.ord_typ_cd
,g.src_sys_crt_dt
,h.plnd_ord_id
,h.mtrl_id
,h.plnd_totl_ord_qty_cd
,h.gds_rcvd_qty_cd
,i.cyc_dys_dt
,j.schdl_strt_dt
,j.actl_ord_strt_dt
,j.schdl_end_dt
,j.cfrd_ord_end_dt
,j.MRP_Controller_cd
,j.plnd_ord_rls_dt
,j.actl_ord_rls_dt
,k.mtrl_id
,k.ord_itm_qty_cd
,k.scrp_qty_cd
,k.prdn_scrp_fx_qty_cd
,k.valtn_typ_cd
,k.cmmtd_qty_cd
,l.blng_itm_nt_amt_cd
,l.blng_itm_nt_amt_cd
,l.plnd_dlvry_dys_dt
,m.bll_mtrl_itm_id
,m.mtrl_id
,m.rcvg_plnt_cd
,m.storg_lctn_cd
,m.storg_bn_id
,m.invy_mgmt_mvmt_typ_cd
,m.asmy_id
,m.rsrvtn_nr
,n.rsrc_obj_id
,j.intgtn_fbrc_msg_id
,j.src_sys_upd_ts
,j.src_sys_ky
,j.lgcl_dlt_ind
,j.ins_gmt_ts
,j.upd_gmt_ts
,j.src_sys_extrc_gmt_ts
,j.src_sys_btch_nr
,j.fl_nm
,j.ld_jb_nr
,j.ins_gmt_dt
from
${dbNameConsmtn}.prdn_ord_dmnsn j
left join ${dbNameConsmtn}.prdn_ord_itm_dmnsn k on j.prdn_ord_id = k.prdn_ord_id
left join ${dbNameConsmtn}.rsrvtn_rqmt_dmnsn m on j.rsrvtn_nr = m.rsrvtn_nr and k.rsrvtn_itm_nr = m.rsrvtn_itm_nr
left join ${dbNameConsmtn}.plnd_ord_dmnsn h on k.prdn_ord_id = h.plnd_ord_id
left join ${dbNameConsmtn}.mtrl_dcmt_sgm_dmnsn c on k.prdn_ord_id = c.ord_id and k.prdn_ord_itm_nr = c.mtrl_dcmt_itm_nr
left join ${dbNameConsmtn}.prch_rqstn_acct_asngmt_dmnsn o on j.prdn_ord_id = o.prch_rqstn_id 
left join ${dbNameConsmtn}.prch_ord_dtl_dmnsn l on l.prch_ord_id = o.prch_rqstn_itm_nr
left join ${dbNameConsmtn}.ord_mstr_dmnsn g on j.prdn_ord_id = g.ord_id
left join ${dbNameConsmtn}.capty_rqmt_hdr_dmnsn p on g.ord_id = p.obj_id
left join ${dbNameConsmtn}.capty_rqmt_dtl_dmnsn a on p.capty_rqmt_rec_nr = a.capty_rqmt_rec_nr
left join ${dbNameConsmtn}.inrn_pstg_cst_dmnsn b on g.ord_id = b.obj_id
left join ${dbNameConsmtn}.po_obj_stts_dmnsn d on g.ord_id = d.obj_id
left join ${dbNameConsmtn}.oprnl_lvl_frcst_dmnsn e on j.oprn_rteg_nr = e.oprn_rteg_nr and j.gnrl_ord_cnter_nr = e.inrn_cnter_nr
left join ${dbNameConsmtn}.ord_cfrn_dmnsn f on j.oprn_cmpltn_nr = f.oprn_cmpltn_cfrn_nr and j.gnrl_ord_cnter_nr = f.cfrn_cnter_nr and j.prdn_ord_id = f.ord_id
left join ${dbNameConsmtn}.ord_oprn_dmnsn q on j.oprn_rteg_nr = q.ord_oprn_nr and j.gnrl_ord_cnter_nr = q.ord_cnter_nr
left join ${dbNameConsmtn}.prdn_wrk_cntr_dmnsn n on q.rsrc_obj_id = n.rsrc_obj_id
left join ${dbNameConsmtn}.plng_capty_sgm_dmnsn r on n.rsrc_obj_id = r.plng_capty_sgm_id
left join ${dbNameConsmtn}.plng_capty_sgm_irvl_dmnsn i on r.plng_capty_sgm_id = i.plng_capty_sgm_id where j.ins_gmt_ts > $maxtgttimestamp""")


val ProdOrderFactTgtcount = ProdOrderFact.count().toInt
ProdOrderFact.createOrReplaceTempView("ProdOrderFact")

if(ProdOrderFactTgtcount > 0)
{

  val prod_ord_hist_data = spark.sql(f"""select * from ${dbNameConsmtn}.${consmptnTable}""") 
    val prdOrdHisDf = prod_ord_hist_data.as("old_data_df")
      .join(ProdOrderFact.as("inc"), $"old_data_df.prdn_ord_ky" === $"inc.prdn_ord_ky", "left_outer")
      .filter("inc.prdn_ord_ky is null")
      .select($"old_data_df.*")

    val prod_ord_fact_start_time = spark.sql(s"""select unix_timestamp()""").first.getLong(0)
    prdOrdHisDf.union(ProdOrderFact).write.mode("overwrite").insertInto(dbNameConsmtn + "." +consmptnTable )
    val prod_ord_fact_end_time = spark.sql(s"""select unix_timestamp()""").first.getLong(0)

    logger.info("prch_agrmnt__part_fact job: loaded in " + (prod_ord_fact_end_time - prod_ord_fact_start_time) / 60.0f + " mins!!")
    val loadStstus_ProdOrdFact = true;

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("cnsmpn_fact")
    auditObj.setAudApplicationName("job_EA_ProductionOrders_Factload")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStstus_ProdOrdFact) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(ProdOrderFactTgtcount)
    auditObj.setAudTgtRowCount(ProdOrderFactTgtcount)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

}
else 
{
     logger.error("No records to process !")
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
		auditObj.setAudDataLayerName("ref_cnsmptn")
		auditObj.setAudApplicationName("job_EA_ProductionOrders_Factload")
		auditObj.setAudObjectName(propertiesObject.getObjName())
		auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobStatusCode("success")
		auditObj.setAudSrcRowCount(0)
		auditObj.setAudTgtRowCount(0)
		auditObj.setAudErrorRecords(0)
		auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
		auditObj.setFlNm("")
		auditObj.setSysBtchNr(ld_jb_nr)
		auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
		auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
		Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl) 
  }
  
}
  
  catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
 finally {
    sqlCon.close()
    spark.close()
  }
  
}
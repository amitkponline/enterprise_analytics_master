package com.hpe.batch.driver.facts.deliveryshipment

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

import scala.collection.JavaConversions._
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel
import scala.collection.mutable
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import org.apache.spark.sql.expressions.Window

object ShipmentText extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj:AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath=propertiesFilePath.substring(0,propertiesFilePath.lastIndexOf("/")+1)+"sKey"
  val sk:SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath,sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var ld_jb_nr_ref = (ld_jb_nr + "_" + batchId)
  val sourceTable =propertiesObject.getSrcTblConsmtn()
  val targetTable =propertiesObject.getTgtTblConsmtn()
  var dbNameConsmtn: String = null
  var ref2: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    ref2 = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  var dbNameConsmtnmainref: String = null 
  var mainref: String = null
  if (propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtnmainref = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0)
     mainref = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(1)
     
     logger.info("main ref tabel name and schema name "+ dbNameConsmtnmainref + mainref)
     
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  
   try {    

  val shipmentMaxInsertTimestamp = "'"+spark.sql(f""" select coalesce(max(ins_gmt_ts),'1900-01-01 00:00:01') from $targetTable""").collect.map(row => row.getString(0)).mkString("")+"'" 
  
  
  //val transformeSrcdDF = spark.sql("""select * from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp)""")
  
  //val src_count = transformeSrcdDF.count().toInt
  
  logger.info("************* Inside if Table Write Status : loadStatus -->*********")
  
 
val keys_sm_ref="""     obj_nm,obj_i_1_id,appl_obj_cd,sys_lng_cd,cl_tg_cd,sm_txt
, intgtn_fbrc_msg_id , src_sys_upd_ts, src_sys_ky
                    ,  lgcl_dlt_ind, ins_gmt_ts, upd_gmt_ts, src_sys_extrc_gmt_ts, src_sys_btch_nr
                    ,  fl_nm ,'""" + ld_jb_nr_ref + """' as ld_jb_nr , to_date(ins_gmt_ts) as ins_gmt_dt"""

val hive_ref_select = spark.sql(f"""select $keys_sm_ref from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp) and obj_i_1_id is not null and obj_nm is not null """)

val query_hive_Ref_select = s"""select $keys_sm_ref from $sourceTable  where ins_gmt_dt >=to_date($shipmentMaxInsertTimestamp) and ins_gmt_ts> cast($shipmentMaxInsertTimestamp as timestamp) and  obj_i_1_id is not null and obj_nm is not null """

logger.info("*************** query_hive_Ref_select  ************ "  +  query_hive_Ref_select)

val finalDataset = hive_ref_select.filter(col("obj_nm").isNotNull and col("obj_i_1_id").isNotNull)

finalDataset.persist(StorageLevel.MEMORY_AND_DISK_SER)
val src_count = finalDataset.count
val tgt_count = src_count 

val numOfWritePartitions = if((shipmentMaxInsertTimestamp.contains("1900-"))) ((spark.conf.get("spark.sql.shuffle.partitions")).toInt)/5 else {((spark.conf.get("spark.sql.shuffle.partitions")).toInt)/30}

val loadStatus = Utilities.storeDataFrame(finalDataset, "Append", "ORC", targetTable,tgt_count,numOfWritePartitions) 

   //************************Completion Audit Entries*******************************//
    auditObj.setAudBatchId(ld_jb_nr_ref)
    auditObj.setAudDataLayerName("rw_ref")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
      logger.info("************* Inside if Table Write Status : loadStatus -->*********" + loadStatus)
    } else {
      auditObj.setAudJobStatusCode("failed")
      logger.info("************* Inside else Table Write Status : loadStatus -->*********" + loadStatus)
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}
package com.hpe.config

import java.util.HashMap

object Test {
  def main(args: Array[String]) {
    val nk = "opt_67_nm,234#obj_id,234#obj_id#obj_id#opt_68_nm,opt_69_nm"
    val surrKey = "abc,def,ghi,jkl,mno".trim
    val latestEntryKey = "asdf" //propertiesObject.getLatestEntryKey().trim
    val naturalKey = nk.trim()
    var keyCols = List[String]()
    if (naturalKey.contains("#")) {
      val tempkeyCols = nk.trim.split("#", -1)
      tempkeyCols.foreach {

        a =>
          println("each temp keys====" + a)
          if (a.contains(",")) {
            val tempList = a.split(",").toList
            keyCols = keyCols ::: tempList
          }

          keyCols = a :: keyCols

      }
    } else {

      keyCols = nk.trim.split(",", -1).toList
    }
    println(keyCols.distinct.mkString(",") + "  Size======" + keyCols.size)
    keyCols.foreach {
      a => println(a)
    }

    ///////////////////////////////////////////

    val surrKeyList = surrKey.split(",").toList
    val naturalKeyList = nk.split("#").toList
    val surrogatekeyMap: HashMap[String, String] = new HashMap[String, String]();
    for (i <- 0 to surrKeyList.length - 1) {
      surrogatekeyMap.put(surrKeyList(i), naturalKeyList(i))
    }
    var Nullkeyfilter = ""

    //colList = surrKeyList ::: refBatchIdListDf.columns.toList
    //     surrKeyList(0)::surrKeyList(1) :: refBatchIdListDf.columns.toList
    println("-------------->>>>>>>>Multiple Surrogate Key<<<<<<<<<<<<<<----------------" + surrKey)

    var multiplesurrKey = ""
    if (naturalKey.contains("#")) {
      println("################## Multiple Surrogate Key Multiple Natural Key Logic ##################")

      val tempsurrkey = surrKey.split(",", -1).toList
      tempsurrkey.foreach {
        a =>
          var tempNk = surrogatekeyMap.get(a)
          if (tempNk.contains(",")) {
            val temp = tempNk.split(",").toList
            temp.foldLeft("")(_ + "coalesce(" + _ + "\"\")")
            multiplesurrKey = multiplesurrKey + "crc32(lower(TRIM(COALESCE(concat(" + temp + ")))))" + " as " + a + ","

            println("################## tempsurrkey ##################" + temp)
          } else {
            multiplesurrKey = multiplesurrKey + "crc32(lower(TRIM(COALESCE(" + tempNk + ",\"\"))))" + " as " + a + ","
          }
      }
      multiplesurrKey = multiplesurrKey.dropRight(1)
      println("################## Multiple Surrogate Key Multiple Natural Key ##################" + multiplesurrKey)

    } else {
      surrKey.foreach { a =>
        multiplesurrKey = multiplesurrKey + "crc32(UPPER(TRIM(COALESCE(" + surrogatekeyMap.get(a) + ",\"\"))))" + " as " + a + ","
      }
      multiplesurrKey = multiplesurrKey.dropRight(1)
    }

    println("################## Multiple Surrogate Key ##################" + multiplesurrKey)

    keyCols.distinct.foreach { a =>
      println("list=====" + a.split(",", -1).toList + " size====" + a.split(",", -1).toList.size)
      if (a.split(",", -1).toList.size < 2) {
        Nullkeyfilter = Nullkeyfilter + a + " IS NOT NULL and "
      }
    }
    Nullkeyfilter = Nullkeyfilter.dropRight(4)

    println("################## Null Key Filter for Multiple Surrogate Key ##################" + Nullkeyfilter)

    //refBatchIdListDf.createOrReplaceTempView("ref_tbl_without_surr_ky")
    // val refLatestDfWithSurrKey = spark.sql(f"select *,${multiplesurrKey}  from ref_tbl_without_surr_ky where ${Nullkeyfilter}")

    //println("################## Count Without NULL ##################" + refLatestDfWithSurrKey.count())

    //refLatestDfWithSurrKey.createOrReplaceTempView("surr_ky_tbl")

    // val refLatestDF = spark.sql(
    //  f"""Select ${surrKey},MAX(COALESCE(${latestEntryKey})) as ${latestEntryKey}
    //                          from surr_ky_tbl group by ${surrKey}""")

    // println("################## Ref Latest DF Count for Multiple Surrogate Key  ##################" + refLatestDF.count())

    val srrKey_1 = latestEntryKey :: surrKeyList

    println("#############::::::::srrKey_1:::::::" + srrKey_1)

    //finalrefLatestDf = refLatestDfWithSurrKey.join(broadcast(refLatestDF), srrKey_1.toSeq)
    // .select(col("*")).dropDuplicates(srrKey_1.toSeq)
    //.select(colList.head, colList.tail: _*)
    /*
              .select(col("*"),struct(surrKey,latestEntryKey).as("tuple"))
              .drop(surrKey)
              .drop(latestEntryKey)
              .dropDuplicates("tuple")
              .select(col("*"),col(f"tuple.${surrKey}"),col(f"tuple.${latestEntryKey}"))
              .select(colList.head, colList.tail: _*)
      */
    // println("Record to validat------>" + finalrefLatestDf.show(2))

  }

}
package main.scala.com.hpe.utils

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.col

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject

object ArchiveAllPartitions extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val tgtTblRef = propertiesObject.getTgtTblRef().trim()
  val dbName = propertiesObject.getDbName().trim()
  val partitionWindow = propertiesObject.getRetainRecords().trim()
  val partitionColNm = propertiesObject.getFilterKey().trim()
  val sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

  try {

    var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
    var latestDistintPartitions = ""
    var dropPartitionQuery = ""
    var endTime = startTime
    var duration = "0"

    def prepareDropPartitionQuery(partitions: String, partititionCol: String, partitionTable: String): String = {
      var sql = ""
      val partitionsList = partitions.split(",").map(_.toString())
      partitionsList.foreach {
        x =>
          sql = sql + "PARTITION(" + partititionCol + "='" + x + "'), "
      }
      sql = "ALTER TABLE " + partitionTable + " DROP IF EXISTS " + sql.dropRight(2)
      return sql
    }

    val tgtTblList = tgtTblRef.split(',')

    for (tgtTbl <- tgtTblList) {
      val tblNm = dbName + "." + tgtTbl
      val tblArcNm = dbName + "." + tgtTbl + "_arc"
      val arcRefDf = spark.sql("select * from " + tblNm + " where " + partitionColNm + " <= DATE_SUB(to_date(current_timestamp)," + partitionWindow + ")")

      logger.info("select * from " + tblNm + " where " + partitionColNm + " <= DATE_SUB(to_date(current_timestamp)," + partitionWindow + ")")

      if (!arcRefDf.head(1).isEmpty) {
        val partitionList = arcRefDf.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0))
        val archiveDf = spark.sql("select * from " + tblArcNm).filter(col(partitionColNm) isin (partitionList: _*))

        logger.info(" select * from " + tblArcNm + " where " + partitionColNm + " in (partitionList)")

        if (!archiveDf.head(1).isEmpty) {
          val duplicatePartitions = archiveDf.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0)).toSeq.mkString(",")
          logger.error("Archival of " + tblNm + " failed as " + duplicatePartitions + " partition(s) are already archived")
          spark.close()
          System.exit(1)
        }
        arcRefDf.write.mode(SaveMode.Append).format("orc").insertInto(tblArcNm)

        logger.info("Older partitions inserted into " + tblArcNm)

        latestDistintPartitions = arcRefDf.select(col(partitionColNm)).distinct.collect.map(row => row.getDate(0)).toSeq.mkString(",")

        dropPartitionQuery = prepareDropPartitionQuery(latestDistintPartitions, partitionColNm, tblNm)

        logger.info(" Archiving Query:::::::::::::" + dropPartitionQuery)

        spark.sql(dropPartitionQuery)
        spark.sql("MSCK REPAIR TABLE " + tblNm)        
        spark.sql("MSCK REPAIR TABLE " + tblArcNm)

        logger.info("Partitions dropped from " + tblNm)

        endTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss")
        duration = (((sdf.parse(endTime).getTime - sdf.parse(startTime).getTime).toString()).toInt / 1000).toString()

        logger.info("Archiving of " + tblNm + " for " + partitionWindow + " days took " + duration + " seconds")

      } else {
        logger.warn("No new partitions found to be archived in table!")
      }
    }
  } catch {
    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      spark.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      spark.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      spark.close()
      System.exit(1)
    }
    case exception: Exception => {
      logger.error(exception.printStackTrace())
      spark.close()
      System.exit(1)
    }
  } finally {
    spark.close()
  }
}
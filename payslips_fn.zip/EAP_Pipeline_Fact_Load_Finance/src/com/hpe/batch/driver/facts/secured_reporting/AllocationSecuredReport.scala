package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source

object AllocationSecuredReport extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }

  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  try {
    logger.info("Initializing log for SECURED REPORT ALLOCATIONS FACT, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)

    val consmptnTable = new StringBuilder()
    var dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    //Initiating queries to load the tables for Secured Report Allocations
    //val execQueries = Source.fromFile(fileBasePath).getLines.mkString("\n").split(";")
    var dbName = propertiesObject.getDbName().split(",")(0).trim
    var dbNameITG = propertiesObject.getDbName().split(",")(1).trim

    val srcCount = spark.sql("select count(*) from " + srcTable).first().getLong(0)
    var tgtCount: Long = 0

    val secrdDF = spark.sql(s"""
select
COALESCE(fscl_yr_prd_cd,'?') as fscl_yr_prd_cd,
sg_level_3 as sgm_lvl_3,
pch_level_3 as pch_lvl_3,
ctry_nm,
cust_sgm_nm,
ttl_rvn_amt as ttl_rvn_amt,
ttl_rvn_usd_amt as ttl_rvn_usd_amt,
cp_nt_rvn_usd_amt as nt_rvn_amt_usd,
entrprs_stndrd_cst_grp_curr_usd_amt as entrprs_stndrd_cst_grp_curr_usd_amt,
ttl_cst_sls_amt as ttl_cst_sls_amt,
fctry_mrgn_amt as fctry_mrgn_amt,
grs_mrgn_amt as grs_mrgn_amt,
ord_itm_qty,
rar_qty as rvn_dlta_qty,
nt_prc_usd_amt as nt_prc_usd_amt,
src_sys_cd as src_sys_cd,
ord_crt_dt as ord_crt_dt,
cp_rtm_nm as cp_rtm_nm,
ord_typ_cd as ord_typ_cd,
mtrl_nr as mtrl_nr, 
cp_sldt_prty_id as cp_sldt_prty_id,
cp_shpt_prty_id as cp_shpt_prty_id,
bll_to_cd as bll_to_cd,
cp_end_cust_prty_id as cp_end_cust_prty_id,
pch_level_4 as pch_lvl_4,
bmt_pft_cntr_alt_hrchy_dmnsn.pc_map_5 as pch_lvl_5, -- updated on 4/30, old mapping pch_level_5 as pch_lvl_5,
pch_level_6 as pch_lvl_6,
pch_level_7 as pch_lvl_7,
pch_level_8 as pch_lvl_8,
sg_level_5 as sgm_lvl_5,
sg_level_6 as sgm_lvl_6,
sg_level_7 as sgm_lvl_7,
sg_level_8 as sgm_lvl_8,
fscl_yr_nr as fscl_yr_nr,
fscl_qtr_nr as fscl_qtr_nr,
fscl_prd_nr as fscl_prd_nr,
cp_rev_recgn_cgy_cd as cp_rev_recgn_cgy_cd,
cp_rev_hdr_nm as cp_rev_hdr_nm,
cp_incd_excld,
sgmtl_rptg_cd,
cp_nt_rvn_usd_amt as cp_nt_rvn_usd_amt,
cp_net_inv_usd_amt as  cp_net_inv_usd_amt,
cp_grs_inv_usd_amt as cp_grs_inv_usd_amt,
cp_nt_rvn_amt as  cp_nt_rvn_amt,
prty.prty_nm as cp_end_cust_prty_nm,
cp_prft_ctr_cd,
cp_ndp_usd_amt as cp_ndp_usd_amt,
cp_grs_usd_amt as cp_grs_usd_amt,
cp_entprs_std_cst_usd_amt as  cp_entprs_std_cst_usd_amt,
cp_tot_cst_of_sls_usd_amt as cp_tot_cst_of_sls_usd_amt,
prft_cntr_cd,
shp_to_cd,
sld_to_cd,
prmry_prcg_cndn_cd, -- added in Lr1
end_cust_cd, -- added in Lr1
cp_entrprs_stndrd_cst, -- added in Lr1
entprs_std_cst_usd_amt, -- added in Lr1
entrprs_stndrd_cst -- added in Lr1
from ${srcTable}
left outer join ${dbNameITG}.segment_std_hrchy segment_std_hrchy on secrd_rpt_fact.cp_sgmtl_cd = segment_std_hrchy.sg_level_8
left outer join ${dbName}.pft_cntr_std_hrchy on secrd_rpt_fact.prft_cntr_cd = pft_cntr_std_hrchy.pch_level_8
left outer join ${dbName}.prty_fact prty on secrd_rpt_fact.cp_end_cust_prty_id = prty.mdm_id
left outer join ${dbName}.doc_typ_dmnsn doc_typ_dmnsn on secrd_rpt_fact.ord_typ_cd = doc_typ_dmnsn.sls_dcmt_typ_cd
left outer join ${dbName}.bmt_pft_cntr_alt_hrchy_dmnsn on secrd_rpt_fact.prft_cntr_cd = bmt_pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd -- added 4/30
where
src_sys_cd not in ('OPPORTUNITY','QUOTES','SFDC_UNBOOKED_ORDERS','DEALS','PC_OFFSET','PC_ADJ')
""").distinct

    secrdDF.createOrReplaceTempView("secrd_rpt_fact")

    val secrdFactSumDF = spark.sql(s"""
select
fscl_yr_prd_cd,
sgm_lvl_3,
max(pch_lvl_3)as pch_lvl_3,
ctry_nm,
cust_sgm_nm,
sum(ttl_rvn_amt) as ttl_rvn_amt,
sum(ttl_rvn_usd_amt) as ttl_rvn_usd_amt,
sum(cp_nt_rvn_usd_amt) as nt_rvn_amt_usd,
sum(entrprs_stndrd_cst_grp_curr_usd_amt) as entrprs_stndrd_cst_grp_curr_usd_amt,
sum(ttl_cst_sls_amt) as ttl_cst_sls_amt,
sum(fctry_mrgn_amt) as fctry_mrgn_amt,
sum(grs_mrgn_amt) as grs_mrgn_amt,
sum(ord_itm_qty) as ord_itm_qty_cd,
sum(rvn_dlta_qty) as rvn_dlta_qty,
max(nt_prc_usd_amt) as nt_prc_usd_amt,
max(src_sys_cd)as src_sys_cd,
max(ord_crt_dt)as ord_crt_dt,
max(cp_rtm_nm) as cp_rtm_nm,
max(ord_typ_cd) as ord_typ_cd,
max(mtrl_nr) as mtrl_nr, 
max(cp_sldt_prty_id) as cp_sldt_prty_id,
max(cp_shpt_prty_id) as cp_shpt_prty_id,
max(bll_to_cd) as bll_to_cd,
max(cp_end_cust_prty_id) as cp_end_cust_prty_id,
max(pch_lvl_4) as pch_lvl_4,
pch_lvl_5 as pch_lvl_5,
max(pch_lvl_6) as pch_lvl_6,
max(pch_lvl_7) as pch_lvl_7,
max(pch_lvl_8) as pch_lvl_8,
max(sgm_lvl_5) as sgm_lvl_5,
max(sgm_lvl_6) as sgm_lvl_6,
max(sgm_lvl_7) as sgm_lvl_7,
max(sgm_lvl_8) as sgm_lvl_8,
max(fscl_yr_nr) as fscl_yr_nr,
max(fscl_qtr_nr) as fscl_qtr_nr,
max(fscl_prd_nr) as fscl_prd_nr,
max(cp_rev_recgn_cgy_cd) as cp_rev_recgn_cgy_cd,
max(cp_rev_hdr_nm) as cp_rev_hdr_nm,
max(cp_incd_excld) as incd_excld_cd,
sgmtl_rptg_cd,
sum(cp_nt_rvn_usd_amt) as cp_nt_rvn_usd_amt,
sum(cp_net_inv_usd_amt) as  cp_net_inv_usd_amt,
sum(cp_grs_inv_usd_amt) as cp_grs_inv_usd_amt,
sum(cp_nt_rvn_amt) as  cp_nt_rvn_amt,
cp_end_cust_prty_nm,
cp_prft_ctr_cd,
sum(cp_ndp_usd_amt) as cp_ndp_usd_amt,
sum(cp_grs_usd_amt) as cp_grs_usd_amt,
sum(cp_entprs_std_cst_usd_amt) as  cp_entprs_std_cst_usd_amt,
sum(cp_tot_cst_of_sls_usd_amt) as cp_tot_cst_of_sls_usd_amt,
prft_cntr_cd,
shp_to_cd, 
sld_to_cd,
prmry_prcg_cndn_cd, -- added in Lr1
end_cust_cd, -- added in Lr1
sum(cp_entrprs_stndrd_cst) as cp_entrprs_stndrd_cst, -- added in Lr1
sum(entprs_std_cst_usd_amt) as entprs_std_cst_usd_amt, -- added in Lr1
sum(entrprs_stndrd_cst) as entrprs_stndrd_cst -- added in Lr1
from secrd_rpt_fact group by 
fscl_yr_prd_cd,
sgm_lvl_3,
pch_lvl_5,
ctry_nm,
cust_sgm_nm,
sgmtl_rptg_cd,
cp_end_cust_prty_nm,
cp_prft_ctr_cd,
prft_cntr_cd,
shp_to_cd,
sld_to_cd,
prmry_prcg_cndn_cd,
end_cust_cd
""")

    secrdFactSumDF.repartition(25).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + ".secrd_rpt_fact_sum")
    logger.info("+++++++++########### secrd_rpt_fact_sum table loaded ###########+++++++++")

    val geoAllctnDf = spark.sql(s"""
      select
secrd_rpt_fact_sum.fscl_yr_prd_cd,
secrd_rpt_fact_sum.sgm_lvl_3,
secrd_rpt_fact_sum.pch_lvl_3,
secrd_rpt_fact_sum.ctry_nm,
secrd_rpt_fact_sum.cust_sgm_nm,
secrd_rpt_fact_sum.ttl_rvn_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_ttl_rvn_usd_amt,
secrd_rpt_fact_sum.ttl_rvn_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_ttl_rvn_amt,
secrd_rpt_fact_sum.nt_rvn_amt_usd*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_nt_rvn_amt_usd,
secrd_rpt_fact_sum.entrprs_stndrd_cst_grp_curr_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_entrprs_stndrd_cst_grp_curr_usd_amt,
secrd_rpt_fact_sum.ttl_cst_sls_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_ttl_cst_sls_amt,
secrd_rpt_fact_sum.fctry_mrgn_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_fctry_mrgn_amt,
secrd_rpt_fact_sum.grs_mrgn_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_grs_mrgn_amt,
secrd_rpt_fact_sum.ord_itm_qty_cd*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_ord_itm_qty_cd,
secrd_rpt_fact_sum.rvn_dlta_qty*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_rvn_dlta_qty,
secrd_rpt_fact_sum.nt_prc_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as geo_nt_prc_usd_amt,
secrd_rpt_fact_sum.src_sys_cd,
secrd_rpt_fact_sum.ord_crt_dt,
secrd_rpt_fact_sum.cp_rtm_nm,
secrd_rpt_fact_sum.ord_typ_cd,
secrd_rpt_fact_sum.mtrl_nr,
secrd_rpt_fact_sum.cp_sldt_prty_id,
secrd_rpt_fact_sum.cp_shpt_prty_id,
secrd_rpt_fact_sum.bll_to_cd,
secrd_rpt_fact_sum.cp_end_cust_prty_id,
secrd_rpt_fact_sum.pch_lvl_4,
secrd_rpt_fact_sum.pch_lvl_5,
secrd_rpt_fact_sum.pch_lvl_6,
secrd_rpt_fact_sum.pch_lvl_7,
secrd_rpt_fact_sum.pch_lvl_8,
secrd_rpt_fact_sum.sgm_lvl_5,
secrd_rpt_fact_sum.sgm_lvl_6,
secrd_rpt_fact_sum.sgm_lvl_7,
secrd_rpt_fact_sum.sgm_lvl_8,
secrd_rpt_fact_sum.fscl_yr_nr,
secrd_rpt_fact_sum.fscl_qtr_nr,
secrd_rpt_fact_sum.fscl_prd_nr,
secrd_rpt_fact_sum.cp_rev_recgn_cgy_cd,
secrd_rpt_fact_sum.cp_rev_hdr_nm,
secrd_rpt_fact_sum.incd_excld_cd,
secrd_rpt_fact_sum.sgmtl_rptg_cd,
allctn_cust_geo_dmnsn.fscl_yr_mt_cd as geo_fscl_yr_mt_cd,
--allctn_cust_geo_dmnsn.sgm_cd as geo_sgm_cd,
--allctn_cust_geo_dmnsn.sgm_lvl_4 as geo_sgm_lvl_4,
--allctn_cust_geo_dmnsn.pft_cntr_cd as geo_pft_cntr_cd,
allctn_cust_geo_dmnsn.pft_cntr_cgy_lvl_5_cd as geo_pft_cntr_cgy_lvl_5_cd,
allctn_cust_geo_dmnsn.ctry_nm as geo_ctry_nm,
CASE WHEN allctn_cust_geo_dmnsn.ctry_geo_allct_nm IS NULL THEN secrd_rpt_fact_sum.ctry_nm ELSE allctn_cust_geo_dmnsn.ctry_geo_allct_nm END as geo_ctry_geo_allct_nm,
allctn_cust_geo_dmnsn.allctn_rate as geo_allctn_rate,
allctn_cust_geo_dmnsn.dlt_ind as geo_dlt_ind,
allctn_cust_geo_dmnsn.geo_rg_cd as geo_geo_rg_cd,
secrd_rpt_fact_sum.cp_nt_rvn_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as cp_nt_rvn_usd_amt,
secrd_rpt_fact_sum.cp_net_inv_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as cp_net_inv_usd_amt,
secrd_rpt_fact_sum.cp_grs_inv_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as cp_grs_inv_usd_amt,
secrd_rpt_fact_sum.cp_nt_rvn_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as cp_nt_rvn_amt,
secrd_rpt_fact_sum.cp_end_cust_prty_nm,
secrd_rpt_fact_sum.cp_prft_ctr_cd,
secrd_rpt_fact_sum.cp_ndp_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as cp_ndp_usd_amt,
secrd_rpt_fact_sum.cp_grs_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as cp_grs_usd_amt,
secrd_rpt_fact_sum.cp_entprs_std_cst_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as cp_entprs_std_cst_usd_amt,
secrd_rpt_fact_sum.cp_tot_cst_of_sls_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as cp_tot_cst_of_sls_usd_amt,
secrd_rpt_fact_sum.prft_cntr_cd,
secrd_rpt_fact_sum.shp_to_cd,
secrd_rpt_fact_sum.sld_to_cd,
secrd_rpt_fact_sum.prmry_prcg_cndn_cd, -- added in Lr1
secrd_rpt_fact_sum.end_cust_cd, -- added in Lr1
secrd_rpt_fact_sum.cp_entrprs_stndrd_cst*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as cp_entrprs_stndrd_cst, -- added in Lr1
secrd_rpt_fact_sum.entprs_std_cst_usd_amt*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as entprs_std_cst_usd_amt, -- added in Lr1
secrd_rpt_fact_sum.entrprs_stndrd_cst*coalesce(allctn_cust_geo_dmnsn.allctn_rate,1) as entrprs_stndrd_cst -- added in Lr1
from ${dbNameConsmtn}.secrd_rpt_fact_sum secrd_rpt_fact_sum 
left outer join ${dbName}.bmt_allctn_cust_geo_dmnsn allctn_cust_geo_dmnsn on
secrd_rpt_fact_sum.fscl_yr_prd_cd= allctn_cust_geo_dmnsn.fscl_yr_mt_cd
and secrd_rpt_fact_sum.pch_lvl_5 = allctn_cust_geo_dmnsn.pft_cntr_cgy_lvl_5_cd
and trim(secrd_rpt_fact_sum.ctry_nm) = trim(allctn_cust_geo_dmnsn.ctry_nm)
""")

    geoAllctnDf.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + ".secrd_rpt_geo_allctn")
    logger.info("+++++++++########### secrd_rpt_geo_allctn table loaded ###########+++++++++")

    val allctnDF = spark.sql(s"""
      select
secrd_rpt_geo_allctn.fscl_yr_prd_cd,
secrd_rpt_geo_allctn.sgm_lvl_3,
secrd_rpt_geo_allctn.pch_lvl_3,
secrd_rpt_geo_allctn.ctry_nm,
secrd_rpt_geo_allctn.cust_sgm_nm,
secrd_rpt_geo_allctn.geo_ttl_rvn_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as ttl_rvn_usd_amt,
secrd_rpt_geo_allctn.geo_ttl_rvn_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as ttl_rvn_amt,
--secrd_rpt_geo_allctn.geo_nt_rvn_amt_usd*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as nt_rvn_amt_usd,
secrd_rpt_geo_allctn.geo_entrprs_stndrd_cst_grp_curr_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1)  as entrprs_stndrd_cst_grp_curr_usd_amt,
secrd_rpt_geo_allctn.geo_ttl_cst_sls_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as ttl_cst_sls_amt,
secrd_rpt_geo_allctn.geo_fctry_mrgn_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as fctry_mrgn_amt,
secrd_rpt_geo_allctn.geo_grs_mrgn_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as grs_mrgn_amt,
secrd_rpt_geo_allctn.geo_ord_itm_qty_cd*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as ord_itm_qty_cd,
secrd_rpt_geo_allctn.geo_rvn_dlta_qty*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as rvn_dlta_qty,
secrd_rpt_geo_allctn.geo_nt_prc_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as nt_prc_usd_amt,
secrd_rpt_geo_allctn.src_sys_cd,
secrd_rpt_geo_allctn.ord_crt_dt,
secrd_rpt_geo_allctn.cp_rtm_nm,
secrd_rpt_geo_allctn.ord_typ_cd,
secrd_rpt_geo_allctn.mtrl_nr,
secrd_rpt_geo_allctn.cp_sldt_prty_id,
secrd_rpt_geo_allctn.cp_shpt_prty_id,
secrd_rpt_geo_allctn.bll_to_cd,
secrd_rpt_geo_allctn.cp_end_cust_prty_id,
secrd_rpt_geo_allctn.pch_lvl_4,
secrd_rpt_geo_allctn.pch_lvl_5,
secrd_rpt_geo_allctn.pch_lvl_6,
secrd_rpt_geo_allctn.pch_lvl_7,
secrd_rpt_geo_allctn.pch_lvl_8,
secrd_rpt_geo_allctn.sgm_lvl_5,
secrd_rpt_geo_allctn.sgm_lvl_6,
secrd_rpt_geo_allctn.sgm_lvl_7,
secrd_rpt_geo_allctn.sgm_lvl_8,
secrd_rpt_geo_allctn.fscl_yr_nr,
secrd_rpt_geo_allctn.fscl_qtr_nr,
secrd_rpt_geo_allctn.fscl_prd_nr,
secrd_rpt_geo_allctn.cp_rev_recgn_cgy_cd,
secrd_rpt_geo_allctn.cp_rev_hdr_nm,
secrd_rpt_geo_allctn.incd_excld_cd,
secrd_rpt_geo_allctn.sgmtl_rptg_cd,
--secrd_rpt_geo_allctn.geo_fscl_yr_mt_cd,
--secrd_rpt_geo_allctn.geo_sgm_cd,
--secrd_rpt_geo_allctn.geo_sgm_lvl_4,
--secrd_rpt_geo_allctn.geo_pft_cntr_cd,
secrd_rpt_geo_allctn.geo_pft_cntr_cgy_lvl_5_cd,
--secrd_rpt_geo_allctn.geo_ctry_nm,
secrd_rpt_geo_allctn.geo_ctry_geo_allct_nm,
secrd_rpt_geo_allctn.geo_allctn_rate,
--secrd_rpt_geo_allctn.geo_dlt_ind,
--secrd_rpt_geo_allctn.geo_geo_rg_cd,
--allctn_cust_seg_dmnsn.fscl_yr_mt_cd as seg_fscl_yr_mt_cd,
--allctn_cust_seg_dmnsn.sgm_cd as seg_sgm_cd,
--allctn_cust_seg_dmnsn.sgm_lvl_4 as seg_sgm_lvl_4,
--allctn_cust_seg_dmnsn.pft_cntr_cd as seg_pft_cntr_cd,
allctn_cust_seg_dmnsn.pft_cntr_cgy_lvl_5_cd as seg_pft_cntr_cgy_lvl_5_cd,
allctn_cust_seg_dmnsn.ctry_geo_allct_nm as seg_ctry_geo_allct_nm,
--allctn_cust_seg_dmnsn.cust_sgm_nm as seg_cust_sgm_nm,
coalesce(allctn_cust_seg_dmnsn.cust_sgm_allctn_nm, secrd_rpt_geo_allctn.cust_sgm_nm) as seg_cust_sgm_allctn_nm,
allctn_cust_seg_dmnsn.allctn_rate as seg_allctn_rate,
--allctn_cust_seg_dmnsn.dlt_ind as seg_dlt_ind,
--allctn_cust_seg_dmnsn.rg_cd as seg_rg_cd,
secrd_rpt_geo_allctn.cp_nt_rvn_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as cp_nt_rvn_usd_amt,
secrd_rpt_geo_allctn.cp_net_inv_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as cp_net_inv_usd_amt,
secrd_rpt_geo_allctn.cp_grs_inv_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as cp_grs_inv_usd_amt,
secrd_rpt_geo_allctn.cp_nt_rvn_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as cp_nt_rvn_amt,
secrd_rpt_geo_allctn.cp_end_cust_prty_nm,
secrd_rpt_geo_allctn.cp_prft_ctr_cd,
secrd_rpt_geo_allctn.cp_ndp_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as cp_ndp_usd_amt,
secrd_rpt_geo_allctn.cp_grs_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as cp_grs_usd_amt,
secrd_rpt_geo_allctn.cp_entprs_std_cst_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as cp_entprs_std_cst_usd_amt,
secrd_rpt_geo_allctn.cp_tot_cst_of_sls_usd_amt*coalesce(allctn_cust_seg_dmnsn.allctn_rate,1) as cp_tot_cst_of_sls_usd_amt,
secrd_rpt_geo_allctn.prft_cntr_cd,
secrd_rpt_geo_allctn.shp_to_cd,
secrd_rpt_geo_allctn.sld_to_cd,
secrd_rpt_geo_allctn.prmry_prcg_cndn_cd, -- added in Lr1
secrd_rpt_geo_allctn.end_cust_cd, -- added in Lr1
secrd_rpt_geo_allctn.cp_entrprs_stndrd_cst, -- added in Lr1
secrd_rpt_geo_allctn.entprs_std_cst_usd_amt, -- added in Lr1
secrd_rpt_geo_allctn.entrprs_stndrd_cst -- added in Lr1
from ${dbNameConsmtn}.secrd_rpt_geo_allctn secrd_rpt_geo_allctn
left outer join ${dbName}.bmt_allctn_cust_seg_dmnsn allctn_cust_seg_dmnsn on
secrd_rpt_geo_allctn.fscl_yr_prd_cd = allctn_cust_seg_dmnsn.fscl_yr_mt_cd and
secrd_rpt_geo_allctn.pch_lvl_5= allctn_cust_seg_dmnsn.pft_cntr_cgy_lvl_5_cd and
trim(secrd_rpt_geo_allctn.geo_ctry_geo_allct_nm)=trim(allctn_cust_seg_dmnsn.ctry_geo_allct_nm) and
trim(secrd_rpt_geo_allctn.cust_sgm_nm)=trim(allctn_cust_seg_dmnsn.cust_sgm_nm)
      """)

    val tgtCol = spark.sql(s"select * from ${dbNameConsmtn}.secrd_rpt_allctn").columns

    val dataLoadAllctn = allctnDF.select(Utilities.loadSelectExpr(allctnDF.columns, tgtCol): _*)

    dataLoadAllctn.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + ".secrd_rpt_allctn")

    logger.info("+++++++++########### secrd_rpt_allctn table loaded ###########+++++++++")

    val allctnSnpshtFact = spark.sql(s"""
      select *,
      CURRENT_TIMESTAMP as snpsht_ins_ts,
      CASE WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('12:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('08:00 AM',"hh:mm a") THEN 1 
      WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('08:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('04:00 PM',"hh:mm a") THEN 2 
      ELSE 3 END as snpsht_nr 
      from ${dbNameConsmtn}.secrd_rpt_allctn
      """)

    val tgtColSnpsht = spark.sql(s"select * from ${dbNameConsmtn}.secrd_rpt_allctn_snpsht_fact").columns

    val dataLoadAllctnSnpsht = allctnSnpshtFact.select(Utilities.loadSelectExpr(allctnSnpshtFact.columns, tgtColSnpsht): _*)

    dataLoadAllctnSnpsht.repartition(10).write.mode("append").format("orc").insertInto(dbNameConsmtn + ".secrd_rpt_allctn_snpsht_fact")
    logger.info("+++++++++########### secrd_rpt_allctn_snpsht_fact table loaded ###########+++++++++")

    tgtCount = spark.sql("select count(*) from " + dbNameConsmtn + "." + consmptnTable).first().getLong(0)

    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (tgtCount > 0) {
      auditObj.setAudJobStatusCode("success")
      logger.info("Load Successful")
    } else {
      auditObj.setAudJobStatusCode("failed")
      logger.info("Load Failed")
    }
    auditObj.setAudSrcRowCount(srcCount)
    auditObj.setAudTgtRowCount(tgtCount)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    sqlCon.close()
    spark.close()
  }
}

package com.hpe.batch.driver.facts.rar_pivoting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object RvnRcgnDeffItemTranspose extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")

  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
  }

  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("RvnRcgnDeffitemTranspose")
  auditObj.setAudObjectName(propertiesObject.getObjName())
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)

  try {

    /*
     * getLatestRecs to get the latest records
     * @Param df: Data frame on which operations needs to be performed
     * @Param partition_col: List of columns required to create partition
     * @Param sortCols: column name to get the latest record for each partition
     */

    def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
      val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*))
      val rowDF = df.withColumn("rn", row_number().over(part))
      val res = rowDF.filter("rn==1").drop("rn")
      res
    }

    logger.info("Initializing log for RAR POSTING TRANSPOSE, object_id : " + propertiesObject.getObjName())
    var dbNameConsmtn: String = null
    var consmptnTable: String = null
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {

      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)

    } else {

      logger.error("Please update tgtTblConsmtn properties to add database name!")

    }

    val dbNameITG = propertiesObject.getDbName().split(",")(0).trim
    val dbNameUAT = propertiesObject.getDbName().split(",")(1).trim

    val src_count = spark.sql(s"select * from ${dbNameConsmtn}.rvn_rcgn_dfrd_itm_dmnsn").count.toInt
    
    //Initiating queries to load the tables for Secured Report Allocations
    var dfrdTrsnDF = spark.sql(s"""
      select *
      from 
        ${dbNameConsmtn}.rvn_rcgn_dfrd_itm_dmnsn 
      where 
        etry_ltst_ind='X'    
        and (ststcs_us_cndn_ind <>'X' or ststcs_us_cndn_ind is null)
        -- and src_acct_nr like '003%'
        and rvn_dlta_amt<> 0
      """)
    
    val fahselectDF = spark.sql(s"select * from ${dbNameITG}.fnctl_ar_std_hrchy")

    val glselectDF = spark.sql(s"select distinct gnrl_ldgr_acct_nr,funtional_ar_cd from ${dbNameUAT}.gnrl_ldgr_acct_dmnsn")

    dfrdTrsnDF = getLatestRecs(dfrdTrsnDF, List("rvn_rcncltn_ky", "prfm_obgn_id", "rvn_rcgn_cntrct_id", "src_acct_nr"), List("ins_gmt_ts"))

    var dfrdTrsnDF_net_revenue = dfrdTrsnDF.as("a").join(glselectDF.as("c"), col("a.src_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").select(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("rvn_dlta_amt"), col("fa_level_7"), col("fa_level_7_desc"), col("fa_level_8"), col("fa_level_8_desc"), col("fa_level_11"), col("fa_level_11_desc"), col("rvn_dlta_qty"), col("curr_ky"), col("dfrl_cgy_cd"),col("flflm_evt_typ_cd"), col("flflm_typ_cd"), col("entrs_lgl_ent_ldgr_cd"), col("acctng_prncpl_cd"),col("measuring_unt_cd"), col("tgt_acct_nr"), col("ststcs_us_cndn_ind"), col("prcg_or_cstg_cndn_ind"), col("prj_sys_etry_ind"), col("dcmt_orgl_amt"), col("dcmt_dlta_amt"), col("dcmt_dlta_qty"), col("dcmt_cmltv_amt"), col("dcmt_cmltv_qty"), col("rvn_dlta_amt"), col("rvn_dlta_qty"), col("rvn_dlta_nmntr_qty"), col("rvn_dlta_dnmntr_qty"), col("rvn_pstd_amt"), col("rvn_pstd_qty"), col("rvn_pstd_nmntr_qty"), col("rvn_pstd_dnmntr_qty"), col("inv_dlta_amt"), col("inv_dlta_qty"), col("inv_totl_amt"), col("inv_totl_qty"), col("mmo_dlta_qty"), col("mmo_totl_amt"), col("dfrl_itm_cmltv_amt"), col("dfrl_itm_cmltv_qty"), col("dfrl_itm_cmltv_nmntr_amt"), col("dfrl_itm_cmltv_dnmntr_amt"), col("dfrl_itm_crss_periods_ind"), col("dfrl_itm_splt_ind"), col("prfm_obgn_asst_imprmnt_ind"), col("etry_ltst_ind"), col("utc_ts")).filter(col("fa_level_7_desc").isNotNull).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("curr_ky"), col("dfrl_cgy_cd"),col("flflm_evt_typ_cd"), col("flflm_typ_cd"), col("acctng_prncpl_cd"),col("measuring_unt_cd"),col("tgt_acct_nr"), col("ststcs_us_cndn_ind"), col("prcg_or_cstg_cndn_ind"), col("prj_sys_etry_ind"),  col("dfrl_itm_splt_ind"),col("prfm_obgn_asst_imprmnt_ind"),col("etry_ltst_ind"),col("entrs_lgl_ent_ldgr_cd")).pivot("fa_level_7_desc").sum("dcmt_orgl_amt","dcmt_dlta_amt","dcmt_dlta_qty","dcmt_cmltv_amt","dcmt_cmltv_qty","rvn_dlta_amt","rvn_dlta_qty","rvn_dlta_nmntr_qty","rvn_dlta_dnmntr_qty","rvn_pstd_amt","rvn_pstd_qty","rvn_pstd_nmntr_qty","rvn_pstd_dnmntr_qty","inv_dlta_amt","inv_dlta_qty","inv_totl_amt","inv_totl_qty","mmo_dlta_qty","mmo_totl_amt","dfrl_itm_cmltv_amt","dfrl_itm_cmltv_qty","dfrl_itm_cmltv_nmntr_amt","dfrl_itm_cmltv_dnmntr_amt")

    dfrdTrsnDF_net_revenue = dfrdTrsnDF_net_revenue.columns.foldLeft(dfrdTrsnDF_net_revenue) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")) }

    var dfrdTrsnDF_gross_discount = dfrdTrsnDF.as("a").join(glselectDF.as("c"), col("a.src_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").select(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("rvn_dlta_amt"), col("fa_level_7"), col("fa_level_7_desc"), col("fa_level_8"), col("fa_level_8_desc"), col("fa_level_11"), col("fa_level_11_desc"), col("rvn_dlta_qty"), col("curr_ky"), col("dfrl_cgy_cd"),col("flflm_evt_typ_cd"), col("flflm_typ_cd"), col("entrs_lgl_ent_ldgr_cd"), col("acctng_prncpl_cd"),col("measuring_unt_cd"), col("tgt_acct_nr"), col("ststcs_us_cndn_ind"), col("prcg_or_cstg_cndn_ind"), col("prj_sys_etry_ind"), col("dcmt_orgl_amt"), col("dcmt_dlta_amt"), col("dcmt_dlta_qty"), col("dcmt_cmltv_amt"), col("dcmt_cmltv_qty"), col("rvn_dlta_amt"), col("rvn_dlta_qty"), col("rvn_dlta_nmntr_qty"), col("rvn_dlta_dnmntr_qty"), col("rvn_pstd_amt"), col("rvn_pstd_qty"), col("rvn_pstd_nmntr_qty"), col("rvn_pstd_dnmntr_qty"), col("inv_dlta_amt"), col("inv_dlta_qty"), col("inv_totl_amt"), col("inv_totl_qty"), col("mmo_dlta_qty"), col("mmo_totl_amt"), col("dfrl_itm_cmltv_amt"), col("dfrl_itm_cmltv_qty"), col("dfrl_itm_cmltv_nmntr_amt"), col("dfrl_itm_cmltv_dnmntr_amt"), col("dfrl_itm_crss_periods_ind"), col("dfrl_itm_splt_ind"), col("prfm_obgn_asst_imprmnt_ind"), col("etry_ltst_ind"), col("utc_ts")).filter(col("fa_level_8_desc").isNotNull).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("curr_ky"), col("dfrl_cgy_cd"),col("flflm_evt_typ_cd"), col("flflm_typ_cd"), col("acctng_prncpl_cd"),col("measuring_unt_cd"),col("tgt_acct_nr"), col("ststcs_us_cndn_ind"), col("prcg_or_cstg_cndn_ind"), col("prj_sys_etry_ind"),  col("dfrl_itm_splt_ind"),col("prfm_obgn_asst_imprmnt_ind"),col("etry_ltst_ind"),col("entrs_lgl_ent_ldgr_cd")).pivot("fa_level_8_desc").sum("dcmt_orgl_amt","dcmt_dlta_amt","dcmt_dlta_qty","dcmt_cmltv_amt","dcmt_cmltv_qty","rvn_dlta_amt","rvn_dlta_qty","rvn_dlta_nmntr_qty","rvn_dlta_dnmntr_qty","rvn_pstd_amt","rvn_pstd_qty","rvn_pstd_nmntr_qty","rvn_pstd_dnmntr_qty","inv_dlta_amt","inv_dlta_qty","inv_totl_amt","inv_totl_qty","mmo_dlta_qty","mmo_totl_amt","dfrl_itm_cmltv_amt","dfrl_itm_cmltv_qty","dfrl_itm_cmltv_nmntr_amt","dfrl_itm_cmltv_dnmntr_amt")

    dfrdTrsnDF_gross_discount = dfrdTrsnDF_gross_discount.columns.foldLeft(dfrdTrsnDF_gross_discount) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")) }

    var dfrdTrsnDF_Estimated_Standard_Cost = dfrdTrsnDF.as("a").join(glselectDF.as("c"), col("a.src_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").select(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("rvn_dlta_amt"), col("fa_level_7"), col("fa_level_7_desc"), col("fa_level_8"), col("fa_level_8_desc"), col("fa_level_11"), col("fa_level_11_desc"), col("rvn_dlta_qty"), col("curr_ky"), col("dfrl_cgy_cd"),col("flflm_evt_typ_cd"), col("flflm_typ_cd"), col("entrs_lgl_ent_ldgr_cd"), col("acctng_prncpl_cd"),col("measuring_unt_cd"), col("tgt_acct_nr"), col("ststcs_us_cndn_ind"), col("prcg_or_cstg_cndn_ind"), col("prj_sys_etry_ind"), col("dcmt_orgl_amt"), col("dcmt_dlta_amt"), col("dcmt_dlta_qty"), col("dcmt_cmltv_amt"), col("dcmt_cmltv_qty"), col("rvn_dlta_amt"), col("rvn_dlta_qty"), col("rvn_dlta_nmntr_qty"), col("rvn_dlta_dnmntr_qty"), col("rvn_pstd_amt"), col("rvn_pstd_qty"), col("rvn_pstd_nmntr_qty"), col("rvn_pstd_dnmntr_qty"), col("inv_dlta_amt"), col("inv_dlta_qty"), col("inv_totl_amt"), col("inv_totl_qty"), col("mmo_dlta_qty"), col("mmo_totl_amt"), col("dfrl_itm_cmltv_amt"), col("dfrl_itm_cmltv_qty"), col("dfrl_itm_cmltv_nmntr_amt"), col("dfrl_itm_cmltv_dnmntr_amt"), col("dfrl_itm_crss_periods_ind"), col("dfrl_itm_splt_ind"), col("prfm_obgn_asst_imprmnt_ind"), col("etry_ltst_ind"), col("utc_ts")).filter(col("fa_level_11_desc").isNotNull).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("curr_ky"), col("dfrl_cgy_cd"),col("flflm_evt_typ_cd"), col("flflm_typ_cd"), col("acctng_prncpl_cd"),col("measuring_unt_cd"),col("tgt_acct_nr"), col("ststcs_us_cndn_ind"), col("prcg_or_cstg_cndn_ind"), col("prj_sys_etry_ind"),   col("dfrl_itm_splt_ind"),col("prfm_obgn_asst_imprmnt_ind"),col("etry_ltst_ind"),col("entrs_lgl_ent_ldgr_cd")).pivot("fa_level_11_desc").sum("dcmt_orgl_amt","dcmt_dlta_amt","dcmt_dlta_qty","dcmt_cmltv_amt","dcmt_cmltv_qty","rvn_dlta_amt","rvn_dlta_qty","rvn_dlta_nmntr_qty","rvn_dlta_dnmntr_qty","rvn_pstd_amt","rvn_pstd_qty","rvn_pstd_nmntr_qty","rvn_pstd_dnmntr_qty","inv_dlta_amt","inv_dlta_qty","inv_totl_amt","inv_totl_qty","mmo_dlta_qty","mmo_totl_amt","dfrl_itm_cmltv_amt","dfrl_itm_cmltv_qty","dfrl_itm_cmltv_nmntr_amt","dfrl_itm_cmltv_dnmntr_amt")

    dfrdTrsnDF_Estimated_Standard_Cost = dfrdTrsnDF_Estimated_Standard_Cost.columns.foldLeft(dfrdTrsnDF_Estimated_Standard_Cost) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")) }
   
    val Keys = "rvn_rcgn_cntrct_id,entrs_lgl_ent_ldgr_cd,acctng_prncpl_cd,rvn_rcncltn_ky,prfm_obgn_id"
    
    val joinKeys = Keys.split(",").toSeq
    
    var final_df2 = dfrdTrsnDF_net_revenue.as("a").join(dfrdTrsnDF_gross_discount.as("b"), joinKeys).join(dfrdTrsnDF_Estimated_Standard_Cost.as("c"),joinKeys)
    
    //var final_df2 = dfrdTrsnDF_net_revenue.as("a").join(dfrdTrsnDF_gross_discount.as("b"), col("a.rvn_rcgn_cntrct_id") === col("b.rvn_rcgn_cntrct_id") && col("a.prfm_obgn_id") === col("b.prfm_obgn_id") && col("a.rvn_rcncltn_ky") === col("b.rvn_rcncltn_ky") && col("a.curr_ky") === col("b.curr_ky")).join(dfrdTrsnDF_Estimated_Standard_Cost.as("c"), col("b.rvn_rcgn_cntrct_id") === col("c.rvn_rcgn_cntrct_id") && col("b.prfm_obgn_id") === col("c.prfm_obgn_id") && col("b.rvn_rcncltn_ky") === col("c.rvn_rcncltn_ky") && col("b.curr_ky") === col("c.curr_ky"))

    val final_dfrd_df = final_df2.selectExpr("concat(a.rvn_rcgn_cntrct_id,a.prfm_obgn_id,a.rvn_rcncltn_ky,a.curr_ky) as rvn_rcgn_pstg_trs_ky","a.rvn_rcgn_cntrct_id", "a.prfm_obgn_id","a.rvn_rcncltn_ky","a.Net_Revenues_sumrvn_dlta_amt", "Net_Revenues_sumrvn_dlta_qty", "Total_Cost_of_Sales_sumrvn_dlta_amt", "Total_Cost_of_Sales_sumrvn_dlta_qty", "Cost_of_Sales_sumrvn_dlta_amt", "Cost_of_Sales_sumrvn_dlta_qty", "Gross_Trade_Revenues_sumrvn_dlta_amt", "Gross_Trade_Revenues_sumrvn_dlta_qty", "Trade_Discounts_sumrvn_dlta_amt", "Trade_Discounts_sumrvn_dlta_qty", "Contra_Revenue_sumrvn_dlta_amt", "Contra_Revenue_sumrvn_dlta_qty", "Enterprise_Standard_Cost_Total_sumrvn_dlta_amt", "Enterprise_Standard_Cost_Total_sumrvn_dlta_qty", "Trade_Sales_LEM_sumrvn_dlta_amt", "Trade_Sales_LEM_sumrvn_dlta_qty", "a.curr_ky", "a.dfrl_cgy_cd", "a.flflm_evt_typ_cd", "a.flflm_typ_cd", "a.measuring_unt_cd", "a.tgt_acct_nr", "a.ststcs_us_cndn_ind", "a.prcg_or_cstg_cndn_ind", "a.prj_sys_etry_ind", "a.dfrl_itm_splt_ind", "a.prfm_obgn_asst_imprmnt_ind", "a.etry_ltst_ind", "a.entrs_lgl_ent_ldgr_cd").withColumn("intgtn_fbrc_msg_id", lit(null)).withColumn("src_sys_upd_ts", lit(null)).withColumn("src_sys_ky", lit(null)).withColumn("lgcl_dlt_ind",lit(null)).withColumn("ins_gmt_ts", current_timestamp()).withColumn("upd_gmt_ts", current_timestamp()).withColumn("src_sys_extrc_gmt_ts", current_timestamp()).withColumn("src_sys_btch_nr",lit(null)).withColumn("fl_nm", lit(null)).withColumn("ld_jb_nr", lit(null))

    val DFcolNames = final_dfrd_df.columns.toList
    
    val transformedDF = DFcolNames.foldLeft(final_dfrd_df)((final_dfrd_df, c) =>
    final_dfrd_df.withColumnRenamed(c.toString.split(",")(0), c.toString.toLowerCase()))
    
    val tgtColumns = spark.sql(s"select * from ${dbNameConsmtn}.rvn_rcgn_defrd_itm_pvt_dmnsn").columns
    
    val finalLoadDF = transformedDF.select(Utilities.loadSelectExpr(transformedDF.columns, tgtColumns): _*)
		   
    finalLoadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn+".rvn_rcgn_defrd_itm_pvt_dmnsn")
    
    val tgt_count = spark.sql(s"select * from ${dbNameConsmtn}.rvn_rcgn_defrd_itm_pvt_dmnsn").count.toInt
    
    
        if (tgt_count <= 0) {
          logger.error("No records to process !")
          auditObj.setAudJobStatusCode("failed")
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

        } else {
          logger.info("CDC process completed !")
          auditObj.setAudJobStatusCode("success")
          auditObj.setAudSrcRowCount(src_count)
          auditObj.setAudTgtRowCount(tgt_count)
          auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
          Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      
    }

  } finally {
    sqlCon.close()
    spark.close()

  }
}
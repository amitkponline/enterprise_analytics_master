package com.hpe.batch.driver.facts.copa

import java.net.ConnectException

//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.coalesce
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions.lit
import org.apache.spark.storage.StorageLevel

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object Copa extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty || args.length != 1) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  //val fileBasePath = propertiesObject.getFileBasePath()
  try {
    
  //***************************Config Properties********************************//
    
    logger.info("Initializing log for Operating Concern Fact, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    val consmptnTable = new StringBuilder()
    //val dbNameConsmtn = new StringBuilder()
    val cst_cntr_dmnsn = new StringBuilder()
    val pftblty_anlys_hdr_tbl_dmnsn = new StringBuilder()
    val pftblty_anlys_vl_fields_tbl_dmnsn = new StringBuilder()
    val pftblty_anlys_qty_tbl_dmnsn = new StringBuilder()
    val pftblty_anlys_characteristics_tbl_dmnsn = new StringBuilder()
    val gnrl_ldgr_acct_dmnsn = new StringBuilder()
    //val dbName_common = new StringBuilder()
    var repartitionNo: Int = 10
    if (propertiesObject.getRepartitionNo() != null && propertiesObject.getRepartitionNo().length() > 0) {
      repartitionNo = propertiesObject.getRepartitionNo().toInt
    }

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      //dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim())
      //srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
      pftblty_anlys_hdr_tbl_dmnsn.append(propertiesObject.getSrcTblConsmtn().trim().split(",", -1)(0))
      pftblty_anlys_vl_fields_tbl_dmnsn.append(propertiesObject.getSrcTblConsmtn().trim().split(",", -1)(1))
      pftblty_anlys_qty_tbl_dmnsn.append(propertiesObject.getSrcTblConsmtn().trim().split(",", -1)(2))
      pftblty_anlys_characteristics_tbl_dmnsn.append(propertiesObject.getSrcTblConsmtn().trim().split(",", -1)(3))
      gnrl_ldgr_acct_dmnsn.append(propertiesObject.getSrcTblConsmtn().trim().split(",", -1)(4))
      cst_cntr_dmnsn.append(propertiesObject.getSrcTblConsmtn().trim().split(",", -1)(5))
      //dbName_common.append(propertiesObject.getDbName().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }
    val hMaxDt = spark.sql("""select coalesce(FROM_UNIXTIME(unix_timestamp(max(ins_gmt_ts))  ,'yyyy-MM-dd HH:mm:ss.0'),'1900-01-01 00:00:00') as max_ld_ts from """ + consmptnTable).first.getString(0)
    val qMaxDt = spark.sql("""select coalesce(FROM_UNIXTIME(unix_timestamp(max(q_ins_gmt_ts)) ,'yyyy-MM-dd HH:mm:ss.0'),'1900-01-01 00:00:00') as max_ld_ts from """ + consmptnTable).first.getString(0)
    val vMaxDt = spark.sql("""select coalesce(FROM_UNIXTIME(unix_timestamp(max(v_ins_gmt_ts)) ,'yyyy-MM-dd HH:mm:ss.0'),'1900-01-01 00:00:00') as max_ld_ts from """ + consmptnTable).first.getString(0)
    val cMaxDt = spark.sql("""select coalesce(FROM_UNIXTIME(unix_timestamp(max(c_ins_gmt_ts)) ,'yyyy-MM-dd HH:mm:ss.0'),'1900-01-01 00:00:00') as max_ld_ts from """ + consmptnTable).first.getString(0)
    val dataHistoryCheck = if ((hMaxDt == "1900-01-01 00:00:00") && (qMaxDt == "1900-01-01 00:00:00") && (cMaxDt == "1900-01-01 00:00:00") && (cMaxDt == "1900-01-01 00:00:00")) true else false

    //Joining the Profitability analysis tables and overwriting to Operating Concern Fact
    //val execQueries = Source.fromFile(fileBasePath).getLines.mkString("\n").split(";")
    //val execQueries = spark.sparkContext.textFile(fileBasePath).collect().mkString("\n").split(";")
    //var hqlQueries = new StringBuilder()
    val srcCount = spark.sql("select count(*) from " + pftblty_anlys_hdr_tbl_dmnsn).first().getLong(0)
    //var tgtCount = 0
    var loadStatus = false

    //Creating crc64 temp function
    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    //Creating accBased df with small table broadcast/repartitioning
    //adding a optimized key for joining- CRC64(existing key)
    val accBased = spark.sql("""select /*+ MAPJOIN(d) */ concat(COALESCE(a.ln_itm_dcmt_nr,""),COALESCE(a.itm_ln_itm_nr,""),COALESCE(a.itm_subnumber_ln_itm_nr,""),COALESCE(coalesce(b.curr_typ_and_valtn_vw_cd),""),COALESCE(coalesce(b.curr_dta_rec_cd),""),COALESCE(d.scndry_cst_elmt_cd,"")) as optg_concern_ky,
										crc64(lower(trim(concat(COALESCE(a.ln_itm_dcmt_nr,""),COALESCE(a.itm_ln_itm_nr,""),COALESCE(a.itm_subnumber_ln_itm_nr,""),COALESCE(coalesce(b.curr_typ_and_valtn_vw_cd),""),COALESCE(coalesce(b.curr_dta_rec_cd),""),COALESCE(d.scndry_cst_elmt_cd,""))))) as optg_concern_ky_crc64,
										crc32(lower(trim(coalesce(a.fnctl_ar_cd,'')))) as fnctl_ar_ky,
										crc32(lower(trim(coalesce(a.co_cd,'')))) as entrs_lgl_ent_ldgr_ky,
										crc32(lower(trim(coalesce(a.cust_cd,'')))) as erp_cust_ky,
										crc32(lower(trim(coalesce(a.sgm_sgmtl_rptg_cd,''))))  as mgmt_grphy_unt_ky,
										crc32(lower(trim(coalesce(a.cst_cntr_cd,'')))) as cst_cntr_ky,
										crc32(lower(trim(coalesce(a.pft_cntr_cd,'')))) as pft_cntr_ky,
										crc32(lower(trim(coalesce(a.ctrlng_ar_cd,'')))) as ctrlng_ar_ky,
										crc32(lower(trim(coalesce(a.sls_org_cd,'')))) as sls_org_ky,
										crc32(lower(trim(coalesce(a.dbn_chnl_cd,'')))) as dbn_chnl_ky,
										crc32(lower(trim(coalesce(a.dvsn_cd,'')))) as dvsn_ky,
										crc32(lower(trim(coalesce(a.blng_typ_cd,'')))) as blng_typ_ky,
										a.clnt_cd as pftblty_anlys_hdr_tbl_clnt_cd,
										a.ln_itm_dcmt_nr,
										a.itm_ln_itm_nr,
										a.itm_subnumber_ln_itm_nr,
										a.rec_typ_cd,
										a.pln_vrsn_COPA_cd,
										a.Periodyear_cd,
										a.fscl_yr_cd as pftblty_anlys_hdr_tbl_fscl_yr_cd,
										a.prd_cd,
										a.pftblty_sgm_COPA_nr,
										a.crtd_by_cd,
										a.dcmt_crtd_dt,
										a.crtd_at_cd,
										a.UTC_tm_Stamp_cd,
										a.pstg_dt,
										a.gds_iss_dt,
										a.inv_crtd_dt,
										a.COPA_pnt_valtn_cd,
										a.ind_blld_cd,
										a.blng_prd_cd,
										a.rfnc_prcgr_cd,
										a.rfnc_orgnl_unt_cd,
										a.lgcl_sys_src_dcmt_cd,
										a.rfnc_dcmt_COPA_ln_itm_nr,
										a.itm_frm_rfnc_dcmt_COPA_nr,
										a.rfnc_Subitem_nr,
										a.cnld_dcmt_cd,
										a.cnld_dcmt_it_1_cd,
										a.cnld_subnumber_ln_itm_nr,
										a.dltd_by_dcmt_cd,
										a.dltd_by_itm_cd,
										a.cnld_by_dcmt_cd,
										a.cnld_dcmt_it_2_cd,
										a.sls_ord_nr,
										a.itm_sls_ord_nr,
										a.ord_nr,
										a.dlvry_cd,
										a.dlvry_itm_cd,
										a.co_cd as pftblty_anlys_hdr_tbl_co_cd,
										a.ctrlng_ar_cd,
										a.plnt_cd,
										a.bsn_ar_cd,
										a.fnctl_ar_cd,
										a.sgm_sgmtl_rptg_cd,
										a.sls_org_cd,
										a.dbn_chnl_cd,
										a.dvsn_cd,
										a.pft_cntr_cd,
										a.ptnr_pft_cntr_cd,
										a.sndr_cst_cntr_cd,
										a.sndr_bsn_prs_cd,
										a.cst_cntr_cd,
										a.cust_cd,
										a.prod_nr,
										a.cst_obj_cd,
										a.wrk_brkdwn_srtr_elmt_wbs_elmt_cd,
										a.blng_typ_cd,
										a.Soldto_prty_cd,
										a.Shipto_prty_cd,
										a.eqpmnt_nr,
										a.Sales_doc_orignal_cd,
										a.srv_cntrct_cd,
										a.OTC_cd,
										a.srv_evt_id,
										a.TS_sls_mtn_cd,
										a.POODMICSTO_LBR_cd,
										a.po_itm_cd,
										a.Ven_odm_ic_pn_labr_cd,
										a.POEM_cd,
										a.EMR_new_mtrl_cd,
										a.go_mkt_ofr_id,
										a.HPE_Fulfilling_plnt_cd,
										a.sltn_3_cd,
										a.sltn_1_cd,
										a.cust_sgm_cd,
										a.sltn_2_cd,
										a.end_cust_cd,
										a.ord_typ_cd,
										a.hghr_lvl_itm_no_cd,
										a.ord_rsn_cd,
										a.valtn_clss_cd,
										a.deal_id,
										a.rte_to_mkt_cd,
										a.src_itm_nr,
										a.opty_id,
										a.mkt_sgm_cd,
										a.mkt_ofrng_cd,
										a.rslt_anlys_ky,
										a.cust_id,
										b.clnt_cd as pftblty_anlys_vl_fields_tbl_clnt_cd,
										b.curr_typ_and_valtn_vw_cd as curr_typ_and_valtn_vw_cd,
										b.curr_dta_rec_cd as curr_dta_rec_cd,
										b.A3_rbt_cd as a3_rbt_amt,
										b.70R_rbt_cd as 70r_rbt_amt,
										b.69R_rbt_cd as 69r_rbt_amt,
										b.69T_rbt_cd as 69t_rbt_amt,
										b.15_rbt_cd as 15_rbt_amt,
										b.4RemrktdDemoEvltn_cd as 4_rmktd_dm_elvtn_amt,
										b.15RPymetPrd_stlmnt_cd as 15r_pmnt_prd_stlmnt_amt,
										b.72Deal_rgst_cd as 72_deal_rgst_amt,
										b.74Tier_Deals_cd as 74tier_deals_amt,
										b.0709RProd_Prmtns_cd as 0709r_prod_prmtns_amt,
										b.26RAingStock_cd as 26raingstock_amt,
										b.77EEnd_sls_cd as 77eend_sls_amt,
										b.77Prtnr_spcf_cd as 77prtnr_spcf_amt,
										b.10SpNgtdEndCusD_oem_cd as 10spngtdendcusd_oem_amt,
										b.79LwMgHiEndCustDisc_cd as 79lwmghiendcustdisc_amt,
										b.72Sp_Ngtd_EndCust_D_cd as 72sp_ngtd_endcust_d_amt,
										b.otr_discounts_cd as otr_discounts_amt,
										b.qty_dscnt_cd as qty_dscnt_amt,
										b.prc_rdctn_cd as prc_rdctn_amt,
										b.rvn_cd as rvn_amt,
										b.OutgoingFreight_cd as otgng_frgt_amt,
										b.VariancesAdjustment_cd as vrnc_adjmt_amt,
										b.93Pur_Agmnt_Disc_cd as 93pur_agmnt_disc_amt,
										b.2XShipngHandlng_cd as 2x_shpng_hndl_amt,
										b.2YSpl_hndl_cd as 2yspl_hndl_amt,
										b.22Basic_frgt_cd as 22basic_frgt_amt,
										b.60ListNet_pr_adjmt_cd as 60listnet_pr_adjmt_amt,
										b.35Pen_feent_rchd_cd as 35pen_feent_rchd_amt,
										b.75Misc_Chg_cd as 75misc_chg_amt,
										b.A8Bklog_PrDcr_Prtn_cd as a8bklog_prdcr_prtn_amt,
										b.12HPE_AcMgmt_Supprt_cd as 12hpe_acmgmt_supprt_amt,
										b.rw_MatSpare_prts_cd as rw_matspare_prts_amt,
										b.EMR_cst_cd as emr_cst_amt,
										b.pkgg_cd as pkgg_amt,
										b.SubasblycontMfg_cd as sub_asbly_contmfg_amt,
										b.Fin_brdn_cd as fin_brdn_amt,
										b.fnshd_mtrls_cd as fnshd_mtrls_amt,
										b.LoHP_cd as lohp_amt,
										b.HPE_ovrhd_cd as hpe_ovrhd_amt,
										b.rylty_cd as rylty_amt,
										b.vndr_Rebates_cd as vndr_rebates_amt,
										b.Masking_cd as masking_amt,
										b.Fees_frgt_Duty_cd as fees_frgt_duty_amt,
										b.prd_var,
										b.othr_var,
										b.pg_cogs,
										b.ppv_moh,
										b.ic_blng_lem_cogs,
										b.ic_blng_lom_cogs,
										null as  pftblty_anlys_characteristics_tbl_clnt_cd,
										null as cst_elmt_cd,
										null as pftblty_anlys_characteristics_tbl_src_cst_elmt_cd,
										null as totl_vl_ldgr_curr,
										null as fix_vl_ldgr_curr,
										null as pftblty_anlys_characteristics_tbl_co_cd,
										null as acctng_dcmt_nr,
										null as pftblty_anlys_characteristics_tbl_fscl_yr_cd,
										null as ln_itm_Within_acctng_dcmt_nr,
										d.src_cst_elmt_cd as pftblty_anlys_qty_tbl_src_cst_elmt_cd,
										d.scndry_cst_elmt_cd,
										d.sls_qty_cd as sls_qty_amt,
										CASE WHEN (a.prd_cd) IN ('001','002','003') THEN '1' WHEN (a.prd_cd) IN ('004','005','006') THEN '2' WHEN (a.prd_cd) IN ('007','008','009') THEN '3' WHEN (a.prd_cd) IN ('010','011','012') THEN '4' WHEN (a.prd_cd) IN ('010','011','012') THEN '4' WHEN (a.prd_cd) IN ('013','014','015','016') THEN '4' else NULL end as qrtr_attrbt,
										CASE WHEN (a.prd_cd) IN ('001','002','003','004','005','006') THEN '1' WHEN (a.prd_cd) IN ('007','008','009','010','011','012') THEN '2' WHEN (a.prd_cd) IN ('013','014','015','016') THEN '3' else NULL end as half_yr_qrtr_attrbt,
										d.src_sys_btch_nr,
										CURRENT_TIMESTAMP as ins_ts,
										d.bs_unt_msr_cd,
										a.src_sys_upd_ts,
										a.src_sys_ky,
										a.lgcl_dlt_ind,
										a.ins_gmt_ts as ins_gmt_ts,
										b.ins_gmt_ts as v_ins_gmt_ts,
										d.ins_gmt_ts as q_ins_gmt_ts,
										null as c_ins_gmt_ts,
										a.upd_gmt_ts ,
										a.src_sys_extrc_gmt_ts,
										a.src_sys_btch_nr as pftblty_anlys_hdr_src_sys_btch_nr,
										a.fl_nm ,
										a.ld_jb_nr,
										a.ins_ts as pftblty_anlys_hdr_ins_ts,
										null as grp_acct_nr,
										b.rwrk,
										b.std_rvsn,
										b.invnt_adj,
										b.excs_obso, 
										b.esc_vrnc,
										b.mt_unt_vrnc,
										CASE WHEN d.ins_gmt_ts > b.ins_gmt_ts AND d.ins_gmt_ts > a.ins_gmt_ts THEN d.ins_gmt_ts WHEN b.ins_gmt_ts > a.ins_gmt_ts AND b.ins_gmt_ts > d.ins_gmt_ts THEN b.ins_gmt_ts ELSE a.ins_gmt_ts END AS last_mfyd_dt_inc,
										'Account Based COPA' as tbl_Src ,
										null as drvd_func_ar_cd 
										from (select * from """ + pftblty_anlys_hdr_tbl_dmnsn + """ where ins_gmt_ts >'""" + hMaxDt + """')a
										left outer join (select * from """ + pftblty_anlys_vl_fields_tbl_dmnsn + """ where ins_gmt_ts > '""" + vMaxDt + """') b on a.ln_itm_dcmt_nr=b.ln_itm_dcmt_nr and a.itm_ln_itm_nr=b.itm_ln_itm_nr and  COALESCE(a.itm_subnumber_ln_itm_nr,'NA')=COALESCE(b.itm_subnumber_ln_itm_nr,'NA')
										left outer join (select * from """ + pftblty_anlys_qty_tbl_dmnsn + """ where ins_gmt_ts>'""" + qMaxDt + """') d on a.ln_itm_dcmt_nr=d.ln_itm_dcmt_nr and a.itm_ln_itm_nr=d.itm_ln_itm_nr and COALESCE(a.itm_subnumber_ln_itm_nr,'NA')=COALESCE(d.itm_subnumber_ln_itm_nr,'NA')""")

    //  Creating costBased df with small table broadcast/repartitioning
    //  adding a optimized key for joining- CRC64(existing key)
    val costBased = spark.sql("""select /*+ MAPJOIN(cst_master) */ concat(COALESCE(a.ln_itm_dcmt_nr,""),COALESCE(a.itm_ln_itm_nr,""),COALESCE(a.itm_subnumber_ln_itm_nr,""),COALESCE(coalesce(c.curr_typ_and_valtn_vw_cd),""),COALESCE(c.cst_elmt_cd,""),COALESCE(c.src_cst_elmt_cd,""),COALESCE(coalesce(c.curr_dta_rec_cd),"")) as optg_concern_ky,
										crc64(lower(trim(concat(COALESCE(a.ln_itm_dcmt_nr,""),COALESCE(a.itm_ln_itm_nr,""),COALESCE(a.itm_subnumber_ln_itm_nr,""),COALESCE(coalesce(c.curr_typ_and_valtn_vw_cd),""),COALESCE(c.cst_elmt_cd,""),COALESCE(c.src_cst_elmt_cd,""),COALESCE(coalesce(c.curr_dta_rec_cd),""))))) as optg_concern_ky_crc64,
										crc32(lower(trim(coalesce(a.fnctl_ar_cd,'')))) as fnctl_ar_ky,
										crc32(lower(trim(coalesce(a.co_cd,'')))) as entrs_lgl_ent_ldgr_ky,
										crc32(lower(trim(coalesce(a.cust_cd,'')))) as erp_cust_ky,
										crc32(lower(trim(coalesce(a.sgm_sgmtl_rptg_cd,''))))  as mgmt_grphy_unt_ky,
										crc32(lower(trim(coalesce(a.cst_cntr_cd,'')))) as cst_cntr_ky,
										crc32(lower(trim(coalesce(a.pft_cntr_cd,'')))) as pft_cntr_ky,
										crc32(lower(trim(coalesce(a.ctrlng_ar_cd,'')))) as ctrlng_ar_ky,
										crc32(lower(trim(coalesce(a.sls_org_cd,'')))) as sls_org_ky,
										crc32(lower(trim(coalesce(a.dbn_chnl_cd,'')))) as dbn_chnl_ky,
										crc32(lower(trim(coalesce(a.dvsn_cd,'')))) as dvsn_ky,
										crc32(lower(trim(coalesce(a.blng_typ_cd,'')))) as blng_typ_ky,
										a.clnt_cd as pftblty_anlys_hdr_tbl_clnt_cd,
										a.ln_itm_dcmt_nr,
										a.itm_ln_itm_nr,
										a.itm_subnumber_ln_itm_nr,
										a.rec_typ_cd,
										a.pln_vrsn_COPA_cd,
										a.Periodyear_cd,
										a.fscl_yr_cd as pftblty_anlys_hdr_tbl_fscl_yr_cd,
										a.prd_cd,
										a.pftblty_sgm_COPA_nr,
										a.crtd_by_cd,
										a.dcmt_crtd_dt,
										a.crtd_at_cd,
										a.UTC_tm_Stamp_cd,
										a.pstg_dt,
										a.gds_iss_dt,
										a.inv_crtd_dt,
										a.COPA_pnt_valtn_cd,
										a.ind_blld_cd,
										a.blng_prd_cd,
										a.rfnc_prcgr_cd,
										a.rfnc_orgnl_unt_cd,
										a.lgcl_sys_src_dcmt_cd,
										a.rfnc_dcmt_COPA_ln_itm_nr,
										a.itm_frm_rfnc_dcmt_COPA_nr,
										a.rfnc_Subitem_nr,
										a.cnld_dcmt_cd,
										a.cnld_dcmt_it_1_cd,
										a.cnld_subnumber_ln_itm_nr,
										a.dltd_by_dcmt_cd,
										a.dltd_by_itm_cd,
										a.cnld_by_dcmt_cd,
										a.cnld_dcmt_it_2_cd,
										a.sls_ord_nr,
										a.itm_sls_ord_nr,
										a.ord_nr,
										a.dlvry_cd,
										a.dlvry_itm_cd,
										a.co_cd as pftblty_anlys_hdr_tbl_co_cd,
										a.ctrlng_ar_cd,
										a.plnt_cd,
										a.bsn_ar_cd,
										a.fnctl_ar_cd,
										a.sgm_sgmtl_rptg_cd,
										a.sls_org_cd,
										a.dbn_chnl_cd,
										a.dvsn_cd,
										a.pft_cntr_cd,
										a.ptnr_pft_cntr_cd,
										a.sndr_cst_cntr_cd,
										a.sndr_bsn_prs_cd,
										a.cst_cntr_cd,
										a.cust_cd,
										a.prod_nr,
										a.cst_obj_cd,
										a.wrk_brkdwn_srtr_elmt_wbs_elmt_cd,
										a.blng_typ_cd,
										a.Soldto_prty_cd,
										a.Shipto_prty_cd,
										a.eqpmnt_nr,
										a.Sales_doc_orignal_cd,
										a.srv_cntrct_cd,
										a.OTC_cd,
										a.srv_evt_id,
										a.TS_sls_mtn_cd,
										a.POODMICSTO_LBR_cd,
										a.po_itm_cd,
										a.Ven_odm_ic_pn_labr_cd,
										a.POEM_cd,
										a.EMR_new_mtrl_cd,
										a.go_mkt_ofr_id,
										a.HPE_Fulfilling_plnt_cd,
										a.sltn_3_cd,
										a.sltn_1_cd,
										a.cust_sgm_cd,
										a.sltn_2_cd,
										a.end_cust_cd,
										a.ord_typ_cd,
										a.hghr_lvl_itm_no_cd,
										a.ord_rsn_cd,
										a.valtn_clss_cd,
										a.deal_id,
										a.rte_to_mkt_cd,
										a.src_itm_nr,
										a.opty_id,
										a.mkt_sgm_cd,
										a.mkt_ofrng_cd,
										a.rslt_anlys_ky,
										a.cust_id,
										null as pftblty_anlys_vl_fields_tbl_clnt_cd,
										c.curr_typ_and_valtn_vw_cd as curr_typ_and_valtn_vw_cd,
										c.curr_dta_rec_cd as curr_dta_rec_cd,
										null as a3_rbt_amt,
										null as 70r_rbt_amt,
										null as 69r_rbt_amt,
										null as 69t_rbt_amt,
										null as 15_rbt_amt,
										null as 4_rmktd_dm_elvtn_amt,
										null as 15r_pmnt_prd_stlmnt_amt,
										null as 72_deal_rgst_amt,
										null as 74tier_deals_amt,
										null as 0709r_prod_prmtns_amt,
										null as 26raingstock_amt,
										null as 77eend_sls_amt,
										null as 77prtnr_spcf_amt,
										null as 10spngtdendcusd_oem_amt,
										null as 79lwmghiendcustdisc_amt,
										null as 72sp_ngtd_endcust_d_amt,
										null as otr_discounts_amt,
										null as qty_dscnt_amt,
										null as prc_rdctn_amt,
										null as rvn_amt,
										null as otgng_frgt_amt,
										null as vrnc_adjmt_amt,
										null as 93pur_agmnt_disc_amt,
										null as 2x_shpng_hndl_amt,
										null as 2yspl_hndl_amt,
										null as 22basic_frgt_amt,
										null as 60listnet_pr_adjmt_amt,
										null as 35pen_feent_rchd_amt,
										null as 75misc_chg_amt,
										null as a8bklog_prdcr_prtn_amt,
										null as 12hpe_acmgmt_supprt_amt,
										null as rw_matspare_prts_amt,
										null as emr_cst_amt,
										null as pkgg_amt,
										null as sub_asbly_contmfg_amt,
										null as fin_brdn_amt,
										null as fnshd_mtrls_amt,
										null as lohp_amt,
										null as hpe_ovrhd_amt,
										null as rylty_amt,
										null as vndr_rebates_amt,
										null as masking_amt,
										null as fees_frgt_duty_amt,
										null as prd_var,
										null as othr_var,
										null as pg_cogs,
										null as ppv_moh,
										null as ic_blng_lem_cogs,
										null as ic_blng_lom_cogs,
										c.clnt_cd as pftblty_anlys_characteristics_tbl_clnt_cd,
										c.cst_elmt_cd,
										c.src_cst_elmt_cd as pftblty_anlys_characteristics_tbl_src_cst_elmt_cd,
										c.totl_vl_ldgr_Curreny_cd as totl_vl_ldgr_curr,
										c.fix_vl_ldgr_Curreny_cd as fix_vl_ldgr_curr,
										c.co_cd as pftblty_anlys_characteristics_tbl_co_cd,
										c.acctng_dcmt_nr,
										c.fscl_yr_cd as pftblty_anlys_characteristics_tbl_fscl_yr_cd,
										c.ln_itm_Within_acctng_dcmt_nr,
										null as pftblty_anlys_qty_tbl_src_cst_elmt_cd,
										null as scndry_cst_elmt_cd,
										null as sls_qty_amt,
										CASE WHEN (a.prd_cd) IN ('001','002','003') THEN '1' WHEN (a.prd_cd) IN ('004','005','006') THEN '2' WHEN (a.prd_cd) IN ('007','008','009') THEN '3' WHEN (a.prd_cd) IN ('010','011','012') THEN '4' WHEN (a.prd_cd) IN ('010','011','012') THEN '4' WHEN (a.prd_cd) IN ('013','014','015','016') THEN '4' else NULL end as qrtr_attrbt,
										CASE WHEN (a.prd_cd) IN ('001','002','003','004','005','006') THEN '1' WHEN (a.prd_cd) IN ('007','008','009','010','011','012') THEN '2' WHEN (a.prd_cd) IN ('013','014','015','016') THEN '3' else NULL end as half_yr_qrtr_attrbt,
										null as src_sys_btch_nr,
										CURRENT_TIMESTAMP as ins_ts,
										null as bs_unt_msr_cd, 
										a.src_sys_upd_ts,
										a.src_sys_ky,
										a.lgcl_dlt_ind,
										a.ins_gmt_ts as ins_gmt_ts,
										null as v_ins_gmt_ts,
										null as q_ins_gmt_ts,
										c.ins_gmt_ts as c_ins_gmt_ts, 
										a.upd_gmt_ts ,
										a.src_sys_extrc_gmt_ts,
										a.src_sys_btch_nr as pftblty_anlys_hdr_src_sys_btch_nr,
										a.fl_nm ,
										a.ld_jb_nr,
										a.ins_ts as pftblty_anlys_hdr_ins_ts,
										gla_master.grp_acct_nr,
										null as rwrk,
										null as std_rvsn,
										null as invnt_adj,
										null as excs_obso, 
										null as esc_vrnc,
										null as mt_unt_vrnc,
										CASE WHEN a.ins_gmt_ts > c.ins_gmt_ts THEN a.ins_gmt_ts else c.ins_gmt_ts END AS last_mfyd_dt_inc,
										'Costing Based COPA' as tbl_src,
										CASE WHEN c.cst_elmt_cd LIKE '004%' THEN cst_master.fnctl_ar_cd ELSE gla_master.funtional_ar_cd END as drvd_func_ar_cd
										from (select * from """ + pftblty_anlys_hdr_tbl_dmnsn + """ where ins_gmt_ts>'""" + hMaxDt + """') a
										left outer join  (select * from """ + pftblty_anlys_characteristics_tbl_dmnsn + """ where ins_gmt_ts> '""" + cMaxDt + """') c on a.ln_itm_dcmt_nr=c.ln_itm_dcmt_nr and a.itm_ln_itm_nr=c.itm_ln_itm_nr and  COALESCE(a.itm_subnumber_ln_itm_nr,'NA')=COALESCE(c.itm_subnumber_ln_itm_nr,'NA')
										left outer join (select distinct gnrl_ldgr_acct_nr, grp_acct_nr,funtional_ar_cd from """ + gnrl_ldgr_acct_dmnsn + """ where chrt_of_accts_cd = 'WW00') gla_master
										on c.cst_elmt_cd=gla_master.gnrl_ldgr_acct_nr left outer join """ + cst_cntr_dmnsn + """ cst_master on a.cst_cntr_cd=cst_master.cst_cntr_cd""")

    import spark.implicits._

    def insert_into_partition(dfInc: DataFrame, tableName: String) {

      // Adding new column-optg_concern_ky_crc64, crc64(existing key) for optimized join
      val dfHis = spark.sql("select *,crc64(lower(trim(optg_concern_ky))) as optg_concern_ky_crc64 from " + tableName)
      var dfIncremental = dfInc.withColumn("partition_year_month", concat_ws("-", coalesce($"pftblty_anlys_hdr_tbl_fscl_yr_cd", lit("2019")), coalesce($"prd_cd", lit("11"))))

      if (dataHistoryCheck) {
        // Check if historydf is empty
        if (dfHis.head(1).isEmpty) {
          dfIncremental.repartition(50).write.mode(SaveMode.Append).format("orc").insertInto(tableName)
          logger.info("CHECK-> historic load completed")
          return
        }
      } else {
        dfIncremental = dfIncremental.repartition(col("partition_year_month"))
        //logger.info("CHECK-> Persist final stage inc count " + dfIncremental.count())

      }

      //Get list of distinct partition_year_month from dfIncremental to be matched with dfHis
      val list_of_distinct_his_partition_inc = dfIncremental.select("partition_year_month").distinct().collect.map(x => x.getString(0).toString).toList
      logger.info("CHECK-> list of partitions -> " + list_of_distinct_his_partition_inc.mkString(","))

      dfIncremental = dfIncremental.repartition(col("optg_concern_ky_crc64"))

      //Filter dfHis only from list_of_distinct_his_partition
      val dfHistorical = dfHis.filter($"partition_year_month".isin(list_of_distinct_his_partition_inc: _*)).repartition(col("optg_concern_ky_crc64"))

      //Get records from dfHistorical that are non matching in dfIncremental and drop the additional column from final df ,df_to_overwite
      val df_to_overwite = dfHistorical.as("his").join(dfIncremental.as("inc"), $"his.optg_concern_ky_crc64" === $"inc.optg_concern_ky_crc64", "left_anti").drop(col("optg_concern_ky_crc64"))

      //Drop the addition column from dfIncremental
      dfIncremental = dfIncremental.drop(col("optg_concern_ky_crc64"))

      //Union dfs and insert into target table
      df_to_overwite.union(dfIncremental).repartition(repartitionNo).write.mode(SaveMode.Overwrite).format("orc").insertInto(tableName)

    }

    var dfInc = accBased.union(costBased)
    //Persist dfInc in memory to be reused later from memory
    dfInc = dfInc.persist(StorageLevel.MEMORY_AND_DISK_SER)

    var runStatus = false
    val inc_count = dfInc.count()
    if (inc_count > 0) {
      runStatus = try {
        insert_into_partition(dfInc, consmptnTable.toString())
        true
      } catch {
        case e: Exception => {
          logger.info("CHECK -> " + e.printStackTrace())
          false
        }
      }
    } else {
      logger.info("CHECK -> No incremenetal data")
      runStatus = true
    }

    loadStatus = runStatus
    //val srcCount = 0
    val tgtCount = dfInc.count().toLong
    dfInc.unpersist()


    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
      logger.info("Load Successful")
    } else {
      auditObj.setAudJobStatusCode("failed")
      logger.info("Load Failed")
    }
    auditObj.setAudSrcRowCount(srcCount)
    auditObj.setAudTgtRowCount(tgtCount)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) {
      System.exit(1)
    }

  }
}
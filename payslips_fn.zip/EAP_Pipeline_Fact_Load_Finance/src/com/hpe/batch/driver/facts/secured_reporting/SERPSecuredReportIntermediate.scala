package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel._

object SERPSecuredReportIntermediate extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  logger.info("//*********************** Log Start for SERPSecuredReportLR1.scala ************************//")

  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }

  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())

  logger.info("+++++++++++############# Properties File Path: " + propertiesFilePath)

  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)

  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"

  logger.info("+++++++++++############# Env Properties File Path: " + envPropertiesFilePath)

  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val objName = propertiesObject.getObjName().trim()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val dbcommonname = propertiesObject.getDbName().split(",")(0).trim
  val dbcommonuatname = propertiesObject.getDbName().split(",")(1).trim
  val dbcommonnamelr1 = propertiesObject.getDbName().split(",")(2).trim
  val dbfinancnamelr1 = propertiesObject.getDbName().split(",")(3).trim
  val dbfinancname = propertiesObject.getDbName().split(",")(4).trim
  val dbfinancnamelr1uat = propertiesObject.getDbName().split(",")(5).trim
  val dbcommonlr1uat = propertiesObject.getDbName().split(",")(6).trim
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()

  logger.info("+++++++++++############# Audit Table Name: " + auditTbl)

  val sqlCon = Utilities.getConnection(envPropertiesObject)

  var dbNameConsmtn: String = null
  var consmptnTable: String = null

  //***************************Audit Properties********************************//
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_secrd_serp_intermidiate_load")
  auditObj.setAudObjectName(objName)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  spark.conf.set("spark.sql.crossJoin.enabled", "true")

  try {

    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn))

    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    if (tgtTblConsmtn.split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val srcCount = spark.sql(s"select * from ${tgtTblConsmtn}").count.toLong

    // ******************************** Data Preparation for SERP LOAD ***********************************\\

    // Filter condition for Current, Future and previous quarter(only till first month of current quarter) data
    val cal = Calendar.getInstance()
    val Year = cal.get(Calendar.YEAR)
    val Month1 = cal.get(Calendar.MONTH)
    var Month = Month1 + 1
    val prev_year = Year - 1
    val year1 = Year + 1
    val prev_year_str = prev_year.toString()
    var Month_val = Month.toString()
    var year_val = Year.toString()
    var next_year = year1.toString()
    logger.info("current year", Year, Month1, Month)

    var fscl_yr_prd = ""

    if ((Month_val == "11") || (Month_val == "12")) {
      if (Month_val == "11") {
        fscl_yr_prd = year_val + "4"
      } else {
        fscl_yr_prd = next_year + "1"
      } //year+Q
    } else if (Month_val == "1") { fscl_yr_prd = year_val + "1" }

    else if ((Month_val == "2") || (Month_val == "3") || (Month_val == "4")) {
      if (Month_val == "2") {
        fscl_yr_prd = year_val + "1"
      } else {
        fscl_yr_prd = year_val + "2"
      }
    } else if ((Month_val == "5") || (Month_val == "6") || (Month_val == "7")) {
      if (Month_val == "5") {
        fscl_yr_prd = year_val + "2"
      } else {
        fscl_yr_prd = year_val + "3"
      }
    } else if ((Month_val == "8") || (Month_val == "9") || (Month_val == "10")) {
      if (Month_val == "8") {
        fscl_yr_prd = year_val + "3"
      } else {
        fscl_yr_prd = year_val + "4"
      }
    }

    val fscl_yr_prd_con = fscl_yr_prd.toInt

    logger.info("//************* current refresh period for secured fact table (fscl_yr_prd_con): " + fscl_yr_prd_con)

    /*
     * derive exchange rate
     *
     */
    val exchdf = spark.sql(s"""
    select 
      frm_curr_cd,
      etry_vld_frm_ts,
      frm_curr_unts_rto_2_nr,
      indrt_qted_exch_rate_nr,
      to_curr_unts_rto_2_nr 
    from 
    ${dbfinancnamelr1uat}.exch_rates_dmnsn 
    where 
      exch_rate_typ_cd = 'M' 
      and to_curr_cd = 'USD' 
      and day(etry_vld_frm_ts) = 1
    """).withColumn("exch_rt", when(col("frm_curr_unts_rto_2_nr") === col("to_curr_unts_rto_2_nr"), (col("frm_curr_unts_rto_2_nr") / col("indrt_qted_exch_rate_nr")) * col("to_curr_unts_rto_2_nr")).
      when(col("frm_curr_unts_rto_2_nr") > col("to_curr_unts_rto_2_nr"), (col("to_curr_unts_rto_2_nr") / col("indrt_qted_exch_rate_nr")) * col("frm_curr_unts_rto_2_nr")).
      when(col("frm_curr_unts_rto_2_nr") < col("to_curr_unts_rto_2_nr"), (col("frm_curr_unts_rto_2_nr") / col("indrt_qted_exch_rate_nr")) * col("to_curr_unts_rto_2_nr")).
      otherwise(1))

    exchdf.createOrReplaceTempView("exch_rt_tbl")

    /*
     * derive rate code from bmts(product rates, customer rates, pl rates, sales order rates, partner rates )
     *
     */

    val slsshpdf = spark.sql(s"""
		select
		  distinct ope_sls_spmt.ope_sldt_prty_id as e1edka1_ptnr_nr_ag,
		  case
		    when ord_dmnsn_adjmt_dmnsn.end_cust_prty_id is null then ope_sls_spmt.ope_end_cust_prty_id
		    else ord_dmnsn_adjmt_dmnsn.end_cust_prty_id
	    end as end_cust_prty_id,
		  sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2,
		  sls_spmt.pft_cntr_nm,
		  sls_spmt.e1edk01_idoc_dcmt_nr,
		  sls_spmt.e1edp01_itm_nr,
		  rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,
		  mkt_rte_cd,
		  sls_spmt.sgmnt_cd as sg_level_3,
		  rvn_rcgn_dfrd_itm_dmnsn.rvn_rcgn_cntrct_id,
		  rvn_rcgn_dfrd_itm_dmnsn.prfm_obgn_id,
		  sls_spmt.sgmnt_cd,
    	case
		    when ord_dmnsn_adjmt_dmnsn.mkt_rte_cd is null then ope_sls_spmt.ope_rtm
		    else ord_dmnsn_adjmt_dmnsn.mkt_rte_cd
	    end as rtm,
		  COALESCE(
		  CASE
			  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr is not null then concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7)),1,6),'-',substr(concat('FY',substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7)),8,	9))
			  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null then concat(substr(concat('FY',substring(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky, 1, 7)),1,6),'-',substr(concat('FY',substring(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky, 1, 7)),8,	9))
			  ELSE CONCAT('FY',substr(inv_clndr_rpt.fisc_yr_mth_cd,1,4),'-',substr(inv_clndr_rpt.fisc_yr_mth_cd,5,2))
		  END,CONCAT('FY',substr(inv_clndr_rpt.fisc_yr_mth_cd,1,4),'-',substr(inv_clndr_rpt.fisc_yr_mth_cd,5,2))) as fscl_yr_mth_cd,
		  prmry_prcg_cndn_cd,
		  sls_spmt.estmd_inv_dt
		from
		${dbfinancnamelr1uat}.secrd_rpt_sls_spmt_dmnsn sls_spmt
		left outer join (select * from (select e1edk01_idoc_dcmt_nr,e1edp01_itm_nr,ope_deal_end_cust_prty_id,ope_bmt_end_cust_prty_id,ope_dstr_prty_id,ope_rslr_prty_id,ope_end_cust_prty_id,ope_sldt_prty_id,ope_src_end_cust_prty_id,ope_rtm,ope_crss_brdr,row_number() over (partition by e1edk01_idoc_dcmt_nr,e1edp01_itm_nr order by ins_gmt_ts) rw_num from ${dbfinancnamelr1uat}.secrd_ope_sls_spmt_dmnsn) ope_stg where rw_num = 1) ope_sls_spmt on
      sls_spmt.e1edk01_idoc_dcmt_nr = ope_sls_spmt.e1edk01_idoc_dcmt_nr
      and sls_spmt.e1edp01_itm_nr = ope_sls_spmt.e1edp01_itm_nr
		left outer join ${dbfinancnamelr1uat}.rvn_rcgn_mppg_dmnsn rvn_rcgn_mppg_dmnsn on
			sls_spmt.e1edk01_idoc_dcmt_nr = substring(rvn_rcgn_mppg_dmnsn.src_itm_id, 1, 10)
			and sls_spmt.e1edp01_itm_nr = substring(rvn_rcgn_mppg_dmnsn.src_itm_id,(length(rvn_rcgn_mppg_dmnsn.src_itm_id)-5), 6)
		left outer join ${dbfinancnamelr1uat}.rvn_rcgn_prfm_obgn_dmnsn on 
			rvn_rcgn_mppg_dmnsn.prfm_obgn_id = rvn_rcgn_prfm_obgn_dmnsn.prfm_obgn_id
		left outer join ${dbfinancnamelr1uat}.rvn_rcgn_cntrct_dmnsn rvn_rcgn_cntrct_dmnsn on
			rvn_rcgn_mppg_dmnsn.rvn_rcgn_cntrct_id = rvn_rcgn_cntrct_dmnsn.rvn_rcgn_cntrct_id
		left outer join ${dbfinancnamelr1uat}.rvn_rcgn_dfrd_itm_dmnsn rvn_rcgn_dfrd_itm_dmnsn on
			rvn_rcgn_mppg_dmnsn.rvn_rcgn_cntrct_id = rvn_rcgn_dfrd_itm_dmnsn.rvn_rcgn_cntrct_id
			and rvn_rcgn_mppg_dmnsn.prfm_obgn_id = rvn_rcgn_dfrd_itm_dmnsn.prfm_obgn_id
			and rvn_rcgn_dfrd_itm_dmnsn.etry_ltst_ind = 'x'
			and (rvn_rcgn_dfrd_itm_dmnsn.rvn_dlta_amt <> 0 or rvn_rcgn_dfrd_itm_dmnsn.rvn_dlta_amt is null)
			and rvn_rcgn_dfrd_itm_dmnsn.ststcs_us_cndn_ind is null
			and upper(rvn_rcgn_dfrd_itm_dmnsn.prcg_or_cstg_cndn_ind) = 'p' -- updated on 3/18
		left outer join ${dbcommonlr1uat}.bmt_ord_dmnsn_adjmt_dmnsn ord_dmnsn_adjmt_dmnsn on
			sls_spmt.e1edk01_idoc_dcmt_nr = ord_dmnsn_adjmt_dmnsn.sls_ord_id
		--left outer join ${dbcommonnamelr1}.segment_std_hrchy segment_std_hrchy on
		--	segment_std_hrchy.sg_level_8 = sls_spmt.sgmnt_cd
		left outer join ${dbcommonlr1uat}.bmt_sgm_alt_hrchy_dmnsn on
		  sls_spmt.sgmnt_cd = bmt_sgm_alt_hrchy_dmnsn.sgm_cd
		left outer join ${dbfinancnamelr1uat}.rvn_rcgn_estd_pvt_dmnsn on
			rvn_rcgn_mppg_dmnsn.rvn_rcgn_cntrct_id = rvn_rcgn_estd_pvt_dmnsn.rvn_rcgn_cntrct_id
			and rvn_rcgn_mppg_dmnsn.prfm_obgn_id = rvn_rcgn_estd_pvt_dmnsn.prfm_obgn_id
		left outer join ${dbcommonnamelr1}.clndr_rpt inv_clndr_rpt on sls_spmt.estmd_inv_dt=inv_clndr_rpt.cldr_dt
		where
    case 
  	  when COALESCE(sls_spmt.sls_ord_totl_qty_cd,0) <= 0 and sls_spmt.no_shp_flg_cd = 'Y' then 1 
	    when sls_spmt.e1edp01_itm_nr is null and sls_spmt.actl_qty_dlvrd_stockkeeping_unts is null and sls_spmt.no_shp_flg_cd = 'FY' then  0
	    when (sls_spmt.actl_qty_dlvrd_stockkeeping_unts > 0.0 or sls_spmt.actl_qty_dlvrd_stockkeeping_unts is null) then 1
	    else 0 
    end = 1
	  """)

    val slsordrtdf = spark.sql(s"select * from ${dbcommonlr1uat}.bmt_sls_ord_rates_dmnsn ")

    val bmtprodrtdf = spark.sql(s"select * from ${dbcommonlr1uat}.bmt_prod_rates_dmnsn")

    val custrtdf = spark.sql(s"select *,case when length(trim(prmry_prcg_cnd)) = 0 then null else prmry_prcg_cnd end as prmry_prcg_cnd_derived from ${dbcommonlr1uat}.bmt_cust_rates_dmnsn").drop("prmry_prcg_cnd").withColumnRenamed("prmry_prcg_cnd_derived", "prmry_prcg_cnd")

    val ptnrrtdf = spark.sql(s"select *,case when length(trim(prmry_prcg_cnd)) = 0 then null else prmry_prcg_cnd end as prmry_prcg_cnd_derived from ${dbcommonlr1uat}.bmt_ptnr_rates_dmnsn").drop("prmry_prcg_cnd").withColumnRenamed("prmry_prcg_cnd_derived", "prmry_prcg_cnd")

    val plrtdf = spark.sql(s"select *,case when length(trim(prmry_prcg_cnd)) = 0 then null else prmry_prcg_cnd end as prmry_prcg_cnd_derived from ${dbcommonlr1uat}.bmt_pl_rates_dmnsn").drop("prmry_prcg_cnd").withColumnRenamed("prmry_prcg_cnd_derived", "prmry_prcg_cnd")

    val slsordratecondition = when(
      col("sls_ord_rates.fscl_yr_mth_cd").isNull || lower(col("sls_ord_rates.fscl_yr_mth_cd")) === "all",
      col("sls_spmt.e1edk01_idoc_dcmt_nr") === col("sls_ord_rates.sls_ord_id") && col("sls_spmt.pft_cntr_nm") === col("sls_ord_rates.pft_cntr_cd")
        && col("sls_spmt.rtm") === col("sls_ord_rates.rte_to_mkt_cd") && col("sls_spmt.rtm") === col("sls_ord_rates.rte_to_mkt_cd")).
      otherwise(col("sls_spmt.e1edk01_idoc_dcmt_nr") === col("sls_ord_rates.sls_ord_id") && col("sls_spmt.pft_cntr_nm") === col("sls_ord_rates.pft_cntr_cd")
        && col("sls_spmt.rtm") === col("sls_ord_rates.rte_to_mkt_cd") && col("sls_spmt.rtm") === col("sls_ord_rates.rte_to_mkt_cd")
        && col("sls_spmt.fscl_yr_mth_cd") === col("sls_ord_rates.fscl_yr_mth_cd"))

    val prodratecondition = when(
      col("prod_rates.fscl_yr_mth_cd").isNull || lower(col("prod_rates.fscl_yr_mth_cd")) === "all",
      col("sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2") === col("prod_rates.prod_id") && col("sls_spmt.sg_level_3") === col("prod_rates.sgm_lvl_3_cd")
        && col("sls_spmt.rtm") === col("prod_rates.rte_to_mkt_cd") && col("sls_spmt.rtm") === col("prod_rates.rte_to_mkt_cd")).
      otherwise(col("sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2") === col("prod_rates.prod_id") && col("sls_spmt.sg_level_3") === col("prod_rates.sgm_lvl_3_cd")
        && col("sls_spmt.rtm") === col("prod_rates.rte_to_mkt_cd") && col("sls_spmt.rtm") === col("prod_rates.rte_to_mkt_cd")
        && col("sls_spmt.fscl_yr_mth_cd") === col("prod_rates.fscl_yr_mth_cd"))

    val custratecondition = when(
      (col("cust_rates.fscl_yr_mth_cd").isNull || lower(col("cust_rates.fscl_yr_mth_cd")) === "all") && (col("cust_rates.prmry_prcg_cnd").isNull || lower(col("cust_rates.prmry_prcg_cnd")) === "all"),
      col("sls_spmt.end_cust_prty_id") === col("cust_rates.prty_id") && col("sls_spmt.pft_cntr_nm") === col("cust_rates.pft_cntr_cd")
        && col("sls_spmt.sg_level_3") === col("cust_rates.sgm_lvl_3_cd") && upper(col("sls_spmt.rtm")) === upper(col("cust_rates.rte_to_mkt_cd"))).
      when(
        (col("cust_rates.prmry_prcg_cnd").isNull || lower(col("cust_rates.prmry_prcg_cnd")) === "all") && (col("cust_rates.fscl_yr_mth_cd").isNotNull || lower(col("cust_rates.fscl_yr_mth_cd")) =!= "all"),
        upper(col("sls_spmt.end_cust_prty_id")) === upper(col("cust_rates.prty_id"))
          && upper(col("sls_spmt.pft_cntr_nm")) === upper(col("cust_rates.pft_cntr_cd")) && upper(col("sls_spmt.sg_level_3")) === upper(col("cust_rates.sgm_lvl_3_cd"))
          && upper(col("sls_spmt.rtm")) === upper(col("cust_rates.rte_to_mkt_cd"))
          && upper(col("sls_spmt.fscl_yr_mth_cd")) === upper(col("cust_rates.fscl_yr_mth_cd"))).
        when(
          (col("cust_rates.fscl_yr_mth_cd").isNull || lower(col("cust_rates.fscl_yr_mth_cd")) === "all") && (col("cust_rates.prmry_prcg_cnd").isNotNull || lower(col("cust_rates.prmry_prcg_cnd")) =!= "all"),
          col("sls_spmt.end_cust_prty_id") === col("cust_rates.prty_id") && col("sls_spmt.pft_cntr_nm") === col("cust_rates.pft_cntr_cd")
            && col("sls_spmt.sg_level_3") === col("cust_rates.sgm_lvl_3_cd") && upper(col("sls_spmt.rtm")) === upper(col("cust_rates.rte_to_mkt_cd")) && col("sls_spmt.prmry_prcg_cndn_cd") === col("cust_rates.prmry_prcg_cnd")).
          otherwise(col("sls_spmt.end_cust_prty_id") === col("cust_rates.prty_id") && col("sls_spmt.pft_cntr_nm") === col("cust_rates.pft_cntr_cd")
            && col("sls_spmt.sg_level_3") === col("cust_rates.sgm_lvl_3_cd") && upper(col("sls_spmt.rtm")) === upper(col("cust_rates.rte_to_mkt_cd"))
            && col("sls_spmt.fscl_yr_mth_cd") === col("cust_rates.fscl_yr_mth_cd") && upper(col("sls_spmt.prmry_prcg_cndn_cd")) === upper(col("cust_rates.prmry_prcg_cnd")))

    val ptrnratecondition = when(
      (col("ptnr_rates.fscl_yr_mth_cd").isNull || lower(col("ptnr_rates.fscl_yr_mth_cd")) === "all") && (col("ptnr_rates.prmry_prcg_cnd").isNull || lower(col("ptnr_rates.prmry_prcg_cnd")) === "all"),
      col("sls_spmt.e1edka1_ptnr_nr_ag") === col("ptnr_rates.prty_id") && col("sls_spmt.pft_cntr_nm") === col("ptnr_rates.pft_cntr_cd")
        && col("sls_spmt.sg_level_3") === col("ptnr_rates.sgm_lvl_3_cd") && upper(col("sls_spmt.rtm")) === upper(col("ptnr_rates.rte_to_mkt_cd"))).
      when(
        (col("ptnr_rates.fscl_yr_mth_cd").isNull || lower(col("ptnr_rates.fscl_yr_mth_cd")) === "all") && (col("ptnr_rates.prmry_prcg_cnd").isNotNull || lower(col("ptnr_rates.prmry_prcg_cnd")) =!= "all"),
        col("sls_spmt.e1edka1_ptnr_nr_ag") === col("ptnr_rates.prty_id") && col("sls_spmt.pft_cntr_nm") === col("ptnr_rates.pft_cntr_cd")
          && col("sls_spmt.sg_level_3") === col("ptnr_rates.sgm_lvl_3_cd") && upper(col("sls_spmt.rtm")) === upper(col("ptnr_rates.rte_to_mkt_cd"))
          && upper(col("sls_spmt.prmry_prcg_cndn_cd")) === upper(col("ptnr_rates.prmry_prcg_cnd"))).
        when((col("ptnr_rates.prmry_prcg_cnd").isNull || lower(col("ptnr_rates.prmry_prcg_cnd")) === "all")
          && (col("ptnr_rates.fscl_yr_mth_cd").isNotNull || lower(col("ptnr_rates.fscl_yr_mth_cd")) =!= "all"), col("sls_spmt.end_cust_prty_id") === col("ptnr_rates.prty_id")
          && col("sls_spmt.pft_cntr_nm") === col("ptnr_rates.pft_cntr_cd") && col("sls_spmt.sg_level_3") === col("ptnr_rates.sgm_lvl_3_cd")
          && upper(col("sls_spmt.rtm")) === upper(col("ptnr_rates.rte_to_mkt_cd")) && col("sls_spmt.fscl_yr_mth_cd") === col("ptnr_rates.fscl_yr_mth_cd")).
        otherwise(col("sls_spmt.end_cust_prty_id") === col("ptnr_rates.prty_id") && col("sls_spmt.pft_cntr_nm") === col("ptnr_rates.pft_cntr_cd")
          && col("sls_spmt.sg_level_3") === col("ptnr_rates.sgm_lvl_3_cd") && upper(col("sls_spmt.rtm")) === upper(col("ptnr_rates.rte_to_mkt_cd"))
          && col("sls_spmt.fscl_yr_mth_cd") === col("ptnr_rates.fscl_yr_mth_cd") && upper(col("sls_spmt.prmry_prcg_cndn_cd")) === upper(col("ptnr_rates.prmry_prcg_cnd")))

    val plratecondition = when(
      (col("pl_rates.fscl_yr_mth_cd").isNull || lower(col("pl_rates.fscl_yr_mth_cd")) === "all") && (col("pl_rates.prmry_prcg_cnd").isNull || lower(col("pl_rates.prmry_prcg_cnd")) === "all"),
      col("sls_spmt.pft_cntr_nm") === col("pl_rates.pft_cntr_cd") && col("sls_spmt.sg_level_3") === col("pl_rates.sgm_lvl_3_cd")
        && upper(col("sls_spmt.rtm")) === upper(col("pl_rates.rte_to_mkt_cd"))).
      when(
        (col("pl_rates.fscl_yr_mth_cd").isNull || lower(col("pl_rates.fscl_yr_mth_cd")) === "all") && (col("pl_rates.prmry_prcg_cnd").isNotNull || lower(col("pl_rates.prmry_prcg_cnd")) =!= "all"),
        col("sls_spmt.pft_cntr_nm") === col("pl_rates.pft_cntr_cd") && col("sls_spmt.sg_level_3") === col("pl_rates.sgm_lvl_3_cd")
          && upper(col("sls_spmt.rtm")) === upper(col("pl_rates.rte_to_mkt_cd")) && upper(col("sls_spmt.prmry_prcg_cndn_cd")) === upper(col("pl_rates.prmry_prcg_cnd"))).
        when(
          (col("pl_rates.prmry_prcg_cnd").isNull || lower(col("pl_rates.prmry_prcg_cnd")) === "all") && (col("pl_rates.fscl_yr_mth_cd").isNotNull || lower(col("pl_rates.fscl_yr_mth_cd")) =!= "all"),
          col("sls_spmt.pft_cntr_nm") === col("pl_rates.pft_cntr_cd") && col("sls_spmt.sg_level_3") === col("pl_rates.sgm_lvl_3_cd")
            && upper(col("sls_spmt.rtm")) === upper(col("pl_rates.rte_to_mkt_cd")) && col("sls_spmt.fscl_yr_mth_cd") === col("pl_rates.fscl_yr_mth_cd")).
          otherwise(col("sls_spmt.pft_cntr_nm") === col("pl_rates.pft_cntr_cd") && col("sls_spmt.sg_level_3") === col("pl_rates.sgm_lvl_3_cd")
            && col("sls_spmt.rtm") === col("pl_rates.rte_to_mkt_cd") && col("sls_spmt.fscl_yr_mth_cd") === col("pl_rates.fscl_yr_mth_cd")
            && col("sls_spmt.prmry_prcg_cndn_cd") === col("pl_rates.prmry_prcg_cnd"))

    val ratedf = slsshpdf.as("sls_spmt").join(broadcast(slsordrtdf).as("sls_ord_rates"), slsordratecondition, "left").
      join(broadcast(bmtprodrtdf).as("prod_rates"), prodratecondition, "left").
      join(broadcast(custrtdf).as("cust_rates"), custratecondition, "left").
      join(broadcast(ptnrrtdf).as("ptnr_rates"), ptrnratecondition, "left").
      join(broadcast(plrtdf).as("pl_rates"), plratecondition, "left")

    val ratedfwithrates = ratedf.withColumn("ratecodevar", when(col("sls_ord_rates.rate_cd").isNotNull, col("sls_ord_rates.rate_cd")).
      when(col("prod_rates.rate_cd").isNotNull, col("prod_rates.rate_cd")).
      when(col("cust_rates.rate_cd").isNotNull, col("cust_rates.rate_cd")).
      when(col("ptnr_rates.rate_cd").isNotNull, col("ptnr_rates.rate_cd")).
      when(col("pl_rates.rt").isNotNull, col("pl_rates.rt")).otherwise(1)).
      withColumn("totalcostsalesratevar", when(col("sls_ord_rates.totl_cst_sls_rate_cd").isNotNull, col("sls_ord_rates.totl_cst_sls_rate_cd")).
        when(col("prod_rates.totl_cst_sls_rate_cd").isNotNull, col("prod_rates.totl_cst_sls_rate_cd")).
        when(col("cust_rates.totl_cst_sls_rate_cd").isNotNull, col("cust_rates.totl_cst_sls_rate_cd")).
        when(col("ptnr_rates.totl_cst_sls_rate_cd").isNotNull, col("ptnr_rates.totl_cst_sls_rate_cd")).
        when(col("pl_rates.totl_cst_sls_rate_cd").isNotNull, col("pl_rates.totl_cst_sls_rate_cd")).otherwise(1)).
      withColumn("entrsstdcstratevar", when(col("sls_ord_rates.entrs_std_cst_rate_cd").isNotNull, col("sls_ord_rates.entrs_std_cst_rate_cd")).
        when(col("prod_rates.entrs_std_cst_rate_cd").isNotNull, col("prod_rates.entrs_std_cst_rate_cd")).
        when(col("cust_rates.entrs_std_cst_rate_cd").isNotNull, col("cust_rates.entrs_std_cst_rate_cd")).
        when(col("ptnr_rates.entrs_std_cst_rate_cd").isNotNull, col("ptnr_rates.entrs_std_cst_rate_cd")).
        when(col("pl_rates.entrs_std_cst_rate_cd").isNotNull, col("pl_rates.entrs_std_cst_rate_cd")).otherwise(1)).
      withColumn("rt_cnvsn_src", when(col("sls_ord_rates.rate_cd").isNotNull, "sales order rates").
        when(col("prod_rates.rate_cd").isNotNull, "product rates").
        when(col("cust_rates.rate_cd").isNotNull, "customer rates").
        when(col("ptnr_rates.rate_cd").isNotNull, "partner rates").
        when(col("pl_rates.rt").isNotNull, "pl rates").otherwise("NA")).
      withColumn("nt_prc_rt", when(col("sls_ord_rates.net_prc_rate").isNotNull, col("sls_ord_rates.net_prc_rate")).
        when(col("prod_rates.net_prc_rate").isNotNull, col("prod_rates.net_prc_rate")).
        when(col("cust_rates.net_prc_rate").isNotNull, col("cust_rates.net_prc_rate")).
        when(col("ptnr_rates.net_prc_rate").isNotNull, col("cust_rates.net_prc_rate")).
        when(col("pl_rates.net_prc_rate").isNotNull, col("pl_rates.net_prc_rate")).otherwise(1)).
      withColumn("grs_rvn_rt", when(col("sls_ord_rates.grs_rvn_rate").isNotNull, col("sls_ord_rates.grs_rvn_rate")).
        when(col("prod_rates.grs_rvn_rate").isNotNull, col("prod_rates.grs_rvn_rate")).
        when(col("cust_rates.grs_rvn_rate").isNotNull, col("cust_rates.grs_rvn_rate")).
        when(col("ptnr_rates.grs_rvn_rate").isNotNull, col("ptnr_rates.grs_rvn_rate")).
        when(col("pl_rates.grs_rvn_rate").isNotNull, col("pl_rates.grs_rvn_rate")).otherwise(1)).
      select("nt_prc_rt", "grs_rvn_rt", "e1edk01_idoc_dcmt_nr", "e1edp01_itm_nr", "ratecodevar", "totalcostsalesratevar", "entrsstdcstratevar", "rt_cnvsn_src", "rvn_rcgn_cntrct_id", "prfm_obgn_id", "sls_spmt.pft_cntr_nm", "rtm", "sgmnt_cd").distinct

    /*
     * ratetable/ratedfwithrates - will have rates corresponding to each orders present in sales shipment dimension
     *
     */

    ratedfwithrates.createOrReplaceTempView("rate_tbl")

    /*
     * copa field selection
     *
     */

    val optg = spark.sql(s"""
    select
	    concat_ws("-",optg_concern.itm_frm_rfnc_dcmt_copa_nr,optg_concern.rfnc_dcmt_copa_ln_itm_nr) as copa_order_number_item_number_key,
	    optg_concern.rfnc_dcmt_copa_ln_itm_nr,
	    optg_concern.itm_frm_rfnc_dcmt_copa_nr,
	    optg_concern.pftblty_anlys_hdr_tbl_co_cd,
	    optg_concern.sls_qty_amt,
	    optg_concern.cst_cntr_cd,
	    (coalesce(optg_concern.pkgg_amt,0) + coalesce(optg_concern.rw_matspare_prts_amt,0) + coalesce(optg_concern.masking_amt,0) + coalesce(emr_cst_amt,0) + coalesce(optg_concern.vrnc_adjmt_amt,0) + coalesce(optg_concern.fnshd_mtrls_amt,0) + coalesce(optg_concern.hpe_ovrhd_amt,0) + coalesce(optg_concern.vndr_rebates_amt,0) + coalesce(optg_concern.rylty_amt,0) + coalesce(optg_concern.fin_brdn_amt,0) + coalesce(optg_concern.lohp_amt,0) + coalesce(optg_concern.sub_asbly_contmfg_amt,0)) as estimated_sales_cost
    from
	  ${dbfinancname}.optg_concern_fact optg_concern
    where
	    optg_concern.cnld_dcmt_cd is null
	    and optg_concern.cnld_dcmt_it_1_cd is null
	    and optg_concern.cnld_subnumber_ln_itm_nr is null
	    and optg_concern.dltd_by_dcmt_cd is null
	    and optg_concern.dltd_by_itm_cd is null
	    and lower(optg_concern.rec_typ_cd) = 'a'
	    and optg_concern.curr_typ_and_valtn_vw_cd = '30'
    """)

    optg.createOrReplaceTempView("optgcopa")

    /*
     * order conditional item field selection
     *
     */

    val ordconditionaldmnsn = spark.sql(s"""
    select 
      e1edk01_idoc_dcmt_nr,
      e1edp01_itm_nr,
      idoc_nr,
      e1edp05_fx_surchargediscount_totl_grs_nm,
      e1edp05_fx_surchargediscount_totl_grs_nm_usd
    from ${dbcommonlr1uat}.ord_conditional_itm_dmnsn
    where
     e1edp05_cndn_typ_coded_cd = 'EK02'
    """)

    ordconditionaldmnsn.createOrReplaceTempView("ord_conditional_itm_dmnsn")

    /*
     * country name derivation
     *
     */

    val bmtcntrynm = spark.sql(s"select * from ${dbcommonlr1uat}.bmt_cntry_nm_dmnsn order by rl_id asc")

    val bmtcntrynmrefined = bmtcntrynm.withColumn("input_table", when(col("inp_tl") === "NA", col("inp_fld")).
      otherwise(concat(col("inp_tl"), lit("."), col("inp_fld")))).withColumn("output_field", when(col("opt_tbl") === "NA", col("opt_fld")).
      otherwise(concat(col("opt_tbl"), lit("."), col("opt_fld"))))

    val bmtcntrynmds = bmtcntrynmrefined.collect.map(c => " when " + c(19) + " " + c(5) + " (" + c(6) + ") then " + c(20))

    var countryname = "case"

    for (i <- 0 to (bmtcntrynmds.length - 1)) { if (bmtcntrynmds(i).contains("'Unknown GEO'")) countryname += " else 'unkown geo' end" else countryname += bmtcntrynmds(i) }

    logger.info("+++++++######### country name condition: " + countryname)

    /*
     * rar deff item column selection and fiscal yr calculation
     *
     */

    val rardeffitemdf = spark.sql(s"""
    select distinct
      rvn_rcncltn_ky,
      net_revenues_sumrvn_dlta_amt,
      curr_ky,
      prfm_obgn_id,
      rvn_rcgn_cntrct_id,
      net_revenues_sumrvn_pstd_qty as rvn_pstd_qty,
      total_cost_of_sales_sumrvn_dlta_amt,
      null as src_acct_nr,
      etry_ltst_ind,
      ststcs_us_cndn_ind,
      prcg_or_cstg_cndn_ind,
			case
				when substr(substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7),6,7)== '01' then concat(cast((cast(substr(substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7),1,4) as int))-1 as string),'11')
				when substr(substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7),6,7)== '02' then concat(cast((cast(substr(substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7),1,4) as int))-1 as string),'12')
				else concat(substr(substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7),	1, 4),
				case
					when ((cast(substr(substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7),	6,7) as int))-2)<10 then concat('0',cast((cast(substr(substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7),6,7) as int))-2 as string))
					else cast((cast(substr(substring(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky, 1, 7),	6,7) as int))-2 as string)
			  end)
		  end as clndr_yr_prd,
		  entrs_lgl_ent_ldgr_cd as entrs_lgl_ent_ldgr_cd,
		  enterprise_standard_cost_total_sumrvn_dlta_amt,
		  total_cost_of_sales_sumrvn_dlta_amt,
		  gross_trade_revenues_sumrvn_dlta_amt
		from ${dbfinancnamelr1uat}.rvn_rcgn_defrd_itm_pvt_dmnsn as rvn_rcgn_dfrd_itm_dmnsn
		""")

    rardeffitemdf.createOrReplaceTempView("rvn_rcgn_dfrd_itm_dmnsn")

    /*
     * three and twelve month budget currency
     *
     */

    val dfrdthreetwelvemonthdf = spark.sql(s"""
    select
			distinct entrs_lgl_ent_ldgr_cd,
		  pft_cntr_cd,
			mgmt_grphy_unt_cd,
			tc_cd,
			fscl_yr_nr,
			case
				when length(pstg_prd_nr)= 1 then concat('00',pstg_prd_nr)
				else concat('0',pstg_prd_nr)
			end as pstg_prd_nr,
			three_mnth_rate,
			twelve_mnth_rate
		from
			${dbfinancnamelr1uat}.three_twelve_month_dmnsn_srvc_curr as dfrd_three_twelve_month
    """)

    dfrdthreetwelvemonthdf.createOrReplaceTempView("dfrd_three_twelve_month")

    /*
     * CCB#473 Estd Revenue
     *
     */

    val estdRvnDF = spark.sql(s"""
    SELECT
    rvn_rcgn_cntrct_id,
    prfm_obgn_id,
    rcncltn_ky,
    net_revenues,
    gross_trade_revenues,
    curr_ky,
    total_cost_of_sales,
    enterprise_standard_cost
    FROM
      ${dbfinancnamelr1uat}.rvn_rcgn_estd_pvt_dmnsn
    WHERE
      CAST(concat(substr(rcncltn_ky,0,4),
      CASE 
        WHEN (substr(rcncltn_ky,5,3)) IN ('001','002','003') THEN '1' 
        WHEN (substr(rcncltn_ky,5,3)) IN ('004','005','006') THEN '2'
        WHEN (substr(rcncltn_ky,5,3)) IN ('007','008','009' ) THEN '3' 
        WHEN (substr(rcncltn_ky,5,3)) IN ('010','011','012' ) THEN '4' 
      ELSE NULL 
      END
      ) AS INT) >= ${fscl_yr_prd_con}
      """)

    estdRvnDF.createOrReplaceTempView("rvn_rcgn_estd_pvt_dmnsn")

    /*
 * salesshipmentdf data frame: contains data from sales shipment table and rar tables
 *
 */
    val salesshipmentdf = spark.sql(s"""
select
	distinct crc64(lower(concat(coalesce(sls_spmt.e1edk01_idoc_dcmt_nr, ""), coalesce(sls_spmt.e1edp01_itm_nr, ""), coalesce(sls_spmt.sm_sm_id, ""), coalesce(sls_spmt.sm_dtl_sm_itm_nr, ""), coalesce(sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr, ""), coalesce(sls_spmt.sls_blng_itm_e1edp01_itm_nr, ""), coalesce(rvn_rcgn_mppg_dmnsn.rvn_rcgn_cntrct_id, ""), coalesce(rvn_rcgn_mppg_dmnsn.prfm_obgn_id, ""),coalesce(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,""),coalesce(sls_spmt.rptg_mtrl_id_id,""),coalesce(sls_spmt.eurofit_flag,""),coalesce(sls_spmt.eurofit_ctry_cd,""),coalesce(sls_spmt.dor_nr,""),coalesce(rvn_rcgn_pstg_dmnsn.curr_ky,"")))) as secrd_rpt_fact_ky,
	crc32(lower(coalesce(sls_spmt.e1edka1_ptnr_nr_zc, ""))) as mdm_cust_ky,
	crc32(lower(coalesce(sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2, ""))) as pdm_mtrl_mstr_grp_ky,
	crc32(lower(coalesce(sls_spmt.pft_cntr_nm, ""))) as pft_cntr_ky,
	crc32(lower(coalesce(sls_spmt.sgmnt_cd, ""))) as mgmt_grphy_unt_ky,
	null as fnctl_ar_ky,
	crc32(lower(coalesce(sls_spmt.transaction_country, ""))) as cntry_ky,
	crc32(lower(coalesce(sls_spmt.e1edka1_ptnr_nr_ag, ""))) as sld_to_ky,
	crc32(lower(coalesce(sls_spmt.e1edka1_ptnr_nr_we, ""))) as shp_to_ky,
	crc32(lower(coalesce(sls_spmt.e1edka1_ptnr_nr_re, ""))) as bll_to_ky,
	crc32(lower(coalesce(sls_spmt.deal_id_nm, ""))) as deal_ky,
	crc32(lower(coalesce(sls_spmt.zord_header_opty_id, ""))) as opty_ky,
	crc32(lower(coalesce(sls_spmt.e1edk01_idoc_dcmt_nr, ""))) as ord_hdr_ky,
	crc32(lower(concat(coalesce(sls_spmt.e1edk01_idoc_dcmt_nr, ""), coalesce(sls_spmt.e1edp01_itm_nr, "")))) as ord_itm_ky,
	sls_spmt.e1edk03_ido_1_id_25 as cldr_rpt_ky,
	sls_spmt.e1edk01_idoc_dcmt_nr as sls_ord_id,
	sls_spmt.e1edp01_itm_nr as sls_ord_ln_itm_id,
	sls_spmt.zord_header_opty_id as opty_id,
	sls_spmt.deal_id_nm as deal_id,
	sls_spmt.collective_sd_nr as mkt_rte_cd,
	sls_spmt.e1edk14_idoc_org_nm_12 as ord_typ_cd,
	crc32(lower(coalesce(sls_spmt.e1edk14_idoc_org_nm_12,''))) as odr_typ_ky,
	sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 as mtrl_nr,
	'SERP' as src_sys_cd,
	cast(from_unixtime(unix_timestamp(cast(sls_spmt.utc_ts_lg_form_cd as string),'yyyyMMddhhmmss')) as timestamp) as src_sys_ts,
	sls_spmt.e1edk03_ido_1_id_25 as ord_crt_dt,-- changed 2/19
	cast(from_unixtime(unix_timestamp(concat(sls_spmt.e1edk03_ido_1_id_25,sls_spmt.e1edk03_ido_2_id_25),'yyyy-MM-ddhh:mm:ss')) as timestamp) as ord_crt_ts,	-- changed 2/19
	sls_spmt.last_chg_dt as ord_last_chg_dt,
	sls_spmt.dt_and_ts as hp_rcvd_dt_txt,
	from_unixtime(unix_timestamp(sls_spmt.dt_and_ts,'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:mm:ss') as hp_rcvd_dt,
	sls_spmt.lgcy_qt_nr as quote_id,
	sls_spmt.e1eds01_totl_vl_sum_sgm_nm_2 as ord_net_vl_amt,-- changed 2/14
	sls_spmt.e1edk01_curr_cd as ord_dcmnt_curr_cd,
	case
		when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0
		else sls_spmt.e1eds01_totl_vl_sum_sgm_nm_2_usd
	end as ord_hddr_nt_vl_usd_amt,
	sls_spmt.e1edk14_idoc_org_nm_8 as sls_orgn_cd,
	sls_spmt.dbn_chnl_cd as dstbn_chnl_cd,
	sls_spmt.zord_item01_dvsn_cd as dvsn_cd,-- check the derivation from soss
	sls_spmt.e1edk14_idoc_org_nm_10 as sls_grp_cd,
	sls_spmt.e1edk14_idoc_org_nm_16 as sls_offc_cd,
	sls_spmt.e1edp02_idoc_dcmt_nr_1 as cust_po_nr,
	sls_spmt.e1edka1_ptnr_nr_ag as sld_to_cd,
	sls_spmt.e1edka1_ptnr_nr_we as shp_to_cd,
	sls_spmt.e1edka1_ptnr_nr_zc as end_cust_cd,
	sls_spmt.e1edka1_ptnr_nr_re as bll_to_cd,
	sls_spmt.e1edk01_dlvry_blck_dcmt_hdr_cd as ord_dlvry_cd,
	sls_spmt.prchg_agrmnt_nm as ord_prch_cd,
	sls_spmt.zord_header_usr_stts_nm as ord_hddr_stts_cd,-- 
	sls_spmt.zord_itm_usr_status as ord_itm_stts_cd,
	sls_spmt.sls_ord_itm_lvl_hld_cd as mtrl_str_cd,
	case
		when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0
		else sls_spmt.sls_ord_totl_qty_cd
	end as ord_itm_qty,--changed 2/14
	sls_spmt.e1edp01_prc_nt_nm as nt_prc_amt,
	case 
	  when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0
	  else sls_spmt.nt_xtnd_sls_spmt_dcmt_amt_frm_src_cd
	end as ord_itm_nt_vl_amt,-- changed 4/3
	sls_spmt.e1edp01_curr_cd as ord_itm_dcmt_curr_cd,
	CASE
	  WHEN UPPER(sls_spmt.e1edp01_curr_cd) = 'USD' THEN sls_spmt.e1edp01_prc_nt_nm 
	  ELSE  sls_spmt.e1edp01_prc_nt_nm * sls_spmt.gbl_curr_exch_rate_cd
	END as nt_prc_usd_amt,-- validate it
	sls_spmt.nt_xtnd_sls_spmt_gbl_amt_frm_src_cd as ord_itm_nt_vl_usd_amt,-- changed 2/17
	sls_spmt.e1edp01_plnt_cd as plnt_cd,
	--cast(from_unixtime(unix_timestamp(concat(e1edp03_dt_25,' ',coalesce(e1edp03_tm_cd_25,'00:00:00')),'yyyy-MM-dd hh:mm:ss')) as timestamp) as ord_itm_crt_ts,
	sls_spmt.e1edk03_ido_2_id_25 as ord_itm_crt_ts, 
	sls_spmt.pft_cntr_nm as prft_cntr_cd,
	sls_spmt.sgmnt_cd as sgmtl_rptg_cd,
	segment_std_hrchy.sg_level_3 as sgm_lvl_2,
	segment_std_hrchy.sg_level_4 as sgm_lvl_3,
	segment_std_hrchy.sg_level_5 as sgm_lvl_4,
	segment_std_hrchy.sg_level_6 as sgm_lvl_5,
	segment_std_hrchy.sg_level_7 as sgm_lvl_6,
	segment_std_hrchy.sg_level_8 as sgm_lvl_7,
	--sls_spmt.zord_header_sys_stts_ln_nm as sys_stts_cd,
	sls_spmt.gnrl_incmpltn_stts_hdr_cd as sys_stts_cd,
	--sls_spmt.zord_item_sys_stts_ln_nm as sys_stts_ln_cd,
	sls_spmt.totl_incmpltn_stts_all_itms_gnrl_cd as sys_stts_ln_cd,
	rvn_rcgn_mppg_dmnsn.rvn_acctng_itm_src_dcmt_hdr_id as rvn_acctng_itm_src_dcmt_hdr_id,
	sls_spmt.blng_blck_cd as blng_blck_sd_dcmt_cd,
	from_unixtime(unix_timestamp(sls_spmt.e1edk03_ido_1_id_2,'yyyyMMdd'),'yyyy-MM-dd') as crdd_cust_rqst_dt,
	sls_spmt.e1edka1_ptnr_nr_z1 as rslr_nr,
	sls_spmt.zord_item_bndl_id as bndl_id,
	sls_spmt.bndl_qty as bndl_qty_cd,
	sls_spmt.zord_header_alrt_sls_ord_to_sfd_2_nm as hdr_hold_cd,
	sls_spmt.sls_ord_itm_lvl_hld_cd as itm_hold_cd,
	sls_spmt.srv_agrmnt_id_sa_id_id as srv_agrmnt_id,
	sls_spmt.sm_sm_id as dlvry_id,
	sls_spmt.sm_dtl_sm_itm_nr as dlvry_itm_id,
	sls_spmt.actl_gds_mvmt_dt as actl_dlvry_dt,
	sls_spmt.sm_actl_gds_mvmt_dt as sm_actl_gds_mvmt_dt,
	sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr as invc_id,
	sls_spmt.sls_blng_itm_e1edp01_itm_nr as invc_ln_itm_id,
	from_unixtime(unix_timestamp(sls_spmt.e1edp03_dt_25,'yyyyMMdd'),'yyyy-MM-dd') as actl_inv_dt,
	case
		when sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 like '%#%' then 0
		else
		(case
			when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0
			else sls_spmt.sls_ord_totl_qty_cd
		end)
	end as base_qty,
	sls_spmt.actl_qty_dlvrd_sls_unts as unt_qty,
	sls_spmt.e1edp26_totl_vl_sum_sgm_nm_3 as nt_inv_vl_amt,-- validate it
	sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 as grs_inv_vl_amt,-- validate it
	(sls_spmt.e1edp26_totl_vl_sum_sgm_nm_3 * sls_spmt.gbl_curr_exch_rate_cd) as cp_net_inv_usd_amt,-- validate it
	(sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 * sls_spmt.gbl_curr_exch_rate_cd) as cp_grs_inv_usd_amt,-- validate it
	case
		when
		((case
			when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0
			else sls_spmt.e1eds01_totl_vl_sum_sgm_nm_2
		end) = (sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 - sls_spmt.e1edp26_totl_vl_sum_sgm_nm_3)
		and sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 = 0.00)
		or sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 is null then 'N'
		else 'Y'
	end as crdt_dbt_ind,-- validate it 
	case
		when sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 - sls_spmt.e1edp26_totl_vl_sum_sgm_nm_3 = 0
		or (sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 is null and sls_spmt.e1edp26_totl_vl_sum_sgm_nm_3 is null)  then 'N'
		else 'Y'
	end as dscnt_ind,-- updated 03/30
	case
		when lower(sls_spmt.e1edk02_idoc_dcmt_nr_1) like '%icoem%' then 'Y'
		else 'N'
	end as icoem_ind,
	case
		when sls_spmt.multiyear_po_typ_cd = '0' then 'N'
		when sls_spmt.multiyear_po_typ_cd = '1' then 'Y'
		else sls_spmt.multiyear_po_typ_cd
	end as mlt_yr_ind,
	sls_spmt.prepaid_cntrct_flg_id as prepaid_ind,
	rvn_rcgn_mppg_dmnsn.rvn_rcgn_cntrct_id as cntrct_id,
	rvn_rcgn_mppg_dmnsn.prfm_obgn_id as pob_id,
	CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null then rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky 
	  ELSE NULL
	END as recon_ky_cd,
	CASE
		WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,0,4)
		WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null then substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,0,4)
		ELSE null
	END as fscl_yr_nr,
	CASE
		WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN lpad(cast(substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3) as int),2,'0')
		WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null then lpad(cast(substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,5,3) as int),2,'0')
		ELSE null
	END as fscl_prd_nr,
	CASE
		WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN 
		case
			when (substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3)) in ('001','002','003') then 'Q1'
			when (substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3)) in ('004','005','006') then 'Q2'
			when (substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3)) in ('007','008','009' ) then 'Q3'
			when (substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3)) in ('010','011','012' ) then 'Q4'
			else null
		end
		WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null  THEN 
		case
			when (substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,5,3)) in ('001','002','003') then 'Q1'
			when (substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,5,3)) in ('004','005','006') then 'Q2'
			when (substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,5,3)) in ('007','008','009' ) then 'Q3'
			when (substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,5,3)) in ('010','011','012' ) then 'Q4'
			else null
		end		
		ELSE null
	END as fscl_qtr_nr,
	null as gl_acct_nr,	-- pivoting , hence kept as null
	sls_spmt.eurofit_flag as eurofit_flg_cd,
	sls_spmt.eurofit_split_percentage as eurofit_splt_pct_cd,
	sls_spmt.eurofit_ctry_cd as eurofit_ctry_cd,
	sls_spmt.transaction_country as ctry_cd,	-- can be used for cntry_ky derivation
	icost_dtl_burden_aggregate.icost_dtl_amt as brdn_cst,
	(icost_dtl_burden_aggregate.icost_dtl_amt*sls_spmt.e1edp01_qty_nm_inv) as ttl_brdn_cst,
	(icost_dtl_burden_aggregate.icost_dtl_amt*sls_spmt.actl_qty_dlvrd_sls_unts) as ttl_dly_brdn_cst,
	(icost_dtl_burden_aggregate.icost_dtl_amt*sls_spmt.sales_order_base_quantity) as ttl_base_qty_brdn_cst,	-- validate base qty
	(icost_dtl_burden_aggregate.icost_dtl_amt*sls_spmt.e1edp01_qty_nm_inv) as ttl_inv_brdn_cst,
  CASE 
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN COALESCE(rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumtrsn_curr_amt,0)*COALESCE(sls_spmt.multiplier,1) + COALESCE(rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt,0) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE COALESCE(COALESCE(rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumtrsn_curr_amt,0)*COALESCE(sls_spmt.multiplier,1) , COALESCE(rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt,0) * COALESCE(sls_spmt.multiplier,1))
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN  
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
		END
	  ELSE 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0) + (COALESCE(icost_dtl_burden_aggregate.icost_dtl_amt,0)*COALESCE(sls_spmt.e1edp01_qty_nm_inv,1))
			ELSE COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0) + (COALESCE(icost_dtl_burden_aggregate.icost_dtl_amt,0)*COALESCE(sls_spmt.e1edp01_qty_nm_inv,1))
		END
  END as ttl_cst_sls_amt,
  CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND (rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt IS NOT NULL AND rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt <> 0) then 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
		END 
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND UPPER(rvn_rcgn_dfrd_itm_dmnsn.curr_ky) = 'USD' THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null AND UPPER(rvn_rcgn_estd_pvt_dmnsn.curr_ky) = 'USD' THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)* COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)
		END
	  ELSE 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN (COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0) + (COALESCE(icost_dtl_burden_aggregate.icost_dtl_amt,0)*COALESCE(sls_spmt.e1edp01_qty_nm_inv,1))) * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE (COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0) + (COALESCE(icost_dtl_burden_aggregate.icost_dtl_amt,0)*COALESCE(sls_spmt.e1edp01_qty_nm_inv,1))) * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1)
		END 
  END as ttl_cst_sls_usd_amt,
	--null as grs_mrgn_usd_amt, 	--validate, bring pivoted value
	rt_cnvsn_src as rt_cnvsn_src,
	ratecodevar as rvn_cnvrsn_rt,
	entrsstdcstratevar as entrprs_stndrd_cst_rt,
	totalcostsalesratevar as ttl_cst_sls_rt,
  COALESCE(
  CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND (rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt is not null or rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt <> 0) THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1) 
			ELSE rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL then
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1) 
			ELSE rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.net_revenues * ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1) 
			ELSE rvn_rcgn_estd_pvt_dmnsn.net_revenues * ratecodevar * COALESCE(sls_spmt.multiplier,1)
		END
	  ELSE 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_prfm_obgn_dmnsn.alct_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1) 
			ELSE rvn_rcgn_prfm_obgn_dmnsn.alct_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1)
		END
  END,
  sls_spmt.nt_xtnd_sls_spmt_dcmt_amt_frm_src_cd * ratecodevar) as cp_nt_rvn_amt,
  COALESCE(CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND (rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt is not null or rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt <> 0) THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL then 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
		END 
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.net_revenues * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.net_revenues * COALESCE(sls_spmt.multiplier,1)
		END
	  ELSE 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_prfm_obgn_dmnsn.alct_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_prfm_obgn_dmnsn.alct_amt * COALESCE(sls_spmt.multiplier,1)
		END
  END,sls_spmt.nt_xtnd_sls_spmt_dcmt_amt_frm_src_cd) as nt_rvn_amt,
  COALESCE(CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND (rvn_rcgn_pstg_dmnsn.net_revenues_sumscnd_prll_lcl_curr_amt IS NOT NULL OR rvn_rcgn_pstg_dmnsn.net_revenues_sumscnd_prll_lcl_curr_amt <> 0) THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.net_revenues_sumscnd_prll_lcl_curr_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.net_revenues_sumscnd_prll_lcl_curr_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND UPPER(rvn_rcgn_dfrd_itm_dmnsn.curr_ky) = 'USD' THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * ratecodevar * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1)* ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1)* ratecodevar * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null AND UPPER(rvn_rcgn_estd_pvt_dmnsn.curr_ky) = 'USD' THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.net_revenues * ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.net_revenues * ratecodevar * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.net_revenues * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.net_revenues * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * ratecodevar * COALESCE(sls_spmt.multiplier,1)
		END 
	  ELSE 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_prfm_obgn_dmnsn.alct_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * ratecodevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_prfm_obgn_dmnsn.alct_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * ratecodevar * COALESCE(sls_spmt.multiplier,1) 
		END 
  END,sls_spmt.nt_xtnd_sls_spmt_dcmt_amt_frm_src_cd *ratecodevar * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1)) as cp_nt_rvn_usd_amt,
	case
		when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0
		else sls_spmt.grs_prc_sls_spmt_gbl_curr_amt_cd
	end as cp_grs_usd_amt,
	--case
		--when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0
		--else sls_spmt.grs_prc_sls_spmt_gbl_curr_amt_cd
	--end as grs_mrgn_amt,-- bring data from pivoted rar table
  CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null AND UPPER(rvn_rcgn_estd_pvt_dmnsn.curr_ky) = 'USD' THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1) 
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost* COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost* COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL THEN
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN COALESCE(optg_concern.estimated_sales_cost,COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0)) * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE COALESCE(optg_concern.estimated_sales_cost,COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0)) * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN (rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumscnd_prll_lcl_curr_amt IS NOT NULL AND rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumscnd_prll_lcl_curr_amt <> 0) THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumscnd_prll_lcl_curr_amt * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumscnd_prll_lcl_curr_amt * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1)
		END
	  ELSE 
		CASE
	      WHEN UPPER(rvn_rcgn_dfrd_itm_dmnsn.curr_ky) = 'USD' then 
			CASE 
				WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN (rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt*entrsstdcstratevar) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
				ELSE (rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt*entrsstdcstratevar) * COALESCE(sls_spmt.multiplier,1)
			END
	      ELSE 
			CASE 
				WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
				ELSE rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1)
			END	
		END
  END as cp_entprs_std_cst_usd_amt,-- changed 4/5
    CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null AND UPPER(rvn_rcgn_estd_pvt_dmnsn.curr_ky) = 'USD' THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN COALESCE(optg_concern.estimated_sales_cost,COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0)) * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1)  * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE COALESCE(optg_concern.estimated_sales_cost,COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0)) * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1)  * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN (rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumscnd_prll_lcl_curr_amt IS NOT NULL AND rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumscnd_prll_lcl_curr_amt <> 0) THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumscnd_prll_lcl_curr_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumscnd_prll_lcl_curr_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.multiplier,1)
		END	
	  ELSE 
		CASE
	      WHEN UPPER(rvn_rcgn_dfrd_itm_dmnsn.curr_ky) = 'USD' then 
		  CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1)
		  END
	      ELSE 
			CASE 
				WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
				ELSE rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)
			END
		END
  END as entprs_std_cst_usd_amt,
  CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN entrsstdcstratevar * COALESCE(optg_concern.estimated_sales_cost,COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0)) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE entrsstdcstratevar * COALESCE(optg_concern.estimated_sales_cost,COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0)) * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN (rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumtrsn_curr_amt IS NOT NULL AND rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumtrsn_curr_amt <> 0) THEN
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN  rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumtrsn_curr_amt * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumtrsn_curr_amt * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1)
		END
	  ELSE 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * entrsstdcstratevar * COALESCE(sls_spmt.multiplier,1)
		END
  END as cp_entrprs_stndrd_cst,-- changed 4/5
  CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.enterprise_standard_cost * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN COALESCE(optg_concern.estimated_sales_cost,COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0)) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE COALESCE(optg_concern.estimated_sales_cost,COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0)) * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN (rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumtrsn_curr_amt IS NOT NULL AND rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumtrsn_curr_amt <> 0) THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumtrsn_curr_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumtrsn_curr_amt * COALESCE(sls_spmt.multiplier,1)
		END
	  ELSE 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.enterprise_standard_cost_total_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1)
		END
  END as entrprs_stndrd_cst,-- changed 4/5  CASE
  CASE  
	WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND (rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt IS NOT NULL AND rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt <> 0) then 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)
		END
	WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND UPPER(rvn_rcgn_dfrd_itm_dmnsn.curr_ky) = 'USD' THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)* COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)
		END
	WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)
		END
	WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null AND UPPER(rvn_rcgn_estd_pvt_dmnsn.curr_ky) = 'USD' THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)
		END
	WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)
		END
	ELSE 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN (COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0) + (COALESCE(icost_dtl_burden_aggregate.icost_dtl_amt,0)*COALESCE(sls_spmt.e1edp01_qty_nm_inv,1))) * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE (COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0) + (COALESCE(icost_dtl_burden_aggregate.icost_dtl_amt,0)*COALESCE(sls_spmt.e1edp01_qty_nm_inv,1))) * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)
		END
  END as cp_tot_cst_of_sls_usd_amt,	-- changed 2/19
	case
		when sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr is not null and sls_spmt.sm_sm_id is not null then "revenue"
		when sls_spmt.sm_sm_id is not null and sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr is null then "sni"
		when sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr is null and sls_spmt.sm_sm_id is null then "backlog"
		else null
	end as cp_bklg_sni_rvn,
	sls_spmt.shp_to_ctry_cd as shp_to_ctry_cd, -- rename physical col
	sls_spmt.bsn_ty_2_cd as bsn_ty_1_cd, -- rename physical col
	sls_spmt.e1edk35_dta_elmt_typ_char_lgt_35_nm_1 as bsn_rshp_typ_cd,
	sls_spmt.prtl_dlvry_at_itm_lvl_cd as prtl_dlvry_itm_lvl,
	sls_spmt.idoc_nr as src_idoc_nr,
	sls_spmt.upd_gmt_ts as idoc_crt_dt_ts,
	sls_spmt.zord_item01_mtrl_acct_asngmt_cd_grp as acct_asngmt_groupitem_cd,
	sls_spmt.e1edp01_qty_nm_inv as inv_qty_itm_cd,
	sls_spmt.estmd_invc_date as estmd_inv_hdr_dt,
	sls_spmt.estmd_inv_dt as estmd_inv_dt,
	sls_spmt.sls_mtrc_cd as sls_mtrc_cd, -- check source logic
	sls_spmt.ord_durtn_cd as ord_durtn_cd,
  split (
	  case
		  when (sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 is null and lower(sls_spmt.src_type) = 'dor orders') then sls_spmt.bs_prod_id_4_id
		  when lower(sls_spmt.src_type) = 's4 orders' then sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
		  else sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
	  end,'#')[0] as itm_vl_usr_stts_cd, -- 2/19
	case
		when (sls_spmt.prod_id is null
		and lower(sls_spmt.src_type) = 'dor orders') then sls_spmt.prod_id
		when lower(sls_spmt.src_type) = 's4 orders' then sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
		else sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
	end as prod_id,
	sls_spmt.rptg_mtrl_id_id as rptg_mtrl_id_id,
	sls_spmt.pkg_prod_id as pkg_id_id,
	sls_spmt.e1edka1_ctry_ky_cd_z1 as rslr_ctry_ky_cd,
	sls_spmt.e1edka1_ctry_ky_cd_we as gds_rcpnt_ctry_ky_cd,
	sls_spmt.e1edka1_ctry_ky_cd_ag as soldto_prty_ctry_ky_cd,
	sls_spmt.spmt_prf_dlvry_dt as sm_prf_dlvry_cfrn_dt,
	sls_spmt.e1edk03_ido_1_id_22 as prch_ord_dt,
	sls_spmt.rsn_at_ln_itm_cd as rsn_at_ln_itm_cd,
	sls_spmt.intangible_ln_itm_stts_cd as intangible_vs_tangible_id_id,
	sls_spmt.e1edk03_ido_1_id_2 as dcmt_dt,
	sls_spmt.e1edk01_cmplt_dlvry_dfnd_each_sls_ord_cd as dlvry_typ_cnsldt_shp,
	sls_spmt.e1edk01_idoc_dcmt_nr as ord_nr,
	sls_spmt.blng_stts_orderrelated_blng_dcmt_cd as blng_stts_cd,
	sls_spmt.itm_stts_cd as itm_stts_cd,
	sls_spmt.ois_trsn_nr as ois_cd,
	sls_spmt.ord_st_cd as ord_st_opn_vs_clsd_cd,
	sls_spmt.e1edk18_txt_ln_nm_1 as txt_ln_nm,
	sls_spmt.sm_dtl_dlvry_grp_nr as sm_grp_cd,
	sls_spmt.shp_athzn_ltr_nm as shp_athzn_ltr_cd,
	sls_spmt.cntrct_strt_dt as cntrct_strt_dt,
	sls_spmt.cntrct_end_dt as cntrct_end_dt,
	sls_spmt.zord_header_preceding_sls_and_dbn_dcmt_nm as rfrnc_dcmt_nr,
	sls_spmt.e1edk02_itm_nr_11 as rfrnc_dcmt_itm_nr,
	ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm as calc_cst_ek02_amt,
	ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm_usd as calc_cst_ek02_usd_amt,
	sls_spmt.lgcl_dlt_ind as src_sys_upd_ts,
	sls_spmt.lgcl_dlt_ind as src_sys_ky,
	sls_spmt.lgcl_dlt_ind as lgcl_dlt_ind,
	sls_spmt.ins_gmt_ts as ins_gmt_ts,
	sls_spmt.upd_gmt_ts as upd_gmt_ts,
	sls_spmt.src_sys_extrc_gmt_ts as src_sys_extrc_gmt_ts,
	sls_spmt.src_sys_btch_nr as src_sys_btch_nr,
	sls_spmt.fl_nm as fl_nm,
	case
		when ord_dmnsn_adjmt_dmnsn.end_cust_prty_id is null then ope_sls_spmt.ope_end_cust_prty_id
		else ord_dmnsn_adjmt_dmnsn.end_cust_prty_id
	end as cp_end_cust_prty_id,
	case
		when ord_dmnsn_adjmt_dmnsn.mkt_rte_cd is null then ope_sls_spmt.ope_rtm
		else ord_dmnsn_adjmt_dmnsn.mkt_rte_cd
	end as cp_rtm_nm,
	ope_sls_spmt.ope_sldt_prty_id as cp_sldt_prty_id,
	sls_spmt.e1edka1_ptnr_nr_we as cp_shpt_prty_id,
	sls_spmt.pft_cntr_nm as cp_prft_ctr_cd,
	sls_spmt.sgmnt_cd as cp_segment_cd,
	cast ( (
	case
		when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0
		else sls_spmt.actl_qty_dlvrd_stockkeeping_unts
	end) as double) as cp_unit_qty,
	case
		when ord_dmnsn_adjmt_dmnsn.sls_ord_id is null then 'N'
		else 'Y'
	end as fnc_adjmt_ind,
	sls_spmt.exch_rate_nm as exch_rate_frm_src_cd,
	sls_spmt.ld_jb_nr as ld_jb_nr,
	sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd as rsn_rjctn_quotations_and_sls_orders_cd,
	sls_spmt.zord_hdr_ovrl_status as sls_ord_cmpltn_stts_cd,
	sls_spmt.dor_nr as unq_dor_id_id,
	rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt,
	rvn_rcgn_pstg_dmnsn.gross_trade_revenues_sumtrsn_curr_amt,
	rvn_rcgn_pstg_dmnsn.enterprise_standard_cost_total_sumtrsn_curr_amt,
	rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt as dfrd_rvn_dlta_amt,
	rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt as pstg_rvn_dlta_amt,
	rvn_rcgn_pstg_dmnsn.net_revenues_sumscnd_prll_lcl_curr_amt as pstg_usd_rvn_dlta_amt,
	case
		when rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt is null
		or rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt = 0 then 0
		when (substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3)) in ('013','014','015','016') then 0
		when dfrd_three_twelve_month.three_mnth_rate*rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt is not null
		or dfrd_three_twelve_month.three_mnth_rate*rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt <> 0 then dfrd_three_twelve_month.three_mnth_rate*rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt
		else 0
	end as dfrd_three_mnth_avg_amt_cal,
	case
		when rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt is null or rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt = 0 then 0
		when (substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3)) in ('013','014','015','016') then 0
		when dfrd_three_twelve_month.twelve_mnth_rate*rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt is not null or dfrd_three_twelve_month.twelve_mnth_rate*rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt <> 0 then dfrd_three_twelve_month.twelve_mnth_rate*rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt
		else 0
	end as dfrd_twelve_mnth_avg_amt_cal,
	case
		when rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt is null
		or rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt = 0 then 0
		when (substr(rvn_rcgn_pstg_dmnsn.rvn_rcncltn_ky,5,3)) in ('013','014','015','016') then 0
		when pstg_three_twelve_month.three_mnth_rate*rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt is not null
		or pstg_three_twelve_month.three_mnth_rate*rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt <> 0 then pstg_three_twelve_month.three_mnth_rate*rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt
		else 0
	end as pstg_three_mnth_avg_amt_cal,
	case
		when rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt is null
		or rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt = 0 then 0
		when (substr(rvn_rcgn_pstg_dmnsn.rvn_rcncltn_ky,5,3)) in ('013','014','015','016') then 0
		when pstg_three_twelve_month.twelve_mnth_rate*rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt is not null
		or pstg_three_twelve_month.twelve_mnth_rate*rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt <> 0 then pstg_three_twelve_month.twelve_mnth_rate*rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt
		else 0
	end as pstg_twelve_mnth_avg_amt_cal,
	dfrd_bmt_trsn_curr.crr_cd as dfrd_curr_cd,
	pstg_bmt_trsn_curr.crr_cd as pstg_curr_cd,
	rvn_rcgn_dfrd_itm_dmnsn.curr_ky as dfrd_curr_ky,
	rvn_rcgn_pstg_dmnsn.curr_ky as pstg_curr_ky,
	rvn_rcgn_pstg_dmnsn.funtional_ar_cd as fnctl_ar_cd,
	case
		when (month(from_unixtime(unix_timestamp()))= 11
		or month(from_unixtime(unix_timestamp()))= 12) then year(from_unixtime(unix_timestamp()))+ 1
		else year(from_unixtime(unix_timestamp()))
	end as calc_fscl_year,
	optg_concern.pftblty_anlys_hdr_tbl_co_cd as entrs_lgl_ent_ldgr_ky,
	optg_concern.sls_qty_amt as sls_qty_amt,
	crc32(lower(coalesce(optg_concern.cst_cntr_cd, ""))) as cst_cntr_ky,
	optg_concern.cst_cntr_cd as cst_cntr_cd,
	optg_concern.estimated_sales_cost * COALESCE(sls_spmt.multiplier,1) as entrprs_stndrd_cst_grp_curr_usd_amt,
	((coalesce(rvn_rcgn_pstg_dmnsn.net_revenues_sumtrsn_curr_amt,0)+ coalesce(rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt,	0)) * (ratecodevar) - coalesce(optg_concern.estimated_sales_cost,0) ) * COALESCE(sls_spmt.multiplier,1) as fctry_mrgn_amt,
	crc32(lower(concat(coalesce(optg_concern.rfnc_dcmt_copa_ln_itm_nr, ""), coalesce(optg_concern.itm_frm_rfnc_dcmt_copa_nr, "")))) as copa_ky,
	sls_spmt.pkg_prod_id as pkg_prod_id,
	crc32(lower(concat(coalesce(rvn_rcgn_dfrd_itm_dmnsn.prfm_obgn_id, ""), coalesce(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcgn_cntrct_id, "")))) as rar_ky,
	sls_spmt.opt_order_qty as ord_optn_qty,
	sls_spmt.sls_ord_totl_qty_cd as ord_ttl_qty,
	sls_spmt.sales_spmt_base_quantity as smpt_base_qty,
	sls_spmt.sales_spmt_opt_quantity as spmt_optn_qty,
	sls_spmt.sales_spmt_total_quantity as spmt_ttl_qty,
	sls_spmt.e1edp01_higherlevel_itm_bom_structures_cd as hghr_lvl_itm_no_cd,
	COALESCE(split (
	  case
		  when (sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 is null and lower(sls_spmt.src_type) = 'dor orders') then sls_spmt.bs_prod_id_4_id
		  when lower(sls_spmt.src_type) = 's4 orders' then sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
		  else sls_spmt.bs_prod_id_4_id
	end,'#')[1],sls_spmt.rptg_mtrl_opt_cd) as rptg_mtrl_opt_cd,
	sls_spmt.srvs_mtrl_id_id as srvs_mtrl_id_id,
	null as pch_lvl_5 ,
	sls_spmt.ope_fiscal_date as trsn_dt,
	rvn_rcgn_dfrd_itm_dmnsn.rvn_pstd_qty,
	sls_spmt.rte_cd as rte_cd,
  CASE 
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN 						
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') then COALESCE(rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumtrsn_curr_amt,rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE COALESCE(rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumtrsn_curr_amt,rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)
		END	
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') then rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.total_cost_of_sales * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)
		END
	  ELSE 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') then (COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0) + (COALESCE(icost_dtl_burden_aggregate.icost_dtl_amt,0)*COALESCE(sls_spmt.e1edp01_qty_nm_inv,1))) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE (COALESCE(ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm,0) + (COALESCE(icost_dtl_burden_aggregate.icost_dtl_amt,0)*COALESCE(sls_spmt.e1edp01_qty_nm_inv,1))) * totalcostsalesratevar * COALESCE(sls_spmt.multiplier,1)
		END	
  END as cp_ttl_cst_sls_amt,
	sls_spmt.e1edp01_prc_nt_nm*nt_prc_rt as cp_nt_prc_amt,
	CASE
	  WHEN UPPER(sls_spmt.e1edp01_curr_cd) = 'USD' THEN sls_spmt.e1edp01_prc_nt_nm 
	  ELSE  sls_spmt.e1edp01_prc_nt_nm * sls_spmt.gbl_curr_exch_rate_cd * nt_prc_rt
  END as cp_nt_prc_usd_amt,
  COALESCE(
  CASE
    WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND (rvn_rcgn_pstg_dmnsn.gross_trade_revenues_sumtrsn_curr_amt IS NOT NULL AND rvn_rcgn_pstg_dmnsn.gross_trade_revenues_sumtrsn_curr_amt <> 0) THEN
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') then rvn_rcgn_pstg_dmnsn.gross_trade_revenues_sumtrsn_curr_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.gross_trade_revenues_sumtrsn_curr_amt * COALESCE(sls_spmt.multiplier,1)
		END
    WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') then rvn_rcgn_dfrd_itm_dmnsn.gross_trade_revenues_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.gross_trade_revenues_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1)
		END
	WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') then rvn_rcgn_estd_pvt_dmnsn.gross_trade_revenues * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.gross_trade_revenues * COALESCE(sls_spmt.multiplier,1)
		END
	ELSE sls_spmt.grs_prc_sls_spmt_dcmt_curr_amt_cd
  END,sls_spmt.grs_prc_sls_spmt_dcmt_curr_amt_cd) as grs_rvn_amt,
  COALESCE(CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND (rvn_rcgn_pstg_dmnsn.gross_trade_revenues_sumscnd_prll_lcl_curr_amt IS NOT NULL OR rvn_rcgn_pstg_dmnsn.gross_trade_revenues_sumscnd_prll_lcl_curr_amt <> 0) THEN
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.gross_trade_revenues_sumscnd_prll_lcl_curr_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.gross_trade_revenues_sumscnd_prll_lcl_curr_amt * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND UPPER(rvn_rcgn_dfrd_itm_dmnsn.curr_ky) = 'USD' then 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.gross_trade_revenues_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.gross_trade_revenues_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.gross_trade_revenues * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)* COALESCE(sls_spmt.eurofit_multiplier,1) 
			ELSE rvn_rcgn_estd_pvt_dmnsn.gross_trade_revenues * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)
		END
	  ELSE sls_spmt.grs_prc_sls_spmt_gbl_curr_amt_cd * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1)
  END,sls_spmt.grs_prc_sls_spmt_gbl_curr_amt_cd) as grs_rvn_usd_amt,
  COALESCE(CASE
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND (rvn_rcgn_pstg_dmnsn.net_revenues_sumscnd_prll_lcl_curr_amt IS NOT NULL AND rvn_rcgn_pstg_dmnsn.net_revenues_sumscnd_prll_lcl_curr_amt <> 0) THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_pstg_dmnsn.net_revenues_sumscnd_prll_lcl_curr_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_pstg_dmnsn.net_revenues_sumscnd_prll_lcl_curr_amt * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL AND UPPER(rvn_rcgn_dfrd_itm_dmnsn.curr_ky) = 'USD' THEN
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN 
		CASE
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_dfrd_itm_dmnsn.net_revenues_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null AND UPPER(rvn_rcgn_estd_pvt_dmnsn.curr_ky) = 'USD' THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.net_revenues * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.net_revenues * COALESCE(sls_spmt.multiplier,1)
		END
	  WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null THEN 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_estd_pvt_dmnsn.net_revenues * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_estd_pvt_dmnsn.net_revenues * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.multiplier,1)
		END
	  ELSE 
		CASE 
			WHEN lower(sls_spmt.eurofit_flag) in ('o','x','y','z') THEN rvn_rcgn_prfm_obgn_dmnsn.alct_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1) * COALESCE(sls_spmt.eurofit_multiplier,1)
			ELSE rvn_rcgn_prfm_obgn_dmnsn.alct_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1)
		END 
  END,sls_spmt.nt_xtnd_sls_spmt_dcmt_amt_frm_src_cd* COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1)) as nt_rvn_usd_amt,
	(case
		when lower(sls_spmt.eurofit_flag) in ('o','x','y','z')
		and sls_spmt.eurofit_split_percentage is not null then (coalesce(rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt,0) +
		(case
			when rvn_rcgn_dfrd_itm_dmnsn.curr_ky = 'USD' then (rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt)
			when rvn_rcgn_dfrd_itm_dmnsn.curr_ky is null then null
			else (rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1))
	end) ) * (sls_spmt.eurofit_split_percentage / 100)
		else (coalesce(rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumscnd_prll_lcl_curr_amt,	0) +
		(case
			when rvn_rcgn_dfrd_itm_dmnsn.curr_ky = 'USD' then (rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt)
			when rvn_rcgn_dfrd_itm_dmnsn.curr_ky is null then null
			else (rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt * COALESCE(exch_rt,sls_spmt.gbl_curr_exch_rate_cd,1))
	end) )
	end) * COALESCE(sls_spmt.multiplier,1) as ttl_rvn_usd_amt,
	(case
		when lower(sls_spmt.eurofit_flag) in ('o','x','y','z')
		and sls_spmt.eurofit_split_percentage is not null then (coalesce(rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumtrsn_curr_amt,0)+ coalesce(rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt,0)) * (sls_spmt.eurofit_split_percentage / 100)
		else (coalesce(rvn_rcgn_pstg_dmnsn.total_cost_of_sales_sumtrsn_curr_amt,0)+ coalesce(rvn_rcgn_dfrd_itm_dmnsn.total_cost_of_sales_sumrvn_dlta_amt,0))
	end) * COALESCE(sls_spmt.multiplier,1) as ttl_rvn_amt,
	case
		when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0
		else sls_spmt.ndp_sls_spmt_usd_curr_amt_cd
	end as cp_ndp_usd_amt,
	sls_spmt.shrt_txt_sls_ord_itm_nm as shrt_txt_sls_ord_itm_nm,
	rvn_rcgn_cntrct_dmnsn.cntrct_crtn_ts as dfrd_cntrct_crtn_ts,
	case
		when lower(sls_spmt.zord_header_usr_stts_nm) rlike '.*(bbre|bblk).*' then 'pre-build/blood-build'
		when lower(sls_spmt.e1edk14_idoc_org_nm_12) = 'znc' then 'cfo'
		when lower(sls_spmt.e1edk14_idoc_org_nm_12) in ('zciv','zcr','zncr','zccr','zscr') then 'cmo'
		else null
	end as ord_class,
	case
	  when lower(sls_spmt.zord_header_usr_stts_nm) rlike '.*(bbre|bblk).*' then 'Y'  
	  else 'N'
	end as pre_bld_ord,
	case
	  when lower(sls_spmt.e1edk14_idoc_org_nm_12) = 'znc' then 'Y'
	  else 'N'
	end as cfo_ord,
	case
	  when lower(sls_spmt.e1edk14_idoc_org_nm_12) in ('zciv','zcr','zncr','zccr','zscr') then 'Y'
	  else 'N'
	end as cmo_ord,
	rvn_rcgn_prfm_obgn_dmnsn.mtrl_acct_asngmt_grp_cd,
	rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd,
	sls_spmt.prmry_prcg_cndn_cd as prmry_prcg_cndn_cd,
	nt_prc_rt as net_prc_rt,
	grs_rvn_rt as grs_rvn_rt,
	sls_spmt.spmlfd_ord_ln_itm_sts_dn as spmlfd_ord_ln_itm_sts_dn,
	sls_spmt.spmlfd_ord_hddr_sts_dn as spmlfd_ord_hddr_sts_dn,
	sls_spmt.spmlfd_dlvry_sts_dn as spmlfd_dlvry_sts_dn,
	sls_spmt.actl_qty_dlvrd_stockkeeping_unts as actl_qty_dlvrd_stockkeeping_unts,
	CAST(CASE
		WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN
		concat(substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,0,4),
			CASE
				WHEN substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3) in ('001','002','003') then '1'
				WHEN substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3) in ('004','005','006') then '2'
				WHEN substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3) in ('007','008','009') then '3'
				WHEN substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3) in ('010','011','012') then '4'
				ELSE NULL
			END)
		WHEN sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL AND UPPER(rvn_rcgn_cntrct_dmnsn.cntrct_cgy_cd) IN ('HLED','SLED', 'SMIG') and rvn_rcgn_prfm_obgn_dmnsn.flflm_typ_cd = 'T' and rvn_rcgn_prfm_obgn_dmnsn.strt_dt is null and rvn_rcgn_prfm_obgn_dmnsn.end_dt is null  THEN
		concat(substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,0,4),
			CASE
				WHEN substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,5,3) in ('001','002','003') then '1'
				WHEN substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,5,3) in ('004','005','006') then '2'
				WHEN substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,5,3) in ('007','008','009') then '3'
				WHEN substr(rvn_rcgn_estd_pvt_dmnsn.rcncltn_ky,5,3) in ('010','011','012') then '4'
				ELSE NULL
			END)
		ELSE null
		END
	as int) as fscl_yr_prd_con_filter,
	crc32(coalesce(sls_spmt.e1edk01_idoc_dcmt_nr,"")) as ord_hddr_ky,
	COALESCE(sls_spmt.multiplier,1) as prtl_spmt_multr,
	ope_sls_spmt.ope_deal_end_cust_prty_id as cp_deal_end_cust_prty_id
  ,ope_sls_spmt.ope_bmt_end_cust_prty_id as cp_bmt_end_cust_prty_id
  ,ope_sls_spmt.ope_dstr_prty_id as cp_dstr_prty_id
  ,ope_sls_spmt.ope_rslr_prty_id as cp_rslr_prty_id
  --,ope_sls_spmt.ope_end_cust_prty_id as cp_end_cust_prty_id
  --,ope_sls_spmt.ope_sldt_prty_id as cp_sldt_prty_id
  ,ope_sls_spmt.ope_src_end_cust_prty_id as cp_src_end_cust_prty_id
  -- ,ope_sls_spmt.ope_rtm as cp_rtm_nm
  ,ope_sls_spmt.ope_crss_brdr as cp_crss_brdr
  ,sls_spmt.src_type
  ,sls_spmt.eurofit_multiplier
  ,case
	  when ord_dmnsn_adjmt_dmnsn.estmd_inv_dt is not null then to_date(from_unixtime(unix_timestamp(ord_dmnsn_adjmt_dmnsn.estmd_inv_dt,'dd/MM/yyyy')))
	  else sls_spmt.estmd_inv_dt
  end as cp_estmd_inv_dt_itm,
  sls_spmt.nt_unt_rsttd_sls_spmt_bdgt_amt_frm_src_cd,
  sls_spmt.nt_xtnd_rsttd_sls_spmt_bdgt_amt_frm_src_cd
  from 
	${dbfinancnamelr1uat}.secrd_rpt_sls_spmt_dmnsn sls_spmt
left outer join (select * from (select e1edk01_idoc_dcmt_nr,e1edp01_itm_nr,ope_deal_end_cust_prty_id,ope_bmt_end_cust_prty_id,ope_dstr_prty_id,ope_rslr_prty_id,ope_end_cust_prty_id,ope_sldt_prty_id,ope_src_end_cust_prty_id,ope_rtm,ope_crss_brdr,row_number() over (partition by e1edk01_idoc_dcmt_nr,e1edp01_itm_nr order by ins_gmt_ts) rw_num from ${dbfinancnamelr1uat}.secrd_ope_sls_spmt_dmnsn) ope_stg where rw_num = 1) ope_sls_spmt on
  sls_spmt.e1edk01_idoc_dcmt_nr = ope_sls_spmt.e1edk01_idoc_dcmt_nr
  and sls_spmt.e1edp01_itm_nr = ope_sls_spmt.e1edp01_itm_nr
  --and sls_spmt.eurofit_ctry_cd = ope_sls_spmt.eurofit_ctry_cd
  --and sls_spmt.sm_sm_id = ope_sls_spmt.sm_sm_id
  --and sls_spmt.rptg_mtrl_id_id= ope_sls_spmt.rptg_mtrl_id_id
  --and sls_spmt.eurofit_flag = ope_sls_spmt.eurofit_flag
left outer join ${dbfinancnamelr1uat}.rvn_rcgn_mppg_dmnsn rvn_rcgn_mppg_dmnsn on
	sls_spmt.e1edk01_idoc_dcmt_nr = substring(rvn_rcgn_mppg_dmnsn.src_itm_id, 1, 10)
	and sls_spmt.e1edp01_itm_nr = substring(rvn_rcgn_mppg_dmnsn.src_itm_id,(length(rvn_rcgn_mppg_dmnsn.src_itm_id)-5), 6)
left outer join ${dbfinancnamelr1uat}.rvn_rcgn_cntrct_dmnsn rvn_rcgn_cntrct_dmnsn on
	rvn_rcgn_mppg_dmnsn.rvn_rcgn_cntrct_id = rvn_rcgn_cntrct_dmnsn.rvn_rcgn_cntrct_id
left outer join ${dbfinancnamelr1uat}.rvn_rcgn_prfm_obgn_dmnsn on 
	rvn_rcgn_mppg_dmnsn.prfm_obgn_id = rvn_rcgn_prfm_obgn_dmnsn.prfm_obgn_id
left outer join rvn_rcgn_dfrd_itm_dmnsn on
	rvn_rcgn_mppg_dmnsn.rvn_rcgn_cntrct_id = rvn_rcgn_dfrd_itm_dmnsn.rvn_rcgn_cntrct_id
	and rvn_rcgn_mppg_dmnsn.prfm_obgn_id = rvn_rcgn_dfrd_itm_dmnsn.prfm_obgn_id
left outer join rvn_rcgn_estd_pvt_dmnsn on
	rvn_rcgn_mppg_dmnsn.rvn_rcgn_cntrct_id = rvn_rcgn_estd_pvt_dmnsn.rvn_rcgn_cntrct_id
	and rvn_rcgn_mppg_dmnsn.prfm_obgn_id = rvn_rcgn_estd_pvt_dmnsn.prfm_obgn_id
left outer join ${dbfinancnamelr1uat}.rvn_rcgn_pstg_pvt_dmnsn rvn_rcgn_pstg_dmnsn on
	rvn_rcgn_dfrd_itm_dmnsn.prfm_obgn_id = rvn_rcgn_pstg_dmnsn.prfm_obgn_id
	and rvn_rcgn_dfrd_itm_dmnsn.rvn_rcgn_cntrct_id = rvn_rcgn_pstg_dmnsn.rvn_rcgn_cntrct_id
	and rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky = rvn_rcgn_pstg_dmnsn.rvn_rcncltn_ky
left outer join ord_conditional_itm_dmnsn on
	sls_spmt.e1edk01_idoc_dcmt_nr = ord_conditional_itm_dmnsn.e1edk01_idoc_dcmt_nr
	and sls_spmt.e1edp01_itm_nr = ord_conditional_itm_dmnsn.e1edp01_itm_nr
	--and sls_spmt.idoc_nr = ord_conditional_itm_dmnsn.idoc_nr
left join exch_rt_tbl on
	COALESCE(rvn_rcgn_dfrd_itm_dmnsn.curr_ky,sls_spmt.e1edp01_curr_cd) = exch_rt_tbl.frm_curr_cd
	and month(COALESCE(to_date(from_unixtime(unix_timestamp(rvn_rcgn_cntrct_dmnsn.cntrct_crtn_ts,'yyyymmdd'))),sls_spmt.e1edk03_ido_1_id_25)) = month(exch_rt_tbl.etry_vld_frm_ts)
	and year(COALESCE(to_date(from_unixtime(unix_timestamp(rvn_rcgn_cntrct_dmnsn.cntrct_crtn_ts,	'yyyymmdd'))),sls_spmt.e1edk03_ido_1_id_25)) = year(exch_rt_tbl.etry_vld_frm_ts)
left outer join ${dbcommonlr1uat}.bmt_ord_dmnsn_adjmt_dmnsn ord_dmnsn_adjmt_dmnsn on
	sls_spmt.e1edk01_idoc_dcmt_nr = ord_dmnsn_adjmt_dmnsn.sls_ord_id
left outer join ${dbcommonname}.segment_std_hrchy segment_std_hrchy on
	segment_std_hrchy.sg_level_8 = sls_spmt.sgmnt_cd
left outer join ${dbfinancname}.icost_dtl_burden_aggregate icost_dtl_burden_aggregate on -- validate join 3/19
	icost_dtl_burden_aggregate.ctry_cd = sls_spmt.e1edka1_ctry_ky_cd_ag
	and icost_dtl_burden_aggregate.mtrl_mstr_mtrl_id = sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
	and icost_dtl_burden_aggregate.clndr_yr_prd = concat(year(sls_spmt.e1edk03_ido_1_id_25),lpad(month(sls_spmt.e1edk03_ido_1_id_25),2,'0'))
left outer join rate_tbl on
	sls_spmt.e1edk01_idoc_dcmt_nr = rate_tbl.e1edk01_idoc_dcmt_nr
	and sls_spmt.e1edp01_itm_nr = rate_tbl.e1edp01_itm_nr
left outer join ${dbcommonname}.prty_fact prty on
	(case
		when ord_dmnsn_adjmt_dmnsn.end_cust_prty_id is null then sls_spmt.e1edka1_ptnr_nr_zc
		else ord_dmnsn_adjmt_dmnsn.end_cust_prty_id
	end) = prty.mdm_id
left outer join optgcopa as optg_concern on
	concat_ws("-",sls_spmt.e1edk01_idoc_dcmt_nr,sls_spmt.e1edp01_itm_nr) = optg_concern.copa_order_number_item_number_key
left outer join dfrd_three_twelve_month on
	rvn_rcgn_dfrd_itm_dmnsn.curr_ky = dfrd_three_twelve_month.tc_cd
	and rvn_rcgn_dfrd_itm_dmnsn.entrs_lgl_ent_ldgr_cd = dfrd_three_twelve_month.entrs_lgl_ent_ldgr_cd
	and sls_spmt.pft_cntr_nm = dfrd_three_twelve_month.pft_cntr_cd
	and sls_spmt.sgmnt_cd = dfrd_three_twelve_month.mgmt_grphy_unt_cd
	and substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,1,4)= dfrd_three_twelve_month.fscl_yr_nr
	and substr(rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky,5,3)= dfrd_three_twelve_month.pstg_prd_nr
left outer join dfrd_three_twelve_month as pstg_three_twelve_month on
	rvn_rcgn_pstg_dmnsn.curr_ky = pstg_three_twelve_month.tc_cd
	and rvn_rcgn_pstg_dmnsn.entrs_lgl_ent_ldgr_cd = pstg_three_twelve_month.entrs_lgl_ent_ldgr_cd
	and sls_spmt.pft_cntr_nm = pstg_three_twelve_month.pft_cntr_cd
	and sls_spmt.sgmnt_cd = pstg_three_twelve_month.mgmt_grphy_unt_cd
	and substr(rvn_rcgn_pstg_dmnsn.rvn_rcncltn_ky,1,4)= pstg_three_twelve_month.fscl_yr_nr
	and substr(rvn_rcgn_pstg_dmnsn.rvn_rcncltn_ky,5,3)= pstg_three_twelve_month.pstg_prd_nr
left outer join ${dbcommonnamelr1}.bmt_trsn_curr_xclsn_dmnsn dfrd_bmt_trsn_curr on
	rvn_rcgn_dfrd_itm_dmnsn.curr_ky = dfrd_bmt_trsn_curr.crr_cd
left outer join ${dbcommonnamelr1}.bmt_trsn_curr_xclsn_dmnsn pstg_bmt_trsn_curr on
	rvn_rcgn_pstg_dmnsn.curr_ky = pstg_bmt_trsn_curr.crr_cd
left outer join ${dbcommonnamelr1}.clndr_rpt inv_clndr_rpt on sls_spmt.estmd_inv_dt=inv_clndr_rpt.cldr_dt
where
  case 
  	when COALESCE(sls_spmt.sls_ord_totl_qty_cd,0) <= 0 and sls_spmt.no_shp_flg_cd = 'Y' then 1 
	  when sls_spmt.e1edp01_itm_nr is null and sls_spmt.actl_qty_dlvrd_stockkeeping_unts is null and sls_spmt.no_shp_flg_cd = 'FY' then  0
	  when (sls_spmt.actl_qty_dlvrd_stockkeeping_unts > 0.0 or sls_spmt.actl_qty_dlvrd_stockkeeping_unts is null) then 1
	  when sls_spmt.actl_qty_dlvrd_stockkeeping_unts < 0 and (no_shp_flg_cd = 'Y' or no_shp_flg_cd = 'FY') then 1
	  when sls_spmt.actl_qty_dlvrd_stockkeeping_unts < 0 and no_shp_flg_cd = 'F' then 1
	  else 0 
  end = 1 
""")

    salesshipmentdf.repartition(col("sls_ord_id"), col("sls_ord_ln_itm_id")).persist(MEMORY_AND_DISK)

    // logger.info("+++++++++++################## Sales Shipment Count")

    salesshipmentdf.filter(col("fscl_yr_prd_con_filter").isNull || col("fscl_yr_prd_con_filter") >= fscl_yr_prd_con).repartition(5).write.mode("overwrite").insertInto(dbfinancnamelr1uat +".secrd_rpt_fact_serp_tmp")

    spark.sql(s"select * from ${dbfinancnamelr1uat}.secrd_rpt_fact_serp_tmp").createOrReplaceTempView("serptemptable1")

    logger.info("+++++++++++##################serp temp 1 table loaded##################+++++++++++")

    val dfPDM = spark.sql(s"""
      select distinct 
        mtrl_mstr_sls_dvsn_cd,
        mtrl_mstr_mtrl_id 
      from 
        ${dbcommonlr1uat}.pdm_mtrl_mstr_grp_dmnsn
        """)

    dfPDM.createOrReplaceTempView("pdm_mtrl_mstr_grp_dmnsn")

    /*
 * enriching salesshipmentdf data frame with pdm fields
 *
 */
    val salesshipmentpdmdf = spark.sql(s"""
    select 
      distinct serp1.*,
      prod_mstr_dmnsn.mtrl_mstr_sls_dvsn_cd as pmd_mtrl_mstr_sls_dvsn_cd,
      prod_mstr.mtrl_mstr_sls_dvsn_cd as pm_mtrl_mstr_sls_dvsn_cd,
      current_prod_hrchy_dmnsn.prod_hrchy_prod_fmly_cd,
      bmt_gbl_carepack_dmnsn.gbl_carepack_hw_prod_ln_id,
      current_prod.prod_hrchy_prod_typ_cd,
      coalesce(case when cst_cntr_grp_hrchy_dmnsn.cch_level_8 is null then "F70000038" else cst_cntr_grp_hrchy_dmnsn.cch_level_8  end,"fo70000038") as fncl_ownr_cd,
      case 
        when pn_disa_flg_dmnsn.sld_to_id is null then 'N'
        else 'Y'
      end as disa_ind,
      case
        when lower(pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.source) like '%dxc%' then 'Y'
        else 'N'
      end as dxc_ind,
      case
        when lower(pn_so_hypr_hpc_dxc_flg_dmnsn_hpc.source) like '%hpc%' then 'Y'
        else 'N' 
      end as hpc_ind,
      case
        when lower(pn_so_hypr_hpc_dxc_flg_dmnsn_hyp.source) like '%hyperconverged%' then 'Y'
        else 'N'
      end as hyperconverged_ind,
      case
        when pn_srv_intensity_dmnsn.srv_intensity_flg_cd is null then 'N'
        else 'Y'
      end as srv_intensity_ind,
      doc_typ_dmnsn.doc_typ_ky
    from serptemptable1 serp1
    left outer join pdm_mtrl_mstr_grp_dmnsn prod_mstr_dmnsn on prod_mstr_dmnsn.mtrl_mstr_mtrl_id = serp1.prod_id
    left outer join pdm_mtrl_mstr_grp_dmnsn prod_mstr on prod_mstr.mtrl_mstr_mtrl_id=serp1.rptg_mtrl_id_id
    left outer join ${dbcommonname}.current_prod_hrchy_dmnsn current_prod_hrchy_dmnsn on current_prod_hrchy_dmnsn.mtrl_mstr_mtrl_id =serp1.prod_id
    left outer join ${dbcommonlr1uat}.bmt_gbl_carepack_dmnsn bmt_gbl_carepack_dmnsn on bmt_gbl_carepack_dmnsn.mfrg_prod_id=serp1.prod_id
    left outer join ${dbcommonname}.current_prod_hrchy_dmnsn current_prod on current_prod.mtrl_mstr_mtrl_id =serp1.itm_vl_usr_stts_cd
    left outer join ${dbcommonname}.cst_cntr_fo_hrchy cst_cntr_grp_hrchy_dmnsn on cst_cntr_grp_hrchy_dmnsn.cch_level_9=serp1.cst_cntr_cd
    left outer join ${dbcommonname}.doc_typ_dmnsn doc_typ_dmnsn on doc_typ_dmnsn.sls_dcmt_typ_cd=serp1.ord_typ_cd
    left outer join ${dbcommonname}.bmt_pn_disa_flg_dmnsn pn_disa_flg_dmnsn on serp1.prft_cntr_cd=pn_disa_flg_dmnsn.pft_cntr_cd and serp1.sld_to_cd = pn_disa_flg_dmnsn.sld_to_id
    left outer join ${dbcommonlr1uat}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn pn_so_hypr_hpc_dxc_flg_dmnsn_dxc on serp1.ord_nr =pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.sls_ord_id and lower(pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.source) like '%dxc%'
    left outer join ${dbcommonlr1uat}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn pn_so_hypr_hpc_dxc_flg_dmnsn_hpc on serp1.ord_nr =pn_so_hypr_hpc_dxc_flg_dmnsn_hpc.sls_ord_id and lower(pn_so_hypr_hpc_dxc_flg_dmnsn_hpc.source) like '%hpc%'
    left outer join ${dbcommonlr1uat}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn pn_so_hypr_hpc_dxc_flg_dmnsn_hyp on serp1.ord_nr= pn_so_hypr_hpc_dxc_flg_dmnsn_hyp.sls_ord_id and lower(pn_so_hypr_hpc_dxc_flg_dmnsn_hyp.source) like '%hyperconverged%'
    left outer join ${dbcommonlr1uat}.bmt_pn_srv_intensity_dmnsn pn_srv_intensity_dmnsn on serp1.itm_vl_usr_stts_cd = pn_srv_intensity_dmnsn.prod_id
    """)

    salesshipmentpdmdf.createOrReplaceTempView("serptemptable2")

    logger.info("+++++++++++##################serp temp 2 table loaded##################+++++++++++")

    /*
     * enriching salesshipmentpdmdf data frame with order adjustment bmt fields
     *
     */

    val bmtrevrec = spark.sql(s"select col_nm,upper(col_vlu) as col_vlu,rev_rec_cgy_cd,dlt_flg from ${dbcommonlr1uat}.bmt_order_rev_rec_dmnsn where lgc_ownr = 'EGI'")

    val bmtrevrecformatted = bmtrevrec.collect.map(c => " when " + c(0) + " = '" + c(1) + "' then '" + c(2) + "'")

    var revrecvalue = "case"

    for (i <- 0 to (bmtrevrecformatted.length - 1)) { revrecvalue += bmtrevrecformatted(i) }

    revrecvalue += "else null end"

    revrecvalue = revrecvalue.replace("sls_ord_id", "serp2.sls_ord_id")

    val salesshipmentordadjdf = spark.sql(s"""
    select 
      distinct serp2.*, 
      ob_scra_fd_srtr_dmnsn.sc_bklg_cgy_cd as scra_cgy_cd,
      ord_sni_dmnsn.in_out_omc_rsk_bkt as sni_risk_asmnt_cgy_cd,
      case 
        when ord_adjmt_dmnsn.rvn_rcgn_cgy_cd is null or lower(ord_adjmt_dmnsn.rvn_rcgn_cgy_cd) in ('include','null') then 
          case 
            when scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd is not null then scra_rev_rec_cgy_dmnsn.rev_recgn_cgy_cd 
            else null 
          end 
        else ord_adjmt_dmnsn.rvn_rcgn_cgy_cd
      end as cp_rev_recgn_cgy_cd_temp,
      scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd as sc_bklg_cgy_cd_scra,
      ord_adjmt_dmnsn.rvn_rcgn_cgy_cd as rvn_rcgn_cgy_cd_ord_adj,
      scra_rev_rec_cgy_dmnsn.rev_recgn_cgy_cd as rvn_rcgn_cgy_cd_scra,
      fscl_cldr_dmnsn.week_in_qtr_cd as fscl_week_cd,
      $countryname as ctry_nm,
      $countryname as cp_ctry_nm,  
      cust_alt_hrchy_dmnsn.cust_mppg_23_cd as cust_sgm_nm,
      cust_alt_hrchy_dmnsn.cust_mppg_23_cd as cp_cust_sgm_nm,
      $revrecvalue as rvn_rcgn_cgy_cd_bmt
    from serptemptable2 serp2
    left outer join (select *,pch_level_7 as oypl_pch_level_7 from ${dbcommonname}.pft_cntr_std_hrchy) pft_cntr_std_hrchy on serp2.prft_cntr_cd = pft_cntr_std_hrchy.pch_level_8
    left outer join ${dbcommonlr1uat}.bmt_ord_dmnsn_adjmt_dmnsn ord_adjmt_dmnsn on serp2.ord_nr = ord_adjmt_dmnsn.sls_ord_id
    left outer join ${dbcommonlr1uat}.bmt_ob_scra_fd_srtr_dmnsn ob_scra_fd_srtr_dmnsn on serp2.ord_nr = ob_scra_fd_srtr_dmnsn.so_id and serp2.sls_ord_ln_itm_id = (case when length(ob_scra_fd_srtr_dmnsn.so_ln_itm_id) <=6 then lpad(ob_scra_fd_srtr_dmnsn.so_ln_itm_id,6,"0")  else ob_scra_fd_srtr_dmnsn.so_ln_itm_id end)
    left outer join ${dbcommonlr1uat}.bmt_scra_rev_rec_cgy_dmnsn scra_rev_rec_cgy_dmnsn on ob_scra_fd_srtr_dmnsn.sc_bklg_cgy_cd = scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd
    left outer join ${dbcommonlr1uat}.bmt_fscl_cldr_dmnsn fscl_cldr_dmnsn on serp2.cldr_rpt_ky = from_unixtime(unix_timestamp(fscl_cldr_dmnsn.fscl_cldr_dt,'yyyy-mm-dd hh:mm:ss.ss'),'yyyymmdd')
    left outer join ${dbcommonlr1uat}.bmt_sls_chnl_dmnsn sls_chnl_dmnsn on serp2.mkt_rte_cd=sls_chnl_dmnsn.sls_chnl_cd
    left outer join (select * from ${dbcommonlr1uat}.bmt_cust_alt_hrchy_dmnsn where UPPER(src_nm) = 'EGI') cust_alt_hrchy_dmnsn on serp2.end_cust_cd=cust_alt_hrchy_dmnsn.prty_id
    left outer join (select * from ${dbcommonlr1uat}.bmt_sgm_alt_hrchy_dmnsn where UPPER(upd_own) = 'EGI') bmt_sgm_alt_hrchy_dmnsn on serp2.sgmtl_rptg_cd = bmt_sgm_alt_hrchy_dmnsn.sgm_cd
    left outer join (select * from ${dbcommonlr1uat}.bmt_pft_cntr_alt_hrchy_dmnsn where UPPER(upd_own) = 'EGI') bmt_pft_cntr_alt_hrchy_dmnsn on serp2.prft_cntr_cd = bmt_pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd
    left outer join (select * from ${dbcommonlr1uat}.bmt_cust_alt_hrchy_dmnsn where src_nm = 'EGI') bmt_cust_alt_hrchy_dmnsn  on serp2.cp_end_cust_prty_id = bmt_cust_alt_hrchy_dmnsn.prty_id
    left outer join (select * from (select *,row_number() over (partition by idoc_nr,e1edk01_idoc_dcmt_nr,e1edp01_itm_nr order by ins_gmt_ts) rw_num from ${dbcommonlr1uat}.ord_sni_dmnsn) x where rw_num = 1) ord_sni_dmnsn on ord_sni_dmnsn.idoc_nr=serp2.src_idoc_nr and ord_sni_dmnsn.e1edk01_idoc_dcmt_nr= serp2.ord_nr and ord_sni_dmnsn.e1edp01_itm_nr= serp2.sls_ord_ln_itm_id
    """)

    salesshipmentordadjdf.persist(MEMORY_ONLY)

    salesshipmentordadjdf.createOrReplaceTempView("serptemptable3")

    logger.info("+++++++++++##################serp temp 3 table loaded##################+++++++++++" + salesshipmentordadjdf.count().toLong)

    /*
     * enriching salesshipmentordadjdf data frame with deals and quotes fields
     *
     */

    val salesshipmentdealquotesdf = spark.sql(s"""
    select distinct serp3.*,
      deal_dmnsn.deal_acct_mgmt_lvl_2_id,
      deal_dmnsn.deal_acct_mgmt_lvl_2_nm,
      deal_dmnsn.deal_bsn_mdl_cd,
      deal_dmnsn.deal_bsn_mdl_dn,
      deal_dmnsn.deal_cust_ltn_nm,
      deal_dmnsn.deal_cust_nn_ltn_nm,
      deal_dmnsn.deal_rgst_id,
      deal_dmnsn.deal_deal_src_sys_cd as deal_src_sys_cd,
      deal_dmnsn.deal_deal_src_sys_dn,
      deal_dmnsn.deal_stts_nm,
      deal_dmnsn.deal_sb_typ_cd,
      deal_dmnsn.deal_typ_cd,
      deal_dmnsn.deal_vrsn_nr,
      deal_dmnsn.deal_vrsn_stts_nm,
      deal_dmnsn.deal_grphc_scp_nm,
      deal_dmnsn.deal_indy_id,
      deal_dmnsn.deal_last_updd_by_eml_id,
      deal_dmnsn.deal_lead_bsn_unt_cd,
      deal_dmnsn.deal_misc_crg_cd,
      deal_dmnsn.deal_prnt_org_id,
      deal_dmnsn.deal_prnt_org_nm,
      deal_dmnsn.deal_pyr_prty_id,
      deal_dmnsn.deal_sls_tty_acct_cnflct_ind,
      deal_dmnsn.deal_sls_tty_acct_nm,
      deal_dmnsn.deal_src_deal_id,
      deal_dmnsn.deal_vld_end_ts,
      deal_dmnsn.deal_vld_strt_ts,
      deal_dmnsn.deal_ins_ts,
      deal_dmnsn.deal_upd_ts,
      deal_end_cust_psls_prty_id as deal_end_cust_presls_prty_id, -- added 3/1
      deal_opsi_id as deal_other_prty_site_insn_id, -- added 3/1
      deal_org_id as deal_org_id, -- added 3/1
      deal_site_insn_id as deal_site_insn_id, -- added 3/1
      deal_sls_tty_acct_id as deal_sls_tty_acct_id, -- added 3/1
      deal_prty_rol_deal_id as deal_prty_rol_deal_id, -- added 3/1
      deal_dmnsn.deal_cust_prty_id as deal_prty_id, -- added 3/1
      crc32(lower(concat(coalesce(quotes_fact.asset_quote_nr_cd, ""),coalesce(quotes_fact.asset_quote_vrsn_cd,"")))) as quote_ky,
      quotes_fact.quote_header_sls_qtn_vrsn_sqn_nr_cd as quote_header_sls_qtn_vrsn_sqn_nr_cd,
		  quotes_fact.asset_quote_nr_cd as asset_quote_nr_cd,
		  quotes_fact.asset_quote_vrsn_cd as asset_quote_vrsn_cd,
		  quotes_fact.modified_ts_cd as modified_ts_cd,
		  quotes_fact.creation_person_id_id as creation_person_id_id,
		  quotes_fact.sfdc_status_cd as sfdc_status_cd,
		  quotes_fact.total_amt_cd as total_amt,
		  quotes_fact.total_list_price_amt_cd as total_list_price_amt,
		  quotes_fact.bmi_id_id as bmi_id_id,
		  quotes_fact.nm as nm,
		  quotes_fact.price_geo_cd as price_geo_cd,
		  quotes_fact.asset_quote_nr_and_vrsn_cd as asset_quote_nr_and_vrsn_cd,
		  quotes_fact.org_id_id as org_id_id,
		  quotes_fact.creation_ts_cd as creation_ts_cd,
		  quotes_fact.currency_cd_cd as currency_cd_cd,
		  quotes_fact.sls_qtn_vrsn_typ_cd_cd as sls_qtn_vrsn_typ_cd_cd,
		  quotes_fact.cty_cd as cty_cd,
		  quotes_fact.quoteowner_cd as quoteowner_cd,
		  quotes_fact.partner_id_id,
		  quotes_fact.orig_asset_cd,
		  quotes_fact.modified_person_id_id,
		  quotes_fact.lead_bu_cd,
		  quotes_fact.last_modifier_ngq_profile_cd ,
		  quotes_fact.customer_mdcp_org_id_id ,
		  quotes_fact.creator_ngq_profile_cd,
		  quotes_fact.completion_ts_cd,
		  quotes_fact.quote_items_product_line_cd as quote_items_product_line_cd, -- added 3/1
		  quotes_fact.lcl_xtnd_nt_amt_cd as lcl_xtnd_nt_amt_cd, -- added 3/1
		  quotes_fact.qty_cd as qty_cd ,  -- added 3/1
		  hpe_qt_flags_dmnsn.flg_typ_cd as flg_typ_cd,  -- added 3/1
		  hpe_qt_flags_dmnsn.flg_vl_cd as flg_vl_cd,  -- added 3/1
		  hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_id_id,  -- added 3/1
		  hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd,  -- added 3/1
		  quotes_fact.region_cd_cd as rgn_cd,  -- added 3/1
		  quotes_fact.sales_org_cd as sales_org_cd,  -- added 3/1
		  quotes_fact.customer_name_nm as soldto_prty_nm,  -- added 3/1
		  customer_name_nm as quotes_cust_nm,  -- added 3/1
		  customer_mdcp_site_id_id as quotes_cust_mdcp_site_id,  -- added 3/1
		  distributor_partner_id_id as quotes_dist_ptnr_id,  -- added 3/1
		  sold_to_staid_id as sold_to_staid_id,  -- added 3/1
		  prty_asscn_dmnsn.prty_asscn_prty_id as mdm_id,  -- added 3/1
		  opty_fact.acct_i_20_nm ,
		  opty_fact.totl_opty_v_cd,
		  opty_fact.expctd_amt_cd,
		  opty_fact.opty_totl_amt_cd,
		  opty_fact.opty_totl_amt_cd as opty_totl_amt_cd1 ,
		  opty_prod_dmnsn.bookshi_2_dt as opty_bk_ship_dt, -- added 3/1
		  opty_fact.last_mfy_6_dt as opty_lst_mfd_dt, -- added 3/1
		  opty_prod_dmnsn.sys_modstam_4_cd as sys_modstam, -- added 3/1
		  opty_prod_dmnsn.b_3_nm as bg_cd, -- added 3/1
		  opty_prod_dmnsn.gb_15_nm as gbu_cd, -- added 3/1
		  opty_fact.sls_st_6_nm as opty_stg, -- added 3/1
		  opty_prod_dmnsn.pro_283_nm as prd_nm, -- added 3/1
		  opty_prod_dmnsn.prod_l_5_nm as prd_ln, -- added 3/1
		  opty_prod_dmnsn.sb_prod_l_2_nm as sub_prd_ln, -- added 3/1
		  acct_dmnsn.chnl_ptnr_flg_cd as opty_chnl_ptnr_flg_cd, -- added 3/1
		  acct_dmnsn.ptnr_typ_cd as opty_ptnr_typ_cd, -- added 3/1
		  c.prmry_dstr_cd as opty_prmry_dstr_cd,-- added 3/1
		  c.prmry_rslr_cd as opty_prmry_rslr_cd,-- added 3/1
		  c.ptnr_typ_nm as opty_ptnr_typ_nm,-- added 3/1
		  opty_fact.prmry_dstr_mdcp_org_id_nm as opty_prmry_dstr_mdcp_org_id_nm, -- added 3/1
		  opty_fact.prmry_dstr_nm as opty_prmry_dstr_nm, -- added 3/1
		  opty_fact.prmry_ppln_own_nm as opty_prmry_ppln_own_nm, -- added 3/1
		  d.prmry_ppln_own_cd as opty_team_mmbr_nm, -- added 3/1
		  d.useremail_nm as opty_useremail_nm, -- added 3/1
		  acct_dmnsn.acct_nm as acct_nm, -- added 3/1
		  acct_dmnsn.mdcp_site_insn_id as mdcp_opsi_id_id, -- added 3/1
		  opty_fact.crt_4_dt as opty_crt_dt, -- added 3/1
		  serp3.opty_id as opty_hpe_opportunity_id, -- added 3/1
		  ln_itm_id_nm as opty_line_item_id, -- added 3/1
		  v_28_cd as opty_val_cd, -- added 3/1
		  sls_re_3_nm as opty_sales_rep_nm, -- added 3/1
	    case
	      when upper(opty_fact.curr_cd) = 'USD' then opty_fact.expctd_amt_cd
	      ELSE opty_fact.expctd_amt_cd*exch_rt 
	    END AS opty_expctd_usd_amt,
	    case 
	      when upper(opty_fact.curr_cd) = 'USD' then v_28_cd
	      ELSE v_28_cd*exch_rt 
	    END AS opty_totl_usd_amt,
	    opty_fact.cl_2_dt as cls_2_dt,
		  --opty_prod_dmnsn.opportunity_estimated_revenue_usd_close_date as opportunity_estimated_revenue_usd,
		  null as opportunity_estimated_revenue_usd,
		  ord_sni_dmnsn.instln_ord_flg,
		  ord_sni_dmnsn.prj_ord,
		  ord_sni_dmnsn.dlvy_inv_cd,
		  ord_sni_dmnsn.inv_bvr,
		  ord_sni_dmnsn.pld_inv_dt,
		  ord_sni_dmnsn.hg_vw_bkt,
		  ord_sni_dmnsn.sni_alt_bkt,
		  ord_sni_dmnsn.in_out,
		  ord_sni_dmnsn.pri_bkt,
		  ord_sni_dmnsn.in_out_omc_rsk_bkt,
		  case when serp3.ord_crt_dt<=sab_cut_off_fd_srtr_dmnsn.beg_sab_cutoff_dt then 'y' else 'n' end as beg_bklg_nm,
		  null as ucid_id,
		  cto.cto_bto as bto_cto_flg,
		  sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt,
		  bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind,
		  bmt_sni_asmnt_fd_srtr_dmnsn.rev_rec_cd,
		  bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt as pri_bkt_sni,
		  bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt as in_out_omc_rsk_bkt_sni,
		  estmtd_inv_dt_ind as estmtd_inv_dt_ind,
      case 
      when rvn_rcgn_cgy_cd_bmt is not null then rvn_rcgn_cgy_cd_bmt
      when actl_dlvry_dt is null then serp3.rvn_rcgn_cgy_cd_scra
      else 
		    case 
		      when (serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt and serp3.pob_id is not null  and ( ( concat(substr(serp3.recon_ky_cd,0,4),  case when (substr(serp3.recon_ky_cd,5,3)) in ('001','002','003') then '1' when (substr(serp3.recon_ky_cd,5,3)) in ('004','005','006') then '2' when (substr(serp3.recon_ky_cd,5,3)) in ('007','008','009' ) then '3' when (substr(serp3.recon_ky_cd,5,3)) in ('010','011','012' ) then '4' else null end ))<=${fscl_yr_prd_con} ) )  then 'REV'
		      when (ord_sni_dmnsn.pri_bkt is null and ord_sni_dmnsn.in_out_omc_rsk_bkt is null and serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt   and ( (case when month(estmd_inv_dt)==11 or month(estmd_inv_dt)==12 then concat((year(estmd_inv_dt)+1) , '1') when month(estmd_inv_dt)==2 or month(estmd_inv_dt)==3 or month(estmd_inv_dt)==4 then concat(year(estmd_inv_dt), '2') when month(estmd_inv_dt)==5 or month(estmd_inv_dt)==6 or month(estmd_inv_dt)==7 then concat(year(estmd_inv_dt),'3') when month(estmd_inv_dt)==8 or month(estmd_inv_dt)==9 or month(estmd_inv_dt)==10 then concat(year(estmd_inv_dt), '4') when month(estmd_inv_dt)==1 then concat(year(estmd_inv_dt), '1') end)<=${fscl_yr_prd_con}  ) and serp3.pob_id is null	 and ( ( concat(substr(serp3.recon_ky_cd,0,4), case when (substr(serp3.recon_ky_cd,5,3)) in ('001','002','003') then '1' when (substr(serp3.recon_ky_cd,5,3)) in ('004','005','006') then '2' when (substr(serp3.recon_ky_cd,5,3)) in ('007','008','009' ) then '3' when (substr(serp3.recon_ky_cd,5,3)) in ('010','011','012' ) then '4' else null end))>${fscl_yr_prd_con}  ))  then 'KLD'
		      when ( ((case when ord_sni_dmnsn.pri_bkt is null then 'null' else ord_sni_dmnsn.pri_bkt end)==(case when bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt is null then 'null' else bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt end)) and ((case when ord_sni_dmnsn.in_out_omc_rsk_bkt is null then 'null' else ord_sni_dmnsn.in_out_omc_rsk_bkt end)==(case when bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt is null then 'null' else bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt end )) and ( case when (bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind=='n' and serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt) or (lower(bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind)='y' ) then true  else false end)
		      and  ( case when (lower(bmt_sni_asmnt_fd_srtr_dmnsn.estmtd_inv_dt_ind) ='n' and ( case when month(estmd_inv_dt)==11 or month(estmd_inv_dt)==12 then concat((year(estmd_inv_dt)+1) , '1') when month(estmd_inv_dt)==2 or month(estmd_inv_dt)==3 or month(estmd_inv_dt)==4 then concat(year(estmd_inv_dt), '2') when month(estmd_inv_dt)==5 or month(estmd_inv_dt)==6 or month(estmd_inv_dt)==7 then concat(year(estmd_inv_dt),'3') when month(estmd_inv_dt)==8 or month(estmd_inv_dt)==9 or month(estmd_inv_dt)==10 then concat(year(estmd_inv_dt), '4') when month(estmd_inv_dt)==1 then concat(year(estmd_inv_dt), '1') end<=${fscl_yr_prd_con} )) or lower(bmt_sni_asmnt_fd_srtr_dmnsn.estmtd_inv_dt_ind)='y' then true  else false end) and ( ( concat(substr(serp3.recon_ky_cd,0,4), case when (substr(serp3.recon_ky_cd,5,3)) in ('001','002','003') then '1' when (substr(serp3.recon_ky_cd,5,3)) in ('004','005','006') then '2' when (substr(serp3.recon_ky_cd,5,3)) in ('007','008','009' ) then '3' when (substr(serp3.recon_ky_cd,5,3)) in ('010','011','012' ) then '4' else null end ))>${fscl_yr_prd_con}  ))  then bmt_sni_asmnt_fd_srtr_dmnsn.rev_rec_cd
		    else 'KOP' 
		    end 
		  end  as rvn_rcgn_cgy_cd,
      case 
      when rvn_rcgn_cgy_cd_ord_adj is null or lower(rvn_rcgn_cgy_cd_ord_adj) in ('include','null') then 
        case 
          when rvn_rcgn_cgy_cd_bmt is not null then rvn_rcgn_cgy_cd_bmt
          when actl_dlvry_dt is null then serp3.rvn_rcgn_cgy_cd_scra
        else 
		      case 
		      when (serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt and serp3.pob_id is not null  and ( ( concat(substr(serp3.recon_ky_cd,0,4),  case when (substr(serp3.recon_ky_cd,5,3)) in ('001','002','003') then '1' when (substr(serp3.recon_ky_cd,5,3)) in ('004','005','006') then '2' when (substr(serp3.recon_ky_cd,5,3)) in ('007','008','009' ) then '3' when (substr(serp3.recon_ky_cd,5,3)) in ('010','011','012' ) then '4' else null end))<=${fscl_yr_prd_con} ) )  then 'REV'
		      when (ord_sni_dmnsn.pri_bkt is null and ord_sni_dmnsn.in_out_omc_rsk_bkt is null and serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt   and ( (case when month(estmd_inv_dt)==11 or month(estmd_inv_dt)==12 then concat((year(estmd_inv_dt)+1) , '1') when month(estmd_inv_dt)==2 or month(estmd_inv_dt)==3 or month(estmd_inv_dt)==4 then concat(year(estmd_inv_dt), '2') when month(estmd_inv_dt)==5 or month(estmd_inv_dt)==6 or month(estmd_inv_dt)==7 then concat(year(estmd_inv_dt),'3') when month(estmd_inv_dt)==8 or month(estmd_inv_dt)==9 or month(estmd_inv_dt)==10 then concat(year(estmd_inv_dt), '4') when month(estmd_inv_dt)==1 then concat(year(estmd_inv_dt), '1') end)<=${fscl_yr_prd_con}  ) and serp3.pob_id is null	 and ( ( concat(substr(serp3.recon_ky_cd,0,4), case when (substr(serp3.recon_ky_cd,5,3)) in ('001','002','003') then '1' when (substr(serp3.recon_ky_cd,5,3)) in ('004','005','006') then '2' when (substr(serp3.recon_ky_cd,5,3)) in ('007','008','009' ) then '3' when (substr(serp3.recon_ky_cd,5,3)) in ('010','011','012' ) then '4' else null end ))>${fscl_yr_prd_con} ))  then 'KLD'
		      when ( ((case when ord_sni_dmnsn.pri_bkt is null then 'null' else ord_sni_dmnsn.pri_bkt end)==(case when bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt is null then 'null' else bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt end)) and ((case when ord_sni_dmnsn.in_out_omc_rsk_bkt is null then 'null' else ord_sni_dmnsn.in_out_omc_rsk_bkt end)==(case when bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt is null then 'null' else bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt end )) and ( case when (bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind=='n' and serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt) or (lower(bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind)='y' ) then true  else false end)
		      and  ( case when (lower(bmt_sni_asmnt_fd_srtr_dmnsn.estmtd_inv_dt_ind) = 'n' and ( case when month(estmd_inv_dt)==11 or month(estmd_inv_dt)==12 then concat((year(estmd_inv_dt)+1) , '1') when month(estmd_inv_dt)==2 or month(estmd_inv_dt)==3 or month(estmd_inv_dt)==4 then concat(year(estmd_inv_dt), '2') when month(estmd_inv_dt)==5 or month(estmd_inv_dt)==6 or month(estmd_inv_dt)==7 then concat(year(estmd_inv_dt),'3') when month(estmd_inv_dt)==8 or month(estmd_inv_dt)==9 or month(estmd_inv_dt)==10 then concat(year(estmd_inv_dt), '4') when month(estmd_inv_dt)==1 then concat(year(estmd_inv_dt), '1') end<=${fscl_yr_prd_con} )) or lower(bmt_sni_asmnt_fd_srtr_dmnsn.estmtd_inv_dt_ind)='y' then true  else false end) and ( ( concat(substr(serp3.recon_ky_cd,0,4), case when (substr(serp3.recon_ky_cd,5,3)) in ('001','002','003') then '1' when (substr(serp3.recon_ky_cd,5,3)) in ('004','005','006') then '2' when (substr(serp3.recon_ky_cd,5,3)) in ('007','008','009' ) then '3' when (substr(serp3.recon_ky_cd,5,3)) in ('010','011','012' ) then '4' else null end ))>${fscl_yr_prd_con}  ))  then bmt_sni_asmnt_fd_srtr_dmnsn.rev_rec_cd
		      else 'KOP' 
		      end 
		    end
		    else rvn_rcgn_cgy_cd_ord_adj
		  end as cp_rev_recgn_cgy_cd
    from serptemptable3 serp3
    left outer join (select * from (select deals.*,row_number() over(partition by deals.deal_id order by deals.deal_vrsn_nr desc) as rank from ${dbcommonlr1uat}.deal_dmnsn deals)a where a.rank=1) deal_dmnsn  on deal_dmnsn.deal_id = serp3.deal_id
    left outer join (select * from  (select quotes.*, row_number() over(partition by quotes.asset_quote_nr_cd order by quotes.asset_quote_vrsn_cd desc ) as rank from ${dbcommonlr1uat}.quotes_fact quotes) a where a.rank=1) quotes_fact on quotes_fact.asset_quote_nr_cd= split(serp3.quote_id,'-')[0]
    left outer join (select * from (select *,row_number() over (partition by hpe_quote_flags_sls_qtn_id_id,hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd order by ins_gmt_ts) as rw_nm from ${dbcommonlr1uat}.hpe_qt_flags_dmnsn) x where rw_nm = 1) hpe_qt_flags_dmnsn on quotes_fact.quote_header_sls_qtn_id_id=hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_id_id and quotes_fact.quote_header_sls_qtn_vrsn_sqn_nr_cd=hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd
    left outer join (select case when count(distinct case when ucid_id is null then null else ucid_id end) >= 1 then 'cto' else 'bto' end as cto_bto ,asset_quote_nr_cd from  ${dbcommonlr1uat}.quotes_fact group by asset_quote_nr_cd) cto on cto.asset_quote_nr_cd=split(serp3.quote_id,'-')[0]
    left outer join (select * from (select *,row_number() over (partition by hpe_opty_i_nm order by ins_gmt_ts) rw_num from ${dbcommonlr1uat}.opty_fact) where rw_num = 1) opty_fact on opty_fact.hpe_opty_i_nm = serp3.opty_id
    left outer join ${dbcommonlr1uat}.pdm_mtrl_plnt_grp_dmnsn mtrl_plnt on mtrl_plnt.mtrl_plnt_mtrl_id=serp3.mtrl_nr and mtrl_plnt.mtrl_plnt_cd=serp3.plnt_cd
    left outer join (select * from (select *,row_number() over (partition by idoc_nr,e1edk01_idoc_dcmt_nr,e1edp01_itm_nr order by ins_gmt_ts) rw_num from ${dbcommonlr1uat}.ord_sni_dmnsn) x where rw_num = 1) ord_sni_dmnsn on ord_sni_dmnsn.idoc_nr=serp3.src_idoc_nr and ord_sni_dmnsn.e1edk01_idoc_dcmt_nr= serp3.ord_nr and ord_sni_dmnsn.e1edp01_itm_nr= serp3.sls_ord_ln_itm_id
    left outer join ${dbcommonlr1uat}.bmt_sni_asmnt_fd_srtr_dmnsn  bmt_sni_asmnt_fd_srtr_dmnsn on 
    (case when bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt is null then 'null' else bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt end) = (case when ord_sni_dmnsn.pri_bkt is null then 'null' else ord_sni_dmnsn.pri_bkt end) and
    (case when bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt is null then 'null' else bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt end ) = (case when ord_sni_dmnsn.in_out_omc_rsk_bkt is null then 'null' else ord_sni_dmnsn.in_out_omc_rsk_bkt end) 
    left outer join ${dbcommonlr1uat}.bmt_sab_cut_off_fd_srtr_dmnsn sab_cut_off_fd_srtr_dmnsn on sab_cut_off_fd_srtr_dmnsn.fscl_yr_qtr_dsply_cd = (case when month(serp3.actl_dlvry_dt)==11 or month(serp3.actl_dlvry_dt)==12 then concat((year(serp3.actl_dlvry_dt)+1) , '-Q1') when month(serp3.actl_dlvry_dt)==2 or month(serp3.actl_dlvry_dt)==3 or month(serp3.actl_dlvry_dt)==4 then concat(year(serp3.actl_dlvry_dt), '-Q2') when month(serp3.actl_dlvry_dt)==5 or month(serp3.actl_dlvry_dt)==6 or month(serp3.actl_dlvry_dt)==7 then concat(year(serp3.actl_dlvry_dt),'-Q3') when month(serp3.actl_dlvry_dt)==8 or month(serp3.actl_dlvry_dt)==9 or month(serp3.actl_dlvry_dt)==10 then concat(year(serp3.actl_dlvry_dt), '-Q4') when month(serp3.actl_dlvry_dt)==1 then concat(year(serp3.actl_dlvry_dt), '-Q1') end) and 
    sab_cut_off_fd_srtr_dmnsn.sgm_cd = serp3.sgmtl_rptg_cd
    left outer join ${dbfinancnamelr1uat}.rvn_rcgn_pstg_dmnsn rvn_rcgn_pstg_dmnsn on serp3.pob_id=rvn_rcgn_pstg_dmnsn.prfm_obgn_id and serp3.cntrct_id=rvn_rcgn_pstg_dmnsn.rvn_rcgn_cntrct_id and serp3.recon_ky_cd=rvn_rcgn_pstg_dmnsn.rvn_rcncltn_ky
    left outer join (select * from (select *,row_number() over (partition by opty_i_11_nm order by ins_gmt_ts) rw_num from ${dbcommonlr1uat}.opty_prod_dmnsn) where rw_num = 1) opty_prod_dmnsn on opty_fact.opty_i_3_nm = opty_prod_dmnsn.opty_i_11_nm
    left outer join ${dbcommonlr1uat}.acct_dmnsn acct_dmnsn on opty_fact.acct_i_20_nm = acct_dmnsn.acct_id
    left outer join (select * from (select *,row_number() over (partition by opt_4_nm order by ins_gmt_ts) rw_num from ${dbcommonlr1uat}.alnc_and_chnl_ptnrs_dmnsn) where rw_num = 1 ) c on opty_fact.opty_i_3_nm=c.opt_4_nm
    left outer join (select * from (select *,row_number() over (partition by opty_i_29_nm order by ins_gmt_ts) rw_num from ${dbcommonlr1uat}.opty_team_mmbr_dmnsn) where rw_num = 1) d on opty_fact.opty_i_3_nm= d.opty_i_29_nm
    left outer join ${dbcommonlr1uat}.clndr_rpt cldr_rpt_fact_book on (opty_prod_dmnsn.bookshi_2_dt = cldr_rpt_fact_book.cldr_dt)
    left outer join ${dbcommonlr1uat}.clndr_rpt cldr_rpt_fact_close on (opty_prod_dmnsn.opty_cl_2_dt = cldr_rpt_fact_close.cldr_dt)
    left outer join exch_rt_tbl exch on opty_fact.curr_cd = exch.frm_curr_cd and month(opty_prod_dmnsn.bookshi_2_dt) = month(exch.etry_vld_frm_ts)
    and year(opty_prod_dmnsn.bookshi_2_dt) = year(exch.etry_vld_frm_ts)
    left outer join (select * from (select *,row_number() over (partition by deal_ky order by ins_gmt_ts) rw_num from ${dbcommonlr1uat}.deal_prty_rol_dmnsn)x where rw_num = 1) deal_prty_rol_dmnsn on deal_dmnsn.deal_ky =  deal_prty_rol_dmnsn.deal_ky -- validate join conditions
    left outer join ${dbcommonlr1uat}.deal_rslr_a_dmnsn on deal_dmnsn.deal_ky = deal_rslr_a_dmnsn.deal_ky
    left outer join ${dbcommonlr1uat}.prty_asscn_dmnsn prty_asscn_dmnsn on quotes_fact.mdcp_org_id_id = prty_asscn_dmnsn.prty_asscn_vl_cd
    """)

    val tgtcolumns = spark.sql(s"select * from ${dbfinancnamelr1}.secrd_rpt_fact_wo_pn_tmp limit 0").columns

    // re-arrange columns based on target table

    val dataloaddf = salesshipmentdealquotesdf.select(Utilities.loadSelectExpr(salesshipmentdealquotesdf.columns, tgtcolumns): _*)

    dataloaddf.repartition(10).write.mode("overwrite").insertInto(dbfinancnamelr1 + ".secrd_rpt_fact_wo_pn_tmp")

    logger.info("+++++++++++##################secrd_rpt_fact_wo_pn_tmp table loaded ##################+++++++++++")

    val tgtcount = spark.sql(s"select * from ${dbfinancnamelr1}.secrd_rpt_fact_wo_pn_tmp").count.toInt

    tgtcount match {
      case 0 =>
        logger.error("//************* data load failed")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtcount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* data loaded into " + tgtTblConsmtn + " ,count:" + tgtcount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtcount)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

    spark.catalog.dropTempView("serptemptable1")
    spark.catalog.dropTempView("serptemptable2")
    spark.catalog.dropTempView("serptemptable3")
    spark.catalog.dropTempView("serptemptable5")
    spark.catalog.dropTempView("finaltemptable")
    spark.catalog.dropTempView("exch")
    spark.catalog.dropTempView("ratetable")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } finally {
    logger.info("//*********************** Log End for SERPSecuredReporting.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
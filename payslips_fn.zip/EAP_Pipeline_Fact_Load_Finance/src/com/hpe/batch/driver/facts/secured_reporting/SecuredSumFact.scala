package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

object SecuredSumFact extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true
  var fileBasePath = propertiesObject.getFileBasePath()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName().trim()

  logger.info("//*********************** Log Start for SecuredSumFact.scala ************************//")
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  try {

    //val tgtTblConsmtn = "ea_fin.secrd_rpt_fact_bkp_1710"
    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn, fileBasePath, dbName))

    //***************************Audit Properties********************************//
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_secured_quotes_fact")
    auditObj.setAudObjectName(objName)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)

    if (tgtTblConsmtn.split("\\.", -1).size != 2) {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    val dfSelectSecured = spark.sql(s"""
SELECT
	fscl_yr_prd_cd,
	sgm_lvl_3,
	MAX(pch_lvl_3),
	ctry_nm,
	cust_sgm_nm,
	SUM(ttl_rvn_amt) AS ttl_rvn_amt,
	SUM(cp_nt_rvn_usd_amt) AS nt_rvn_amt_usd,
	SUM(estmd_rvn_usd_amt) AS estmd_std_cst_grp_curr_usd_amt,
	SUM(ttl_cst_sls_amt) AS ttl_cst_sls_amt,
	SUM(fctry_mrgn_amt) AS fctry_mrgn_amt,
	SUM(grs_mrgn_amt) AS grs_mrgn_amt,
	SUM(ord_itm_qty) AS ord_itm_qty_cd,
	SUM(rvn_dlta_qty) AS rvn_dlta_qty,
	MAX(nt_prc_usd_amt) AS nt_prc_cd,
	MAX(src_sys_cd)AS src_sys_cd,
	MAX(ord_crt_dt)AS ord_crt_dt,
	MAX(cp_rtm_nm) AS cp_rtm_nm,
	MAX(ord_typ_cd) AS ord_typ_cd,
	MAX(mtrl_nr) AS mtrl_nr,
	MAX(cp_sldt_prty_id) AS cp_sldt_prty_id,
	MAX(cp_shpt_prty_id) AS cp_shpt_prty_id,
	MAX(bll_to_cd) AS bll_to_cd,
	MAX(cp_end_cust_prty_id) AS cp_end_cust_prty_id,
	MAX(pch_lvl_4) AS pch_lvl_4,
	pch_lvl_5 AS pch_lvl_5,
	MAX(pch_lvl_6) AS pch_lvl_6,
	MAX(pch_lvl_7) AS pch_lvl_7,
	MAX(pch_lvl_8) AS pch_lvl_8,
	MAX(sgm_lvl_5) AS sgm_lvl_5,
	MAX(sgm_lvl_6) AS sgm_lvl_6,
	MAX(sgm_lvl_7) AS sgm_lvl_7,
	MAX(sgm_lvl_8) AS sgm_lvl_8,
	MAX(fscl_yr_nr) AS fscl_yr_nr,
	MAX(fscl_qtr_nr) AS fscl_qtr_nr,
	MAX(fscl_prd_nr) AS fscl_prd_nr,
	MAX(cp_rev_recgn_cgy_cd) AS cp_rev_recgn_cgy_cd,
	MAX(cp_rev_hdr_nm) AS cp_rev_hdr_nm,
	MAX(cp_incd_excld) AS incd_excld_cd,
	sgmtl_rptg_cd,
	SUM(cp_nt_rvn_usd_amt) AS cp_nt_rvn_usd_amt,
	SUM(cp_net_inv_usd_amt) AS cp_net_inv_usd_amt,
	SUM(cp_grs_inv_usd_amt) AS cp_grs_inv_usd_amt,
	SUM(cp_nt_rvn_amt) AS cp_nt_rvn_amt,
	cp_end_cust_prty_nm,
	cp_prft_ctr_cd,
	SUM(cp_ndp_usd_amt) AS cp_ndp_usd_amt,
	SUM(cp_grs_usd_amt) AS cp_grs_usd_amt,
	SUM(cp_entprs_std_cst_usd_amt) AS cp_entprs_std_cst_usd_amt,
	SUM(cp_tot_cst_of_sls_usd_amt) AS cp_tot_cst_of_sls_usd_amt,
	prft_cntr_cd,
	shp_to_cd,
	sld_to_cd
FROM
	${srcTableName}
GROUP BY
	fscl_yr_prd_cd,
	sgm_lvl_3,
	pch_lvl_5,
	ctry_nm,
	cust_sgm_nm,
	sgmtl_rptg_cd,
	cp_end_cust_prty_nm,
	cp_prft_ctr_cd,
	prft_cntr_cd,
	shp_to_cd,
	sld_to_cd
""")

    val load_status = Utilities.storeDataFrame(dfSelectSecured, "overwrite", "ORC", tgtTblConsmtn, configObject)
    val tgtCount = spark.sql("select * from " + tgtTblConsmtn).count.toLong

    load_status match {
      case true =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
  } finally {
    logger.info("//*********************** Log End for SfdcSecuredReport.scala ************************//")
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) System.exit(1)
  }

}
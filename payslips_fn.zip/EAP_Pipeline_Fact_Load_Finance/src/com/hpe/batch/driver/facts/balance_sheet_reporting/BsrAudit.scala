package com.hpe.batch.driver.facts.balance_sheet_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
object BsrAudit extends App {
 //**************************Driver properties******************************//
  
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val ins_ts=Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
  val upd_ts=null
  val ld_jb_id=ld_jb_nr+'_'+batchId
  logger.info("First log")
  
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

  val transformeSrcdDF = spark.sql("""select count(*) from """ + propertiesObject.getSrcTblConsmtn() )

  val src_count = transformeSrcdDF.count().toInt
  
  var dbNameSrc = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0)
  
  logger.info("Target Database: "+dbNameConsmtn)
  
  logger.info("Source DataBase: "+dbNameSrc)  

import spark.implicits._

  val CurrentQuarter=propertiesObject.getCurrentQuarter()
  val PreviousQuarter=propertiesObject.getPreviousQuarter()
  val CurrentYear=propertiesObject.getCurrentYear()
  val PreviousYear=propertiesObject.getPreviousYear()
  //println(CurrentQuarter, PreviousQuarter,CurrentYear,PreviousYear)
  try{
   var curr_ytd_val="(1)"
  var prev_ytd_val="(1)"
  var curr_period="(1)"
  var prev_period="(1)"
  var curr_prev_qrtr_query="select"
  var curr_prev_ytd_query="select"
  if (CurrentQuarter=="1"){
      curr_ytd_val="(0,1,2,3)"
      curr_period="(1,2,3)"
    }
    else if(CurrentQuarter=="2"){
      curr_ytd_val="(0,1,2,3,4,5,6)"
      curr_period="(4,5,6)"
    }
    else if(CurrentQuarter=="3"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
      curr_period="(7,8,9)"
    }
    else if(CurrentQuarter=="4"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
      curr_period="(10,11,12)"
    }
    if (PreviousQuarter=="1"){
      prev_ytd_val="(0,1,2,3)"
      prev_period="(1,2,3)"
    }
    else if(PreviousQuarter=="2"){
      prev_ytd_val="(0,1,2,3,4,5,6)"
      prev_period="(4,5,6)"
    }
    else if(PreviousQuarter=="3"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
      prev_period="(7,8,9)"
    }
    else if(PreviousQuarter=="4"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
      prev_period="(10,11,12)"
    }

//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_gn_ldgr_itm_aggr_temp")
val transformedDF = spark.sql(s"""
 -- create table ea_fin_r2_2itg.bsr_gn_ldgr_itm_aggr_temp as 
 select entrs_lgl_ent_ldgr_cd, grp_acct_nr,acct_nr,qrtr_attrbt,fscl_yr_nr,
case when fscl_yr_nr ='"""+CurrentYear+"""' and pstg_prd_nr in """+curr_ytd_val+""" then round(sum(gbl_curr_amt),2) else null end as Current_Qtr_YTD,
case when fscl_yr_nr ='"""+PreviousYear+"""' and pstg_prd_nr in """+prev_ytd_val+""" then round(sum(gbl_curr_amt),2) else null end as Prior_Qtr_YTD 
from """+dbNameConsmtn + "." +"""gnrl_ldgr_ln_itm_acct_number2 where gnrl_ldgr_acctng_cd='0L'  
and entrs_lgl_ent_ldgr_cd in ('AR00','AR15','BR10','BR20','BR40','BR65','BR66','BR70','BR81','BRMA','CA00','CA40','CA50','CA65','CA70','CA71','CA72','CA73','CA74','CA76','CA90','CAM1','CL00','CL20','CO00','CO10','CO20','CR00','CR01','DO00','DO10','DO45','EC00','EC45','GT00','GT10','HN00','HN10','JM00','MX00','MX40','MX50','MX60','MX70','MX75','MX85','MX90','MX94','MX97','MX98','NI00','NI10','PA10','PE00','PE20','PR10','PR11','PR12','PR20','PR30','PR40','PR50','PR61','PR62','PR70','PR80','PR85','SV10','US18','US27','US80','US86','US95','US97','US98','US99','USA4','USA9','USB3','USD5','USD6','USE0','USE3','USE4','USE5','USE7','USE8','USED','USF1','USG8','USH0','USJ0','USJE','USK0','USK3','USK4','USL2','USL4','USL5','USM0','USMD','USN5','USN8','USX4','USY5','USY9','USZ0','USZ4','VE00','VE10','VE20','VE30','VE50','VE51') 
group by entrs_lgl_ent_ldgr_cd, grp_acct_nr,acct_nr, fscl_yr_nr, qrtr_attrbt,pstg_prd_nr
  """)

 transformedDF.createOrReplaceTempView("bsr_gn_ldgr_itm_aggr_temp_aud")
  
//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_grp_ldgr_aggrt")

 val transformedDF2 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.bsr_grp_ldgr_aggrt as 
 select grp_acct_nr, entrs_lgl_ent_ldgr_cd, 
sum(current_qtr_ytd) as current_qtr_ytd, 
sum(prior_qtr_ytd) as prior_qtr_ytd
from bsr_gn_ldgr_itm_aggr_temp_aud group by grp_acct_nr, entrs_lgl_ent_ldgr_cd
  """)
  
transformedDF2.createOrReplaceTempView("bsr_grp_ldgr_aggrt_aud")
  
//spark.sql("drop table if exists ea_fin_r2_2itg.blnce_sht_reprtg_audit_fact")

val transformedDF3 = spark.sql(s"""
--  create table ea_fin_r2_2itg.blnce_sht_reprtg_audit_fact as
select a.zbpc_acdocc_c_1_cd as legalcompanycode_cd,
a.grp_acct_nr, 
b.mapping_country_with_threshold_ctry_cd as ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd as countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd as rgn_cd, 
b.tr_cd as tr_cd,
b.thresholdtext_cd as thresholdtext_cd,
b.thresholdvalue_cd, 
b.thresholdpercent_cd,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+""" then zbpc_acdocc_fscl_yr_nr else null end as curr_year,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" then zbpc_acdocc_fscl_yr_nr else null end as prev_year,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+""" then """+CurrentQuarter+""" else null end as curr_quarter,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" then """+PreviousQuarter+""" else null end as prev_quarter,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+"""  and a.zbpc_acdocc_pstg_prd_nr in """+curr_ytd_val+""" and a.zbpc_acdocc_adt_Trail_nm in ( 'TOPSIDE_ADJ', 'PRE_CONS_ADJ', 'PRE_CONS_ADJ_HIST', 'RECLASS_PRE', 'ALLOC_ADJ_HIST') then round(sum(amt_grp_curr),2) else null end as CurrQtr_YTD_PL10,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+prev_ytd_val+""" and a.zbpc_acdocc_adt_Trail_nm in ( 'TOPSIDE_ADJ', 'PRE_CONS_ADJ', 'PRE_CONS_ADJ_HIST', 'RECLASS_PRE', 'ALLOC_ADJ_HIST') then round(sum(amt_grp_curr),2) else null end as PriorQtr_YTD_PL10,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+curr_ytd_val+""" and a.zbpc_acdocc_adt_Trail_nm in ('ELIM_ADJ_HIST', 'RECLASS_ELIM', 'ELIM_ADJ') then round(sum(amt_grp_curr),2) else null end as CurrQtr_YTD_PL20,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+prev_ytd_val+""" and a.zbpc_acdocc_adt_Trail_nm in ('ELIM_ADJ_HIST', 'RECLASS_ELIM', 'ELIM_ADJ') then round(sum(amt_grp_curr),2) else null end as PriorQtr_YTD_PL20,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+"""  and a.zbpc_acdocc_pstg_prd_nr in """+curr_period+"""  and a.zbpc_acdocc_adt_Trail_nm in ( 'TOPSIDE_ADJ', 'PRE_CONS_ADJ', 'PRE_CONS_ADJ_HIST', 'RECLASS_PRE', 'ALLOC_ADJ_HIST') and a.zbpc_acdocc_trsn_typ_cd = 999  then round(sum(amt_grp_curr),2) else null end as CurrQtr_MM_PL10,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+prev_period+""" and a.zbpc_acdocc_adt_Trail_nm in ( 'TOPSIDE_ADJ', 'PRE_CONS_ADJ', 'PRE_CONS_ADJ_HIST', 'RECLASS_PRE', 'ALLOC_ADJ_HIST') and a.zbpc_acdocc_trsn_typ_cd = 999 then round(sum(amt_grp_curr),2) else null end as PriorQtr_MM_PL10,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+curr_period+""" and a.zbpc_acdocc_adt_Trail_nm in ('ELIM_ADJ_HIST', 'RECLASS_ELIM', 'ELIM_ADJ') and 
a.zbpc_acdocc_trsn_typ_cd = 999 then round(sum(amt_grp_curr),2) else null end as CurrQtr_MM_PL20,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+prev_period+""" and a.zbpc_acdocc_adt_Trail_nm in ('ELIM_ADJ_HIST', 'RECLASS_ELIM', 'ELIM_ADJ') 
and a.zbpc_acdocc_trsn_typ_cd = 999 then round(sum(amt_grp_curr),2) else null end as PriorQtr_MM_PL20
from """+dbNameConsmtn + "." +"""bpc_cnsldtn_trsn_0107  a inner join """+dbNameConsmtn + "." +"""cntry_thrs_mpng_cmpny_code b on a.zbpc_acdocc_c_1_cd = b.legalcompanycode_cd
where 
a.cnsldtn_grp_1_nm = 'G_HPE' 
and a.zbpc_acdocc_c_1_cd in ('AR00','AR15','BR10','BR20','BR40','BR65','BR66','BR70','BR81','BRMA','CA00','CA40','CA50','CA65','CA70','CA71','CA72','CA73','CA74','CA76','CA90','CAM1','CL00','CL20','CO00','CO10','CO20','CR00','CR01','DO00','DO10','DO45','EC00','EC45','GT00','GT10','HN00','HN10','JM00','MX00','MX40','MX50','MX60','MX70','MX75','MX85','MX90','MX94','MX97','MX98','NI00','NI10','PA10','PE00','PE20','PR10','PR11','PR12','PR20','PR30','PR40','PR50','PR61','PR62','PR70','PR80','PR85','SV10','US18','US27','US80','US86','US95','US97','US98','US99','USA4','USA9','USB3','USD5','USD6','USE0','USE3','USE4','USE5','USE7','USE8','USED','USF1','USG8','USH0','USJ0','USJE','USK0','USK3','USK4','USL2','USL4','USL5','USM0','USMD','USN5','USN8','USX4','USY5','USY9','USZ0','USZ4','VE00','VE10','VE20','VE30','VE50','VE51') group by a.zbpc_acdocc_c_1_cd, a.grp_acct_nr, a.zbpc_acdocc_fscl_yr_nr, a.zbpc_acdocc_pstg_prd_nr, a.zbpc_acdocc_adt_Trail_nm,
b.mapping_country_with_threshold_ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd,
b.tr_cd,
b.thresholdtext_cd, 
a.zbpc_acdocc_trsn_typ_cd,
b.thresholdvalue_cd,
b.thresholdpercent_cd
  """)

var loadStatus = Utilities.storeDataFrame(transformedDF3, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable, configObject)

logger.info("Created table: blnce_sht_reprtg_audit_fact")  
 // val src_count = 0
//var loadStatus =src_count


    //************************Completion Audit Entries*******************************//
    val tgt_count = transformedDF3.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    //auditObj.setAudObjectName("blnce_sht_reprtg_driver_fact")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } 
  
  catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}

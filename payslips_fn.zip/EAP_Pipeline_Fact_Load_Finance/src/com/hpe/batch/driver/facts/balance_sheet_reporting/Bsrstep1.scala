package com.hpe.batch.driver.facts.balance_sheet_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap

object Bsrstep1 extends App {
 //**************************Driver properties******************************//
  
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val ins_ts=Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
  val upd_ts=null
  val ld_jb_id=ld_jb_nr+'_'+batchId
  logger.info("First log")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  var dbNameSrcTbl = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0) 
  logger.info("Source DataBase: "+dbNameSrcTbl) 
  
  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

  val transformeSrcdDF = spark.sql("""select count(*) from """ + propertiesObject.getSrcTblConsmtn() )

  val src_count = transformeSrcdDF.count().toInt

  
import spark.implicits._
  val CurrentQuarter=propertiesObject.getCurrentQuarter()
  val PreviousQuarter=propertiesObject.getPreviousQuarter()
  val CurrentYear=propertiesObject.getCurrentYear()
  val PreviousYear=propertiesObject.getPreviousYear()
  try{
  var curr_ytd_val="(1)"
  var prev_ytd_val="(1)"
  var curr_prev_qrtr_query="select"
  var curr_prev_ytd_query="select"
  //var loadStatus =0
  if (CurrentQuarter=="1"){
      curr_ytd_val="(0,1,2,3)"
    }
    else if(CurrentQuarter=="2"){
      curr_ytd_val="(0,1,2,3,4,5,6)"
    }
    else if(CurrentQuarter=="3"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
    }
    else if(CurrentQuarter=="4"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
    }
    if (PreviousQuarter=="1"){
      prev_ytd_val="(0,1,2,3)"
    }
    else if(PreviousQuarter=="2"){
      prev_ytd_val="(0,1,2,3,4,5,6)"
    }
    else if(PreviousQuarter=="3"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
    }
    else if(PreviousQuarter=="4"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
    }

//joining with gl line item with account dimension table to get group account number
//spark.sql("drop table if exists ea_fin_r2_2itg.gnrl_ldgr_ln_itm_acct_number2")

val gnrl_ldgr_ln_itm_acct_number2 = "gnrl_ldgr_ln_itm_acct_number2"    
    
val transformedDF = spark.sql(s"""
  --create table ea_fin_r2_2itg.gnrl_ldgr_ln_itm_acct_number2 as 
select 
a.fscl_prd_cd,
a.acctng_dcmt_entrd_dt,
a.dcmt_etry_ts,
a.last_dcmt_chgd_by_trsn_dt,
a.last_dcmt_upd_dt,
a.exch_rate_dt,
a.trsn_cd,
a.crss_co_cd_pstg_trsn_nr,
a.rfnc_dcmt_nr,
a.rcrrg_etry_dcmt_nr,
a.rcrrg_etry_fscl_yr_nr,
a.rcrrg_etry_dcmt_co_cd,
a.rvrs_dcmt_nr,
a.rvrs_dcmt_fscl_yr_nr,
a.dcmt_hdr_txt,
a.curr_cd as gnrl_ldge_ln_itm_curr_cd,
a.exch_rate,
a.cprt_gc_cd,
a.gc_exch_rate,
a.atmtc_csh_dscnt_ind,
a.uplnd_dlvry_cst_amt,
a.dcmt_pstd_prv_prd_ind,
a.bsn_trsn_cd,
a.sssn_nm,
a.archd_orgl_dcmt_nm,
a.dcmt_hdr_extrc_id,
a.dcmt_ctrl_inrn_dcmt_typ_cd,
a.lcr_cd,
a.scnd_lcr_cd,
a.thrd_lcr_cd,
a.scnd_lcr_exch_rate,
a.thrd_lcr_exch_rate,
a.frst_lcr_trnsltn_src_curr_ind,
a.scnd_lcr_trnsltn_src_curr_ind,
a.scnd_lcr_trnsltn_dt_typ_cd,
a.thrd_lcr_trnsltn_dt_typ_cd,
a.dcmt_rvrsl_ind,
a.rvrs_pstg_plnd_dt,
a.atmtc_tx_cltn_ind,
a.scnd_lcr_typ_cd,
a.thrd_lcr_typ_cd,
a.frst_exch_rate_cd,
a.scnd_exch_rate_cd,
a.gnrl_ldgr_acct_amt_xcld_tx_ind,
a.src_co_cd,
a.sls_tx_dtl_scn_ind,
a.dta_trnsfr_stts_ind,
a.tx_exch_rate,
a.lcr_tx_rate,
a.rqst_lt_nr,
a.bll_of_exch_bfr_pmnt_due_dt_ind,
a.rvrsl_dcmt_rsn_cd,
a.prkd_dcmt_usr_nm,
a.acctng_dcmt_prkd_dt,
a.dcmt_prkd_ts,
a.brnh_cd,
a.inv_pgs_nr,
a.dscnt_dcmt_etry_ind,
a.frst_rfnc_fld_inrn_dcmt_hdr_txt,
a.scnd_rfnc_fld_inrn_dcmt_hdr_txt,
a.dcmt_rvrsd_rvrsl_cd,
a.inv_rcpt_dt,
a.ldgr_grp_cd,
a.real_estte_mgmt_mndt_cd,
a.altv_rfnc_dcmt_nr,
a.tx_rptg_dt,
a.fi_dcmt_clsfn_cd,
a.splt_pstg_fi_dcmt_ind,
a.csh_rlvnt_dcmt_ind,
a.dcmt_fllw_on_ind,
a.opn_itm_trnsfrd_reorg_ind,
a.cmpnnt_sb_set_cd,
a.exch_rate_typ_cd,
a.frst_lcr_mkt_dta_exch_rate,
a.scnd_lcr_mkt_dta_exch_rate,
a.thrd_lcr_mkt_dta_exch_rate,
a.mlt_curr_acctng_dcmt_ind,
a.rsbmssn_dt,
a.sndr_lgcl_sys_cd,
a.acctng_dcmt_sndr_sys_cd,
a.acctng_dcmt_sndr_sys_fscl_yr_nr,
a.inrn_asngd_sb_id_nr,
a.gnrl_ldgr_bsn_trsn_grp_cd,
a.ctrlng_bsn_trsn_cd,
a.rfnc_dcmt_typ_cd,
a.gnr_sys_dcmt_nr,
a.cst_acctng_spcl_valtn_dt,
a.sndr_sys_ctrlng_dcmt_nr,
a.sndr_sys_ctrlng_ar_cd,
a.acctng_prncpl_cd,
a.trnsfr_vrnt_intr_co_asst_cd,
a.dcmt_entrd_ldgr_spcf_ind,
a.ar_lmtn_pstg_ind,
a.rprssng_stts_cd,
a.prtl_prsng_ind,
a.inv_typ_ind,
a.anxtn_amt,
a.anxtn_pct,
a.vt_fl_exctn_dt,
a.dcmt_stts_cd,
a.dcmt_cgy_pmnt_rqst_cd,
a.ddctn_rsn_cd,
a.rqst_rgn_cd,
a.rvrsl_rsn_cd,
a.actvy_grp_fl_nm,
a.int_fml_cd,
a.int_cltn_dt,
a.pstg_dt,
a.actl_pstg_dy_ind,
a.last_chg_dt,
a.last_chg_ts,
a.pmnt_trnsfr_typ_cd,
a.crdt_crd_typ_cd,
a.crdt_crd_nr,
a.pmnt_ststcl_samplg_blck_ind,
a.dcmt_lt_nr,
a.rspnsbl_usr_nm,
a.inv_pmnt_crtfn_cd,
a.prmpt_pmnt_act_xcld_ind,
a.bdgt_dcmt_cd,
a.trsry_ofst_stts_cd,
a.rec_rfr_dt,
a.dcmt_cndn_nr,
a.dcmt_blck_ind,
a.cntrct_dcmt_id,
a.pmnt_bss_dcmt_typ_cd,
a.pmnt_bss_dcmt_nr,
a.pmnt_bss_dcmt_dt,
a.intl_bnk_acct_nr,
a.incmg_dcmt_dt,
a.gnrl_ldgr_acctng_cd,
a.entrs_lgl_ent_ldgr_cd,
a.fscl_yr_nr,
a.acctng_dcmt_id,
a.pstg_itm_ldgr_cd,
a.gnrl_ldgr_fscl_yr_nr,
a.ldgr_spcf_acctng_dcmt_nr,
a.rec_typ_cd,
a.trsn_typ_cd,
a.gnrl_ldgr_trsn_typ_cd,
a.sys_bsn_trsn_cd,
a.bsn_trsn_typ_cd,
a.rfnc_prcgr_cd,
a.src_dcmt_lgcl_sys_cd,
a.rfnc_org_unt_cd,
a.src_dcmt_nr,
a.rfnc_dcmt_ln_itm_nr,
a.rfnc_dcmt_ln_itm_grp_nr,
a.prtl_dcmt_blcd_nr,
a.itm_rvrsng_otr_itm_ind,
a.rvrsd_itm_ind,
a.tru_rvrsl_ind,
a.rvrs_rfnc_trsn_dcmt_nr,
a.rvrs_dcmt_rfnc_org_cd,
a.rvrs_dcmt_rfnc_dcmt_nr,
a.dcmt_blcd_rvrsl_cd,
a.trnsfrng_itm_ind,
a.trnsfrd_ln_itm_ind,
a.prv_dcmt_rfnc_trsn_cd,
a.prv_rfnc_dcmt_lgcl_sys_cd,
a.prv_dcmt_rfnc_org_unt_cd,
a.prv_dcmt_rfnc_nr,
a.prv_dcmt_rfnc_ln_itm_nr,
a.prv_prtl_dcmt_blcd_nr,
a.mltpl_prcdng_dcmt_rfnc_id,
a.scndry_jrnl_etry_ind,
a.blc_tc_cd,
a.tc_cd,
a.co_curr_cd,
a.gbl_curr_cd,
a.frst_dfnd_curr_cd,
a.scnd_dfnd_curr_cd,
a.thrd_dfnd_curr_cd,
a.frth_dfnd_curr_cd,
a.ffth_dfnd_curr_cd,
a.sxth_dfnd_curr_cd,
a.svnth_dfnd_curr_cd,
a.eght_dfnd_curr_cd,
a.ctrlng_obj_curr_cd,
a.bs_unt_of_msr_cd,
a.valtn_qty_unt_of_msr_cd,
a.rfnc_qty_unt_of_msr_cd,
a.invy_qty_unt_of_msr_cd,
a.frst_addnl_unt_of_msr_cd,
a.scnd_addnl_unt_of_msr_cd,
a.thrd_addnl_unt_of_msr_cd,
a.ctrlng_obj_valtn_qty_unt_of_msr_cd,
a.acct_nr,
a.cst_cntr_cd,
a.pft_cntr_cd,
a.fnctl_ar_cd,
a.bsn_ar_cd,
a.ctrlng_ar_cd,
a.mgmt_grphy_unt_cd,
a.sndr_cst_cntr_cd,
a.ptnr_pft_cntr_cd,
a.ptnr_fnctl_ar_cd,
a.trdg_ptnr_bsn_ar_cd,
a.trdg_ptnr_co_id,
a.ptnr_mgmt_grphy_unt_cd,
a.tc_blc_amt,
a.tc_amt,
a.tc_grp_valtn_amt,
a.tc_pft_cntr_valtn_amt,
a.co_cd_curr_amt,
a.gbl_curr_amt,
a.frly_dfnd_curr_1_amt,
a.frly_dfnd_curr_2_amt,
a.frly_dfnd_curr_3_amt,
a.frly_dfnd_curr_4_amt,
a.frly_dfnd_curr_5_amt,
a.frly_dfnd_curr_6_amt,
a.frly_dfnd_curr_7_amt,
a.frly_dfnd_curr_8_amt,
a.gbl_curr_fx_amt,
a.gbl_curr_grp_valtn_fx_amt,
a.gbl_curr_pft_cntr_valtn_fx_amt,
a.gbl_curr_totl_prc_vrnc_amt,
a.gbl_curr_grp_valtn_totl_prc_vrnc_amt,
a.gbl_curr_pft_cntr_valtn_totl_prc_vrnc_amt,
a.gbl_curr_fx_prc_vrnc_amt,
a.gbl_curr_grp_valtn_fx_prc_vrnc_amt,
a.gbl_curr_pft_cntr_valtn_fx_prc_vrnc_amt,
a.ctrlng_obj_curr_amt,
a.lcr_invy_vl_amt,
a.gc_invy_vl_amt,
a.otr_curr_invy_vl_amt,
a.frth_curr_invy_vl_amt,
a.lcr_alt_invy_vl_amt,
a.gc_alt_invy_vl_amt,
a.otr_curr_alt_invy_vl_amt,
a.frth_curr_alt_invy_vl_amt,
a.lcr_mvng_avg_prc_amt,
a.gc_mvng_avg_prc_amt,
a.otr_curr_mvng_avg_prc_amt,
a.frth_curr_mvng_avg_prc_amt,
a.lcr_std_prc_amt,
a.gc_std_prc_amt,
a.otr_curr_std_prc_amt,
a.frth_curr_std_prc_amt,
a.lcr_alt_vl_amt,
a.gc_alt_vl_amt,
a.otr_curr_alt_vl_amt,
a.otr_curr_2_alt_vl_amt,
a.lcr_xtrn_vl_amt,
a.gc_xtrn_vl_amt,
a.otr_curr_xtrn_vl_amt,
a.frth_curr_xtrn_vl_amt,
a.lcr_sls_prc_vl_amt,
a.lcr_invy_vl_sls_prc_amt,
a.msr_qty,
a.cmpnnt_qty,
a.valtn_qty,
a.fx_valtn_qty,
a.frmt_qty,
a.frst_fld_addnl_qty,
a.scnd_fld_addnl_qty,
a.thrd_fld_addnl_qty,
a.ctrlng_obj_qty,
a.fx_ctrlng_obj_qty,
a.invy_mgmt_stk_qty,
a.dbt_crdt_ind,
a.pstg_prd_nr,
a.fscl_yr_vrnt_cd,
a.prd_yr_etry_cd,
a.dcmt_pstg_dt,
a.dcmt_dt,
a.dcmt_typ_cd,
a.acctng_dcmt_ln_itm_nr,
a.asngmt_nr,
a.pstg_ky_cd,
a.spcl_fnctn_dcmt_stts_cd,
a.itm_cgy_cd,
a.trsn_ky_cd,
a.ln_itm_pstd_amt,
a.dcmt_splt_itm_chgd_ind,
a.usr_nm,
a.utc_ts,
a.inrn_bsn_elmnt_ptnr_pft_cntr_cd,
a.orgn_obj_typ_cd,
a.gnrl_ldgr_acct_typ_cd as gnrl_ldgr_ln_itm_gnrl_ldgr_acct_typ_cd,
a.chrt_of_acct_cd,
a.alt_acct_nr as gnrl_ldgr_ln_itm_alt_acct_nr,
a.ctry_lgsn_chrt_of_acct_cd,
a.trsn_inv_dcmt_nr,
a.rlvnt_inv_fscl_yr_nr,
a.rlvnt_inv_ln_itm_nr,
a.fllw_on_dcmt_typ_cd,
a.rfnc_po_cgy_cd,
a.prchg_dcmt_nr,
a.prchg_dcmt_itm_nr,
a.acct_asngmt_sqnl_nr,
a.ln_itm_txt,
a.sls_ord_nr,
a.sls_ord_itm_nr,
a.gds_bsn_actvy_dn,
a.plnt_nm,
a.vndr_id,
a.cust_nr,
a.srvs_rndrd_dt,
a.acct_typ_cd,
a.spcl_gnrl_ldgr_trsn_ind,
a.tx_cgy_cd as gnrl_ldgr_ln_itm_tx_cgy_cd,
a.hs_bnk_id,
a.hs_bnk_acct_id as gnrl_ldgr_ln_itm_hs_bnk_acct_id,
a.opn_itm_mgmt_ind as gnrl_ldgr_ln_itm_opn_itm_mgmt_ind,
a.clarg_dt,
a.clarg_dcmt_nr,
a.clarg_dcmt_fscl_yr_nr,
a.dprc_ar_cd,
a.mn_asst_nr,
a.asst_sb_nr,
a.asst_vl_dt,
a.asst_trsn_typ,
a.trsn_typ_ctg_cd,
a.dprc_pstg_prd_fscl_yr_nr,
a.grp_asst_cd,
a.dprc_ar_grp_asst_cd,
a.dbn_rl_grp_cd,
a.fx_asst_clsfn_cd,
a.acct_dtrmn_cd as gnrl_ldgr_ln_itm_acct_dtrmn_cd,
a.ptnr_asst_mn_nr,
a.ptnr_asst_sb_nr,
a.orgl_vl_trsn_dt,
a.pst_cmplt_rtrmnt_ind,
a.asst_rtrmnt_pct,
a.prprtnl_vl_mnl_etry_ind,
a.cst_est_nr,
a.prc_ctrl_ind,
a.mtrl_prc_dtrmn_ind,
a.stk_valtn_cd,
a.vndr_stk_valtn_ind,
a.spcl_stk_ind,
a.valtn_ts,
a.spcl_invy_sls_dcmt_nr,
a.spcl_invy_sls_dcmt_itm_nr,
a.inrn_vlutd_spcl_invy_wbs_elmt_nr,
a.xtrn_vlutd_spcl_invy_wbs_elmt_nr,
a.vlutd_spcl_invy_splyr_cd,
a.valtn_typ_cd,
a.valtn_ar_cd,
a.lcr_unt_prc_amt,
a.gc_unt_prc_amt,
a.otr_curr_unt_prc_amt,
a.frth_curr_unt_prc_amt,
a.prs_cgy_cd,
a.mtrl_upd_srtr_cgy_cd,
a.prcmt_alt_prs_nr,
a.prcmt_prs_nr,
a.prd_typ_cd,
a.mtrl_ldgr_dcmt_itm_cd,
a.sndr_sys_entrs_lgl_ent_ldgr_cd,
a.sndr_sys_gnrl_ldgr_acct_cd,
a.sndr_sys_acct_asngmt_cd,
a.sndr_sys_acct_asngmt_typ_cd,
a.obj_nr,
a.ctrlng_obj_sb_nr,
a.cst_elmt_sb_dvsn_orgn_grp_cd,
a.ptnr_obj_nr,
a.ptnr_src_cd,
a.actvy_typ_dn,
a.ctrlng_obj_dbt_crdt_ind,
a.orgn_dbt_crdt_ind,
a.dbt_trsn_typ_cd,
a.incmplt_qty_ind,
a.ofst_acct_nr,
a.ofst_acct_typ_cd,
a.ln_itm_cmpltn_ind,
a.prsnl_nr,
a.pftblty_sgm_nr,
a.ctrlng_obj_pftblty_sgm_rlvnt_ind,
a.obj_cls_cd,
a.lgcl_sys_cd,
a.ptnr_entrs_lgl_ent_ldgr_cd,
a.ptnr_obj_cls_cd,
a.ptnr_obj_lgcl_sys_cd,
a.allctn_prc_dtrmn_cd,
a.orgn_obj_nr,
a.orgn_ord_nr,
a.orgn_cst_cntr_cd,
a.orgn_actvy_cd,
a.src_bsn_prs_cd,
a.orgn_pft_cntr_cd,
a.acct_asngmt_cgy_nm,
a.obj_typ_cd,
a.actvy_typ_cd,
a.ord_nr,
a.ord_ctg_nr,
a.wbs_elmt_id,
a.wbs_elmt_cd,
a.prj_dn,
a.acct_asngmt_ntwrk_nr,
a.actvy_cd,
a.bsn_prs_cd,
a.cst_obj_id,
a.acctng_cd,
a.bsn_actvy_cd,
a.ntfctn_cd,
a.optg_cncrn_cd,
a.ptnr_acct_asngmt_cgy_dn,
a.ptnr_obj_typ_cd,
a.ptnr_cst_cntr_actvy_cd,
a.ptnr_ord_nr,
a.ptnr_ord_cgy_cd,
a.ptnr_wbs_elmt_cd,
a.ptnr_prj_dn,
a.ptnr_sls_ord_nr,
a.ptnr_sls_ord_itm_nr,
a.ptnr_pftblty_sgm_nr,
a.ptnr_prj_ntwrk_cd,
a.ptnr_prj_ntwrk_actvy_cd,
a.ptnr_bsn_prs_cd,
a.ptnr_cst_obj_cd,
a.frst_ststcl_acct_asngmt_cd,
a.scnd_ststcl_acct_asngmt_cd,
a.thrd_ststcl_acct_asngmt_cd,
a.dta_inp_row_nr,
a.cst_acctng_dcmt_nr,
a.pstg_row_nr,
a.ctrlng_obj_frst_addnl_valtn_pstg_row_nr,
a.ctrlng_obj_scnd_addnl_valtn_pstg_row_nr,
a.ctrlng_obj_ffth_addnl_valtn_pstg_row_nr,
a.ctrlng_obj_sxth_addnl_valtn_pstg_row_nr,
a.ctrlng_obj_svnth_addnl_valtn_pstg_row_nr,
a.rfnc_dcmt_pstg_row_nr,
a.rfnc_dcmt_frst_addnl_valtn_pstg_row_nr,
a.rfnc_dcmt_scnd_addnl_valtn_pstg_row_nr,
a.rfnc_dcmt_ffth_addnl_valtn_pstg_row_nr,
a.rfnc_dcmt_sxth_addnl_valtn_pstg_row_nr,
a.rfnc_dcmt_svnth_addnl_valtn_pstg_row_nr,
a.wrk_itm_id,
a.rsrc_obj_id,
a.prdn_plng_cd,
a.ord_itm_nr,
a.sb_oprn_cd,
a.eqpmnt_nr,
a.fnctl_lctn_nm,
a.asmy_nm,
a.mntnc_actvy_typ_cd,
a.mntnc_ord_plng_ind,
a.pri_typ_cd,
a.pri_ind,
a.sprr_ord_nr,
a.mtrl_grp_cd,
a.plnd_prt_wrk_ind,
a.blng_typ_cd,
a.sls_org_cd,
a.dbn_chnl_cd,
a.dvsn_cd,
a.prod_id,
a.prod_sld_mtrl_grp_cd,
a.casng_grp_cd,
a.ctry_cd,
a.indy_typ_cd,
a.rgn_cd,
a.grp_id,
a.dmy_fnctn_cd,
a.prcmt_typ_cd,
a.blng_ptnr_id,
a.shp_to_ptnr_id,
a.ptnr_ctry_cd,
a.prod_hrchy_cd,
a.scnd_prod_hrchy_cd,
a.thrd_prod_hrchy_cd,
a.sls_ofc_cd,
a.sls_emp_nr,
a.shp_to_ctry_cd,
a.ic_trnsfr_cd,
a.mtrl_typ_cd,
a.csh_ldgr_entrs_lgl_ent_ldgr_cd,
a.csh_ldgr_gnrl_ldgr_acct_nr,
a.fncl_mgmt_ar_cd,
a.fnd_cntr_cd,
a.fndd_prgm_cd,
a.fnd_cd,
a.gnt_cd,
a.bdgt_prd_cd,
a.ptnr_fnd_cd,
a.ptnr_gnt_cd,
a.ptnr_bdgt_prd_cd,
a.jnt_vntr_cd,
a.jnt_vntr_eqty_grp_cd,
a.jnt_vntr_rcvry_cd,
a.ptnr_acct_nr,
a.jnt_vntr_blng_cd,
a.jnt_vntr_eqty_typ_cd,
a.prdn_dt,
a.bsn_ent_nr,
a.bld_nr,
a.lnd_nr,
a.rntl_obj_nr,
a.cntrct_nr,
a.srv_crg_cd,
a.stlmnt_unt_cd,
a.stlmnt_rfnc_dt,
a.ptnr_bsn_ent_nr,
a.ptnr_bld_nr,
a.ptnr_lnd_nr,
a.ptnr_rntl_unt_nr,
a.ptnr_cntrct_nr,
a.ptnr_srv_crg_ky,
a.ptnr_stlmnt_unt_cd,
a.ptnr_stlmnt_rfnc_dt,
a.unv_jrnl_etry_ln_itm_fllw_up_acn_cd,
a.mgrtd_jrnl_etry_itm_src_cd,
a.mgrtd_gnrl_ldgr_ln_itm_cd,
a.dta_aging_fltr_dt,
a.zjournal_items_acdoca04_dmy_fnctn_lgt__2_cd,
a.prfrmc_oblgtn_id,
a.zjournal_items_acdoca04_dmy_fnctn_lgt__3_cd,
a.cust_hrchy_lvl_1_nm,
a.soldto_prty_nm,
a.sls_dcmt_cd,
a.eqpmnt_2_nr,
a.src_itm_nr,
a.eqpmnt_cd,
a.end_cust_cd,
a.sls_doc_orgl_cd,
a.ord_typ_cd,
a.hghr_lvl_itm_nr,
a.ord_rsn_cd,
a.srv_cntrct_cd,
a.srv_cntrct_itm_cd,
a.otc_cd,
a.srv_evt_id,
a.sltn_3_cd,
a.ts_sls_mtn_cd,
a.unq_prod_id,
a.sltn_1_cd,
a.cust_sgm_cd,
a.upi_pft_cntr_cd,
a.po_cd,
a.po_itm_cd,
a.ven_odm_ic_pn_labr_cd,
a.valtn_clss_cd,
a.poem_cd,
a.emr_new_mtrl_cd,
a.go_mkt_ofr_id,
a.hpe_flflng_plnt_cd,
a.sltn_2_cd,
a.deal_id,
a.mrkt_rte_id,
a.prod_hrchy_nm,
a.clnt,
a.sls_grp_cd,
a.sls_dcmt_typ_cd,
a.pmnt_trms_cd,
a.frst_csh_dscnt_trms_end_dy_nr,
a.scnd_csh_dscnt_trm_end_dy_nr,
a.std_stlmnt_prd_dy_qty,
a.shrt_pmnt_prd_csh_dscnt_pct,
a.scnd_pmnt_prd_csh_dscnt_pct,
a.lcr_csh_dscnt_amt,
a.pmnt_mtd_ind,
a.pmnt_blck_cd,
a.nt_pmnt_due_dt,
a.csh_dscnt_due_dt,
a.bsln_due_cltn_dt,
a.vl_dt,
a.due_csh_dscnt_2_dt,
a.csh_dscnt_amt_dcmt_curr,
a.amt_elgbl_csh_dscnt_dcmt_curr,
a.fw_typ_cd,
a.grp_acct_nr as grp_acct_ln_itm_grp_acct_nr,
a.zjournal_items_bseg01_in_1_cd,
a.zjournal_items_bseg01_in_2_cd,
a.zjournal_items_bseg01_in_3_cd,
a.cst_elmt_nm,
a.obj_ky_nm,
a.zjournal_items_header1_rvrs_1_nm,
a.zjournal_items_header1_rvrs_2_nm,
a.lgcl_sys_nm,
a.zjournal_items_header1_rfnc_prcgr_cd,
a.zjournal_items_header1_acctng_dcmt_nr,
a.zjournal_items_header1_dcmt_typ_cd,
a.zjournal_items_header1_dcmt_dcmt_dt,
a.zjournal_items_header1_dcmt_stts_cd,
a.zjournal_items_header1_pstg_dcmt_dt,
a.zjournal_items_header1_co_cd,
a.zjournal_items_header1_co_sndr_sys_cd,
a.zjournal_items_header1_fncl_mgmt_ar_cd,
a.zjournal_items_header1_fscl_yr_nr,
a.incmg_dcmt_nr,
a.rsn_late_pmnt_cd,
a.zjournal_items_header1_ldgr_gnrl_ldgr_acctng_cd,
a.zjournal_items_header1_usr_nm,
a.zjournal_items_header1_ind_cd,
a.id_rvrsl_dcmt_ind,
a.zjournal_items_header1_scndry_jrnl_etry_cd,
a.opty_id,
a.mkt_sgm_cd,
a.mkt_ofrng_cd,
a.intgtn_fbrc_msg_id as gnrl_ldge_ln_itm_intgtn_fbrc_msg_id,
a.src_sys_upd_ts,
a.src_sys_ky,
a.lgcl_dlt_ind,
a.ins_gmt_ts,
a.upd_gmt_ts,
a.src_sys_extrc_gmt_ts,
a.src_sys_btch_nr,
a.fl_nm,
a.ld_jb_nr,
b.gl_account_ky,
b.msg_fnctn_cd,
b.chrt_of_accts_cd,
b.gnrl_ldgr_acct_nr,
b.grp_acct_nr,
b.grp_acct_nr as offset_grp_acct_nr,
b.pft_loss_stmt_acct_typ_cd,
b.gnrl_ldgr_acct_grp_cd,
b.samp_acct_nr,
b.co_id,
b.blc_sht_acct_ind,
b.acct_dlt_ind,
b.acct_crt_blck_ind,
b.acct_pstg_blck_ind,
b.acct_plng_b,
b.funtional_ar_cd,
b.rsrv_fld_nm,
b.gnrl_ldgr_acct_typ_cd,
b.last_int_cltn_prsd_dt,
b.last_int_cltn_dt,
b.gnrl_ldgr_acct_ky_word_txt,
b.lng_ky,
b.crtr_txt,
b.gnrl_ldgr_acct_lg_dn,
b.dcmt_etry_entrs_lgl_ent_ldgr_cd,
b.athzn_grp_cd,
b.acctng_clrk_id,
b.plng_lvl_cd,
b.scn_lyt_cd,
b.hs_bnk_id as gnrl_ldgr_acct_hs_bnk_id,
b.hs_bnk_acct_id,
b.acct_dtrmn_cd,
b.rcncltn_acct_ind,
b.tx_cgy_cd,
b.int_cltn_cd,
b.curr_cd,
b.sys_mngd_acct_cd,
b.csh_fw_acct_ind,
b.atmtc_acct_pstg_ind,
b.acct_ln_itm_dsply_ind,
b.acct_dltn_ind,
b.atmtc_pstg_splmnt_ind,
b.opn_itm_mgmt_ind,
b.gnrl_ldgr_co_acct_pstg_blck_ind,
b.int_cltn_frq_mth_qty,
b.allctn_fld_lyt_rl_cd,
b.alt_acct_nr,
b.rcncltn_acct_rdy_ind,
b.rcvry_cd,
b.cmmtmnt_itm_cd,
b.tx_cd_not_rqrd_ind,
b.lcr_blc_ind,
b.valtn_grp_cd,
b.infltn_id,
b.tlnc_grp_cd,
b.rsrv_scnd_fld_nm,
b.mca_prs_cd,
b.cst_elmt_cgy_cd,
b.actl_pstg_qty_unt_ind,
b.lng_idpt_msrmt_unt_frmt_cd,
CASE WHEN (a.pstg_prd_nr) IN (1,2,3) THEN '1' WHEN (a.pstg_prd_nr) IN (4,5,6) THEN '2' WHEN (a.pstg_prd_nr) IN (7,8,9) THEN '3' WHEN (a.pstg_prd_nr) IN (10,11,12) THEN '4' else NULL end as qrtr_attrbt,
b.intgtn_fbrc_msg_id from ${dbNameConsmtn}.gnrl_ldgr_ln_itm_trsn a 
left outer join ${dbNameConsmtn}.gnrl_ldgr_acct_dmnsn b on (a.chrt_of_acct_cd=b.chrt_of_accts_cd and a.acct_nr=b.gnrl_ldgr_acct_nr and a.entrs_lgl_ent_ldgr_cd=b.dcmt_etry_entrs_lgl_ent_ldgr_cd) left outer join ${dbNameConsmtn}.gnrl_ldgr_acct_dmnsn c on(a.chrt_of_acct_cd=c.chrt_of_accts_cd and a.entrs_lgl_ent_ldgr_cd=c.dcmt_etry_entrs_lgl_ent_ldgr_cd and a.ofst_acct_nr=c.gnrl_ldgr_acct_nr) where pstg_prd_nr <> 13
""")

var loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + gnrl_ldgr_ln_itm_acct_number2, configObject)

transformedDF.cache()

logger.info("Created table: gnrl_ldgr_ln_itm_acct_number2")

//creating aggregated table to improve performance
//spark.sql("drop table if exists ea_fin_r2_2itg.gnrl_ldgr_ln_itm_aggrt")

val transformedDF2 = spark.sql(s"""
  --create table ea_fin_r2_2itg.gnrl_ldgr_ln_itm_aggrt as 
  select sum(gbl_curr_amt) as gbl_curr_amt,offset_grp_acct_nr,dbt_crdt_ind,dcmt_typ_cd,
  gnrl_ldgr_acct_nr,fscl_yr_nr,qrtr_attrbt,pft_cntr_cd,cust_nr,ofst_acct_nr,vndr_id,
  entrs_lgl_ent_ldgr_cd,grp_acct_nr,pstg_prd_nr,mrkt_rte_id,acct_nr,
  pstg_ky_cd from ${dbNameConsmtn}.gnrl_ldgr_ln_itm_acct_number2 where gnrl_ldgr_acctng_cd='0L' 
  and fscl_yr_nr in('"""+CurrentYear+"""','"""+PreviousYear+"""')  
  group by offset_grp_acct_nr,dbt_crdt_ind,dcmt_typ_cd,gnrl_ldgr_acct_nr,fscl_yr_nr,qrtr_attrbt,pft_cntr_cd,cust_nr,ofst_acct_nr,vndr_id,entrs_lgl_ent_ldgr_cd,grp_acct_nr,pstg_prd_nr,mrkt_rte_id,acct_nr,pstg_ky_cd
  """)
  
loadStatus = Utilities.storeDataFrame(transformedDF2, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable, configObject)

logger.info("Created table: gnrl_ldgr_ln_itm_aggrt")
  
    //************************Completion Audit Entries*******************************//
val tgt_count = transformedDF2.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    //auditObj.setAudObjectName("blnce_sht_reprtg_driver_fact")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(0)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } 
  
  catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}

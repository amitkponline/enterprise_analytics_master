package com.hpe.batch.driver.facts.expenses

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import scala.util.control.Breaks._
import scala.collection.breakOut

object ExpenseAggregateFact extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()
  try {

    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'com.hpe.batch.hive.udfs.CRC64'""")

    logger.info("Initializing log for EXPENSE FACT, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    val consmptnTable = new StringBuilder()
    val dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()
    val dbName_common = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
      //dbName_common.append(propertiesObject.getDbName().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())
    //****************************Fact Code****************************************//
    spark.conf.set("spark.sql.crossJoin.enabled", "true")

    val maxTimeStamp = spark.sql("""select coalesce(FROM_UNIXTIME(unix_timestamp(max(ins_gmt_ts)) ,'yyyyMMddHHmmss'),'19000101000000') as max_ld_ts from """ + dbNameConsmtn + """.""" + consmptnTable + """ where upper(tbl_src) = 'GL LINE ITEM TRANSACTION'""").first.getString(0)

    //Utilities.readHistMaxLoadTimestampFact(sqlCon, propertiesObject.getObjName())

    logger.info("/****************************Max Load Timestamp: " + maxTimeStamp)

    val df_exp_dtl_select = spark.sql(s"""
SELECT crc64(lower(concat(coalesce(entrs_lgl_ent_ldgr_cd,'#'),coalesce(grp_acct_nr,'#'),coalesce(fscl_yr_nr,'#'),coalesce(gnrl_ldgr_trsn_typ_cd,'#'),coalesce(bsn_trsn_typ_cd,'#'),coalesce(co_curr_cd,'#'),coalesce(gbl_curr_cd,'#'),coalesce(frst_dfnd_curr_cd,'#'),coalesce(scnd_dfnd_curr_cd,'#'),coalesce(thrd_dfnd_curr_cd,'#'),coalesce(frth_dfnd_curr_cd,'#'),coalesce(ffth_dfnd_curr_cd,'#'),coalesce(sxth_dfnd_curr_cd,'#'),coalesce(svnth_dfnd_curr_cd,'#'),coalesce(eght_dfnd_curr_cd,'#'),coalesce(bs_unt_of_msr_cd,'#'),coalesce(acct_nr,'#'),coalesce(cst_cntr_cd,'#'),coalesce(pft_cntr_cd,'#'),coalesce(fnctl_ar_cd,'#'),coalesce(bsn_ar_cd,'#'),coalesce(ctrlng_ar_cd,'#'),coalesce(mgmt_grphy_unt_cd,'#'),coalesce(sndr_cst_cntr_cd,'#'),coalesce(dbt_crdt_ind,'#'),coalesce(pstg_prd_nr,'#'),coalesce(fscl_yr_vrnt_cd,'#'),coalesce(prd_yr_etry_cd,'#'),coalesce(dcmt_typ_cd,'#'),coalesce(pstg_ky_cd,'#'),coalesce(spcl_fnctn_dcmt_stts_cd,'#'),coalesce(chrt_of_acct_cd,'#'),coalesce(acct_typ_cd,'#'),coalesce(obj_nr,'#'),coalesce(ctrlng_obj_sb_nr,'#'),coalesce(ofst_acct_nr,'#'),coalesce(ofst_acct_typ_cd,'#'),coalesce(ord_nr,'#'),coalesce(ord_ctg_nr,'#'),coalesce(lgcl_sys_cd,'#'),coalesce(src_dcmt_lgcl_sys_cd,'#'),coalesce(table_src,'#'),coalesce(prchg_dcmt_itm_nr,'#'),coalesce(prchg_dcmt_nr,'#'),coalesce(tc_cd,'#'),coalesce(ctrlng_obj_curr_cd,'#'))))  as expense_aggregate_fact_ky,
 crc32(coalesce(grp_acct_nr,'')) as grp_acct_nr_ky
,crc32(coalesce(entrs_lgl_ent_ldgr_cd,'')) as entrs_lgl_ent_ldgr_cd_ky
,crc32(coalesce(acct_nr,'')) as acct_nr_ky 
,crc32(coalesce(cst_cntr_cd,'')) as cst_cntr_cd_ky
,crc32(coalesce(pft_cntr_cd,'')) as pft_cntr_cd_ky
,crc32(coalesce(fnctl_ar_cd,'')) as fnctl_ar_cd_ky
,crc32(coalesce(bsn_ar_cd,'')) as bsn_ar_cd_ky 
,crc32(coalesce(ctrlng_ar_cd,'')) as ctrlng_ar_cd_ky
,crc32(coalesce(mgmt_grphy_unt_cd,'')) as mgmt_grphy_unt_cd_ky   , 
entrs_lgl_ent_ldgr_cd,
grp_acct_nr,
fscl_yr_nr,
gnrl_ldgr_trsn_typ_cd,
bsn_trsn_typ_cd,
co_curr_cd,
gbl_curr_cd,
frst_dfnd_curr_cd,
scnd_dfnd_curr_cd,
thrd_dfnd_curr_cd,
frth_dfnd_curr_cd,
ffth_dfnd_curr_cd,
sxth_dfnd_curr_cd,
svnth_dfnd_curr_cd,
eght_dfnd_curr_cd,
bs_unt_of_msr_cd,
acct_nr,
cst_cntr_cd,
pft_cntr_cd,
fnctl_ar_cd,
bsn_ar_cd,
ctrlng_ar_cd,
mgmt_grphy_unt_cd,
sndr_cst_cntr_cd,
tc_amt,
co_cd_curr_amt,
gbl_curr_amt,
frly_dfnd_curr_1_amt,
frly_dfnd_curr_2_amt,
frly_dfnd_curr_3_amt,
frly_dfnd_curr_4_amt,
frly_dfnd_curr_5_amt,
frly_dfnd_curr_6_amt,
frly_dfnd_curr_7_amt,
frly_dfnd_curr_8_amt,
ctrlng_obj_curr_amt,
dbt_crdt_ind,
pstg_prd_nr,
fscl_yr_vrnt_cd,
prd_yr_etry_cd,
dcmt_pstg_dt,
dcmt_dt,
dcmt_typ_cd,
pstg_ky_cd,
spcl_fnctn_dcmt_stts_cd,
ins_gmt_ts_cd,
chrt_of_acct_cd,
acct_typ_cd,
obj_nr,
ctrlng_obj_sb_nr,
ofst_acct_nr,
ofst_acct_typ_cd,
ord_nr,
ord_ctg_nr,
acctng_dcmt_entrd_dt,
dcmt_etry_ts,
last_dcmt_chgd_by_trsn_dt,
last_dcmt_upd_dt,
lgcl_sys_cd,
src_dcmt_lgcl_sys_cd ,
table_src as tbl_src,
prchg_dcmt_itm_nr,
prchg_dcmt_nr,
ins_ts as ins_gmt_ts,
tc_cd,
ctrlng_obj_curr_cd
from ea_fin.expense_fact 
where  coalesce(from_unixtime(unix_timestamp(ins_ts),'yyyyMMddHHmmss'),'19010101000000') > ${maxTimeStamp}""")

    df_exp_dtl_select.createOrReplaceTempView("df_exp_dtl_select_tbl")

    val max_inc_ld_ts = spark.sql(s"""select coalesce(from_unixtime(unix_timestamp(max(ins_ts)),'yyyyMMddHHmmss'),'19000101000000') as max_ins_gmt_ts from ea_fin.expense_fact 
where  from_unixtime(unix_timestamp(ins_ts),'yyyyMMddHHmmss') > ${maxTimeStamp}""").first.getString(0)

    val incrementalCount = df_exp_dtl_select.count.toInt

    incrementalCount match {
      case 0 =>
        logger.info("/***************++++++++ No Incremental Records ++++++++***************/")
        auditObj.setAudBatchId(ld_jb_nr + "_" + max_inc_ld_ts)
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(0)
        auditObj.setAudTgtRowCount(0)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
        auditObj.setFlNm("")
        auditObj.setAudObjectName(propertiesObject.getObjName())
        auditObj.setSysBtchNr(ld_jb_nr)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("/***************++++++++ Incremental Records Available++++++++***************/")
        val df_exp_agg_select = spark.sql(s"""select * from ${dbNameConsmtn}.expense_aggregate_fact""")
        val df_exp_agg_union = df_exp_agg_select.union(df_exp_dtl_select)
        df_exp_agg_union.createOrReplaceTempView("exp_agg_union_tbl")
        val df_exp_agg_final = spark.sql(s"""
SELECT crc64(lower(concat(coalesce(entrs_lgl_ent_ldgr_cd,'#'),coalesce(grp_acct_nr,'#'),coalesce(fscl_yr_nr,'#'),coalesce(gnrl_ldgr_trsn_typ_cd,'#'),coalesce(bsn_trsn_typ_cd,'#'),coalesce(co_curr_cd,'#'),coalesce(gbl_curr_cd,'#'),coalesce(frst_dfnd_curr_cd,'#'),coalesce(scnd_dfnd_curr_cd,'#'),coalesce(thrd_dfnd_curr_cd,'#'),coalesce(frth_dfnd_curr_cd,'#'),coalesce(ffth_dfnd_curr_cd,'#'),coalesce(sxth_dfnd_curr_cd,'#'),coalesce(svnth_dfnd_curr_cd,'#'),coalesce(eght_dfnd_curr_cd,'#'),coalesce(bs_unt_of_msr_cd,'#'),coalesce(acct_nr,'#'),coalesce(cst_cntr_cd,'#'),coalesce(pft_cntr_cd,'#'),coalesce(fnctl_ar_cd,'#'),coalesce(bsn_ar_cd,'#'),coalesce(ctrlng_ar_cd,'#'),coalesce(mgmt_grphy_unt_cd,'#'),coalesce(sndr_cst_cntr_cd,'#'),coalesce(dbt_crdt_ind,'#'),coalesce(pstg_prd_nr,'#'),coalesce(fscl_yr_vrnt_cd,'#'),coalesce(prd_yr_etry_cd,'#'),coalesce(dcmt_typ_cd,'#'),coalesce(pstg_ky_cd,'#'),coalesce(spcl_fnctn_dcmt_stts_cd,'#'),coalesce(chrt_of_acct_cd,'#'),coalesce(acct_typ_cd,'#'),coalesce(obj_nr,'#'),coalesce(ctrlng_obj_sb_nr,'#'),coalesce(ofst_acct_nr,'#'),coalesce(ofst_acct_typ_cd,'#'),coalesce(ord_nr,'#'),coalesce(ord_ctg_nr,'#'),coalesce(lgcl_sys_cd,'#'),coalesce(src_dcmt_lgcl_sys_cd,'#'),coalesce(tbl_src,'#'),coalesce(prchg_dcmt_itm_nr,'#'),coalesce(prchg_dcmt_nr,'#'),coalesce(tc_cd,'#'),coalesce(ctrlng_obj_curr_cd,'#'))))  as expense_aggregate_fact_ky,
 crc32(coalesce(grp_acct_nr,'')) as grp_acct_nr_ky
,crc32(coalesce(entrs_lgl_ent_ldgr_cd,'')) as entrs_lgl_ent_ldgr_cd_ky
,crc32(coalesce(acct_nr,'')) as acct_nr_ky 
,crc32(coalesce(cst_cntr_cd,'')) as cst_cntr_cd_ky
,crc32(coalesce(pft_cntr_cd,'')) as pft_cntr_cd_ky
,crc32(coalesce(fnctl_ar_cd,'')) as fnctl_ar_cd_ky
,crc32(coalesce(bsn_ar_cd,'')) as bsn_ar_cd_ky 
,crc32(coalesce(ctrlng_ar_cd,'')) as ctrlng_ar_cd_ky
,crc32(coalesce(mgmt_grphy_unt_cd,'')) as mgmt_grphy_unt_cd_ky   , 
entrs_lgl_ent_ldgr_cd,
grp_acct_nr,
fscl_yr_nr,
gnrl_ldgr_trsn_typ_cd,
bsn_trsn_typ_cd,
co_curr_cd,
gbl_curr_cd,
frst_dfnd_curr_cd,
scnd_dfnd_curr_cd,
thrd_dfnd_curr_cd,
frth_dfnd_curr_cd,
ffth_dfnd_curr_cd,
sxth_dfnd_curr_cd,
svnth_dfnd_curr_cd,
eght_dfnd_curr_cd,
bs_unt_of_msr_cd,
acct_nr,
cst_cntr_cd,
pft_cntr_cd,
fnctl_ar_cd,
bsn_ar_cd,
ctrlng_ar_cd,
mgmt_grphy_unt_cd,
sndr_cst_cntr_cd,
SUM(tc_amt)as tc_amt,
SUM(co_cd_curr_amt) co_cd_curr_amt,
SUM(gbl_curr_amt) gbl_curr_amt,
SUM(frly_dfnd_curr_1_amt) frly_dfnd_curr_1_amt,
SUM(frly_dfnd_curr_2_amt) frly_dfnd_curr_2_amt,
SUM(frly_dfnd_curr_3_amt) frly_dfnd_curr_3_amt,
SUM(frly_dfnd_curr_4_amt) frly_dfnd_curr_4_amt,
SUM(frly_dfnd_curr_5_amt) frly_dfnd_curr_5_amt,
SUM(frly_dfnd_curr_6_amt) frly_dfnd_curr_6_amt,
SUM(frly_dfnd_curr_7_amt) frly_dfnd_curr_7_amt,
SUM(frly_dfnd_curr_8_amt) frly_dfnd_curr_8_amt,
SUM(ctrlng_obj_curr_amt) ctrlng_obj_curr_amt,
dbt_crdt_ind,
pstg_prd_nr,
fscl_yr_vrnt_cd,
prd_yr_etry_cd,
MAX(dcmt_pstg_dt) dcmt_pstg_dt,
MAX(dcmt_dt) dcmt_dt,
dcmt_typ_cd,
pstg_ky_cd,
spcl_fnctn_dcmt_stts_cd,
MAX(ins_gmt_ts_cd) ins_gmt_ts_cd,
chrt_of_acct_cd,
acct_typ_cd,
obj_nr,
ctrlng_obj_sb_nr,
ofst_acct_nr,
ofst_acct_typ_cd,
ord_nr,
ord_ctg_nr,
MAX(acctng_dcmt_entrd_dt) acctng_dcmt_entrd_dt,
MAX(dcmt_etry_ts) dcmt_etry_ts,
MAX(last_dcmt_chgd_by_trsn_dt) last_dcmt_chgd_by_trsn_dt,
MAX(last_dcmt_upd_dt) last_dcmt_upd_dt,
lgcl_sys_cd,
src_dcmt_lgcl_sys_cd ,
tbl_src,
prchg_dcmt_itm_nr,
prchg_dcmt_nr,
MAX(ins_gmt_ts) as ins_gmt_ts,
tc_cd,
ctrlng_obj_curr_cd
from exp_agg_union_tbl GROUP BY
crc32(coalesce(grp_acct_nr,''))
,crc32(coalesce(entrs_lgl_ent_ldgr_cd,''))
,crc32(coalesce(acct_nr,'')) 
,crc32(coalesce(cst_cntr_cd,''))
,crc32(coalesce(pft_cntr_cd,''))
,crc32(coalesce(fnctl_ar_cd,''))
,crc32(coalesce(bsn_ar_cd,'')) 
,crc32(coalesce(ctrlng_ar_cd,''))
,crc32(coalesce(mgmt_grphy_unt_cd,'')), 
entrs_lgl_ent_ldgr_cd,
grp_acct_nr,
fscl_yr_nr,
gnrl_ldgr_trsn_typ_cd,
bsn_trsn_typ_cd,
co_curr_cd,
gbl_curr_cd,
frst_dfnd_curr_cd,
scnd_dfnd_curr_cd,
thrd_dfnd_curr_cd,
frth_dfnd_curr_cd,
ffth_dfnd_curr_cd,
sxth_dfnd_curr_cd,
svnth_dfnd_curr_cd,
eght_dfnd_curr_cd,
bs_unt_of_msr_cd,
acct_nr,
cst_cntr_cd,
pft_cntr_cd,
fnctl_ar_cd,
bsn_ar_cd,
ctrlng_ar_cd,
mgmt_grphy_unt_cd,
sndr_cst_cntr_cd,
dbt_crdt_ind,
pstg_prd_nr,
fscl_yr_vrnt_cd,
prd_yr_etry_cd,
dcmt_typ_cd,
pstg_ky_cd,
spcl_fnctn_dcmt_stts_cd,
chrt_of_acct_cd,
acct_typ_cd,
obj_nr,
ctrlng_obj_sb_nr,
ofst_acct_nr,
ofst_acct_typ_cd,
ord_nr,
ord_ctg_nr,
lgcl_sys_cd,
src_dcmt_lgcl_sys_cd,
tbl_src,
prchg_dcmt_itm_nr,
prchg_dcmt_nr,
tc_cd,
ctrlng_obj_curr_cd
""")

        df_exp_agg_final.repartition(25).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + ".expense_aggregate_fact")

        val tgtCount = spark.sql(s"select * from ${dbNameConsmtn}.expense_aggregate_fact").count.toLong

        logger.info("/***************++++++++ Aggregate Fact Refreshed ++++++++***************/")

        //auditObj.setAudBatchId(propertiesObject.getObjName() + "_" + max_inc_ld_ts)
        auditObj.setAudBatchId(ld_jb_nr + "_" + max_inc_ld_ts)
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(incrementalCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudObjectName(propertiesObject.getObjName())
        auditObj.setAudErrorRecords(0)
        auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
        auditObj.setFlNm("")
        auditObj.setSysBtchNr(ld_jb_nr)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(propertiesObject.getObjName())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
}

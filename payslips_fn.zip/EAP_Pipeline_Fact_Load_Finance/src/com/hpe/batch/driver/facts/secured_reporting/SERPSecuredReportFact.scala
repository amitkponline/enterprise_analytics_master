package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object SERPSecuredReportFact extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true
  val logger = Logger.getLogger(getClass.getName)
  val objName = propertiesObject.getObjName().trim()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  logger.info("//*********************** Log Start for SERPEnrichmentSecuredReport.scala ************************//")
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  def budgetindirectexchtr(df: DataFrame, fromCurr: String, bgdtCol: String, schemaName: String): DataFrame = {
    val exhchangedf = spark.sql(s"select a.* from (select exch.*,row_number() over (partition by frm_curr_cd order by year(etry_vld_frm_ts) desc,month(etry_vld_frm_ts) desc) rn from ${dbNameConsmtn}.exch_rates_dmnsn exch where exch_rate_typ_cd = 'C' and to_curr_cd = 'USD') as a where a.rn=1")
    val joindf = df.alias("src").join(exhchangedf.alias("exch"), df(fromCurr) === exhchangedf("frm_curr_cd"), "leftouter").select("src.*", "exch.etry_vld_frm_ts", "exch.frm_curr_unts_rto_1_nr", "exch.to_curr_unts_rto_1_nr", "exch.indrt_qted_exch_rate_nr", "exch.frm_curr_cd", "exch.to_curr_cd")
    val df4 = joindf.select(col("*"), expr("CASE WHEN frm_curr_unts_rto_1_nr = to_curr_unts_rto_1_nr THEN  CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE) " + "WHEN frm_curr_unts_rto_1_nr > to_curr_unts_rto_1_nr THEN CAST(((to_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*frm_curr_unts_rto_1_nr) AS DOUBLE) " + "WHEN frm_curr_unts_rto_1_nr < to_curr_unts_rto_1_nr THEN CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE)" + " else null end").alias(bgdtCol))
    val df4_final = df4.drop("etry_vld_frm_ts", "frm_curr_unts_rto_1_nr", "to_curr_unts_rto_1_nr", "indrt_qted_exch_rate_nr", "frm_curr_cd", "to_curr_cd")
    df4_final
  }

  //***************************Audit Properties********************************//
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_secrd_serp_fact_load")
  auditObj.setAudObjectName(objName)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)

  spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 1 * 1024 * 1024 * 1024)

  try {

    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn))

    val dbCommonName = propertiesObject.getDbName().trim().split(",")(0)
    val dbCommonUATName = propertiesObject.getDbName().trim().split(",")(1)
    val dbCommonNameLR1 = propertiesObject.getDbName().trim().split(",")(2)
    val dbFinancNameLR1 = propertiesObject.getDbName().trim().split(",")(3)
    val dbFinancName = propertiesObject.getDbName().trim().split(",")(4)
    val dbCommonNameLR1UAT = propertiesObject.getDbName().trim().split(",")(5)
    val directElmtTyp = propertiesObject.getDirectElmtTyp()
    val inDirectElmtTyp = propertiesObject.getInDirectElmtTyp()
    val totalElmtTyp = propertiesObject.getTotalElmtTyp()
    val variableMaterial = propertiesObject.getVariableElmtTyp()

    if (tgtTblConsmtn.split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt
    
    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    val bmtrevrec = spark.sql(s"select col_nm,upper(col_vlu) as col_vlu,rev_rec_cgy_cd,dlt_flg from ${dbCommonNameLR1UAT}.bmt_order_rev_rec_dmnsn where lgc_ownr = 'EGI'")

    val bmtrevrecformatted = bmtrevrec.collect.map(c => " when " + c(0) + " = '" + c(1) + "' then '" + c(2) + "'")

    var revrecvalue = "case"

    for (i <- 0 to (bmtrevrecformatted.length - 1)) { revrecvalue += bmtrevrecformatted(i) }

    revrecvalue += "else null end"

    logger.info("+++++++######### rev rec condition: " + revrecvalue)

    val c4DF = spark.sql(s"""
               select
                 e1edka1_ctry_ky_cd,
                 e1edp01_idoc_drdl_id_nm,
                 year_month,
                 option,
                 SUM(Case when elmt_typ IN (${directElmtTyp}) then amt else null end) as direct_cost,
                 SUM(Case when elmt_typ IN(${inDirectElmtTyp}) then amt else null end) as indirect_cost, 
                 SUM(Case when elmt_typ IN(${totalElmtTyp}) then amt else null end) as var_trd_cost,
                 SUM(Case when elmt_typ IN (${variableMaterial}) then amt else null end) as variable_cost
               FROM
               (
                 select
                 trim(e1edka1_ctry_ky_cd) as e1edka1_ctry_ky_cd,trim(e1edp01_idoc_drdl_id_nm) as e1edp01_idoc_drdl_id_nm,case when trim(option) = '?' then NULL else concat('#',trim(option)) end as option ,trim(elmt_typ) as elmt_typ,substr(query_date,1,7) as year_month,amt,row_number() over (partition by e1edka1_ctry_ky_cd,e1edp01_idoc_drdl_id_nm,option,elmt_typ,substr(query_date,1,7) order by query_date desc) as rw_num
                 from 
                   ${dbCommonNameLR1UAT}.servicecost_drd_dmnsn c4
                 where
                   upper(c4.metric) = 'TCOS' 
                   and upper(c4.stts) = 'OK'
               ) servicecost_drd_dmnsn
               where
                 servicecost_drd_dmnsn.rw_num = 1
               group by
                 e1edka1_ctry_ky_cd,e1edp01_idoc_drdl_id_nm,option,year_month
               """)

    c4DF.createOrReplaceTempView("c4DFTemp")

    val serpDF = spark.sql(s"""
               select
                 df4.*,
                 cst.cch_level_2 as MRU,
                 spnd.ff_ln_itm_6,spnd.ff_ln_itm_7,
                 crc32(lower(trim(concat(coalesce(c4.e1edka1_ctry_ky_cd,""),coalesce(c4.e1edp01_idoc_drdl_id_nm,""),coalesce(c4.option,""),coalesce(c4.year_month,""))))) as c4_ky,
                 c4.direct_cost,
                 c4.indirect_cost, 
                 c4.var_trd_cost,
                 c4.variable_cost,
                 $revrecvalue as revrecvalue
               from ${dbFinancNameLR1}.secrd_rpt_fact_wo_pn_tmp df4 
               left join ${dbCommonName}.cst_cntr_MRU_hrchy cst on df4.cst_cntr_cd=cst.cch_level_8
               left join ${dbCommonNameLR1UAT}.bmt_pn_ff_spnd_lvl_dmnsn spnd on substring(df4.gl_acct_nr,3,8)= spnd.acct_cd
               left outer join c4DFTemp c4 on 
               lower(trim(df4.mtrl_nr))=trim(lower(concat(coalesce(trim(e1edp01_idoc_drdl_id_nm),''),coalesce(trim(option),'')))) 
               and df4.Soldto_prty_ctry_ky_cd = c4.e1edka1_ctry_ky_cd 
               and c4.year_month = substr(df4.ord_crt_dt,1,7)
               """)

    logger.info("+++++++++++################## C4 Data Added ##################+++++++++++")

    /*
     * Identify unique records based on inrn_id
     *
     */

    val pnPtflFrmwkDmnsn = spark.sql(s""" select  a.*,pkg_prod_id as bmt_pkg_prod_id from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.bs_prod_id, tbl.sgm_cd, tbl.pkg_prod_id order by tbl.inrn_id) seq_id
                           from ${dbCommonNameLR1UAT}.bmt_pn_ptfl_frmwk_dmnsn tbl) a where a.seq_id =1 """).repartition(col("pft_cntr_cd"), col("sgm_cd"), col("bmt_pkg_prod_id"), col("bs_prod_id"))

    val pnSlngMtnFrmwkDmnsnDf = spark.sql(s"""select a.* from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.sls_ord_typ_cd ,tbl.bsn_typ_cd, tbl.sgm_cd, tbl.bs_prod_id, tbl.mfrg_prod_fmly_id order by tbl.inrn_id) seq_id
                                from ${dbCommonNameLR1UAT}.bmt_pn_slng_mtn_frmwk_dmnsn tbl) a where a.seq_id =1 """)

    val pnHwFrmwkDmnsnDf = spark.sql(s"""select a.* from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.sgm_cd, tbl.gbl_carepack_hw_prod_ln_id, tbl.hw_prod_ln_cd ,tbl.srv_gds_prod_ln_id, tbl.mfrg_prod_prod_ln_id,tbl.bs_prod_typ_cd,tbl.bs_prod_id order by tbl.inrn_id) seq_id
                           from ${dbCommonNameLR1UAT}.bmt_pn_hw_frmwk_dmnsn tbl) a  where a.seq_id =1 """)

    val pnBsnCatFrmwkDmnsn = spark.sql(s"""select a.* from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.hw_lvl_4_cd ,tbl.bsn_typ_cd, tbl.bs_prod_id, tbl.sgm_cd, tbl.ln_itm_3_cd, tbl.mfrg_prod_fmly_id order by tbl.inrn_id) seq_id 
                             from ${dbCommonNameLR1UAT}.bmt_pn_bsn_cat_frmwk_dmnsn tbl) a where a.seq_id =1 """)

    val pnNnFcsDmnsnDf = spark.sql(s"""select a.* from (select tbl.* ,row_number() over (partition by tbl.ba_cd,tbl.prft_ctr_cd,tbl.sgmt_lvl_2_cd,tbl.sgmt_lvl_3_cd,tbl.sgmt_lvl_4_cd,tbl.sgmt_lvl_5_cd order by tbl.inrn_id) seq_id 
                         from ${dbCommonNameLR1UAT}.bmt_pn_nn_fcus_flg_ord_dmnsn tbl) a where a.seq_id=1""")

    val pnNnFcsDmnsnDf1 = spark.sql(s"""select a.* from (select tbl.*, row_number() over (partition by tbl.ba_cd,tbl.prft_ctr_cd,tbl.sgmt_lvl_2_cd,tbl.sgmt_lvl_3_cd,tbl.sgmt_lvl_4_cd,tbl.sgmt_lvl_5_cd,tbl.ff_l15_cd order by tbl.inrn_id) seq_id 
                          from ${dbCommonNameLR1UAT}.bmt_pn_nn_fcus_flg_actl_dmnsn tbl) a where a.seq_id=1""")

    val pnFnclFrmwkDf = spark.sql(s"""select a.* from (select tbl.*,row_number() over (partition by tbl.pft_cntr,tbl.acct_cd,tbl.mru_cd,tbl.cst_obj,tbl.fnctl_ar order by tbl.precedence) seq_id
                        from ${dbCommonNameLR1UAT}.bmt_pn_fncl_frmwk_dmnsn tbl)a where a.seq_id=1""")

    val serpSelectDf = serpDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "pkg_prod_id", "itm_vl_usr_stts_cd").distinct.repartition(col("prft_cntr_cd"), col("sgmtl_rptg_cd"), col("pkg_prod_id"), col("itm_vl_usr_stts_cd"))

    /*
     * Joining SERP base table with Point Next BMT Step 1
     *
     * 1.a Match the identified joining column between two dataset
     * 1.b if value all is passed then data set should be joined on all the available records
     */

    val serpJoinedPnptflFrmwkDF = serpSelectDf.alias("serpCol").join(
      (pnPtflFrmwkDmnsn).alias("pnPtflFrmwkCol"),
      (serpSelectDf("prft_cntr_cd") === pnPtflFrmwkDmnsn("pft_cntr_cd") || pnPtflFrmwkDmnsn("pft_cntr_cd") === "all")
        && (serpSelectDf("sgmtl_rptg_cd") === pnPtflFrmwkDmnsn("sgm_cd") || pnPtflFrmwkDmnsn("sgm_cd") === "all")
        && (serpSelectDf("pkg_prod_id") === pnPtflFrmwkDmnsn("bmt_pkg_prod_id") || pnPtflFrmwkDmnsn("bmt_pkg_prod_id") === "all")
        && (serpSelectDf("itm_vl_usr_stts_cd") === pnPtflFrmwkDmnsn("bs_prod_id") || pnPtflFrmwkDmnsn("bs_prod_id") === "all"), "leftouter").filter(pnPtflFrmwkDmnsn("inrn_id").isNotNull).select("serpCol.*", "pnPtflFrmwkCol.ln_itm_1_cd", "pnPtflFrmwkCol.ln_itm_2_cd", "pnPtflFrmwkCol.ln_itm_3_cd", "pnPtflFrmwkCol.ln_itm_4_ofr_cd", "pnPtflFrmwkCol.ln_itm_5_sla_cvrg_cd", "pnPtflFrmwkCol.ln_itm_6_typ_cd", "pnPtflFrmwkCol.ln_itm_7_durtn_cd", "pnPtflFrmwkCol.inrn_id", "pnPtflFrmwkCol.pft_cntr_cd", "pnPtflFrmwkCol.sgm_cd", "pnPtflFrmwkCol.bmt_pkg_prod_id", "pnPtflFrmwkCol.bs_prod_id")

    logger.info("********************************************* serpJoinedDf write to table")

    val serpJoinedPnptflFrmwkStgDF = serpJoinedPnptflFrmwkDF
    val serpJoinedPnptflFrmwkDeDupDF = Utilities.getLatestRecs(serpJoinedPnptflFrmwkStgDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "pkg_prod_id", "itm_vl_usr_stts_cd"), List("inrn_id"))

    serpJoinedPnptflFrmwkDF.repartition(col("sls_ord_id"), col("sls_ord_ln_itm_id"))

    /*
     * Joining SERP base table with Point Next BMT Step 2
     *
     * 2.a join back the data set prepared in
     * 2.b if value all is passed then data set should be joined on all the available records
     */

    val serpJoinedPnptflFrmwkFinalDF = serpDF.alias("serpCol").join(
      (serpJoinedPnptflFrmwkDeDupDF).alias("JoinedDfCol"),
      serpDF("sls_ord_id") === serpJoinedPnptflFrmwkDeDupDF("sls_ord_id") && serpDF("sls_ord_ln_itm_id") === serpJoinedPnptflFrmwkDeDupDF("sls_ord_ln_itm_id") &&
        ((serpDF("prft_cntr_cd").isNull && serpJoinedPnptflFrmwkDeDupDF("prft_cntr_cd").isNull) || serpDF("prft_cntr_cd") === serpJoinedPnptflFrmwkDeDupDF("prft_cntr_cd"))
        && ((serpDF("sgmtl_rptg_cd").isNull && serpJoinedPnptflFrmwkDeDupDF("sgmtl_rptg_cd").isNull) || serpDF("sgmtl_rptg_cd") === serpJoinedPnptflFrmwkDeDupDF("sgmtl_rptg_cd"))
        && ((serpDF("pkg_prod_id").isNull && serpJoinedPnptflFrmwkDeDupDF("pkg_prod_id").isNull) || serpDF("pkg_prod_id") === serpJoinedPnptflFrmwkDeDupDF("pkg_prod_id"))
        && ((serpDF("itm_vl_usr_stts_cd").isNull && serpJoinedPnptflFrmwkDeDupDF("itm_vl_usr_stts_cd").isNull) || serpDF("itm_vl_usr_stts_cd") === serpJoinedPnptflFrmwkDeDupDF("itm_vl_usr_stts_cd")), "leftouter").select("serpCol.*", "JoinedDfCol.ln_itm_1_cd", "JoinedDfCol.ln_itm_2_cd", "JoinedDfCol.ln_itm_3_cd", "JoinedDfCol.ln_itm_4_ofr_cd", "JoinedDfCol.ln_itm_5_sla_cvrg_cd", "JoinedDfCol.ln_itm_6_typ_cd", "JoinedDfCol.ln_itm_7_durtn_cd", "JoinedDfCol.inrn_id", "JoinedDfCol.pft_cntr_cd", "JoinedDfCol.sgm_cd", "JoinedDfCol.bmt_pkg_prod_id", "JoinedDfCol.bs_prod_id")

    logger.info("********************************************* finalDf write to table")

    val serpSelectDfpnHwFrmwk = serpJoinedPnptflFrmwkFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "gbl_carepack_hw_prod_ln_id", "pm_mtrl_mstr_sls_dvsn_cd", "pmd_mtrl_mstr_sls_dvsn_cd", "prod_hrchy_prod_typ_cd", "itm_vl_usr_stts_cd").distinct

    val serpJoinedPnptflFrmwkOldDF = serpSelectDfpnHwFrmwk.alias("serpDF").join(
      broadcast(pnHwFrmwkDmnsnDf).alias("pnHwFrmwkCol"),
      (serpSelectDfpnHwFrmwk("prft_cntr_cd") === pnHwFrmwkDmnsnDf("pft_cntr_cd") || pnHwFrmwkDmnsnDf("pft_cntr_cd") === "all") && (serpSelectDfpnHwFrmwk("sgmtl_rptg_cd") === pnHwFrmwkDmnsnDf("sgm_cd") || pnHwFrmwkDmnsnDf("sgm_cd") === "all") && ((pnHwFrmwkDmnsnDf("gbl_carepack_hw_prod_ln_id") === "all" && ((serpSelectDfpnHwFrmwk("gbl_carepack_hw_prod_ln_id") === pnHwFrmwkDmnsnDf("hw_prod_ln_cd")) || pnHwFrmwkDmnsnDf("hw_prod_ln_cd") === "all")) || (pnHwFrmwkDmnsnDf("srv_gds_prod_ln_id") === "all" && ((serpSelectDfpnHwFrmwk("pm_mtrl_mstr_sls_dvsn_cd") === pnHwFrmwkDmnsnDf("hw_prod_ln_cd")) || pnHwFrmwkDmnsnDf("hw_prod_ln_cd") === "all")) || (pnHwFrmwkDmnsnDf("mfrg_prod_prod_ln_id") === "all" && ((serpSelectDfpnHwFrmwk("pmd_mtrl_mstr_sls_dvsn_cd") === pnHwFrmwkDmnsnDf("hw_prod_ln_cd")) || pnHwFrmwkDmnsnDf("hw_prod_ln_cd") === "all")))
        && (serpSelectDfpnHwFrmwk("prod_hrchy_prod_typ_cd") === pnHwFrmwkDmnsnDf("bs_prod_typ_cd") || pnHwFrmwkDmnsnDf("bs_prod_typ_cd") === "all") && (serpSelectDfpnHwFrmwk("itm_vl_usr_stts_cd") === pnHwFrmwkDmnsnDf("bs_prod_id") || pnHwFrmwkDmnsnDf("bs_prod_id") === "all"), "leftouter").filter(pnHwFrmwkDmnsnDf("inrn_id").isNotNull).select("serpDF.*", "pnHwFrmwkCol.hw_lvl_1_cd", "pnHwFrmwkCol.hw_lvl_2_cd", "pnHwFrmwkCol.hw_lvl_3_cd", "pnHwFrmwkCol.hw_lvl_4_cd", "pnHwFrmwkCol.hw_lvl_5_cd", "pnHwFrmwkCol.hw_lvl_6_cd", "pnHwFrmwkCol.inrn_id", "pnHwFrmwkCol.hw_prod_ln_cd")

    logger.info("********************************************* serpJoinedPnptflFrmwkOldDF write to table")

    val joinCondition = when(serpJoinedPnptflFrmwkOldDF("gbl_carepack_hw_prod_ln_id").isNotNull && serpJoinedPnptflFrmwkOldDF("gbl_carepack_hw_prod_ln_id") === serpJoinedPnptflFrmwkOldDF("hw_prod_ln_cd"), "1").when(serpJoinedPnptflFrmwkOldDF("pm_mtrl_mstr_sls_dvsn_cd").isNotNull && serpJoinedPnptflFrmwkOldDF("pm_mtrl_mstr_sls_dvsn_cd") === serpJoinedPnptflFrmwkOldDF("hw_prod_ln_cd"), "2").when(serpJoinedPnptflFrmwkOldDF("pmd_mtrl_mstr_sls_dvsn_cd").isNotNull && serpJoinedPnptflFrmwkOldDF("pmd_mtrl_mstr_sls_dvsn_cd") === serpJoinedPnptflFrmwkOldDF("hw_prod_ln_cd"), "3").otherwise("4")

    val serpJoinedValidHwPlDf = serpJoinedPnptflFrmwkOldDF.withColumn("valid_hw_pl", joinCondition)

    val serpJoinedValidHwPlDeDupDf = Utilities.getLatestRecs(serpJoinedValidHwPlDf, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "gbl_carepack_hw_prod_ln_id", "pm_mtrl_mstr_sls_dvsn_cd", "pmd_mtrl_mstr_sls_dvsn_cd",
      "prod_hrchy_prod_typ_cd", "itm_vl_usr_stts_cd"), List("inrn_id", "valid_hw_pl"))

    val serpJoinedPnHwFinalDF = serpJoinedPnptflFrmwkFinalDF.alias("serpDF").join(
      (serpJoinedValidHwPlDeDupDf).alias("pnHwFrmwkCol"),
      serpJoinedPnptflFrmwkFinalDF("sls_ord_id") === serpJoinedValidHwPlDeDupDf("sls_ord_id") && serpJoinedPnptflFrmwkFinalDF("sls_ord_ln_itm_id") === serpJoinedValidHwPlDeDupDf("sls_ord_ln_itm_id") &&
        ((serpJoinedPnptflFrmwkFinalDF("prft_cntr_cd").isNull && serpJoinedValidHwPlDeDupDf("prft_cntr_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("prft_cntr_cd") === serpJoinedValidHwPlDeDupDf("prft_cntr_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("sgmtl_rptg_cd").isNull && serpJoinedValidHwPlDeDupDf("sgmtl_rptg_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("sgmtl_rptg_cd") === serpJoinedValidHwPlDeDupDf("sgmtl_rptg_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("gbl_carepack_hw_prod_ln_id").isNull && serpJoinedValidHwPlDeDupDf("gbl_carepack_hw_prod_ln_id").isNull) || serpJoinedPnptflFrmwkFinalDF("gbl_carepack_hw_prod_ln_id") === serpJoinedValidHwPlDeDupDf("gbl_carepack_hw_prod_ln_id"))
        && ((serpJoinedPnptflFrmwkFinalDF("pm_mtrl_mstr_sls_dvsn_cd").isNull && serpJoinedValidHwPlDeDupDf("pm_mtrl_mstr_sls_dvsn_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("pm_mtrl_mstr_sls_dvsn_cd") === serpJoinedValidHwPlDeDupDf("pm_mtrl_mstr_sls_dvsn_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("pmd_mtrl_mstr_sls_dvsn_cd").isNull && serpJoinedValidHwPlDeDupDf("pmd_mtrl_mstr_sls_dvsn_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("pmd_mtrl_mstr_sls_dvsn_cd") === serpJoinedValidHwPlDeDupDf("pmd_mtrl_mstr_sls_dvsn_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("prod_hrchy_prod_typ_cd").isNull && serpJoinedValidHwPlDeDupDf("prod_hrchy_prod_typ_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("prod_hrchy_prod_typ_cd") === serpJoinedValidHwPlDeDupDf("prod_hrchy_prod_typ_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("itm_vl_usr_stts_cd").isNull && serpJoinedValidHwPlDeDupDf("itm_vl_usr_stts_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("itm_vl_usr_stts_cd") === serpJoinedValidHwPlDeDupDf("itm_vl_usr_stts_cd")), "leftouter").select("serpDF.*", "pnHwFrmwkCol.hw_lvl_1_cd", "pnHwFrmwkCol.hw_lvl_2_cd", "pnHwFrmwkCol.hw_lvl_3_cd", "pnHwFrmwkCol.hw_lvl_4_cd", "pnHwFrmwkCol.hw_lvl_5_cd", "pnHwFrmwkCol.hw_lvl_6_cd").distinct

    logger.info("********************************************* serpJoinedPnptflFrmwkOldDF write to table")

    val serpSelectDfpnSlngMtnFrmwk = serpJoinedPnHwFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "ord_typ_cd", "sls_mtrc_cd", "prft_cntr_cd", "sgmtl_rptg_cd", "itm_vl_usr_stts_cd", "prod_hrchy_prod_fmly_cd").distinct

    val serpJoinedSlngMtnFrmwkDF = serpSelectDfpnSlngMtnFrmwk.alias("serpDF").join(
      broadcast(pnSlngMtnFrmwkDmnsnDf).alias("pnSlngMtnFrmwkCol"),
      (serpSelectDfpnSlngMtnFrmwk("ord_typ_cd") === pnSlngMtnFrmwkDmnsnDf("sls_ord_typ_cd") || pnSlngMtnFrmwkDmnsnDf("sls_ord_typ_cd") === "all")
        && (serpSelectDfpnSlngMtnFrmwk("sls_mtrc_cd") === pnSlngMtnFrmwkDmnsnDf("bsn_typ_cd") || pnSlngMtnFrmwkDmnsnDf("bsn_typ_cd") === "all")
        && (serpSelectDfpnSlngMtnFrmwk("prft_cntr_cd") === pnSlngMtnFrmwkDmnsnDf("pft_cntr_cd") || pnSlngMtnFrmwkDmnsnDf("pft_cntr_cd") === "all")
        && (serpSelectDfpnSlngMtnFrmwk("sgmtl_rptg_cd") === pnSlngMtnFrmwkDmnsnDf("sgm_cd") || pnSlngMtnFrmwkDmnsnDf("sgm_cd") === "all")
        && ((serpSelectDfpnSlngMtnFrmwk("itm_vl_usr_stts_cd") === pnSlngMtnFrmwkDmnsnDf("bs_prod_id") || (substring(trim(serpSelectDfpnSlngMtnFrmwk("itm_vl_usr_stts_cd")), -2, 2) === substring(trim(pnSlngMtnFrmwkDmnsnDf("bs_prod_id")), -2, 2)
          && (pnSlngMtnFrmwkDmnsnDf("bs_prod_id").like("*%")))) || pnSlngMtnFrmwkDmnsnDf("bs_prod_id") === "all")
          && (serpSelectDfpnSlngMtnFrmwk("prod_hrchy_prod_fmly_cd") === pnSlngMtnFrmwkDmnsnDf("mfrg_prod_fmly_id") || pnSlngMtnFrmwkDmnsnDf("mfrg_prod_fmly_id") === "all"), "leftouter").filter(pnSlngMtnFrmwkDmnsnDf("inrn_id").isNotNull).select("serpDF.*", "pnSlngMtnFrmwkCol.slng_mtn_lvl_1_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_2_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_3_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_4_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_5_cd", "pnSlngMtnFrmwkCol.inrn_id")

    val serpJoinedSlngMtnFrmwkDeDupDF = Utilities.getLatestRecs(serpJoinedSlngMtnFrmwkDF, List("sls_ord_id", "sls_ord_ln_itm_id", "ord_typ_cd", "sls_mtrc_cd", "prft_cntr_cd", "sgmtl_rptg_cd", "itm_vl_usr_stts_cd",
      "prod_hrchy_prod_fmly_cd"), List("inrn_id"))

    val serpJoinedSlngMtnFrmwkFinalDF = serpJoinedPnHwFinalDF.alias("serpCol").join(
      (serpJoinedSlngMtnFrmwkDeDupDF).alias("pnSlngMtnFrmwkCol"),
      (serpJoinedPnHwFinalDF("sls_ord_id") === serpJoinedSlngMtnFrmwkDeDupDF("sls_ord_id") && serpJoinedPnHwFinalDF("sls_ord_ln_itm_id") === serpJoinedSlngMtnFrmwkDeDupDF("sls_ord_ln_itm_id")) &&
        ((serpJoinedPnHwFinalDF("ord_typ_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("ord_typ_cd").isNull) || serpJoinedPnHwFinalDF("ord_typ_cd") === serpJoinedSlngMtnFrmwkDeDupDF("ord_typ_cd"))
        && ((serpJoinedPnHwFinalDF("sls_mtrc_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("sls_mtrc_cd").isNull) || serpJoinedPnHwFinalDF("sls_mtrc_cd") === serpJoinedSlngMtnFrmwkDeDupDF("sls_mtrc_cd"))
        && ((serpJoinedPnHwFinalDF("prft_cntr_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("prft_cntr_cd").isNull) || serpJoinedPnHwFinalDF("prft_cntr_cd") === serpJoinedSlngMtnFrmwkDeDupDF("prft_cntr_cd"))
        && ((serpJoinedPnHwFinalDF("sgmtl_rptg_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("sgmtl_rptg_cd").isNull) || serpJoinedPnHwFinalDF("sgmtl_rptg_cd") === serpJoinedSlngMtnFrmwkDeDupDF("sgmtl_rptg_cd"))
        && ((serpJoinedPnHwFinalDF("itm_vl_usr_stts_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("itm_vl_usr_stts_cd").isNull) || serpJoinedPnHwFinalDF("itm_vl_usr_stts_cd") === serpJoinedSlngMtnFrmwkDeDupDF("itm_vl_usr_stts_cd"))
        && ((serpJoinedPnHwFinalDF("prod_hrchy_prod_fmly_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("prod_hrchy_prod_fmly_cd").isNull) || serpJoinedPnHwFinalDF("prod_hrchy_prod_fmly_cd") === serpJoinedSlngMtnFrmwkDeDupDF("prod_hrchy_prod_fmly_cd")), "leftouter").select("serpCol.*", "pnSlngMtnFrmwkCol.slng_mtn_lvl_1_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_2_cd",
        "pnSlngMtnFrmwkCol.slng_mtn_lvl_3_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_4_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_5_cd").distinct

    logger.info("********************************************* serpJoinedSlngMtnFrmwkFinalDF write to table")

    val serpSelectDfpnBsnCatFrmwk = serpJoinedSlngMtnFrmwkFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "hw_lvl_4_cd", "sls_mtrc_cd", "itm_vl_usr_stts_cd", "prod_hrchy_prod_fmly_cd", "ln_itm_3_cd").distinct

    val serpJoinedPnBsnCatFrmwkDF = serpSelectDfpnBsnCatFrmwk.alias("serpDF").join(
      broadcast(pnBsnCatFrmwkDmnsn).alias("pnBsnCatFrmwkCol"),
      (serpSelectDfpnBsnCatFrmwk("prft_cntr_cd") === pnBsnCatFrmwkDmnsn("pft_cntr_cd") || pnBsnCatFrmwkDmnsn("pft_cntr_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("sgmtl_rptg_cd") === pnBsnCatFrmwkDmnsn("sgm_cd") || pnBsnCatFrmwkDmnsn("sgm_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("hw_lvl_4_cd") === pnBsnCatFrmwkDmnsn("hw_lvl_4_cd") || pnBsnCatFrmwkDmnsn("hw_lvl_4_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("sls_mtrc_cd") === pnBsnCatFrmwkDmnsn("bsn_typ_cd") || pnBsnCatFrmwkDmnsn("bsn_typ_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("itm_vl_usr_stts_cd") === pnBsnCatFrmwkDmnsn("bs_prod_id")
          || ((pnBsnCatFrmwkDmnsn("bs_prod_id").like("*%")) && (serpSelectDfpnBsnCatFrmwk("itm_vl_usr_stts_cd").rlike((concat(lit("."), trim(pnBsnCatFrmwkDmnsn("bs_prod_id"))).toString())))) || pnBsnCatFrmwkDmnsn("bs_prod_id") === "all")
          && (serpSelectDfpnBsnCatFrmwk("prod_hrchy_prod_fmly_cd") === pnBsnCatFrmwkDmnsn("mfrg_prod_fmly_id") || pnBsnCatFrmwkDmnsn("mfrg_prod_fmly_id") === "all")
          && (serpSelectDfpnBsnCatFrmwk("ln_itm_3_cd") === pnBsnCatFrmwkDmnsn("ln_itm_3_cd") || pnBsnCatFrmwkDmnsn("ln_itm_3_cd") === "all"), "leftouter").filter(pnBsnCatFrmwkDmnsn("inrn_id").isNotNull).select("serpDF.*", "pnBsnCatFrmwkCol.bsn_cgy_lvl_1_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_2_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_3_cd", "pnBsnCatFrmwkCol.inrn_id")

    val serpJoinedPnBsnCatFrmwkDeDupDF = Utilities.getLatestRecs(serpJoinedPnBsnCatFrmwkDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "hw_lvl_4_cd", "sls_mtrc_cd", "itm_vl_usr_stts_cd", "prod_hrchy_prod_fmly_cd", "ln_itm_3_cd"), List("inrn_id"))

    val serpJoinedPnBsnCatFrmwkFinalDF = serpJoinedSlngMtnFrmwkFinalDF.alias("serpJoindCol").join(
      (serpJoinedPnBsnCatFrmwkDeDupDF).alias("pnBsnCatFrmwkCol"),
      serpJoinedSlngMtnFrmwkFinalDF("sls_ord_id") === serpJoinedPnBsnCatFrmwkDeDupDF("sls_ord_id") && serpJoinedSlngMtnFrmwkFinalDF("sls_ord_ln_itm_id") === serpJoinedPnBsnCatFrmwkDeDupDF("sls_ord_ln_itm_id") &&
        ((serpJoinedSlngMtnFrmwkFinalDF("prft_cntr_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("prft_cntr_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("prft_cntr_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("prft_cntr_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("sgmtl_rptg_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("sgmtl_rptg_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("sgmtl_rptg_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("sgmtl_rptg_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("hw_lvl_4_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("hw_lvl_4_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("hw_lvl_4_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("hw_lvl_4_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("sls_mtrc_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("sls_mtrc_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("sls_mtrc_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("sls_mtrc_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("itm_vl_usr_stts_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("itm_vl_usr_stts_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("itm_vl_usr_stts_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("itm_vl_usr_stts_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("prod_hrchy_prod_fmly_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("prod_hrchy_prod_fmly_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("prod_hrchy_prod_fmly_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("prod_hrchy_prod_fmly_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("ln_itm_3_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("ln_itm_3_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("ln_itm_3_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("ln_itm_3_cd")), "leftouter").select("serpJoindCol.*", "pnBsnCatFrmwkCol.bsn_cgy_lvl_1_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_2_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_3_cd")

    logger.info("********************************************* serpJoinedPnBsnCatFrmwkFinalDF write to table")

    val serpSelectDfpnNnFcsDmnsn = serpJoinedPnBsnCatFrmwkFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5").distinct

    val serpJoinedPnNnFcsDF = serpSelectDfpnNnFcsDmnsn.alias("serpJoindCol1").join(
      broadcast(pnNnFcsDmnsnDf).alias("pnNnFcsDmnsnCol"),
      (serpSelectDfpnNnFcsDmnsn("prft_cntr_cd") === pnNnFcsDmnsnDf("prft_ctr_cd") || pnNnFcsDmnsnDf("prft_ctr_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_2") === pnNnFcsDmnsnDf("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf("sgmt_lvl_2_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_3") === pnNnFcsDmnsnDf("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf("sgmt_lvl_3_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_4") === pnNnFcsDmnsnDf("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf("sgmt_lvl_4_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_5") === pnNnFcsDmnsnDf("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf("sgmt_lvl_5_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_2") != pnNnFcsDmnsnDf("sgmt_lvl_2_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_3") != pnNnFcsDmnsnDf("sgmt_lvl_3_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_4") != pnNnFcsDmnsnDf("sgmt_lvl_4_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_5") != pnNnFcsDmnsnDf("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf("inrn_id").isNotNull).select("serpJoindCol1.*", "pnNnFcsDmnsnCol.nn_fcs_cntry", "pnNnFcsDmnsnCol.inrn_id")

    val serpJoinedPnNnFcsDeDupDF = Utilities.getLatestRecs(serpJoinedPnNnFcsDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5"), List("inrn_id"))

    var serpJoinedPnNnFcsFinalDF = serpJoinedPnBsnCatFrmwkFinalDF.alias("serpJoindCol").join(
      (serpJoinedPnNnFcsDeDupDF).alias("pnNnFcsDmnsnCol"),
      serpJoinedPnBsnCatFrmwkFinalDF("sls_ord_id") === serpJoinedPnNnFcsDeDupDF("sls_ord_id") && serpJoinedPnBsnCatFrmwkFinalDF("sls_ord_ln_itm_id") === serpJoinedPnNnFcsDeDupDF("sls_ord_ln_itm_id") &&
        ((serpJoinedPnBsnCatFrmwkFinalDF("prft_cntr_cd").isNull && serpJoinedPnNnFcsDeDupDF("prft_cntr_cd").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("prft_cntr_cd") === serpJoinedPnNnFcsDeDupDF("prft_cntr_cd"))
        && ((serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_2").isNull && serpJoinedPnNnFcsDeDupDF("sgm_lvl_2").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_2") === serpJoinedPnNnFcsDeDupDF("sgm_lvl_2"))
        && ((serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_3").isNull && serpJoinedPnNnFcsDeDupDF("sgm_lvl_3").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_3") === serpJoinedPnNnFcsDeDupDF("sgm_lvl_3"))
        && ((serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_4").isNull && serpJoinedPnNnFcsDeDupDF("sgm_lvl_4").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_4") === serpJoinedPnNnFcsDeDupDF("sgm_lvl_4"))
        && ((serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_5").isNull && serpJoinedPnNnFcsDeDupDF("sgm_lvl_5").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_5") === serpJoinedPnNnFcsDeDupDF("sgm_lvl_5")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry")

    logger.info("********************************************* serpJoinedPnNnFcsFinalDF write to table")

    serpJoinedPnNnFcsFinalDF = serpJoinedPnNnFcsFinalDF.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_ord")

    val serpSelectDfpnFnclFrmwk = serpJoinedPnNnFcsFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "gl_acct_nr", "MRU", "cst_cntr_cd", "fnctl_ar_cd").distinct

    var serpJoinedPnFnclDF = serpSelectDfpnFnclFrmwk.alias("serpJoindCol2").join(
      broadcast(pnFnclFrmwkDf).alias("pnFnclFrmwkCol"),
      (serpSelectDfpnFnclFrmwk("prft_cntr_cd") === pnFnclFrmwkDf("pft_cntr") || pnFnclFrmwkDf("pft_cntr") === "all")
        && (substring(serpSelectDfpnFnclFrmwk("gl_acct_nr"), 3, 8) === pnFnclFrmwkDf("acct_cd") || pnFnclFrmwkDf("acct_cd") === "all")
        && (serpSelectDfpnFnclFrmwk("MRU") === pnFnclFrmwkDf("mru_cd") || pnFnclFrmwkDf("mru_cd") === "all")
        && (serpSelectDfpnFnclFrmwk("cst_cntr_cd") === pnFnclFrmwkDf("cst_obj") || pnFnclFrmwkDf("cst_obj") === "all")
        && (serpSelectDfpnFnclFrmwk("fnctl_ar_cd") === pnFnclFrmwkDf("fnctl_ar") || pnFnclFrmwkDf("fnctl_ar") === "all"), "leftouter").filter(pnFnclFrmwkDf("precedence").isNotNull).select("serpJoindCol2.*", "pnFnclFrmwkCol.ff_ln_itm_0", "pnFnclFrmwkCol.ff_ln_itm_1", "pnFnclFrmwkCol.ff_ln_itm_2",
        "pnFnclFrmwkCol.ff_ln_itm_3", "pnFnclFrmwkCol.ff_ln_itm_4", "pnFnclFrmwkCol.ff_ln_itm_5", "pnFnclFrmwkCol.precedence")

    var serpJoinedPnFnclDeDupDF = Utilities.getLatestRecs(serpJoinedPnFnclDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "gl_acct_nr", "MRU", "cst_cntr_cd", "fnctl_ar_cd"), List("precedence"))

    serpJoinedPnFnclDeDupDF = serpJoinedPnFnclDeDupDF.select(serpJoinedPnFnclDeDupDF.columns.toList.map(c => col(c).alias(c + "_tmp")).toList: _*)

    var serpJoinedPnFnclFinalDF = serpJoinedPnNnFcsFinalDF.alias("serpJoindCol").join(
      (serpJoinedPnFnclDeDupDF).alias("pnFnclFrmwkCol"),
      serpJoinedPnNnFcsFinalDF("sls_ord_id") === serpJoinedPnFnclDeDupDF("sls_ord_id_tmp") && serpJoinedPnNnFcsFinalDF("sls_ord_ln_itm_id") === serpJoinedPnFnclDeDupDF("sls_ord_ln_itm_id_tmp") &&
        ((serpJoinedPnNnFcsFinalDF("prft_cntr_cd").isNull && serpJoinedPnFnclDeDupDF("prft_cntr_cd_tmp").isNull) || serpJoinedPnNnFcsFinalDF("prft_cntr_cd") === serpJoinedPnFnclDeDupDF("prft_cntr_cd_tmp"))
        && ((serpJoinedPnNnFcsFinalDF("gl_acct_nr").isNull && serpJoinedPnFnclDeDupDF("gl_acct_nr_tmp").isNull) || serpJoinedPnNnFcsFinalDF("gl_acct_nr") === serpJoinedPnFnclDeDupDF("gl_acct_nr_tmp"))
        && ((serpJoinedPnNnFcsFinalDF("MRU").isNull && serpJoinedPnFnclDeDupDF("MRU_tmp").isNull) || serpJoinedPnNnFcsFinalDF("MRU") === serpJoinedPnFnclDeDupDF("MRU_tmp"))
        && ((serpJoinedPnNnFcsFinalDF("cst_cntr_cd").isNull && serpJoinedPnFnclDeDupDF("cst_cntr_cd_tmp").isNull) || serpJoinedPnNnFcsFinalDF("cst_cntr_cd") === serpJoinedPnFnclDeDupDF("cst_cntr_cd_tmp"))
        && ((serpJoinedPnNnFcsFinalDF("fnctl_ar_cd").isNull && serpJoinedPnFnclDeDupDF("fnctl_ar_cd_tmp").isNull) || serpJoinedPnNnFcsFinalDF("fnctl_ar_cd") === serpJoinedPnFnclDeDupDF("fnctl_ar_cd_tmp")), "leftouter").select("serpJoindCol.*", "pnFnclFrmwkCol.ff_ln_itm_0_tmp", "pnFnclFrmwkCol.ff_ln_itm_1_tmp", "pnFnclFrmwkCol.ff_ln_itm_2_tmp", "pnFnclFrmwkCol.ff_ln_itm_3_tmp", "pnFnclFrmwkCol.ff_ln_itm_4_tmp", "pnFnclFrmwkCol.ff_ln_itm_5_tmp", "pnFnclFrmwkCol.precedence_tmp")

    val serpSelectDfpnNnFcsDmnsn1 = serpJoinedPnFnclFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "ff_ln_itm_5_tmp").distinct

    logger.info("********************************************* serpJoinedPnFnclFinalDF write to table")

    var serpJoinedNewPnNnFcsDF = serpSelectDfpnNnFcsDmnsn1.alias("serpJoindCol1").join(
      broadcast(pnNnFcsDmnsnDf1).alias("pnNnFcsDmnsnCol1"),
      (serpSelectDfpnNnFcsDmnsn1("prft_cntr_cd") === pnNnFcsDmnsnDf1("prft_ctr_cd") || pnNnFcsDmnsnDf1("prft_ctr_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_2") === pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_3") === pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_4") === pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_5") === pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("ff_ln_itm_5_tmp") === pnNnFcsDmnsnDf1("ff_l15_cd") || pnNnFcsDmnsnDf1("ff_l15_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_2") != pnNnFcsDmnsnDf1("sgmt_lvl_2_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_3") != pnNnFcsDmnsnDf1("sgmt_lvl_3_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_4") != pnNnFcsDmnsnDf1("sgmt_lvl_4_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_5") != pnNnFcsDmnsnDf1("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf1("inrn_id").isNotNull).select("serpJoindCol1.*", "pnNnFcsDmnsnCol1.nn_fcs_cntry", "pnNnFcsDmnsnCol1.inrn_id")

    serpJoinedNewPnNnFcsDF = serpJoinedNewPnNnFcsDF.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_actl")

    val serpJoinedNewPnNnFcsDeDupDF = Utilities.getLatestRecs(serpJoinedNewPnNnFcsDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "ff_ln_itm_5_tmp"), List("inrn_id"))

    var serpJoinedNewPnNnFcsFinalDF = serpJoinedPnFnclFinalDF.alias("serpJoindCol").join(
      (serpJoinedNewPnNnFcsDeDupDF).alias("pnNnFcsDmnsnCol"),
      serpJoinedPnFnclFinalDF("sls_ord_id") === serpJoinedNewPnNnFcsDeDupDF("sls_ord_id") && serpJoinedPnFnclFinalDF("sls_ord_ln_itm_id") === serpJoinedNewPnNnFcsDeDupDF("sls_ord_ln_itm_id") &&
        ((serpJoinedPnFnclFinalDF("prft_cntr_cd").isNull && serpJoinedNewPnNnFcsDeDupDF("prft_cntr_cd").isNull) || serpJoinedPnFnclFinalDF("prft_cntr_cd") === serpJoinedNewPnNnFcsDeDupDF("prft_cntr_cd"))
        && ((serpJoinedPnFnclFinalDF("sgm_lvl_2").isNull && serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_2").isNull) || serpJoinedPnFnclFinalDF("sgm_lvl_2") === serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_2"))
        && ((serpJoinedPnFnclFinalDF("sgm_lvl_3").isNull && serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_3").isNull) || serpJoinedPnFnclFinalDF("sgm_lvl_3") === serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_3"))
        && ((serpJoinedPnFnclFinalDF("sgm_lvl_4").isNull && serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_4").isNull) || serpJoinedPnFnclFinalDF("sgm_lvl_4") === serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_4"))
        && ((serpJoinedPnFnclFinalDF("sgm_lvl_5").isNull && serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_5").isNull) || serpJoinedPnFnclFinalDF("sgm_lvl_5") === serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_5"))
        && ((serpJoinedPnFnclFinalDF("ff_ln_itm_5_tmp").isNull && serpJoinedNewPnNnFcsDeDupDF("ff_ln_itm_5_tmp").isNull) || serpJoinedPnFnclFinalDF("ff_ln_itm_5_tmp") === serpJoinedNewPnNnFcsDeDupDF("ff_ln_itm_5_tmp")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry_actl")

    logger.info("********************************************* SERP BMT join completed ")

    val pnGreenLakeFlgDF = spark.sql(s"select greenlake_flg_cd,cust_po_id as cust_po_id_1,bsn_cgy_lvl_1_cd as bsn_cgy_lvl_1_cd_1,pft_cntr_cd from ${dbCommonNameLR1UAT}.bmt_pn_greenlake_flg_dmnsn")

    val bmtRevRecCgySnpDF = spark.sql(s"select * from ${dbCommonNameLR1UAT}.bmt_rev_rec_cgy_snp_dmnsn")

    val serpSelectDF = serpJoinedNewPnNnFcsFinalDF.withColumn("cust_po_id", upper(substring(col("cust_po_nr"), 1, 3))).select("sls_ord_id", "cust_po_id", "prft_cntr_cd", "bsn_cgy_lvl_1_cd").distinct

    var serpJoinedPNGreenLakeDF = serpSelectDF.alias("serpSelectDF").join(
      broadcast(pnGreenLakeFlgDF).alias("pnGreenLakeFlgDF"),
      ((serpSelectDF("cust_po_id") === pnGreenLakeFlgDF("cust_po_id_1")) || pnGreenLakeFlgDF("cust_po_id_1") === "all")
        && ((serpSelectDF("prft_cntr_cd") === pnGreenLakeFlgDF("pft_cntr_cd")) || pnGreenLakeFlgDF("pft_cntr_cd") === "all")
        && ((serpSelectDF("bsn_cgy_lvl_1_cd") === pnGreenLakeFlgDF("bsn_cgy_lvl_1_cd_1")) || pnGreenLakeFlgDF("bsn_cgy_lvl_1_cd_1") === "all"), "leftouter").select("pnGreenLakeFlgDF.*", "serpSelectDF.sls_ord_id")

    val serpJoinedPNGreenLakeDeDupDF = Utilities.getLatestRecs(serpJoinedPNGreenLakeDF, List("sls_ord_id", "cust_po_id_1", "pft_cntr_cd", "bsn_cgy_lvl_1_cd_1", "greenlake_flg_cd"), List("sls_ord_id"))

    val serpJoinedNewPnNnFcsFinalDF_new = serpJoinedNewPnNnFcsFinalDF.withColumn("cust_po_id", upper(substring(col("cust_po_nr"), 1, 3)))

    var serpJoinedPNGreenLakeFinalDF = serpJoinedNewPnNnFcsFinalDF_new.alias("serpJoinedNewPnNnFcsFinalDF_new").join(
      (serpJoinedPNGreenLakeDeDupDF).alias("serpJoinedPNGreenLakeDeDupDF"),
      serpJoinedNewPnNnFcsFinalDF_new("sls_ord_id") === serpJoinedPNGreenLakeDeDupDF("sls_ord_id")
        && ((serpJoinedNewPnNnFcsFinalDF_new("cust_po_id") === serpJoinedPNGreenLakeDeDupDF("cust_po_id_1")) || (serpJoinedNewPnNnFcsFinalDF_new("cust_po_id").isNull && serpJoinedPNGreenLakeDeDupDF("cust_po_id_1").isNull))
        && ((serpJoinedNewPnNnFcsFinalDF_new("prft_cntr_cd") === serpJoinedPNGreenLakeDeDupDF("pft_cntr_cd")) || (serpJoinedNewPnNnFcsFinalDF_new("prft_cntr_cd").isNull && serpJoinedPNGreenLakeDeDupDF("pft_cntr_cd").isNull))
        && ((serpJoinedNewPnNnFcsFinalDF_new("bsn_cgy_lvl_1_cd") === serpJoinedPNGreenLakeDeDupDF("bsn_cgy_lvl_1_cd_1")) || (serpJoinedNewPnNnFcsFinalDF_new("bsn_cgy_lvl_1_cd").isNull && serpJoinedPNGreenLakeDeDupDF("bsn_cgy_lvl_1_cd_1").isNull)), "leftouter").select("serpJoinedNewPnNnFcsFinalDF_new.*", "serpJoinedPNGreenLakeDeDupDF.greenlake_flg_cd")

    val SerpTblDf = serpJoinedPNGreenLakeFinalDF.as("serpTempTable5").
      join(bmtRevRecCgySnpDF.as("rev_rec_cgy_snp_dmnsn_cp"), col("serpTempTable5.cp_rev_recgn_cgy_cd") === col("rev_rec_cgy_snp_dmnsn_cp.rev_recgn_cgy_cd"), "left").
      join(bmtRevRecCgySnpDF.as("rev_rec_cgy_snp_dmnsn"), col("serpTempTable5.rvn_rcgn_cgy_cd") === col("rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd"), "left").
      join(bmtRevRecCgySnpDF.as("rev_rec_cgy_snp_dmnsn_incld_excld"), coalesce(col("revrecvalue"), col("serpTempTable5.rvn_rcgn_cgy_cd")) === col("rev_rec_cgy_snp_dmnsn_incld_excld.rev_recgn_cgy_cd"), "left").
      selectExpr(
        "secrd_rpt_fact_ky",
        "crc32(lower(trim(concat(coalesce(sls_ord_id,''),coalesce(sls_ord_ln_itm_id,''),coalesce(dlvry_id,''),coalesce(dlvry_itm_id,''),coalesce(soldto_prty_ctry_ky_cd,''),coalesce(eurofit_flg_cd,''))))) as mnl_corr_ky",
        "mdm_cust_ky",
        "cst_cntr_ky",
        "pdm_mtrl_mstr_grp_ky",
        "pft_cntr_ky",
        "mgmt_grphy_unt_ky",
        "fnctl_ar_ky",
        "cntry_ky",
        "sld_to_ky",
        "shp_to_ky",
        "bll_to_ky",
        "vndr_ky",
        "gl_acct_ky",
        "deal_ky",
        "quote_ky",
        "opty_ky",
        "ord_hddr_ky",
        "ord_itm_ky",
        "entrs_lgl_ent_ldgr_ky",
        "cldr_rpt_ky",
        "copa_ky",
        "hp_rcvd_dt_txt",
        "sls_ord_ln_itm_id",
        "sls_ord_id",
        "null as hpe_ord_nr",
        "deal_id",
        "mkt_rte_cd",
        "opty_id",
        "ord_typ_cd",
        "mtrl_nr",
        "src_sys_cd",
        "src_sys_ts",
        "ord_crt_ts",
        "ord_last_chg_dt",
        "hp_rcvd_dt",
        "quote_id",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else ord_net_vl_amt end as ord_net_vl_amt",
        "ord_dcmnt_curr_cd",
        "ord_dcmnt_curr_cd as tc_cd",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else ord_hddr_nt_vl_usd_amt end as ord_hddr_nt_vl_usd_amt",
        "sls_orgn_cd",
        "dstbn_chnl_cd",
        "dvsn_cd",
        "sls_grp_cd",
        "sls_offc_cd",
        "cst_cntr_cd",
        "fncl_ownr_cd",
        "cust_po_nr",
        "sld_to_cd",
        "shp_to_cd",
        "end_cust_cd",
        "bll_to_cd",
        "ord_dlvry_cd",
        "ord_prch_cd",
        "ord_hddr_stts_cd",
        "ord_itm_stts_cd",
        "mtrl_str_cd",
        "ord_itm_qty",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else nt_prc_amt end as nt_prc_amt",
        "ord_itm_nt_vl_amt",
        "ord_itm_dcmt_curr_cd",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else nt_prc_usd_amt end as nt_prc_usd_amt",
        "ord_itm_nt_vl_usd_amt",
        "plnt_cd",
        "ord_itm_crt_ts",
        "prft_cntr_cd",
        "prft_cntr_cd as cp_prft_cntr_cd",
        "sgmtl_rptg_cd",
        "sys_stts_cd",
        "sys_stts_ln_cd",
        "rvn_acctng_itm_src_dcmt_hdr_id",
        "blng_blck_sd_dcmt_cd",
        "crdd_cust_rqst_dt",
        "rslr_nr",
        "bndl_id",
        "bndl_qty_cd as bndl_qty",
        "hdr_hold_cd",
        "itm_hold_cd",
        "srv_agrmnt_id",
        "dlvry_id",
        "dlvry_itm_id",
        "actl_dlvry_dt",
        "sm_actl_gds_mvmt_dt",
        "invc_id",
        "invc_ln_itm_id",
        "actl_inv_dt",
        "base_qty as ord_base_qty",
        "unt_qty",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else nt_inv_vl_amt end as nt_inv_vl_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else grs_inv_vl_amt end as grs_inv_vl_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else cp_net_inv_usd_amt end as cp_net_inv_usd_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else cp_grs_inv_usd_amt end as cp_grs_inv_usd_amt",
        "crdt_dbt_ind",
        "disa_ind",
        "dscnt_ind",
        "CASE WHEN greenlake_flg_cd IS NULL THEN 'N' ELSE 'Y' END as grn_lake_ind",
        "dxc_ind",
        "hpc_ind",
        "hyperconverged_ind",
        "icoem_ind",
        "CASE WHEN nn_fcs_cntry_ord IS NULL THEN 'N' ELSE nn_fcs_cntry_ord END as nn_fcs_ctry_ord_ind",
        "CASE WHEN nn_fcs_cntry_actl IS NULL THEN 'N' ELSE nn_fcs_cntry_actl END as nn_fcs_ctry_actl_ind",
        "mlt_yr_ind",
        "prepaid_ind",
        "srv_intensity_ind",
        "ln_itm_1_cd",
        "ln_itm_2_cd",
        "ln_itm_3_cd",
        "ln_itm_4_ofr_cd",
        "ln_itm_5_sla_cvrg_cd",
        "ln_itm_6_typ_cd",
        "ln_itm_7_durtn_cd",
        "slng_mtn_lvl_1_cd",
        "slng_mtn_lvl_2_cd",
        "slng_mtn_lvl_3_cd",
        "slng_mtn_lvl_4_cd",
        "slng_mtn_lvl_5_cd",
        "hw_lvl_1_cd",
        "hw_lvl_2_cd",
        "hw_lvl_3_cd",
        "hw_lvl_4_cd",
        "hw_lvl_5_cd",
        "hw_lvl_6_cd",
        "serpTempTable5.bsn_cgy_lvl_1_cd",
        "serpTempTable5.bsn_cgy_lvl_2_cd",
        "serpTempTable5.bsn_cgy_lvl_3_cd",
        "cntrct_id",
        "pob_id",
        "recon_ky_cd",
        "fscl_yr_nr",
        "fscl_prd_nr",
        "CONCAT('FY',fscl_yr_nr,'-',fscl_prd_nr) as fscl_yr_prd_cd",
        "fscl_qtr_nr",
        "gl_acct_nr",
        "eurofit_flg_cd as eurofit_flag",
        "eurofit_splt_pct_cd as eurofit_split_percentage",
        "eurofit_ctry_cd",
        "ctry_cd",
        "Calc_cst_EK02_usd_amt as entrprs_stndrd_cst_grp_curr_usd_amt",
        "brdn_cst",
        "ttl_brdn_cst",
        "ttl_dly_brdn_cst",
        "ttl_base_qty_brdn_cst",
        "ttl_inv_brdn_cst",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else coalesce(case when ttl_cst_sls_amt = 0 then null else ttl_cst_sls_amt end,calc_cst_ek02_amt) end as ttl_cst_sls_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else coalesce(ttl_cst_sls_usd_amt,calc_cst_ek02_usd_amt) end as ttl_cst_sls_usd_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else fctry_mrgn_amt end as fctry_mrgn_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else nt_rvn_amt - ttl_cst_sls_amt end as grs_mrgn_amt",
        "rt_cnvsn_src",
        "rvn_cnvrsn_rt",
        "entrprs_stndrd_cst_rt",
        "ttl_cst_sls_rt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else cp_nt_rvn_amt end as cp_nt_rvn_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else cp_nt_rvn_usd_amt end as cp_nt_rvn_usd_amt",
        "CURRENT_TIMESTAMP as ins_ts",
        "scra_cgy_cd",
        "sni_risk_asmnt_cgy_cd",
        "fnc_adjmt_ind",
        "'N' as fnc_insrt_ind",
        "'NA' as fnc_insrt_rsn_cd",
        "cp_end_cust_prty_id",
        "cp_rtm_nm",
        "cp_sldt_prty_id",
        "cp_shpt_prty_id",
        "cp_prft_ctr_cd",
        "cp_segment_cd",
        "cp_grs_usd_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else coalesce(cp_entprs_std_cst_usd_amt,calc_cst_ek02_usd_amt*entrprs_stndrd_cst_rt) end as cp_entprs_std_cst_usd_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else coalesce(cp_entrprs_stndrd_cst,calc_cst_ek02_amt*entrprs_stndrd_cst_rt) end as cp_entrprs_stndrd_cst",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else coalesce(entprs_std_cst_usd_amt,calc_cst_ek02_usd_amt) end as entprs_std_cst_usd_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else coalesce(entrprs_stndrd_cst,calc_cst_ek02_amt) end as entrprs_stndrd_cst",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else coalesce(cp_tot_cst_of_sls_usd_amt,calc_cst_ek02_usd_amt*ttl_cst_sls_rt) end as cp_tot_cst_of_sls_usd_amt",
        "cp_unit_qty",
        "cp_rev_recgn_cgy_cd",
        "CASE WHEN rev_rec_cgy_snp_dmnsn_cp.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn_cp.rev_hd_cd ELSE 'Opportunity' END as cp_rev_hdr_nm",
        "rvn_rcgn_cgy_cd",
        s"CASE WHEN rev_rec_cgy_snp_dmnsn_incld_excld.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn_incld_excld.incd_excld_cd ELSE NULL END as cp_incd_excld",
        "CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.rev_hd_cd ELSE 'Opportunity' END as rev_hd_cd",
        s"$revrecvalue as rev_rec_cgy_cd",
        "beg_bklg_nm",
        "cp_bklg_sni_rvn",
        "fscl_week_cd",
        "shp_to_ctry_cd",
        "bsn_ty_1_cd",
        "ctry_nm",
        "cust_sgm_nm",
        "bsn_rshp_typ_cd",
        "prtl_dlvry_itm_lvl",
        "src_idoc_nr",
        "idoc_crt_dt_ts",
        "deal_acct_mgmt_lvl_2_id",
        "deal_acct_mgmt_lvl_2_nm",
        "deal_bsn_mdl_cd",
        "deal_bsn_mdl_dn",
        "deal_cust_ltn_nm",
        "deal_cust_nn_ltn_nm",
        "deal_rgst_id",
        "deal_src_sys_cd",
        "deal_deal_src_sys_dn as deal_src_sys_dn",
        "deal_stts_nm",
        "deal_sb_typ_cd",
        "deal_typ_cd",
        "deal_vrsn_nr",
        "deal_vrsn_stts_nm",
        "deal_grphc_scp_nm",
        "deal_indy_id",
        "deal_last_updd_by_eml_id",
        "deal_lead_bsn_unt_cd",
        "deal_misc_crg_cd",
        "deal_prnt_org_id",
        "deal_prnt_org_nm",
        "deal_pyr_prty_id",
        "deal_sls_tty_acct_cnflct_ind",
        "deal_sls_tty_acct_nm",
        "deal_src_deal_id",
        "deal_vld_end_ts",
        "deal_vld_strt_ts",
        "deal_ins_ts",
        "deal_upd_ts",
        "quote_header_sls_qtn_vrsn_sqn_nr_cd",
        "asset_quote_nr_cd",
        "asset_quote_vrsn_cd",
        "modified_ts_cd",
        "creation_person_id_id as crtd_by_usr_id",
        "sfdc_status_cd",
        "total_amt",
        "total_list_price_amt",
        "bmi_id_id",
        "nm",
        "price_geo_cd",
        "asset_quote_nr_and_vrsn_cd",
        "org_id_id",
        "creation_ts_cd",
        "currency_cd_cd",
        "sls_qtn_vrsn_typ_cd_cd",
        "cty_cd",
        "quoteowner_cd",
        "flg_typ_cd",
        "flg_vl_cd",
        "sls_qtn_vrsn_typ_cd_cd as sls_qtn_vrsn_stts_cd_cd",
        "partner_id_id",
        "orig_asset_cd",
        "modified_person_id_id",
        "lead_bu_cd",
        "last_modifier_ngq_profile_cd",
        "customer_mdcp_org_id_id",
        "mdcp_opsi_id_id",
        "creator_ngq_profile_cd",
        "creation_person_id_id",
        "completion_ts_cd",
        "quote_items_product_line_cd",
        "lcl_xtnd_nt_amt_cd",
        "qty_cd",
        "acct_i_20_nm as accnt_id",
        "hpe_quote_flags_sls_qtn_id_id as hpe_quote_flags_sls_qtn_id",
        "hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd as hpe_quote_flags_sls_qtn_vrsn_sqn_nr",
        "totl_opty_v_cd as ttl_opty_vl",
        "expctd_amt_cd as opty_expctd_amt",
        "opty_totl_amt_cd as opty_totl_amt",
        "opty_totl_amt_cd as opty_val",
        "instln_ord_flg",
        "prj_ord",
        "dlvy_inv_cd",
        "inv_bvr",
        "pld_inv_dt",
        "hg_vw_bkt",
        "sni_alt_bkt",
        "in_out",
        "pri_bkt",
        "in_out_omc_rsk_bkt",
        "acct_asngmt_groupItem_cd as acct_asngmt_cd_grp",
        "case when estmd_inv_hdr_dt = '00000000' then '' else estmd_inv_hdr_dt end as estmd_invc_date_hdr",
        "estmd_inv_dt as estmd_inv_dt_itm",
        "cp_estmd_inv_dt_itm",
        "sls_mtrc_cd as sls_mtrc_cd",
        "ord_durtn_cd",
        "itm_vl_usr_stts_cd as prod_base_id",
        "prod_id",
        "pkg_prod_id as pkg_prod_id",
        "pmd_mtrl_mstr_sls_dvsn_cd as mft_prd_ln_cd",
        "pm_mtrl_mstr_sls_dvsn_cd as srvc_gds_prd_ln_cd",
        "prod_hrchy_prod_fmly_cd as mft_prd_fmly_ln_cd",
        "gbl_carepack_hw_prod_ln_id as gbl_crpk_prd_ln_cd",
        "prod_hrchy_prod_typ_cd as bs_prd_typ_cd",
        "gds_rcpnt_ctry_ky_cd as shp_to_ctry_ky",
        "soldto_prty_ctry_ky_cd as sld_to_ctry_ky",
        "sm_prf_dlvry_cfrn_dt as prf_dlvry_cfrn_dt",
        "prch_ord_dt as prch_ord_dt",
        "rsn_at_ln_itm_cd as rsn_at_ln_itm_cd",
        "Intangible_vs_Tangible_id_id as intangible_ln_itm_stts_cd",
        "blng_stts_cd as invc_stts_cd",
        "itm_stts_cd as itm_stts_cd",
        "OIS_cd as ois_trsn_nr",
        "ord_st_opn_vs_clsd_cd as ord_st_cd",
        "cntrct_strt_dt",
        "cntrct_end_dt",
        "ff_ln_itm_0_tmp as FF_LI0",
        "ff_ln_itm_1_tmp as FF_LI1",
        "ff_ln_itm_2_tmp as FF_LI2",
        "ff_ln_itm_3_tmp as FF_LI3",
        "ff_ln_itm_4_tmp as FF_LI4",
        "ff_ln_itm_5_tmp as FF_LI5",
        "ff_ln_itm_6 as FF_LI6",
        "ff_ln_itm_7 as FF_LI7",
        "rfrnc_dcmt_nr",
        "rfrnc_dcmt_itm_nr as rfnc_dcmt_ln_itm_nr",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else calc_cst_ek02_amt end as calc_cst_ek02_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else calc_cst_ek02_usd_amt end as calc_cst_ek02_usd_amt",
        "exch_rate_frm_src_cd as exch_rate",
        "MRU as mru_cd",
        "ucid_id",
        "bto_cto_flg",
        "rsn_rjctn_quotations_and_sls_orders_cd",
        "sls_ord_cmpltn_stts_cd",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else direct_cost*(1+coalesce(variable_cost,0)) end as c4_direct_cost",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else indirect_cost end as c4_indirect_cost",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else direct_cost*(1+coalesce(variable_cost,0)) + coalesce(indirect_cost,0) + coalesce(var_trd_cost,0) end as c4_total_cost",
        "unq_dor_id_id as unq_dor_id_id",
        "serpTempTable5.src_sys_upd_ts",
        "serpTempTable5.src_sys_ky as src_sys_ky",
        "serpTempTable5.lgcl_dlt_ind as lgcl_dlt_ind",
        "serpTempTable5.ins_gmt_ts",
        "serpTempTable5.upd_gmt_ts",
        "serpTempTable5.src_sys_extrc_gmt_ts",
        "serpTempTable5.src_sys_btch_nr",
        "serpTempTable5.fl_nm",
        "serpTempTable5.ld_jb_nr",
        "c4_ky",
        "dfrd_curr_ky",
        "dfrd_curr_cd",
        "dfrd_rvn_dlta_amt",
        "dfrd_grp_acct",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else nt_rvn_amt end as nt_rvn_amt",
        "calc_fscl_year",
        "pstg_curr_cd",
        "pstg_rvn_dlta_amt",
        "pstg_grp_acct",
        "pstg_curr_ky",
        "dfrd_three_mnth_avg_amt_cal",
        "dfrd_twelve_mnth_avg_amt_cal",
        "pstg_three_mnth_avg_amt_cal",
        "pstg_twelve_mnth_avg_amt_cal",
        "rar_ky",
        "ord_optn_qty",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else ord_ttl_qty end as ord_ttl_qty",
        "smpt_base_qty",
        "spmt_optn_qty",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else spmt_ttl_qty end as spmt_ttl_qty",
        "oa_ord_stts",
        "ord_crt_dt",
        "fnctl_ar_cd",
        "txt_ln_nm as ln_itm_txt",
        "bsn_ty_1_cd as bsn_typ_cd",
        "base_qty as cp_base_qty",
        "rptg_mtrl_opt_cd as prod_bs_and_opt_nr",
        "srvs_mtrl_id_id as srvc_gds_prod_id",
        "crc32(lower(coalesce(dlvry_id,''))) as dlvry_itm_ky",
        "crc32(lower(coalesce(invc_id,''))) as invc_itm_ky",
        "sld_to_cd as cp_sld_to_cd",
        "shp_to_cd as cp_shp_to_cd",
        "end_cust_cd as cp_end_cust_cd",
        "sgmtl_rptg_cd as cp_sgmtl_cd",
        "unt_qty as cp_unt_qty",
        "trsn_dt as ope_fscl_prd",
        "mkt_rte_cd as cp_mkt_rte_cd",
        "rvn_pstd_qty as rar_qty",
        "rte_cd",
        "COALESCE(pstg_curr_ky,dfrd_curr_ky) as grs_rvn_curr",
        "COALESCE(pstg_curr_ky,dfrd_curr_ky) as nt_rvn_curr",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else coalesce(cp_ttl_cst_sls_amt,calc_cst_ek02_amt*ttl_cst_sls_rt) end as cp_ttl_cst_sls_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else cp_nt_prc_usd_amt end as cp_nt_prc_usd_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else cp_nt_prc_amt end as cp_nt_prc_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else case when grs_rvn_amt is null or grs_rvn_amt = 0 then nt_rvn_amt else (grs_rvn_amt - nt_rvn_amt) end end as disc_dcmt_curr_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else case when grs_rvn_usd_amt is null or grs_rvn_usd_amt = 0 then nt_rvn_usd_amt else (grs_rvn_usd_amt - nt_rvn_usd_amt) end end as disc_glbl_curr_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else case when grs_rvn_amt is null or grs_rvn_amt = 0 then nt_rvn_amt*rvn_cnvrsn_rt else (grs_rvn_amt*grs_rvn_rt) - (nt_rvn_amt*rvn_cnvrsn_rt) end end as cp_disc_dcmt_curr_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else case when grs_rvn_usd_amt is null or grs_rvn_usd_amt = 0 then nt_rvn_usd_amt*rvn_cnvrsn_rt else (grs_rvn_usd_amt*grs_rvn_rt) - (nt_rvn_usd_amt*rvn_cnvrsn_rt) end end as cp_disc_glbl_curr_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else grs_rvn_amt end as grs_rvn_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else grs_rvn_usd_amt end as grs_rvn_usd_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else grs_rvn_amt*grs_rvn_rt end as cp_grs_rvn_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else grs_rvn_usd_amt*grs_rvn_rt end as cp_grs_rvn_usd_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else nt_rvn_usd_amt - ttl_cst_sls_usd_amt end as grs_mrgn_usd_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else ttl_rvn_amt end as ttl_rvn_amt",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else ttl_rvn_usd_amt end as ttl_rvn_usd_amt",
        "cp_ndp_usd_amt",
        "hghr_lvl_itm_no_cd",
        "shrt_txt_sls_ord_itm_nm",
        "pstg_usd_rvn_dlta_amt",
        "dfrd_cntrct_crtn_ts",
        "deal_end_cust_presls_prty_id",
        "deal_other_prty_site_insn_id",
        "deal_org_id",
        "deal_site_insn_id",
        "deal_sls_tty_acct_id",
        "deal_prty_rol_deal_id",
        "deal_prty_id",
        "sales_org_cd",
        "soldto_prty_nm",
        "quotes_cust_nm",
        "quotes_cust_mdcp_site_id",
        "quotes_dist_ptnr_id",
        "sold_to_staid_id",
        "mdm_id",
        "opty_bk_ship_dt",
        "opty_lst_mfd_dt",
        "sys_modstam",
        "bg_cd",
        "gbu_cd",
        "opty_stg",
        "prd_nm",
        "prd_ln",
        "sub_prd_ln",
        "opty_chnl_ptnr_flg_cd",
        "opty_ptnr_typ_cd",
        "opty_prmry_dstr_cd",
        "opty_prmry_rslr_cd",
        "opty_ptnr_typ_nm",
        "opty_prmry_dstr_mdcp_org_id_nm",
        "opty_prmry_dstr_nm",
        "opty_prmry_ppln_own_nm",
        "opty_team_mmbr_nm",
        "opty_useremail_nm",
        "acct_nm",
        "opty_crt_dt",
        "opty_hpe_opportunity_id",
        "opty_line_item_id",
        "opty_val_cd",
        "opty_sales_rep_nm",
        "opty_expctd_usd_amt",
        "opty_totl_usd_amt",
        "ord_class",
        "cp_ctry_nm",
        "cp_cust_sgm_nm",
        "crc32(lower(concat(trim(coalesce(dlvry_id,'')),trim(coalesce(dlvry_itm_id,''))))) as dlvry_hdr_ky",
        "crc32(lower(concat(trim(coalesce(invc_id,'')),trim(coalesce(invc_ln_itm_id,''))))) as invc_hdr_ky",
        "pre_bld_ord",
        "cfo_ord",
        "cmo_ord",
        "mtrl_acct_asngmt_grp_cd",
        "cntrct_cgy_cd",
        "case when rptg_mtrl_id_id like '%#%' and ord_itm_nt_vl_amt = 0 then 0 when rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else nt_rvn_usd_amt end as nt_rvn_usd_amt",
        "prmry_prcg_cndn_cd",
        "grs_rvn_rt",
        "net_prc_rt",
        "spmlfd_dlvry_sts_dn",
        "spmlfd_ord_ln_itm_sts_dn",
        "spmlfd_ord_hddr_sts_dn",
        "actl_qty_dlvrd_stockkeeping_unts",
        "ord_hddr_ky",
        "odr_typ_ky",
        "prtl_spmt_multr",
        "cp_deal_end_cust_prty_id",
        "cp_bmt_end_cust_prty_id",
        "cp_dstr_prty_id",
        "cp_rslr_prty_id",
        "cp_src_end_cust_prty_id",
        "cp_crss_brdr",
        "src_type",
        "eurofit_multiplier",
        "opportunity_estimated_revenue_usd",
        "rptg_mtrl_id_id",
        "cls_2_dt",
        "nt_unt_rsttd_sls_spmt_bdgt_amt_frm_src_cd",
        "nt_xtnd_rsttd_sls_spmt_bdgt_amt_frm_src_cd").distinct

    /*
     * Budget Rate Currency and Restatement
     *
     * Derivation of Budget Rate in USD
     *
		 * Derivation 3 months Average
		 * columns added - grs_rvn_three_mnth_avg_amt,nt_rvn_three_mnth_avg_amt
		 *
		 * Derivation 12 months Average
		 * columns added - grs_rvn_twelve_mnth_avg_amt,nt_rvn_twelve_mnth_avg_amt
		 *
		 *
     */

    //Derivation of global currency amount for deferred resttated logic

    def globalindirectexchtr(df: DataFrame, fromCurr: String, rateDate: String, globalCol: String): DataFrame = {
      val exhchangedf = spark.sql(s"select a.* from (select exch.*,row_number() over (partition by frm_curr_cd,year(etry_vld_frm_ts),month(etry_vld_frm_ts) order by day(etry_vld_frm_ts) desc) rn from ${dbNameConsmtn}.exch_rates_dmnsn exch where exch_rate_typ_cd = 'M' and to_curr_cd = 'USD') as a where a.rn=1")
      val joindf = df.alias("src").join(exhchangedf.alias("exch"), df(fromCurr) === exhchangedf("frm_curr_cd") && month(to_date(from_unixtime(unix_timestamp(df(rateDate), "yyyyMMdd")))) === month(exhchangedf("etry_vld_frm_ts")) && year(to_date(from_unixtime(unix_timestamp(df(rateDate), "yyyyMMdd")))) === year(exhchangedf("etry_vld_frm_ts")), "leftouter").select("src.*", "exch.etry_vld_frm_ts", "exch.frm_curr_unts_rto_1_nr", "exch.to_curr_unts_rto_1_nr", "exch.indrt_qted_exch_rate_nr", "exch.frm_curr_cd", "exch.to_curr_cd")
      val df4 = joindf.select(
        col("*"),
        expr("CASE WHEN frm_curr_unts_rto_1_nr = to_curr_unts_rto_1_nr THEN  CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE) " + "WHEN frm_curr_unts_rto_1_nr > to_curr_unts_rto_1_nr THEN CAST(((to_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*frm_curr_unts_rto_1_nr) AS DOUBLE) " + "WHEN frm_curr_unts_rto_1_nr < to_curr_unts_rto_1_nr THEN CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE)" + " else null end").alias(globalCol))
      val df4_final = df4.drop("etry_vld_frm_ts", "frm_curr_unts_rto_1_nr", "to_curr_unts_rto_1_nr", "indrt_qted_exch_rate_nr", "frm_curr_cd", "to_curr_cd")
      df4_final
    }

    val deferredRevenueDF_gbl = globalindirectexchtr(SerpTblDf, "dfrd_curr_ky", "dfrd_cntrct_crtn_ts", "exch_rate_global")

    val deferredRevenueDF_gbl1 = deferredRevenueDF_gbl.select(col("*"), expr("CASE WHEN dfrd_curr_ky='USD' THEN cast((dfrd_rvn_dlta_amt / 1) as double)" + " WHEN dfrd_curr_ky is NULL THEN NULL" + " else CAST((dfrd_rvn_dlta_amt*exch_rate_global) AS DOUBLE) end").alias("dfrd_usd_rvn_dlta_amt"))

    //Derivation of Budget Rate in USD for deferred

    val serpSelectDfFinal_dfrdbdgt = budgetindirectexchtr(deferredRevenueDF_gbl1, "dfrd_curr_ky", "dfrd_exch_rate_budget", dbFinancName)

    //Derivation of Restated Budget amount in USD for deferred

    val serpSelectDfFinal_dfrdrsttdbdgt = serpSelectDfFinal_dfrdbdgt.select(col("*"), expr("CASE WHEN dfrd_exch_rate_budget IS NULL OR dfrd_exch_rate_budget=0 OR fscl_prd_nr ='000' OR fscl_prd_nr IS NULL THEN dfrd_usd_rvn_dlta_amt" + " WHEN dfrd_curr_cd = 'USD' OR dfrd_curr_cd = 'NA' THEN dfrd_usd_rvn_dlta_amt" + " WHEN dfrd_rvn_dlta_amt =0 OR dfrd_rvn_dlta_amt IS NULL THEN dfrd_usd_rvn_dlta_amt" + " WHEN dfrd_curr_cd is not NULL THEN dfrd_usd_rvn_dlta_amt" + " WHEN dfrd_curr_cd is NULL and fscl_yr_nr=calc_fscl_year THEN dfrd_usd_rvn_dlta_amt" + " WHEN dfrd_curr_cd is NULL and fscl_yr_nr >=(calc_fscl_year-3) and fscl_yr_nr != calc_fscl_year THEN cast((dfrd_rvn_dlta_amt*dfrd_exch_rate_budget) AS DOUBLE)" + " else dfrd_usd_rvn_dlta_amt end").alias("dfrd_rvn_amt_usd_rsttd_bdgt_rate_cd_cal"))

    //Derivation of Budget Rate in USD for posting

    val serpSelectDfFinal_pstgbdgt = budgetindirectexchtr(serpSelectDfFinal_dfrdrsttdbdgt, "pstg_curr_ky", "pstg_exch_rate_budget", dbFinancName)

    //Derivation of Restated Budget amount in USD for posting

    val serpSelectDfFinal_pstgrsttdbdgt = serpSelectDfFinal_pstgbdgt.select(col("*"), expr("CASE WHEN pstg_exch_rate_budget IS NULL OR pstg_exch_rate_budget=0 OR fscl_prd_nr ='000' OR fscl_prd_nr IS NULL THEN pstg_usd_rvn_dlta_amt" + " WHEN pstg_curr_cd = 'USD' OR pstg_curr_cd = 'NA' THEN pstg_usd_rvn_dlta_amt" + " WHEN pstg_rvn_dlta_amt =0 OR pstg_rvn_dlta_amt IS NULL THEN pstg_usd_rvn_dlta_amt" + " WHEN pstg_curr_cd is not NULL THEN pstg_usd_rvn_dlta_amt" + " WHEN pstg_curr_cd is NULL and fscl_yr_nr=calc_fscl_year THEN pstg_usd_rvn_dlta_amt" + " WHEN pstg_curr_cd is NULL and fscl_yr_nr >=(calc_fscl_year-3) and fscl_yr_nr != calc_fscl_year THEN cast((pstg_rvn_dlta_amt*pstg_exch_rate_budget) AS DOUBLE)" + " else pstg_usd_rvn_dlta_amt end").alias("pstg_rvn_amt_usd_rsttd_bdgt_rate_cd_cal"))

    val finalSERPDF = serpSelectDfFinal_pstgrsttdbdgt.as("finalSERPDF").selectExpr("finalSERPDF.*","crc64(concat(secrd_rpt_fact_ky,row_number() over (partition by sls_ord_id,sls_ord_ln_itm_id order by finalSERPDF.upd_gmt_ts))) as secrd_rpt_fact_ky_new", "CASE WHEN dfrd_three_mnth_avg_amt_cal=0 THEN dfrd_usd_rvn_dlta_amt ELSE dfrd_three_mnth_avg_amt_cal end as grs_rvn_three_mnth_avg_amt", "CASE WHEN dfrd_twelve_mnth_avg_amt_cal=0 then dfrd_usd_rvn_dlta_amt else dfrd_twelve_mnth_avg_amt_cal end as grs_rvn_twelve_mnth_avg_amt", "CASE WHEN pstg_three_mnth_avg_amt_cal=0 THEN pstg_usd_rvn_dlta_amt ELSE pstg_three_mnth_avg_amt_cal end as nt_rvn_three_mnth_avg_amt", "CASE WHEN pstg_twelve_mnth_avg_amt_cal=0 then pstg_usd_rvn_dlta_amt else pstg_twelve_mnth_avg_amt_cal end as nt_rvn_twelve_mnth_avg_amt", "CASE WHEN dfrd_exch_rate_budget IS NULL OR dfrd_exch_rate_budget=0 OR fscl_prd_nr ='000' OR fscl_prd_nr IS NULL THEN dfrd_usd_rvn_dlta_amt WHEN dfrd_curr_cd = 'USD' OR dfrd_curr_cd = 'NA' THEN dfrd_usd_rvn_dlta_amt WHEN dfrd_rvn_dlta_amt =0 OR dfrd_rvn_dlta_amt IS NULL THEN dfrd_usd_rvn_dlta_amt WHEN dfrd_curr_cd is not NULL THEN dfrd_usd_rvn_dlta_amt WHEN dfrd_curr_cd is NULL and fscl_yr_nr=calc_fscl_year THEN dfrd_rvn_dlta_amt*dfrd_exch_rate_budget ELSE 0 END as grs_rvn_bdgt_curr_rvn_dlta_amt", "CASE WHEN pstg_exch_rate_budget IS NULL OR pstg_exch_rate_budget=0 OR fscl_prd_nr ='000' OR fscl_prd_nr IS NULL THEN pstg_usd_rvn_dlta_amt WHEN pstg_curr_cd = 'USD' OR pstg_curr_cd = 'NA' THEN pstg_usd_rvn_dlta_amt WHEN pstg_rvn_dlta_amt =0 OR pstg_rvn_dlta_amt IS NULL THEN pstg_usd_rvn_dlta_amt WHEN pstg_curr_cd is not NULL THEN pstg_usd_rvn_dlta_amt WHEN  pstg_curr_cd is NULL and fscl_yr_nr=calc_fscl_year THEN pstg_rvn_dlta_amt*pstg_exch_rate_budget ELSE 0 END as nt_rvn_bdgt_curr_rvn_dlta_amt", "dfrd_rvn_amt_usd_rsttd_bdgt_rate_cd_cal as grs_rvn_amt_usd_rsttd_bdgt_rate_cd", "pstg_rvn_amt_usd_rsttd_bdgt_rate_cd_cal as nt_rvn_amt_usd_rsttd_bdgt_rate_cd").drop("secrd_rpt_fact_ky").withColumnRenamed("secrd_rpt_fact_ky_new", "secrd_rpt_fact_ky")

    
    logger.info("++++++++++++++############ SERP data prepared ############++++++++++++++")

    val tgtColumns = spark.sql(s"select * from " + tgtTblConsmtn + " limit 0").columns

    // re-arrange columns based on target table
    val dataLoadDF = finalSERPDF.select(Utilities.loadSelectExpr(finalSERPDF.columns, tgtColumns): _*)

    dataLoadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblConsmtn)

    logger.info("++++++++++++++############ Data inserted ############++++++++++++++")

    val tgtCount = spark.sql(s"select * from ${tgtTblConsmtn} where src_sys_cd = 'SERP'").count.toInt

    tgtCount match {
      case 0 =>
        logger.error("//************* Data Load Failed")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } finally {
    logger.info("//*********************** Log End for SERPSecuredReporting.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
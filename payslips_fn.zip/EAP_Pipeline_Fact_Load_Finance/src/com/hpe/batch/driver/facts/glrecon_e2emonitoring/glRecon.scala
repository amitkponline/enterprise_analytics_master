package com.hpe.batch.driver.facts.glrecon_e2emonitoring

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._

import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types.StringType
import main.scala.com.hpe.utils.Utilities
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import org.apache.spark.storage.StorageLevel

object glRecon extends App {

	//**************************Driver properties******************************//

	    val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
			val spark = configObject.spark
			val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
			val propertiesFilePath = String.valueOf(args(0).trim())
			val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
			val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"

			val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
			val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
			val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
			val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
			val sqlCon = Utilities.getConnection(envPropertiesObject)

			//***************************Audit Properties********************************//
			val logger = Logger.getLogger(getClass.getName)
			auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

			val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
			val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
			val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
			val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
			val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
			val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
			val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

			auditObj.setAudObjectName(propertiesObject.getObjName())
			var startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
			auditObj.setAudJobStartTimeStamp(startTime)
			auditObj.setAudLoadTimeStamp("9999-12-31 00:00:00")
			auditObj.setAudDataLayerName("ref_cnsmpn")
			auditObj.setAudSrcRowCount(0)
			auditObj.setAudTgtRowCount(0)
			auditObj.setAudErrorRecords(0)
			auditObj.setAudCreatedBy(configObject.getSpark().sparkContext.sparkUser)
			auditObj.setFlNm("")

			var dbNameSrc: String   = null
			var dbNameCnsmp: String = null
			var srcTable: String    = null
			var dbNameOthr: String  = null
			
			if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
				    dbNameSrc   = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0)
						dbNameCnsmp = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
						srcTable    = propertiesObject.getSrcTblConsmtn().trim()
						dbNameOthr  = propertiesObject.getDbName().trim()

			} else {
				logger.error("Please update tgtTblConsmtn properties to add database name!")
				sqlCon.close()
				System.exit(1)
			}

			var src_count: Long = 0
			var tgt_count: Long = 0

					try {

						var reprocessDays = propertiesObject.getReprocessDays()

								logger.error("The Detailed view will be updated for last "+reprocessDays+" days!")

								var ref_btch_id     = Utilities.readRefBatchId(sqlCon, "e2emonitoring_fin",auditTbl)
								var cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, "e2emonitoring_fin_gl_ln_itm_vw_consp",auditTbl)   

								logger.info("Source table Name :"+srcTable+" ref_btch_id :- "+ref_btch_id+" cnsmptn_btch_id :- "+cnsmptn_btch_id)

								logger.info("******************* E2EMonitoring glRecon Consumption Table load Started ************************************")

								auditObj.setAudBatchId(ref_btch_id)
								auditObj.setAudDataLayerName("ref_cnsmptn")
								auditObj.setAudApplicationName("e2emonitoring_gl_Aud_EAP_Recon")
								auditObj.setAudObjectName("e2emonitoring_fin_gl_ln_itm_vw_consp")
															
							if(	ref_btch_id != cnsmptn_btch_id){
							  
								var transformedDF  = spark.sql(s"""select
										a.splitted_col[0] as gnrl_ldgr_acctng_cd
										,a.splitted_col[1] as entrs_lgl_ent_ldgr_cd
										,a.splitted_col[4] as acctng_dcmt_id
										,a.splitted_col[5] as pstg_itm_ldgr_cd
										,from_unixtime(unix_timestamp(a.splitted_col[6],'yyyyMMddHHmmss'),'yyyy-MM-dd HH:mm:ss') as utc_ts
										,from_unixtime(unix_timestamp(a.splitted_col[7],'yyyyMMdd'),'yyyy-MM-dd') as dcmt_pstg_dt
										,a.splitted_col[8] as dbt_crdt_ind
										,a.splitted_col[9] as dcmt_typ_cd
										,a.splitted_col[10] as pft_cntr_cd
										,a.splitted_col[11] as mgmt_grphy_unt_cd
										,a.splitted_col[12] as acct_nr
										,a.splitted_col[13] as fnctl_ar_cd
										,a.splitted_col[14] as cst_cntr_cd
										,a.splitted_col[15] as ord_nr
										,a.splitted_col[16] as sndr_cst_cntr_cd
										,a.splitted_col[17] as clarg_dcmt_nr
										,from_unixtime(unix_timestamp(a.splitted_col[18],'yyyyMMdd'),'yyyy-MM-dd') as clarg_dt
										,a.splitted_col[19] as tc_cd
										,case when substr(a.splitted_col[20],-1,1)='-' then cast(concat('-',substr(a.splitted_col[20],1,length(a.splitted_col[20])-1)) as double) else a.splitted_col[20] end as tc_amt
										,a.splitted_col[21] as co_curr_cd
										,case when substr(a.splitted_col[22],-1,1)='-' then cast(concat('-',substr(a.splitted_col[22],1,length(a.splitted_col[22])-1)) as double) else a.splitted_col[22] end as co_cd_curr_amt
										,a.splitted_col[23] as gbl_curr_cd
										,case when substr(a.splitted_col[24],-1,1)='-' then cast(concat('-',substr(a.splitted_col[24],1,length(a.splitted_col[24])-1)) as double) else a.splitted_col[24] end as gbl_curr_amt
										,CURRENT_TIMESTAMP AS ins_gmt_ts
										,a.ld_jb_nr
										,a.splitted_col[2] as fscl_yr_nr 
										,a.splitted_col[3] as pstg_prd_nr
										FROM
										(select e2e.*, row_number() over (partition by e2e.splitted_col[0] ,e2e.splitted_col[1] ,e2e.splitted_col[2] ,e2e.splitted_col[3] ,e2e.splitted_col[4] ,e2e.splitted_col[5] order by e2e.splitted_col[6] desc)rn 
										FROM  
										(select split(e2emonitoring_fin_ref.obj_id,'\\\\|') as splitted_col,ld_jb_nr FROM """+srcTable+""" as e2emonitoring_fin_ref where msg_typ='GL_LINE_ITEM' and ld_jb_nr >'"""+cnsmptn_btch_id+"""' ) e2e 
										where e2e.splitted_col[0] ='0L' ) a where a.rn=1""")
																			
								transformedDF.repartition(10).write.mode("append").format("orc").insertInto(dbNameCnsmp+".e2emonitoring_fin_gl_ln_itm_vw_consp")

								logger.info("******************* E2EMonitoring glRecon Consumption load completed ************************************")

								transformedDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

								transformedDF.repartition(10)

								//tgt_count = transformedDF.count().toInt
								
								tgt_count = spark.sql(s"select * from ${dbNameCnsmp}.e2emonitoring_fin_gl_ln_itm_vw_consp where ld_jb_nr >'${cnsmptn_btch_id}'").count.toInt 
								
								src_count = tgt_count

								transformedDF.unpersist()

								auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobStatusCode("success")
								auditObj.setAudSrcRowCount(src_count)
								auditObj.setAudTgtRowCount(tgt_count)
								auditObj.setAudErrorRecords(0)
								auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
								auditObj.setFlNm("")
								auditObj.setSysBtchNr(ld_jb_nr)
								auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
								Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

               
							  logger.info("******************* e2emonitoring_fin_gl_itm_aud_trsn Table load Started ************************************")

								cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, "e2emonitoring_fin_gl_itm_aud_trsn",auditTbl) 

								logger.info("e2emonitoring_fin_gl_itm_aud_trsn cnsmptn_btch_id :-"+cnsmptn_btch_id)

								auditObj.setAudBatchId(ref_btch_id)
								auditObj.setAudDataLayerName("ref_cnsmptn")
								auditObj.setAudApplicationName("e2emonitoring_gl_Aud_EAP_Recon")
								auditObj.setAudObjectName("e2emonitoring_fin_gl_itm_aud_trsn")
								src_count = 0
								tgt_count = 0

								transformedDF  = spark.sql(s"""select
								    adt.gnrl_ldgr_acctng_cd
										,adt.entrs_lgl_ent_ldgr_cd
										,adt.acctng_dcmt_id
										,adt.pstg_itm_ldgr_cd
										,adt.utc_ts
										,adt.dcmt_pstg_dt
										,adt.dbt_crdt_ind
										,adt.dcmt_typ_cd
										,adt.pft_cntr_cd
										,adt.mgmt_grphy_unt_cd
										,adt.acct_nr
										,adt.fnctl_ar_cd
										,adt.cst_cntr_cd
										,adt.ord_nr
										,adt.sndr_cst_cntr_cd
										,adt.clarg_dcmt_nr
										,adt.clarg_dt
										,adt.tc_cd
										,adt.tc_amt
										,adt.co_curr_cd
										,adt.co_cd_curr_amt
										,adt.gbl_curr_cd
										,adt.gbl_curr_amt
										,adt.cst_cntr_cd_calc
										,adt.acct_type_cd
								    ,CASE WHEN adt.acct_type_cd = 'BS' THEN NULL
										WHEN (Length(Trim(adt.cst_cntr_cd))> 0) THEN c.prnt_cst_cntr_cd
										WHEN (CASE WHEN (adt.cst_cntr_cd IS NULL ) and (adt.acct_type_cd = 'PL')
										THEN b.out_put end) IS NULL and (adt.acct_type_cd = 'PL') AND (adt.mgmt_grphy_unt_cd like 'S1780' or adt.mgmt_grphy_unt_cd like 'S1785') THEN 'FO70000010'
										WHEN (CASE WHEN (adt.cst_cntr_cd IS NULL ) and (adt.acct_type_cd = 'PL')
										THEN b.out_put end) IS NULL and (adt.acct_type_cd = 'PL') AND (adt.mgmt_grphy_unt_cd not like 'S1780' AND adt.mgmt_grphy_unt_cd not like'S1785') THEN 'FO70000038'
										WHEN (adt.cst_cntr_cd IS NULL ) and (adt.acct_type_cd = 'PL') THEN b.out_put 
										END AS fin_own_cd
										,gla_master.grp_acct_nr AS grp_acct_nr
										,adt.ins_gmt_ts
										,adt.ld_jb_nr
										,adt.fscl_yr_nr
										,adt.pstg_prd_nr from
										(select a.*, 
										CASE WHEN inr.rspnsbl_cst_cntr_cd is not null THEN inr.rspnsbl_cst_cntr_cd
										WHEN inr.rspnsbl_cst_cntr_cd is null and (a.cst_cntr_cd = '' or a.cst_cntr_cd is null) THEN a.sndr_cst_cntr_cd
										ELSE (CASE WHEN Trim(a.cst_cntr_cd) = '' THEN NULL ELSE a.cst_cntr_cd end) 
										END AS cst_cntr_cd_calc,
										CASE WHEN Substr(a.acct_nr, 3, 1) <= '2' THEN 'BS'
										WHEN Substr(a.acct_nr, 3, 1) >= '3' and Substr(a.acct_nr, 3, 1) <= '4' THEN 'PL' ELSE 'OTHER' 
										END AS acct_type_cd 
										FROM """+dbNameCnsmp+""".e2emonitoring_fin_gl_ln_itm_vw_consp a   
										LEFT JOIN (select distinct ord_id, CASE WHEN rspnsbl_cst_cntr_cd = '' THEN NULL ELSE rspnsbl_cst_cntr_cd 
										END AS rspnsbl_cst_cntr_cd from """+dbNameOthr+""".inrn_ord_dmnsn) inr 
										on a.ord_nr = inr.ord_id 
										where a.ld_jb_nr >'"""+cnsmptn_btch_id+"""') adt 
										LEFT JOIN """+dbNameCnsmp+""".eap_config_tbl b 
										ON  adt.mgmt_grphy_unt_cd = b.in_put 
										LEFT JOIN (SELECT DISTINCT cst_cntr_cd, prnt_cst_cntr_cd 
										FROM  """+dbNameOthr+""".cst_cntr_grp_hrchy WHERE prnt_cst_cntr_cd LIKE 'FO%') c 
										ON adt.cst_cntr_cd = c.cst_cntr_cd 
										left outer join (select distinct gnrl_ldgr_acct_nr, grp_acct_nr from """+dbNameOthr+""".gnrl_ldgr_acct_dmnsn where chrt_of_accts_cd = 'WW00') gla_master
										on adt.acct_nr = gla_master.gnrl_ldgr_acct_nr """)

							  transformedDF.repartition(10).write.mode("append").format("orc").insertInto(dbNameCnsmp + ".e2emonitoring_fin_gl_itm_aud_trsn")

								logger.info("******************* e2emonitoring_fin_gl_itm_aud_trsn load completed ************************************")
 								
								transformedDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

								transformedDF.repartition(10)

								//tgt_count = transformedDF.count().toInt
								
								tgt_count = spark.sql(s"select * from ${dbNameCnsmp}.e2emonitoring_fin_gl_itm_aud_trsn where ld_jb_nr >'${cnsmptn_btch_id}'").count.toInt 
								
								src_count = tgt_count

								transformedDF.unpersist()
						
								auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobStatusCode("success")
								auditObj.setAudSrcRowCount(src_count)
								auditObj.setAudTgtRowCount(tgt_count)
								auditObj.setAudErrorRecords(0)
								auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
								auditObj.setFlNm("")
								auditObj.setSysBtchNr(ld_jb_nr)
								auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
								Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
              
								logger.info("******************* e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact Table load Started ************************************")

								cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, "e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact",auditTbl) 

								logger.info("e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact cnsmptn_btch_id :-"+cnsmptn_btch_id)

								auditObj.setAudBatchId(ref_btch_id)
								auditObj.setAudDataLayerName("ref_cnsmptn")
								auditObj.setAudApplicationName("e2emonitoring_gl_Aud_EAP_Recon")
								auditObj.setAudObjectName("e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact")
								src_count = 0
								tgt_count = 0

								transformedDF  = spark.sql(s"""select concat(`gl`.`gnrl_ldgr_acctng_cd`,'|',`gl`.`entrs_lgl_ent_ldgr_cd`,'|',`gl`.`fscl_yr_nr`,'|',`gl`.`pstg_prd_nr`,'|',`gl`.`acctng_dcmt_id`,'|',`gl`.`pstg_itm_ldgr_cd`) as `obj_id`                                                                                                                                                                                                                                                                    
										,`gl`.`gnrl_ldgr_acctng_cd`                                                                                                                                                                                                                                                                                     
										,`gl`.`fscl_yr_nr`                                                                                                                                                                                                                                                                                              
										,`gl`.`pstg_prd_nr`                                                                                                                                                                                                                                                                                             
										,`gl`.`entrs_lgl_ent_ldgr_cd`                                                                                                                                                                                                                                                                                   
										,`gl`.`acctng_dcmt_id`                                                                                                                                                                                                                                                                                          
										,`gl`.`pstg_itm_ldgr_cd`                                                                                                                                                                                                                                                                                        
										,`gl`.`dcmt_pstg_dt`                                                                                                                                                                                                                                                                                            
										,`gl`.`dbt_crdt_ind`                                                                                                                                                                                                                                                                                            
										,`gl`.`dcmt_typ_cd`                                                                                                                                                                                                                                                                                             
										,crc32(concat(COALESCE(upper(`gl`.`pft_cntr_cd`),""))) as `pft_cntr_ky`                                                                                                                                                                                                                                         
										,crc32((COALESCE(upper(`gl`.`mgmt_grphy_unt_cd`)))) as `mgmt_grphy_unt_ky`                                                                                                                                                                                                                                      
										,crc32((COALESCE(upper(`gl`.`acct_nr`))))  as `gl_account_ky`                                                                                                                                                                                                                                                   
										,`gl`.`acct_nr`                                                                                                                                                                                                                                                                                                 
										,`gl`.`grp_acct_nr`                                                                                                                                                                                                                                                                                             
										,`gl`.`fnctl_ar_cd`                                                                                                                                                                                                                                                                                             
										,crc32(concat(COALESCE(upper(`gl`.`cst_cntr_cd`),""))) as `cst_cntr_ky`                                                                                                                                                                                                                                         
										,`gl`.`ord_nr`                                                                                                                                                                                                                                                                                                  
										,`gl`.`sndr_cst_cntr_cd`                                                                                                                                                                                                                                                                                        
										,"" as `clarg_dcmt_nr`                                                                                                                                                                                                                                                                                           
										,`gl`.`clarg_dt`                                                                                                                                                                                                                                                                                                
										,`gl`.`tc_cd`                                                                                                                                                                                                                                                                                                   
										,`gl`.`tc_amt`                                                                                                                                                                                                                                                                                                  
										,`gl`.`co_curr_cd`                                                                                                                                                                                                                                                                                              
										,`gl`.`co_cd_curr_amt`                                                                                                                                                                                                                                                                                          
										,`gl`.`gbl_curr_cd`                                                                                                                                                                                                                                                                                             
										,`gl`.`gbl_curr_amt`                                                                                                                                                                                                                                                                                            
										,`gl`.`cst_cntr_cd_calc` as `cst_cntr_cd`                                                                                                                                                                                                                                                                       
										,`gl`.`fin_own_cd`                                                                                                                                                                                                                                                                                              
										,"S4" as `eap_layer`                                                                                                                                                                                                                                                                                            
										,`gl`.`ld_jb_nr`
										,to_date(`gl`.`utc_ts`) as `doc_crt_dt`                                                                                                                                                                                                                                                                                             
										from                                                                                                                                                                                                                                                                                                            
										`ea_fin`.`e2emonitoring_fin_gl_itm_aud_trsn` `gl` where to_date(`gl`.`utc_ts`)>=date_sub(to_date(current_timestamp()),"""+reprocessDays+""")                                                                                                                                                                                                                                                 
										UNION ALL                                                                                                                                                                                                                                                                                                       
										select concat(`gnlr_ldgr_fact`.`gnrl_ldgr_acctng_cd`,'|',`gnlr_ldgr_fact`.`entrs_lgl_ent_ldgr_cd`,'|',`gnlr_ldgr_fact`.`fscl_yr_nr`,'|',`gnlr_ldgr_fact`.`pstg_prd_nr`,'|',`gnlr_ldgr_fact`.`acctng_dcmt_id`,'|',`gnlr_ldgr_fact`.`pstg_itm_ldgr_cd`) as `obj_id`                                                                                                                                                                                                                                                  
										,`gnlr_ldgr_fact`.`gnrl_ldgr_acctng_cd`                                                                                                                                                                                                                                                                  
										,`gnlr_ldgr_fact`.`fscl_yr_nr`                                                                                                                                                                                                                                                                           
										,`gnlr_ldgr_fact`.`pstg_prd_nr`                                                                                                                                                                                                                                                                          
										,`gnlr_ldgr_fact`.`entrs_lgl_ent_ldgr_cd`                                                                                                                                                                                                                                                                
										,`gnlr_ldgr_fact`.`acctng_dcmt_id`                                                                                                                                                                                                                                                                       
										,`gnlr_ldgr_fact`.`pstg_itm_ldgr_cd`                                                                                                                                                                                                                                                                     
										,`gnlr_ldgr_fact`.`dcmt_pstg_dt`                                                                                                                                                                                                                                                                         
										,`gnlr_ldgr_fact`.`dbt_crdt_ind`                                                                                                                                                                                                                                                                         
										,`gnlr_ldgr_fact`.`dcmt_typ_cd`                                                                                                                                                                                                                                                                          
										,crc32((COALESCE(upper(`gnlr_ldgr_fact`.`pft_cntr_cd`)))) as `pft_cntr_ky`                                                                                                                                                                                                                               
										,crc32((COALESCE(upper(`gnlr_ldgr_fact`.`mgmt_grphy_unt_cd`)))) as `mgmt_grphy_unt_ky`                                                                                                                                                                                                                   
										,crc32((COALESCE(upper(`gnlr_ldgr_fact`.`acct_nr`))))  as `gl_account_ky`                                                                                                                                                                                                                                
										,`gnlr_ldgr_fact`.`acct_nr`                                                                                                                                                                                                                                                                              
										,`gnlr_ldgr_fact`.`grp_acct_nr`                                                                                                                                                                                                                                                                          
										,`gnlr_ldgr_fact`.`fnctl_ar_cd`                                                                                                                                                                                                                                                                          
										,crc32(concat(COALESCE(upper(`gnlr_ldgr_fact`.`cst_cntr_cd`),""))) as `cst_cntr_ky`                                                                                                                                                                                                                      
										,`gnlr_ldgr_fact`.`ord_nr`                                                                                                                                                                                                                                                                               
										--,`gnlr_ldgr_fact`.`sndr_cst_cntr_cd` 
										,"" as  sndr_cst_cntr_cd
										,`gnlr_ldgr_fact`.`clarg_dcmt_nr`                                                                                                                                                                                                                                                                        
										,`gnlr_ldgr_fact`.`clarg_dt`                                                                                                                                                                                                                                                                             
										,`gnlr_ldgr_fact`.`tc_cd`                                                                                                                                                                                                                                                                                
										,`gnlr_ldgr_fact`.`tc_amt`                                                                                                                                                                                                                                                                               
										,`gnlr_ldgr_fact`.`co_curr_cd`                                                                                                                                                                                                                                                                           
										,`gnlr_ldgr_fact`.`co_cd_curr_amt`                                                                                                                                                                                                                                                                       
										,`gnlr_ldgr_fact`.`gbl_curr_cd`                                                                                                                                                                                                                                                                          
										,`gnlr_ldgr_fact`.`gbl_curr_amt`                                                                                                                                                                                                                                                                         
										,`gnlr_ldgr_fact`.`cst_cntr_cd`                                                                                                                                                                                                                                                                          
										,`gnlr_ldgr_fact`.`fin_own_cd`                                                                                                                                                                                                                                                                           
										,"SERV" as `eap_layer`                                                                                                                                                                                                                                                                                          
										,`gnlr_ldgr_fact`.`ld_jb_nr`
										,to_date(`gnlr_ldgr_fact`.`utc_ts`) as `doc_crt_dt`                                                                                                                                                                                                                                                                              
										from                                                                                                                                                                                                                                                                                                            
										`ea_fin`.`gnlr_ldgr_fact` where to_date(`gnlr_ldgr_fact`.`utc_ts`) >=date_sub(to_date(current_timestamp()),"""+reprocessDays+""")""")						
								
								transformedDF.repartition(25).write.mode("overwrite").format("orc").insertInto(dbNameCnsmp + ".e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact")

								logger.info("******************* e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact load completed ************************************")
 								
								transformedDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

								transformedDF.repartition(10)

								//tgt_count = transformedDF.count().toInt
								
								tgt_count = spark.sql(s"select * from ${dbNameCnsmp}.e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact where where doc_crt_dt>=date_sub(to_date(current_timestamp()),${reprocessDays})").count.toInt 
								
								src_count = tgt_count

								transformedDF.unpersist()
						
								auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobStatusCode("success")
								auditObj.setAudSrcRowCount(src_count)
								auditObj.setAudTgtRowCount(tgt_count)
								auditObj.setAudErrorRecords(0)
								auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
								auditObj.setFlNm("")
								auditObj.setSysBtchNr(ld_jb_nr)
								auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
								Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
								
								logger.info("******************* e2emonitoring_fin_gl_itm_attrbt_rcn_dtl Table load Started ************************************")

								auditObj.setAudBatchId(ref_btch_id)
								auditObj.setAudDataLayerName("ref_cnsmptn")
								auditObj.setAudApplicationName("e2emonitoring_gl_Aud_EAP_Recon")
								auditObj.setAudObjectName("e2emonitoring_fin_gl_itm_attrbt_rcn_dtl")
								src_count = 0
								tgt_count = 0

								transformedDF  = spark.sql(s"""select distinct 
										"Attribute data mismatch" as dlta_typ
										,S4.obj_id                as obj_id
										,S4.gnrl_ldgr_acctng_cd   as gnrl_ldgr_acctng_cd
										,S4.entrs_lgl_ent_ldgr_cd as entrs_lgl_ent_ldgr_cd 
										,S4.acctng_dcmt_id        as acctng_dcmt_id
										,S4.fscl_yr_nr            as fscl_yr_nr
										,S4.pstg_prd_nr           as pstg_prd_nr
										,S4.pft_cntr_ky           as pft_cntr_ky       
										,S4.mgmt_grphy_unt_ky     as mgmt_grphy_unt_ky 
										,case when S4.dcmt_pstg_dt     = EAP.dcmt_pstg_dt      then concat(S4.dcmt_pstg_dt,"|",EAP.dcmt_pstg_dt,"|Matched")          else concat(S4.dcmt_pstg_dt,"|",EAP.dcmt_pstg_dt,"|MisMatch")         end as dcmt_pstg_dt      
										,case when S4.dbt_crdt_ind     = EAP.dbt_crdt_ind      then concat(S4.dbt_crdt_ind,"|",EAP.dbt_crdt_ind,"|Matched")          else concat(S4.dbt_crdt_ind,"|",EAP.dbt_crdt_ind,"|MisMatch")         end as dbt_crdt_ind       
										,case when S4.dcmt_typ_cd      = EAP.dcmt_typ_cd       then concat(S4.dcmt_typ_cd,"|",EAP.dcmt_typ_cd,"|Matched")            else concat(S4.dcmt_typ_cd,"|",EAP.dcmt_typ_cd,"|MisMatch")           end as dcmt_typ_cd       
										,case when S4.gl_account_ky    = EAP.gl_account_ky     then concat(S4.gl_account_ky,"|",EAP.gl_account_ky,"|Matched")        else concat(S4.gl_account_ky,"|",EAP.gl_account_ky,"|MisMatch")       end as gl_account_ky   
										,case when S4.acct_nr          = EAP.acct_nr           then concat(S4.acct_nr,"|",EAP.acct_nr,"|Matched")                    else concat(S4.acct_nr,"|",EAP.acct_nr,"|MisMatch")                   end as acct_nr
										,case when S4.grp_acct_nr      = EAP.grp_acct_nr       then concat(S4.grp_acct_nr,"|",EAP.grp_acct_nr,"|Matched")            else concat(S4.grp_acct_nr,"|",EAP.grp_acct_nr,"|MisMatch")           end as grp_acct_nr 
										,case when S4.fnctl_ar_cd      = EAP.fnctl_ar_cd       then concat(S4.fnctl_ar_cd,"|",EAP.fnctl_ar_cd,"|Matched")            else concat(S4.fnctl_ar_cd,"|",EAP.fnctl_ar_cd,"|MisMatch")           end as fnctl_ar_cd       
										,case when S4.cst_cntr_ky      = EAP.cst_cntr_ky       then concat(S4.cst_cntr_ky,"|",EAP.cst_cntr_ky,"|Matched")            else concat(S4.cst_cntr_ky,"|",EAP.cst_cntr_ky,"|MisMatch")           end as cst_cntr_ky       
										,case when S4.ord_nr           = EAP.ord_nr            then concat(S4.ord_nr,"|",EAP.ord_nr,"|Matched")                      else concat(S4.ord_nr,"|",EAP.ord_nr,"|MisMatch")                     end as ord_nr            
										,case when S4.sndr_cst_cntr_cd = EAP.sndr_cst_cntr_cd  then concat(S4.sndr_cst_cntr_cd,"|",EAP.sndr_cst_cntr_cd,"|Matched")  else concat(S4.sndr_cst_cntr_cd,"|",EAP.sndr_cst_cntr_cd,"|MisMatch") end as sndr_cst_cntr_cd  
										,case when S4.clarg_dcmt_nr    = EAP.clarg_dcmt_nr     then concat(S4.clarg_dcmt_nr,"|",EAP.clarg_dcmt_nr,"|Matched")        else concat(S4.clarg_dcmt_nr,"|",EAP.clarg_dcmt_nr,"|MisMatch")       end as clarg_dcmt_nr     
										,case when COALESCE(S4.clarg_dt,"") = COALESCE(EAP.clarg_dt,"") then concat(COALESCE(S4.clarg_dt,""),"|",COALESCE(EAP.clarg_dt,""),"|Matched") else concat(COALESCE(S4.clarg_dt,""),"|",COALESCE(EAP.clarg_dt,""),"|MisMatch")                 end as clarg_dt          
										,case when S4.tc_cd            = EAP.tc_cd             then concat(S4.tc_cd,"|",EAP.tc_cd,"|Matched")                        else concat(S4.tc_cd,"|",EAP.tc_cd,"|MisMatch")                       end as tc_cd             
										,case when S4.tc_amt           = EAP.tc_amt            then concat(S4.tc_amt,"|",EAP.tc_amt,"|Matched")                      else concat(S4.tc_amt,"|",EAP.tc_amt,"|MisMatch")                     end as tc_amt            
										,case when S4.co_curr_cd       = EAP.co_curr_cd        then concat(S4.co_curr_cd,"|",EAP.co_curr_cd,"|Matched")              else concat(S4.co_curr_cd,"|",EAP.co_curr_cd,"|MisMatch")             end as co_curr_cd        
										,case when S4.co_cd_curr_amt   = EAP.co_cd_curr_amt    then concat(S4.co_cd_curr_amt,"|",EAP.co_cd_curr_amt,"|Matched")      else concat(S4.co_cd_curr_amt,"|",EAP.co_cd_curr_amt,"|MisMatch")     end as co_cd_curr_amt    
										,case when S4.gbl_curr_cd      = EAP.gbl_curr_cd       then concat(S4.gbl_curr_cd,"|",EAP.gbl_curr_cd,"|Matched")            else concat(S4.gbl_curr_cd,"|",EAP.gbl_curr_cd,"|MisMatch")           end as gbl_curr_cd       
										,case when S4.gbl_curr_amt     = EAP.gbl_curr_amt      then concat(S4.gbl_curr_amt,"|",EAP.gbl_curr_amt,"|Matched")          else concat(S4.gbl_curr_amt,"|",EAP.gbl_curr_amt,"|MisMatch")         end as gbl_curr_amt      
										,case when S4.cst_cntr_cd      = EAP.cst_cntr_cd       then concat(S4.cst_cntr_cd,"|",EAP.cst_cntr_cd,"|Matched")            else concat(S4.cst_cntr_cd,"|",EAP.cst_cntr_cd,"|MisMatch")           end as cst_cntr_cd       
										,case when S4.fin_own_cd       = EAP.fin_own_cd        then concat(S4.fin_own_cd,"|",EAP.fin_own_cd,"|Matched")              else concat(S4.fin_own_cd,"|",EAP.fin_own_cd,"|MisMatch")             end as fin_own_cd
										,S4.doc_crt_dt                 as doc_crt_dt
										from 
										(select distinct a.* from """+dbNameCnsmp+""".e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact a where eap_layer = "S4" and a.doc_crt_dt>=date_sub(to_date(current_timestamp()),"""+reprocessDays+""")) S4
										inner join 
										(select distinct b.* from """+dbNameCnsmp+""".e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact b where eap_layer="SERV" and b.doc_crt_dt>=date_sub(to_date(current_timestamp()),"""+reprocessDays+""")) EAP
										on 
										EAP.obj_id = S4.obj_id and 
										EAP.doc_crt_dt = S4.doc_crt_dt """)

								transformedDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameCnsmp + ".e2emonitoring_fin_gl_itm_attrbt_rcn_dtl")

								transformedDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
								
								transformedDF.repartition(10)

								//tgt_count = transformedDF.count().toInt
								
								tgt_count = spark.sql(s"select * from ${dbNameCnsmp}.e2emonitoring_fin_gl_itm_attrbt_rcn_dtl where doc_crt_dt>=date_sub(to_date(current_timestamp()),${reprocessDays})").count.toInt
								
								src_count = tgt_count

								transformedDF.unpersist()

								logger.info("******************* e2emonitoring_fin_gl_itm_attrbt_rcn_dtl load completed ************************************")    

								auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobStatusCode("success")
								auditObj.setAudSrcRowCount(src_count)
								auditObj.setAudTgtRowCount(tgt_count)
								auditObj.setAudErrorRecords(0)
								auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
								auditObj.setFlNm("")
								auditObj.setSysBtchNr(ld_jb_nr)
								auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
								Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)    

								logger.info("******************* gnrl_ldgr_ln_itm_recon_summary_fact Table load Started ************************************")

								auditObj.setAudBatchId(ref_btch_id)
								auditObj.setAudDataLayerName("ref_cnsmptn")
								auditObj.setAudApplicationName("e2emonitoring_gl_Aud_EAP_Recon")
								auditObj.setAudObjectName("e2emonitoring_fin_gl_itm_recon_summary_fact")
								src_count = 0
								tgt_count = 0

								transformedDF  = spark.sql(s"""select                                        
										rcn.entrs_lgl_ent_ldgr_cd,
										NVL(sum(`rcn`.`s4_object_count`),0) as `doc_rcvd_cnt`,                                                                               
										NVL(sum(`rcn`.`serv_object_count`),0) as `doc_snt_cnt`,
										NVL(sum(`rcn`.`serv_object_count`),0) - NVL(sum(`rcn`.`s4_object_count`),0)  as `doc_msng_cnt`,
										NVL(sum(`rcn`.`s4_gbl_curr_amt`),0)  as `gbl_curr_amt_rcvd`,                                                                               
										NVL(sum(`rcn`.`serv_gbl_curr_amt`),0) as `gbl_curr_amt_snt`,
										NVL(sum(`rcn`.`s4_gbl_curr_amt`),0)  - NVL(sum(`rcn`.`serv_gbl_curr_amt`),0) as `gbl_curr_amt_dffrnc`,
										`rcn`.`doc_crt_dt` as doc_crt_dt
										from(
										select a.entrs_lgl_ent_ldgr_cd, a.doc_crt_dt,
										case when `a`.`eap_layer`="S4" then count(distinct `a`.`obj_id`) end as `s4_object_count`,
										case when `a`.`eap_layer`="SERV" then count(distinct `a`.`obj_id`) end as `serv_object_count`,
										case when `a`.`eap_layer`="S4" then cast(NVL(sum(a.gbl_curr_amt),0) as decimal(22,3)) end as s4_gbl_curr_amt,
										case when `a`.`eap_layer`="SERV" then cast(NVL(sum(a.gbl_curr_amt),0) as decimal(22,3)) end as serv_gbl_curr_amt
										from """+dbNameCnsmp+""".e2emonitoring_fin_gl_itm_aud_EAP_recon_trsn_vw_fact a 
										where doc_crt_dt >= date_sub(to_date(current_timestamp()),"""+reprocessDays+""") 
										group by `a`.`doc_crt_dt`,`a`.`eap_layer`,a.entrs_lgl_ent_ldgr_cd ) rcn
										group by rcn.doc_crt_dt,rcn.entrs_lgl_ent_ldgr_cd""")       

								transformedDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameCnsmp + ".gnrl_ldgr_ln_itm_recon_summary_fact")

								transformedDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

								transformedDF.repartition(10)

								//tgt_count = transformedDF.count().toInt
								
								tgt_count = spark.sql(s"select * from ${dbNameCnsmp}.gnrl_ldgr_ln_itm_recon_summary_fact where doc_crt_dt>=date_sub(to_date(current_timestamp()),${reprocessDays})").count.toInt
								
								src_count = tgt_count

								transformedDF.unpersist()

								logger.info("******************* gnrl_ldgr_ln_itm_recon_summary_fact load completed ************************************")    
                
								auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobStatusCode("success")
								auditObj.setAudSrcRowCount(src_count)
								auditObj.setAudTgtRowCount(tgt_count)
								auditObj.setAudErrorRecords(0)
								auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
								auditObj.setFlNm("")
								auditObj.setSysBtchNr(ld_jb_nr)
								auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
								Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)  
								
								logger.info("******************* gnrl_ldgr_ln_itm_attr_recon_summary_fact Table load Started ************************************")

								auditObj.setAudBatchId(ref_btch_id)
								auditObj.setAudDataLayerName("ref_cnsmptn")
								auditObj.setAudApplicationName("e2emonitoring_gl_Aud_EAP_Recon")
								auditObj.setAudObjectName("e2emonitoring_fin_gl_itm_attr_recon_summary_fact")
								src_count = 0
								tgt_count = 0

								transformedDF  = spark.sql(s"""select                                        
								rcn.entrs_lgl_ent_ldgr_cd,
								NVL(sum(`rcn`.`EAP_msng_rec_count`),0) as `EAP_msng_rec_count`,
								NVL(sum(`rcn`.`S4_msng_rec_count`),0) as `S4_msng_rec_count`,                                                                               
								NVL(sum(`rcn`.`Atrbt_msmtch_rec_cnt`),0)  as `Atrbt_msmtch_rec_cnt`,
								`rcn`.`doc_crt_dt` as doc_crt_dt
								from(
								select a.entrs_lgl_ent_ldgr_cd, a.doc_crt_dt,
								case when `a`.`dlta_typ`="EAP missing data" then count(distinct `a`.`obj_id`) end as        `EAP_msng_rec_count`,
								case when `a`.`dlta_typ`="S4 Audit missing data" then count(distinct `a`.`obj_id`) end as   `S4_msng_rec_count`,
								case when `a`.`dlta_typ`="Attribute data mismatch" then count(distinct `a`.`obj_id`) end as `Atrbt_msmtch_rec_cnt`
								from """+dbNameCnsmp+""".gnrl_ldgr_ln_itm_recon_detailed_vw a 
								where doc_crt_dt >= date_sub(to_date(current_timestamp()),"""+reprocessDays+""")
								group by `a`.`doc_crt_dt`,`a`.`dlta_typ`,a.entrs_lgl_ent_ldgr_cd ) rcn
								group by rcn.doc_crt_dt,rcn.entrs_lgl_ent_ldgr_cd""")

								transformedDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameCnsmp + ".gnrl_ldgr_ln_itm_attr_recon_summary_fact")

								transformedDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

								transformedDF.repartition(10)

								//tgt_count = transformedDF.count().toInt
								
								tgt_count = spark.sql(s"select * from ${dbNameCnsmp}.gnrl_ldgr_ln_itm_attr_recon_summary_fact where doc_crt_dt>=date_sub(to_date(current_timestamp()),${reprocessDays})").count.toInt
								
								src_count = tgt_count

								transformedDF.unpersist()

								logger.info("******************* gnrl_ldgr_ln_itm_attr_recon_summary_fact Table load completed ************************************")    

								auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobStatusCode("success")
								auditObj.setAudSrcRowCount(src_count)
								auditObj.setAudTgtRowCount(tgt_count)
								auditObj.setAudErrorRecords(0)
								auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
								auditObj.setFlNm("")
								auditObj.setSysBtchNr(ld_jb_nr)
								auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
								auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
								Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)  
							}
				 else{
								logger.warn("No New record loaded in the ingestion table !")
								auditObj.setAudJobStatusCode("success")
								auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
								auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
								Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)						  
							}
					}
				catch{
				case sslException: InterruptedException => {
					logger.error("Interrupted Exception")
					auditObj.setAudJobStatusCode("failed")
					auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
					auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
					Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
				}
				case nseException: NoSuchElementException => {
					logger.error("No Such element found: " + nseException.printStackTrace())
					auditObj.setAudJobStatusCode("failed")
					auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
					auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
					Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

				}
				case anaException: AnalysisException => {
					logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
					auditObj.setAudJobStatusCode("failed")
					auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
					auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
					Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

				}
				case connException: ConnectException => {
					logger.error("Connection Exception: " + connException.printStackTrace())
					auditObj.setAudJobStatusCode("failed")
					auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
					auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
					Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

				} case illegalArgs: IllegalArgumentException => {
					logger.error("Connection Exception: " + illegalArgs.printStackTrace())     
					auditObj.setAudJobStatusCode("failed")
					auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
					auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
					Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

				}
				case allException: Exception => {
					logger.error("Connection Exception: " + allException.printStackTrace())
					auditObj.setAudJobStatusCode("failed")
					auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
					auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
					Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

				}    

				} finally {
					logger.info("//*********************** Log End for Gl Recon between S4 and EAP ************************//")
					sqlCon.close()
					spark.close()
				}
}
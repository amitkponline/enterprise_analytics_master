package com.hpe.batch.driver.facts.expenses

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import org.apache.spark.storage.StorageLevel
import scala.io.Source
import scala.util.control.Breaks._
import scala.collection.breakOut

object ExpenseFact extends App {
  
val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  //val fileBasePath = propertiesObject.getFileBasePath()

  try {
    logger.info("Initializing log for EXPENSE FACT, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    val consmptnTable = new StringBuilder()
    val dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()
    val dbName_common = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
      dbName_common.append(propertiesObject.getDbName().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

    //Calculating Max Insert timestamp for each table source
    val srcCount = spark.sql("select count(*) from " + srcTable).first().getLong(0)
    val gl_max_dt = spark.sql("""select coalesce(FROM_UNIXTIME(unix_timestamp(max(ins_ts))  ,'yyyy-MM-dd HH:mm:ss.0'),'1900-01-01 00:00:00') as max_ld_ts from """ + dbNameConsmtn + """.""" + consmptnTable + """ where upper(table_src) = 'GL LINE ITEM TRANSACTION'""").first.getString(0)
    val gl_consol_max_dt = spark.sql("""select coalesce(FROM_UNIXTIME(unix_timestamp(max(ins_gmt_ts)) ,'yyyy-MM-dd HH:mm:ss.0'),'1900-01-01 00:00:00') as max_ld_ts from """ + dbNameConsmtn + """.""" + consmptnTable + """ where upper(table_src) = 'GL CONSOLIDATION TRANSACTION'""").first.getString(0)
    val open_req_max_dt = spark.sql("""select coalesce(FROM_UNIXTIME(unix_timestamp(max(ins_ts)) ,'yyyy-MM-dd HH:mm:ss.0'),'1900-01-01 00:00:00') as max_ld_ts from """ + dbNameConsmtn + """.""" + consmptnTable + """ where upper(table_src) = 'OPEN REQUISTION'""").first.getString(0)
    val head_max_dt = spark.sql("""select coalesce(FROM_UNIXTIME(unix_timestamp(max(ins_ts)),'yyyy-MM-dd HH:mm:ss.0'),'1900-01-01 00:00:00') as max_ld_ts from """ + dbNameConsmtn + """.""" + consmptnTable + """ where upper(table_src) = 'HEADCOUNT INFORMATION'""").first.getString(0)
    val fsclYr = spark.sql("select CAST(fisc_yr_nr AS INT) from ea_common.clndr_rpt where cldr_dt=to_date(current_timestamp)").first().getInt(0)
    val prdNr=spark.sql("select  CAST( SUBSTR(fisc_yr_mth_cd,5,2) AS INT) from ea_common.clndr_rpt where cldr_dt=to_date(current_timestamp)").first().getInt(0)
    val data_history_check = if ((gl_max_dt == "1900-01-01 00:00:00") && (gl_consol_max_dt == "1900-01-01 00:00:00") && (open_req_max_dt == "1900-01-01 00:00:00") && (head_max_dt == "1900-01-01 00:00:00")) true else false

    var previous_list:List[String] = List()
    var current_list:List[String] = List()
    
    if (prdNr <= 2 ){
      val previousyr = fsclYr - 1
      previous_list = List(previousyr.toString+12,previousyr.toString+13,previousyr.toString+14)
      if (prdNr == 1) current_list = List(fsclYr.toString+(prdNr-1),fsclYr.toString+prdNr) 
      else if (prdNr == 2) current_list = List(fsclYr.toString+(prdNr-2),fsclYr.toString+(prdNr-1),fsclYr.toString+prdNr)
      //else if (prdNr == 2) current_list = List(fsclYr.toString+(prdNr-2),fsclYr.toString+(prdNr-1),fsclYr.toString+prdNr)
      else 0
    }else current_list = List(fsclYr.toString+(prdNr-2),fsclYr.toString+(prdNr-1),fsclYr.toString+prdNr)
    
    val finalList = previous_list ::: current_list
    val partition_nr=finalList.mkString(",")
    
    //Incremental for GL
    val gnrl_ldgr_join = spark.sql("""select
concat_ws(lower(trim(coalesce(a.gnrl_ldgr_acctng_cd,''))),lower(trim(coalesce(a.entrs_lgl_ent_ldgr_cd,''))),lower(trim(coalesce(a.fscl_yr_nr,''))),lower(trim(coalesce(a.acctng_dcmt_id,''))),lower(trim(coalesce(a.pstg_itm_ldgr_cd,'')))) AS expense_fact_ky 
 ,crc32(lower(trim(coalesce(gla.grp_acct_nr,'')))) as grp_acct_nr_ky 
,crc32(lower(trim(coalesce(a.entrs_lgl_ent_ldgr_cd,'')))) as entrs_lgl_ent_ldgr_cd_ky
,crc32(lower(trim(coalesce(a.acct_nr,'')))) as acct_nr_ky 
,crc32(lower(trim(coalesce(a.cst_cntr_cd,'')))) as cst_cntr_cd_ky
,crc32(lower(trim(coalesce(a.pft_cntr_cd,'')))) as pft_cntr_cd_ky
,crc32(lower(trim(coalesce(a.fnctl_ar_cd,'')))) as fnctl_ar_cd_ky
,crc32(lower(trim(coalesce(a.bsn_ar_cd,'')))) as bsn_ar_cd_ky 
,crc32(lower(trim(coalesce(a.ctrlng_ar_cd,'')))) as ctrlng_ar_cd_ky
,crc32(lower(trim(coalesce(a.mgmt_grphy_unt_cd,'')))) as mgmt_grphy_unt_cd_ky                                     
,a.acct_asngmt_cgy_nm
,a.sndr_sys_acct_asngmt_cd
,a.sndr_sys_acct_asngmt_typ_cd
,a.acct_dtrmn_cd
,a.acct_nr
,a.vndr_id
,a.acct_typ_cd
,a.acctng_dcmt_id
,a.acctng_cd
,a.actvy_typ_cd
,a.alt_acct_nr
,a.ctrlng_obj_curr_amt
,a.co_cd_curr_amt
,a.frly_dfnd_curr_1_amt
,a.frly_dfnd_curr_2_amt
,a.frly_dfnd_curr_3_amt
,a.frly_dfnd_curr_4_amt
,a.frly_dfnd_curr_5_amt
,a.frly_dfnd_curr_6_amt
,a.frly_dfnd_curr_7_amt
,a.frly_dfnd_curr_8_amt
,a.gbl_curr_amt
,a.tc_amt
,a.fx_asst_clsfn_cd
,a.asst_sb_nr
,a.asst_trsn_typ
,a.asst_vl_dt
,a.asngmt_nr
,a.bs_unt_of_msr_cd
,a.bsn_ar_cd
,a.bsn_prs_cd
,a.bsn_trsn_typ_cd
,a.rfnc_po_cgy_cd
,a.chrt_of_acct_cd
,a.ctry_lgsn_chrt_of_acct_cd
,a.sys_bsn_trsn_cd
,a.ctrlng_obj_dbt_crdt_ind
,a.ctrlng_obj_sb_nr
,a.ctrlng_obj_qty
,a.entrs_lgl_ent_ldgr_cd
,a.co_curr_cd
,a.sndr_sys_entrs_lgl_ent_ldgr_cd
,a.ptnr_entrs_lgl_ent_ldgr_cd
,a.trdg_ptnr_co_id
,a.ln_itm_cmpltn_ind
,a.ctrlng_ar_cd
,a.cst_cntr_cd
,a.cst_obj_id
,a.cust_nr
,a.srvs_rndrd_dt
,a.dbt_trsn_typ_cd
,a.dbt_crdt_ind
,a.orgn_dbt_crdt_ind
,a.dprc_ar_cd
,a.dbn_rl_grp_cd
,a.dcmt_dt
,a.spcl_fnctn_dcmt_stts_cd
,a.dcmt_typ_cd 
,a.fscl_yr_nr
,a.fscl_yr_vrnt_cd
,a.fllw_on_dcmt_typ_cd
,a.frst_dfnd_curr_cd
,a.scnd_dfnd_curr_cd
,a.thrd_dfnd_curr_cd
,a.frth_dfnd_curr_cd
,a.ffth_dfnd_curr_cd
,a.sxth_dfnd_curr_cd
,a.svnth_dfnd_curr_cd
,a.eght_dfnd_curr_cd
,a.fnctl_ar_cd
,a.sndr_sys_gnrl_ldgr_acct_cd
,a.gnrl_ldgr_fscl_yr_nr
,a.gbl_curr_cd
,a.grp_asst_cd
,a.rvrsd_itm_ind
,a.itm_rvrsng_otr_itm_ind
,a.trnsfrng_itm_ind
,a.trnsfrd_ln_itm_ind
,a.ctrlng_obj_pftblty_sgm_rlvnt_ind
,a.incmplt_qty_ind
,a.tru_rvrsl_ind
,a.itm_cgy_cd
,a.dcmt_splt_itm_chgd_ind
,a.sls_ord_itm_nr
,a.prchg_dcmt_itm_nr
,a.ln_itm_txt
,a.gnrl_ldgr_acctng_cd
,a.ldgr_spcf_acctng_dcmt_nr
,a.lgcl_sys_cd
,a.ptnr_obj_lgcl_sys_cd
,a.prv_rfnc_dcmt_lgcl_sys_cd
,a.src_dcmt_lgcl_sys_cd
,a.mn_asst_nr
,a.ptnr_asst_mn_nr
,a.gds_bsn_actvy_dn
,a.actvy_cd
,a.acct_asngmt_ntwrk_nr
,a.acctng_dcmt_ln_itm_nr
,a.obj_cls_cd
,a.obj_nr
,a.orgn_obj_nr
,a.obj_typ_cd
,a.ofst_acct_nr
,a.ofst_acct_typ_cd
,a.ord_ctg_nr
,a.ord_nr
,a.orgn_actvy_cd
,a.orgn_cst_cntr_cd
,a.cst_elmt_sb_dvsn_orgn_grp_cd
,a.orgn_ord_nr
,a.orgn_pft_cntr_cd
,a.prtl_dcmt_blcd_nr
,a.ptnr_cst_cntr_actvy_cd
,a.ptnr_asst_sb_nr
,a.ptnr_cst_obj_cd
,a.ptnr_fnctl_ar_cd
,a.ptnr_obj_nr
,a.ptnr_obj_cls_cd
,a.ptnr_obj_typ_cd
,a.ptnr_ord_cgy_cd
,a.ptnr_ord_nr
,a.ptnr_pft_cntr_cd
,a.inrn_bsn_elmnt_ptnr_pft_cntr_cd
,a.ptnr_prj_dn
,a.ptnr_mgmt_grphy_unt_cd
,a.ptnr_wbs_elmt_cd
,a.prd_yr_etry_cd
,a.prsnl_nr
,a.plnt_nm
,a.dcmt_pstg_dt
,a.pstg_ky_cd
,a.pstg_prd_nr
,a.dprc_pstg_prd_fscl_yr_nr
,a.prv_dcmt_rfnc_nr
,a.prv_dcmt_rfnc_org_unt_cd
,a.prv_dcmt_rfnc_trsn_cd
,a.prv_prtl_dcmt_blcd_nr
,a.prv_dcmt_rfnc_ln_itm_nr
,a.pft_cntr_cd
,a.pftblty_sgm_nr
,a.prj_dn
,a.prchg_dcmt_nr
,a.msr_qty
,a.rec_typ_cd
,a.rfnc_prcgr_cd
,a.dcmt_blcd_rvrsl_cd
,a.rvrs_rfnc_trsn_dcmt_nr
,a.rvrs_dcmt_rfnc_dcmt_nr
,a.rvrs_dcmt_rfnc_org_cd
,a.scndry_jrnl_etry_ind
,a.mgmt_grphy_unt_cd
,a.sndr_cst_cntr_cd
,a.acct_asngmt_sqnl_nr
,a.pstg_itm_ldgr_cd
,a.actvy_typ_dn
,a.ptnr_src_cd
,a.src_bsn_prs_cd
,a.allctn_prc_dtrmn_cd
,a.ln_itm_pstd_amt
,a.dprc_ar_grp_asst_cd
,a.trdg_ptnr_bsn_ar_cd
,a.trsn_ky_cd
,a.trsn_typ_cd
,a.trsn_typ_ctg_cd
,a.gnrl_ldgr_trsn_typ_cd
,a.gnrl_ldgr_acct_typ_cd
,a.frst_ststcl_acct_asngmt_cd
,a.orgn_obj_typ_cd
,a.usr_nm
,NULL as mdl_vrsn_nr
,NULL as vrsn_id_id
,NULL as zbpc_acdocc_c_1_cd
,NULL as vrnt_cd
,NULL as zbpc_acdocc_cgy_nm
,NULL as RealTime_cnsldtn_dta_cgy_nm
,NULL as zbpc_acdocc_adt_Trail_nm
,NULL as rfnc_acctng_dcmt_nr
,NULL as rfnc_ln_itm
,NULL as zbpc_acdocc_trsn_curr
,NULL as grp_curr
,NULL as unt_msr_co_valtn_qty
,NULL as amt_grp_curr
,a.wrk_itm_id
,a.acctng_dcmt_entrd_dt
,a.dcmt_etry_ts                                     
,a.last_dcmt_chgd_by_trsn_dt                        
,a.last_dcmt_upd_dt                                 
,a.exch_rate_dt                                     
,a.trsn_cd                                          
,a.crss_co_cd_pstg_trsn_nr                          
,a.rfnc_dcmt_nr                                     
,a.rcrrg_etry_dcmt_nr                               
,a.rcrrg_etry_fscl_yr_nr                            
,a.rcrrg_etry_dcmt_co_cd                            
,a.rvrs_dcmt_nr                                     
,a.rvrs_dcmt_fscl_yr_nr                             
,a.dcmt_hdr_txt
,a.sls_ord_nr  
,a.src_sys_upd_ts as gnrl_ldgr_src_sys_upd_ts
,a.src_sys_ky as gnrl_ldgr_
,a.lgcl_dlt_ind as gnrl_ldgr_lgcl_dlt_ind
,a.ins_gmt_ts as ins_gmt_ts 
,a.upd_gmt_ts
,a.src_sys_extrc_gmt_ts
,a.src_sys_btch_nr
,a.fl_nm 
,a.ld_jb_nr   
,a.extract_ts as ins_ts                                     
,gla.grp_acct_nr         
,'GL Line Item Transaction' as table_src
,CASE WHEN (pstg_prd_nr) IN (1,2,3) THEN '1' WHEN (pstg_prd_nr) IN (4,5,6) THEN '2' WHEN (pstg_prd_nr) IN (7,8,9) THEN '3' WHEN (pstg_prd_nr) IN (10,11,12) THEN '4' WHEN (pstg_prd_nr) IN (10,11,12) THEN '4' WHEN (pstg_prd_nr) IN (13,14,15,16) THEN '4' ELSE NULL END as new_qrtr_attrbt
,CASE WHEN (pstg_prd_nr) IN (1,2,3,4,5,6) THEN '1' WHEN (pstg_prd_nr) IN (7,8,9,10,11,12) THEN '2' WHEN (pstg_prd_nr) IN (13,14,15,16) THEN '3' ELSE NULL END as half_yr_attrbt,
 NULL as req_cgy_cd      ,         
 NULL as reqs_nr            ,      
 NULL as fld_1_cd           ,      
 NULL as fld_2_cd           ,      
 NULL as fld_3_cd           ,      
 NULL as fld_4_cd           ,      
 NULL as fld_5_cd           ,      
 NULL as lgcl_del_fg_cd     ,      
 NULL as upd_gmt_ts_cd      ,      
 NULL as ins_gmt_ts_cd      ,      
 NULL as upldd_by_cd        ,      
 NULL as sprn_co_id              ,
 NULL as orig_sprn_co_id         ,                  
 NULL as cst_pool_cd             ,
 NULL as head_ct_type_id         ,
 NULL as fin_own_cd              ,    
 NULL as post_lvl_cd             ,
 NULL as head_ct_nr              ,
 NULL as hdcnt_inf_upd_gmt_ts_cd         ,
 NULL as hdcnt_inf_ins_gmt_ts_cd    ,
 NULL as load_job_nr             ,
 NULL as rec_st_nr               ,
 NULL as post_obj_id  
,b.aprvl_tbl_ky       
,b.acctng_dcmt_nr     
,b.pstg_prd           
,b.dcmt_typ_cd as dcmt_typ_cd_aprvl        
,b.co_cd              
,b.amt_gbl_curr_cd    
,b.dcmt_hdr_txt_cd    
,b.rfnc_dcmt_nr as rfnc_dcmt_nr_aprvl       
,b.rqstr_nm           
,b.prprr_nm           
,b.last_aprvr_nm      
,b.last_aprvr_lvl_cd  
,b.rqst_stts_cd       
,b.ct_own_cd          
,b.ct_own_lvl_cd      
,b.last_stts_dt       
,b.last_stts_tm_cd    
,b.fscl_yr            
,b.src_sys_upd_ts as aprvl_tbl_src_sys_upd_ts     
,b.src_sys_ky         
,b.lgcl_dlt_ind     ,
a.src_dcmt_nr  
,null as dt_ky,
a.tc_cd,
a.ctrlng_obj_curr_cd
FROM """ + dbNameConsmtn + """.gnrl_ldgr_ln_itm_trsn a 
LEFT OUTER JOIN
""" + dbNameConsmtn + """.aprvl_tbl_dmnsn b 
ON
a.acctng_dcmt_id=b.acctng_dcmt_nr AND a.fscl_yr_nr=b.fscl_yr AND a.entrs_lgl_ent_ldgr_cd=b.co_cd
LEFT OUTER JOIN
(select distinct gnrl_ldgr_acct_nr, grp_acct_nr from """ + dbName_common + """.gnrl_ldgr_acct_dmnsn where chrt_of_accts_cd = 'WW00') gla ON 
a.acct_nr = gla.gnrl_ldgr_acct_nr
WHERE concat(a.yr_nr,a.prd_nr) in (""" + partition_nr + """) and a.gnrl_ldgr_acctng_cd ='0L' AND ((trim(a.cst_cntr_cd)<>'' and  a.cst_cntr_cd IS NOT NULL) OR (trim(a.sndr_cst_cntr_cd)<>'' and a.sndr_cst_cntr_cd IS NOT NULL) OR (trim(a.ord_nr)<>'' and a.ord_nr IS NOT NULL)) AND a.extract_ts > '""" + gl_max_dt + """' 
      """)
      
      //concat(a.yr_nr,a.prd_nr) in (""" + partition_nr + """) and
      // AND a.extract_ts > '""" + gl_max_dt + """'

    //Incremental for BPC Data
    val bpc_cnsldtn_trsn = spark.sql("""select
concat_ws(lower(trim(coalesce(mdl_cd,''))),lower(trim(coalesce(zbpc_acdocc_fscl_yr_nr,''))),lower(trim(coalesce(acctng_dcmt_nr,''))),lower(trim(coalesce(zbpc_acdocc_ln_it_2,''))))
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,ZBPC_ACDOCC_zbpc_acdocc_acct_vndr_crdtr_nr
,NULL
,acctng_dcmt_nr
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_amt_co_curr_cd
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_amt_gbl_curr
,zbpc_acdocc_amt_trsn_curr
,NULL
,zbpc_acdocc_asst_Subnumber_nr
,asst_trsn_typ_cd
,NULL
,NULL
,zbpc_acdocc_bs_unt_msr
,zbpc_acdocc_bsn_ar_cd
,NULL
,zbpc_acdocc_bsn_trsn_typ_cd
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_c_1_cd
,zbpc_acdocc_co_curr_cd
,NULL
,zbpc_acdocc_co_ptnr_cd
,zbpc_acdocc_co_id_trdg_ptnr_id
,NULL
,zbpc_acdocc_ctrlng_ar_cd
,zbpc_acdocc_cst_cntr_nm
,NULL
,zbpc_acdocc_cust_nr
,NULL
,NULL
,zbpc_acdocc_DebitCredit_ind_cd
,NULL
,NULL
,NULL
,zbpc_acdocc_dcmt_dcmt_dt
,dcmt_stts_cd
,NULL
,zbpc_acdocc_fscl_yr_nr
,zbpc_acdocc_fscl_yr_vrnt_cd
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_gbl_curr
,grp_asst_nm
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_mn_asst_nr
,NULL
,zbpc_acdocc_mtrl_nr
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_ptnr_fnctl_ar_nm
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_Periodyear_nr
,NULL
,zbpc_acdocc_plnt_cd
,zbpc_acdocc_pstg_dcmt_dt
,pstg_ky_cd
,zbpc_acdocc_pstg_prd_nr
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_prj_dfn_nm
,NULL
,zbpc_acdocc_qty
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_trdg_ptnr_bsn_ar_cd
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,zbpc_acdocc_usr_nm
,mdl_vrsn_nr
,vrsn_id_id
,zbpc_acdocc_c_3_cd
,vrnt_cd
,zbpc_acdocc_cgy_nm
,RealTime_cnsldtn_dta_cgy_nm
,zbpc_acdocc_adt_Trail_nm
,rfnc_acctng_dcmt_nr
,rfnc_ln_itm
,zbpc_acdocc_trsn_curr
,grp_curr
,unt_msr_co_valtn_qty
,amt_grp_curr
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,ins_gmt_ts
,NULL
,NULL
,NULL
,NULL
,NULL
,ins_ts
,grp_acct_nr
,'GL Consolidation Transaction'
,NULL
,NULL,
 NULL,         
 NULL,      
 NULL,      
 NULL,      
 NULL,      
 NULL,      
 NULL,      
 NULL,      
 NULL,      
 NULL,      
 NULL,      
 NULL,
 NULL,                  
 NULL,
 NULL,
 NULL,    
 NULL,
 NULL,
 NULL,
 NULL,
 NULL,
 NULL,
 NULL   
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
 ,null as src_dcmt_nr
,null
,null
,null
FROM
""" + dbNameConsmtn + """.bpc_cnsldtn_trsn
WHERE (zbpc_acdocc_cst_cntr_nm IS NOT NULL OR zbpc_acdocc_sndr_cst_cntr_nm IS NOT NULL) and cnsldtn_grp_1_nm = 'G_HPE' and zbpc_acdocc_trsn_typ_cd = 999 and zbpc_acdocc_adt_Trail_nm not in ('INPUT', 'RECLASS', 'ALLOC_ADJ_HIST')  AND ins_gmt_ts > '""" + gl_consol_max_dt + """'
        """)

    //Incremental for Open Requisition
    val bmt_opn_rqstn_dmnsn = spark.sql("""select
concat_ws(lower(trim(coalesce(cst_obj_cd,''))),lower(trim(coalesce(prd_cd,''))),lower(trim(coalesce(req_cgy_cd,''))))
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,cst_obj_cd
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,cast(substr(prd_cd, 0,4) as BIGINT)
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,cast(substr(prd_cd, 5,2) as BIGINT)
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,ins_gmt_ts
,NULL
,NULL
,NULL
,NULL
,NULL
,ins_ts
,NULL
,'Open Requistion'
,NULL
,NULL,
req_cgy_cd  ,             
 reqs_nr    ,              
 fld_1_cd    ,             
 fld_2_cd    ,             
 fld_3_cd   ,              
 fld_4_cd    ,             
 fld_5_cd    ,             
 lgcl_del_fg_cd ,          
 upd_gmt_ts_cd   ,         
 ins_gmt_ts_cd    ,        
 upldd_by_cd,
NULL,           
NULL,                          
NULL,             
NULL,      
NULL,                    
NULL,            
NULL,            
NULL,         
NULL,          
NULL,           
NULL,            
NULL  
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,null as src_dcmt_nr
,null
,null
,null
FROM
""" + dbName_common + """.bmt_opn_rqstn_dmnsn where ins_ts > '""" + open_req_max_dt + """'
         """)

    //Incremental for Head Count Information
    val bmt_hdcnt_inf_dmnsn = spark.sql("""select 
concat_ws(lower(trim(coalesce(legl_co_cd,''))),lower(trim(coalesce(cst_obj_cd,''))))
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,legl_co_cd
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,cst_obj_cd
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,prft_ctr_cd
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,ins_gmt_ts
,NULL
,NULL
,NULL
,NULL
,NULL
,ins_ts
,NULL
,'HeadCount Information'
,NULL
,NULL
,NULL      
,NULL      
,NULL      
,NULL      
,NULL      
,NULL      
,NULL      
,NULL      
,NULL      
,NULL      
,NULL      
,sprn_co_id          
,orig_sprn_co_id        
,cst_pool_cd     
,head_ct_type_id 
,fin_own_cd        
,post_lvl_cd     
,head_ct_nr      
,upd_gmt_ts_cd as hdcnt_inf_upd_gmt_ts_cd      
,ins_gmt_ts_cd as hdcnt_inf_ins_gmt_ts_cd 
,load_job_nr
,rec_st_nr  
,post_obj_id      
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
,NULL
 ,null as src_dcmt_nr
,dt_ky
,null
,null
FROM """ + dbName_common + """.bmt_hdcnt_inf_dmnsn where ins_ts > '""" + head_max_dt + """'
           """)

    import spark.implicits._
    import org.apache.spark.sql.DataFrame
    import org.apache.spark.sql.SaveMode
    import org.apache.spark.sql.functions._
    //target -> expense_fact
    //fscl_yr_nr  | pstg_prd_nr

    def insert_into_partition(df_inc: DataFrame, table_name: String) {

      val df_his = spark.sql("select * from " + dbNameConsmtn + "." + table_name)
      var df_incremental = df_inc.withColumn("partition_year_month", concat_ws("-", coalesce($"fscl_yr_nr", lit("2019")), coalesce($"pstg_prd_nr", lit("11"))))

      if (data_history_check) {
        if (df_his.count() == 0) {
          df_incremental.repartition(20).write.mode(SaveMode.Append).format("orc").insertInto(dbNameConsmtn + "." + table_name)
          logger.info("CHECK-> historic load completed")
          return
        }
      } else {
        df_incremental = df_incremental.repartition($"expense_fact_ky")//.persist(StorageLevel.MEMORY_AND_DISK_SER)
        //logger.info("CHECK-> Persist final stage inc count " + df_incremental.count())

      }

      val list_of_distinct_his_partition_inc = df_incremental.select("partition_year_month").distinct().collect.map(x => x.getString(0).toString).toList
      logger.info("CHECK-> list of partitions -> " + list_of_distinct_his_partition_inc.mkString(","))

      //Filter data only from list_of_distinct_his_partition and Extracting trsn_id from sn_vw_trsn_id on basis of _
      val df_historical = df_his.filter($"partition_year_month".isin(list_of_distinct_his_partition_inc: _*)).repartition($"expense_fact_ky")

      val df_incremental_key = df_incremental.select("expense_fact_ky").distinct
      
      val df_to_overwite = df_historical.as("his").join(broadcast(df_incremental_key).as("inc"), $"his.expense_fact_ky" === $"inc.expense_fact_ky", "left_anti")

      df_to_overwite.union(df_incremental).coalesce(10).write.mode(SaveMode.Overwrite).format("orc").insertInto(dbNameConsmtn + "." + table_name)
      df_incremental.unpersist()
    }

    val df_inc = gnrl_ldgr_join.union(bpc_cnsldtn_trsn).union(bmt_opn_rqstn_dmnsn).union(bmt_hdcnt_inf_dmnsn)

    var run_status = false
    val inc_count = df_inc.count()
    if (inc_count > 0) {
      run_status = try {
        insert_into_partition(df_inc, consmptnTable.toString())
        true
      } catch {
        case e: Exception => {
          logger.info("CHECK -> " + e.printStackTrace())
          false
        }
      }
    } else {
      logger.info("CHECK -> No incremenetal data")
      run_status = true
    }

    val loadStatus = run_status
    //val srcCount = 0
    val tgtCount = df_inc.count().toLong

    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
      logger.info("Load Successful")
    } else {
      auditObj.setAudJobStatusCode("failed")
      logger.info("Load Failed")
    }
    auditObj.setAudSrcRowCount(srcCount)
    auditObj.setAudTgtRowCount(tgtCount)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      //auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      //auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      // auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      //auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) {
      System.exit(1)
    }

  }
}

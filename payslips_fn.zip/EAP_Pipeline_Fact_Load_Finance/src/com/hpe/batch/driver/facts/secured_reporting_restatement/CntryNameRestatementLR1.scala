package com.hpe.batch.driver.facts.secured_reporting_restatement

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import java.text.SimpleDateFormat

class CntryNameRestatementLR1(auditObj: main.scala.com.hpe.config.AuditLoadObject, propertiesObject: StreamingPropertiesObject, spark: SparkSession, sqlCon: Connection, auditTbl: String, sourceSystem: Array[String], restatementDate: String, snpshtStrtDt: String, snpshtEndDt: String, snpshtNr: String, recepient: String) {

  def sendemail(mailTo: String, mailFrom: String, mailSubject: String, mailContent: String, mailHost: String) = {
    import javax.mail.{ Message, Session, Transport }
    import javax.mail.internet.{ InternetAddress, MimeMessage }
    import java.util.{ HashMap, Properties }
    var properties: Properties = System.getProperties();
    properties.setProperty("mail.smtp.host", mailHost)
    var session: Session = Session.getDefaultInstance(properties)
    var message: MimeMessage = new MimeMessage(session)
    message.setFrom(new InternetAddress(mailFrom))
    var mailrecipient = mailTo.split(",")
    for (mailto <- mailrecipient) {
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailto))
    }
    message.setSubject(mailSubject)
    message.setContent(mailContent, "text/html");
    Transport.send(message)
  }

  def email_content(process: String, srcsys: String, strtDt: String, endDt: String, snpshtNr: String, jobStatus: String, subject: String): String =
    {

      var message = """
      <style>td {border: solid 1px black;}</style>        
      <html>
      <body>
        Hi Team, <br><br>
      <b>Restatement Job Status:</b><br><br>
      <table id="table_id" style="border: 2px; border-collapse: collapse">
      <tr bgcolor=#87CEFA><td>Process Name</td><td>Source System</td><td>Snapshot Start Date</td><td>Snapshot End Date</td><td>Snapshot Nr</td></tr> """
      val consumptionmessage = """<tr><td>""" + process + """</td><td>""" + srcsys + """</td><td>""" + strtDt + """</td><td>""" + endDt + """</td><td>""" + snpshtNr + """</td></tr>"""
      message = message + consumptionmessage + "</table> <br><br> Thanks </body></html>"

      message
    }

  def run() {

    val logger = Logger.getLogger(getClass.getName)
    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    //val startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
    val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
    val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
    val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
    val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
    val apiName = propertiesObject.getApiName()
    val deleteflag = propertiesObject.getDeleteflag()
    val deletetableName = propertiesObject.getDeleteTableName()
    val joinCol = propertiesObject.getDeletejoinCol()
    val dbCommon = propertiesObject.getDbName().split(",")(0)
    val dbFin = propertiesObject.getDbName().split(",")(1)
    
    try {

      // check to see if restatement already happened

      val srcName = sourceSystem.mkString(",")

      val audCheck = spark.sql(s"""
        select 
          * 
        from 
          ${dbCommon}.bmt_restmnt_trigr_audt_dmnsn
        where 
          prcs_nm = 'CTRY-NM-REPROCESS' 
          and src_sys_cd = '${srcName}' 
          and rstmnt_dt = '${restatementDate}' 
          and snpsht_strt_dt = '${snpshtStrtDt}'
          and snpsht_end_dt = '${snpshtEndDt}'
          and snpsht_no = '${snpshtNr}' """).count.toInt

      logger.info("+++++++++++++########## Country Name Restatement")

      logger.info("+++++++++++++########## Source System:" + sourceSystem)

      logger.info("+++++++++++++########## Snapshot Start Date:" + snpshtStrtDt)

      logger.info("+++++++++++++########## Snapshot End Date:" + snpshtEndDt)

      logger.info("+++++++++++++########## Snapshot Number:" + snpshtNr)

      val format = new SimpleDateFormat("yyyy-MM-dd")
      val c = Calendar.getInstance()
      val formattedDate = format.format(c.getTime())

      var subject = "ITG:Secured Reporting Country Name Restatement Start - " + restatementDate

      var message = email_content("Country Name", sourceSystem.mkString(","), snpshtStrtDt, snpshtEndDt, snpshtNr, "start", subject)

      //val formattedDate = "2020-05-20"

      if (audCheck != null && audCheck == 0) {

        if (restatementDate != null && restatementDate == formattedDate) {

          sendemail(recepient, "Restatement_Monitoring@hpe.com", subject, message, "smtp3.hpe.com")

          val bmtcntrynm = spark.sql(s"select * from ${dbCommon}.bmt_cntry_nm_dmnsn order by rl_id asc")

          val bmtcntrynmrefined = bmtcntrynm.withColumn("input_table", when(col("inp_tl") === "NA", col("inp_fld")).
            otherwise(concat(col("inp_tl"), lit("."), col("inp_fld")))).withColumn("output_field", when(col("opt_tbl") === "NA", col("opt_fld")).
            otherwise(concat(col("opt_tbl"), lit("."), col("opt_fld"))))

          val bmtcntrynmds = bmtcntrynmrefined.collect.map(c => " when " + c(19) + " " + c(5) + " (" + c(6) + ") then " + c(20))

          var countryname = "case"

          for (i <- 0 to (bmtcntrynmds.length - 1)) { if (bmtcntrynmds(i).contains("'Unknown GEO'")) countryname += " else 'unkown geo' end" else countryname += bmtcntrynmds(i) }

          logger.info("+++++++######### country name condition: " + countryname)

          val df_secrd_snp_shot_all = spark.sql(s"""select secrd_rpt_snpsht_fact.*,crc32(lower(coalesce(end_cust_cd,""))) as end_cust_ky from ${dbFin}.secrd_rpt_snpsht_fact
                                  left outer join (select *,pch_level_7 as oypl_pch_level_7 from ${dbCommon}.pft_cntr_std_hrchy) pft_cntr_std_hrchy on secrd_rpt_snpsht_fact.prft_cntr_cd = pft_cntr_std_hrchy.pch_level_8
                                  left outer join ${dbCommon}.bmt_sgm_alt_hrchy_dmnsn on secrd_rpt_snpsht_fact.sgmtl_rptg_cd = bmt_sgm_alt_hrchy_dmnsn.sgm_cd
                                  left outer join ${dbCommon}.bmt_pft_cntr_alt_hrchy_dmnsn on secrd_rpt_snpsht_fact.prft_cntr_cd = bmt_pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd
                                  left outer join ${dbCommon}.bmt_cust_alt_hrchy_dmnsn on secrd_rpt_snpsht_fact.cp_end_cust_prty_id = bmt_cust_alt_hrchy_dmnsn.prty_id
        """).filter(col("src_sys_cd").isin(sourceSystem: _*) && col("partition_dt") >= snpshtStrtDt && col("partition_dt") <= snpshtEndDt && col("partition_nr").isin(snpshtNr.split(","): _*))

          //val df_cntry_nm_updated = spark.sql(s"""select distinct cust_alt_hrchy_ky,concat(cust_mppg_23_cd,'-new') as cust_mppg_23_cd from ea_common_r2_2itg.bmt_cust_alt_hrchy_dmnsn""")

          val df_completed_orders = spark.sql(s"""select distinct sls_ord_id,sls_ord_ln_itm_id,partition_dt as partition_dt,partition_nr as part_nr,src_sys_cd,cp_ctry_nm,${countryname} as cp_ctry_nm_updated from ${dbFin}.secrd_rpt_snpsht_fact
                                  left outer join (select *,pch_level_7 as oypl_pch_level_7 from ${dbCommon}.pft_cntr_std_hrchy) pft_cntr_std_hrchy on secrd_rpt_snpsht_fact.prft_cntr_cd = pft_cntr_std_hrchy.pch_level_8
                                  left outer join ${dbCommon}.bmt_sgm_alt_hrchy_dmnsn on secrd_rpt_snpsht_fact.sgmtl_rptg_cd = bmt_sgm_alt_hrchy_dmnsn.sgm_cd
                                  left outer join ${dbCommon}.bmt_pft_cntr_alt_hrchy_dmnsn on secrd_rpt_snpsht_fact.prft_cntr_cd = bmt_pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd
                                  left outer join ${dbCommon}.bmt_cust_alt_hrchy_dmnsn on secrd_rpt_snpsht_fact.cp_end_cust_prty_id = bmt_cust_alt_hrchy_dmnsn.prty_id
                                  """).
            filter(col("src_sys_cd").isin(sourceSystem: _*) && col("partition_dt") >= snpshtStrtDt && col("partition_dt") <= snpshtEndDt && col("part_nr").isin(snpshtNr.split(","): _*))

          val overWriteDatePartition = df_completed_orders.as("cmplt").
            filter(col("cp_ctry_nm") =!= col("cp_ctry_nm_updated") || (col("cp_ctry_nm").isNull && col("cp_ctry_nm_updated").isNotNull)).
            select(col("partition_dt").cast("string")).distinct().collect.map(row => row.getString(0).toString()).toSeq

          val df_updated_orders = df_completed_orders.as("cmplt").
            filter(col("cp_ctry_nm") =!= col("cp_ctry_nm_updated") || (col("cp_ctry_nm").isNull && col("cp_ctry_nm_updated").isNotNull))

          var colList = df_secrd_snp_shot_all.columns.toList

          for (partitionDate <- overWriteDatePartition) {
            for (partNr <- snpshtNr.split(",").toSeq) {

              logger.info("*****************************************processign partitions " + partitionDate + "," + partNr)
              val df_updated_records = df_secrd_snp_shot_all.as("secrd_snp_shot_all").
                filter(col("partition_dt").isin(partitionDate) && col("partition_nr") === partNr).
                join(df_updated_orders.as("cmplt"), col("secrd_snp_shot_all.sls_ord_id") === col("cmplt.sls_ord_id") && col("secrd_snp_shot_all.partition_dt") === col("cmplt.partition_dt") && col("secrd_snp_shot_all.partition_nr") === col("cmplt.part_nr") && col("secrd_snp_shot_all.sls_ord_ln_itm_id") === col("cmplt.sls_ord_ln_itm_id")).drop("cp_ctry_nm").selectExpr("secrd_snp_shot_all.*", "cmplt.cp_ctry_nm_updated as cp_ctry_nm").select(colList.head, colList.tail: _*).repartition(col("secrd_snp_shot_all.sls_ord_id"))

              val df_non_updated_records = df_secrd_snp_shot_all.as("secrd_snp_shot_all").
                filter(col("partition_dt").isin(partitionDate) && col("partition_nr") === partNr).
                join(df_updated_orders.as("cmplt"), col("secrd_snp_shot_all.sls_ord_id") === col("cmplt.sls_ord_id") && col("secrd_snp_shot_all.partition_dt") === col("cmplt.partition_dt") && col("secrd_snp_shot_all.partition_nr") === col("cmplt.part_nr") && col("secrd_snp_shot_all.sls_ord_ln_itm_id") === col("cmplt.sls_ord_ln_itm_id"), "left_anti").selectExpr("secrd_snp_shot_all.*").
                select(colList.head, colList.tail: _*).repartition(col("sls_ord_id"))

              val df_final = df_non_updated_records.union(df_updated_records)

              val tgtColumns = spark.sql(s"select * from ${dbFin}.secrd_rpt_snpsht_fact").columns

              val dataloadDF = df_final.select(Utilities.loadSelectExpr(df_final.columns, tgtColumns): _*)

              dataloadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbFin+".secrd_rpt_snpsht_fact")

              logger.info("************************************************partition overwritten " + partitionDate + "," + partNr)
            }
          }
          
          import spark.implicits._

          val audEntry = Seq(("CTRY-NM-REPROCESS","Y", srcName, restatementDate, snpshtStrtDt, snpshtEndDt, snpshtNr)).toDF()

          audEntry.coalesce(1).write.mode("append").format("orc").insertInto(dbCommon+".bmt_restmnt_trigr_audt_dmnsn")

          // send email
          subject = "PROD:Secured Reporting Country Name Restatement Success - " + restatementDate

          message = email_content("Country Name", sourceSystem.mkString(","), snpshtStrtDt, snpshtEndDt, snpshtNr, "end", subject)

          sendemail(recepient, "Restatement_Monitoring@hpe.com", subject, message, "smtp3.hpe.com")

        } else {
          logger.info("+++++++++++++########## restament process suspended ##########+++++++++++++")
          logger.info("+++++++++++++########## restament date," + restatementDate)
        }
      } else {
        logger.info("+++++++++++++########## restament process already executed ##########+++++++++++++")
        logger.info("+++++++++++++########## restament date," + restatementDate)

      }
    } catch {

      case sslException: InterruptedException => {
        logger.error("Interrupted Exception")
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }
      case connException: ConnectException => {
        logger.error("Connection Exception: " + connException.printStackTrace())
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      } case illegalArgs: IllegalArgumentException => {
        logger.error("Connection Exception: " + illegalArgs.printStackTrace())
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }
      case allException: Exception => {
        logger.error("Connection Exception: " + allException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }
    }

    logger.info("+++++++++++++########## Country Name Restatement Finished")

  }

}
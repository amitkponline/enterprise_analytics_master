package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import java.text.SimpleDateFormat

object TrueUpSecuredReport extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  logger.info("//*********************** Log Start for TrueUpSecuredReport.scala ************************//")

  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  logger.info("+++++++++++++############## properties file:" + propertiesFilePath)

  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  logger.info("+++++++++++++############## environment properties file:" + envPropertiesFilePath)

  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  if (sqlCon == null) {
    logger.error("+++++++++++++############## MYSQL Connection Not Established")
    throw new NullPointerException("Please update tgtTblConsmtn properties to add database name!")
  }

  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val objName = propertiesObject.getObjName().trim()
  val dbCommonName = propertiesObject.getDbName().trim().split(",")(0).trim
  val dbFinName = propertiesObject.getDbName().trim().split(",")(1).trim
  val srcTblName = propertiesObject.getSrcTblConsmtn().trim
  var dbNameConsmtn: String = null
  var consmptnTable: String = null

  try {

    def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
      val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*))
      val rowDF = df.withColumn("rn", row_number().over(part))
      val res = rowDF.filter("rn==1").drop("rn")
      res
    }

    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    //***************************Audit Properties********************************//

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_ea_secrd_trueup_fact_load")
    auditObj.setAudObjectName(objName)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)

    if (tgtTblConsmtn.split("\\.", -1).size != 2) {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)

    val tgtColumns = spark.sql(s"select * from ${srcTblName} limit 0").columns
    val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())
    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    logger.info("#################++++++++++++++++ SERP Dataset Process Start ++++++++++++++++#################")

    // Calculate previous month period

    val format = new SimpleDateFormat("yyyy-MM-dd")
    val c = Calendar.getInstance()
    val formattedDate = format.format(c.getTime()).toString

    val periodFilter: String = spark.sql(s"""
        select 
        cast(CASE
          WHEN substr(fisc_yr_mth_cd,5,2) = 01 THEN CONCAT(cast(substr(fisc_yr_mth_cd,1,4)-1 as string),12)
          ELSE CONCAT(cast(substr(fisc_yr_mth_cd,1,4) as string),cast(substr(fisc_yr_mth_cd,5,2)-1 as string))
        END as int) from ea_common_r2_3itg.clndr_rpt where cldr_dt = '${formattedDate}'""").first()(0).toString()

    logger.info("##################++++++++++++++ periodFilter value: " + periodFilter)

    // EDW Data set from secured fact table
    val dfSecrdRptSelect = spark.sql(s"""
      select 
        fscl_yr_nr,
        fscl_prd_nr as pstg_prd_nr,
        fscl_qtr_nr,
        ord_itm_dcmt_curr_cd as curr_ky,
        prft_cntr_cd as pft_cntr_cd,
        cp_rtm_nm as rtm,
        sgmtl_rptg_cd as sgm_cd,
        nt_rvn_usd_amt as Net_Revenues_USD,
        cp_nt_rvn_usd_amt as CP_Net_Revenues_USD,
        ttl_cst_sls_usd_amt as Total_Cost_of_Sales_USD,
        cp_tot_cst_of_sls_usd_amt as CP_Total_Cost_of_Sales_USD,
        grs_rvn_usd_amt as Gross_Trade_Revenues_USD,
        cp_grs_rvn_usd_amt as CP_Gross_Trade_Revenues_USD,
        entprs_std_cst_usd_amt as Enterprise_Standard_Cost_Total_USD,
        cp_entprs_std_cst_usd_amt as CP_Enterprise_Standard_Cost_Total_USD,
        nt_rvn_amt as Net_Revenues,
        cp_nt_rvn_amt as CP_Net_Revenues,
        ttl_cst_sls_amt as Total_Cost_of_Sales,
        cp_ttl_cst_sls_amt as CP_Total_Cost_of_Sales,
        grs_rvn_amt as Gross_Trade_Revenues,
        cp_grs_rvn_amt as CP_Gross_Trade_Revenues,
        entrprs_stndrd_cst as Enterprise_Standard_Cost_Total,
        cp_entrprs_stndrd_cst as CP_Enterprise_Standard_Cost_Total,
        src_sys_cd
      FROM 
      ${srcTblName} 
      WHERE CONCAT(fscl_yr_nr,cast(fscl_prd_nr as int)) = ${periodFilter}
      AND LOWER(cp_rev_hdr_nm) like 'rev%'
      AND (src_sys_cd = 'SERP' 
      OR src_sys_cd LIKE 'EGI%'
      OR src_sys_cd LIKE 'PN%'
      OR src_sys_cd LIKE 'EDW%')
      """).groupBy("fscl_yr_nr", "pstg_prd_nr", "curr_ky", "pft_cntr_cd", "rtm", "sgm_cd").
      agg(
        sum("Net_Revenues") as "Net_Revenues",
        sum("CP_Net_Revenues") as "CP_Net_Revenues",
        sum("Net_Revenues_USD") as "Net_Revenues_USD",
        sum("CP_Net_Revenues_USD") as "CP_Net_Revenues_USD",
        sum("Total_Cost_of_Sales") as "Total_Cost_of_Sales",
        sum("CP_Total_Cost_of_Sales") as "CP_Total_Cost_of_Sales",
        sum("Total_Cost_of_Sales_USD") as "Total_Cost_of_Sales_USD",
        sum("CP_Total_Cost_of_Sales_USD") as "CP_Total_Cost_of_Sales_USD",
        sum("Gross_Trade_Revenues") as "Gross_Trade_Revenues",
        sum("CP_Gross_Trade_Revenues") as "CP_Gross_Trade_Revenues",
        sum("Gross_Trade_Revenues_USD") as "Gross_Trade_Revenues_USD",
        sum("CP_Gross_Trade_Revenues_USD") as "CP_Gross_Trade_Revenues_USD",
        sum("Enterprise_Standard_Cost_Total") as "Enterprise_Standard_Cost_Total",
        sum("CP_Enterprise_Standard_Cost_Total") as "CP_Enterprise_Standard_Cost_Total",
        sum("Enterprise_Standard_Cost_Total_USD") as "Enterprise_Standard_Cost_Total_USD",
        sum("CP_Enterprise_Standard_Cost_Total_USD") as "CP_Enterprise_Standard_Cost_Total_USD")

    logger.info("#################++++++++++++++++ EDW + SERP + Order Insert Dataset Complete ++++++++++++++++#################")

    /*
     * Pivoting of GL Line Item data
     *
     */

    val df_gl_ln_itm = spark.sql(s"""
    SELECT * 
    FROM 
      ${dbFinName}.gnrl_ldgr_ln_itm_trsn
    WHERE 
      LOWER(dcmt_typ_cd) = 'zb'
      AND CONCAT(fscl_yr_nr,cast(fscl_prd_cd as int)) = ${periodFilter}
    """)

    val fahselectDF = spark.sql(s"select * from ${dbCommonName}.fnctl_ar_std_hrchy")

    val trueupNetRevenueDF = df_gl_ln_itm.as("a").join(fahselectDF.as("c"), col("a.fnctl_ar_cd") === col("c.fa_level_13"), "left").
      select("fscl_prd_cd", "fscl_yr_nr", "pft_cntr_cd", "curr_cd", "grp_acct_nr", "mgmt_grphy_unt_cd", "tc_amt", "fnctl_ar_cd", "mrkt_rte_id", "fa_level_7", "fa_level_7_desc", "fa_level_8", "fa_level_8_desc", "fa_level_11", "fa_level_11_desc").
      filter(col("fnctl_ar_cd").isNotNull).distinct.groupBy("fscl_prd_cd", "fscl_yr_nr", "pft_cntr_cd", "curr_cd", "mgmt_grphy_unt_cd", "mrkt_rte_id").
      pivot("fa_level_7_desc").sum("tc_amt")

    val trueupNetRevenueFinalDF = trueupNetRevenueDF.columns.foldLeft(trueupNetRevenueDF) {
      (newdf, colname) =>
        newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").
          replace(")", ""))
    }

    val trueupGrossDiscountDF = df_gl_ln_itm.as("a").join(fahselectDF.as("c"), col("a.fnctl_ar_cd") === col("c.fa_level_13"), "left").
      select("fscl_prd_cd", "fscl_yr_nr", "pft_cntr_cd", "curr_cd", "grp_acct_nr", "mgmt_grphy_unt_cd", "tc_amt", "fnctl_ar_cd", "mrkt_rte_id", "fa_level_7", "fa_level_7_desc", "fa_level_8",
        "fa_level_8_desc", "fa_level_11", "fa_level_11_desc").filter(col("fnctl_ar_cd").isNotNull).
        distinct.groupBy("fscl_prd_cd", "fscl_yr_nr", "pft_cntr_cd", "curr_cd", "mgmt_grphy_unt_cd", "mrkt_rte_id").pivot("fa_level_8_desc").sum("tc_amt")

    val trueupGrossDiscountFinalDF = trueupGrossDiscountDF.columns.foldLeft(trueupGrossDiscountDF) {
      (newdf, colname) =>
        newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").
          replace("(", "").replace(")", ""))
    }

    val trueupEstimatedStandardCostDF = df_gl_ln_itm.as("a").join(fahselectDF.as("c"), col("a.fnctl_ar_cd") === col("c.fa_level_13"),
      "left").select("fscl_prd_cd", "fscl_yr_nr", "pft_cntr_cd", "curr_cd", "grp_acct_nr", "mgmt_grphy_unt_cd", "tc_amt", "fnctl_ar_cd", "mrkt_rte_id", "fa_level_7", "fa_level_7_desc",
        "fa_level_8", "fa_level_8_desc", "fa_level_11", "fa_level_11_desc").filter(col("fnctl_ar_cd").isNotNull).
        distinct.groupBy("fscl_prd_cd", "fscl_yr_nr", "pft_cntr_cd", "curr_cd", "mgmt_grphy_unt_cd", "mrkt_rte_id").pivot("fa_level_11_desc").sum("tc_amt")

    val trueupEstimatedStandardCostFianlDF = trueupEstimatedStandardCostDF.columns.foldLeft(trueupEstimatedStandardCostDF) { (newdf, colname) =>
      newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").
        replace(")", ""))
    }

    var final_join = trueupNetRevenueFinalDF.as("a").join(trueupGrossDiscountFinalDF.as("b"), col("a.fscl_prd_cd") === col("b.fscl_prd_cd")
      && col("a.fscl_yr_nr") === col("b.fscl_yr_nr") && col("a.pft_cntr_cd") === col("b.pft_cntr_cd") && col("a.curr_cd") === col("b.curr_cd")
      && col("a.mgmt_grphy_unt_cd") === col("b.mgmt_grphy_unt_cd") && col("a.mrkt_rte_id") === col("b.mrkt_rte_id")).
      join(trueupEstimatedStandardCostFianlDF.as("c"), col("b.fscl_prd_cd") === col("c.fscl_prd_cd") && col("b.fscl_yr_nr") === col("c.fscl_yr_nr")
        && col("b.pft_cntr_cd") === col("c.pft_cntr_cd") && col("b.curr_cd") === col("c.curr_cd") && col("b.mgmt_grphy_unt_cd") === col("c.mgmt_grphy_unt_cd")
        && col("b.mrkt_rte_id") === col("c.mrkt_rte_id"))

    final_join = if (!final_join.columns.contains("Net_Revenues")) { final_join.withColumn("Net_Revenues", lit(null)) } else final_join
    final_join = if (!final_join.columns.contains("Gross_Trade_Revenues")) { final_join.withColumn("Gross_Trade_Revenues", lit(null)) } else final_join
    final_join = if (!final_join.columns.contains("Enterprise_Standard_Cost_Total")) { final_join.withColumn("Enterprise_Standard_Cost_Total", lit(null)) } else final_join
    final_join = if (!final_join.columns.contains("Total_Cost_of_Sales")) { final_join.withColumn("Total_Cost_of_Sales", lit(null)) } else final_join

    val exchdf = spark.sql(s"""
    select 
      frm_curr_cd,
      etry_vld_frm_ts,
      year(etry_vld_frm_ts) as fscl_yr_nr,
      month(etry_vld_frm_ts) as fscl_prd_cd,
      frm_curr_unts_rto_2_nr,
      indrt_qted_exch_rate_nr,
      to_curr_unts_rto_2_nr 
    from 
    ${dbNameConsmtn}.exch_rates_dmnsn 
    where 
      exch_rate_typ_cd = 'M' 
      and to_curr_cd = 'USD' 
      and day(etry_vld_frm_ts) = 1
    """).withColumn("exch_rt", when(col("frm_curr_unts_rto_2_nr") === col("to_curr_unts_rto_2_nr"), (col("frm_curr_unts_rto_2_nr") / col("indrt_qted_exch_rate_nr")) * col("to_curr_unts_rto_2_nr")).
      when(col("frm_curr_unts_rto_2_nr") > col("to_curr_unts_rto_2_nr"), (col("to_curr_unts_rto_2_nr") / col("indrt_qted_exch_rate_nr")) * col("frm_curr_unts_rto_2_nr")).
      when(col("frm_curr_unts_rto_2_nr") < col("to_curr_unts_rto_2_nr"), (col("frm_curr_unts_rto_2_nr") / col("indrt_qted_exch_rate_nr")) * col("to_curr_unts_rto_2_nr")).
      otherwise(1))

    val final_gl_ln_itm = final_join.select("a.fscl_prd_cd", "a.fscl_yr_nr", "a.pft_cntr_cd", "a.curr_cd", "a.mgmt_grphy_unt_cd", "a.mrkt_rte_id", "Net_Revenues", "Gross_Trade_Revenues", "Enterprise_Standard_Cost_Total", "Total_Cost_of_Sales").
      as("GL").join(exchdf.as("exch"), col("GL.fscl_yr_nr") === col("exch.fscl_yr_nr")
        && col("GL.fscl_prd_cd") === col("exch.fscl_prd_cd")
        && col("GL.curr_cd") === col("exch.frm_curr_cd"), "left").selectExpr(
        "GL.fscl_prd_cd as pstg_prd_nr",
        "GL.fscl_yr_nr",
        "CASE WHEN cast(GL.fscl_prd_cd as int) in ('11','12','1') then 1 WHEN cast(GL.fscl_prd_cd as int) in ('2','3','4') then 2 WHEN cast(GL.fscl_prd_cd as int) in ('5','6','7') then 3 WHEN cast(GL.fscl_prd_cd as int) in ('8','9','10') then 4 else null end as fscl_qtr_nr",
        "GL.pft_cntr_cd as pft_cntr_cd",
        "GL.curr_cd as curr_ky",
        "GL.mgmt_grphy_unt_cd as sgm_cd",
        "GL.mrkt_rte_id as rtm",
        "Net_Revenues",
        "Net_Revenues*exch_rt as Net_Revenues_USD",
        "Gross_Trade_Revenues",
        "Gross_Trade_Revenues*exch_rt as Gross_Trade_Revenues_USD",
        "Enterprise_Standard_Cost_Total",
        "Enterprise_Standard_Cost_Total*exch_rt as Enterprise_Standard_Cost_Total_USD",
        "Total_Cost_of_Sales",
        "Total_Cost_of_Sales*exch_rt as Total_Cost_of_Sales_USD")

    logger.info("#################++++++++++++++++ GL Transpose Complete ++++++++++++++++#################")

    val GLLoadDF = final_gl_ln_itm.selectExpr(
      "crc64(lower(concat(coalesce(fscl_yr_nr,''),coalesce(pstg_prd_nr,''),coalesce(curr_ky,''),coalesce(pft_cntr_cd,''),coalesce(sgm_cd,''),row_number() over (partition by curr_ky,pft_cntr_cd,sgm_cd,'GL_TRUE_UP' order by fscl_yr_nr,pstg_prd_nr)))) as secrd_rpt_fact_ky",
      "pstg_prd_nr as fscl_prd_nr",
      "fscl_yr_nr",
      "concat('FY',fscl_yr_nr,'-',lpad(pstg_prd_nr,2,'0')) as fscl_yr_prd_cd",
      "fscl_qtr_nr",
      "curr_ky as ord_dcmnt_curr_cd",
      "pft_cntr_cd as prft_cntr_cd",
      "sgm_cd as sgmtl_rptg_cd",
      "rtm as mkt_rte_cd",
      "Net_Revenues_USD as nt_rvn_usd_amt",
      "Total_Cost_of_Sales_USD as ttl_cst_sls_usd_amt",
      "Gross_Trade_Revenues_USD as grs_rvn_usd_amt",
      "Enterprise_Standard_Cost_Total_USD as entprs_std_cst_usd_amt",
      "Net_Revenues as nt_rvn_amt",
      "Gross_Trade_Revenues as grs_rvn_amt",
      "Enterprise_Standard_Cost_Total as entrprs_stndrd_cst",
      "Total_Cost_of_Sales as ttl_cst_sls_amt")

    val trueUpGLLOAD = GLLoadDF.select(Utilities.loadSelectExpr(GLLoadDF.columns, tgtColumns): _*).withColumn("src_sys_cd", lit("GL_TRUE_UP"))

    trueUpGLLOAD.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblConsmtn)

    logger.info("#################++++++++++++++++ GL Transpose Load Complete ++++++++++++++++#################")

    val joinKy = "fscl_yr_nr,pstg_prd_nr,curr_ky,pft_cntr_cd,rtm,sgm_cd"

    val finalDf = final_gl_ln_itm.as("a").join(
      dfSecrdRptSelect.as("b"),
      joinKy.split(",").toSeq, "left").selectExpr(
        "crc64(lower(concat(coalesce(a.fscl_yr_nr,''),coalesce(a.pstg_prd_nr,''),coalesce(a.curr_ky,''),coalesce(a.pft_cntr_cd,''),coalesce(a.sgm_cd,''),row_number() over (partition by curr_ky,pft_cntr_cd,sgm_cd,'TRUE_UP' order by fscl_yr_nr,pstg_prd_nr)))) as secrd_rpt_fact_ky",
        "a.fscl_yr_nr as fscl_yr_nr",
        "a.pstg_prd_nr as fscl_prd_nr",
        "concat('FY',a.fscl_yr_nr,'-',lpad(a.pstg_prd_nr,2,'0')) as fscl_yr_prd_cd",
        "a.fscl_qtr_nr",
        "a.curr_ky as ord_dcmnt_curr_cd",
        "a.pft_cntr_cd as prft_cntr_cd",
        "a.rtm as mkt_rte_cd",
        "a.sgm_cd as sgmtl_rptg_cd",
        "cast((coalesce(a.Net_Revenues_USD,0)-coalesce(b.Net_Revenues_USD,0)) as decimal(32,6)) as nt_rvn_usd_amt",
        "cast((coalesce(a.Net_Revenues_USD,0)-coalesce(b.CP_Net_Revenues_USD,0)) as decimal(32,6)) as cp_nt_rvn_usd_amt",
        "cast((coalesce(a.Net_Revenues,0)-coalesce(b.Net_Revenues,0)) as decimal(32,6)) as nt_rvn_amt",
        "cast((coalesce(a.Net_Revenues,0)-coalesce(b.CP_Net_Revenues,0)) as decimal(32,6)) as cp_nt_rvn_amt",
        "cast((coalesce(a.Total_Cost_of_Sales_USD,0)-coalesce(b.Total_Cost_of_Sales_USD,0)) as decimal(32,6)) as ttl_cst_sls_usd_amt",
        "cast((coalesce(a.Total_Cost_of_Sales_USD,0)-coalesce(b.CP_Total_Cost_of_Sales_USD,0)) as decimal(32,6)) as cp_tot_cst_of_sls_usd_amt",
        "cast((coalesce(a.Total_Cost_of_Sales,0)-coalesce(b.Total_Cost_of_Sales,0)) as decimal(32,6)) as ttl_cst_sls_amt",
        "cast((coalesce(a.Total_Cost_of_Sales,0)-coalesce(b.CP_Total_Cost_of_Sales,0)) as decimal(32,6)) as cp_ttl_cst_sls_amt",
        "cast((coalesce(a.Gross_Trade_Revenues_USD,0)-coalesce(b.Gross_Trade_Revenues_USD,0)) as decimal(32,6)) as grs_rvn_usd_amt",
        "cast((coalesce(a.Gross_Trade_Revenues_USD,0)-coalesce(b.CP_Gross_Trade_Revenues_USD,0)) as decimal(32,6)) as cp_grs_rvn_usd_amt",
        "cast((coalesce(a.Gross_Trade_Revenues,0)-coalesce(b.Gross_Trade_Revenues,0)) as decimal(32,6)) as grs_rvn_amt",
        "cast((coalesce(a.Gross_Trade_Revenues,0)-coalesce(b.CP_Gross_Trade_Revenues,0)) as decimal(32,6)) as cp_grs_rvn_amt",
        "cast((coalesce(a.Enterprise_Standard_Cost_Total_USD,0)-coalesce(b.Enterprise_Standard_Cost_Total_USD,0)) as decimal(32,6)) as entprs_std_cst_usd_amt",
        "cast((coalesce(a.Enterprise_Standard_Cost_Total_USD,0)-coalesce(b.CP_Enterprise_Standard_Cost_Total_USD,0)) as decimal(32,6)) as cp_entprs_std_cst_usd_amt",
        "cast((coalesce(a.Enterprise_Standard_Cost_Total,0)-coalesce(b.Enterprise_Standard_Cost_Total,0)) as decimal(32,6)) as entrprs_stndrd_cst",
        "cast((coalesce(a.Enterprise_Standard_Cost_Total,0)-coalesce(b.CP_Enterprise_Standard_Cost_Total,0)) as decimal(32,6)) as cp_entrprs_stndrd_cst",
        "'TRUE_UP' as src_sys_cd",
        "current_timestamp() as ins_ts")

    logger.info("#################++++++++++++++++ True Up Calculation Complete ++++++++++++++++#################")

    finalDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

    val finalDf1 = finalDf.filter(finalDf("src_sys_cd").isNotNull)

    val finalTrueUpDf = finalDf1.select(Utilities.loadSelectExpr(finalDf1.columns, tgtColumns): _*)

    //val finalTrueUpDf = finalDf1.select(loadSelectExpr(finalDf1.columns, tgtColumns): _*)

    finalTrueUpDf.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblConsmtn)

    logger.info("#################++++++++++++++++ True Up Data Load Complete ++++++++++++++++#################")

    val tgtCount = spark.sql(s"select * from ${tgtTblConsmtn} where src_sys_cd = 'TRUE_UP'").count.toLong

    tgtCount match {
      case 0 =>
        logger.info("//************* Data Load Failed")

        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
  } finally {
    logger.info("//*********************** Log End for TrueUpSecuredReport.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
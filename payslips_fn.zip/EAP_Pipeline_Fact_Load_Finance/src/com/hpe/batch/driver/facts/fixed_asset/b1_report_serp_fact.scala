package com.hpe.batch.driver.facts.fixed_asset

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object b1_report_serp_fact extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var srcCount = 0
  var tgtCount = 0
  var jobStatusFlag = true

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  //************************Set Audit Entries*******************************//

  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(propertiesObject.getObjName())
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(srcCount)
  auditObj.setAudTgtRowCount(tgtCount)

  try {

    var ref_btch_id = Utilities.readRefBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)
    var cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)

    logger.info("ref_btch_id :- " + ref_btch_id + " cnsmptn_btch_id :- " + cnsmptn_btch_id)

    logger.info("Initializing log for B1 REPORT SERP FACT, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ref_btch_id)

    val consmptnTable = new StringBuilder()
    val dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    /* *************************************** Selecting source count ****************************** */
    var ins_gmt_date = ""

    if (cnsmptn_btch_id == "1900-01-01 00:00:00") {
      ins_gmt_date = cnsmptn_btch_id.substring(0, 4) + "-" + cnsmptn_btch_id.substring(5, 7) + "-" + cnsmptn_btch_id.substring(8, 10)
    } else {
      ins_gmt_date = cnsmptn_btch_id.substring(19, 23) + "-" + cnsmptn_btch_id.substring(23, 25) + "-" + cnsmptn_btch_id.substring(25, 27)
    }

    srcCount = spark.sql(s"""select count(*) FROM ${srcTable} b1 where date_sub(b1.ins_gmt_dt,-1)>='${ins_gmt_date}' and b1.ld_jb_nr > '${cnsmptn_btch_id}'""").first().getLong(0).toInt
    logger.info(s"""select count(*) FROM ${srcTable} b1 where date_sub(b1.ins_gmt_dt,-1)>='${ins_gmt_date}' and b1.ld_jb_nr > '${cnsmptn_btch_id}'""")
    logger.info("source count: " + srcCount)
    var tgtTbl = consmptnTable

    /* ****************** Checking if source count is greater than zero or not ********************* */
    if (srcCount > 0) {
      auditObj.setAudSrcRowCount(srcCount)
      
      spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'com.hpe.batch.hive.udfs.CRC64'""")

      /* ************************** Creating data frame for latest data ************************* */
      val current_fscl_yr_prd_df = spark.sql(s"""SELECT crc64(concat(COALESCE(trim(b1.lgl_co_cd),""),COALESCE(trim(b1.mn_asst_nr),""))) as cmpny_cd_mn_asst_nmbr_ky, crc64(concat(COALESCE(trim(b1.lgl_co_cd),""),COALESCE(trim(b1.mn_asst_nr),""),COALESCE(trim(b1.dprc_ar_cd),""))) as cmpny_cd_mn_asst_nmbr_dprctn_ara_ky, crc64(COALESCE(trim(b1.cst_cntr_cd),"")) as cst_cntr_ky, crc64(COALESCE(trim(b1.asst_typ_dn),"")) as asst_typ_nm_ky, crc64(COALESCE(trim(ANLZ.inrn_ord_id),"")) as intrnl_ord_ky, b1.lgl_co_cd, b1.mn_asst_nr, b1.asst_clss_cd, b1.asst_dn, b1.asst_own_nm, b1.mfrr_srl_id, b1.cptlzn_dt, b1.cst_cntr_cd, b1.pft_cntr_cd, b1.mr_cd, b1.lctn_cd, b1.lctn_dn, b1.acctng_prncpl_cd, b1.evltn_grp_1_cd, b1.evltn_grp_2_cd, b1.orgl_asst_id, b1.vndr_nm, b1.vhl_lcns_plt_id, b1.asst_spr_nr, b1.invy_note, b1.dactvn_dt, b1.asst_shtdwn_ind, b1.dprc_ar_cd, b1.dprc_cltn_strt_dt, b1.plnd_usfl_lf_yr_qty, b1.plnd_usfl_lf_prd_qty, b1.usfl_lf, b1.dprc_cd, b1.trsn_typ_cd, b1.trsn_typ_dn, b1.dcmt_dt, b1.asst_vl_dt, b1.dcmt_id, b1.dcmt_hdr_txt, b1.dcmt_pstg_dt, b1.invy_id, b1.invy_last_dt, b1.mfrr_nm, b1.curr_cd, b1.aqstn_amt, b1.ordnry_dprc_amt, b1.rtrd_dprc_amt, b1.rtrd_rvn_amt, b1.gn_amt, b1.loss_amt, b1.abs_asst_scrp_vl_amt, b1.qty, b1.usr_nm, b1.gl_acct_id, b1.rfnc_dcmt_id, b1.dcmt_typ_cd, b1.asst_typ_dn, b1.oft_acct_id, b1.itm_txt, b1.sqn_nr, b1.intgtn_fbrc_msg_id, b1.src_sys_upd_ts, b1.src_sys_ky, b1.lgcl_dlt_ind, b1.ins_gmt_ts, b1.upd_gmt_ts, b1.src_sys_extrc_gmt_ts, b1.src_sys_btch_nr, b1.fl_nm, b1.ld_jb_nr, cast(substr(split(b1.fl_nm,'_')[3],0,4) as int), cast(substr(split(b1.fl_nm,'_')[3],5,3) as int) FROM ${srcTable} b1 left join ${dbNameConsmtn}.tm_dpndnt_asst_allctns_serp_dmnsn ANLZ on b1.lgl_co_cd=ANLZ.lgl_co_cd and b1.mn_asst_nr=ANLZ.mn_asst_nr where date_sub(b1.ins_gmt_dt,-1)>='${ins_gmt_date}' and b1.ld_jb_nr > '${cnsmptn_btch_id}'""")

      logger.info(s"""SELECT crc64(concat(COALESCE(trim(b1.lgl_co_cd),""),COALESCE(trim(b1.mn_asst_nr),""))) as cmpny_cd_mn_asst_nmbr_ky, crc64(concat(COALESCE(trim(b1.lgl_co_cd),""),COALESCE(trim(b1.mn_asst_nr),""),COALESCE(trim(b1.dprc_ar_cd),""))) as cmpny_cd_mn_asst_nmbr_dprctn_ara_ky, crc64(COALESCE(trim(b1.cst_cntr_cd),"")) as cst_cntr_ky, crc64(COALESCE(trim(b1.asst_typ_dn),"")) as asst_typ_nm_ky, crc64(COALESCE(trim(ANLZ.inrn_ord_id),"")) as intrnl_ord_ky, b1.lgl_co_cd, b1.mn_asst_nr, b1.asst_clss_cd, b1.asst_dn, b1.asst_own_nm, b1.mfrr_srl_id, b1.cptlzn_dt, b1.cst_cntr_cd, b1.pft_cntr_cd, b1.mr_cd, b1.lctn_cd, b1.lctn_dn, b1.acctng_prncpl_cd, b1.evltn_grp_1_cd, b1.evltn_grp_2_cd, b1.orgl_asst_id, b1.vndr_nm, b1.vhl_lcns_plt_id, b1.asst_spr_nr, b1.invy_note, b1.dactvn_dt, b1.asst_shtdwn_ind, b1.dprc_ar_cd, b1.dprc_cltn_strt_dt, b1.plnd_usfl_lf_yr_qty, b1.plnd_usfl_lf_prd_qty, b1.usfl_lf, b1.dprc_cd, b1.trsn_typ_cd, b1.trsn_typ_dn, b1.dcmt_dt, b1.asst_vl_dt, b1.dcmt_id, b1.dcmt_hdr_txt, b1.dcmt_pstg_dt, b1.invy_id, b1.invy_last_dt, b1.mfrr_nm, b1.curr_cd, b1.aqstn_amt, b1.ordnry_dprc_amt, b1.rtrd_dprc_amt, b1.rtrd_rvn_amt, b1.gn_amt, b1.loss_amt, b1.abs_asst_scrp_vl_amt, b1.qty, b1.usr_nm, b1.gl_acct_id, b1.rfnc_dcmt_id, b1.dcmt_typ_cd, b1.asst_typ_dn, b1.oft_acct_id, b1.itm_txt, b1.sqn_nr, b1.intgtn_fbrc_msg_id, b1.src_sys_upd_ts, b1.src_sys_ky, b1.lgcl_dlt_ind, b1.ins_gmt_ts, b1.upd_gmt_ts, b1.src_sys_extrc_gmt_ts, b1.src_sys_btch_nr, b1.fl_nm, b1.ld_jb_nr, cast(substr(split(b1.fl_nm,'_')[3],0,4) as int), cast(substr(split(b1.fl_nm,'_')[3],5,3) as int) FROM ${srcTable} b1 left join ${dbNameConsmtn}.tm_dpndnt_asst_allctns_serp_dmnsn ANLZ on b1.lgl_co_cd=ANLZ.lgl_co_cd and b1.mn_asst_nr=ANLZ.mn_asst_nr where date_sub(b1.ins_gmt_dt,-1)>='${ins_gmt_date}' and b1.ld_jb_nr > '${cnsmptn_btch_id}'""")

      /* ****************************** Insert overwrite latest data year and period *********************** */
      current_fscl_yr_prd_df.coalesce(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + tgtTbl)

      /* ************************ selecting target count ****************************************** */
      tgtCount = spark.sql(s"""select count(*) from ${dbNameConsmtn}.${tgtTbl} where ld_jb_nr > '${cnsmptn_btch_id}'""").first().getLong(0).toInt
      logger.info(s"""select count(*) from ${dbNameConsmtn}.${tgtTbl} where ld_jb_nr > '${cnsmptn_btch_id}'""")
      logger.info("target count: " + tgtCount)

      logger.info("+++++++++++############# Load Successful #############+++++++++++")
      auditObj.setAudTgtRowCount(tgtCount)
      auditObj.setAudJobStatusCode("success")
    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("failed")
    }

    /* ********************************************* Completion audit entries ************************** */

    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) {
      System.exit(1)
    }

  }
}

package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source

object ISSOptionedUp extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }

  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  try {
    logger.info("Initializing log for SECURED REPORT ISS FACT, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)

    val consmptnTable = new StringBuilder()
    val dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    val dbName = propertiesObject.getDbName().trim
    var tgtCount: Long = 0
    val srcCount = spark.sql("select count(*) from " + srcTable).first().getLong(0)
    //Initiating queries to load the tables for Secured Report ISS
    //val execQueries = Source.fromFile(fileBasePath).getLines.mkString("\n").split(";")
    /*    val execQueries = spark.sparkContext.textFile(fileBasePath).collect().mkString("\n").split(";")

    var hqlQueries = new StringBuilder()
    val srcCount = spark.sql("select count(*) from " + srcTable).first().getLong(0)

    var loadStatus = false
    var i = 0

    for (hqlQueries <- execQueries) {

      spark.sql(hqlQueries)
      i = i + 1
    }

    if (i == 4) {
      loadStatus = true
      tgtCount = spark.sql("select count(*) from " + dbNameConsmtn + "." + consmptnTable).first().getLong(0)
    } else {
      loadStatus = false
    }
    *
    *
    */

    val ordItmMtrlDF = spark.sql(s"""
    select ord_mtrl_dmnsn.e1edk01_idoc_dcmt_nr, ord_mtrl_dmnsn.e1edp01_itm_nr,ord_itm_dmnsn.e1edp01_higherlevel_itm_bom_structures_cd,  prod_mstr_dmnsn.mtrl_grp_cd, prod_mstr_dmnsn.mtrl_mstr_old_mtrl_id , ord_itm_dmnsn.pft_cntr_nm,
    pft_cntr_alt_hrchy_dmnsn.pc_map_30 as cp_optnd_up ,CASE WHEN SERVER_CNT.CNT = 1 THEN 'Pure' 
    WHEN SERVER_CNT.CNT > 1 THEN 'Multi' ELSE 
    'Option Only' END as allc_typ,
    trim(pft_cntr_alt_hrchy_dmnsn.pc_map_31) as ctg_allc,
    trim(current_prod_hrchy_dmnsn.prod_hrchy_prod_srs_dn) as cp_prod_char
    from
    $dbName.ord_itm_dmnsn ord_itm_dmnsn left outer join ea_common.ord_mtrl_dmnsn ord_mtrl_dmnsn on ord_mtrl_dmnsn.e1edk01_idoc_dcmt_nr = ord_itm_dmnsn.e1edk01_idoc_dcmt_nr and ord_mtrl_dmnsn.e1edp01_itm_nr = ord_itm_dmnsn.e1edp01_itm_nr 
    left outer join $dbName.prod_mstr_dmnsn prod_mstr_dmnsn on ord_mtrl_dmnsn.e1edp19_idoc_mtrl_i_1_nm_2 = prod_mstr_dmnsn.mtrl_mstr_mtrl_id
    left outer join $dbName.current_prod_hrchy_dmnsn current_prod_hrchy_dmnsn on current_prod_hrchy_dmnsn.mtrl_mstr_mtrl_id =ord_mtrl_dmnsn.e1edp19_idoc_mtrl_i_1_nm_2 
    left outer join $dbName.bmt_alt_pft_cntr_dmnsn  alt_pft_cntr_dmnsn on ord_itm_dmnsn.pft_cntr_nm=alt_pft_cntr_dmnsn.pft_cntr_cd 
    left outer join $dbName.bmt_pft_cntr_alt_hrchy_dmnsn pft_cntr_alt_hrchy_dmnsn on pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd=ord_itm_dmnsn.pft_cntr_nm
    left outer join (SELECT a.e1edk01_idoc_dcmt_nr,COUNT(a.e1edp01_itm_nr) as CNT FROM $dbName.ord_mtrl_dmnsn a  
    left outer join $dbName.prod_mstr_dmnsn prod_mstr_dmnsn on a.e1edp19_idoc_mtrl_i_1_nm_2 = prod_mstr_dmnsn.mtrl_mstr_mtrl_id 
    WHERE UPPER(TRIM(prod_mstr_dmnsn.mtrl_grp_cd)) = 'SERVER' GROUP BY a.e1edk01_idoc_dcmt_nr ) SERVER_CNT  on SERVER_CNT.e1edk01_idoc_dcmt_nr=ord_mtrl_dmnsn.e1edk01_idoc_dcmt_nr
      """)

    ordItmMtrlDF.repartition(25).write.mode("overwrite").format("orc").insertInto(dbName + ".ord_itm_mtrl_dmnsn")
    logger.info("+++++++++########### ord_itm_mtrl_dmnsn table loaded ###########+++++++++")

    val secrdRptLayer_1_2Iss = spark.sql(s"""
  select secrd_rpt_fact.fscl_yr_prd_cd,
	secrd_rpt_fact.sgm_lvl_4,
	secrd_rpt_fact.pch_lvl_3,
	secrd_rpt_fact.ctry_nm,
	secrd_rpt_fact.cust_sgm_nm,
	secrd_rpt_fact.sls_ord_id,
	ord_itm_mtrl_dmnsn.e1edk01_idoc_dcmt_nr,
	secrd_rpt_fact.sls_ord_ln_itm_id,
	ord_itm_mtrl_dmnsn.e1edp01_itm_nr,
	ord_itm_mtrl_dmnsn.cp_optnd_up as cp_optnd_up,
	ord_itm_mtrl_dmnsn.allc_typ as allc_typ,
	ord_itm_mtrl_dmnsn.ctg_allc as ctg_allc,
	CASE WHEN ord_itm_mtrl_dmnsn.cp_optnd_up<>'ISS' THEN NULL
	WHEN ord_itm_mtrl_dmnsn.mtrl_grp_cd ='SERVER' THEN ord_itm_mtrl_dmnsn.ctg_allc
	WHEN ord_itm_mtrl_dmnsn.mtrl_grp_cd <>'SERVER' AND ord_itm_mtrl_dmnsn.allc_typ='Pure' AND ord_itm_mtrl_dmnsn.ctg_allc='Shared'  THEN ORD_CP_DINAL_PURE.ctg_allc
	WHEN ord_itm_mtrl_dmnsn.mtrl_grp_cd <>'SERVER' AND ord_itm_mtrl_dmnsn.allc_typ='Multi' AND ord_itm_mtrl_dmnsn.ctg_allc='Shared'  THEN ORD_CP_DINAL_MULTI.ctg_allc
	WHEN ord_itm_mtrl_dmnsn.ctg_allc<>'Shared' THEN ord_itm_mtrl_dmnsn.ctg_allc END as cp_fnl_eg_ctg,
	CASE WHEN ord_itm_mtrl_dmnsn.cp_optnd_up<>'ISS' THEN NULL
	WHEN ord_itm_mtrl_dmnsn.mtrl_grp_cd ='SERVER' THEN 'Layer 1'
	WHEN ord_itm_mtrl_dmnsn.mtrl_grp_cd <>'SERVER' AND ord_itm_mtrl_dmnsn.allc_typ IN ('Pure','Multi') AND ord_itm_mtrl_dmnsn.ctg_allc='Shared'  THEN 'Layer 1'
	WHEN ord_itm_mtrl_dmnsn.ctg_allc<>'Shared' THEN 'Layer 2'
	ELSE NULL END as allc_lyr,
	CASE WHEN ord_itm_mtrl_dmnsn.cp_optnd_up<>'ISS' THEN NULL
	WHEN ord_itm_mtrl_dmnsn.mtrl_grp_cd ='SERVER' THEN ord_itm_mtrl_dmnsn.cp_prod_char
	WHEN ord_itm_mtrl_dmnsn.mtrl_grp_cd <>'SERVER' AND ord_itm_mtrl_dmnsn.allc_typ='Pure' AND ord_itm_mtrl_dmnsn.ctg_allc='Shared'  THEN ORD_CP_DINAL_PURE.cp_prod_char
	WHEN ord_itm_mtrl_dmnsn.mtrl_grp_cd <>'SERVER' AND ord_itm_mtrl_dmnsn.allc_typ='Multi' AND ord_itm_mtrl_dmnsn.ctg_allc='Shared'  THEN ORD_CP_DINAL_MULTI.cp_prod_char END as cp_prod_char ,
	coalesce(bmt_allctn_cust_geo_dmnsn.ctry_geo_allct_nm,secrd_rpt_fact.ctry_nm ) as ctry_geo_allct_nm,
	bmt_allctn_cust_geo_dmnsn.allctn_rate,
	secrd_rpt_fact.sgmtl_rptg_cd,
	secrd_rpt_fact.sgm_lvl_3,
	secrd_rpt_fact.prft_cntr_cd,
	secrd_rpt_fact.oypl_pch_level_7,
	secrd_rpt_fact.oypl_pch_level_7_desc,
	secrd_rpt_fact.oypl_pch_level_6_desc,
	secrd_rpt_fact.oypl_pch_level_5_desc,
	secrd_rpt_fact.oypl_pch_level_4_desc,
	secrd_rpt_fact.oypl_pch_level_3_desc,
	secrd_rpt_fact.oypl_pch_level_2_desc,
	secrd_rpt_fact.oypl_pch_level_1_desc,
	secrd_rpt_fact.cp_bklg_sni_rvn,
	secrd_rpt_fact.cp_end_cust_prty_id,
	secrd_rpt_fact.cp_end_cust_prty_nm,
	secrd_rpt_fact.sld_to_cd,
	secrd_rpt_fact.shp_to_cd,
	secrd_rpt_fact.cp_incd_excld,
	secrd_rpt_fact.scra_cgy_cd,
	secrd_rpt_fact.cp_rev_recgn_cgy_cd,
	secrd_rpt_fact.cp_rev_hdr_nm,
	secrd_rpt_fact.cp_rtm_nm,
	secrd_rpt_fact.mkt_rte_cd,
	secrd_rpt_fact.mtrl_nr,
	secrd_rpt_fact.opty_id,
	secrd_rpt_fact.ord_crt_dt,
	secrd_rpt_fact.ord_typ_cd,
	secrd_rpt_fact.ord_cgy_dn,
	secrd_rpt_fact.rvn_cnvrsn_rt,
	secrd_rpt_fact.rt_cnvsn_src,
	secrd_rpt_fact.fscl_qtr_nr,
	secrd_rpt_fact.invc_id,
	secrd_rpt_fact.src_sys_cd,
	secrd_rpt_fact.beg_bklg_nm,
	secrd_rpt_fact.ttl_rvn_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ttl_rvn_usd_amt,
	secrd_rpt_fact.cp_nt_rvn_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_nt_rvn_usd_amt,
	secrd_rpt_fact.ttl_cst_sls_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ttl_cst_sls_usd_amt,
	secrd_rpt_fact.cp_net_inv_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_net_inv_usd_amt,
	secrd_rpt_fact.cp_grs_inv_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_grs_inv_usd_amt,
	secrd_rpt_fact.cp_nt_rvn_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_nt_rvn_amt,
	secrd_rpt_fact.cp_ndp_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_ndp_usd_amt,
	secrd_rpt_fact.cp_grs_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_grs_usd_amt,
	secrd_rpt_fact.cp_entprs_std_cst_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_entprs_std_cst_usd_amt,
	secrd_rpt_fact.cp_tot_cst_of_sls_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_tot_cst_of_sls_usd_amt,
	secrd_rpt_fact.base_qty*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as base_qty,
	secrd_rpt_fact.unt_qty*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as unt_qty,
	secrd_rpt_fact.cp_prft_ctr_cd,
	--secrd_rpt_fact.nt_rvn_amt_usd,
	secrd_rpt_fact.ttl_rvn_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ttl_rvn_amt,
	--secrd_rpt_fact.end_cus_nm,
	secrd_rpt_fact.end_cust_cd,
	secrd_rpt_fact.hghr_lvl_itm_no_cd,
	secrd_rpt_fact.cust_sgm_cd,
	secrd_rpt_fact.deal_id,
	secrd_rpt_fact.prod_base_id,
	secrd_rpt_fact.prod_id,
	secrd_rpt_fact.shrt_txt_sls_ord_itm_nm,
	secrd_rpt_fact.cust_po_nr,
	secrd_rpt_fact.plnd_shp_strt_dt,
	secrd_rpt_fact.entrprs_stndrd_cst_grp_curr_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as entrprs_stndrd_cst_grp_curr_usd_amt,
	secrd_rpt_fact.grs_mrgn_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as grs_mrgn_usd_amt,
	secrd_rpt_fact.use_nm,
	secrd_rpt_fact.actl_inv_dt,
	secrd_rpt_fact.eurofit_flag,
	secrd_rpt_fact.prch_agrmnt_nr,
	secrd_rpt_fact.sm_actl_gds_mvmt_dt,
	secrd_rpt_fact.sld_to_ctry_ky,
	secrd_rpt_fact.rfrnc_dcmt_nr,
	secrd_rpt_fact.rev_hd_cd
	from $dbNameConsmtn.secrd_rpt_fact secrd_rpt_fact
	left outer join $dbName.ord_itm_mtrl_dmnsn ord_itm_mtrl_dmnsn on secrd_rpt_fact.sls_ord_id=ord_itm_mtrl_dmnsn.e1edk01_idoc_dcmt_nr and ord_itm_mtrl_dmnsn.e1edp01_itm_nr=secrd_rpt_fact.sls_ord_ln_itm_id  
	left outer join (select e1edk01_idoc_dcmt_nr, e1edp01_itm_nr, ctg_allc,cp_prod_char from $dbName.ord_itm_mtrl_dmnsn where mtrl_grp_cd ='SERVER' ) ORD_CP_DINAL_PURE on ORD_CP_DINAL_PURE.e1edk01_idoc_dcmt_nr= secrd_rpt_fact.sls_ord_id and ORD_CP_DINAL_PURE.e1edp01_itm_nr=secrd_rpt_fact.hghr_lvl_itm_no_cd 
	left outer join (select e1edk01_idoc_dcmt_nr, e1edp01_itm_nr, ctg_allc,cp_prod_char from $dbName.ord_itm_mtrl_dmnsn where mtrl_grp_cd ='SERVER' ) ORD_CP_DINAL_MULTI on ORD_CP_DINAL_MULTI.e1edk01_idoc_dcmt_nr= secrd_rpt_fact.sls_ord_id and ORD_CP_DINAL_MULTI.e1edp01_itm_nr=secrd_rpt_fact.hghr_lvl_itm_no_cd
	left outer join $dbName.bmt_allctn_cust_geo_dmnsn bmt_allctn_cust_geo_dmnsn on bmt_allctn_cust_geo_dmnsn.fscl_yr_mt_cd=secrd_rpt_fact.fscl_yr_prd_cd and bmt_allctn_cust_geo_dmnsn.sgm_lvl_4=secrd_rpt_fact.sgm_lvl_3 and bmt_allctn_cust_geo_dmnsn.pft_cntr_cgy_lvl_1_cd=secrd_rpt_fact.pch_lvl_5 AND bmt_allctn_cust_geo_dmnsn.ctry_nm=secrd_rpt_fact.ctry_nm 
	where ord_itm_mtrl_dmnsn.cp_optnd_up='ISS'
      """)

    ordItmMtrlDF.repartition(25).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + ".secrd_rpt_layer_1_2_iss")
    logger.info("+++++++++########### secrd_rpt_layer_1_2_iss table loaded ###########+++++++++")

    val secrdRptIssDF = spark.sql(s"""
    select 
	  secrd_rpt_layer_1_2_iss.fscl_yr_prd_cd,
	  secrd_rpt_layer_1_2_iss.sgm_lvl_4,
	  secrd_rpt_layer_1_2_iss.pch_lvl_3,
	  secrd_rpt_layer_1_2_iss.ctry_nm,
	  secrd_rpt_layer_1_2_iss.cust_sgm_nm,
	  secrd_rpt_layer_1_2_iss.sls_ord_id,
	  secrd_rpt_layer_1_2_iss.e1edk01_idoc_dcmt_nr,
	  secrd_rpt_layer_1_2_iss.sls_ord_ln_itm_id,
	  secrd_rpt_layer_1_2_iss.e1edp01_itm_nr,
	  secrd_rpt_layer_1_2_iss.cp_optnd_up,
	  secrd_rpt_layer_1_2_iss.allc_typ,
	  secrd_rpt_layer_1_2_iss.ctg_allc,
	  secrd_rpt_layer_1_2_iss.cp_fnl_eg_ctg,
	  CASE WHEN secrd_rpt_layer_1_2_iss.cp_optnd_up='ISS' AND  secrd_rpt_layer_1_2_iss.allc_lyr IS NULL THEN 'Layer 3' ELSE secrd_rpt_layer_1_2_iss.allc_lyr END as allc_lyr,
	  secrd_rpt_layer_1_2_iss.cp_prod_char,
	  secrd_rpt_layer_1_2_iss.ctry_geo_allct_nm,
	  secrd_rpt_layer_1_2_iss.allctn_rate,
	  secrd_rpt_layer_1_2_iss.sgmtl_rptg_cd,
	  secrd_rpt_layer_1_2_iss.sgm_lvl_3,
	  secrd_rpt_layer_1_2_iss.prft_cntr_cd,
	  secrd_rpt_layer_1_2_iss.oypl_pch_level_7,
	  secrd_rpt_layer_1_2_iss.oypl_pch_level_7_desc,
	  secrd_rpt_layer_1_2_iss.oypl_pch_level_6_desc,
	  secrd_rpt_layer_1_2_iss.oypl_pch_level_5_desc,
	  secrd_rpt_layer_1_2_iss.oypl_pch_level_4_desc,
	  secrd_rpt_layer_1_2_iss.oypl_pch_level_3_desc,
	  secrd_rpt_layer_1_2_iss.oypl_pch_level_2_desc,
	  secrd_rpt_layer_1_2_iss.oypl_pch_level_1_desc,
	  secrd_rpt_layer_1_2_iss.cp_bklg_sni_rvn,
	  secrd_rpt_layer_1_2_iss.cp_end_cust_prty_id,
	  secrd_rpt_layer_1_2_iss.cp_end_cust_prty_nm,
	  secrd_rpt_layer_1_2_iss.sld_to_cd,
	  secrd_rpt_layer_1_2_iss.shp_to_cd,
	  secrd_rpt_layer_1_2_iss.cp_incd_excld,
	  secrd_rpt_layer_1_2_iss.scra_cgy_cd,
	  secrd_rpt_layer_1_2_iss.cp_rev_recgn_cgy_cd,
	  secrd_rpt_layer_1_2_iss.cp_rev_hdr_nm,
	  secrd_rpt_layer_1_2_iss.cp_rtm_nm,
	  secrd_rpt_layer_1_2_iss.mkt_rte_cd,
	  secrd_rpt_layer_1_2_iss.mtrl_nr,
	  secrd_rpt_layer_1_2_iss.opty_id,
	  secrd_rpt_layer_1_2_iss.ord_crt_dt,
	  secrd_rpt_layer_1_2_iss.ord_typ_cd,
	  secrd_rpt_layer_1_2_iss.ord_cgy_dn,
	  secrd_rpt_layer_1_2_iss.rvn_cnvrsn_rt,
	  secrd_rpt_layer_1_2_iss.rt_cnvsn_src,
	  secrd_rpt_layer_1_2_iss.fscl_qtr_nr,
	  secrd_rpt_layer_1_2_iss.invc_id,
	  secrd_rpt_layer_1_2_iss.src_sys_cd,
	  secrd_rpt_layer_1_2_iss.beg_bklg_nm,
	  secrd_rpt_layer_1_2_iss.ttl_rvn_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS ttl_rvn_usd_amt,
	  secrd_rpt_layer_1_2_iss.cp_nt_rvn_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_nt_rvn_usd_amt,
	  secrd_rpt_layer_1_2_iss.ttl_cst_sls_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt ,1) AS ttl_cst_sls_usd_amt,
	  secrd_rpt_layer_1_2_iss.cp_net_inv_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_net_inv_usd_amt,
	  secrd_rpt_layer_1_2_iss.cp_grs_inv_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_grs_inv_usd_amt,
	  secrd_rpt_layer_1_2_iss.cp_nt_rvn_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_nt_rvn_amt,
	  secrd_rpt_layer_1_2_iss.cp_ndp_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)   AS cp_ndp_usd_amt,
	  secrd_rpt_layer_1_2_iss.cp_grs_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_grs_usd_amt,
	  secrd_rpt_layer_1_2_iss.cp_entprs_std_cst_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) AS cp_entprs_std_cst_usd_amt,
	  secrd_rpt_layer_1_2_iss.cp_tot_cst_of_sls_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) AS cp_tot_cst_of_sls_usd_amt,
	  secrd_rpt_layer_1_2_iss.base_qty*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS base_qty,
	  secrd_rpt_layer_1_2_iss.unt_qty*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS unt_qty,
	  secrd_rpt_layer_1_2_iss.cp_prft_ctr_cd,
	  secrd_rpt_layer_1_2_iss.ttl_rvn_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS ttl_rvn_amt,
	  secrd_rpt_layer_1_2_iss.end_cust_cd,
	  secrd_rpt_layer_1_2_iss.hghr_lvl_itm_no_cd,
	  bmt_optn_up_allctn_cgy_rate_dmnsn.to_eg_catg,
	  bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,
	  secrd_rpt_layer_1_2_iss.cust_sgm_cd,
	  secrd_rpt_layer_1_2_iss.deal_id,
	  secrd_rpt_layer_1_2_iss.prod_base_id,
	  secrd_rpt_layer_1_2_iss.prod_id,
	  secrd_rpt_layer_1_2_iss.shrt_txt_sls_ord_itm_nm,
	  secrd_rpt_layer_1_2_iss.cust_po_nr,
	  secrd_rpt_layer_1_2_iss.plnd_shp_strt_dt,
	  secrd_rpt_layer_1_2_iss.entrprs_stndrd_cst_grp_curr_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS entrprs_stndrd_cst_grp_curr_usd_amt,
	  secrd_rpt_layer_1_2_iss.grs_mrgn_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS grs_mrgn_usd_amt,
	  secrd_rpt_layer_1_2_iss.use_nm,
	  secrd_rpt_layer_1_2_iss.actl_inv_dt,
	  secrd_rpt_layer_1_2_iss.eurofit_flag,
	  secrd_rpt_layer_1_2_iss.prch_agrmnt_nr,
	  secrd_rpt_layer_1_2_iss.sm_actl_gds_mvmt_dt,
	  secrd_rpt_layer_1_2_iss.sld_to_ctry_ky,
	  secrd_rpt_layer_1_2_iss.rfrnc_dcmt_nr,
	  secrd_rpt_layer_1_2_iss.rev_hd_cd
	  from $dbNameConsmtn.secrd_rpt_layer_1_2_iss secrd_rpt_layer_1_2_iss left outer join $dbName.bmt_optn_up_allctn_cgy_rate_dmnsn bmt_optn_up_allctn_cgy_rate_dmnsn on
	  bmt_optn_up_allctn_cgy_rate_dmnsn.fisc_mth_cd = secrd_rpt_layer_1_2_iss.fscl_yr_prd_cd and
	  bmt_optn_up_allctn_cgy_rate_dmnsn.dsply_ctry_nm = secrd_rpt_layer_1_2_iss.ctry_geo_allct_nm and
	  UPPER(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rtm) = UPPER(secrd_rpt_layer_1_2_iss.mkt_rte_cd) and
	  bmt_optn_up_allctn_cgy_rate_dmnsn.catg_lvl_1 = secrd_rpt_layer_1_2_iss.cp_optnd_up and
	  secrd_rpt_layer_1_2_iss.cp_optnd_up = 'ISS' and secrd_rpt_layer_1_2_iss.allc_lyr is null
    """)

    secrdRptIssDF.repartition(25).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + ".secrd_rpt_iss")
    logger.info("+++++++++########### secrd_rpt_iss table loaded ###########+++++++++")

    val secrdRptIssSnpshtDF = spark.sql(s"""
      select
 fscl_yr_prd_cd ,
 sgm_lvl_4,
 pch_lvl_3,
 ctry_nm,
 cust_sgm_nm,
 sls_ord_id ,
 e1edk01_idoc_dcmt_nr ,
 sls_ord_ln_itm_id,
 e1edp01_itm_nr ,
 cp_optnd_up,
 allc_typ ,
 ctg_allc ,
 cp_fnl_eg_ctg,
 allc_lyr ,
 cp_prod_char ,
 ctry_geo_allct_nm,
 allctn_rate,
 sgmtl_rptg_cd,
 sgm_lvl_3,
 prft_cntr_cd ,
 oypl_pch_level_7 ,
 oypl_pch_level_7_desc,
 oypl_pch_level_6_desc,
 oypl_pch_level_5_desc,
 oypl_pch_level_4_desc,
 oypl_pch_level_3_desc,
 oypl_pch_level_2_desc,
 oypl_pch_level_1_desc,
 cp_bklg_sni_rvn,
 cp_end_cust_prty_id,
 cp_end_cust_prty_nm,
 sld_to_cd,
 shp_to_cd,
 cp_incd_excld,
 scra_cgy_cd,
 cp_rev_recgn_cgy_cd,
 cp_rev_hdr_nm,
 cp_rtm_nm,
 mkt_rte_cd ,
 mtrl_nr,
 opty_id,
 ord_crt_dt ,
 ord_typ_cd ,
 ord_cgy_dn ,
 rvn_cnvrsn_rt,
 rt_cnvsn_src ,
 fscl_qtr_nr,
 invc_id,
 src_sys_cd ,
 beg_bklg_nm,
 ttl_rvn_usd_amt,
 cp_nt_rvn_usd_amt,
 ttl_cst_sls_usd_amt,
 cp_net_inv_usd_amt ,
 cp_grs_inv_usd_amt ,
 cp_nt_rvn_amt,
 cp_ndp_usd_amt ,
 cp_grs_usd_amt ,
 cp_entprs_std_cst_usd_amt,
 cp_tot_cst_of_sls_usd_amt,
 base_qty ,
 unt_qty,
 cp_prft_ctr_cd ,
 ttl_rvn_amt,
 end_cust_cd,
 hghr_lvl_itm_no_cd ,
 to_eg_catg ,
 final_rt ,
 cust_sgm_cd,
 deal_id,
 prod_base_id ,
 prod_id,
 shrt_txt_sls_ord_itm_nm,
 cust_po_nr ,
 plnd_shp_strt_dt ,
 entrprs_stndrd_cst_grp_curr_usd_amt,
 grs_mrgn_usd_amt ,
 use_nm ,
 actl_inv_dt,
 eurofit_flag ,
 prch_agrmnt_nr,
 sm_actl_gds_mvmt_dt,
 sld_to_ctry_ky,
 rfrnc_dcmt_nr,
 rev_hd_cd,
CURRENT_TIMESTAMP as snpsht_ins_ts,
CASE WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('12:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('08:00 AM',"hh:mm a") THEN 1 
WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('08:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('04:00 PM',"hh:mm a") THEN 2 
ELSE 3 END as snpsht_nr 
from $dbNameConsmtn.secrd_rpt_iss
      """)

    secrdRptIssSnpshtDF.repartition(25).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + ".secrd_rpt_iss_snpsht_fact")
    logger.info("+++++++++########### secrd_rpt_iss_snpsht_fact table loaded ###########+++++++++")

    tgtCount = spark.sql("select count(*) from " + dbNameConsmtn + "." + consmptnTable).first().getLong(0)

    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (tgtCount > 0) {
      auditObj.setAudJobStatusCode("success")
      logger.info("Load Successful")
    } else {
      auditObj.setAudJobStatusCode("failed")
      logger.info("Load Failed")
    }
    auditObj.setAudSrcRowCount(srcCount)
    auditObj.setAudTgtRowCount(tgtCount)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    sqlCon.close()
    spark.close()
  }
}

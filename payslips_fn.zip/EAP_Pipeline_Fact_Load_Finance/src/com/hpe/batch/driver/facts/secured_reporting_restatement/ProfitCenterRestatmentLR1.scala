package com.hpe.batch.driver.facts.secured_reporting_restatement

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import java.text.SimpleDateFormat


class ProfitCenterRestatementLR1(auditObj: main.scala.com.hpe.config.AuditLoadObject, propertiesObject: StreamingPropertiesObject, spark: SparkSession, sqlCon: Connection, auditTbl: String, sourceSystem: Array[String], restatementDate: String, snpshtStrtDt: String, snpshtEndDt: String, snpshtNr: String, recepient: String) {

  def sendemail(mailTo: String, mailFrom: String, mailSubject: String, mailContent: String, mailHost: String) = {
    import javax.mail.{ Message, Session, Transport }
    import javax.mail.internet.{ InternetAddress, MimeMessage }
    import java.util.{ HashMap, Properties }
    var properties: Properties = System.getProperties();
    properties.setProperty("mail.smtp.host", mailHost)
    var session: Session = Session.getDefaultInstance(properties)
    var message: MimeMessage = new MimeMessage(session)
    message.setFrom(new InternetAddress(mailFrom))
    var mailrecipient = mailTo.split(",")
    for (mailto <- mailrecipient) {
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailto))
    }
    message.setSubject(mailSubject)
    message.setContent(mailContent, "text/html");
    Transport.send(message)
  }

  def email_content(process: String, srcsys: String, strtDt: String, endDt: String, snpshtNr: String, jobStatus: String, subject: String): String =
    {

      /*var message = "Hi Team,<br><br> " + subject + """<br><br><b>Restatement process status:</b><br><br><table id="table_id" style=\"border: 2px; border-collapse: collapse\"><tr bgcolor=blue><td><b>Process Name</b></td><td><b>Source System</b></td><td><b>Snaphot Start Date</b></td><td><b>Snaphot End Date</b></td><td><b>Snaphot Start Number</b></td></tr>"""
      //message = htmlHead + message

      message += message + """<tr><td class="y_n">""" + process + """</td><td class="y_n">""" + srcsys + """</td><td class="y_n">""" + strtDt + """</td><td class="y_n">""" + endDt + "</td><td>" + snpshtNr + """</td><td class="y_n">""" + "</td></tr>"

      message
      * */

      var message = """
      <style>td {border: solid 1px black;}</style>        
      <html>
      <body>
        Hi Team, <br><br>
      <b>Restatement Job Status:</b><br><br>
      <table id="table_id" style="border: 2px; border-collapse: collapse">
      <tr bgcolor=#87CEFA><td>Process Name</td><td>Source System</td><td>Snapshot Start Date</td><td>Snapshot End Date</td><td>Snapshot Nr</td></tr> """
      val consumptionmessage = """<tr><td>""" + process + """</td><td>""" + srcsys + """</td><td>""" + strtDt + """</td><td>""" + endDt + """</td><td>""" + snpshtNr + """</td></tr>"""
      message = message + consumptionmessage + "</table> <br><br> Thanks </body></html>"

      message
    }

  def run() {

    val logger = Logger.getLogger(getClass.getName)
    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    //val startTime = Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
    val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
    val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
    val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
    val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
    val apiName = propertiesObject.getApiName()
    val deleteflag = propertiesObject.getDeleteflag()
    val deletetableName = propertiesObject.getDeleteTableName()
    val joinCol = propertiesObject.getDeletejoinCol()
    val dbCommon = propertiesObject.getDbName().split(",")(0)
    val dbFin = propertiesObject.getDbName().split(",")(1)
    
    try {

      val srcName = sourceSystem.mkString(",")

      val audCheck = spark.sql(s"""
        select 
          * 
        from 
          ${dbCommon}.bmt_restmnt_trigr_audt_dmnsn
        where 
          prcs_nm = 'PC-RESTATE' 
          and src_sys_cd = '${srcName}' 
          and rstmnt_dt = '${restatementDate}' 
          and snpsht_strt_dt = '${snpshtStrtDt}'
          and snpsht_end_dt = '${snpshtEndDt}'
          and snpsht_no = '${snpshtNr}'
          and cmpltn_flg = 'Y' """).count.toInt

      logger.info("+++++++++++++########## Profit Center Restatement")

      logger.info("+++++++++++++########## Source System:" + sourceSystem)

      logger.info("+++++++++++++########## Snapshot Start Date:" + snpshtStrtDt)

      logger.info("+++++++++++++########## Snapshot End Date:" + snpshtEndDt)

      logger.info("+++++++++++++########## Snapshot Number:" + snpshtNr)

      var subject = "ITG:Secured Reporting Profit Center Restatement Start - " + restatementDate

      var message = email_content("Profit Center", sourceSystem.mkString(","), snpshtStrtDt, snpshtEndDt, snpshtNr, "start", subject)

      val format = new SimpleDateFormat("yyyy-MM-dd");
      val c = Calendar.getInstance();
      val formattedDate = format.format(c.getTime());

      //val formattedDate = "2020-05-20"

      if (audCheck != null && audCheck == 0) {
        if (restatementDate != null && restatementDate == formattedDate) {

          logger.info("+++++++++++++########## profit center restament process start ##########+++++++++++++")

          // send start email
          sendemail(recepient, "Restatement_Monitoring@hpe.com", subject, message, "smtp3.hpe.com")

          val df_secrd_snp_shot_all = spark.sql(s"select * from ${dbFin}.secrd_rpt_snpsht_fact").
            filter(col("src_sys_cd").isin(sourceSystem: _*) && col("partition_dt") >= snpshtStrtDt && col("partition_dt") <= snpshtEndDt && col("partition_nr").isin(snpshtNr.split(","): _*))

          val df_pdm_mtrl_plnt_grp = spark.sql(s"select distinct mtrl_plnt_mtrl_id,mtrl_plnt_cd,mtrl_plnt_pft_cntr_cd  from ${dbCommon}.pdm_mtrl_plnt_grp_dmnsn")

          val df_completed_orders = spark.sql(s"select distinct sls_ord_id,sls_ord_ln_itm_id,mtrl_nr,plnt_cd,partition_dt as partition_dt,partition_nr as part_nr,cp_prft_ctr_cd,src_sys_cd from ${dbFin}.secrd_rpt_snpsht_fact").
            filter(col("src_sys_cd").isin(sourceSystem: _*) && col("partition_dt") >= snpshtStrtDt && col("partition_dt") <= snpshtEndDt && col("part_nr").isin(snpshtNr.split(","): _*))

          val overWriteDatePartition = df_completed_orders.as("cmplt").join(df_pdm_mtrl_plnt_grp.as("mtrl_plnt"), col("cmplt.mtrl_nr") === col("mtrl_plnt.mtrl_plnt_mtrl_id") && col("cmplt.plnt_cd") === col("mtrl_plnt.mtrl_plnt_cd"), "left").
            filter(col("cp_prft_ctr_cd") =!= col("mtrl_plnt_pft_cntr_cd")).
            select(col("partition_dt").cast("string")).distinct().collect.map(row => row.getString(0).toString()).toSeq

          val df_updated_orders = df_completed_orders.as("cmplt").join(df_pdm_mtrl_plnt_grp.as("mtrl_plnt"), col("cmplt.mtrl_nr") === col("mtrl_plnt.mtrl_plnt_mtrl_id") && col("cmplt.plnt_cd") === col("mtrl_plnt.mtrl_plnt_cd"), "left").
            filter(col("cp_prft_ctr_cd") =!= col("mtrl_plnt_pft_cntr_cd"))

          var colList = df_secrd_snp_shot_all.columns.toList

          for (partitionDate <- overWriteDatePartition) {
            for (partNr <- snpshtNr.split(",").toSeq) {

              logger.info("*****************************************processign partitions " + partitionDate + "," + partNr)
              val df_updated_records = df_secrd_snp_shot_all.as("secrd_snp_shot_all").
                filter(col("partition_dt").isin(partitionDate) && col("partition_nr") === partNr).
                join(df_updated_orders.as("cmplt"), col("secrd_snp_shot_all.sls_ord_id") === col("cmplt.sls_ord_id") && col("secrd_snp_shot_all.mtrl_nr") === col("cmplt.mtrl_nr") && col("secrd_snp_shot_all.plnt_cd") === col("cmplt.plnt_cd") && col("secrd_snp_shot_all.partition_dt") === col("cmplt.partition_dt") && col("secrd_snp_shot_all.partition_nr") === col("cmplt.part_nr") && col("secrd_snp_shot_all.sls_ord_ln_itm_id") === col("cmplt.sls_ord_ln_itm_id")).drop("cp_prft_ctr_cd").selectExpr("secrd_snp_shot_all.*", "cmplt.mtrl_plnt_pft_cntr_cd as cp_prft_ctr_cd").select(colList.head, colList.tail: _*).repartition(col("secrd_snp_shot_all.sls_ord_id"))

              val df_non_updated_records = df_secrd_snp_shot_all.as("secrd_snp_shot_all").
                filter(col("partition_dt").isin(partitionDate) && col("partition_nr") === partNr).
                join(df_updated_orders.as("cmplt"), col("secrd_snp_shot_all.sls_ord_id") === col("cmplt.sls_ord_id") && col("secrd_snp_shot_all.mtrl_nr") === col("cmplt.mtrl_nr") && col("secrd_snp_shot_all.plnt_cd") === col("cmplt.plnt_cd") && col("secrd_snp_shot_all.partition_dt") === col("cmplt.partition_dt") && col("secrd_snp_shot_all.partition_nr") === col("cmplt.part_nr") && col("secrd_snp_shot_all.sls_ord_ln_itm_id") === col("cmplt.sls_ord_ln_itm_id"), "left_anti").selectExpr("secrd_snp_shot_all.*").
                select(colList.head, colList.tail: _*).repartition(col("sls_ord_id"))

              val df_final = df_non_updated_records.union(df_updated_records)

              val tgtColumns = spark.sql(s"select * from ${dbFin}.secrd_rpt_snpsht_fact").columns

              val dataloadDF = df_final.select(Utilities.loadSelectExpr(df_final.columns, tgtColumns): _*).drop("inst_ts").withColumn("ins_ts", from_unixtime(unix_timestamp()))

              dataloadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbFin+".secrd_rpt_snpsht_fact")

              logger.info("************************************************partition overwritten " + partitionDate + "," + partNr)
            }
          }


          import spark.implicits._
          
          val audEntry = Seq(("PC-RESTATE","Y",srcName,restatementDate,snpshtStrtDt,snpshtEndDt,snpshtNr)).toDF()
          
          audEntry.coalesce(1).write.mode("append").format("orc").insertInto(dbCommon+".bmt_restmnt_trigr_audt_dmnsn")
          
          // send end email
          subject = "PROD:Secured Reporting Profit Center Restatement Success - " + restatementDate

          message = email_content("Profit Center", sourceSystem.mkString(","), snpshtStrtDt, snpshtEndDt, snpshtNr, "end", subject)

          sendemail(recepient, "Restatement_Monitoring@hpe.com", subject, message, "smtp3.hpe.com")

        } else {
          logger.info("+++++++++++++########## restament process suspended ##########+++++++++++++")
          logger.info("+++++++++++++########## restament date," + restatementDate)
        }
      } else {
        logger.info("+++++++++++++########## restament process already executed ##########+++++++++++++")
        logger.info("+++++++++++++########## restament date," + restatementDate)

      }

    } catch {

      case sslException: InterruptedException => {
        logger.error("Interrupted Exception")
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }
      case nseException: NoSuchElementException => {
        logger.error("No Such element found: " + nseException.printStackTrace())
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }
      case anaException: AnalysisException => {
        logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }
      case connException: ConnectException => {
        logger.error("Connection Exception: " + connException.printStackTrace())
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      } case illegalArgs: IllegalArgumentException => {
        logger.error("Connection Exception: " + illegalArgs.printStackTrace())
        auditObj.setAudBatchId(ld_jb_nr)
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }
      case allException: Exception => {
        logger.error("Connection Exception: " + allException.printStackTrace())
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      }

    }
  }

}
package com.hpe.batch.driver.facts.balance_sheet_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
object BsrCash extends App {
 //**************************Driver properties******************************//
  
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val ins_ts=Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
  val upd_ts=null
  val ld_jb_id=ld_jb_nr+'_'+batchId
  logger.info("First log")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

  val transformeSrcdDF = spark.sql("""select count(*) from """ + propertiesObject.getSrcTblConsmtn() )

  val src_count = transformeSrcdDF.count().toInt
  
  var dbNameSrc = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0)
  
  logger.info("Target Database: "+dbNameConsmtn)
  
  logger.info("Source DataBase: "+dbNameSrc)   
  
import spark.implicits._
  val CurrentQuarter=propertiesObject.getCurrentQuarter()
  val PreviousQuarter=propertiesObject.getPreviousQuarter()
  val CurrentYear=propertiesObject.getCurrentYear()
  val PreviousYear=propertiesObject.getPreviousYear()
  try{
  var curr_ytd_val="(1)"
  var prev_ytd_val="(1)"
  var curr_period="(1)"
  var prev_period="(1)"
  var curr_qrtr_query="select"
  var prev_qrtr_query="select"
  //var loadStatus =0
  if (CurrentQuarter=="1"){
      curr_ytd_val="(0,1,2,3)"
      curr_period="(1,2,3)"
    }
    else if(CurrentQuarter=="2"){
      curr_ytd_val="(0,1,2,3,4,5,6)"
      curr_period="(4,5,6)"
    }
    else if(CurrentQuarter=="3"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
      curr_period="(7,8,9)"
    }
    else if(CurrentQuarter=="4"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
      curr_period="(10,11,12)"
    }
    if (PreviousQuarter=="1"){
      prev_ytd_val="(0,1,2,3)"
      prev_period="(1,2,3)"
    }
    else if(PreviousQuarter=="2"){
      prev_ytd_val="(0,1,2,3,4,5,6)"
      prev_period="(4,5,6)"
    }
    else if(PreviousQuarter=="3"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
      prev_period="(7,8,9)"
    }
    else if(PreviousQuarter=="4"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
      prev_period="(10,11,12)"
    }

    
//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_gn_ldgr_itm_cash_aggr_temp")

    val transformedDF = spark.sql(s"""
  --create table ea_fin_r2_2itg.bsr_gn_ldgr_itm_cash_aggr_temp as 
  select entrs_lgl_ent_ldgr_cd, grp_acct_nr,acct_nr,qrtr_attrbt,fscl_yr_nr,
case when fscl_yr_nr ='"""+CurrentYear+"""' and pstg_prd_nr in """+curr_ytd_val+""" then round(sum(gbl_curr_amt),2) else null end as curr_ytd_gbl_curr_amt,
case when fscl_yr_nr ='"""+PreviousYear+"""' and pstg_prd_nr in """+prev_ytd_val+""" then round(sum(gbl_curr_amt),2) else null end as prev_ytd_gbl_curr_amt
 from """+dbNameConsmtn + "." +"""gnrl_ldgr_ln_itm_acct_number2 where gnrl_ldgr_acctng_cd='0L'  
 group by entrs_lgl_ent_ldgr_cd, grp_acct_nr,acct_nr, fscl_yr_nr, qrtr_attrbt,pstg_prd_nr
  """)
  
  transformedDF.createOrReplaceTempView("bsr_gn_ldgr_itm_cash_aggr_temp") 
  
  logger.info("Created view: bsr_gn_ldgr_itm_cash_aggr_temp") 
 
//spark.sql("drop table if exists ea_fin_r2_2itg.gl_line_item_cash_tmp")

 val  gl_line_item_cash_tmp = "gl_line_item_cash_tmp"
  
 val transformedDF2 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.gl_line_item_cash_tmp as 
select a.curr_ytd_gbl_curr_amt,
a.prev_ytd_gbl_curr_amt,
a.grp_acct_nr,
a.acct_nr,
a.entrs_lgl_ent_ldgr_cd,
"""+CurrentYear+""" as curr_year,
"""+PreviousYear+""" as prev_year,
'"""+CurrentQuarter+"""' as curr_quarter,
'"""+PreviousQuarter+"""' as prev_quarter,
b.mapping_country_with_threshold_ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd,
b.mapping_country_with_threshold_rgn_cd,
b.tr_cd,
b.thresholdtext_cd,
b.thresholdvalue_cd,
b.thresholdpercent_cd from bsr_gn_ldgr_itm_cash_aggr_temp a inner join """+dbNameConsmtn + "." +"""cntry_thrs_mpng_cmpny_code b on (a.entrs_lgl_ent_ldgr_cd=b.legalcompanycode_cd) and grp_acct_nr like '00000010%'
  """)

var loadStatus = Utilities.storeDataFrame(transformedDF2, "overwrite", "ORC", dbNameConsmtn + "." + gl_line_item_cash_tmp, configObject)

logger.info("Created table: gl_line_item_cash_tmp")  
  
//GL account cash fact table creation ddls
  
//spark.sql("drop table if exists ea_fin_r2_2itg.GLI_acct_aggrt")

val GLI_acct_aggrt = "GLI_acct_aggrt"

val transformedDF3 = spark.sql(s"""
  --create table ea_fin_r2_2itg.GLI_acct_aggrt as 
select entrs_lgl_ent_ldgr_cd, acct_nr, grp_acct_nr, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt, sum(gbl_curr_amt) as gbl_curr_amt  from """+dbNameConsmtn + "." +"""gnrl_ldgr_ln_itm_acct_number2 
where gnrl_ldgr_acctng_cd='0L' and fscl_yr_nr in('"""+CurrentYear+"""','"""+PreviousYear+"""') 
and case when fscl_yr_nr ='"""+PreviousYear+"""' then pstg_prd_nr in """+prev_period+""" 
when fscl_yr_nr='"""+CurrentYear+"""' then pstg_prd_nr in """+curr_period+""" else Null END 
group by 
entrs_lgl_ent_ldgr_cd, acct_nr, grp_acct_nr, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt
  """)
 
loadStatus = Utilities.storeDataFrame(transformedDF3, "overwrite", "ORC", dbNameConsmtn + "." + GLI_acct_aggrt, configObject)

logger.info("Created table: GLI_acct_aggrt")    
  
//spark.sql("drop table if exists ea_fin_r2_2itg.GLI_acct_aggrt_ofst")


val transformedDF4 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.GLI_acct_aggrt_ofst as 
select 
a.entrs_lgl_ent_ldgr_cd, a.acct_nr, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt,
b.acct_nr as ofst_acct_nr_calc,
b.grp_acct_nr as ofst_grp_acct_nr_calc,
sum(b.gbl_curr_amt) as ofset_gbl_curr_amt
from """+dbNameConsmtn + "." +"""GLI_acct_aggrt a, """+dbNameConsmtn + "." +"""GLI_acct_aggrt b 
where a.acctng_dcmt_id= b.acctng_dcmt_id and a.acct_nr != b.acct_nr and a.fscl_yr_nr=b.fscl_yr_nr and a.entrs_lgl_ent_ldgr_cd = b.entrs_lgl_ent_ldgr_cd group by 
a.entrs_lgl_ent_ldgr_cd, a.acct_nr, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt, b.acct_nr, b.grp_acct_nr
  """)

transformedDF4.createOrReplaceTempView("GLI_acct_aggrt_ofst") 
  
logger.info("Created view: GLI_acct_aggrt_ofst") 
  
//spark.sql("drop table if exists ea_fin_r2_2itg.csh_acc_drv_tbl")

val transformedDF5 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.csh_acc_drv_tbl as 
select 
a.entrs_lgl_ent_ldgr_cd, a.acct_nr, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt, a.ofst_acct_nr_calc, a.ofst_grp_acct_nr_calc, a.ofset_gbl_curr_amt,
b.csh_flw_stmt ,  b.drvr, b.sb_drvr 
from GLI_acct_aggrt_ofst a left join """+dbNameConsmtn + "." +"""csh_acc_tbl b on a.ofst_acct_nr_calc=b.gl_acct where a.grp_acct_nr < '0000001100'
  """)

transformedDF5.createOrReplaceTempView("csh_acc_drv_tbl") 
  
logger.info("Created view: csh_acc_drv_tbl")   
  
//spark.sql("drop table if exists ea_fin_r2_2itg.csh_acc_drv_tbl_aggrgt")

val csh_acc_drv_tbl_aggrgt="csh_acc_drv_tbl_aggrgt"

val transformedDF6 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.csh_acc_drv_tbl_aggrgt as
select
a.entrs_lgl_ent_ldgr_cd, a.acct_nr, a.grp_acct_nr,
case when a.fscl_yr_nr = """+CurrentYear+""" then fscl_yr_nr else null end as curr_year,
case when a.fscl_yr_nr = """+PreviousYear+""" then fscl_yr_nr else null end as prev_year,
case when a.qrtr_attrbt = """+CurrentQuarter+""" then qrtr_attrbt else null end as curr_quarter,
case when a.qrtr_attrbt = """+PreviousQuarter+""" then qrtr_attrbt else null end as prev_quarter,
a.pstg_prd_nr,
a.ofst_acct_nr_calc,
a.ofst_grp_acct_nr_calc,
a.csh_flw_stmt,
a.drvr,
a.sb_drvr,
b.mapping_country_with_threshold_ctry_cd as ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd as countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd as rgn_cd, 
b.tr_cd as tr_cd,
b.thresholdtext_cd as thresholdtext_cd,
b.thresholdvalue_cd, 
b.thresholdpercent_cd,
case when fscl_yr_nr = """+CurrentYear+""" and pstg_prd_nr in """+curr_period+""" then round(sum(ofset_gbl_curr_amt),2) else 0 end as  curr_qtr_amt,
case when fscl_yr_nr = """+PreviousYear+""" and pstg_prd_nr in """+prev_period+""" then round(sum(ofset_gbl_curr_amt),2) else 0 end as   prior_qtr_amt
from csh_acc_drv_tbl a inner join """+dbNameConsmtn + "." +"""cntry_thrs_mpng_cmpny_code b on a.entrs_lgl_ent_ldgr_cd = b.legalcompanycode_cd 
group by a.entrs_lgl_ent_ldgr_cd, a.acct_nr, a.grp_acct_nr,  a.fscl_yr_nr, a.qrtr_attrbt, a.pstg_prd_nr, a.ofst_acct_nr_calc, a.ofst_grp_acct_nr_calc, a.csh_flw_stmt, a.drvr, a.sb_drvr,
b.mapping_country_with_threshold_ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd,
b.tr_cd,
b.thresholdtext_cd, 
b.thresholdvalue_cd,
b.thresholdpercent_cd
  """)

loadStatus = Utilities.storeDataFrame(transformedDF6, "overwrite", "ORC", dbNameConsmtn + "." + csh_acc_drv_tbl_aggrgt, configObject)

logger.info("Created table: csh_acc_drv_tbl_aggrgt")      
  
//spark.sql("drop table if exists ea_fin_r2_2itg.cash_gl_acc_fact")

val cash_gl_acc_fact="cash_gl_acc_fact"

val transformedDF7 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.cash_gl_acc_fact as 
select entrs_lgl_ent_ldgr_cd,
acct_nr,
grp_acct_nr,
curr_year,
prev_year,
curr_quarter,
prev_quarter,
pstg_prd_nr,
ofst_acct_nr_calc,
ofst_grp_acct_nr_calc,
csh_flw_stmt,
drvr,
sb_drvr,
ctry_cd,
countrygroup_cd,
rgn_cd,
tr_cd,
thresholdtext_cd,
thresholdvalue_cd,
thresholdpercent_cd,
curr_qtr_amt,
prior_qtr_amt from """+dbNameConsmtn + "." +"""csh_acc_drv_tbl_aggrgt
union all
select
entrs_lgl_ent_ldgr_cd,
acct_nr,
grp_acct_nr,
curr_year,
prev_year,
curr_quarter,
prev_quarter,
999 as pstg_prd_nr,
NULL as ofst_acct_nr_calc,
NULL as ofst_grp_acct_nr_calc,
'YTD Total' as csh_flw_stmt,
'Cash account YTD  - INPUT' as drvr,
'Account Balance YTD' as sb_drvr,
mapping_country_with_threshold_ctry_cd,
mapping_country_with_threshold_countrygroup_cd,
mapping_country_with_threshold_rgn_cd,
tr_cd,
thresholdtext_cd,
thresholdvalue_cd,
thresholdpercent_cd,
curr_ytd_gbl_curr_amt,
prev_ytd_gbl_curr_amt from """+dbNameConsmtn + "." +"""gl_line_item_cash_tmp
  """)

loadStatus = Utilities.storeDataFrame(transformedDF7, "overwrite", "ORC", dbNameConsmtn + "." + cash_gl_acc_fact, configObject)

logger.info("Created table: cash_gl_acc_fact")      
  
// group account cash table creation
  
//spark.sql("drop table if exists ea_fin_r2_2itg.GLI_grp_acct_aggrt")

val GLI_grp_acct_aggrt = "GLI_grp_acct_aggrt"

val transformedDF8 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.GLI_grp_acct_aggrt as 
select entrs_lgl_ent_ldgr_cd, grp_acct_nr, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt, sum(gbl_curr_amt) as gbl_curr_amt 
from """+dbNameConsmtn + "." +"""gnrl_ldgr_ln_itm_acct_number2 where gnrl_ldgr_acctng_cd='0L'  
and fscl_yr_nr in('"""+CurrentYear+"""','"""+PreviousYear+"""') and case when fscl_yr_nr ='"""+PreviousYear+"""' then pstg_prd_nr in """+prev_period+""" 
when fscl_yr_nr='"""+CurrentYear+"""' then pstg_prd_nr in """+curr_period+""" else Null END 
group by 
entrs_lgl_ent_ldgr_cd, grp_acct_nr, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt
  """)
  
loadStatus = Utilities.storeDataFrame(transformedDF8, "overwrite", "ORC", dbNameConsmtn + "." + GLI_grp_acct_aggrt, configObject)

logger.info("Created table: GLI_grp_acct_aggrt")   

  
//spark.sql("drop table if exists ea_fin_r2_2itg.GLI_grp_acct_aggrt_ofst")

val transformedDF9 = spark.sql(s"""
  create table ea_fin_r2_2itg.GLI_grp_acct_aggrt_ofst as 
select 
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt,
b.grp_acct_nr as ofst_grp_acct_nr_calc,
sum(b.gbl_curr_amt) as ofset_gbl_curr_amt
from """+dbNameConsmtn + "." +"""GLI_grp_acct_aggrt a, """+dbNameConsmtn + "." +"""GLI_grp_acct_aggrt b 
where a.acctng_dcmt_id= b.acctng_dcmt_id and a.grp_acct_nr != b.grp_acct_nr and a.fscl_yr_nr=b.fscl_yr_nr and a.entrs_lgl_ent_ldgr_cd = b.entrs_lgl_ent_ldgr_cd group by 
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt, b.grp_acct_nr
  """)

transformedDF9.createOrReplaceTempView("GLI_grp_acct_aggrt_ofst")  
  
//spark.sql("drop table if exists ea_fin_r2_2itg.csh_grp_acc_drv_tbl")

val transformedDF10 = spark.sql(s"""
  create table ea_fin_r2_2itg.csh_grp_acc_drv_tbl as 
select 
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt, a.ofst_grp_acct_nr_calc, a.ofset_gbl_curr_amt,
b.csh_flw_stmt ,  b.drvr
from GLI_grp_acct_aggrt_ofst a left join ( select distinct gro_acct_nr, csh_flw_stmt, drvr from """+dbNameConsmtn + "." +"""csh_acc_tbl) b on a.ofst_grp_acct_nr_calc=b.gro_acct_nr where a.grp_acct_nr < '0000001100'
  """)
  
transformedDF10.createOrReplaceTempView("csh_grp_acc_drv_tbl") 
  
//spark.sql("drop table if exists ea_fin_r2_2itg.csh_grp_acc_drv_tbl_aggrgt")

val csh_grp_acc_drv_tbl_aggrgt ="csh_grp_acc_drv_tbl_aggrgt"

val transformedDF11 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.csh_grp_acc_drv_tbl_aggrgt as
select
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr,
case when a.fscl_yr_nr = """+CurrentYear+""" then fscl_yr_nr else null end as curr_year,
case when a.fscl_yr_nr = """+PreviousYear+""" then fscl_yr_nr else null end as prev_year,
case when a.qrtr_attrbt = """+CurrentQuarter+""" then qrtr_attrbt else null end as curr_quarter,
case when a.qrtr_attrbt = """+PreviousQuarter+""" then qrtr_attrbt else null end as prev_quarter,
a.pstg_prd_nr,
a.ofst_grp_acct_nr_calc,
a.csh_flw_stmt,
a.drvr,
b.mapping_country_with_threshold_ctry_cd as ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd as countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd as rgn_cd, 
b.tr_cd as tr_cd,
b.thresholdtext_cd as thresholdtext_cd,
b.thresholdvalue_cd, 
b.thresholdpercent_cd,
case when fscl_yr_nr = """+CurrentYear+""" and pstg_prd_nr in """+curr_period+""" then round(sum(a.ofset_gbl_curr_amt),2) else 0 end as  curr_qtr_amt,
case when fscl_yr_nr = """+PreviousYear+""" and pstg_prd_nr in """+prev_period+""" then round(sum(a.ofset_gbl_curr_amt),2) else 0 end as   prior_qtr_amt
from csh_grp_acc_drv_tbl a inner join """+dbNameConsmtn + "." +"""cntry_thrs_mpng_cmpny_code b on a.entrs_lgl_ent_ldgr_cd = b.legalcompanycode_cd 
group by a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr,  a.fscl_yr_nr, a.qrtr_attrbt, a.pstg_prd_nr, a.ofst_grp_acct_nr_calc, a.csh_flw_stmt, a.drvr,
b.mapping_country_with_threshold_ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd,
b.tr_cd,
b.thresholdtext_cd, 
b.thresholdvalue_cd,
b.thresholdpercent_cd
  """)
  
loadStatus = Utilities.storeDataFrame(transformedDF11, "overwrite", "ORC", dbNameConsmtn + "." + csh_grp_acc_drv_tbl_aggrgt, configObject)

logger.info("Created table: csh_grp_acc_drv_tbl_aggrgt")     
  
//spark.sql("drop table if exists ea_fin_r2_2itg.cash_grp_acc_fact")

val cash_grp_acc_fact="cash_grp_acc_fact"

val transformedDF12 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.cash_grp_acc_fact as 
 select entrs_lgl_ent_ldgr_cd,
grp_acct_nr,
curr_year,
prev_year,
curr_quarter,
prev_quarter,
pstg_prd_nr,
ofst_grp_acct_nr_calc,
csh_flw_stmt,
drvr,
ctry_cd,
countrygroup_cd,
rgn_cd,
tr_cd,
thresholdtext_cd,
thresholdvalue_cd,
thresholdpercent_cd,
curr_qtr_amt,
prior_qtr_amt from """+dbNameConsmtn + "." +"""csh_grp_acc_drv_tbl_aggrgt
union all
select
entrs_lgl_ent_ldgr_cd,
grp_acct_nr,
curr_year,
prev_year,
curr_quarter,
prev_quarter,
999 as pstg_prd_nr,
NULL as ofst_grp_acct_nr_calc,
'YTD Total' as csh_flw_stmt,
'Cash account YTD  - INPUT' as drvr,
mapping_country_with_threshold_ctry_cd,
mapping_country_with_threshold_countrygroup_cd,
mapping_country_with_threshold_rgn_cd,
tr_cd,
thresholdtext_cd,
thresholdvalue_cd,
thresholdpercent_cd,
sum(curr_ytd_gbl_curr_amt) as curr_ytd_gbl_curr_amt,
sum(prev_ytd_gbl_curr_amt) as prev_ytd_gbl_curr_amt from """+dbNameConsmtn + "." +"""gl_line_item_cash_tmp group by entrs_lgl_ent_ldgr_cd,grp_acct_nr,curr_year,prev_year,curr_quarter,prev_quarter,mapping_country_with_threshold_ctry_cd,mapping_country_with_threshold_countrygroup_cd,mapping_country_with_threshold_rgn_cd,tr_cd,thresholdtext_cd,thresholdvalue_cd,thresholdpercent_cd
  """)

loadStatus = Utilities.storeDataFrame(transformedDF12, "overwrite", "ORC", dbNameConsmtn + "." + cash_grp_acc_fact, configObject)

logger.info("Created table: cash_grp_acc_fact")      

//Consolidation cash fact table creation 
  
//spark.sql("drop table if exists ea_fin_r2_2itg.GLI_grp_cons")

val transformedDF13 = spark.sql(s"""
  --create table ea_fin_r2_2itg.GLI_grp_cons as 
select entrs_lgl_ent_ldgr_cd, grp_acct_nr, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt, sum(gbl_curr_amt) as gbl_curr_amt,
case when grp_acct_nr < '0000001100' then '0000099999' else grp_acct_nr end as grp_acct_nr_calc
from """+dbNameConsmtn + "." +"""gnrl_ldgr_ln_itm_acct_number2 where gnrl_ldgr_acctng_cd='0L' group by
entrs_lgl_ent_ldgr_cd, grp_acct_nr, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt
  """)

transformedDF13.createOrReplaceTempView("GLI_grp_cons")  
  
//spark.sql("drop table if exists ea_fin_r2_2itg.GLI_grp_cons_aggrt")

val GLI_grp_cons_aggrt ="GLI_grp_cons_aggrt"

val transformedDF14 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.GLI_grp_cons_aggrt as 
select entrs_lgl_ent_ldgr_cd, grp_acct_nr_calc as grp_acct_nr, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt, sum(gbl_curr_amt) as gbl_curr_amt  
from GLI_grp_cons where fscl_yr_nr in('"""+CurrentYear+"""','"""+PreviousYear+"""') 
and case when fscl_yr_nr ='"""+PreviousYear+"""' then pstg_prd_nr in """+prev_period+""" 
when fscl_yr_nr='"""+CurrentYear+"""' then pstg_prd_nr in """+curr_period+""" else Null END 
group by entrs_lgl_ent_ldgr_cd, grp_acct_nr_calc, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt
  """)

loadStatus = Utilities.storeDataFrame(transformedDF14, "overwrite", "ORC", dbNameConsmtn + "." + GLI_grp_cons_aggrt, configObject)

logger.info("Created table: GLI_grp_cons_aggrt")

//spark.sql("drop table if exists ea_fin_r2_2itg.GLI_grp_cons_aggrt_ofst")

val transformedDF15 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.GLI_grp_cons_aggrt_ofst as 
select 
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt,
b.grp_acct_nr as ofst_grp_acct_nr_calc,
sum(b.gbl_curr_amt) as ofset_gbl_curr_amt
from """+dbNameConsmtn + "." +"""GLI_grp_cons_aggrt a, """+dbNameConsmtn + "." +"""GLI_grp_cons_aggrt b 
where a.acctng_dcmt_id= b.acctng_dcmt_id and a.grp_acct_nr != b.grp_acct_nr and a.fscl_yr_nr=b.fscl_yr_nr and a.entrs_lgl_ent_ldgr_cd = b.entrs_lgl_ent_ldgr_cd group by 
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt, b.grp_acct_nr
  """)

transformedDF15.createOrReplaceTempView("GLI_grp_cons_aggrt_ofst") 
  
//spark.sql("drop table if exists ea_fin_r2_2itg.csh_grp_cons_drv_tbl")

val transformedDF16 = spark.sql(s"""
  --create table ea_fin_r2_2itg.csh_grp_cons_drv_tbl as 
select 
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt, a.ofst_grp_acct_nr_calc, a.ofset_gbl_curr_amt,
b.csh_flw_stmt ,  b.drvr
from GLI_grp_cons_aggrt_ofst a left join ( select distinct gro_acct_nr, csh_flw_stmt, drvr from """+dbNameConsmtn + "." +"""csh_acc_tbl) b on a.ofst_grp_acct_nr_calc=b.gro_acct_nr where 
a.grp_acct_nr = '0000099999'
  """)

transformedDF16.createOrReplaceTempView("csh_grp_cons_drv_tbl")  
  
//spark.sql("drop table if exists ea_fin_r2_2itg.csh_grp_cons_drv_tbl_aggrgt")

val csh_grp_cons_drv_tbl_aggrgt ="csh_grp_cons_drv_tbl_aggrgt"

val transformedDF17 = spark.sql(s"""
--  create table ea_fin_r2_2itg.csh_grp_cons_drv_tbl_aggrgt as
select
a.entrs_lgl_ent_ldgr_cd, "Consolidated" as grp_acct_nr,
case when a.fscl_yr_nr = """+CurrentYear+""" then fscl_yr_nr else null end as curr_year,
case when a.fscl_yr_nr = """+PreviousYear+""" then fscl_yr_nr else null end as prev_year,
case when a.qrtr_attrbt = """+CurrentQuarter+""" then qrtr_attrbt else null end as curr_quarter,
case when a.qrtr_attrbt = """+PreviousQuarter+""" then qrtr_attrbt else null end as prev_quarter,
a.pstg_prd_nr,
a.ofst_grp_acct_nr_calc,
a.csh_flw_stmt,
a.drvr,
b.mapping_country_with_threshold_ctry_cd as ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd as countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd as rgn_cd, 
b.tr_cd as tr_cd,
b.thresholdtext_cd as thresholdtext_cd,
b.thresholdvalue_cd, 
b.thresholdpercent_cd,
case when fscl_yr_nr = """+CurrentYear+""" and pstg_prd_nr in """+curr_period+""" then round(sum(a.ofset_gbl_curr_amt),2) else 0 end as  curr_qtr_amt,
case when fscl_yr_nr = """+PreviousYear+""" and pstg_prd_nr in """+prev_period+""" then round(sum(a.ofset_gbl_curr_amt),2) else 0 end as   prior_qtr_amt
from csh_grp_cons_drv_tbl a inner join """+dbNameConsmtn + "." +"""cntry_thrs_mpng_cmpny_code b on a.entrs_lgl_ent_ldgr_cd = b.legalcompanycode_cd 
group by a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr,  a.fscl_yr_nr, a.qrtr_attrbt, a.pstg_prd_nr, a.ofst_grp_acct_nr_calc, a.csh_flw_stmt, a.drvr,
b.mapping_country_with_threshold_ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd,
b.tr_cd,
b.thresholdtext_cd, 
b.thresholdvalue_cd,
b.thresholdpercent_cd
  """)

loadStatus = Utilities.storeDataFrame(transformedDF17, "overwrite", "ORC", dbNameConsmtn + "." + csh_grp_cons_drv_tbl_aggrgt, configObject)

logger.info("Created table: csh_grp_cons_drv_tbl_aggrgt")    

//spark.sql("drop table if exists ea_fin_r2_2itg.cash_grp_cons_fact")

val cash_grp_cons_fact ="cash_grp_cons_fact"

val transformedDF18 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.cash_grp_cons_fact as 
 select entrs_lgl_ent_ldgr_cd,
grp_acct_nr,
curr_year,
prev_year,
curr_quarter,
prev_quarter,
pstg_prd_nr,
ofst_grp_acct_nr_calc,
csh_flw_stmt,
drvr,
ctry_cd,
countrygroup_cd,
rgn_cd,
tr_cd,
thresholdtext_cd,
thresholdvalue_cd,
thresholdpercent_cd,
curr_qtr_amt,
prior_qtr_amt from """+dbNameConsmtn + "." +"""csh_grp_cons_drv_tbl_aggrgt
union all
select
entrs_lgl_ent_ldgr_cd,
grp_acct_nr,
curr_year,
prev_year,
curr_quarter,
prev_quarter,
999 as pstg_prd_nr,
NULL as ofst_grp_acct_nr_calc,
CASE WHEN grp_acct_nr='0000001001' THEN "Cash account YTD@FCBS157" else "Cash account YTD@FCBS12" END as csh_flw_stmt,
NULL as drvr,
mapping_country_with_threshold_ctry_cd,
mapping_country_with_threshold_countrygroup_cd,
mapping_country_with_threshold_rgn_cd,
tr_cd,
thresholdtext_cd,
thresholdvalue_cd,
thresholdpercent_cd,
sum(curr_ytd_gbl_curr_amt) as curr_ytd_gbl_curr_amt,
sum(prev_ytd_gbl_curr_amt) as prev_ytd_gbl_curr_amt from """+dbNameConsmtn + "." +"""gl_line_item_cash_tmp group by entrs_lgl_ent_ldgr_cd,grp_acct_nr,curr_year,prev_year,curr_quarter,prev_quarter,mapping_country_with_threshold_ctry_cd,mapping_country_with_threshold_countrygroup_cd,mapping_country_with_threshold_rgn_cd,tr_cd,thresholdtext_cd,thresholdvalue_cd,thresholdpercent_cd
  """)

loadStatus = Utilities.storeDataFrame(transformedDF18, "overwrite", "ORC", dbNameConsmtn + "." + cash_grp_cons_fact, configObject)

logger.info("Created table: cash_grp_cons_fact")    

    //************************Completion Audit Entries*******************************//

val tgt_count = transformedDF18.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    //auditObj.setAudObjectName("blnce_sht_reprtg_cash_fact")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(0)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } 
  
  catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}

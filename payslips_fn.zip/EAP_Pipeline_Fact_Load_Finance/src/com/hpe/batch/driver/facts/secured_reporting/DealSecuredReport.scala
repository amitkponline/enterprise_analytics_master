package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source

object DealSecuredReport extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  logger.info("//*********************** Log Start for DealSecuredReport.scala ************************//")
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  logger.info("+++++++++++++############## properties file:" + propertiesFilePath)
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  logger.info("+++++++++++++############## environment properties file:" + envPropertiesFilePath)
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  logger.info("+++++++++++++############## audit table:" + auditTbl)
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  if (sqlCon == null) {
    logger.error("+++++++++++++############## MYSQL Connection Not Established")
    throw new NullPointerException("Please update tgtTblConsmtn properties to add database name!")
  }
  var fileBasePath = propertiesObject.getFileBasePath()
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val objName = propertiesObject.getObjName().trim()
  val dbCommonName = propertiesObject.getDbName().trim()
  //val tgtTblConsmtn = "ea_fin_r2_2itg.secrd_rpt_fact_bkp_1710"

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  try {

    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn, fileBasePath))

    //***************************Audit Properties********************************//

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_secrd_deal_fact_load")
    auditObj.setAudObjectName(objName)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)

    if (tgtTblConsmtn.split("\\.", -1).size != 2) {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val tgtColumns = spark.sql("select * from " + tgtTblConsmtn + " limit 0").columns
    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    /*
     * Selecting deal dimensions deal_dmnsn & deal_itm_dmnsn
     * Filter: 1 year data is selected from the current date
     *
     */

    val dealDimSelectDF = spark.sql(s"""
    select 
      deal_dmnsn.deal_ky,
      deal_id,
      deal_opty_qt_dn,
      deal_cust_prty_id,
      deal_cust_sgm_cd,
      deal_cust_engmnt_typ_nm,
      deal_dmnsn.deal_acct_mgmt_lvl_2_id,
      deal_dmnsn.deal_acct_mgmt_lvl_2_nm,
      deal_dmnsn.deal_bsn_mdl_cd,
      deal_dmnsn.deal_bsn_mdl_dn,
      deal_dmnsn.deal_cust_ltn_nm,
      deal_dmnsn.deal_cust_nn_ltn_nm,
      deal_dmnsn.deal_rgst_id,
      deal_dmnsn.deal_deal_src_sys_cd as deal_src_sys_cd,
      deal_dmnsn.deal_deal_src_sys_dn,
      deal_dmnsn.deal_stts_nm,
      deal_dmnsn.deal_sb_typ_cd,
      deal_dmnsn.deal_typ_cd,
      deal_dmnsn.deal_vrsn_nr,
      deal_dmnsn.deal_vrsn_stts_nm,
      deal_dmnsn.deal_grphc_scp_nm,
      deal_dmnsn.deal_indy_id,
      deal_dmnsn.deal_last_updd_by_eml_id,
      deal_dmnsn.deal_lead_bsn_unt_cd,
      deal_dmnsn.deal_misc_crg_cd,
      deal_dmnsn.deal_prnt_org_id,
      deal_dmnsn.deal_prnt_org_nm,
      deal_dmnsn.deal_pyr_prty_id,
      deal_dmnsn.deal_sls_tty_acct_cnflct_ind,
      deal_dmnsn.deal_sls_tty_acct_nm,
      deal_dmnsn.deal_src_deal_id,
      deal_dmnsn.deal_vld_end_ts,
      deal_dmnsn.deal_vld_strt_ts,
      deal_dmnsn.deal_ins_ts,
      deal_dmnsn.deal_upd_ts,
      deal_dmnsn.ins_gmt_ts as ins_gmt_ts,
      deal_dmnsn.upd_gmt_ts as upd_gmt_ts,
      deal_dmnsn.src_sys_extrc_gmt_ts as src_sys_extrc_gmt_ts,
      deal_dmnsn.src_sys_btch_nr as src_sys_btch_nr,
      deal_dmnsn.fl_nm as fl_nm,
      deal_dmnsn.ld_jb_nr as ld_jb_nr,
      deal_dmnsn.deal_bll_to_prty_id as bll_to_cd,
      deal_dmnsn.deal_ctry_cd as ctry_cd,
      deal_dmnsn.deal_rte_cd as rte_cd,
      deal_dmnsn.deal_rte_to_mkt_typ_cd as mkt_rte_cd,
      deal_dmnsn.deal_sls_tty_acct_id as sls_tty_id,
      deal_dmnsn.deal_shp_to_prty_id as shp_to_cd,
      deal_end_cust_psls_prty_id AS deal_end_cust_presls_prty_id,
      deal_opsi_id AS deal_other_prty_site_insn_id,
      deal_org_id AS deal_org_id,
      deal_site_insn_id AS deal_site_insn_id,
      --deal_sls_tty_acct_id AS sls_tty_id,
      deal_prty_rol_deal_id AS deal_prty_rol_deal_id,
      deal_rslr_a_dmnsn.deal_rslr_a_prty_id AS rslr_nr,
      deal_dmnsn.deal_cust_prty_id as deal_prty_id
    FROM ${dbCommonName}.deal_dmnsn deal_dmnsn
    LEFT OUTER JOIN (select * from (select *,row_number() over (partition by deal_ky order by ins_gmt_ts) as rw_nm from ${dbCommonName}.deal_prty_rol_dmnsn) where rw_nm = 1 ) deal_prty_rol_dmnsn ON 
	    deal_dmnsn.deal_ky =  deal_prty_rol_dmnsn.deal_ky 
    LEFT OUTER JOIN (select * from (select *,row_number() over (partition by deal_ky order by ins_gmt_ts) as rw_nm from ${dbCommonName}.deal_rslr_a_dmnsn) where rw_nm = 1 ) deal_rslr_a_dmnsn ON
	    deal_dmnsn.deal_ky = deal_rslr_a_dmnsn.deal_ky
	  WHERE
	    deal_dmnsn.deal_id  NOT IN( SELECT distinct sales_shipment_dmnsn.deal_id_nm 
      FROM ${dbCommonName}.sales_shipment_ref sales_shipment_dmnsn where sales_shipment_dmnsn.deal_id_nm is not null) and 
      deal_dmnsn.deal_vld_strt_ts  >= date_sub(to_date(from_unixtime(unix_timestamp())), 365)
	    """)

    val dealJoinDF = dealDimSelectDF.as("deal_dmnsn").selectExpr(
      "concat(deal_dmnsn.deal_ky,crc32(LOWER(CONCAT(COALESCE(deal_id,''),COALESCE(ld_jb_nr,''))))) as secrd_rpt_fact_ky", "crc32(LOWER(COALESCE(deal_id,''))) as deal_ky", "crc32(LOWER(COALESCE(deal_opty_qt_dn,''))) as opty_ky", "deal_id as deal_id", "deal_opty_qt_dn as opty_id", "'DEALS' as src_sys_cd", "deal_cust_prty_id as end_cust_cd", "deal_cust_sgm_cd as cust_sgm_cd", "CURRENT_TIMESTAMP as ins_ts", "deal_cust_engmnt_typ_nm as bsn_rshp_typ_cd", "deal_dmnsn.deal_acct_mgmt_lvl_2_id", "deal_dmnsn.deal_acct_mgmt_lvl_2_nm", "deal_dmnsn.deal_bsn_mdl_cd", "deal_dmnsn.deal_bsn_mdl_dn", "deal_dmnsn.deal_cust_ltn_nm", "deal_dmnsn.deal_cust_nn_ltn_nm", "deal_dmnsn.deal_rgst_id", "deal_dmnsn.deal_src_sys_cd", "deal_dmnsn.deal_deal_src_sys_dn", "deal_dmnsn.deal_stts_nm", "deal_dmnsn.deal_sb_typ_cd", "deal_dmnsn.deal_typ_cd", "deal_dmnsn.deal_vrsn_nr", "deal_dmnsn.deal_vrsn_stts_nm", "deal_dmnsn.deal_grphc_scp_nm", "deal_dmnsn.deal_indy_id", "deal_dmnsn.deal_last_updd_by_eml_id", "deal_dmnsn.deal_lead_bsn_unt_cd", "deal_dmnsn.deal_misc_crg_cd", "deal_dmnsn.deal_prnt_org_id", "deal_dmnsn.deal_prnt_org_nm", "deal_dmnsn.deal_pyr_prty_id", "deal_dmnsn.deal_sls_tty_acct_cnflct_ind", "deal_dmnsn.deal_sls_tty_acct_nm", "deal_dmnsn.deal_src_deal_id", "deal_dmnsn.deal_vld_end_ts", "deal_dmnsn.deal_vld_strt_ts", "deal_dmnsn.deal_ins_ts", "deal_dmnsn.deal_upd_ts", "deal_dmnsn.ins_gmt_ts as ins_gmt_ts", "deal_dmnsn.upd_gmt_ts as upd_gmt_ts", "deal_dmnsn.src_sys_extrc_gmt_ts as src_sys_extrc_gmt_ts", "deal_dmnsn.src_sys_btch_nr as src_sys_btch_nr", "deal_dmnsn.fl_nm as fl_nm", "deal_dmnsn.ld_jb_nr as ld_jb_nr", "deal_dmnsn.bll_to_cd", "deal_dmnsn.ctry_cd", "deal_dmnsn.rte_cd", "deal_dmnsn.mkt_rte_cd", "deal_dmnsn.sls_tty_id", "deal_dmnsn.shp_to_cd").distinct

    val finalLoadDF = dealJoinDF.select(Utilities.loadSelectExpr(dealJoinDF.columns, tgtColumns): _*)

    finalLoadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblConsmtn)

    val tgtCount = spark.sql(s"select * from ${tgtTblConsmtn} where src_sys_cd = 'DEALS'").count.toInt

    tgtCount match {
      case 0 =>
        logger.info("//************* Data Load Failed")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_Deal_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_Deal_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_Deal_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_Deal_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_Deal_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }

  } finally {
    logger.info("//*********************** Log End for DealSecuredReport.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
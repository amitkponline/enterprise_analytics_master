package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.Column

object SecuredSalesShipmentConsumption extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true
  val logger = Logger.getLogger(getClass.getName)
  val objName = propertiesObject.getObjName().trim()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  var dbNameRef: String = null
  var refTable: String = null
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim
  val srcCol = propertiesObject.getSrcCol().trim
  val naturalKey = propertiesObject.getNaturalKeys().trim
  val latestEntryKey = propertiesObject.getLatestEntryKey().trim
  val groupByKey = propertiesObject.getGroupByKey().trim

  logger.info("//*********************** Log Start for SecuredSalesShipmentConsumption.scala ************************//")

  def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
    val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*).desc)
    val rowDF = df.withColumn("rn", dense_rank().over(part))
    val res = rowDF.filter("rn==1").drop("rn")
    res
  }

  //***************************Audit Properties********************************//
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_secured_serp_sales_ship_dmnsn")
  auditObj.setAudObjectName(objName)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)

  try {

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    //****************** Set Refine Table Name *********************\\
    if (propertiesObject.getTgtTblRef().trim().split("\\.", -1).size == 2) {
      dbNameRef = propertiesObject.getTgtTblRef().trim().split("\\.", -1)(0)
      refTable = propertiesObject.getTgtTblRef().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblRef properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }
    // Take last processed time-stamp from target table

    val lastModifiedTime = Utilities.readHistMaxLoadTimestampFact(sqlCon, propertiesObject.getObjName())
    logger.info("+++++++++++++++############## Last Modified Time :" + lastModifiedTime)

    // Take delta from sales shipment refine table

    val srcDF = spark.sql(s"select ${srcCol} from ${dbNameRef}.${refTable} where from_unixtime(unix_timestamp(ins_gmt_ts),'yyyyMMddHHmmss') > ${lastModifiedTime}")

    val DFcolNames = srcDF.columns.toList

    val deltaSrcDF = DFcolNames.foldLeft(srcDF)((srcDF, c) =>
      srcDF.withColumnRenamed(c.toString.split(",")(0), c.toString.toLowerCase()))

    val srcCount = deltaSrcDF.count.toInt

    val maxTimeStamp = deltaSrcDF.agg(max(col("ins_gmt_ts")).as("max_ins_gmt_ts")).
      selectExpr("coalesce(from_unixtime(unix_timestamp(max(max_ins_gmt_ts)),'yyyyMMddHHmmss'),'19000101000000')").first.get(0)

    srcCount match {

      case 0 =>
        logger.info("+++++++++++++++############## No incremental data to process ##############+++++++++++++++")
      case _ =>

        // Get latest records from delta

        val deDupDeltaSrcDF = getLatestRecs(deltaSrcDF, groupByKey.split(",").toList, latestEntryKey.split(",").toList).withColumn("period", lit(expr(s"substr(upd_gmt_ts,0,7)")))

        val tgtDF = spark.sql(s"select * from ${dbNameConsmtn}.${consmptnTable}")

        val tgtColumns = tgtDF.columns

        val existingTgtCnt = tgtDF.count.toInt

        existingTgtCnt match {
          case 0 =>

            logger.info("+++++++++++++++############## Full Load ##############+++++++++++++++")

            val loadDF = deDupDeltaSrcDF.select(Utilities.loadSelectExpr(deDupDeltaSrcDF.columns, tgtColumns): _*)

            loadDF.distinct.repartition(10).write.mode("Overwrite").format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)

            logger.info("+++++++++++++++############## Data Load Complete ##############+++++++++++++++")

          case _ =>

            logger.info("+++++++++++++++############## Incremental Load ##############+++++++++++++++")

            val latestIncrementalTransations = deDupDeltaSrcDF.select(naturalKey.split(",").toList.head, naturalKey.split(",").toList.tail: _*)

            val colExpr: Column = tgtDF(naturalKey.split(",").toSeq.head) <=> latestIncrementalTransations(naturalKey.split(",").toSeq.head)
            val fullExpr = naturalKey.split(",").toSeq.tail.foldLeft(colExpr) {
              (colExpr, p) => colExpr && tgtDF(p) <=> latestIncrementalTransations(p)
            }

            logger.info("+++++++++++++++############## Join Expression: " + fullExpr)

            val commonDF = tgtDF.join(latestIncrementalTransations, fullExpr).persist(StorageLevel.MEMORY_AND_DISK_SER)

            commonDF.count match {
              case 0 =>

                logger.info("+++++++++++++++############## No Partitions To Be Updated ##############+++++++++++++++")

                deDupDeltaSrcDF.select(Utilities.loadSelectExpr(deDupDeltaSrcDF.columns, tgtColumns): _*).distinct.repartition(5).write.mode("Append").format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)

                logger.info("+++++++++++++++############## Data Load Complete ##############+++++++++++++++")

              case _ =>

                val identifiedPartition = commonDF.select(col("period").cast(StringType)).distinct.collect.map(row => row.getString(0).toString()).toSeq

                logger.info("###################### identified Partition" + identifiedPartition)

                val nonUpdatedRecords = tgtDF.where(col("period").isin(identifiedPartition: _*)).join(latestIncrementalTransations, fullExpr, "left_anti")

                nonUpdatedRecords.count match { 
                  
                  case 0 => 

                    logger.info("+++++++++++++++############## FULL partitions updated ##############+++++++++++++++")
                    
                    deDupDeltaSrcDF.select(Utilities.loadSelectExpr(deDupDeltaSrcDF.columns, tgtColumns): _*).distinct.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)
                  
                    logger.info("+++++++++++++++############## Data Load Complete ##############+++++++++++++++")
                    
                  case _ =>
                
                    nonUpdatedRecords.select(Utilities.loadSelectExpr(nonUpdatedRecords.columns, tgtColumns): _*).distinct.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)

                    logger.info("+++++++++++++++############## Existing partitions updated ##############+++++++++++++++")

                    deDupDeltaSrcDF.select(Utilities.loadSelectExpr(deDupDeltaSrcDF.columns, tgtColumns): _*).distinct.repartition(5).write.mode("append").format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)

                    logger.info("+++++++++++++++############## Data Load Complete ##############+++++++++++++++")
                }

            }

        }

    }

    val cnsptnDF = spark.sql(s"select * from ${dbNameConsmtn}.${consmptnTable}")
    val tgtCount = cnsptnDF.count.toInt

    tgtCount match {
      case 0 =>
        logger.error("//************* Data Load Failed")
        auditObj.setAudBatchId(objName + "_" + maxTimeStamp)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn + " ,count:" + tgtCount)
        auditObj.setAudBatchId(objName + "_" + maxTimeStamp)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(objName)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudBatchId(objName)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } finally {
    logger.info("//*********************** Log End for SecuredSalesShipmentConsumption.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
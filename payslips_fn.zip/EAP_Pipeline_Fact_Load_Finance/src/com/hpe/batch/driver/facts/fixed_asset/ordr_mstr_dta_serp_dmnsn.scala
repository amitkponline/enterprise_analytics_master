package com.hpe.batch.driver.facts.fixed_asset

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object ordr_mstr_dta_serp_dmnsn extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var srcCount = 0
  var tgtCount = 0
  var jobStatusFlag = true
  var incrementalDf = spark.emptyDataFrame

  //***************************Audit Properties********************************//
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  //************************Set Audit Entries*******************************//

  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(propertiesObject.getObjName())
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(srcCount)
  auditObj.setAudTgtRowCount(tgtCount)

  try {

    var ref_btch_id = Utilities.readRefBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)
    var cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)

    logger.info("ref_btch_id :- " + ref_btch_id + " cnsmptn_btch_id :- " + cnsmptn_btch_id)

    logger.info("Initializing log for ORDER MASTER DATA SERP DIMENSION, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ref_btch_id)

    val consmptnTable = new StringBuilder()
    val dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    /* *************************************** Selecting source count ****************************** */
    var ins_gmt_date = ""

    if (cnsmptn_btch_id == "1900-01-01 00:00:00") {
      ins_gmt_date = cnsmptn_btch_id.substring(0, 4) + "-" + cnsmptn_btch_id.substring(5, 7) + "-" + cnsmptn_btch_id.substring(8, 10)
    } else {
      ins_gmt_date = cnsmptn_btch_id.substring(19, 23) + "-" + cnsmptn_btch_id.substring(23, 25) + "-" + cnsmptn_btch_id.substring(25, 27)
    }

    srcCount = spark.sql(s"""select count(*) from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""").first().getLong(0).toInt
    logger.info(s"""select count(*) from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""")
    logger.info("source count: " + srcCount)
    var tgtTbl = consmptnTable
    if (srcCount > 0) {
      auditObj.setAudSrcRowCount(srcCount)

      spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'com.hpe.batch.hive.udfs.CRC64'""")

      /* ************************** Creating data frame for latest data ************************* */
      incrementalDf = spark.sql(s"""SELECT  crc64(COALESCE(trim(ord_nr),"")) as intrnl_ord_ky ,crc64(concat(COALESCE(trim(bsc_stlmnt_cst_cntr),""),COALESCE(trim(co_cd),""))) AS cst_cntr_cmpny_cd_ky ,coalesce(ord_nr,'') as ord_nr ,ord_typ ,ord_cgy ,rfnc_ord_nr ,entrd_by ,crtd_on ,last_chgd_by ,ord_mstr_chg_dt ,dn ,lg_txt_exss ,co_cd ,plnt ,bsn_ar ,ctrlng_ar ,cst_clctr_ky ,rspnsbl_cst_cntr ,lctn ,lctn_plnt ,ststcl_ord_id ,ord_curr ,ord_stts ,last_stts_chg_dt ,stts_reached_so_far ,phs_ord_crtd ,phs_ord_rlsd ,phs_ord_cmpltd ,phs_ord_clsd ,plnd_rls_dt ,plnd_cmpltn_dt ,plnd_closing_dt ,rls_dt ,tchnl_cmpltn_dt ,cls_dt ,obj_id ,dsallwd_transactions_grp ,dltn_flg ,plng_ln_itms_id ,cndn_tbl_usg ,appl ,cstg_sht ,ovrhd_ky ,prsng_grp ,stlmnt_cst_elmt ,bsc_stlmnt_cst_cntr ,bsc_stlmnt_gl_acct ,allctn_set ,costs_actually_pstd_cst_cntr ,strt_dt ,sqn_nr ,applcnt ,applcnt_s_tel_nr ,pers_rspnsbl ,pers_in_crg_tel_nr ,estmd_totl_costs_of_ord ,appl_dt ,dpt ,wrk_strt ,end_of_wrk ,wrk_prmt_issd_id ,obj_nr ,pft_cntr ,wbs_elmt ,vrnc_ky ,rslts_anlys_ky ,tx_jrstc ,fnctl_ar ,obj_clss ,intgd_plng_ind ,sls_ord_nr ,sls_ord_itm_nr ,xtrn_ord_nr ,ivstmt_msr_pfl ,lgcl_sys ,ord_has_mltpl_itms ,rqstg_co_cd ,rqstg_cst_cntr ,ivstmt_objects_scl ,ivstmt_rsn ,envl_ivstmt_rsn ,drct_cst_clctr_ind ,prj_int_cltn_int_pfl ,prdn_prs_procnr_cst_clctr ,rqstg_ord ,prdn_prs ,prs_cgy ,refurbishment_ord_ind ,acctng_ind ,addr_nr ,tm_crtd ,chgd_at ,cstg_vrnt ,cst_est_wo_qty_srtr_cst_est_no ,co_inrn_ord_usr_rspnsbl ,dmy_fnctn_lgt ,jnt_vntr ,rcvry_ind ,eqty_typ ,jnt_vntr_obj_typ ,jib_jibe_clss ,jib_jibe_subclass_a ,jv_orgl_cst_obj ,tm_stamp ,ord_used_compatible_unts ,construction_msr_nr ,atmtc_cp_of_estmd_costs ,dsgn_nr ,dyn_itm_prsr_pfl ,mntnc_tasks_mn_wrk_cntr ,mn_wrk_cntr_plnt_asscd ,rgty_ind ,stts_cmbn ,clm_crtn_ctrl_ind ,ord_ind_clm_inconsistency ,srv_ord_clm_upd_trg_pnt ,intgtn_fbrc_msg_id ,src_sys_upd_ts ,src_sys_ky ,lgcl_dlt_ind ,ins_gmt_ts ,upd_gmt_ts ,src_sys_extrc_gmt_ts ,src_sys_btch_nr ,fl_nm ,ld_jb_nr,cast(concat(substr(ins_gmt_dt,0,7),"-01") as date) as ins_gmt_dt FROM (select *,row_number() over (partition by ord_nr order by ins_gmt_ts desc) as rownum from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}')a where a.rownum = 1""")
      logger.info(s"""SELECT  crc64(COALESCE(trim(ord_nr),"")) as intrnl_ord_ky ,crc64(concat(COALESCE(trim(bsc_stlmnt_cst_cntr),""),COALESCE(trim(co_cd),""))) AS cst_cntr_cmpny_cd_ky ,coalesce(ord_nr,'') as ord_nr ,ord_typ ,ord_cgy ,rfnc_ord_nr ,entrd_by ,crtd_on ,last_chgd_by ,ord_mstr_chg_dt ,dn ,lg_txt_exss ,co_cd ,plnt ,bsn_ar ,ctrlng_ar ,cst_clctr_ky ,rspnsbl_cst_cntr ,lctn ,lctn_plnt ,ststcl_ord_id ,ord_curr ,ord_stts ,last_stts_chg_dt ,stts_reached_so_far ,phs_ord_crtd ,phs_ord_rlsd ,phs_ord_cmpltd ,phs_ord_clsd ,plnd_rls_dt ,plnd_cmpltn_dt ,plnd_closing_dt ,rls_dt ,tchnl_cmpltn_dt ,cls_dt ,obj_id ,dsallwd_transactions_grp ,dltn_flg ,plng_ln_itms_id ,cndn_tbl_usg ,appl ,cstg_sht ,ovrhd_ky ,prsng_grp ,stlmnt_cst_elmt ,bsc_stlmnt_cst_cntr ,bsc_stlmnt_gl_acct ,allctn_set ,costs_actually_pstd_cst_cntr ,strt_dt ,sqn_nr ,applcnt ,applcnt_s_tel_nr ,pers_rspnsbl ,pers_in_crg_tel_nr ,estmd_totl_costs_of_ord ,appl_dt ,dpt ,wrk_strt ,end_of_wrk ,wrk_prmt_issd_id ,obj_nr ,pft_cntr ,wbs_elmt ,vrnc_ky ,rslts_anlys_ky ,tx_jrstc ,fnctl_ar ,obj_clss ,intgd_plng_ind ,sls_ord_nr ,sls_ord_itm_nr ,xtrn_ord_nr ,ivstmt_msr_pfl ,lgcl_sys ,ord_has_mltpl_itms ,rqstg_co_cd ,rqstg_cst_cntr ,ivstmt_objects_scl ,ivstmt_rsn ,envl_ivstmt_rsn ,drct_cst_clctr_ind ,prj_int_cltn_int_pfl ,prdn_prs_procnr_cst_clctr ,rqstg_ord ,prdn_prs ,prs_cgy ,refurbishment_ord_ind ,acctng_ind ,addr_nr ,tm_crtd ,chgd_at ,cstg_vrnt ,cst_est_wo_qty_srtr_cst_est_no ,co_inrn_ord_usr_rspnsbl ,dmy_fnctn_lgt ,jnt_vntr ,rcvry_ind ,eqty_typ ,jnt_vntr_obj_typ ,jib_jibe_clss ,jib_jibe_subclass_a ,jv_orgl_cst_obj ,tm_stamp ,ord_used_compatible_unts ,construction_msr_nr ,atmtc_cp_of_estmd_costs ,dsgn_nr ,dyn_itm_prsr_pfl ,mntnc_tasks_mn_wrk_cntr ,mn_wrk_cntr_plnt_asscd ,rgty_ind ,stts_cmbn ,clm_crtn_ctrl_ind ,ord_ind_clm_inconsistency ,srv_ord_clm_upd_trg_pnt ,intgtn_fbrc_msg_id ,src_sys_upd_ts ,src_sys_ky ,lgcl_dlt_ind ,ins_gmt_ts ,upd_gmt_ts ,src_sys_extrc_gmt_ts ,src_sys_btch_nr ,fl_nm ,ld_jb_nr,cast(concat(substr(ins_gmt_dt,0,7),"-01") as date) as ins_gmt_dt FROM (select *,row_number() over (partition by ord_nr order by ins_gmt_ts desc) as rownum from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}')a where a.rownum = 1""")

      incrementalDf = incrementalDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

      //***************************incremental CDC*********************************//

      val existingDmnsnDF = spark.sql(f"""select intrnl_ord_ky,cst_cntr_cmpny_cd_ky,coalesce(ord_nr,'') as ord_nr,ord_typ,ord_cgy,rfnc_ord_nr,entrd_by,crtd_on,last_chgd_by,ord_mstr_chg_dt,dn,lg_txt_exss,co_cd,plnt,bsn_ar,ctrlng_ar,cst_clctr_ky,rspnsbl_cst_cntr,lctn,lctn_plnt,ststcl_ord_id,ord_curr,ord_stts,last_stts_chg_dt,stts_reached_so_far,phs_ord_crtd,phs_ord_rlsd,phs_ord_cmpltd,phs_ord_clsd,plnd_rls_dt,plnd_cmpltn_dt,plnd_closing_dt,rls_dt,tchnl_cmpltn_dt,cls_dt,obj_id,dsallwd_transactions_grp,dltn_flg,plng_ln_itms_id,cndn_tbl_usg,appl,cstg_sht,ovrhd_ky,prsng_grp,stlmnt_cst_elmt,bsc_stlmnt_cst_cntr,bsc_stlmnt_gl_acct,allctn_set,costs_actually_pstd_cst_cntr,strt_dt,sqn_nr,applcnt,applcnt_s_tel_nr,pers_rspnsbl,pers_in_crg_tel_nr,estmd_totl_costs_of_ord,appl_dt,dpt,wrk_strt,end_of_wrk,wrk_prmt_issd_id,obj_nr,pft_cntr,wbs_elmt,vrnc_ky,rslts_anlys_ky,tx_jrstc,fnctl_ar,obj_clss,intgd_plng_ind,sls_ord_nr,sls_ord_itm_nr,xtrn_ord_nr,ivstmt_msr_pfl,lgcl_sys,ord_has_mltpl_itms,rqstg_co_cd,rqstg_cst_cntr,ivstmt_objects_scl,ivstmt_rsn,envl_ivstmt_rsn,drct_cst_clctr_ind,prj_int_cltn_int_pfl,prdn_prs_procnr_cst_clctr,rqstg_ord,prdn_prs,prs_cgy,refurbishment_ord_ind,acctng_ind,addr_nr,tm_crtd,chgd_at,cstg_vrnt,cst_est_wo_qty_srtr_cst_est_no,co_inrn_ord_usr_rspnsbl,dmy_fnctn_lgt,jnt_vntr,rcvry_ind,eqty_typ,jnt_vntr_obj_typ,jib_jibe_clss,jib_jibe_subclass_a,jv_orgl_cst_obj,tm_stamp,ord_used_compatible_unts,construction_msr_nr,atmtc_cp_of_estmd_costs,dsgn_nr,dyn_itm_prsr_pfl,mntnc_tasks_mn_wrk_cntr,mn_wrk_cntr_plnt_asscd,rgty_ind,stts_cmbn,clm_crtn_ctrl_ind,ord_ind_clm_inconsistency,srv_ord_clm_upd_trg_pnt,intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_gmt_dt from ${dbNameConsmtn}.${tgtTbl}""")
      logger.info(f"""select intrnl_ord_ky,cst_cntr_cmpny_cd_ky,coalesce(ord_nr,'') as ord_nr,ord_typ,ord_cgy,rfnc_ord_nr,entrd_by,crtd_on,last_chgd_by,ord_mstr_chg_dt,dn,lg_txt_exss,co_cd,plnt,bsn_ar,ctrlng_ar,cst_clctr_ky,rspnsbl_cst_cntr,lctn,lctn_plnt,ststcl_ord_id,ord_curr,ord_stts,last_stts_chg_dt,stts_reached_so_far,phs_ord_crtd,phs_ord_rlsd,phs_ord_cmpltd,phs_ord_clsd,plnd_rls_dt,plnd_cmpltn_dt,plnd_closing_dt,rls_dt,tchnl_cmpltn_dt,cls_dt,obj_id,dsallwd_transactions_grp,dltn_flg,plng_ln_itms_id,cndn_tbl_usg,appl,cstg_sht,ovrhd_ky,prsng_grp,stlmnt_cst_elmt,bsc_stlmnt_cst_cntr,bsc_stlmnt_gl_acct,allctn_set,costs_actually_pstd_cst_cntr,strt_dt,sqn_nr,applcnt,applcnt_s_tel_nr,pers_rspnsbl,pers_in_crg_tel_nr,estmd_totl_costs_of_ord,appl_dt,dpt,wrk_strt,end_of_wrk,wrk_prmt_issd_id,obj_nr,pft_cntr,wbs_elmt,vrnc_ky,rslts_anlys_ky,tx_jrstc,fnctl_ar,obj_clss,intgd_plng_ind,sls_ord_nr,sls_ord_itm_nr,xtrn_ord_nr,ivstmt_msr_pfl,lgcl_sys,ord_has_mltpl_itms,rqstg_co_cd,rqstg_cst_cntr,ivstmt_objects_scl,ivstmt_rsn,envl_ivstmt_rsn,drct_cst_clctr_ind,prj_int_cltn_int_pfl,prdn_prs_procnr_cst_clctr,rqstg_ord,prdn_prs,prs_cgy,refurbishment_ord_ind,acctng_ind,addr_nr,tm_crtd,chgd_at,cstg_vrnt,cst_est_wo_qty_srtr_cst_est_no,co_inrn_ord_usr_rspnsbl,dmy_fnctn_lgt,jnt_vntr,rcvry_ind,eqty_typ,jnt_vntr_obj_typ,jib_jibe_clss,jib_jibe_subclass_a,jv_orgl_cst_obj,tm_stamp,ord_used_compatible_unts,construction_msr_nr,atmtc_cp_of_estmd_costs,dsgn_nr,dyn_itm_prsr_pfl,mntnc_tasks_mn_wrk_cntr,mn_wrk_cntr_plnt_asscd,rgty_ind,stts_cmbn,clm_crtn_ctrl_ind,ord_ind_clm_inconsistency,srv_ord_clm_upd_trg_pnt,intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_gmt_dt from ${dbNameConsmtn}.${tgtTbl}""")

      if (!existingDmnsnDF.head(1).isEmpty) {
        //************************For incremental load*****************************//
        var overWritePrtition = existingDmnsnDF.join(
          incrementalDf,
          existingDmnsnDF("ord_nr") === incrementalDf("ord_nr")).select(existingDmnsnDF("ins_gmt_dt").cast(StringType)).
          distinct.collect.map(row => row.getString(0).toString()).toSeq
          
        if (overWritePrtition.size == 0) { overWritePrtition = incrementalDf.select(incrementalDf("ins_gmt_dt").cast(StringType)).distinct.collect.map(row => row.getString(0).toString()).toSeq }

        val dmnsnNonMatchDF = existingDmnsnDF.where(existingDmnsnDF("ins_gmt_dt").isin(overWritePrtition: _*)).join(
          incrementalDf,
          existingDmnsnDF("ord_nr") === incrementalDf("ord_nr"), "left_anti")

        val finalDmnsnDF = incrementalDf.union(dmnsnNonMatchDF)

        finalDmnsnDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + tgtTbl)

      } else {
        //**************************For initial load*****************************//
        incrementalDf.write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + tgtTbl)
      }
      /* ************************ selecting target count ****************************************** */
      tgtCount = incrementalDf.count().toInt
      logger.info("target count: " + tgtCount)

      logger.info("+++++++++++############# Load Successful #############+++++++++++")
      auditObj.setAudTgtRowCount(tgtCount)
      auditObj.setAudJobStatusCode("success")
    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("failed")
    }
    /* ********************************************* Completion audit entries ************************** */

    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    incrementalDf.unpersist()
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) {
      System.exit(1)
    }

  }
}

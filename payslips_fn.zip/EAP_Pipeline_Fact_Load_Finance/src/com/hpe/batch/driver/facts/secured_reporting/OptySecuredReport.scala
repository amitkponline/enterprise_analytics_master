package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel._

object OptySecuredReport extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var fileBasePath = propertiesObject.getFileBasePath().trim()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val objName = propertiesObject.getObjName()
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val dbName = propertiesObject.getDbName().trim()

  def getExchangeRate(df: DataFrame): DataFrame = {
    df.withColumn("exch_rt", when(col("frm_curr_unts_rto_2_nr") === col("to_curr_unts_rto_2_nr"), (col("frm_curr_unts_rto_2_nr") / col("indrt_qted_exch_rate_nr")) * col("to_curr_unts_rto_2_nr")).
      when(col("frm_curr_unts_rto_2_nr") > col("to_curr_unts_rto_2_nr"), (col("to_curr_unts_rto_2_nr") / col("indrt_qted_exch_rate_nr")) * col("frm_curr_unts_rto_2_nr")).
      when(col("frm_curr_unts_rto_2_nr") < col("to_curr_unts_rto_2_nr"), (col("frm_curr_unts_rto_2_nr") / col("indrt_qted_exch_rate_nr")) * col("to_curr_unts_rto_2_nr")).
      otherwise(null))
  }

  //***************************Audit Properties********************************//
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_secrd_Opty_fact_load")
  auditObj.setAudObjectName(objName)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)

  try {

    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn, dbName))

    if (tgtTblConsmtn.split("\\.", -1).size != 2) {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    var dbNameConsmtn: String = null
    var consmptnTable: String = null
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    val dbCommon = dbName.split(",")(0)
    val dbCommonUAT = dbName.split(",")(1)
    val tgtColumns = spark.sql("select * from " + tgtTblConsmtn + " limit 0").columns
    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    val exchDF = spark.sql(s"""
      select 
        frm_curr_cd,
        etry_vld_frm_ts,
        frm_curr_unts_rto_2_nr,
        indrt_qted_exch_rate_nr,
        to_curr_unts_rto_2_nr 
      from 
        ${dbNameConsmtn}.exch_rates_dmnsn 
      where 
        exch_rate_typ_cd = 'M' 
        and to_curr_cd = 'USD' 
        and  DAY(etry_vld_frm_ts) = 1
        """)

    getExchangeRate(exchDF).createOrReplaceTempView("exch_rt_tbl")

    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    val dfOptyFilter = spark.sql(s"""
      	SELECT
		      distinct sales_shipment_ref.zord_header_opty_id as opty_id
	      FROM
		    ${dbCommon}.sales_shipment_ref
        UNION
	      SELECT
		      distinct deal_dmnsn.deal_opty_qt_dn as opty_id
	      FROM
		    ${dbCommonUAT}.deal_dmnsn
        UNION
      	SELECT
		      distinct quotes_fact.opportunity_id_id as opty_id
	      FROM
		    ${dbCommonUAT}.quotes_fact
      """)

    dfOptyFilter.persist(MEMORY_AND_DISK)
    dfOptyFilter.createOrReplaceTempView("dfoptyfilter")

    val optySrcSelectDf = spark.sql(s"""select distinct
opty_fact_key,
qt_i_nm,
opty_i_3_nm,
qt_i_nm,
cust_engmn_2_nm,
acct_i_20_nm,
totl_opty_v_cd ,
expctd_amt_cd,
opty_totl_amt_cd ,
opty_totl_amt_cd ,
ins_gmt_ts,
ctr_19_nm,
end_cus_nm,
qt_2_cd,
prmry_dstr_mdcp_org_id_nm,
prmry_dstr_nm,
prmry_ppln_own_nm,
prmry_rslr_nm,
hpe_opty_i_nm,
sls_re_3_nm,
curr_cd,
cl_2_dt as cls_2_dt,
crt_4_dt,
sls_st_6_nm,
last_mfy_6_dt
from ${dbCommon}.opty_fact
left outer join dfoptyfilter on 
  opty_fact.hpe_opty_i_nm = dfoptyfilter.opty_id
where
  --lower(ld_jb_nr) not like '%his%'
  sls_st_6_nm not in ('Lost','Error')  
  AND dfoptyfilter.opty_id is null
""")

    optySrcSelectDf.createOrReplaceTempView("opty_fact")

    val optySelectDF = spark.sql(s"""
SELECT
	crc64(lower(concat(coalesce(opty_i_3_nm,""),coalesce(opty_fact_key,""),coalesce(opty_prod_dmnsn.prod_l_5_nm,""),coalesce(opty_prod_dmnsn.prod_i_2_nm,""),coalesce(d.useremail_nm,""),coalesce(cast(c.prmry_dstr_cd as string),""),coalesce(cast(c.prmry_rslr_cd as string),""),row_number() over (partition by opty_i_3_nm order by opty_fact.ins_gmt_ts)))) AS secrd_rpt_fact_ky,
	crc32(LOWER(COALESCE(qt_i_nm, ""))) AS quote_ky,
	crc32(LOWER(COALESCE(opty_i_3_nm, ""))) AS opty_ky,
	opty_i_3_nm AS opty_id,
	'OPPORTUNITY' AS src_sys_cd,
	qt_i_nm AS quote_id,
	CURRENT_TIMESTAMP AS ins_ts,
	cust_engmn_2_nm AS bsn_rshp_typ_cd,
	opty_fact.acct_i_20_nm AS accnt_id ,
	opty_fact.totl_opty_v_cd AS ttl_opty_vl,
	opty_fact.expctd_amt_cd AS opty_expctd_amt,
	opty_fact.opty_totl_amt_cd AS opty_totl_amt,
	opty_fact.opty_totl_amt_cd AS opty_val,
	opty_prod_dmnsn.bookshi_2_dt AS opty_bk_ship_dt,
	opty_fact.last_mfy_6_dt AS opty_lst_mfd_dt,
	opty_prod_dmnsn.sys_modstam_4_cd AS sys_modstam,
	opty_prod_dmnsn.b_3_nm AS bg_cd,
	opty_prod_dmnsn.gb_15_nm AS gbu_cd,
	opty_fact.sls_st_6_nm AS opty_stg,
	opty_prod_dmnsn.pro_283_nm AS prd_nm,
	opty_prod_dmnsn.prod_l_5_nm AS prd_ln,
	opty_prod_dmnsn.sb_prod_l_2_nm AS sub_prd_ln,
	acct_dmnsn.chnl_ptnr_flg_cd AS opty_chnl_ptnr_flg_cd,
	acct_dmnsn.ptnr_typ_cd AS opty_ptnr_typ_cd,
	c.prmry_dstr_cd AS opty_prmry_dstr_cd,
	c.prmry_rslr_cd AS opty_prmry_rslr_cd,
	c.ptnr_typ_nm AS opty_ptnr_typ_nm,
	opty_fact.prmry_dstr_mdcp_org_id_nm AS opty_prmry_dstr_mdcp_org_id_nm,
	opty_fact.prmry_dstr_nm AS opty_prmry_dstr_nm,
	opty_fact.prmry_ppln_own_nm AS opty_prmry_ppln_own_nm,
	opty_fact.prmry_rslr_nm as rslr_nr, -- changed 2/19
	d.prmry_ppln_own_cd AS opty_team_mmbr_nm,
	d.useremail_nm AS opty_useremail_nm,
	acct_dmnsn.acct_nm as acct_nm, -- changed 2/19
	opty_fact.ctr_19_nm AS ctry_nm,
	opty_prod_dmnsn.prod_i_2_nm AS mtrl_nr,
	opty_fact.end_cus_nm AS end_cust_cd,
	opty_fact.qt_2_cd AS qty_cd,
	acct_dmnsn.mdcp_site_id AS sls_tty_id,
	acct_dmnsn.mdcp_site_insn_id as mdcp_opsi_id_id,
	opty_fact.crt_4_dt AS opty_crt_dt,
	hpe_opty_i_nm AS opty_hpe_opportunity_id,
  ln_itm_id_nm AS opty_line_item_id,
  v_28_cd AS opty_val_cd,
  sls_re_3_nm AS opty_sales_rep_nm,
	opty_fact.ins_gmt_ts AS ins_gmt_ts,
	case
	  when upper(opty_fact.curr_cd) = 'USD' then opty_fact.expctd_amt_cd
	  ELSE opty_fact.expctd_amt_cd*exch_rt 
	END AS opty_expctd_usd_amt,
	case 
	  when upper(opty_fact.curr_cd) = 'USD' then v_28_cd
	  ELSE v_28_cd*exch_rt
	END AS opty_totl_usd_amt,
	cls_2_dt,
	--opty_prod_dmnsn.opportunity_estimated_revenue_usd_close_date as opportunity_estimated_revenue_usd
	NULL as opportunity_estimated_revenue_usd
FROM
opty_fact
LEFT OUTER JOIN (select * from (select *,row_number() over (partition by opty_i_11_nm order by ins_gmt_ts) rw_num from ${dbCommonUAT}.opty_prod_dmnsn) where rw_num = 1) opty_prod_dmnsn ON opty_fact.opty_i_3_nm = opty_prod_dmnsn.opty_i_11_nm
LEFT OUTER JOIN ${dbCommonUAT}.acct_dmnsn acct_dmnsn ON opty_fact.acct_i_20_nm = acct_dmnsn.acct_id
LEFT OUTER JOIN (select * from (select *,row_number() over (partition by opt_4_nm order by ins_gmt_ts) rw_num from ${dbCommonUAT}.alnc_and_chnl_ptnrs_dmnsn) where rw_num = 1 ) c on opty_fact.opty_i_3_nm=c.opt_4_nm
LEFT OUTER JOIN (select * from (select *,row_number() over (partition by opty_i_29_nm order by ins_gmt_ts) rw_num from ${dbCommonUAT}.opty_team_mmbr_dmnsn) where rw_num = 1) d on opty_fact.opty_i_3_nm= d.opty_i_29_nm
LEFT OUTER JOIN ${dbCommon}.clndr_rpt cldr_rpt_fact_book on (opty_prod_dmnsn.bookshi_2_dt = cldr_rpt_fact_book.cldr_dt)
LEFT OUTER JOIN ${dbCommon}.clndr_rpt cldr_rpt_fact_close on (opty_prod_dmnsn.opty_cl_2_dt = cldr_rpt_fact_close.cldr_dt)
LEFT OUTER JOIN exch_rt_tbl on opty_fact.curr_cd = exch_rt_tbl.frm_curr_cd AND MONTH(opty_prod_dmnsn.bookshi_2_dt) = MONTH(exch_rt_tbl.etry_vld_frm_ts)
 AND YEAR(opty_prod_dmnsn.bookshi_2_dt) = YEAR(exch_rt_tbl.etry_vld_frm_ts)
WHERE
(cldr_rpt_fact_book.fisc_yr_nm = (select distinct fisc_yr_nm from ${dbCommon}.clndr_rpt where cldr_dt = date(current_timestamp)) OR cldr_rpt_fact_close.fisc_yr_nm = (select distinct fisc_yr_nm from ${dbCommon}.clndr_rpt where cldr_dt = date(current_timestamp)))
""").distinct

    val optyLoad = optySelectDF.select(Utilities.loadSelectExpr(optySelectDF.columns, tgtColumns): _*)

    optyLoad.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblConsmtn)

    //optyLoad.write.mode("append").format("orc").insertInto("ea_fin_r2_2itg.secrd_rpt_fact_test_1611")

    val tgtCount = spark.sql(s"select * from ${tgtTblConsmtn} where src_sys_cd = 'OPPORTUNITY'").count.toInt

    tgtCount match {
      case 0 =>
        logger.info("//************* No Data To Load")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }

  } finally {
    sqlCon.close()
    spark.close()
  }

}
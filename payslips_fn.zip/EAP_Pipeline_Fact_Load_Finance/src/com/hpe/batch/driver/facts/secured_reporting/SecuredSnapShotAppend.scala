package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object SecuredSnapShotAppend extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val objName = propertiesObject.getObjName()
  var jobStatusFlag = true
  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  try {

    if (tgtTblConsmtn.split("\\.", -1).size != 2) {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val tgtColumns = spark.sql("select * from " + tgtTblConsmtn + " limit 0").columns
    val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

    val dfSecuredSelect = spark.sql(s"""
select *,
CURRENT_TIMESTAMP as snpsht_ins_ts,
CASE WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('12:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('08:00 AM',"hh:mm a") THEN 1 
WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('08:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('04:00 PM',"hh:mm a") THEN 2 
ELSE 3 END as snpsht_nr,
date(CURRENT_TIMESTAMP) as partition_dt,
CASE WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('12:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('08:00 AM',"hh:mm a") THEN 1 
WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('08:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('04:00 PM',"hh:mm a") THEN 2 
ELSE 3 END as partition_nr
FROM
${srcTableName}
""")

    val partitionDt = dfSecuredSelect.select("partition_dt").distinct.first.getDate(0).toString()
    
    val partitionNr = dfSecuredSelect.select("partition_nr").distinct.first.getInt(0).toString()

    val snpshotFinalLoadDF = dfSecuredSelect.select(Utilities.loadSelectExpr(dfSecuredSelect.columns, tgtColumns): _*)

    snpshotFinalLoadDF.repartition(10).write.format("orc").mode("append").insertInto(tgtTblConsmtn)
    
    val tgtCount = spark.sql(s"select * from ${tgtTblConsmtn} where partition_dt = '${partitionDt}' and partition_nr = ${partitionNr}").count.toLong

    val loadStatus = if(tgtCount > 0 ) "success" else "failed"
      
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudJobStatusCode(loadStatus)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }

  } finally {
    logger.info("//*********************** Log End for SfdcSecuredReport.scala ************************//")
    sqlCon.close()
    spark.close()

  }

}


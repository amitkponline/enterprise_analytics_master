package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel._

object PNSecuredReport extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  logger.info("//*********************** Log Start for SERPSecuredReportLR1.scala ************************//")

  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }

  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())

  logger.info("+++++++++++############# Properties File Path: " + propertiesFilePath)

  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)

  if (propertiesObject == null) {
    logger.error("Error with property file location.File not found/File not readable")
    spark.close()
    System.exit(1)
  }

  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"

  logger.info("+++++++++++############# Env Properties File Path: " + envPropertiesFilePath)

  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val objName = propertiesObject.getObjName().trim()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val dbcommonname = propertiesObject.getDbName().split(",")(0).trim
  val dbcommonuatname = propertiesObject.getDbName().split(",")(1).trim
  val dbcommonnamelr1 = propertiesObject.getDbName().split(",")(2).trim
  val dbfinancnamelr1 = propertiesObject.getDbName().split(",")(3).trim
  val dbfinancname = propertiesObject.getDbName().split(",")(4).trim
  val dbfinancnamelr1uat = propertiesObject.getDbName().split(",")(5).trim
  val dbcommonlr1uat = propertiesObject.getDbName().split(",")(6).trim
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()

  logger.info("+++++++++++############# Audit Table Name: " + auditTbl)

  val sqlCon = Utilities.getConnection(envPropertiesObject)

  var dbNameConsmtn: String = null
  var consmptnTable: String = null

  //***************************Audit Properties********************************//
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_secrd_pn_intermidiate_load")
  auditObj.setAudObjectName(objName)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  spark.conf.set("spark.sql.crossJoin.enabled", "true")

  try {

    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn))

    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    if (tgtTblConsmtn.split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    // ******************************** Data Preparation for SERP LOAD ***********************************\\

    val srcCount = spark.sql(s"select * from ${dbfinancnamelr1uat}.secrd_rpt_sls_spmt_dmnsn").count.toLong

    val optg = spark.sql(s"""
    select
	    concat_ws("-",optg_concern.itm_frm_rfnc_dcmt_copa_nr,optg_concern.rfnc_dcmt_copa_ln_itm_nr) as copa_order_number_item_number_key,
	    optg_concern.rfnc_dcmt_copa_ln_itm_nr,
	    optg_concern.itm_frm_rfnc_dcmt_copa_nr,
	    optg_concern.pftblty_anlys_hdr_tbl_co_cd,
	    optg_concern.sls_qty_amt,
	    optg_concern.cst_cntr_cd,
	    (coalesce(optg_concern.pkgg_amt,0) + coalesce(optg_concern.rw_matspare_prts_amt,0) + coalesce(optg_concern.masking_amt,0) + coalesce(emr_cst_amt,0) + coalesce(optg_concern.vrnc_adjmt_amt,0) + coalesce(optg_concern.fnshd_mtrls_amt,0) + coalesce(optg_concern.hpe_ovrhd_amt,0) + coalesce(optg_concern.vndr_rebates_amt,0) + coalesce(optg_concern.rylty_amt,0) + coalesce(optg_concern.fin_brdn_amt,0) + coalesce(optg_concern.lohp_amt,0) + coalesce(optg_concern.sub_asbly_contmfg_amt,0)) as estimated_sales_cost
    from
	  ${dbfinancname}.optg_concern_fact optg_concern
    where
	    optg_concern.cnld_dcmt_cd is null
	    and optg_concern.cnld_dcmt_it_1_cd is null
	    and optg_concern.cnld_subnumber_ln_itm_nr is null
	    and optg_concern.dltd_by_dcmt_cd is null
	    and optg_concern.dltd_by_itm_cd is null
	    and lower(optg_concern.rec_typ_cd) = 'a'
	    and optg_concern.curr_typ_and_valtn_vw_cd = '30'
    """)

    optg.createOrReplaceTempView("optgcopa")

    /*
 * salesshipmentdf data frame: contains data from sales shipment table and rar tables
 *
 */
    val salesshipmentdf = spark.sql(s"""
select distinct
	sls_spmt.e1edk01_idoc_dcmt_nr as sls_ord_id,
	sls_spmt.e1edp01_itm_nr as sls_ord_ln_itm_id,
	sls_spmt.pft_cntr_nm as prft_cntr_cd,
	sls_spmt.sgmnt_cd as sgmtl_rptg_cd,
	segment_std_hrchy.sg_level_3 as sgm_lvl_2,
	segment_std_hrchy.sg_level_4 as sgm_lvl_3,
	segment_std_hrchy.sg_level_5 as sgm_lvl_4,
	segment_std_hrchy.sg_level_6 as sgm_lvl_5,
	segment_std_hrchy.sg_level_7 as sgm_lvl_6,
	segment_std_hrchy.sg_level_8 as sgm_lvl_7,
	sls_spmt.pkg_prod_id as pkg_prod_id,
	split (
	  case
		  when (sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 is null and lower(sls_spmt.src_type) = 'dor orders') then sls_spmt.bs_prod_id_4_id
		  when lower(sls_spmt.src_type) = 's4 orders' then sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
		  else sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
	  end,'#')[0] as itm_vl_usr_stts_cd,
	prod_mstr.mtrl_mstr_sls_dvsn_cd as pm_mtrl_mstr_sls_dvsn_cd,
	current_prod.prod_hrchy_prod_typ_cd,
	sls_spmt.sls_mtrc_cd as sls_mtrc_cd,
	current_prod_hrchy_dmnsn.prod_hrchy_prod_fmly_cd,
	cst.cch_level_2 as MRU,
	'' as gl_acct_nr,
	optg_concern.cst_cntr_cd as cst_cntr_cd,
	rvn_rcgn_pstg_dmnsn.fnctl_ar_cd as fnctl_ar_cd,
	bmt_gbl_carepack_dmnsn.gbl_carepack_hw_prod_ln_id,
	prod_mstr_dmnsn.mtrl_mstr_sls_dvsn_cd as pmd_mtrl_mstr_sls_dvsn_cd,
	sls_spmt.e1edk14_idoc_org_nm_12 as ord_typ_cd,
	sls_spmt.e1edp02_idoc_dcmt_nr_1 as cust_po_nr
  from 
	${dbfinancnamelr1uat}.secrd_rpt_sls_spmt_dmnsn sls_spmt
	left outer join ${dbcommonlr1uat}.pdm_mtrl_mstr_grp_dmnsn prod_mstr_dmnsn on prod_mstr_dmnsn.mtrl_mstr_mtrl_id = sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
  left outer join ${dbcommonlr1uat}.pdm_mtrl_mstr_grp_dmnsn prod_mstr on prod_mstr.mtrl_mstr_mtrl_id=sls_spmt.rptg_mtrl_id_id
  left outer join ${dbcommonlr1uat}.bmt_gbl_carepack_dmnsn bmt_gbl_carepack_dmnsn on bmt_gbl_carepack_dmnsn.mfrg_prod_id=sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
  left outer join optgcopa as optg_concern on concat_ws("-",sls_spmt.e1edk01_idoc_dcmt_nr,sls_spmt.e1edp01_itm_nr) = optg_concern.copa_order_number_item_number_key
  left join ${dbcommonname}.cst_cntr_MRU_hrchy cst on optg_concern.cst_cntr_cd=cst.cch_level_8
  left outer join ${dbfinancnamelr1uat}.rvn_rcgn_mppg_dmnsn rvn_rcgn_mppg_dmnsn on
	sls_spmt.e1edk01_idoc_dcmt_nr = substring(rvn_rcgn_mppg_dmnsn.src_itm_id, 1, 10)
	and sls_spmt.e1edp01_itm_nr = substring(rvn_rcgn_mppg_dmnsn.src_itm_id,(length(rvn_rcgn_mppg_dmnsn.src_itm_id)-5), 6)
left outer join ${dbfinancnamelr1uat}.rvn_rcgn_dfrd_itm_dmnsn on
	rvn_rcgn_mppg_dmnsn.rvn_rcgn_cntrct_id = rvn_rcgn_dfrd_itm_dmnsn.rvn_rcgn_cntrct_id
	and rvn_rcgn_mppg_dmnsn.prfm_obgn_id = rvn_rcgn_dfrd_itm_dmnsn.prfm_obgn_id
left outer join ${dbfinancnamelr1uat}.rvn_rcgn_pstg_dmnsn rvn_rcgn_pstg_dmnsn on
	rvn_rcgn_dfrd_itm_dmnsn.prfm_obgn_id = rvn_rcgn_pstg_dmnsn.prfm_obgn_id
	and rvn_rcgn_dfrd_itm_dmnsn.rvn_rcgn_cntrct_id = rvn_rcgn_pstg_dmnsn.rvn_rcgn_cntrct_id
	and rvn_rcgn_dfrd_itm_dmnsn.rvn_rcncltn_ky = rvn_rcgn_pstg_dmnsn.rvn_rcncltn_ky
left outer join ${dbcommonname}.current_prod_hrchy_dmnsn current_prod_hrchy_dmnsn on current_prod_hrchy_dmnsn.mtrl_mstr_mtrl_id =sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2
left outer join ${dbcommonname}.segment_std_hrchy segment_std_hrchy on segment_std_hrchy.sg_level_8 = sls_spmt.sgmnt_cd
left outer join ${dbcommonname}.current_prod_hrchy_dmnsn current_prod on current_prod.mtrl_mstr_mtrl_id = split(sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2,'#')[0]
where
  case 
  	when COALESCE(sls_spmt.sls_ord_totl_qty_cd,0) <= 0 and sls_spmt.no_shp_flg_cd = 'Y' then 1 
	  when sls_spmt.e1edp01_itm_nr is null and sls_spmt.actl_qty_dlvrd_stockkeeping_unts is null and sls_spmt.no_shp_flg_cd = 'FY' then  0
	  when (sls_spmt.actl_qty_dlvrd_stockkeeping_unts > 0.0 or sls_spmt.actl_qty_dlvrd_stockkeeping_unts is null) then 1
	  when sls_spmt.actl_qty_dlvrd_stockkeeping_unts < 0 and (no_shp_flg_cd = 'Y' or no_shp_flg_cd = 'FY') then 1
	  when sls_spmt.actl_qty_dlvrd_stockkeeping_unts < 0 and no_shp_flg_cd = 'F' then 1
	  else 0 
  end = 1 
""")

    salesshipmentdf.repartition(col("sls_ord_id"), col("sls_ord_ln_itm_id")).persist(MEMORY_AND_DISK)

    val pnPtflFrmwkDmnsn = spark.sql(s""" select  a.*,pkg_prod_id as bmt_pkg_prod_id from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.bs_prod_id, tbl.sgm_cd, tbl.pkg_prod_id order by tbl.inrn_id) seq_id
                           from ${dbcommonlr1uat}.bmt_pn_ptfl_frmwk_dmnsn tbl) a where a.seq_id =1 """).repartition(col("pft_cntr_cd"), col("sgm_cd"), col("bmt_pkg_prod_id"), col("bs_prod_id"))

    val pnSlngMtnFrmwkDmnsnDf = spark.sql(s"""select a.* from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.sls_ord_typ_cd ,tbl.bsn_typ_cd, tbl.sgm_cd, tbl.bs_prod_id, tbl.mfrg_prod_fmly_id order by tbl.inrn_id) seq_id
                                from ${dbcommonlr1uat}.bmt_pn_slng_mtn_frmwk_dmnsn tbl) a where a.seq_id =1 """)

    val pnHwFrmwkDmnsnDf = spark.sql(s"""select a.* from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.sgm_cd, tbl.gbl_carepack_hw_prod_ln_id, tbl.hw_prod_ln_cd ,tbl.srv_gds_prod_ln_id, tbl.mfrg_prod_prod_ln_id,tbl.bs_prod_typ_cd,tbl.bs_prod_id order by tbl.inrn_id) seq_id
                           from ${dbcommonlr1uat}.bmt_pn_hw_frmwk_dmnsn tbl) a  where a.seq_id =1 """)

    val pnBsnCatFrmwkDmnsn = spark.sql(s"""select a.* from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.hw_lvl_4_cd ,tbl.bsn_typ_cd, tbl.bs_prod_id, tbl.sgm_cd, tbl.ln_itm_3_cd, tbl.mfrg_prod_fmly_id order by tbl.inrn_id) seq_id 
                             from ${dbcommonlr1uat}.bmt_pn_bsn_cat_frmwk_dmnsn tbl) a where a.seq_id =1 """)

    val pnNnFcsDmnsnDf = spark.sql(s"""select a.* from (select tbl.* ,row_number() over (partition by tbl.ba_cd,tbl.prft_ctr_cd,tbl.sgmt_lvl_2_cd,tbl.sgmt_lvl_3_cd,tbl.sgmt_lvl_4_cd,tbl.sgmt_lvl_5_cd order by tbl.inrn_id) seq_id 
                         from ${dbcommonlr1uat}.bmt_pn_nn_fcus_flg_ord_dmnsn tbl) a where a.seq_id=1""")

    val pnNnFcsDmnsnDf1 = spark.sql(s"""select a.* from (select tbl.*, row_number() over (partition by tbl.ba_cd,tbl.prft_ctr_cd,tbl.sgmt_lvl_2_cd,tbl.sgmt_lvl_3_cd,tbl.sgmt_lvl_4_cd,tbl.sgmt_lvl_5_cd,tbl.ff_l15_cd order by tbl.inrn_id) seq_id 
                          from ${dbcommonlr1uat}.bmt_pn_nn_fcus_flg_actl_dmnsn tbl) a where a.seq_id=1""")

    val pnFnclFrmwkDf = spark.sql(s"""select a.* from (select tbl.*,row_number() over (partition by tbl.pft_cntr,tbl.acct_cd,tbl.mru_cd,tbl.cst_obj,tbl.fnctl_ar order by tbl.precedence) seq_id
                        from ${dbcommonlr1uat}.bmt_pn_fncl_frmwk_dmnsn tbl)a where a.seq_id=1""")

    val serpSelectDf = salesshipmentdf.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "pkg_prod_id", "itm_vl_usr_stts_cd").distinct.repartition(col("sls_ord_id"), col("sls_ord_ln_itm_id"))

    /*
     * Joining SERP base table with Point Next BMT Step 1
     *
     * 1.a Match the identified joining column between two dataset
     * 1.b if value all is passed then data set should be joined on all the available records
     */

    val serpJoinedPnptflFrmwkDF = serpSelectDf.alias("serpCol").join(
      broadcast(pnPtflFrmwkDmnsn).alias("pnPtflFrmwkCol"),
      (serpSelectDf("prft_cntr_cd") === pnPtflFrmwkDmnsn("pft_cntr_cd") || pnPtflFrmwkDmnsn("pft_cntr_cd") === "all")
        && (serpSelectDf("sgmtl_rptg_cd") === pnPtflFrmwkDmnsn("sgm_cd") || pnPtflFrmwkDmnsn("sgm_cd") === "all")
        && (serpSelectDf("pkg_prod_id") === pnPtflFrmwkDmnsn("bmt_pkg_prod_id") || pnPtflFrmwkDmnsn("bmt_pkg_prod_id") === "all")
        && (serpSelectDf("itm_vl_usr_stts_cd") === pnPtflFrmwkDmnsn("bs_prod_id") || pnPtflFrmwkDmnsn("bs_prod_id") === "all"), "leftouter").filter(pnPtflFrmwkDmnsn("inrn_id").isNotNull).select("serpCol.*", "pnPtflFrmwkCol.ln_itm_1_cd", "pnPtflFrmwkCol.ln_itm_2_cd", "pnPtflFrmwkCol.ln_itm_3_cd", "pnPtflFrmwkCol.ln_itm_4_ofr_cd", "pnPtflFrmwkCol.ln_itm_5_sla_cvrg_cd", "pnPtflFrmwkCol.ln_itm_6_typ_cd", "pnPtflFrmwkCol.ln_itm_7_durtn_cd", "pnPtflFrmwkCol.inrn_id", "pnPtflFrmwkCol.pft_cntr_cd", "pnPtflFrmwkCol.sgm_cd", "pnPtflFrmwkCol.bmt_pkg_prod_id", "pnPtflFrmwkCol.bs_prod_id")

    logger.info("********************************************* serpJoinedDf write to table")

    val serpJoinedPnptflFrmwkStgDF = serpJoinedPnptflFrmwkDF
    val serpJoinedPnptflFrmwkDeDupDF = Utilities.getLatestRecs(serpJoinedPnptflFrmwkStgDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "pkg_prod_id", "itm_vl_usr_stts_cd"), List("inrn_id"))

    serpJoinedPnptflFrmwkDF.repartition(col("sls_ord_id"), col("sls_ord_ln_itm_id"))

    /*
     * Joining SERP base table with Point Next BMT Step 2
     *
     * 2.a join back the data set prepared in
     * 2.b if value all is passed then data set should be joined on all the available records
     */

    val serpJoinedPnptflFrmwkFinalDF = salesshipmentdf.alias("serpCol").join(
      (serpJoinedPnptflFrmwkDeDupDF).alias("JoinedDfCol"),
      salesshipmentdf("sls_ord_id") === serpJoinedPnptflFrmwkDeDupDF("sls_ord_id") && salesshipmentdf("sls_ord_ln_itm_id") === serpJoinedPnptflFrmwkDeDupDF("sls_ord_ln_itm_id") &&
        ((salesshipmentdf("prft_cntr_cd").isNull && serpJoinedPnptflFrmwkDeDupDF("prft_cntr_cd").isNull) || salesshipmentdf("prft_cntr_cd") === serpJoinedPnptflFrmwkDeDupDF("prft_cntr_cd"))
        && ((salesshipmentdf("sgmtl_rptg_cd").isNull && serpJoinedPnptflFrmwkDeDupDF("sgmtl_rptg_cd").isNull) || salesshipmentdf("sgmtl_rptg_cd") === serpJoinedPnptflFrmwkDeDupDF("sgmtl_rptg_cd"))
        && ((salesshipmentdf("pkg_prod_id").isNull && serpJoinedPnptflFrmwkDeDupDF("pkg_prod_id").isNull) || salesshipmentdf("pkg_prod_id") === serpJoinedPnptflFrmwkDeDupDF("pkg_prod_id"))
        && ((salesshipmentdf("itm_vl_usr_stts_cd").isNull && serpJoinedPnptflFrmwkDeDupDF("itm_vl_usr_stts_cd").isNull) || salesshipmentdf("itm_vl_usr_stts_cd") === serpJoinedPnptflFrmwkDeDupDF("itm_vl_usr_stts_cd")), "leftouter").select("serpCol.*", "JoinedDfCol.ln_itm_1_cd", "JoinedDfCol.ln_itm_2_cd", "JoinedDfCol.ln_itm_3_cd", "JoinedDfCol.ln_itm_4_ofr_cd", "JoinedDfCol.ln_itm_5_sla_cvrg_cd", "JoinedDfCol.ln_itm_6_typ_cd", "JoinedDfCol.ln_itm_7_durtn_cd", "JoinedDfCol.inrn_id", "JoinedDfCol.pft_cntr_cd", "JoinedDfCol.sgm_cd", "JoinedDfCol.bmt_pkg_prod_id", "JoinedDfCol.bs_prod_id")

    logger.info("********************************************* finalDf write to table")

    val serpSelectDfpnHwFrmwk = serpJoinedPnptflFrmwkFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "gbl_carepack_hw_prod_ln_id", "pm_mtrl_mstr_sls_dvsn_cd", "pmd_mtrl_mstr_sls_dvsn_cd", "prod_hrchy_prod_typ_cd", "itm_vl_usr_stts_cd").distinct

    val serpJoinedPnptflFrmwkOldDF = serpSelectDfpnHwFrmwk.alias("serpDF").join(
      broadcast(pnHwFrmwkDmnsnDf).alias("pnHwFrmwkCol"),
      (serpSelectDfpnHwFrmwk("prft_cntr_cd") === pnHwFrmwkDmnsnDf("pft_cntr_cd") || pnHwFrmwkDmnsnDf("pft_cntr_cd") === "all") && (serpSelectDfpnHwFrmwk("sgmtl_rptg_cd") === pnHwFrmwkDmnsnDf("sgm_cd") || pnHwFrmwkDmnsnDf("sgm_cd") === "all") && ((pnHwFrmwkDmnsnDf("gbl_carepack_hw_prod_ln_id") === "all" && ((serpSelectDfpnHwFrmwk("gbl_carepack_hw_prod_ln_id") === pnHwFrmwkDmnsnDf("hw_prod_ln_cd")) || pnHwFrmwkDmnsnDf("hw_prod_ln_cd") === "all")) || (pnHwFrmwkDmnsnDf("srv_gds_prod_ln_id") === "all" && ((serpSelectDfpnHwFrmwk("pm_mtrl_mstr_sls_dvsn_cd") === pnHwFrmwkDmnsnDf("hw_prod_ln_cd")) || pnHwFrmwkDmnsnDf("hw_prod_ln_cd") === "all")) || (pnHwFrmwkDmnsnDf("mfrg_prod_prod_ln_id") === "all" && ((serpSelectDfpnHwFrmwk("pmd_mtrl_mstr_sls_dvsn_cd") === pnHwFrmwkDmnsnDf("hw_prod_ln_cd")) || pnHwFrmwkDmnsnDf("hw_prod_ln_cd") === "all")))
        && (serpSelectDfpnHwFrmwk("prod_hrchy_prod_typ_cd") === pnHwFrmwkDmnsnDf("bs_prod_typ_cd") || pnHwFrmwkDmnsnDf("bs_prod_typ_cd") === "all") && (serpSelectDfpnHwFrmwk("itm_vl_usr_stts_cd") === pnHwFrmwkDmnsnDf("bs_prod_id") || pnHwFrmwkDmnsnDf("bs_prod_id") === "all"), "leftouter").filter(pnHwFrmwkDmnsnDf("inrn_id").isNotNull).select("serpDF.*", "pnHwFrmwkCol.hw_lvl_1_cd", "pnHwFrmwkCol.hw_lvl_2_cd", "pnHwFrmwkCol.hw_lvl_3_cd", "pnHwFrmwkCol.hw_lvl_4_cd", "pnHwFrmwkCol.hw_lvl_5_cd", "pnHwFrmwkCol.hw_lvl_6_cd", "pnHwFrmwkCol.inrn_id", "pnHwFrmwkCol.hw_prod_ln_cd")

    logger.info("********************************************* serpJoinedPnptflFrmwkOldDF write to table")

    val joinCondition = when(serpJoinedPnptflFrmwkOldDF("gbl_carepack_hw_prod_ln_id").isNotNull && serpJoinedPnptflFrmwkOldDF("gbl_carepack_hw_prod_ln_id") === serpJoinedPnptflFrmwkOldDF("hw_prod_ln_cd"), "1").when(serpJoinedPnptflFrmwkOldDF("pm_mtrl_mstr_sls_dvsn_cd").isNotNull && serpJoinedPnptflFrmwkOldDF("pm_mtrl_mstr_sls_dvsn_cd") === serpJoinedPnptflFrmwkOldDF("hw_prod_ln_cd"), "2").when(serpJoinedPnptflFrmwkOldDF("pmd_mtrl_mstr_sls_dvsn_cd").isNotNull && serpJoinedPnptflFrmwkOldDF("pmd_mtrl_mstr_sls_dvsn_cd") === serpJoinedPnptflFrmwkOldDF("hw_prod_ln_cd"), "3").otherwise("4")

    val serpJoinedValidHwPlDf = serpJoinedPnptflFrmwkOldDF.withColumn("valid_hw_pl", joinCondition)

    val serpJoinedValidHwPlDeDupDf = Utilities.getLatestRecs(serpJoinedValidHwPlDf, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "gbl_carepack_hw_prod_ln_id", "pm_mtrl_mstr_sls_dvsn_cd", "pmd_mtrl_mstr_sls_dvsn_cd",
      "prod_hrchy_prod_typ_cd", "itm_vl_usr_stts_cd"), List("inrn_id", "valid_hw_pl"))

    val serpJoinedPnHwFinalDF = serpJoinedPnptflFrmwkFinalDF.alias("serpDF").join(
      (serpJoinedValidHwPlDeDupDf).alias("pnHwFrmwkCol"),
      serpJoinedPnptflFrmwkFinalDF("sls_ord_id") === serpJoinedValidHwPlDeDupDf("sls_ord_id") && serpJoinedPnptflFrmwkFinalDF("sls_ord_ln_itm_id") === serpJoinedValidHwPlDeDupDf("sls_ord_ln_itm_id") &&
        ((serpJoinedPnptflFrmwkFinalDF("prft_cntr_cd").isNull && serpJoinedValidHwPlDeDupDf("prft_cntr_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("prft_cntr_cd") === serpJoinedValidHwPlDeDupDf("prft_cntr_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("sgmtl_rptg_cd").isNull && serpJoinedValidHwPlDeDupDf("sgmtl_rptg_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("sgmtl_rptg_cd") === serpJoinedValidHwPlDeDupDf("sgmtl_rptg_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("gbl_carepack_hw_prod_ln_id").isNull && serpJoinedValidHwPlDeDupDf("gbl_carepack_hw_prod_ln_id").isNull) || serpJoinedPnptflFrmwkFinalDF("gbl_carepack_hw_prod_ln_id") === serpJoinedValidHwPlDeDupDf("gbl_carepack_hw_prod_ln_id"))
        && ((serpJoinedPnptflFrmwkFinalDF("pm_mtrl_mstr_sls_dvsn_cd").isNull && serpJoinedValidHwPlDeDupDf("pm_mtrl_mstr_sls_dvsn_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("pm_mtrl_mstr_sls_dvsn_cd") === serpJoinedValidHwPlDeDupDf("pm_mtrl_mstr_sls_dvsn_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("pmd_mtrl_mstr_sls_dvsn_cd").isNull && serpJoinedValidHwPlDeDupDf("pmd_mtrl_mstr_sls_dvsn_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("pmd_mtrl_mstr_sls_dvsn_cd") === serpJoinedValidHwPlDeDupDf("pmd_mtrl_mstr_sls_dvsn_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("prod_hrchy_prod_typ_cd").isNull && serpJoinedValidHwPlDeDupDf("prod_hrchy_prod_typ_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("prod_hrchy_prod_typ_cd") === serpJoinedValidHwPlDeDupDf("prod_hrchy_prod_typ_cd"))
        && ((serpJoinedPnptflFrmwkFinalDF("itm_vl_usr_stts_cd").isNull && serpJoinedValidHwPlDeDupDf("itm_vl_usr_stts_cd").isNull) || serpJoinedPnptflFrmwkFinalDF("itm_vl_usr_stts_cd") === serpJoinedValidHwPlDeDupDf("itm_vl_usr_stts_cd")), "leftouter").select("serpDF.*", "pnHwFrmwkCol.hw_lvl_1_cd", "pnHwFrmwkCol.hw_lvl_2_cd", "pnHwFrmwkCol.hw_lvl_3_cd", "pnHwFrmwkCol.hw_lvl_4_cd", "pnHwFrmwkCol.hw_lvl_5_cd", "pnHwFrmwkCol.hw_lvl_6_cd").distinct

    logger.info("********************************************* serpJoinedPnptflFrmwkOldDF write to table")

    val serpSelectDfpnSlngMtnFrmwk = serpJoinedPnHwFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "ord_typ_cd", "sls_mtrc_cd", "prft_cntr_cd", "sgmtl_rptg_cd", "itm_vl_usr_stts_cd", "prod_hrchy_prod_fmly_cd").distinct

    val serpJoinedSlngMtnFrmwkDF = serpSelectDfpnSlngMtnFrmwk.alias("serpDF").join(
      broadcast(pnSlngMtnFrmwkDmnsnDf).alias("pnSlngMtnFrmwkCol"),
      (serpSelectDfpnSlngMtnFrmwk("ord_typ_cd") === pnSlngMtnFrmwkDmnsnDf("sls_ord_typ_cd") || pnSlngMtnFrmwkDmnsnDf("sls_ord_typ_cd") === "all")
        && (serpSelectDfpnSlngMtnFrmwk("sls_mtrc_cd") === pnSlngMtnFrmwkDmnsnDf("bsn_typ_cd") || pnSlngMtnFrmwkDmnsnDf("bsn_typ_cd") === "all")
        && (serpSelectDfpnSlngMtnFrmwk("prft_cntr_cd") === pnSlngMtnFrmwkDmnsnDf("pft_cntr_cd") || pnSlngMtnFrmwkDmnsnDf("pft_cntr_cd") === "all")
        && (serpSelectDfpnSlngMtnFrmwk("sgmtl_rptg_cd") === pnSlngMtnFrmwkDmnsnDf("sgm_cd") || pnSlngMtnFrmwkDmnsnDf("sgm_cd") === "all")
        && ((serpSelectDfpnSlngMtnFrmwk("itm_vl_usr_stts_cd") === pnSlngMtnFrmwkDmnsnDf("bs_prod_id") || (substring(trim(serpSelectDfpnSlngMtnFrmwk("itm_vl_usr_stts_cd")), -2, 2) === substring(trim(pnSlngMtnFrmwkDmnsnDf("bs_prod_id")), -2, 2)
          && (pnSlngMtnFrmwkDmnsnDf("bs_prod_id").like("*%")))) || pnSlngMtnFrmwkDmnsnDf("bs_prod_id") === "all")
          && (serpSelectDfpnSlngMtnFrmwk("prod_hrchy_prod_fmly_cd") === pnSlngMtnFrmwkDmnsnDf("mfrg_prod_fmly_id") || pnSlngMtnFrmwkDmnsnDf("mfrg_prod_fmly_id") === "all"), "leftouter").filter(pnSlngMtnFrmwkDmnsnDf("inrn_id").isNotNull).select("serpDF.*", "pnSlngMtnFrmwkCol.slng_mtn_lvl_1_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_2_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_3_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_4_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_5_cd", "pnSlngMtnFrmwkCol.inrn_id")

    val serpJoinedSlngMtnFrmwkDeDupDF = Utilities.getLatestRecs(serpJoinedSlngMtnFrmwkDF, List("sls_ord_id", "sls_ord_ln_itm_id", "ord_typ_cd", "sls_mtrc_cd", "prft_cntr_cd", "sgmtl_rptg_cd", "itm_vl_usr_stts_cd",
      "prod_hrchy_prod_fmly_cd"), List("inrn_id"))

    val serpJoinedSlngMtnFrmwkFinalDF = serpJoinedPnHwFinalDF.alias("serpCol").join(
      (serpJoinedSlngMtnFrmwkDeDupDF).alias("pnSlngMtnFrmwkCol"),
      (serpJoinedPnHwFinalDF("sls_ord_id") === serpJoinedSlngMtnFrmwkDeDupDF("sls_ord_id") && serpJoinedPnHwFinalDF("sls_ord_ln_itm_id") === serpJoinedSlngMtnFrmwkDeDupDF("sls_ord_ln_itm_id")) &&
        ((serpJoinedPnHwFinalDF("ord_typ_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("ord_typ_cd").isNull) || serpJoinedPnHwFinalDF("ord_typ_cd") === serpJoinedSlngMtnFrmwkDeDupDF("ord_typ_cd"))
        && ((serpJoinedPnHwFinalDF("sls_mtrc_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("sls_mtrc_cd").isNull) || serpJoinedPnHwFinalDF("sls_mtrc_cd") === serpJoinedSlngMtnFrmwkDeDupDF("sls_mtrc_cd"))
        && ((serpJoinedPnHwFinalDF("prft_cntr_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("prft_cntr_cd").isNull) || serpJoinedPnHwFinalDF("prft_cntr_cd") === serpJoinedSlngMtnFrmwkDeDupDF("prft_cntr_cd"))
        && ((serpJoinedPnHwFinalDF("sgmtl_rptg_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("sgmtl_rptg_cd").isNull) || serpJoinedPnHwFinalDF("sgmtl_rptg_cd") === serpJoinedSlngMtnFrmwkDeDupDF("sgmtl_rptg_cd"))
        && ((serpJoinedPnHwFinalDF("itm_vl_usr_stts_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("itm_vl_usr_stts_cd").isNull) || serpJoinedPnHwFinalDF("itm_vl_usr_stts_cd") === serpJoinedSlngMtnFrmwkDeDupDF("itm_vl_usr_stts_cd"))
        && ((serpJoinedPnHwFinalDF("prod_hrchy_prod_fmly_cd").isNull && serpJoinedSlngMtnFrmwkDeDupDF("prod_hrchy_prod_fmly_cd").isNull) || serpJoinedPnHwFinalDF("prod_hrchy_prod_fmly_cd") === serpJoinedSlngMtnFrmwkDeDupDF("prod_hrchy_prod_fmly_cd")), "leftouter").select("serpCol.*", "pnSlngMtnFrmwkCol.slng_mtn_lvl_1_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_2_cd",
        "pnSlngMtnFrmwkCol.slng_mtn_lvl_3_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_4_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_5_cd").distinct

    logger.info("********************************************* serpJoinedSlngMtnFrmwkFinalDF write to table")

    //serpJoinedSlngMtnFrmwkFinalDF.persist(MEMORY_AND_DISK)

    //logger.info("+++++++++++################## serpJoinedSlngMtnFrmwkFinalDF Count:" + serpJoinedSlngMtnFrmwkFinalDF.count.toLong)

    val serpSelectDfpnBsnCatFrmwk = serpJoinedSlngMtnFrmwkFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "hw_lvl_4_cd", "sls_mtrc_cd", "itm_vl_usr_stts_cd", "prod_hrchy_prod_fmly_cd", "ln_itm_3_cd").distinct

    val serpJoinedPnBsnCatFrmwkDF = serpSelectDfpnBsnCatFrmwk.alias("serpDF").join(
      broadcast(pnBsnCatFrmwkDmnsn).alias("pnBsnCatFrmwkCol"),
      (serpSelectDfpnBsnCatFrmwk("prft_cntr_cd") === pnBsnCatFrmwkDmnsn("pft_cntr_cd") || pnBsnCatFrmwkDmnsn("pft_cntr_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("sgmtl_rptg_cd") === pnBsnCatFrmwkDmnsn("sgm_cd") || pnBsnCatFrmwkDmnsn("sgm_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("hw_lvl_4_cd") === pnBsnCatFrmwkDmnsn("hw_lvl_4_cd") || pnBsnCatFrmwkDmnsn("hw_lvl_4_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("sls_mtrc_cd") === pnBsnCatFrmwkDmnsn("bsn_typ_cd") || pnBsnCatFrmwkDmnsn("bsn_typ_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("itm_vl_usr_stts_cd") === pnBsnCatFrmwkDmnsn("bs_prod_id")
          || ((pnBsnCatFrmwkDmnsn("bs_prod_id").like("*%")) && (serpSelectDfpnBsnCatFrmwk("itm_vl_usr_stts_cd").rlike((concat(lit("."), trim(pnBsnCatFrmwkDmnsn("bs_prod_id"))).toString())))) || pnBsnCatFrmwkDmnsn("bs_prod_id") === "all")
          && (serpSelectDfpnBsnCatFrmwk("prod_hrchy_prod_fmly_cd") === pnBsnCatFrmwkDmnsn("mfrg_prod_fmly_id") || pnBsnCatFrmwkDmnsn("mfrg_prod_fmly_id") === "all")
          && (serpSelectDfpnBsnCatFrmwk("ln_itm_3_cd") === pnBsnCatFrmwkDmnsn("ln_itm_3_cd") || pnBsnCatFrmwkDmnsn("ln_itm_3_cd") === "all"), "leftouter").filter(pnBsnCatFrmwkDmnsn("inrn_id").isNotNull).select("serpDF.*", "pnBsnCatFrmwkCol.bsn_cgy_lvl_1_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_2_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_3_cd", "pnBsnCatFrmwkCol.inrn_id")

    val serpJoinedPnBsnCatFrmwkDeDupDF = Utilities.getLatestRecs(serpJoinedPnBsnCatFrmwkDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "hw_lvl_4_cd", "sls_mtrc_cd", "itm_vl_usr_stts_cd", "prod_hrchy_prod_fmly_cd", "ln_itm_3_cd"), List("inrn_id"))

    val serpJoinedPnBsnCatFrmwkFinalDF = serpJoinedSlngMtnFrmwkFinalDF.alias("serpJoindCol").join(
      (serpJoinedPnBsnCatFrmwkDeDupDF).alias("pnBsnCatFrmwkCol"),
      serpJoinedSlngMtnFrmwkFinalDF("sls_ord_id") === serpJoinedPnBsnCatFrmwkDeDupDF("sls_ord_id") && serpJoinedSlngMtnFrmwkFinalDF("sls_ord_ln_itm_id") === serpJoinedPnBsnCatFrmwkDeDupDF("sls_ord_ln_itm_id") &&
        ((serpJoinedSlngMtnFrmwkFinalDF("prft_cntr_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("prft_cntr_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("prft_cntr_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("prft_cntr_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("sgmtl_rptg_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("sgmtl_rptg_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("sgmtl_rptg_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("sgmtl_rptg_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("hw_lvl_4_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("hw_lvl_4_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("hw_lvl_4_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("hw_lvl_4_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("sls_mtrc_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("sls_mtrc_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("sls_mtrc_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("sls_mtrc_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("itm_vl_usr_stts_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("itm_vl_usr_stts_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("itm_vl_usr_stts_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("itm_vl_usr_stts_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("prod_hrchy_prod_fmly_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("prod_hrchy_prod_fmly_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("prod_hrchy_prod_fmly_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("prod_hrchy_prod_fmly_cd"))
        && ((serpJoinedSlngMtnFrmwkFinalDF("ln_itm_3_cd").isNull && serpJoinedPnBsnCatFrmwkDeDupDF("ln_itm_3_cd").isNull) || serpJoinedSlngMtnFrmwkFinalDF("ln_itm_3_cd") === serpJoinedPnBsnCatFrmwkDeDupDF("ln_itm_3_cd")), "leftouter").select("serpJoindCol.*", "pnBsnCatFrmwkCol.bsn_cgy_lvl_1_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_2_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_3_cd")

    logger.info("********************************************* serpJoinedPnBsnCatFrmwkFinalDF write to table")

    //logger.info("+++++++++++################## serpJoinedPnBsnCatFrmwkFinalDF Count:" + serpJoinedPnBsnCatFrmwkFinalDF.count.toLong)

    val serpSelectDfpnNnFcsDmnsn = serpJoinedPnBsnCatFrmwkFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5").distinct

    val serpJoinedPnNnFcsDF = serpSelectDfpnNnFcsDmnsn.alias("serpJoindCol1").join(
      broadcast(pnNnFcsDmnsnDf).alias("pnNnFcsDmnsnCol"),
      (serpSelectDfpnNnFcsDmnsn("prft_cntr_cd") === pnNnFcsDmnsnDf("prft_ctr_cd") || pnNnFcsDmnsnDf("prft_ctr_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_2") === pnNnFcsDmnsnDf("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf("sgmt_lvl_2_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_3") === pnNnFcsDmnsnDf("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf("sgmt_lvl_3_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_4") === pnNnFcsDmnsnDf("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf("sgmt_lvl_4_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_5") === pnNnFcsDmnsnDf("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf("sgmt_lvl_5_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_2") != pnNnFcsDmnsnDf("sgmt_lvl_2_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_3") != pnNnFcsDmnsnDf("sgmt_lvl_3_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_4") != pnNnFcsDmnsnDf("sgmt_lvl_4_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_5") != pnNnFcsDmnsnDf("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf("inrn_id").isNotNull).select("serpJoindCol1.*", "pnNnFcsDmnsnCol.nn_fcs_cntry", "pnNnFcsDmnsnCol.inrn_id")

    val serpJoinedPnNnFcsDeDupDF = Utilities.getLatestRecs(serpJoinedPnNnFcsDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5"), List("inrn_id"))

    var serpJoinedPnNnFcsFinalDF = serpJoinedPnBsnCatFrmwkFinalDF.alias("serpJoindCol").join(
      (serpJoinedPnNnFcsDeDupDF).alias("pnNnFcsDmnsnCol"),
      serpJoinedPnBsnCatFrmwkFinalDF("sls_ord_id") === serpJoinedPnNnFcsDeDupDF("sls_ord_id") && serpJoinedPnBsnCatFrmwkFinalDF("sls_ord_ln_itm_id") === serpJoinedPnNnFcsDeDupDF("sls_ord_ln_itm_id") &&
        ((serpJoinedPnBsnCatFrmwkFinalDF("prft_cntr_cd").isNull && serpJoinedPnNnFcsDeDupDF("prft_cntr_cd").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("prft_cntr_cd") === serpJoinedPnNnFcsDeDupDF("prft_cntr_cd"))
        && ((serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_2").isNull && serpJoinedPnNnFcsDeDupDF("sgm_lvl_2").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_2") === serpJoinedPnNnFcsDeDupDF("sgm_lvl_2"))
        && ((serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_3").isNull && serpJoinedPnNnFcsDeDupDF("sgm_lvl_3").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_3") === serpJoinedPnNnFcsDeDupDF("sgm_lvl_3"))
        && ((serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_4").isNull && serpJoinedPnNnFcsDeDupDF("sgm_lvl_4").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_4") === serpJoinedPnNnFcsDeDupDF("sgm_lvl_4"))
        && ((serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_5").isNull && serpJoinedPnNnFcsDeDupDF("sgm_lvl_5").isNull) || serpJoinedPnBsnCatFrmwkFinalDF("sgm_lvl_5") === serpJoinedPnNnFcsDeDupDF("sgm_lvl_5")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry")

    logger.info("********************************************* serpJoinedPnNnFcsFinalDF write to table")

    serpJoinedPnNnFcsFinalDF = serpJoinedPnNnFcsFinalDF.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_ord")

    val serpSelectDfpnFnclFrmwk = serpJoinedPnNnFcsFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "gl_acct_nr", "MRU", "cst_cntr_cd", "fnctl_ar_cd").distinct

    var serpJoinedPnFnclDF = serpSelectDfpnFnclFrmwk.alias("serpJoindCol2").join(
      broadcast(pnFnclFrmwkDf).alias("pnFnclFrmwkCol"),
      (serpSelectDfpnFnclFrmwk("prft_cntr_cd") === pnFnclFrmwkDf("pft_cntr") || pnFnclFrmwkDf("pft_cntr") === "all")
        && (substring(serpSelectDfpnFnclFrmwk("gl_acct_nr"), 3, 8) === pnFnclFrmwkDf("acct_cd") || pnFnclFrmwkDf("acct_cd") === "all")
        && (serpSelectDfpnFnclFrmwk("MRU") === pnFnclFrmwkDf("mru_cd") || pnFnclFrmwkDf("mru_cd") === "all")
        && (serpSelectDfpnFnclFrmwk("cst_cntr_cd") === pnFnclFrmwkDf("cst_obj") || pnFnclFrmwkDf("cst_obj") === "all")
        && (serpSelectDfpnFnclFrmwk("fnctl_ar_cd") === pnFnclFrmwkDf("fnctl_ar") || pnFnclFrmwkDf("fnctl_ar") === "all"), "leftouter").filter(pnFnclFrmwkDf("precedence").isNotNull).select("serpJoindCol2.*", "pnFnclFrmwkCol.ff_ln_itm_0", "pnFnclFrmwkCol.ff_ln_itm_1", "pnFnclFrmwkCol.ff_ln_itm_2",
        "pnFnclFrmwkCol.ff_ln_itm_3", "pnFnclFrmwkCol.ff_ln_itm_4", "pnFnclFrmwkCol.ff_ln_itm_5", "pnFnclFrmwkCol.precedence")

    var serpJoinedPnFnclDeDupDF = Utilities.getLatestRecs(serpJoinedPnFnclDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "gl_acct_nr", "MRU", "cst_cntr_cd", "fnctl_ar_cd"), List("precedence"))

    serpJoinedPnFnclDeDupDF = serpJoinedPnFnclDeDupDF.select(serpJoinedPnFnclDeDupDF.columns.toList.map(c => col(c).alias(c + "_tmp")).toList: _*)

    var serpJoinedPnFnclFinalDF = serpJoinedPnNnFcsFinalDF.alias("serpJoindCol").join(
      (serpJoinedPnFnclDeDupDF).alias("pnFnclFrmwkCol"),
      serpJoinedPnNnFcsFinalDF("sls_ord_id") === serpJoinedPnFnclDeDupDF("sls_ord_id_tmp") && serpJoinedPnNnFcsFinalDF("sls_ord_ln_itm_id") === serpJoinedPnFnclDeDupDF("sls_ord_ln_itm_id_tmp") &&
        ((serpJoinedPnNnFcsFinalDF("prft_cntr_cd").isNull && serpJoinedPnFnclDeDupDF("prft_cntr_cd_tmp").isNull) || serpJoinedPnNnFcsFinalDF("prft_cntr_cd") === serpJoinedPnFnclDeDupDF("prft_cntr_cd_tmp"))
        && ((serpJoinedPnNnFcsFinalDF("gl_acct_nr").isNull && serpJoinedPnFnclDeDupDF("gl_acct_nr_tmp").isNull) || serpJoinedPnNnFcsFinalDF("gl_acct_nr") === serpJoinedPnFnclDeDupDF("gl_acct_nr_tmp"))
        && ((serpJoinedPnNnFcsFinalDF("MRU").isNull && serpJoinedPnFnclDeDupDF("MRU_tmp").isNull) || serpJoinedPnNnFcsFinalDF("MRU") === serpJoinedPnFnclDeDupDF("MRU_tmp"))
        && ((serpJoinedPnNnFcsFinalDF("cst_cntr_cd").isNull && serpJoinedPnFnclDeDupDF("cst_cntr_cd_tmp").isNull) || serpJoinedPnNnFcsFinalDF("cst_cntr_cd") === serpJoinedPnFnclDeDupDF("cst_cntr_cd_tmp"))
        && ((serpJoinedPnNnFcsFinalDF("fnctl_ar_cd").isNull && serpJoinedPnFnclDeDupDF("fnctl_ar_cd_tmp").isNull) || serpJoinedPnNnFcsFinalDF("fnctl_ar_cd") === serpJoinedPnFnclDeDupDF("fnctl_ar_cd_tmp")), "leftouter").select("serpJoindCol.*", "pnFnclFrmwkCol.ff_ln_itm_0_tmp", "pnFnclFrmwkCol.ff_ln_itm_1_tmp", "pnFnclFrmwkCol.ff_ln_itm_2_tmp", "pnFnclFrmwkCol.ff_ln_itm_3_tmp", "pnFnclFrmwkCol.ff_ln_itm_4_tmp", "pnFnclFrmwkCol.ff_ln_itm_5_tmp", "pnFnclFrmwkCol.precedence_tmp")

    val serpSelectDfpnNnFcsDmnsn1 = serpJoinedPnFnclFinalDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "ff_ln_itm_5_tmp").distinct

    logger.info("********************************************* serpJoinedPnFnclFinalDF write to table")

    var serpJoinedNewPnNnFcsDF = serpSelectDfpnNnFcsDmnsn1.alias("serpJoindCol1").join(
      broadcast(pnNnFcsDmnsnDf1).alias("pnNnFcsDmnsnCol1"),
      (serpSelectDfpnNnFcsDmnsn1("prft_cntr_cd") === pnNnFcsDmnsnDf1("prft_ctr_cd") || pnNnFcsDmnsnDf1("prft_ctr_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_2") === pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_3") === pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_4") === pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_5") === pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("ff_ln_itm_5_tmp") === pnNnFcsDmnsnDf1("ff_l15_cd") || pnNnFcsDmnsnDf1("ff_l15_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_2") != pnNnFcsDmnsnDf1("sgmt_lvl_2_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_3") != pnNnFcsDmnsnDf1("sgmt_lvl_3_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_4") != pnNnFcsDmnsnDf1("sgmt_lvl_4_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_5") != pnNnFcsDmnsnDf1("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf1("inrn_id").isNotNull).select("serpJoindCol1.*", "pnNnFcsDmnsnCol1.nn_fcs_cntry", "pnNnFcsDmnsnCol1.inrn_id")

    serpJoinedNewPnNnFcsDF = serpJoinedNewPnNnFcsDF.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_actl")

    val serpJoinedNewPnNnFcsDeDupDF = Utilities.getLatestRecs(serpJoinedNewPnNnFcsDF, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "ff_ln_itm_5_tmp"), List("inrn_id"))

    var serpJoinedNewPnNnFcsFinalDF = serpJoinedPnFnclFinalDF.alias("serpJoindCol").join(
      (serpJoinedNewPnNnFcsDeDupDF).alias("pnNnFcsDmnsnCol"),
      serpJoinedPnFnclFinalDF("sls_ord_id") === serpJoinedNewPnNnFcsDeDupDF("sls_ord_id") && serpJoinedPnFnclFinalDF("sls_ord_ln_itm_id") === serpJoinedNewPnNnFcsDeDupDF("sls_ord_ln_itm_id") &&
        ((serpJoinedPnFnclFinalDF("prft_cntr_cd").isNull && serpJoinedNewPnNnFcsDeDupDF("prft_cntr_cd").isNull) || serpJoinedPnFnclFinalDF("prft_cntr_cd") === serpJoinedNewPnNnFcsDeDupDF("prft_cntr_cd"))
        && ((serpJoinedPnFnclFinalDF("sgm_lvl_2").isNull && serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_2").isNull) || serpJoinedPnFnclFinalDF("sgm_lvl_2") === serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_2"))
        && ((serpJoinedPnFnclFinalDF("sgm_lvl_3").isNull && serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_3").isNull) || serpJoinedPnFnclFinalDF("sgm_lvl_3") === serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_3"))
        && ((serpJoinedPnFnclFinalDF("sgm_lvl_4").isNull && serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_4").isNull) || serpJoinedPnFnclFinalDF("sgm_lvl_4") === serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_4"))
        && ((serpJoinedPnFnclFinalDF("sgm_lvl_5").isNull && serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_5").isNull) || serpJoinedPnFnclFinalDF("sgm_lvl_5") === serpJoinedNewPnNnFcsDeDupDF("sgm_lvl_5"))
        && ((serpJoinedPnFnclFinalDF("ff_ln_itm_5_tmp").isNull && serpJoinedNewPnNnFcsDeDupDF("ff_ln_itm_5_tmp").isNull) || serpJoinedPnFnclFinalDF("ff_ln_itm_5_tmp") === serpJoinedNewPnNnFcsDeDupDF("ff_ln_itm_5_tmp")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry_actl")

    logger.info("********************************************* SERP BMT join completed ")

    val serpSelectDF = serpJoinedNewPnNnFcsFinalDF.withColumn("cust_po_id", upper(substring(col("cust_po_nr"), 1, 3))).select("sls_ord_id", "cust_po_id", "prft_cntr_cd", "bsn_cgy_lvl_1_cd").distinct

    val pnGreenLakeFlgDF = spark.sql(s"select greenlake_flg_cd,cust_po_id as cust_po_id_1,bsn_cgy_lvl_1_cd as bsn_cgy_lvl_1_cd_1,pft_cntr_cd from ${dbcommonlr1uat}.bmt_pn_greenlake_flg_dmnsn")

    var serpJoinedPNGreenLakeDF = serpSelectDF.alias("serpSelectDF").join(
      broadcast(pnGreenLakeFlgDF).alias("pnGreenLakeFlgDF"),
      ((serpSelectDF("cust_po_id") === pnGreenLakeFlgDF("cust_po_id_1")) || pnGreenLakeFlgDF("cust_po_id_1") === "all")
        && ((serpSelectDF("prft_cntr_cd") === pnGreenLakeFlgDF("pft_cntr_cd")) || pnGreenLakeFlgDF("pft_cntr_cd") === "all")
        && ((serpSelectDF("bsn_cgy_lvl_1_cd") === pnGreenLakeFlgDF("bsn_cgy_lvl_1_cd_1")) || pnGreenLakeFlgDF("bsn_cgy_lvl_1_cd_1") === "all"), "leftouter").select("pnGreenLakeFlgDF.*", "serpSelectDF.sls_ord_id")

    val serpJoinedPNGreenLakeDeDupDF = Utilities.getLatestRecs(serpJoinedPNGreenLakeDF, List("sls_ord_id", "cust_po_id_1", "pft_cntr_cd", "bsn_cgy_lvl_1_cd_1", "greenlake_flg_cd"), List("sls_ord_id"))

    val serpJoinedNewPnNnFcsFinalDF_new = serpJoinedNewPnNnFcsFinalDF.withColumn("cust_po_id", upper(substring(col("cust_po_nr"), 1, 3)))

    var serpJoinedPNGreenLakeFinalDF = serpJoinedNewPnNnFcsFinalDF_new.alias("serpJoinedNewPnNnFcsFinalDF_new").join(
      (serpJoinedPNGreenLakeDeDupDF).alias("serpJoinedPNGreenLakeDeDupDF"),
      serpJoinedNewPnNnFcsFinalDF_new("sls_ord_id") === serpJoinedPNGreenLakeDeDupDF("sls_ord_id")
        && ((serpJoinedNewPnNnFcsFinalDF_new("cust_po_id") === serpJoinedPNGreenLakeDeDupDF("cust_po_id_1")) || (serpJoinedNewPnNnFcsFinalDF_new("cust_po_id").isNull && serpJoinedPNGreenLakeDeDupDF("cust_po_id_1").isNull))
        && ((serpJoinedNewPnNnFcsFinalDF_new("prft_cntr_cd") === serpJoinedPNGreenLakeDeDupDF("pft_cntr_cd")) || (serpJoinedNewPnNnFcsFinalDF_new("prft_cntr_cd").isNull && serpJoinedPNGreenLakeDeDupDF("pft_cntr_cd").isNull))
        && ((serpJoinedNewPnNnFcsFinalDF_new("bsn_cgy_lvl_1_cd") === serpJoinedPNGreenLakeDeDupDF("bsn_cgy_lvl_1_cd_1")) || (serpJoinedNewPnNnFcsFinalDF_new("bsn_cgy_lvl_1_cd").isNull && serpJoinedPNGreenLakeDeDupDF("bsn_cgy_lvl_1_cd_1").isNull)), "leftouter").select("serpJoinedNewPnNnFcsFinalDF_new.*", "serpJoinedPNGreenLakeDeDupDF.greenlake_flg_cd").drop("prft_cntr_cd", "sgmtl_rptg_cd", "pkg_prod_id", "itm_vl_usr_stts_cd", "pm_mtrl_mstr_sls_dvsn_cd", "prod_hrchy_prod_typ_cd", "sls_mtrc_cd", "prod_hrchy_prod_fmly_cd", "MRU", "gl_acct_nr", "cst_cntr_cd", "fnctl_ar_cd", "gbl_carepack_hw_prod_ln_id", "pmd_mtrl_mstr_sls_dvsn_cd", "ord_typ_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "sgm_lvl_6", "sgm_lvl_7", "cust_po_nr")

    val tgtcolumns = spark.sql(s"select * from ${dbfinancnamelr1uat}.secrd_rpt_pn_dmnsn limit 0").columns

    // re-arrange columns based on target table

    val dataloaddf = serpJoinedPNGreenLakeFinalDF.select(Utilities.loadSelectExpr(serpJoinedPNGreenLakeFinalDF.columns, tgtcolumns): _*)

    dataloaddf.repartition(10).write.mode("overwrite").insertInto(dbfinancnamelr1uat + ".secrd_rpt_pn_dmnsn")

    logger.info("+++++++++++##################secrd_rpt_pn_dmnsn table loaded ##################+++++++++++")

    val tgtcount = spark.sql(s"select * from ${dbfinancnamelr1uat}.secrd_rpt_pn_dmnsn").count.toInt

    tgtcount match {
      case 0 =>
        logger.error("//************* data load failed")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtcount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* data loaded into " + tgtTblConsmtn + " ,count:" + tgtcount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtcount)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } finally {
    logger.info("//*********************** Log End for SERPSecuredReporting.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
package com.hpe.batch.driver.facts.balance_sheet_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import scala.util.control.Breaks._
import scala.collection.breakOut

object anet_rcncltn_itm_dmnsn extends App{
     val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true

  var ref_btch_id     = Utilities.readRefBatchId(sqlCon, "anet_rcncltn_itm",auditTbl)
  var cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, "anet_rcncltn_itm",auditTbl)
  
  logger.info("ref_btch_id :- "+ref_btch_id+" cnsmptn_btch_id :- "+cnsmptn_btch_id)
   
  logger.info("******************* anet_bsr_dmnsn load Started *****************")
  
  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()
  try {
    logger.info("Initializing log for ANET Dimension, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ref_btch_id)

    val consmptnTable = new StringBuilder()
    val dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    var hqlQueries = new StringBuilder()
    /* *************************************** Selecting source count ****************************** */
    val srcCount = spark.sql(s"""select count(*) from ${srcTable} where ld_jb_nr > '${cnsmptn_btch_id}'""").first().getLong(0)
    var tgtCount:Long = 0
    var loadStatus = false
    var tgtTbl = consmptnTable
    breakable 
    {
      /* ****************** Checking if source count is greater than zero or not ********************* */
      if(srcCount>0)
      {
         /* *********************************Inserting new data ******************************************* */
         spark.sql(s"""INSERT OVERWRITE TABLE ${dbNameConsmtn}.${consmptnTable} SELECT c.mapping_of_company_code_with_region_ctry_cd, c.mapping_of_company_code_with_region_countrygroup_cd, c.tr_cd, a.company_geo_level_1, a.company_geo_level_4, a.company_geo_level_5, a.account_number, a.account_segment_01, a.account_segment_02, a.account_segment_03, a.profit_center, a.segment, a.group_account_4digitafm, a.days_aged, a.ccy1_amount_abs, a.ccy1_amount, a.ccy1_code, a.ccy2_amount_abs, a.ccy2_amount, a.ccy2_code, a.date_1, a.date_1_label, a.date_2, a.date_2_label, case when a.days_aged < 31 then "A. 0-30 days" when a.days_aged < 61 then "B. 31-60 days" when a.days_aged < 91 then "C. 61-90 days" when a.days_aged < 121 then "D. 91-120 days" when a.days_aged < 181 then "E. 121-180" when a.days_aged < 365 then "F. 181-365" else "G. >365" end as general_ageing_bucket, a.aging_method, a.location, a.risk_rating, a.account_type, trim(concat_ws(' ',a.itemcategory_data,a.itemcategorybd_data,a.itemcategoryri_data)), a.effective_date, a.comments, a.actionplan_data, a.escdate_data, case when a.escdate_data is null then datediff(a.effective_date,a.date_1) else datediff(a.effective_date,a.escdate_data) end as escalatables_days, case when (case when a.escdate_data is null then datediff(a.effective_date,a.date_1) else datediff(a.effective_date,a.escdate_data) end) < 31 then "Escalatable Aging (0-30 days)" when (case when a.escdate_data is null then datediff(a.effective_date,a.date_1) else datediff(a.effective_date,a.escdate_data) end) < 61 then "Escalatable Aging (31-60 days)" when (case when a.escdate_data is null then datediff(a.effective_date,a.date_1) else datediff(a.effective_date,a.escdate_data) end) < 91 then "Escalatable Aging (61-90 days)" when (case when a.escdate_data is null then datediff(a.effective_date,a.date_1) else datediff(a.effective_date,a.escdate_data) end) < 121 then "Escalatable Aging (91-120 days)" when (case when a.escdate_data is null then datediff(a.effective_date,a.date_1) else datediff(a.effective_date,a.escdate_data) end) < 181 then "Escalatable Aging (121-180 days)" when (case when a.escdate_data is null then datediff(a.effective_date,a.date_1) else datediff(a.effective_date,a.escdate_data) end) < 366 then "Escalatable Aging (181-365 days)" else "Escalatable Aging > 365 days" end as escalatable_aging_bucket, a.jeworkflowsupport_data, a.plimpact_data, a.exoffset_data, a.netimpact_data, a.corpinvimpact_data, a.corpothimpact_data, a.hpfsimpact_data, a.uspubsecimpact_data, a.reconciler, a.reconciler_email, a.reconciler_org2, a.reconciler_org3, a.reconciler_org4, a.reconciler_org5, a.reconciler_org6, a.reconciler_country, a.reconciler_mgr3, a.reconciler_mgr4, a.reconciler_mgr5, a.reconciler_supervisor, a.reviewer, a.reviewer_email, a.reviewer_org2, a.reviewer_org3, a.reviewer_org4, a.reviewer_org5, a.reviewer_org6, a.reviewer_country, a.reviewer_mgr3, a.reviewer_mgr4, a.reviewer_mgr5, a.reviewer_supervisor, a.bs_statement_line_1, a.bs_statement_line_2, a.bs_statement_line_3, a.bs_statement_line_4, a.bs_statement_line_5, a.bs_statement_line_6, a.account_name, a.update_data, a.comments_data, a.contact_data, a.contractdet_data, a.contractnum_data, a.description_data, a.docnum_data, a.invoiceno_data, a.item_type, a.sourcecode_data, a.sourcesys_data, a.mega_process, a.sub_process, a.reconciler_mgr2, a.reviewer_mgr2, a.reviewer_checklist, a.costprofitcenter_data, case when month(a.effective_date) in ('11','12','1') then 'Q1' when month(a.effective_date) in ('2','3','4') then 'Q2' when month(a.effective_date) in ('5','6','7') then 'Q3' when month(a.effective_date) in ('8','9','10') then 'Q4' else null end as quarter, a.src_sys_upd_ts, a.src_sys_ky, a.lgcl_dlt_ind, a.ins_gmt_ts, a.upd_gmt_ts, a.src_sys_extrc_gmt_ts, a.src_sys_btch_nr, a.fl_nm, a.ld_jb_nr FROM ${srcTable} a left join (select distinct a.legalcompanycode_cd, a.mapping_of_company_code_with_region_ctry_cd, a.mapping_of_company_code_with_region_countrygroup_cd, b.tr_cd from ${dbNameConsmtn}.bmt_co_cd_rgn_mppg_dmnsn a left join ${dbNameConsmtn}.bmt_ctry_thrs_mppg_dmnsn b on a.mapping_of_company_code_with_region_countrygroup_cd = b.mapping_country_with_threshold_countrygroup_cd) c on a.account_segment_02 = c.legalcompanycode_cd where ld_jb_nr > '${cnsmptn_btch_id}'""")
         
         /* ************************ selecting target count ****************************************** */
         tgtCount = spark.sql(s"""select count(*) from ${dbNameConsmtn}.${tgtTbl}""").first().getLong(0)
         loadStatus = true
      }
    }
    
    /* ********************************************* Completion audit entries ************************** */
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
      logger.info("Load Successful")
    } else {
      auditObj.setAudJobStatusCode("failed")
      logger.info("Load Failed")
    }
    auditObj.setAudSrcRowCount(srcCount)
    auditObj.setAudTgtRowCount(tgtCount)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }   

  } finally {
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) {
      System.exit(1)
    }

  }
}
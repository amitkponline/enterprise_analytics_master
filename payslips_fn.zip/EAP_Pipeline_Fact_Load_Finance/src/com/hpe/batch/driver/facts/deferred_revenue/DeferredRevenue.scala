package com.hpe.batch.driver.facts.deferred_revenue

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{ DataFrame, SQLContext }
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import scala.util.control.Breaks._
import scala.collection.breakOut
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.functions.{ when, _ }
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{ from_unixtime, unix_timestamp }
import java.util.Calendar
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import scala.io.Source

object DeferredRevenue extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"

  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  logger.info("//********************** Log start for DeferredRevenue.scala *********************************//")
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var jobStatusFlag = true
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val dbCommonName = propertiesObject.getDbName().trim().split(",")(0)
  val dbfin = propertiesObject.getDbName().trim().split(",")(1)
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  try {

    //Utilities.paramCheck(Seq(tgtTblConsmtn, dbCommonName,dbCommonUAT, srcTableName))

    if (tgtTblConsmtn.split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

    def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
      val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*))
      val rowDF = df.withColumn("rn", row_number().over(part))
      val res = rowDF.filter("rn==1").drop("rn")
      res
    }

    // Filter condition for Current, Future and previous quarter(only till first month of current quarter) data
    val cal = Calendar.getInstance()
    val Year = cal.get(Calendar.YEAR)
    val Month1 = cal.get(Calendar.MONTH)
    var Month = Month1 + 1
    val prev_year = Year - 1
    val year1 = Year + 1
    val prev_year_str = prev_year.toString()
    var Month_val = Month.toString()
    var year_val = Year.toString()
    var next_year = year1.toString()
    var fscl_yr_prd = ""

    if ((Month_val == "11") || Month_val == "12") { fscl_yr_prd = next_year + "1" } //year+Q
    else if ((Month_val == "1")) { fscl_yr_prd = year_val + "1" }
    else if ((Month_val == "2") || (Month_val == "3") || (Month_val == "4")) { fscl_yr_prd = year_val + "2" }
    else if ((Month_val == "5") || (Month_val == "6") || (Month_val == "7")) { fscl_yr_prd = year_val + "3" }
    else if ((Month_val == "8") || (Month_val == "9") || (Month_val == "10")) { fscl_yr_prd = year_val + "4" }

    val fscl_yr_prd_con = fscl_yr_prd.toInt

    val hive_tgt_table = consmptnTable

var exchangedf=spark.sql(s"""select CASE WHEN frm_curr_unts_rto_1_nr = to_curr_unts_rto_1_nr THEN  CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE) WHEN frm_curr_unts_rto_1_nr > to_curr_unts_rto_1_nr THEN CAST(((to_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*frm_curr_unts_rto_1_nr) AS DOUBLE) WHEN frm_curr_unts_rto_1_nr < to_curr_unts_rto_1_nr THEN CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE) else null end as exch_rate_global,fscl_yr_nr1,
  fscl_prd_nr1,frm_curr_cd from (select exch.*,row_number() over (partition by frm_curr_cd,year(etry_vld_frm_ts),month(etry_vld_frm_ts) order by 
  day(etry_vld_frm_ts) desc) rn,substring(clndr_rpt.fisc_yr_mth_cd,1,4) AS fscl_yr_nr1,substring(clndr_rpt.fisc_yr_mth_cd,5,2) AS fscl_prd_nr1 from 
  ${dbfin}.exch_rates_dmnsn exch LEFT OUTER JOIN ${dbCommonName}.clndr_rpt clndr_rpt on to_date(exch.etry_vld_frm_ts)=clndr_rpt.cldr_dt where 
  exch_rate_typ_cd = 'M' and to_curr_cd = 'USD') as a where a.rn=1""")

exchangedf.createOrReplaceTempView("exchangedf")

var exchangedflocal=spark.sql(s"""select CASE WHEN frm_curr_unts_rto_1_nr = to_curr_unts_rto_1_nr THEN  
  CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE) WHEN frm_curr_unts_rto_1_nr > to_curr_unts_rto_1_nr 
  THEN CAST(((to_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*frm_curr_unts_rto_1_nr) AS DOUBLE) WHEN frm_curr_unts_rto_1_nr < to_curr_unts_rto_1_nr 
  THEN CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE) else null end as exch_rate_local,to_curr_cd,fscl_yr_nr1,
  fscl_prd_nr1,frm_curr_cd from (select exch.*,row_number() over (partition by frm_curr_cd,year(etry_vld_frm_ts),month(etry_vld_frm_ts) order by 
  day(etry_vld_frm_ts) desc) rn,substring(clndr_rpt.fisc_yr_mth_cd,1,4) AS fscl_yr_nr1,substring(clndr_rpt.fisc_yr_mth_cd,5,2) AS fscl_prd_nr1 from 
  ${dbfin}.exch_rates_dmnsn exch LEFT OUTER JOIN ${dbCommonName}.clndr_rpt clndr_rpt on to_date(exch.etry_vld_frm_ts)=clndr_rpt.cldr_dt
where exch_rate_typ_cd = 'M') as a left outer join ${dbCommonName}.entrs_lgl_ent_ldgr_dmnsn entrs_lgl_ent_ldgr on entrs_lgl_ent_ldgr.curr_cd=a.to_curr_cd 
where a.rn=1""")

exchangedflocal.createOrReplaceTempView("exchangedflocal")

val deferredRevenueRAR = spark.sql(s"""
select crc32(LOWER(CONCAT(COALESCE(trns.rvn_rcncltn_ky,""),
COALESCE(trns.prfm_obgn_id,""),COALESCE(SUBSTR(mppg.src_itm_id,1,10),""),
COALESCE(SUBSTR(mppg.src_itm_id,-6),"")))) as dfrd_rvn_flsh_ky,
crc32(COALESCE(LOWER(rvn_rcgn_pob.fnctl_ar_cd),"")) as fnctl_ar_ky,
crc32(COALESCE(LOWER(trns.entrs_lgl_ent_ldgr_cd),"")) as entrs_lgl_ent_ldgr_ky,
crc32(COALESCE(LOWER(rvn_rcgn_pob.cust_nr),"")) as mdm_cust_ky,
crc32(COALESCE(LOWER(rvn_rcgn_pob.sgmtl_rptg_sgm_cd),"")) as mgmt_grphy_unt_ky,
crc32(COALESCE(LOWER(rvn_rcgn_pob.pft_cntr_cd),"")) as pft_cntr_ky,
crc32(COALESCE(LOWER(rvn_rcgn_pstg_dmnsn.gnrl_ldgr_acct_nr),"")) as gl_acct_ky,
SUBSTR(mppg.src_itm_id,1,10) as sls_dcmt_cd,
SUBSTR(mppg.src_itm_id,-6) as sls_dcmt_itm_nr,
mppg.src_dcmt_itm_typ_cd as sls_dcmt_typ_cd,
SUBSTR(trns.rvn_rcncltn_ky,1,4) as fscl_yr_nr,
CONCAT(SUBSTR(trns.rvn_rcncltn_ky,1,4),(CASE WHEN (substr(trns.rvn_rcncltn_ky,5,3)) IN ('001','002','003')  THEN 'Q1' WHEN (substr(trns.rvn_rcncltn_ky,5,3)) IN ('004','005','006')  THEN 'Q2' WHEN (substr(trns.rvn_rcncltn_ky,5,3)) IN ('007','008','009' ) THEN 'Q3' WHEN (substr(trns.rvn_rcncltn_ky,5,3)) IN ('010','011','012' ) THEN 'Q4' else NULL end)) as fscl_yr_qtr_nr,
SUBSTR(trns.rvn_rcncltn_ky,5,3) as pstg_prd_nr,
rvn_rcgn_pstg_dmnsn.scnd_prll_lcl_curr_amt as scnd_prll_lcl_curr_amt,
trns.rvn_rcgn_cntrct_id as rvn_rcgn_cntrct_id,
trns.prfm_obgn_id as prfm_obgn_id,
mppg.src_itm_id as src_itm_id,
rvn_rcgn_pob.strt_dt as  strt_dt,
rvn_rcgn_pob.end_dt as end_dt,
rvn_rcgn_pob.pft_cntr_cd as pft_cntr_cd,
rvn_rcgn_pob.sgmtl_rptg_sgm_cd as sgmtl_rptg_sgm_cd,
rvn_rcgn_pob.cust_nr as  cust_nr,
rvn_rcgn_pob.fnctl_ar_cd as fnctl_ar_cd,
trns.entrs_lgl_ent_ldgr_cd as entrs_lgl_ent_ldgr_cd,
trns.rvn_dlta_amt as rvn_dlta_amt,
trns.rvn_dlta_qty as rvn_dlta_qty,
trns.curr_ky as curr_ky,
trns.measuring_unt_cd as measuring_unt_cd,
trns.utc_ts as utc_ts,
trns.src_acct_nr as gl_src_acct_nr,
trns.tgt_acct_nr as gl_tgt_acct_nr,
null as nn_fcs_cntry_ind,
"FO70000038" as fncl_ownr_cd,
CASE WHEN CONCAT(SUBSTR(trns.rvn_rcncltn_ky,1,4),
CASE WHEN (substr(trns.rvn_rcncltn_ky,5,3)) IN ('001','002','003')  THEN '1' WHEN (substr(trns.rvn_rcncltn_ky,5,3)) IN ('004','005','006')  THEN '2' WHEN (substr(trns.rvn_rcncltn_ky,5,3)) IN ('007','008','009' ) THEN '3' WHEN (substr(trns.rvn_rcncltn_ky,5,3)) IN ('010','011','012' ) THEN '4' else NULL end) <= ${fscl_yr_prd_con} THEN 'O&C Secured Billed' ELSE 'O&C Secured Unbilled' END as fncl_frmwk_lvl_6,
CASE
WHEN (month(from_unixtime(unix_timestamp()))=11 or month(from_unixtime(unix_timestamp()))=12) THEN year(from_unixtime(unix_timestamp()))+1 
ELSE year(from_unixtime(unix_timestamp()))
END as calc_fscl_year,
rvn_rcgn_pob.prfm_obgn_typ_cd as prfm_obgn_typ_cd,
rvn_rcgn_pob.trsn_prc_amt as trsn_prc_amt,
rvn_rcgn_pob.sspnd_pstg_ind as sspnd_pstg_ind,
rvn_rcgn_rcn_ky_dmnsn.rvn_rcncltn_ky_stts_cd as stts_rvn_rcncltn_ky_cd,
rvn_rcgn_pob.alct_amt as alct_amt,
rvn_rcgn_pob.alct_amt-rvn_rcgn_pob.trsn_prc_amt as alct_efct_cd,
rvn_rcgn_pob.fnl_inv_ind as fnl_inv_ind,
rvn_rcgn_pob.prfm_obgn_stts_cd as prfm_obgn_stts_cd,
cntrct.cntrct_crtn_ts as cntrct_crtn_ts,
rvn_rcgn_pstg_dmnsn.lcl_curr_amt as lcl_curr_amt,
rvn_rcgn_pstg_dmnsn.trsn_curr_amt as trsn_curr_amt,
NULL as intgtn_fbrc_msg_id,
trns.src_sys_upd_ts,
trns.src_sys_ky,
trns.lgcl_dlt_ind,
trns.ins_gmt_ts,
trns.upd_gmt_ts,
trns.src_sys_extrc_gmt_ts,
trns.src_sys_btch_nr,
trns.fl_nm,
trns.ld_jb_nr,
month(trns.utc_ts) as utc_month,
CURRENT_TIMESTAMP as ins_ts,
substring(mppg.src_itm_id,1,10) as sls_ord_id,
substring(mppg.src_itm_id,(length(mppg.src_itm_id)-5),6) as sls_ord_ln_itm_id,
rvn_rcgn_pob.flflm_typ_cd as flflm_typ_cd
from (select dfrd_itm.*, ROW_NUMBER() OVER (Partition By rvn_rcncltn_ky,prfm_obgn_id,cndn_typ_cd,dfrl_cgy_cd order by ins_gmt_ts DESC ) 
as seq_id from ${dbfin}.rvn_rcgn_dfrd_itm_dmnsn dfrd_itm) trns
left outer join ${dbfin}.rvn_rcgn_rcn_ky_dmnsn rvn_rcgn_rcn_ky_dmnsn on trns.rvn_rcncltn_ky=rvn_rcgn_rcn_ky_dmnsn.rvn_rcncltn_ky and trns.rvn_rcgn_cntrct_id=rvn_rcgn_rcn_ky_dmnsn.rvn_rcgn_cntrct_id and trns.entrs_lgl_ent_ldgr_cd=rvn_rcgn_rcn_ky_dmnsn.entrs_lgl_ent_ldgr_cd
left outer join ${dbfin}.rvn_rcgn_pstg_dmnsn rvn_rcgn_pstg_dmnsn on trns.prfm_obgn_id=rvn_rcgn_pstg_dmnsn.prfm_obgn_id and trns.rvn_rcgn_cntrct_id=rvn_rcgn_pstg_dmnsn.rvn_rcgn_cntrct_id and trns.rvn_rcncltn_ky=rvn_rcgn_pstg_dmnsn.rvn_rcncltn_ky and 
trns.cndn_typ_cd=rvn_rcgn_pstg_dmnsn.cndn_typ_cd and rvn_rcgn_pstg_dmnsn.pstg_dcmt_cgy_cd = 'RV'  
left outer join ${dbfin}.rvn_rcgn_prfm_obgn_dmnsn rvn_rcgn_pob on trns.prfm_obgn_id = rvn_rcgn_pob.prfm_obgn_id 
left outer join ${dbfin}.rvn_rcgn_mppg_dmnsn mppg on rvn_rcgn_pob.prfm_obgn_id = mppg.prfm_obgn_id
left outer join ${dbfin}.rvn_rcgn_cntrct_dmnsn cntrct on mppg.rvn_rcgn_cntrct_id = cntrct.rvn_rcgn_cntrct_id where trns.rvn_dlta_amt is NOT NULL and trns.rvn_dlta_amt <> 0 AND trns.ststcs_us_cndn_ind is null
AND upper(trns.prcg_or_cstg_cndn_ind) = 'P' and trns.seq_id = 1 and case when upper(rvn_rcgn_pob.sspnd_pstg_ind) = 'X' AND (upper(rvn_rcgn_rcn_ky_dmnsn.rvn_rcncltn_ky_stts_cd))='O' then 0  
else 1 end =1""").distinct

 deferredRevenueRAR.createOrReplaceTempView("deferredRevenueDF1")
 

    val deferredRevenueDF = spark.sql(s"""
select rar.*,
case when rar.stts_rvn_rcncltn_ky_cd='C' then rar.scnd_prll_lcl_curr_amt*(-1)
when rar.curr_ky='USD' then cast((rar.rvn_dlta_amt / 1) as double)
when rar.curr_ky is null then null
when rar.stts_rvn_rcncltn_ky_cd<>'C' and exch.exch_rate_global is not null then rar.rvn_dlta_amt*exch.exch_rate_global
else exchmax.exch_rate_global*rar.rvn_dlta_amt end as usd_rvn_dlta_amt,
case when rar.stts_rvn_rcncltn_ky_cd='C' then rar.lcl_curr_amt*(-1)
when rar.curr_ky is null then null
when rar.stts_rvn_rcncltn_ky_cd<>'C' and exchlocal.exch_rate_local is not null then rar.rvn_dlta_amt*exchlocal.exch_rate_local
else exchmaxlocal.exch_rate_local*rar.rvn_dlta_amt end as rvn_amt_lcr_cd,
exchmax.exch_rate_global as exch_rate_globalmax,
exch.exch_rate_global as exch_rate_global,
exchmaxlocal.exch_rate_local as exch_rate_localmax,
exchlocal.exch_rate_local as exch_rate_local,
crc32(LOWER(CONCAT(COALESCE(srv_cntrct_mstr_fact.sls_ord_dtl_sls_mtrc_cd,""),COALESCE(srv_cntrct_mstr_fact.blng_pln_nxt_blng_dt_org_rl_cd,"")))) as fncl_frmwk_ky,
crc32(grp_dmnsn.grp_acct_nr) as src_grp_acct_nr_ky,
crc32(COALESCE(LOWER(sls_ord.e1edp19_idoc_mtrl_i_1_nm_2),"")) as pdm_mtrl_mstr_grp_ky,
srv_cntrct_mstr_fact.sls_ord_dtl_sls_mtrc_cd as sls_mtrc_cd,
srv_cntrct_mstr_fact.blng_pln_nxt_blng_dt_org_rl_cd,
blng_typ_invc_dmnsn.blng_cgy_cd as blng_cgy_cd,
bmt_fncl_frmwk_dmnsn.fncl_frmwk_lvl_0_dn as fncl_frmwk_lvl_0,
bmt_fncl_frmwk_dmnsn.fncl_frmwk_lvl_1_dn as fncl_frmwk_lvl_1,
bmt_fncl_frmwk_dmnsn.fncl_frmwk_lvl_2_dn as fncl_frmwk_lvl_2,
bmt_fncl_frmwk_dmnsn.fncl_frmwk_lvl_3_dn as fncl_frmwk_lvl_3,
bmt_fncl_frmwk_dmnsn.fncl_frmwk_lvl_4_dn as fncl_frmwk_lvl_4,
bmt_fncl_frmwk_dmnsn.fncl_frmwk_lvl_5_dn as fncl_frmwk_lvl_5,
bmt_fncl_frmwk_dmnsn.fncl_frmwk_lvl_7_dn as fncl_frmwk_lvl_7,
segment_std_hrchy.sg_level_3 as sgm_lvl_2,
segment_std_hrchy.sg_level_4 as sgm_lvl_3,
segment_std_hrchy.sg_level_5 as sgm_lvl_4,
segment_std_hrchy.sg_level_6 as sgm_lvl_5,
BMT_grp_acct.grp_accnt as grp_acct,
BMT_trsn_curr.crr_cd as curr_cd,
grp_dmnsn.grp_acct_nr as src_grp_acct_nr,
sls_ord.rsn_rjctn_quotations_and_sls_orders_cd as rsn_rjctn_quotations_and_sls_orders_cd,
sls_ord.rjctn_stts_cd as rjctn_stts_cd,
sls_ord.e1edka1_ptnr_nr_ze as shp_to_cust_id,
sls_ord.e1edka1_ptnr_nr_re as bll_to_cust_id,
sls_ord.e1edka1_ptnr_nr_ag as sld_to_cust_id,
sls_ord.e1edka1_ptnr_nr_zc as end_cust_id,
sls_ord.e1edp02_idoc_dcmt_nr_1 as cust_po_nr,
sls_ord.zord_item01_mtrl_acct_asngmt_cd_grp as mtrl_acct_asngmt_grp_cd,
CASE WHEN rar.rvn_dlta_amt IS NULL OR rar.rvn_dlta_amt=0 THEN 0
WHEN rar.pstg_prd_nr IN ('013','014','015','016') THEN 0
WHEN three_twelve_month.three_mnth_rate*rar.rvn_dlta_amt IS NOT NULL OR three_twelve_month.three_mnth_rate*rar.rvn_dlta_amt <>0 THEN three_twelve_month.three_mnth_rate*rar.rvn_dlta_amt ELSE 0 END as three_mnth_avg_amt_cal,
CASE WHEN rar.rvn_dlta_amt IS NULL OR rar.rvn_dlta_amt=0 THEN 0
WHEN rar.pstg_prd_nr IN ('013','014','015','016') THEN 0
WHEN three_twelve_month.twelve_mnth_rate*rar.rvn_dlta_amt IS NOT NULL OR three_twelve_month.three_mnth_rate*rar.rvn_dlta_amt<>0 THEN three_twelve_month.twelve_mnth_rate*rar.rvn_dlta_amt ELSE 0 END as twelve_mnth_avg_amt_cal,
sls_ord.e1edp19_idoc_mtrl_i_1_nm_2 as e1edp01_idoc_mtrl_id_nm
from deferredRevenueDF1 rar
left outer join (select distinct entrs_lgl_ent_ldgr_cd,pft_cntr_cd,mgmt_grphy_unt_cd,tc_cd,fscl_yr_nr,
CASE WHEN length(pstg_prd_nr)=1 then concat('00',pstg_prd_nr) else concat('0',pstg_prd_nr) end as pstg_prd_nr,three_mnth_rate,twelve_mnth_rate 
from ${dbfin}.three_twelve_month_dmnsn_srvc_curr ) as three_twelve_month on 
rar.curr_ky=three_twelve_month.tc_cd and rar.entrs_lgl_ent_ldgr_cd=three_twelve_month.entrs_lgl_ent_ldgr_cd and 
rar.pft_cntr_cd=three_twelve_month.pft_cntr_cd and 
rar.sgmtl_rptg_sgm_cd =three_twelve_month.mgmt_grphy_unt_cd and 
rar.fscl_yr_nr=three_twelve_month.fscl_yr_nr
and rar.pstg_prd_nr=three_twelve_month.pstg_prd_nr 
left outer join ${dbfin}.secrd_rpt_sls_spmt_dmnsn sls_ord on (sls_ord.e1edk01_idoc_dcmt_nr=substring(rar.src_itm_id,1,10) and sls_ord.e1edp01_itm_nr=substring(rar.src_itm_id,(length(rar.src_itm_id)-5),6))
left outer join (select distinct sls_ord_sls_ord_id,sls_ord_dtl_sls_ord_itm_nr,blng_pln_nxt_blng_dt_org_rl_cd,sls_ord_dtl_sls_mtrc_cd from ${dbCommonName}.srv_cntrct_mstr_fact) srv_cntrct_mstr_fact 
on (substring(rar.src_itm_id,1,10)=srv_cntrct_mstr_fact.sls_ord_sls_ord_id 
and substring(rar.src_itm_id,(length(rar.src_itm_id)-5),6)=srv_cntrct_mstr_fact.sls_ord_dtl_sls_ord_itm_nr)
left outer join ${dbCommonName}.sls_blng_hddr_invc_fact sls_blng_hddr_invc_fact on sls_blng_hddr_invc_fact.idoc_nr=sls_ord.idoc_nr and sls_blng_hddr_invc_fact.e1edk01_idoc_dcmt_nr=sls_ord.sls_blng_itm_e1edk01_idoc_dcmt_nr
left outer join ${dbCommonName}.blng_typ_dmnsn blng_typ_invc_dmnsn on sls_blng_hddr_invc_fact.e1edk14_idoc_org_nm_15 = blng_typ_invc_dmnsn.blng_typ_cd 
left outer join ${dbCommonName}.segment_std_hrchy segment_std_hrchy on segment_std_hrchy.sg_level_8 = rar.sgmtl_rptg_sgm_cd 
left outer join ${dbCommonName}.bmt_fncl_frmwk_dmnsn bmt_fncl_frmwk_dmnsn on
crc32(LOWER(CONCAT(COALESCE(srv_cntrct_mstr_fact.sls_ord_dtl_sls_mtrc_cd,""),COALESCE(srv_cntrct_mstr_fact.blng_pln_nxt_blng_dt_org_rl_cd,"")))) = bmt_fncl_frmwk_dmnsn.fncl_frmwk_ky
left outer join (select distinct acct.gnrl_ldgr_acct_nr,acct.grp_acct_nr from ${dbCommonName}.gnrl_ldgr_acct_dmnsn acct ) as grp on rar.gl_src_acct_nr=grp.gnrl_ldgr_acct_nr
left outer join ${dbCommonName}.bmt_grp_accnt_exclsn_dmnsn BMT_grp_acct on grp.grp_acct_nr=CONCAT('000000',BMT_grp_acct.grp_accnt) 
left outer join ${dbCommonName}.bmt_trsn_curr_xclsn_dmnsn BMT_trsn_curr on  rar.curr_ky=BMT_trsn_curr.crr_cd
left outer join (select distinct acct.gnrl_ldgr_acct_nr,acct.grp_acct_nr from ${dbCommonName}.gnrl_ldgr_acct_dmnsn acct 
where chrt_of_accts_cd = 'WW00') as grp_dmnsn on rar.gl_src_acct_nr=grp_dmnsn.gnrl_ldgr_acct_nr
left outer join exchangedf exch on exch.fscl_yr_nr1=rar.fscl_yr_nr and exch.fscl_prd_nr1=rar.pstg_prd_nr and rar.curr_ky=exch.frm_curr_cd 
left outer join (select a.exch_rate_global,a.frm_curr_cd from (select exch_max.*,row_number() over (partition by frm_curr_cd order by fscl_yr_nr1 desc,fscl_prd_nr1 desc) rn from exchangedf exch_max) as a where a.rn=1) as exchmax on rar.curr_ky=exchmax.frm_curr_cd
left outer join exchangedflocal as exchlocal on exchlocal.fscl_yr_nr1=rar.fscl_yr_nr and exchlocal.fscl_prd_nr1=rar.pstg_prd_nr and rar.curr_ky=exchlocal.frm_curr_cd
left outer join (select a.exch_rate_local,a.frm_curr_cd from (select exch_max_local.*,row_number() over (partition by frm_curr_cd order by fscl_yr_nr1 desc,fscl_prd_nr1 desc) rn from exchangedflocal exch_max_local) as a where a.rn=1) as exchmaxlocal on rar.curr_ky=exchmaxlocal.frm_curr_cd""").distinct


    //Budget

    def budgetindirectexchtr(df: DataFrame, fromCurr: String, bgdtCol: String): DataFrame = {
      val exhchangedf = spark.sql("select a.* from (select exch.*,row_number() over (partition by frm_curr_cd order by year(etry_vld_frm_ts) desc,month(etry_vld_frm_ts) desc) rn from ea_fin.exch_rates_dmnsn exch where exch_rate_typ_cd = 'C' and to_curr_cd = 'USD') as a where a.rn=1")
      val joindf = df.alias("src").join(exhchangedf.alias("exch"), df(fromCurr) === exhchangedf("frm_curr_cd"), "leftouter").select("src.*", "exch.etry_vld_frm_ts", "exch.frm_curr_unts_rto_1_nr", "exch.to_curr_unts_rto_1_nr", "exch.indrt_qted_exch_rate_nr", "exch.frm_curr_cd", "exch.to_curr_cd")
      val df4 = joindf.select(col("*"), expr("CASE WHEN frm_curr_unts_rto_1_nr = to_curr_unts_rto_1_nr THEN  CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE) " + "WHEN frm_curr_unts_rto_1_nr > to_curr_unts_rto_1_nr THEN CAST(((to_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*frm_curr_unts_rto_1_nr) AS DOUBLE) " + "WHEN frm_curr_unts_rto_1_nr < to_curr_unts_rto_1_nr THEN CAST(((frm_curr_unts_rto_1_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_1_nr) AS DOUBLE)" + " else null end").alias(bgdtCol))
      val df4_final = df4.drop("etry_vld_frm_ts", "frm_curr_unts_rto_1_nr", "to_curr_unts_rto_1_nr", "indrt_qted_exch_rate_nr", "frm_curr_cd", "to_curr_cd")
      df4_final
    }

    val deferredRevenueDF_bdgt = budgetindirectexchtr(deferredRevenueDF, "curr_ky", "exch_rate_budget")
    
    val deferredRevenueDF_bdgtcal = deferredRevenueDF_bdgt.select(col("*"), expr("CASE WHEN exch_rate_budget IS NULL OR exch_rate_budget=0 OR pstg_prd_nr ='000' OR pstg_prd_nr IS NULL THEN usd_rvn_dlta_amt" + " WHEN curr_ky = 'USD' OR curr_ky = 'NA' THEN usd_rvn_dlta_amt" + " WHEN rvn_dlta_amt =0 OR rvn_dlta_amt IS NULL THEN usd_rvn_dlta_amt" + " WHEN grp_acct is not NULL OR curr_cd is not NULL THEN usd_rvn_dlta_amt" + " WHEN grp_acct is NULL and curr_cd is NULL and fscl_yr_nr=calc_fscl_year THEN usd_rvn_dlta_amt" + " WHEN grp_acct is NULL and curr_cd is NULL and fscl_yr_nr >=(calc_fscl_year-3) and fscl_yr_nr != calc_fscl_year THEN cast((rvn_dlta_amt*exch_rate_budget) AS DOUBLE)" + " else usd_rvn_dlta_amt end").alias("rvn_amt_usd_rsttd_bdgt_rate_cd_cal"))

    val deferredRevenueDF_final = deferredRevenueDF_bdgtcal
    
    deferredRevenueDF_final.repartition(25).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + ".deferred_revenue_temp")

    val deferredRevenueDF_finaldf=spark.sql(s"""select * from ${dbNameConsmtn}.deferred_revenue_temp""")

    val pnNnFcsDmnsnDF = spark.sql(s"""select * from ${dbCommonName}.bmt_pn_nn_fcus_flg_actl_dmnsn""")
    
    val dfrrdNnFcsJoinStgDF = deferredRevenueDF_finaldf.alias("serpJoindCol1").join(
      broadcast(pnNnFcsDmnsnDF).alias("pnNnFcsDmnsnCol"),
      (deferredRevenueDF_finaldf("pft_cntr_cd") === pnNnFcsDmnsnDF("prft_ctr_cd") || pnNnFcsDmnsnDF("prft_ctr_cd").isNull || pnNnFcsDmnsnDF("prft_ctr_cd") === "all")
        && (deferredRevenueDF_finaldf("sgm_lvl_2") === pnNnFcsDmnsnDF("sgmt_lvl_2_cd") || pnNnFcsDmnsnDF("sgmt_lvl_2_cd").isNull || pnNnFcsDmnsnDF("sgmt_lvl_2_cd") === "all")
        && (deferredRevenueDF_finaldf("sgm_lvl_3") === pnNnFcsDmnsnDF("sgmt_lvl_3_cd") || pnNnFcsDmnsnDF("sgmt_lvl_3_cd").isNull || pnNnFcsDmnsnDF("sgmt_lvl_3_cd") === "all")
        && (deferredRevenueDF_finaldf("sgm_lvl_4") === pnNnFcsDmnsnDF("sgmt_lvl_4_cd") || pnNnFcsDmnsnDF("sgmt_lvl_4_cd").isNull || pnNnFcsDmnsnDF("sgmt_lvl_4_cd") === "all")
        && (deferredRevenueDF_finaldf("sgm_lvl_5") === pnNnFcsDmnsnDF("sgmt_lvl_5_cd") || pnNnFcsDmnsnDF("sgmt_lvl_5_cd").isNull || pnNnFcsDmnsnDF("sgmt_lvl_5_cd") === "all")
        && (deferredRevenueDF_finaldf("fncl_frmwk_lvl_5") === pnNnFcsDmnsnDF("ff_l15_cd") || pnNnFcsDmnsnDF("ff_l15_cd").isNull || pnNnFcsDmnsnDF("ff_l15_cd") === "all")
        && (deferredRevenueDF_finaldf("sgm_lvl_2") != pnNnFcsDmnsnDF("sgmt_lvl_2_cd_exclude"))
        && (deferredRevenueDF_finaldf("sgm_lvl_3") != pnNnFcsDmnsnDF("sgmt_lvl_3_cd_exclude"))
        && (deferredRevenueDF_finaldf("sgm_lvl_4") != pnNnFcsDmnsnDF("sgmt_lvl_4_cd_exclude"))
        && (deferredRevenueDF_finaldf("sgm_lvl_5") != pnNnFcsDmnsnDF("sgmt_lvl_5_cd_exclude")), "leftouter").select("serpJoindCol1.*", "pnNnFcsDmnsnCol.nn_fcs_cntry", "pnNnFcsDmnsnCol.inrn_id").distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
	

	val dfrrdNnFcsJoinStgDeDupDF = getLatestRecs(dfrrdNnFcsJoinStgDF, List("dfrd_rvn_flsh_ky","pft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "fncl_frmwk_lvl_5"), List("inrn_id"))
	
	val dfrrdNnFcsJoinFinalDF = deferredRevenueDF_finaldf.alias("serpJoindCol1").join(
      broadcast(dfrrdNnFcsJoinStgDeDupDF).alias("pnNnFcsDmnsnCol"),deferredRevenueDF_finaldf("dfrd_rvn_flsh_ky") === dfrrdNnFcsJoinStgDeDupDF("dfrd_rvn_flsh_ky") &&
      (deferredRevenueDF_finaldf("pft_cntr_cd") === dfrrdNnFcsJoinStgDeDupDF("pft_cntr_cd") || dfrrdNnFcsJoinStgDeDupDF("pft_cntr_cd").isNull && deferredRevenueDF_finaldf("pft_cntr_cd").isNull)
        && (deferredRevenueDF_finaldf("sgm_lvl_2") === dfrrdNnFcsJoinStgDeDupDF("sgm_lvl_2") || dfrrdNnFcsJoinStgDeDupDF("sgm_lvl_2").isNull && deferredRevenueDF_finaldf("sgm_lvl_2").isNull)
        && (deferredRevenueDF_finaldf("sgm_lvl_3") === dfrrdNnFcsJoinStgDeDupDF("sgm_lvl_3") || dfrrdNnFcsJoinStgDeDupDF("sgm_lvl_3").isNull && deferredRevenueDF_finaldf("sgm_lvl_3").isNull)
        && (deferredRevenueDF_finaldf("sgm_lvl_4") === dfrrdNnFcsJoinStgDeDupDF("sgm_lvl_4") || dfrrdNnFcsJoinStgDeDupDF("sgm_lvl_4").isNull && deferredRevenueDF_finaldf("sgm_lvl_4").isNull)
        && (deferredRevenueDF_finaldf("sgm_lvl_5") === dfrrdNnFcsJoinStgDeDupDF("sgm_lvl_5") || dfrrdNnFcsJoinStgDeDupDF("sgm_lvl_5").isNull && deferredRevenueDF_finaldf("sgm_lvl_5").isNull)
        && (deferredRevenueDF_finaldf("fncl_frmwk_lvl_5") === dfrrdNnFcsJoinStgDeDupDF("fncl_frmwk_lvl_5") || dfrrdNnFcsJoinStgDeDupDF("fncl_frmwk_lvl_5").isNull && deferredRevenueDF_finaldf("fncl_frmwk_lvl_5").isNull), "leftouter").select("serpJoindCol1.*", "pnNnFcsDmnsnCol.nn_fcs_cntry").distinct()
    
        dfrrdNnFcsJoinFinalDF.createOrReplaceTempView("serpTempTable5")

   val finalDF = spark.sql(s"""    
select 
dfrd_rvn_flsh_ky,
fnctl_ar_ky,
entrs_lgl_ent_ldgr_ky,
mdm_cust_ky,
mgmt_grphy_unt_ky,
pdm_mtrl_mstr_grp_ky,
pft_cntr_ky,
gl_acct_ky,
fncl_frmwk_ky,
src_grp_acct_nr_ky,
sls_dcmt_cd,
sls_dcmt_itm_nr,
sls_dcmt_typ_cd,
fscl_yr_nr,
fscl_yr_qtr_nr,
pstg_prd_nr,
rvn_rcgn_cntrct_id,
prfm_obgn_id,
strt_dt,
end_dt,
pft_cntr_cd,
sgmtl_rptg_sgm_cd,
cust_nr,
e1edp01_idoc_mtrl_id_nm,
fnctl_ar_cd,
entrs_lgl_ent_ldgr_cd,
CASE WHEN exch_rate_budget IS NULL OR exch_rate_budget=0 OR pstg_prd_nr ='000' OR pstg_prd_nr IS NULL THEN usd_rvn_dlta_amt
WHEN curr_ky = 'USD' OR curr_ky = 'NA' THEN usd_rvn_dlta_amt
WHEN rvn_dlta_amt =0 OR rvn_dlta_amt IS NULL THEN usd_rvn_dlta_amt
WHEN grp_acct is not NULL OR curr_cd is not NULL THEN usd_rvn_dlta_amt 
WHEN grp_acct is NULL and curr_cd is NULL and fscl_yr_nr=calc_fscl_year THEN rvn_dlta_amt*exch_rate_budget
ELSE 0 END as bdgt_curr_rvn_dlta_amt,
usd_rvn_dlta_amt,
case when stts_rvn_rcncltn_ky_cd='C' then trsn_curr_amt*(-1) else rvn_dlta_amt end as dcmt_curr_rvn_dlta_amt,
rvn_dlta_qty,
curr_ky,
measuring_unt_cd,
utc_ts,
sls_mtrc_cd,
blng_cgy_cd,
gl_src_acct_nr,
gl_tgt_acct_nr,
case when nn_fcs_cntry is null then 'N' else nn_fcs_cntry end as nn_fcs_cntry_ind,
fncl_ownr_cd,
fncl_frmwk_lvl_0,
fncl_frmwk_lvl_1,
fncl_frmwk_lvl_2,
fncl_frmwk_lvl_3,
fncl_frmwk_lvl_4,
fncl_frmwk_lvl_5,
fncl_frmwk_lvl_6,
fncl_frmwk_lvl_7,
blng_pln_nxt_blng_dt_org_rl_cd,
CASE WHEN three_mnth_avg_amt_cal=0 THEN usd_rvn_dlta_amt ELSE three_mnth_avg_amt_cal end as three_mnth_avg_amt,
CASE WHEN twelve_mnth_avg_amt_cal=0 then usd_rvn_dlta_amt ELSE twelve_mnth_avg_amt_cal end as twelve_mnth_avg_amt,
rvn_amt_usd_rsttd_bdgt_rate_cd_cal as rvn_amt_usd_rsttd_bdgt_rate_amt,
null as curr_cnvrsn_1_cd,
null as curr_cnvrsn_2_cd,
null as curr_cnvrsn_3_cd,
null as curr_cnvrsn_4_cd,
flflm_typ_cd as flflm_typ_cd,
prfm_obgn_typ_cd as prfm_obgn_typ_cd,
trsn_prc_amt as trsn_prc_amt,
sspnd_pstg_ind as sspnd_pstg_ind,
shp_to_cust_id,
bll_to_cust_id,
sld_to_cust_id,
end_cust_id,
cust_po_nr,
stts_rvn_rcncltn_ky_cd,
mtrl_acct_asngmt_grp_cd,
rvn_amt_lcr_cd as rvn_amt_lcr_amt,
alct_amt,
alct_efct_cd,
rsn_rjctn_quotations_and_sls_orders_cd,
rjctn_stts_cd,
fnl_inv_ind,
prfm_obgn_stts_cd,
src_grp_acct_nr,
intgtn_fbrc_msg_id,
src_sys_upd_ts,
src_sys_ky,
lgcl_dlt_ind,
ins_gmt_ts,
upd_gmt_ts,
src_sys_extrc_gmt_ts,
src_sys_btch_nr,
fl_nm,
ld_jb_nr,
ld_jb_nr as ld_jb_nr_audit,
ins_ts
from serpTempTable5""").distinct

    val final_Count = finalDF.count()
    logger.info("table" + final_Count + " dfrd_rvn_flsh_fact count")

    finalDF.repartition(25).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)

    val tgtCount = spark.sql(s"select * from ${dbNameConsmtn}.${consmptnTable}").count.toInt

    tgtCount match {
      case 0 =>
        logger.info("******** load into " + dbNameConsmtn + ".dfrd_rvn_flsh_fact failed")
        auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
        auditObj.setAudDataLayerName("ref_cnsmptn")
        auditObj.setAudApplicationName("job_secured_Deal_fact")
        auditObj.setAudObjectName(propertiesObject.getObjName())
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
        auditObj.setFlNm("")
        auditObj.setSysBtchNr(ld_jb_nr)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        jobStatusFlag = false
      case _ =>
        logger.info("******** data load into " + dbNameConsmtn + ".dfrd_rvn_flsh_fact, count:" + tgtCount)
        auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
        auditObj.setAudDataLayerName("ref_cnsmptn")
        auditObj.setAudApplicationName("job_secured_Deal_fact")
        auditObj.setAudObjectName(propertiesObject.getObjName())
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
        auditObj.setFlNm("")
        auditObj.setSysBtchNr(ld_jb_nr)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_Deal_fact")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    logger.info("//*********************** Log End for DeferredRevenue.scala ************************//")
    sqlCon.close()
    spark.close()
  }
}
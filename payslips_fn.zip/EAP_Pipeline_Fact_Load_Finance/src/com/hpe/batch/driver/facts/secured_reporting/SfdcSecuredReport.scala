package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source

object SfdcSecuredReport extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true
  var fileBasePath = propertiesObject.getFileBasePath()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName().trim()

  logger.info("//*********************** Log Start for SfdcSecuredReport.scala ************************//")
  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  try {
    
    
    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn, fileBasePath, dbName))

    //***************************Audit Properties********************************//
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_ea_secrd_sfdc_fact_load")
    auditObj.setAudObjectName(objName)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)

    if (tgtTblConsmtn.split("\\.", -1).size != 2) {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val dbCommon = dbName.split(",")(0)
    val dbCommonUAT = dbName.split(",")(1)
    val tgtColumns = spark.sql("select * from " + tgtTblConsmtn + " limit 0").columns
    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt
    
    
    //spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    val sfdcSelectDF = spark.sql(s"""
      SELECT 
crc64(lower(concat(coalesce(cse_unbkd_vw_flat_dmnsn.unbooked_vw_flat_dmnsn_ky,""),coalesce(cse_unbkd_vw_flat_dmnsn.hpe_ord_nr,"")))) as secrd_rpt_fact_ky,
crc32(LOWER(COALESCE(cse_unbkd_vw_flat_dmnsn.q_116_nr,""))) as quote_ky,
crc32(LOWER(COALESCE(cse_unbkd_vw_flat_dmnsn.hpe_ord_nr,""))) as ord_hddr_ky,
cse_unbkd_vw_flat_dmnsn.hpe_ord_nr as sls_ord_id,
'SFDC_UNBOOKED_ORDERS' as src_sys_cd,
cse_unbkd_vw_flat_dmnsn.q_116_nr as quote_id,
CURRENT_TIMESTAMP as ins_ts,
cse_unbkd_vw_flat_dmnsn.cs_nr as cs_nr,
cse_unbkd_vw_flat_dmnsn.acct_nm as acct_nm,
cse_unbkd_vw_flat_dmnsn.rec_typ_i_118_nm as rec_typ_i_118_nm,
cse_unbkd_vw_flat_dmnsn.stt_130_nm as stt_130_nm,
cse_unbkd_vw_flat_dmnsn.cse_rs_2_nm as cse_rs_2_nm,
cse_unbkd_vw_flat_dmnsn.sb_7_nm as sb_7_nm,
cse_unbkd_vw_flat_dmnsn.cls_15_cd as cls_15_cd,
cse_unbkd_vw_flat_dmnsn.cls_2_dt as cls_2_dt,
cse_unbkd_vw_flat_dmnsn.cse_curr_cd as cse_curr_cd,
cse_unbkd_vw_flat_dmnsn.own_i_33_nm as own_i_33_nm,
cse_unbkd_vw_flat_dmnsn.crt_37_dt as crt_37_dt,
cse_unbkd_vw_flat_dmnsn.last_mfy_39_dt as last_mfy_39_dt,
cse_unbkd_vw_flat_dmnsn.ctry_submitter_nm as ctry_submitter_nm,
cse_unbkd_vw_flat_dmnsn.q_116_nr as q_116_nr,
cse_unbkd_vw_flat_dmnsn.cse_comments_nm as cse_comments_nm,
cse_unbkd_vw_flat_dmnsn.rg_29_nm as rg_29_nm,
cse_unbkd_vw_flat_dmnsn.wrld_rg_nm as wrld_rg_nm,
cse_unbkd_vw_flat_dmnsn.wrld_rgn_rgn_nm as wrld_rgn_rgn_nm,
cse_unbkd_vw_flat_dmnsn.wrld_rgn_sb_rgn_nm as wrld_rgn_sb_rgn_nm,
cse_unbkd_vw_flat_dmnsn.wrld_rgn_sb_rgn_2_nm as wrld_rgn_sb_rgn_2_nm,
cse_unbkd_vw_flat_dmnsn.wrld_rgn_sb_rgn_3_nm as wrld_rgn_sb_rgn_3_nm,
cse_unbkd_vw_flat_dmnsn.ctr_56_nm as ctr_56_nm,
cse_unbkd_vw_flat_dmnsn.b_nm as b_nm,
cse_unbkd_vw_flat_dmnsn.cse_age_bsn_dys_dt as cse_age_bsn_dys_dt,
cse_unbkd_vw_flat_dmnsn.asng_to_team_nm as asng_to_team_nm,
cse_unbkd_vw_flat_dmnsn.bsn_ty_2_nm as bsn_ty_2_nm,
cse_unbkd_vw_flat_dmnsn.cse_rqstr_eml_nm as cse_rqstr_eml_nm,
cse_unbkd_vw_flat_dmnsn.cls_cse_rsn_nm as cls_cse_rsn_nm,
cse_unbkd_vw_flat_dmnsn.opendate_dt as opendate_dt,
cse_unbkd_vw_flat_dmnsn.re_2_nm as re_2_nm,
cse_unbkd_vw_flat_dmnsn.rsln_stts_nm as rsln_stts_nm,
cse_unbkd_vw_flat_dmnsn.asscd_cse_nm as asscd_cse_nm,
cse_unbkd_vw_flat_dmnsn.rte_to_mk_2_nm as rte_to_mk_2_nm,
cse_unbkd_vw_flat_dmnsn.sld_to_prt_nm as sld_to_prt_nm,
cse_unbkd_vw_flat_dmnsn.prnt_rec_typ_nm as prnt_rec_typ_nm,
cse_unbkd_vw_flat_dmnsn.rqstr_p_nm as rqstr_p_nm,
cse_unbkd_vw_flat_dmnsn.sls_ord_amt_cd as sls_ord_amt_cd,
cse_unbkd_vw_flat_dmnsn.submitter_em_2_nm as submitter_em_2_nm,
cse_unbkd_vw_flat_dmnsn.db_eml_ref_id_nm as db_eml_ref_id_nm,
cse_unbkd_vw_flat_dmnsn.cse_own_eml_nm as cse_own_eml_nm,
cse_unbkd_vw_flat_dmnsn.hpe_ord_nr as hpe_ord_nr,
cse_unbkd_vw_flat_dmnsn.cse_age_cd as cse_age_cd,
cse_unbkd_vw_flat_dmnsn.cse_scnr_nm as cse_scnr_nm,
cse_unbkd_vw_flat_dmnsn.cust_ph_nm as cust_ph_nm,
cse_unbkd_vw_flat_dmnsn.po_amt_cd as po_amt_cd,
cse_unbkd_vw_flat_dmnsn.cb_2_nm as cb_2_nm,
cse_unbkd_vw_flat_dmnsn.clm_rfn_nm as clm_rfn_nm,
cse_unbkd_vw_flat_dmnsn.inrn_scnr_nm as inrn_scnr_nm,
cse_unbkd_vw_flat_dmnsn.po_nr as po_nr,
cse_unbkd_vw_flat_dmnsn.prch_agrmn_2_nm as prch_agrmn_2_nm,
cse_unbkd_vw_flat_dmnsn.cse_curr_nm as cse_curr_nm,
cse_unbkd_vw_flat_dmnsn.rec_typ_nm as rec_typ_nm,
cse_unbkd_vw_flat_dmnsn.ctry_cd as geo_bmt_ctry_cd,
cse_unbkd_vw_flat_dmnsn.ctry_nm as geo_bmt_ctry_nm,
cse_unbkd_vw_flat_dmnsn.sb_rgn_lvl_2_cd as sb_rgn_lvl_2_cd,
cse_unbkd_vw_flat_dmnsn.sb_rgn_cd as sb_rgn_cd,
cse_unbkd_vw_flat_dmnsn.rgn_cd as geo_bmt_rgn_cd,
actvy_vw_dmnsn.due_tm_dt as due_tm_dt,
actvy_vw_dmnsn.actvy_i_12_nm as actvy_i_12_nm,
actvy_vw_dmnsn.stt_3_nm as stt_3_nm,
actvy_vw_dmnsn.sb_3_nm as sb_3_nm,
actvy_vw_dmnsn.tsk_sbt_63_nm as tsk_sbt_63_nm,
actvy_vw_dmnsn.tsk_ty_64_nm as tsk_ty_64_nm,
actvy_vw_dmnsn.tsk_sbt_nm as tsk_sbt_nm,
unbkd_drvd_metrics_dmnsn.workingdaysopen as workingdaysopen,
unbkd_drvd_metrics_dmnsn.over_25k as over_25k,
unbkd_drvd_metrics_dmnsn.ge_5_wd as ge_5_wd,
unbkd_drvd_metrics_dmnsn.aging_bucket as aging_bucket,
unbkd_drvd_metrics_dmnsn.unclean_in_sap as unclean_in_sap,
unbkd_drvd_metrics_dmnsn.usd_flag as usd_flag,
unbkd_drvd_metrics_dmnsn.om_org as om_org,
unbkd_drvd_metrics_dmnsn.consolidated_amt as consolidated_amt,
unbkd_drvd_metrics_dmnsn.unbooked_aging as unbooked_aging,
unbkd_drvd_metrics_dmnsn.op_aging as op_aging,
unbkd_drvd_metrics_dmnsn.tsk_sbj as tsk_sbj,
unbkd_drvd_metrics_dmnsn.cc as cc,
unbkd_drvd_metrics_dmnsn.gt as gt,
unbkd_drvd_metrics_dmnsn.sc as sc,
unbkd_drvd_metrics_dmnsn.omc as omc,
unbkd_drvd_metrics_dmnsn.cpq as cpq,
unbkd_drvd_metrics_dmnsn.rso as rso,
unbkd_drvd_metrics_dmnsn.others as others,
unbkd_drvd_metrics_dmnsn.open_tasks as open_tasks,
unbkd_drvd_metrics_dmnsn.status_tasks as status_tasks,
unbkd_drvd_metrics_dmnsn.issue_code as issue_code,
unbkd_drvd_metrics_dmnsn.cse_own_ro_nm as cse_own_ro_nm
from (select * from ${dbCommon}.cse_unbkd_vw_flat_dmnsn where ld_jb_nr not like '%his%') cse_unbkd_vw_flat_dmnsn 
left outer join ${dbCommon}.unbkd_drvd_metrics_dmnsn unbkd_drvd_metrics_dmnsn on 
cse_unbkd_vw_flat_dmnsn.cse_i_2_nm=unbkd_drvd_metrics_dmnsn.cse_i_2_nm
left outer join ${dbCommon}.actvy_vw_dmnsn actvy_vw_dmnsn on unbkd_drvd_metrics_dmnsn.actvy_i_12_nm=actvy_vw_dmnsn.actvy_i_12_nm
WHERE UPPER(cse_unbkd_vw_flat_dmnsn.stt_130_nm) <> 'CLOSED' and cse_unbkd_vw_flat_dmnsn.po_nr is NOT NULL and cse_unbkd_vw_flat_dmnsn.crt_37_dt  >= date_sub(to_date(from_unixtime(unix_timestamp())), 365)
""").distinct 

    val sfdcFinalLoadDF = sfdcSelectDF.select(Utilities.loadSelectExpr(sfdcSelectDF.columns, tgtColumns): _*)
    sfdcFinalLoadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblConsmtn)

    val tgtCount = spark.sql(s"select * from ${tgtTblConsmtn} where src_sys_cd = 'SFDC_UNBOOKED_ORDERS'").count.toInt

    tgtCount match {
      case 0 =>
        logger.info("//************* Data Load Failed")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
        jobStatusFlag = false
      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case illegalArgs: IllegalArgumentException => {
      logger.error("IllegalArgumentException Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
  } finally {
    logger.info("//*********************** Log End for SfdcSecuredReport.scala ************************//")
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) System.exit(1)
  }

}
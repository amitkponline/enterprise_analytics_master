package com.hpe.batch.driver.facts.secured_reporting_restatement

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object RestatementSecuredReport extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  val logger = Logger.getLogger(getClass.getName)
  //val objectType = propertiesObject.getObjectType().trim
  val dbCommon = propertiesObject.getDbName().split(",")(0)

  try {
    val processList = spark.sql(s"""
    select prcs_nm,src_sys_cd,rstmnt_dt,snpsht_strt_dt,snpsht_end_dt,snpsht_no from ${dbCommon}.bmt_restmnt_trigr_dmnsn
    """).collect()

    processList.foreach {
      row =>
        row(0).toString().toUpperCase() match {
          case "PC-RESTATE"         => new ProfitCenterRestatementLR1(auditObj, propertiesObject, spark, sqlCon, auditTbl, row(1).toString().split(","), row(2).toString, row(3).toString, row(4).toString, row(5).toString, args(1)).run()
          case "CUST-SEG-REPROCESS" => new CustSegmentRestatementLR1(auditObj, propertiesObject, spark, sqlCon, auditTbl, row(1).toString().split(","), row(2).toString, row(3).toString, row(4).toString, row(5).toString, args(1)).run()
          case "CTRY-NM-REPROCESS"  => new CntryNameRestatementLR1(auditObj, propertiesObject, spark, sqlCon, auditTbl, row(1).toString().split(","), row(2).toString, row(3).toString, row(4).toString, row(5).toString, args(1)).run()
          case _                    => logger.info("############++++++++++ No matching process name built ++++++++++############")
        }
    }

    logger.info("############++++++++++ Restatement Process Completed ++++++++++############")
  } catch {
    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())

    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())

    }
  } finally {
    sqlCon.close
    spark.close
  }
}

package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object ISSOptionedUpSecuredReport extends App {

  val logger = Logger.getLogger(getClass.getName)
  logger.info("//*********************** Log Start for ISSOptionedUp.scala ************************//")

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark

  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  logger.info("+++++++++++++############## properties file:" + propertiesFilePath)

  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  logger.info("+++++++++++++############## environment properties file:" + envPropertiesFilePath)

  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  logger.info("+++++++++++++############## audit table:" + auditTbl)
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  if (sqlCon == null) {
    logger.error("+++++++++++++############## MYSQL Connection Not Established")
    throw new NullPointerException("Please update tgtTblConsmtn properties to add database name!")
  }

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val objName = propertiesObject.getObjName()
  val src_sys_ky_cd = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val dbCommonName = propertiesObject.getDbName().trim().split(",")(0)
  val dbCommonUATName = propertiesObject.getDbName().trim().split(",")(1)
  val dbCommonFinR2_2 = propertiesObject.getDbName().trim().split(",")(2)
  val dbCommonR2_3 = propertiesObject.getDbName().trim().split(",")(3)
  val dbCommonR2_3UAT = propertiesObject.getDbName().trim().split(",")(4)
  val tgtTblName = propertiesObject.getTgtTblConsmtn().trim()
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()

  //***************************Audit Properties********************************//
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_ea_secrd_iss_fact_load")
  auditObj.setAudObjectName(objName)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)

  var dbNameConsmtn: String = null
  var consmptnTable: String = null

  try {

    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toLong

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
    }

    logger.info("********************************************* ISS Option up load data started")

    val tgtCol = spark.sql(s"select * from ${tgtTblName}").columns

    val odrMtrl = spark.sql(s"""
		  select 
			distinct
			secrd_rpt_fact.sls_ord_id as e1edk01_idoc_dcmt_nr,
			secrd_rpt_fact.sls_ord_ln_itm_id as e1edp01_itm_nr,
			secrd_rpt_fact.hghr_lvl_itm_no_cd as e1edp01_higherlevel_itm_bom_structures_cd,
			bmt_prod_alt_hrchy_dmnsn.prod_mppg_23_cd as mtrl_grp_cd,
			null as mtrl_mstr_old_mtrl_id, 
			secrd_rpt_fact.prft_cntr_cd as pft_cntr_nm,
			pft_cntr_alt_hrchy_dmnsn.pc_map_30 as cp_optnd_up,
			CASE 
			  WHEN SERVER_CNT.CNT = 1 THEN 'Pure' 
			  WHEN SERVER_CNT.CNT > 1 THEN 'Multi' 
			  ELSE 'Option Only' 
			END as allc_typ,
			trim(pft_cntr_alt_hrchy_dmnsn.pc_map_31) as ctg_allc,
			trim(bmt_prod_alt_hrchy_dmnsn.prod_mppg_24_cd) as cp_prod_char
			from 
			${srcTableName} secrd_rpt_fact
		  left outer join ${dbCommonR2_3UAT}.ord_mtrl_dmnsn ord_mtrl_dmnsn on ord_mtrl_dmnsn.e1edk01_idoc_dcmt_nr = secrd_rpt_fact.sls_ord_id and ord_mtrl_dmnsn.e1edp01_itm_nr = secrd_rpt_fact.sls_ord_ln_itm_id
		  left outer join ${dbCommonR2_3UAT}.bmt_pft_cntr_alt_hrchy_dmnsn pft_cntr_alt_hrchy_dmnsn on pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd=secrd_rpt_fact.prft_cntr_cd
		  left outer join (SELECT a.e1edk01_idoc_dcmt_nr,COUNT(a.e1edp01_itm_nr) as CNT FROM ${dbCommonR2_3UAT}.ord_mtrl_dmnsn a  
		  left outer join ${dbCommonR2_3UAT}.bmt_prod_alt_hrchy_dmnsn bmt_prod_alt_hrchy_dmnsn on a.e1edp19_idoc_mtrl_i_1_nm_2 = bmt_prod_alt_hrchy_dmnsn.prod_id 
		  WHERE UPPER(TRIM(bmt_prod_alt_hrchy_dmnsn.prod_mppg_23_cd)) = 'SERVER' GROUP BY a.e1edk01_idoc_dcmt_nr ) SERVER_CNT  on SERVER_CNT.e1edk01_idoc_dcmt_nr=ord_mtrl_dmnsn.e1edk01_idoc_dcmt_nr
			left outer join ${dbCommonR2_3UAT}.bmt_prod_alt_hrchy_dmnsn on ord_mtrl_dmnsn.e1edp19_idoc_mtrl_i_1_nm_2 = bmt_prod_alt_hrchy_dmnsn.prod_id 
			where pft_cntr_alt_hrchy_dmnsn.pc_map_30 = 'ISS' and secrd_rpt_fact.src_sys_cd not in ('QUOTES','DEALS','OPPORTUNITY','PC_OFFSET','GL_TRUE_UP')
		  """)

    odrMtrl.write.mode("overwrite").format("orc").insertInto(dbCommonName + ".ord_itm_mtrl_dmnsn")

    val securedFactDF = spark.sql(s"""
      select
        concat('FY',secrd_rpt_fact.fscl_yr_nr,'-',lpad(cast(secrd_rpt_fact.fscl_prd_nr as int),2,'0')) as fscl_yr_prd_cd,
        segment_std_hrchy.sg_level_5 as sgm_lvl_4,
        pft_cntr_std_hrchy.pch_level_3 as pch_lvl_3,
        pft_cntr_std_hrchy.pch_level_5 as pch_lvl_5,
        secrd_rpt_fact.ctry_nm,
        secrd_rpt_fact.cust_sgm_nm,
        secrd_rpt_fact.sls_ord_id,
        secrd_rpt_fact.sls_ord_ln_itm_id,
        coalesce(secrd_rpt_fact.ctry_nm,'') as ctry_geo_allct_nm,
        secrd_rpt_fact.sgmtl_rptg_cd,
        segment_std_hrchy.sg_level_4 as sgm_lvl_3,
        secrd_rpt_fact.prft_cntr_cd,
        pft_cntr_std_hrchy.pch_level_7 as oypl_pch_level_7,
        pft_cntr_std_hrchy.pch_level_7_desc as oypl_pch_level_7_desc,
        pft_cntr_std_hrchy.pch_level_6_desc as oypl_pch_level_6_desc,
        pft_cntr_std_hrchy.pch_level_5_desc as oypl_pch_level_5_desc,
        pft_cntr_std_hrchy.pch_level_4_desc as oypl_pch_level_4_desc,
        pft_cntr_std_hrchy.pch_level_3_desc as oypl_pch_level_3_desc,
        pft_cntr_std_hrchy.pch_level_2_desc as oypl_pch_level_2_desc,
        pft_cntr_std_hrchy.pch_level_1_desc as oypl_pch_level_1_desc,
        secrd_rpt_fact.cp_bklg_sni_rvn,
        secrd_rpt_fact.cp_end_cust_prty_id,
        prty.prty_nm as cp_end_cust_prty_nm,
        secrd_rpt_fact.sld_to_cd,
        secrd_rpt_fact.shp_to_cd,
        secrd_rpt_fact.cp_incd_excld,
        secrd_rpt_fact.scra_cgy_cd,
        secrd_rpt_fact.cp_rev_recgn_cgy_cd,
        secrd_rpt_fact.cp_rev_hdr_nm,
        secrd_rpt_fact.cp_rtm_nm,
        secrd_rpt_fact.mkt_rte_cd,
        secrd_rpt_fact.mtrl_nr,
        secrd_rpt_fact.opty_id,
        secrd_rpt_fact.ord_crt_dt,
        secrd_rpt_fact.ord_typ_cd,
        doc_typ_dmnsn.sls_dcmt_typ_dn as ord_cgy_dn,
        secrd_rpt_fact.rvn_cnvrsn_rt,
        secrd_rpt_fact.rt_cnvsn_src,
        secrd_rpt_fact.fscl_qtr_nr,
				secrd_rpt_fact.invc_id,
				secrd_rpt_fact.src_sys_cd,
				secrd_rpt_fact.beg_bklg_nm,
				secrd_rpt_fact.ttl_rvn_usd_amt,
				secrd_rpt_fact.cp_nt_rvn_usd_amt,
				secrd_rpt_fact.ttl_cst_sls_usd_amt,
				secrd_rpt_fact.cp_net_inv_usd_amt,
				secrd_rpt_fact.cp_grs_inv_usd_amt,
				secrd_rpt_fact.cp_nt_rvn_amt,
				secrd_rpt_fact.cp_ndp_usd_amt,
				secrd_rpt_fact.cp_grs_usd_amt,
				secrd_rpt_fact.cp_entprs_std_cst_usd_amt,
				secrd_rpt_fact.cp_tot_cst_of_sls_usd_amt,
				secrd_rpt_fact.ord_base_qty as base_qty,
				secrd_rpt_fact.unt_qty,
				secrd_rpt_fact.cp_prft_ctr_cd,
				secrd_rpt_fact.hghr_lvl_itm_no_cd,
				secrd_rpt_fact.ttl_rvn_amt,
				secrd_rpt_fact.end_cust_cd,
				secrd_rpt_fact.sgmtl_rptg_cd as cust_sgm_cd,
				secrd_rpt_fact.deal_id,
				secrd_rpt_fact.prod_base_id,
				secrd_rpt_fact.prod_id,
				secrd_rpt_fact.shrt_txt_sls_ord_itm_nm,
				secrd_rpt_fact.cust_po_nr,
				null as plnd_shp_strt_dt,
				secrd_rpt_fact.entrprs_stndrd_cst_grp_curr_usd_amt,
				secrd_rpt_fact.grs_mrgn_usd_amt,
				secrd_rpt_fact.use_nm,
				secrd_rpt_fact.actl_inv_dt,
				secrd_rpt_fact.eurofit_flag,
				secrd_rpt_fact.ord_prch_cd as prch_agrmnt_nr,
				secrd_rpt_fact.sm_actl_gds_mvmt_dt,
				secrd_rpt_fact.sld_to_ctry_ky,
				secrd_rpt_fact.rfrnc_dcmt_nr,
				secrd_rpt_fact.rev_hd_cd
				,secrd_rpt_fact.recon_ky_cd --RAR recon key
				,secrd_rpt_fact.dlvry_id
				,secrd_rpt_fact.ord_net_vl_amt --Total Order values, this field should be Average and not sum
				,secrd_rpt_fact.nt_prc_amt  --net price values, 
				,secrd_rpt_fact.ord_itm_qty --Order Item Quantity, this field should be Average and not sum
				,secrd_rpt_fact.nt_prc_usd_amt --this field should be Average and not sum
				,secrd_rpt_fact.ord_base_qty --Base Quantity, this field should be Average and not sum
				,secrd_rpt_fact.grs_rvn_amt --Gross Revenue
				,secrd_rpt_fact.grs_rvn_usd_amt --Gross Revenue (USD)
				,secrd_rpt_fact.cp_grs_rvn_amt --CP Gross Revenue
				,secrd_rpt_fact.cp_grs_rvn_usd_amt --CP Gross Revenue (USD)
				,secrd_rpt_fact.ttl_cst_sls_amt --Total Cost of Sales
				,secrd_rpt_fact.cp_ttl_cst_sls_amt --CP Total Cost of Sales
				,secrd_rpt_fact.entrprs_stndrd_cst --Enterprise Standard Cost
				,secrd_rpt_fact.entprs_std_cst_usd_amt --Enterprise Standard Cost (USD)
				,secrd_rpt_fact.cp_entrprs_stndrd_cst --CP Enterprise Standard Cost
				,secrd_rpt_fact.actl_qty_dlvrd_stockkeeping_unts --Actual Delivered Stock Keeping Unit
				,secrd_rpt_fact.ord_optn_qty --Order Option Quantity
				,secrd_rpt_fact.ord_ttl_qty --Order Total Quantity
				,secrd_rpt_fact.actl_dlvry_dt
,secrd_rpt_fact.bsn_rshp_typ_cd
,secrd_rpt_fact.cp_crss_brdr
,secrd_rpt_fact.cp_estmd_inv_dt_itm
,secrd_rpt_fact.cp_src_end_cust_prty_id
,secrd_rpt_fact.currency_cd_cd
,secrd_rpt_fact.estmd_invc_date_hdr
,secrd_rpt_fact.itm_stts_cd
,secrd_rpt_fact.nt_rvn_amt
,secrd_rpt_fact.nt_rvn_usd_amt
,secrd_rpt_fact.ord_itm_dcmt_curr_cd
,secrd_rpt_fact.ord_prch_cd
,secrd_rpt_fact.rsn_rjctn_quotations_and_sls_orders_cd
,secrd_rpt_fact.prmry_prcg_cndn_cd
,secrd_rpt_fact.cp_sldt_prty_id
      from
        ${srcTableName}
      left outer join ${dbCommonR2_3}.segment_std_hrchy segment_std_hrchy on secrd_rpt_fact.cp_sgmtl_cd = segment_std_hrchy.sg_level_8
      left outer join ${dbCommonR2_3UAT}.pft_cntr_std_hrchy on secrd_rpt_fact.prft_cntr_cd = pft_cntr_std_hrchy.pch_level_8
      left outer join ${dbCommonR2_3UAT}.prty_fact prty on secrd_rpt_fact.cp_end_cust_prty_id = prty.mdm_id
      left outer join (select doc_type_dm.* from (select doc_typ.*, ROW_NUMBER() OVER (Partition By sls_dcmt_typ_cd,sls_dcmt_typ_dn order by ins_gmt_ts DESC ) as seq_id from ${dbCommonR2_3UAT}.doc_typ_dmnsn doc_typ) as doc_type_dm where doc_type_dm.seq_id=1) as doc_typ_dmnsn on secrd_rpt_fact.ord_typ_cd = doc_typ_dmnsn.sls_dcmt_typ_cd""")

    securedFactDF.createOrReplaceTempView("secrd_rpt_fact")

    val secrd_rpt_layer_1_2_iss = spark.sql(s"""select distinct 
(case when secrd_rpt_fact.fscl_yr_prd_cd is null then '?' else secrd_rpt_fact.fscl_yr_prd_cd end) as fscl_yr_prd_cd,
secrd_rpt_fact.sgm_lvl_4,
secrd_rpt_fact.pch_lvl_3,
secrd_rpt_fact.ctry_nm,
secrd_rpt_fact.cust_sgm_nm,
secrd_rpt_fact.sls_ord_id,
ord_itm_mtrl_dmnsn.e1edk01_idoc_dcmt_nr,
secrd_rpt_fact.sls_ord_ln_itm_id,
ord_itm_mtrl_dmnsn.e1edp01_itm_nr,
ord_itm_mtrl_dmnsn.cp_optnd_up as cp_optnd_up,
ord_itm_mtrl_dmnsn.allc_typ as allc_typ,
ord_itm_mtrl_dmnsn.ctg_allc as ctg_allc,
CASE 
  WHEN ord_itm_mtrl_dmnsn.cp_optnd_up <>'ISS' or ord_itm_mtrl_dmnsn.cp_optnd_up is null THEN NULL
  WHEN UPPER(ord_itm_mtrl_dmnsn.mtrl_grp_cd) ='SERVER' and secrd_rpt_fact.sls_ord_id is not null and secrd_rpt_fact.sls_ord_id <>'' THEN ord_itm_mtrl_dmnsn.ctg_allc
  WHEN UPPER(ord_itm_mtrl_dmnsn.mtrl_grp_cd) <>'SERVER' and secrd_rpt_fact.sls_ord_id is not null and secrd_rpt_fact.sls_ord_id <>'' AND ord_itm_mtrl_dmnsn.allc_typ='Pure' AND high_lvl.e1edk01_idoc_dcmt_nr is not null  THEN high_lvl.ctg_allc
  WHEN UPPER(ord_itm_mtrl_dmnsn.mtrl_grp_cd) <>'SERVER' and secrd_rpt_fact.sls_ord_id is not null and secrd_rpt_fact.sls_ord_id <>'' AND ord_itm_mtrl_dmnsn.allc_typ='Multi' AND high_lvl.e1edk01_idoc_dcmt_nr is not null  THEN high_lvl.ctg_allc
  WHEN UPPER(ord_itm_mtrl_dmnsn.ctg_allc) <> 'SHARED' THEN ord_itm_mtrl_dmnsn.ctg_allc
ELSE ord_itm_mtrl_dmnsn.ctg_allc END  as cp_fnl_eg_ctg,
CASE 
  WHEN ord_itm_mtrl_dmnsn.cp_optnd_up <>'ISS' or ord_itm_mtrl_dmnsn.cp_optnd_up is null THEN NULL
  WHEN UPPER(ord_itm_mtrl_dmnsn.mtrl_grp_cd) ='SERVER' and secrd_rpt_fact.sls_ord_id is not null and secrd_rpt_fact.sls_ord_id <>'' THEN 'Layer 1'
  WHEN UPPER(ord_itm_mtrl_dmnsn.mtrl_grp_cd) <> 'SERVER' AND high_lvl.e1edk01_idoc_dcmt_nr is not null and secrd_rpt_fact.sls_ord_id <>'' and secrd_rpt_fact.sls_ord_ln_itm_id is not null  THEN 'Layer 1'
  WHEN UPPER(ord_itm_mtrl_dmnsn.ctg_allc) <> 'SHARED'  THEN 'Layer 2'
ELSE NULL END as allc_lyr,
CASE 
	WHEN ord_itm_mtrl_dmnsn.cp_optnd_up <>'ISS' or ord_itm_mtrl_dmnsn.cp_optnd_up is null THEN NULL
	WHEN UPPER(ord_itm_mtrl_dmnsn.mtrl_grp_cd) ='SERVER' and secrd_rpt_fact.sls_ord_id is not null and secrd_rpt_fact.sls_ord_id <>'' THEN ord_itm_mtrl_dmnsn.cp_prod_char
	WHEN UPPER(ord_itm_mtrl_dmnsn.mtrl_grp_cd) <>'SERVER' and secrd_rpt_fact.sls_ord_id is not null and secrd_rpt_fact.sls_ord_id <>'' AND ord_itm_mtrl_dmnsn.allc_typ='Pure' AND high_lvl.e1edk01_idoc_dcmt_nr is not null THEN high_lvl.cp_prod_char
	WHEN UPPER(ord_itm_mtrl_dmnsn.mtrl_grp_cd) <>'SERVER' and secrd_rpt_fact.sls_ord_id is not null and secrd_rpt_fact.sls_ord_id <>'' AND ord_itm_mtrl_dmnsn.allc_typ='Multi' AND high_lvl.e1edk01_idoc_dcmt_nr is not null THEN high_lvl.cp_prod_char
	WHEN UPPER(ord_itm_mtrl_dmnsn.ctg_allc) <> 'SHARED' and secrd_rpt_fact.sls_ord_id is not null and secrd_rpt_fact.sls_ord_id <> '' and (bmt_ord_ins_dmnsn_with_so.pltf_allctn is not null and length(bmt_ord_ins_dmnsn_with_so.pltf_allctn) <> 0)  then bmt_ord_ins_dmnsn_with_so.pltf_allctn
	WHEN UPPER(ord_itm_mtrl_dmnsn.ctg_allc) <> 'SHARED' and (bmt_ord_ins_dmnsn_without_so.pltf_allctn is not null and length(bmt_ord_ins_dmnsn_without_so.pltf_allctn) <> 0)  then bmt_ord_ins_dmnsn_without_so.pltf_allctn
	WHEN UPPER(ord_itm_mtrl_dmnsn.ctg_allc) <> 'SHARED' THEN ord_itm_mtrl_dmnsn.cp_prod_char
ELSE ord_itm_mtrl_dmnsn.cp_prod_char END as cp_prod_char,
coalesce(bmt_allctn_cust_geo_dmnsn.ctry_geo_allct_nm,secrd_rpt_fact.ctry_nm ) as ctry_geo_allct_nm,
bmt_allctn_cust_geo_dmnsn.allctn_rate,
secrd_rpt_fact.sgmtl_rptg_cd,
secrd_rpt_fact.sgm_lvl_3,
secrd_rpt_fact.prft_cntr_cd,
secrd_rpt_fact.oypl_pch_level_7,
secrd_rpt_fact.oypl_pch_level_7_desc,
secrd_rpt_fact.oypl_pch_level_6_desc,
secrd_rpt_fact.oypl_pch_level_5_desc,
secrd_rpt_fact.oypl_pch_level_4_desc,
secrd_rpt_fact.oypl_pch_level_3_desc,
secrd_rpt_fact.oypl_pch_level_2_desc,
secrd_rpt_fact.oypl_pch_level_1_desc,
secrd_rpt_fact.cp_bklg_sni_rvn,
secrd_rpt_fact.cp_end_cust_prty_id,
secrd_rpt_fact.cp_end_cust_prty_nm,
secrd_rpt_fact.sld_to_cd,
secrd_rpt_fact.shp_to_cd,
secrd_rpt_fact.cp_incd_excld,
secrd_rpt_fact.scra_cgy_cd,
secrd_rpt_fact.cp_rev_recgn_cgy_cd,
secrd_rpt_fact.cp_rev_hdr_nm,
secrd_rpt_fact.cp_rtm_nm,
secrd_rpt_fact.mkt_rte_cd,
secrd_rpt_fact.mtrl_nr,
secrd_rpt_fact.opty_id,
secrd_rpt_fact.ord_crt_dt,
secrd_rpt_fact.ord_typ_cd,
secrd_rpt_fact.ord_cgy_dn,
secrd_rpt_fact.rvn_cnvrsn_rt,
secrd_rpt_fact.rt_cnvsn_src,
secrd_rpt_fact.fscl_qtr_nr,
secrd_rpt_fact.invc_id,
secrd_rpt_fact.src_sys_cd,
secrd_rpt_fact.beg_bklg_nm,
secrd_rpt_fact.ttl_rvn_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ttl_rvn_usd_amt,
secrd_rpt_fact.cp_nt_rvn_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_nt_rvn_usd_amt,
secrd_rpt_fact.ttl_cst_sls_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ttl_cst_sls_usd_amt,
secrd_rpt_fact.cp_net_inv_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_net_inv_usd_amt,
secrd_rpt_fact.cp_grs_inv_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_grs_inv_usd_amt,
secrd_rpt_fact.cp_nt_rvn_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_nt_rvn_amt,
secrd_rpt_fact.cp_ndp_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_ndp_usd_amt,
secrd_rpt_fact.cp_grs_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_grs_usd_amt,
secrd_rpt_fact.cp_entprs_std_cst_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_entprs_std_cst_usd_amt,
secrd_rpt_fact.cp_tot_cst_of_sls_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_tot_cst_of_sls_usd_amt,
secrd_rpt_fact.base_qty*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as base_qty,
secrd_rpt_fact.unt_qty*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as unt_qty,
secrd_rpt_fact.cp_prft_ctr_cd,
--secrd_rpt_fact.nt_rvn_amt_usd,
secrd_rpt_fact.ttl_rvn_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ttl_rvn_amt,
--secrd_rpt_fact.end_cus_nm,
secrd_rpt_fact.end_cust_cd,
secrd_rpt_fact.hghr_lvl_itm_no_cd,
secrd_rpt_fact.cust_sgm_cd,
secrd_rpt_fact.deal_id,
secrd_rpt_fact.prod_base_id,
secrd_rpt_fact.prod_id,
secrd_rpt_fact.shrt_txt_sls_ord_itm_nm,
secrd_rpt_fact.cust_po_nr,
secrd_rpt_fact.plnd_shp_strt_dt,
secrd_rpt_fact.entrprs_stndrd_cst_grp_curr_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as entrprs_stndrd_cst_grp_curr_usd_amt,
secrd_rpt_fact.grs_mrgn_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as grs_mrgn_usd_amt,
secrd_rpt_fact.use_nm,
secrd_rpt_fact.actl_inv_dt,
secrd_rpt_fact.eurofit_flag,
secrd_rpt_fact.prch_agrmnt_nr,
secrd_rpt_fact.sm_actl_gds_mvmt_dt,
secrd_rpt_fact.sld_to_ctry_ky,
secrd_rpt_fact.rfrnc_dcmt_nr,
secrd_rpt_fact.rev_hd_cd
,secrd_rpt_fact.recon_ky_cd
,secrd_rpt_fact.dlvry_id
,secrd_rpt_fact.ord_net_vl_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ord_net_vl_amt
,secrd_rpt_fact.nt_prc_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as nt_prc_amt
,secrd_rpt_fact.ord_itm_qty*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ord_itm_qty
,secrd_rpt_fact.nt_prc_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as nt_prc_usd_amt
,secrd_rpt_fact.ord_base_qty*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ord_base_qty
,secrd_rpt_fact.grs_rvn_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as grs_rvn_amt
,secrd_rpt_fact.grs_rvn_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as grs_rvn_usd_amt
,secrd_rpt_fact.cp_grs_rvn_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_grs_rvn_amt
,secrd_rpt_fact.cp_grs_rvn_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_grs_rvn_usd_amt
,secrd_rpt_fact.ttl_cst_sls_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ttl_cst_sls_amt
,secrd_rpt_fact.cp_ttl_cst_sls_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_ttl_cst_sls_amt
,secrd_rpt_fact.entrprs_stndrd_cst*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as entrprs_stndrd_cst
,secrd_rpt_fact.entprs_std_cst_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as entprs_std_cst_usd_amt
,secrd_rpt_fact.cp_entrprs_stndrd_cst*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as cp_entrprs_stndrd_cst
,secrd_rpt_fact.actl_qty_dlvrd_stockkeeping_unts*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as actl_qty_dlvrd_stockkeeping_unts
,secrd_rpt_fact.ord_optn_qty*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ord_optn_qty
,secrd_rpt_fact.ord_ttl_qty*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as ord_ttl_qty
,secrd_rpt_fact.actl_dlvry_dt
,secrd_rpt_fact.bsn_rshp_typ_cd
,secrd_rpt_fact.cp_crss_brdr
,secrd_rpt_fact.cp_estmd_inv_dt_itm
,secrd_rpt_fact.cp_src_end_cust_prty_id
,secrd_rpt_fact.currency_cd_cd
,secrd_rpt_fact.estmd_invc_date_hdr
,secrd_rpt_fact.itm_stts_cd
,secrd_rpt_fact.nt_rvn_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as nt_rvn_amt
,secrd_rpt_fact.nt_rvn_usd_amt*coalesce(bmt_allctn_cust_geo_dmnsn.allctn_rate,1) as nt_rvn_usd_amt
,secrd_rpt_fact.ord_itm_dcmt_curr_cd
,secrd_rpt_fact.ord_prch_cd
,secrd_rpt_fact.rsn_rjctn_quotations_and_sls_orders_cd
,secrd_rpt_fact.prmry_prcg_cndn_cd
,secrd_rpt_fact.cp_sldt_prty_id
from secrd_rpt_fact
left outer join ${dbCommonName}.ord_itm_mtrl_dmnsn ord_itm_mtrl_dmnsn on coalesce(secrd_rpt_fact.sls_ord_id,'')=coalesce(ord_itm_mtrl_dmnsn.e1edk01_idoc_dcmt_nr,'') and coalesce(ord_itm_mtrl_dmnsn.e1edp01_itm_nr,'')=coalesce(secrd_rpt_fact.sls_ord_ln_itm_id,'')  and secrd_rpt_fact.prft_cntr_cd=ord_itm_mtrl_dmnsn.pft_cntr_nm
left outer join (select e1edk01_idoc_dcmt_nr, e1edp01_itm_nr, ctg_allc,cp_prod_char from ${dbCommonName}.ord_itm_mtrl_dmnsn where mtrl_grp_cd ='SERVER' ) ORD_CP_DINAL_PURE on cast(ORD_CP_DINAL_PURE.e1edk01_idoc_dcmt_nr as bigint)= cast(secrd_rpt_fact.sls_ord_id as bigint) and cast(ORD_CP_DINAL_PURE.e1edp01_itm_nr as int)= cast(secrd_rpt_fact.sls_ord_ln_itm_id as int) 
left outer join (select e1edk01_idoc_dcmt_nr, e1edp01_itm_nr, ctg_allc,cp_prod_char from ${dbCommonName}.ord_itm_mtrl_dmnsn where mtrl_grp_cd ='SERVER' ) ORD_CP_DINAL_MULTI on cast(ORD_CP_DINAL_MULTI.e1edk01_idoc_dcmt_nr as bigint) = cast(secrd_rpt_fact.sls_ord_id as bigint)  and cast(ORD_CP_DINAL_MULTI.e1edp01_itm_nr as int) = cast(secrd_rpt_fact.hghr_lvl_itm_no_cd as int)
left outer join ${dbCommonR2_3UAT}.bmt_allctn_cust_geo_dmnsn bmt_allctn_cust_geo_dmnsn on bmt_allctn_cust_geo_dmnsn.fscl_yr_mt_cd=secrd_rpt_fact.fscl_yr_prd_cd and bmt_allctn_cust_geo_dmnsn.pft_cntr_cgy_lvl_5_cd=secrd_rpt_fact.pch_lvl_5 AND bmt_allctn_cust_geo_dmnsn.ctry_nm=secrd_rpt_fact.ctry_nm
left outer join (select e1edk01_idoc_dcmt_nr, e1edp01_itm_nr, ctg_allc,cp_prod_char from ${dbCommonName}.ord_itm_mtrl_dmnsn where UPPER(mtrl_grp_cd) ='SERVER') high_lvl on cast(high_lvl.e1edk01_idoc_dcmt_nr as bigint) = cast(secrd_rpt_fact.sls_ord_id as bigint)  and cast(high_lvl.e1edp01_itm_nr as int) = cast(secrd_rpt_fact.hghr_lvl_itm_no_cd as int)
left outer join ${dbCommonR2_3UAT}.bmt_ord_ins_dmnsn bmt_ord_ins_dmnsn_with_so on bmt_ord_ins_dmnsn_with_so.sls_ord_id=secrd_rpt_fact.sls_ord_id and 
bmt_ord_ins_dmnsn_with_so.pft_cntr_cd=secrd_rpt_fact.prft_cntr_cd
left outer join ${dbCommonR2_3UAT}.bmt_ord_ins_dmnsn bmt_ord_ins_dmnsn_without_so on bmt_ord_ins_dmnsn_without_so.pft_cntr_cd=secrd_rpt_fact.prft_cntr_cd
where
secrd_rpt_fact.src_sys_cd not in ('QUOTES','DEALS','OPPORTUNITY','PC_OFFSET','GL_TRUE_UP') and ord_itm_mtrl_dmnsn.cp_optnd_up = 'ISS'
""")

    val tgtcol1_2 = spark.sql(s"select * from ${dbNameConsmtn}.secrd_rpt_layer_1_2_iss").columns

    val dataLoadISS_layer2df = secrd_rpt_layer_1_2_iss.select(Utilities.loadSelectExpr(secrd_rpt_layer_1_2_iss.columns, tgtcol1_2): _*)

    dataLoadISS_layer2df.write.mode("overwrite").format("orc").insertInto(dbCommonFinR2_2 + ".secrd_rpt_layer_1_2_iss")

    val dataLoadISS_layer2 = secrd_rpt_layer_1_2_iss.select(Utilities.loadSelectExpr(secrd_rpt_layer_1_2_iss.columns, tgtCol): _*)

    logger.info("++++++++++++############# Data loaded to secrd_rpt_layer_1_2_iss #############++++++++++++")

    val secrd_rpt_iss_3 = spark.sql(s"""
select distinct 
secrd_rpt_layer_1_2_iss.fscl_yr_prd_cd,
secrd_rpt_layer_1_2_iss.sgm_lvl_4,
secrd_rpt_layer_1_2_iss.pch_lvl_3,
secrd_rpt_layer_1_2_iss.ctry_nm,
secrd_rpt_layer_1_2_iss.cust_sgm_nm,
secrd_rpt_layer_1_2_iss.sls_ord_id,
secrd_rpt_layer_1_2_iss.e1edk01_idoc_dcmt_nr,
secrd_rpt_layer_1_2_iss.sls_ord_ln_itm_id,
secrd_rpt_layer_1_2_iss.e1edp01_itm_nr,
secrd_rpt_layer_1_2_iss.cp_optnd_up,
secrd_rpt_layer_1_2_iss.allc_typ,
secrd_rpt_layer_1_2_iss.ctg_allc,
case 
  when lower(secrd_rpt_layer_1_2_iss.ctg_allc) = 'shared' and secrd_rpt_layer_1_2_iss.sls_ord_id is not null and secrd_rpt_layer_1_2_iss.sls_ord_id <> '' and (bmt_ord_ins_dmnsn.iss_cgy_allctn is not null and length(trim(bmt_ord_ins_dmnsn.iss_cgy_allctn)) <> 0)  then bmt_ord_ins_dmnsn.iss_cgy_allctn
  -- when lower(secrd_rpt_layer_1_2_iss.ctg_allc) = 'shared' and secrd_rpt_layer_1_2_iss.sls_ord_id is not null and secrd_rpt_layer_1_2_iss.sls_ord_id <> '' and (bmt_ord_ins_dmnsn.iss_cgy_allctn is null or length(trim(bmt_ord_ins_dmnsn.iss_cgy_allctn)) = 0) then bmt_optn_up_allctn_cgy_rate_dmnsn.to_eg_catg  
  when lower(secrd_rpt_layer_1_2_iss.ctg_allc) <> 'shared' and secrd_rpt_layer_1_2_iss.sls_ord_id is not null and secrd_rpt_layer_1_2_iss.sls_ord_id <> '' then secrd_rpt_layer_1_2_iss.cp_fnl_eg_ctg
  else bmt_optn_up_allctn_cgy_rate_dmnsn.to_eg_catg end cp_fnl_eg_ctg,
CASE 
  WHEN (secrd_rpt_layer_1_2_iss.cp_optnd_up='ISS' AND  secrd_rpt_layer_1_2_iss.allc_lyr IS NULL) 
  AND secrd_rpt_layer_1_2_iss.src_sys_cd <> 'TRUE_UP' and secrd_rpt_layer_1_2_iss.sls_ord_id is not null and secrd_rpt_layer_1_2_iss.sls_ord_id <> '' THEN 'Layer 3' 
  ELSE secrd_rpt_layer_1_2_iss.allc_lyr 
END as allc_lyr,
case when bmt_ord_ins_dmnsn.pltf_allctn is not null and secrd_rpt_layer_1_2_iss.sls_ord_id is not null and secrd_rpt_layer_1_2_iss.sls_ord_id <> '' and length(bmt_ord_ins_dmnsn.pltf_allctn) <> 0 then bmt_ord_ins_dmnsn.pltf_allctn else secrd_rpt_layer_1_2_iss.cp_prod_char end as cp_prod_char,
secrd_rpt_layer_1_2_iss.ctry_geo_allct_nm,
secrd_rpt_layer_1_2_iss.allctn_rate,
secrd_rpt_layer_1_2_iss.sgmtl_rptg_cd,
secrd_rpt_layer_1_2_iss.sgm_lvl_3,
secrd_rpt_layer_1_2_iss.prft_cntr_cd,
secrd_rpt_layer_1_2_iss.oypl_pch_level_7,
secrd_rpt_layer_1_2_iss.oypl_pch_level_7_desc,
secrd_rpt_layer_1_2_iss.oypl_pch_level_6_desc,
secrd_rpt_layer_1_2_iss.oypl_pch_level_5_desc,
secrd_rpt_layer_1_2_iss.oypl_pch_level_4_desc,
secrd_rpt_layer_1_2_iss.oypl_pch_level_3_desc,
secrd_rpt_layer_1_2_iss.oypl_pch_level_2_desc,
secrd_rpt_layer_1_2_iss.oypl_pch_level_1_desc,
secrd_rpt_layer_1_2_iss.cp_bklg_sni_rvn,
secrd_rpt_layer_1_2_iss.cp_end_cust_prty_id,
secrd_rpt_layer_1_2_iss.cp_end_cust_prty_nm,
secrd_rpt_layer_1_2_iss.sld_to_cd,
secrd_rpt_layer_1_2_iss.shp_to_cd,
secrd_rpt_layer_1_2_iss.cp_incd_excld,
secrd_rpt_layer_1_2_iss.scra_cgy_cd,
secrd_rpt_layer_1_2_iss.cp_rev_recgn_cgy_cd,
secrd_rpt_layer_1_2_iss.cp_rev_hdr_nm,
secrd_rpt_layer_1_2_iss.cp_rtm_nm,
secrd_rpt_layer_1_2_iss.mkt_rte_cd,
secrd_rpt_layer_1_2_iss.mtrl_nr,
secrd_rpt_layer_1_2_iss.opty_id,
secrd_rpt_layer_1_2_iss.ord_crt_dt,
secrd_rpt_layer_1_2_iss.ord_typ_cd,
secrd_rpt_layer_1_2_iss.ord_cgy_dn,
secrd_rpt_layer_1_2_iss.rvn_cnvrsn_rt,
secrd_rpt_layer_1_2_iss.rt_cnvsn_src,
secrd_rpt_layer_1_2_iss.fscl_qtr_nr,
secrd_rpt_layer_1_2_iss.invc_id,
secrd_rpt_layer_1_2_iss.src_sys_cd,
secrd_rpt_layer_1_2_iss.beg_bklg_nm,
secrd_rpt_layer_1_2_iss.ttl_rvn_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS ttl_rvn_usd_amt,
secrd_rpt_layer_1_2_iss.cp_nt_rvn_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_nt_rvn_usd_amt,
secrd_rpt_layer_1_2_iss.ttl_cst_sls_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt ,1) AS ttl_cst_sls_usd_amt,
secrd_rpt_layer_1_2_iss.cp_net_inv_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_net_inv_usd_amt,
secrd_rpt_layer_1_2_iss.cp_grs_inv_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_grs_inv_usd_amt,
secrd_rpt_layer_1_2_iss.cp_nt_rvn_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_nt_rvn_amt,
secrd_rpt_layer_1_2_iss.cp_ndp_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)   AS cp_ndp_usd_amt,
secrd_rpt_layer_1_2_iss.cp_grs_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS cp_grs_usd_amt,
secrd_rpt_layer_1_2_iss.cp_entprs_std_cst_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) AS cp_entprs_std_cst_usd_amt,
secrd_rpt_layer_1_2_iss.cp_tot_cst_of_sls_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) AS cp_tot_cst_of_sls_usd_amt,
secrd_rpt_layer_1_2_iss.base_qty*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS base_qty,
secrd_rpt_layer_1_2_iss.unt_qty*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS unt_qty,
secrd_rpt_layer_1_2_iss.cp_prft_ctr_cd,
secrd_rpt_layer_1_2_iss.ttl_rvn_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS ttl_rvn_amt,
secrd_rpt_layer_1_2_iss.end_cust_cd,
secrd_rpt_layer_1_2_iss.hghr_lvl_itm_no_cd,
bmt_optn_up_allctn_cgy_rate_dmnsn.to_eg_catg,
bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,
secrd_rpt_layer_1_2_iss.cust_sgm_cd,
secrd_rpt_layer_1_2_iss.deal_id,
secrd_rpt_layer_1_2_iss.prod_base_id,
secrd_rpt_layer_1_2_iss.prod_id,
secrd_rpt_layer_1_2_iss.shrt_txt_sls_ord_itm_nm,
secrd_rpt_layer_1_2_iss.cust_po_nr,
secrd_rpt_layer_1_2_iss.plnd_shp_strt_dt,
secrd_rpt_layer_1_2_iss.entrprs_stndrd_cst_grp_curr_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS entrprs_stndrd_cst_grp_curr_usd_amt,
secrd_rpt_layer_1_2_iss.grs_mrgn_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1)  AS grs_mrgn_usd_amt,
secrd_rpt_layer_1_2_iss.use_nm,
secrd_rpt_layer_1_2_iss.actl_inv_dt,
secrd_rpt_layer_1_2_iss.eurofit_flag,
secrd_rpt_layer_1_2_iss.prch_agrmnt_nr,
secrd_rpt_layer_1_2_iss.sm_actl_gds_mvmt_dt,
secrd_rpt_layer_1_2_iss.sld_to_ctry_ky,
secrd_rpt_layer_1_2_iss.rfrnc_dcmt_nr,
secrd_rpt_layer_1_2_iss.rev_hd_cd
,secrd_rpt_layer_1_2_iss.recon_ky_cd
,secrd_rpt_layer_1_2_iss.dlvry_id
,secrd_rpt_layer_1_2_iss.ord_net_vl_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as ord_net_vl_amt
,secrd_rpt_layer_1_2_iss.nt_prc_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as nt_prc_amt
,secrd_rpt_layer_1_2_iss.ord_itm_qty*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as ord_itm_qty
,secrd_rpt_layer_1_2_iss.nt_prc_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as nt_prc_usd_amt
,secrd_rpt_layer_1_2_iss.ord_base_qty*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as ord_base_qty
,secrd_rpt_layer_1_2_iss.grs_rvn_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as grs_rvn_amt
,secrd_rpt_layer_1_2_iss.grs_rvn_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as grs_rvn_usd_amt
,secrd_rpt_layer_1_2_iss.cp_grs_rvn_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as cp_grs_rvn_amt
,secrd_rpt_layer_1_2_iss.cp_grs_rvn_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as cp_grs_rvn_usd_amt
,secrd_rpt_layer_1_2_iss.ttl_cst_sls_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as ttl_cst_sls_amt
,secrd_rpt_layer_1_2_iss.cp_ttl_cst_sls_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as cp_ttl_cst_sls_amt
,secrd_rpt_layer_1_2_iss.entrprs_stndrd_cst*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as entrprs_stndrd_cst
,secrd_rpt_layer_1_2_iss.entprs_std_cst_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as entprs_std_cst_usd_amt
,secrd_rpt_layer_1_2_iss.cp_entrprs_stndrd_cst*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as cp_entrprs_stndrd_cst
,secrd_rpt_layer_1_2_iss.actl_qty_dlvrd_stockkeeping_unts*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as actl_qty_dlvrd_stockkeeping_unts
,secrd_rpt_layer_1_2_iss.ord_optn_qty*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as ord_optn_qty
,secrd_rpt_layer_1_2_iss.ord_ttl_qty*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as ord_ttl_qty
,bmt_optn_up_allctn_cgy_rate_dmnsn.fisc_mth_cd
,bmt_optn_up_allctn_cgy_rate_dmnsn.dsply_ctry_nm
,bmt_optn_up_allctn_cgy_rate_dmnsn.final_rtm
,secrd_rpt_layer_1_2_iss.actl_dlvry_dt
,secrd_rpt_layer_1_2_iss.bsn_rshp_typ_cd
,secrd_rpt_layer_1_2_iss.cp_crss_brdr
,secrd_rpt_layer_1_2_iss.cp_estmd_inv_dt_itm
,secrd_rpt_layer_1_2_iss.cp_src_end_cust_prty_id
,secrd_rpt_layer_1_2_iss.currency_cd_cd
,secrd_rpt_layer_1_2_iss.estmd_invc_date_hdr
,secrd_rpt_layer_1_2_iss.itm_stts_cd
,secrd_rpt_layer_1_2_iss.nt_rvn_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as nt_rvn_amt
,secrd_rpt_layer_1_2_iss.nt_rvn_usd_amt*COALESCE(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rt,1) as nt_rvn_usd_amt
,secrd_rpt_layer_1_2_iss.ord_itm_dcmt_curr_cd
,secrd_rpt_layer_1_2_iss.ord_prch_cd
,secrd_rpt_layer_1_2_iss.rsn_rjctn_quotations_and_sls_orders_cd
,secrd_rpt_layer_1_2_iss.prmry_prcg_cndn_cd
,secrd_rpt_layer_1_2_iss.cp_sldt_prty_id
from (select * from ${dbCommonFinR2_2}.secrd_rpt_layer_1_2_iss where allc_lyr is null) secrd_rpt_layer_1_2_iss 
left outer join ${dbCommonR2_3UAT}.bmt_ord_ins_dmnsn bmt_ord_ins_dmnsn on bmt_ord_ins_dmnsn.sls_ord_id=secrd_rpt_layer_1_2_iss.sls_ord_id and 
bmt_ord_ins_dmnsn.pft_cntr_cd=secrd_rpt_layer_1_2_iss.prft_cntr_cd
left outer join ${dbCommonR2_3UAT}.bmt_optn_up_allctn_cgy_rate_dmnsn bmt_optn_up_allctn_cgy_rate_dmnsn on
bmt_optn_up_allctn_cgy_rate_dmnsn.fisc_mth_cd = secrd_rpt_layer_1_2_iss.fscl_yr_prd_cd and
bmt_optn_up_allctn_cgy_rate_dmnsn.dsply_ctry_nm = secrd_rpt_layer_1_2_iss.ctry_geo_allct_nm and
UPPER(bmt_optn_up_allctn_cgy_rate_dmnsn.final_rtm) = UPPER(secrd_rpt_layer_1_2_iss.mkt_rte_cd) and
bmt_optn_up_allctn_cgy_rate_dmnsn.catg_lvl_1 = secrd_rpt_layer_1_2_iss.cp_optnd_up and
secrd_rpt_layer_1_2_iss.cp_optnd_up = 'ISS'
""")

    //val dataLoadISS_layer3 = secrd_rpt_iss_3.select(Utilities.loadSelectExpr(secrd_rpt_iss_3.columns, tgtCol): _*)

    secrd_rpt_iss_3.createOrReplaceTempView("secrd_rpt_iss_lyr_123")

    val dataLoadISS_layer3 = secrd_rpt_iss_3.select(Utilities.loadSelectExpr(secrd_rpt_iss_3.columns, tgtCol): _*)

    logger.info("++++++++++++############# Data loaded to secrd_rpt_iss_lyr_123 #############++++++++++++")

    val secrd_rpt_iss_4 = spark.sql(s"""select distinct 
secrd_rpt_layer_iss.fscl_yr_prd_cd,
secrd_rpt_layer_iss.sgm_lvl_4,
secrd_rpt_layer_iss.pch_lvl_3,
secrd_rpt_layer_iss.ctry_nm,
secrd_rpt_layer_iss.cust_sgm_nm,
secrd_rpt_layer_iss.sls_ord_id,
--secrd_rpt_layer_iss.e1edk01_idoc_dcmt_nr,
secrd_rpt_layer_iss.sls_ord_ln_itm_id,
--secrd_rpt_layer_iss.e1edp01_itm_nr,
secrd_rpt_layer_iss.cp_optnd_up,
secrd_rpt_layer_iss.allc_typ,
secrd_rpt_layer_iss.ctg_allc,
CASE 
WHEN lower(secrd_rpt_layer_iss.ctg_allc) = 'shared' and (secrd_rpt_layer_iss.src_sys_cd='TRUE_UP' or secrd_rpt_layer_iss.sls_ord_id is null or secrd_rpt_layer_iss.sls_ord_id='') and (bmt_ord_ins_dmnsn.iss_cgy_allctn is not null and length(bmt_ord_ins_dmnsn.iss_cgy_allctn) <> 0) then bmt_ord_ins_dmnsn.iss_cgy_allctn
WHEN (secrd_rpt_layer_iss.src_sys_cd='TRUE_UP' or secrd_rpt_layer_iss.sls_ord_id is null or secrd_rpt_layer_iss.sls_ord_id ='') AND secrd_rpt_layer_iss.hghr_lvl_itm_no_cd IS NULL AND 
secrd_rpt_layer_iss.ctg_allc <> 'Shared' THEN secrd_rpt_layer_iss.ctg_allc else secrd_rpt_layer_iss.cp_fnl_eg_ctg end as cp_fnl_eg_ctg,
CASE 
WHEN secrd_rpt_layer_iss.allc_lyr IS NULL and (secrd_rpt_layer_iss.src_sys_cd='TRUE_UP' or secrd_rpt_layer_iss.sls_ord_id is null or secrd_rpt_layer_iss.sls_ord_id ='') THEN 'Layer 4' ELSE secrd_rpt_layer_iss.allc_lyr END as allc_lyr,
case when bmt_ord_ins_dmnsn.pltf_allctn is not null and (secrd_rpt_layer_iss.sls_ord_id is null or secrd_rpt_layer_iss.sls_ord_id ='') and length(bmt_ord_ins_dmnsn.pltf_allctn) <> 0 then 
bmt_ord_ins_dmnsn.pltf_allctn else secrd_rpt_layer_iss.cp_prod_char end as cp_prod_char,
secrd_rpt_layer_iss.ctry_geo_allct_nm,
secrd_rpt_layer_iss.allctn_rate,
secrd_rpt_layer_iss.sgmtl_rptg_cd,
secrd_rpt_layer_iss.sgm_lvl_3,
secrd_rpt_layer_iss.prft_cntr_cd,
secrd_rpt_layer_iss.oypl_pch_level_7,
secrd_rpt_layer_iss.oypl_pch_level_7_desc,
secrd_rpt_layer_iss.oypl_pch_level_6_desc,
secrd_rpt_layer_iss.oypl_pch_level_5_desc,
secrd_rpt_layer_iss.oypl_pch_level_4_desc,
secrd_rpt_layer_iss.oypl_pch_level_3_desc,
secrd_rpt_layer_iss.oypl_pch_level_2_desc,
secrd_rpt_layer_iss.oypl_pch_level_1_desc,
secrd_rpt_layer_iss.cp_bklg_sni_rvn,
secrd_rpt_layer_iss.cp_end_cust_prty_id,
secrd_rpt_layer_iss.cp_end_cust_prty_nm,
secrd_rpt_layer_iss.sld_to_cd,
secrd_rpt_layer_iss.shp_to_cd,
secrd_rpt_layer_iss.cp_incd_excld,
secrd_rpt_layer_iss.scra_cgy_cd,
secrd_rpt_layer_iss.cp_rev_recgn_cgy_cd,
secrd_rpt_layer_iss.cp_rev_hdr_nm,
secrd_rpt_layer_iss.cp_rtm_nm,
secrd_rpt_layer_iss.mkt_rte_cd,
secrd_rpt_layer_iss.mtrl_nr,
secrd_rpt_layer_iss.opty_id,
secrd_rpt_layer_iss.ord_crt_dt,
secrd_rpt_layer_iss.ord_typ_cd,
secrd_rpt_layer_iss.ord_cgy_dn,
secrd_rpt_layer_iss.rvn_cnvrsn_rt,
secrd_rpt_layer_iss.rt_cnvsn_src,
secrd_rpt_layer_iss.fscl_qtr_nr,
secrd_rpt_layer_iss.invc_id,
secrd_rpt_layer_iss.src_sys_cd,
secrd_rpt_layer_iss.beg_bklg_nm,
secrd_rpt_layer_iss.ttl_rvn_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1)  AS ttl_rvn_usd_amt,
secrd_rpt_layer_iss.cp_nt_rvn_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1)  AS cp_nt_rvn_usd_amt,
secrd_rpt_layer_iss.ttl_cst_sls_usd_amt*COALESCE(bmt_optnd_up.fnl_rt ,1) AS ttl_cst_sls_usd_amt,
secrd_rpt_layer_iss.cp_net_inv_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1)  AS cp_net_inv_usd_amt,
secrd_rpt_layer_iss.cp_grs_inv_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1)  AS cp_grs_inv_usd_amt,
secrd_rpt_layer_iss.cp_nt_rvn_amt*COALESCE(bmt_optnd_up.fnl_rt,1)  AS cp_nt_rvn_amt,
secrd_rpt_layer_iss.cp_ndp_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1)   AS cp_ndp_usd_amt,
secrd_rpt_layer_iss.cp_grs_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1)  AS cp_grs_usd_amt,
secrd_rpt_layer_iss.cp_entprs_std_cst_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1) AS cp_entprs_std_cst_usd_amt,
secrd_rpt_layer_iss.cp_tot_cst_of_sls_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1) AS cp_tot_cst_of_sls_usd_amt,
secrd_rpt_layer_iss.base_qty*COALESCE(bmt_optnd_up.fnl_rt,1)  AS base_qty,
secrd_rpt_layer_iss.unt_qty*COALESCE(bmt_optnd_up.fnl_rt,1)  AS unt_qty,
secrd_rpt_layer_iss.cp_prft_ctr_cd,
secrd_rpt_layer_iss.ttl_rvn_amt*COALESCE(bmt_optnd_up.fnl_rt,1)  AS ttl_rvn_amt,
secrd_rpt_layer_iss.end_cust_cd,
secrd_rpt_layer_iss.hghr_lvl_itm_no_cd,
bmt_optnd_up.to_eg_ctg,
bmt_optnd_up.fnl_rt,
secrd_rpt_layer_iss.cust_sgm_cd,
secrd_rpt_layer_iss.deal_id,
secrd_rpt_layer_iss.prod_base_id,
secrd_rpt_layer_iss.prod_id,
secrd_rpt_layer_iss.shrt_txt_sls_ord_itm_nm,
secrd_rpt_layer_iss.cust_po_nr,
secrd_rpt_layer_iss.plnd_shp_strt_dt,
secrd_rpt_layer_iss.entrprs_stndrd_cst_grp_curr_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1)  AS entrprs_stndrd_cst_grp_curr_usd_amt,
secrd_rpt_layer_iss.grs_mrgn_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1)  AS grs_mrgn_usd_amt,
secrd_rpt_layer_iss.use_nm,
secrd_rpt_layer_iss.actl_inv_dt,
secrd_rpt_layer_iss.eurofit_flag,
secrd_rpt_layer_iss.prch_agrmnt_nr,
secrd_rpt_layer_iss.sm_actl_gds_mvmt_dt,
secrd_rpt_layer_iss.sld_to_ctry_ky,
secrd_rpt_layer_iss.rfrnc_dcmt_nr,
secrd_rpt_layer_iss.rev_hd_cd
,secrd_rpt_layer_iss.recon_ky_cd
,secrd_rpt_layer_iss.dlvry_id
,secrd_rpt_layer_iss.ord_net_vl_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as ord_net_vl_amt
,secrd_rpt_layer_iss.nt_prc_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as nt_prc_amt
,secrd_rpt_layer_iss.ord_itm_qty*COALESCE(bmt_optnd_up.fnl_rt,1) as ord_itm_qty
,secrd_rpt_layer_iss.nt_prc_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as nt_prc_usd_amt
,secrd_rpt_layer_iss.ord_base_qty*COALESCE(bmt_optnd_up.fnl_rt,1) as ord_base_qty
,secrd_rpt_layer_iss.grs_rvn_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as grs_rvn_amt
,secrd_rpt_layer_iss.grs_rvn_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as grs_rvn_usd_amt
,secrd_rpt_layer_iss.cp_grs_rvn_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as cp_grs_rvn_amt
,secrd_rpt_layer_iss.cp_grs_rvn_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as cp_grs_rvn_usd_amt
,secrd_rpt_layer_iss.ttl_cst_sls_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as ttl_cst_sls_amt
,secrd_rpt_layer_iss.cp_ttl_cst_sls_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as cp_ttl_cst_sls_amt
,secrd_rpt_layer_iss.entrprs_stndrd_cst*COALESCE(bmt_optnd_up.fnl_rt,1) as entrprs_stndrd_cst
,secrd_rpt_layer_iss.entprs_std_cst_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as entprs_std_cst_usd_amt
,secrd_rpt_layer_iss.cp_entrprs_stndrd_cst*COALESCE(bmt_optnd_up.fnl_rt,1) as cp_entrprs_stndrd_cst
,secrd_rpt_layer_iss.actl_qty_dlvrd_stockkeeping_unts*COALESCE(bmt_optnd_up.fnl_rt,1) as actl_qty_dlvrd_stockkeeping_unts
,secrd_rpt_layer_iss.ord_optn_qty*COALESCE(bmt_optnd_up.fnl_rt,1) as ord_optn_qty
,secrd_rpt_layer_iss.ord_ttl_qty*COALESCE(bmt_optnd_up.fnl_rt,1) as ord_ttl_qty
,secrd_rpt_layer_iss.actl_dlvry_dt
,secrd_rpt_layer_iss.bsn_rshp_typ_cd
,secrd_rpt_layer_iss.cp_crss_brdr
,secrd_rpt_layer_iss.cp_estmd_inv_dt_itm
,secrd_rpt_layer_iss.cp_src_end_cust_prty_id
,secrd_rpt_layer_iss.currency_cd_cd
,secrd_rpt_layer_iss.estmd_invc_date_hdr
,secrd_rpt_layer_iss.itm_stts_cd
,secrd_rpt_layer_iss.nt_rvn_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as nt_rvn_amt
,secrd_rpt_layer_iss.nt_rvn_usd_amt*COALESCE(bmt_optnd_up.fnl_rt,1) as nt_rvn_usd_amt
,secrd_rpt_layer_iss.ord_itm_dcmt_curr_cd
,secrd_rpt_layer_iss.ord_prch_cd
,secrd_rpt_layer_iss.rsn_rjctn_quotations_and_sls_orders_cd
,secrd_rpt_layer_iss.prmry_prcg_cndn_cd
,secrd_rpt_layer_iss.cp_sldt_prty_id
from secrd_rpt_iss_lyr_123 as secrd_rpt_layer_iss
left outer join ${dbCommonR2_3UAT}.bmt_ord_ins_dmnsn bmt_ord_ins_dmnsn on bmt_ord_ins_dmnsn.pft_cntr_cd=secrd_rpt_layer_iss.prft_cntr_cd
left outer join ${dbCommonR2_3UAT}.bmt_optnd_up_dmnsn bmt_optnd_up on
bmt_optnd_up.fscl_mnth_cd = secrd_rpt_layer_iss.fscl_yr_prd_cd and
bmt_optnd_up.dsply_cntr_nm = secrd_rpt_layer_iss.ctry_geo_allct_nm and
UPPER(bmt_optnd_up.rt_to_mkt) = UPPER(secrd_rpt_layer_iss.mkt_rte_cd) and
bmt_optnd_up.ctg_lvl_1 = secrd_rpt_layer_iss.cp_optnd_up and
secrd_rpt_layer_iss.cp_optnd_up = 'ISS'
where
secrd_rpt_layer_iss.allc_lyr is null
""")

    val dataLoadISS_layer4 = secrd_rpt_iss_4.select(Utilities.loadSelectExpr(secrd_rpt_iss_4.columns, tgtCol): _*)

    dataLoadISS_layer4.union(dataLoadISS_layer2.filter(col("allc_lyr").isNotNull)).union(dataLoadISS_layer3.filter(col("allc_lyr").isNotNull)).repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblName)

    logger.info("++++++++++++############# ISS Option up Category load data inserted #############++++++++++++")

    logger.info("++++++++++++############# ISS Option up Platform load data started #############++++++++++++")

    // 2020-03-26: added cp_prod_char to group by

    val layer1df = spark.sql(s"""select distinct * from ${tgtTblName} where allc_lyr='Layer 1'""")

    // 2020-05-13: added Lr1 amount and quantity columns
    val layer1dfsum = layer1df.select(col("*")).groupBy("ctry_geo_allct_nm", "fscl_yr_prd_cd", "cp_rtm_nm", "cp_fnl_eg_ctg", "cp_prod_char").
      agg(sum("cp_nt_rvn_usd_amt").as("sum_cp_nt_rvn_usd_amt"), sum("cp_grs_inv_usd_amt").as("sum_cp_grs_inv_usd_amt"),
        sum("ttl_cst_sls_usd_amt").as("sum_ttl_cst_sls_usd_amt"), sum("unt_qty").as("sum_unt_qty"),
        sum("cp_entprs_std_cst_usd_amt").as("sum_cp_entprs_std_cst_usd_amt"), sum("grs_mrgn_usd_amt").as("sum_grs_mrgn_usd_amt"), sum("ttl_rvn_amt").as("sum_ttl_rvn_amt"), sum("cp_nt_rvn_amt").as("sum_cp_nt_rvn_amt"), sum("ord_net_vl_amt").as("sum_ord_net_vl_amt"), sum("nt_prc_amt").as("sum_nt_prc_amt"), sum("ord_itm_qty").as("sum_ord_itm_qty"), sum("nt_prc_usd_amt").as("sum_nt_prc_usd_amt"), sum("ord_base_qty").as("sum_ord_base_qty"), sum("grs_rvn_amt").as("sum_grs_rvn_amt"), sum("grs_rvn_usd_amt").as("sum_grs_rvn_usd_amt"), sum("cp_grs_rvn_amt").as("sum_cp_grs_rvn_amt"), sum("cp_grs_rvn_usd_amt").as("sum_cp_grs_rvn_usd_amt"), sum("ttl_cst_sls_amt").as("sum_ttl_cst_sls_amt"), sum("cp_ttl_cst_sls_amt").as("sum_cp_ttl_cst_sls_amt"), sum("entrprs_stndrd_cst").as("sum_entrprs_stndrd_cst"), sum("entprs_std_cst_usd_amt").as("sum_entprs_std_cst_usd_amt"), sum("cp_entrprs_stndrd_cst").as("sum_cp_entrprs_stndrd_cst"), sum("actl_qty_dlvrd_stockkeeping_unts").as("sum_actl_qty_dlvrd_stockkeeping_unts"), sum("ord_optn_qty").as("sum_ord_optn_qty"), sum("ord_ttl_qty").as("sum_ord_ttl_qty"), sum("nt_rvn_amt").as("sum_nt_rvn_amt"), sum("nt_rvn_usd_amt").as("sum_nt_rvn_usd_amt"))

    // 2020-05-13: added Lr1 amount and quantity columns
    val overAllSum = layer1dfsum.groupBy("ctry_geo_allct_nm", "fscl_yr_prd_cd", "cp_rtm_nm", "cp_fnl_eg_ctg").
      agg(sum("sum_cp_nt_rvn_usd_amt").as("oa_sum_cp_nt_rvn_usd_amt"), sum("sum_cp_grs_inv_usd_amt").as("oa_sum_cp_grs_inv_usd_amt"),
        sum("sum_ttl_cst_sls_usd_amt").as("oa_sum_ttl_cst_sls_usd_amt"), sum("sum_unt_qty").as("oa_sum_unt_qty"),
        sum("sum_cp_entprs_std_cst_usd_amt").as("oa_sum_cp_entprs_std_cst_usd_amt"),
        sum("sum_grs_mrgn_usd_amt").as("oa_sum_grs_mrgn_usd_amt"), sum("sum_ttl_rvn_amt").as("oa_sum_ttl_rvn_amt"), sum("sum_cp_nt_rvn_amt").as("oa_sum_cp_nt_rvn_amt"), sum("sum_ord_net_vl_amt").as("oa_sum_ord_net_vl_amt"), sum("sum_nt_prc_amt").as("oa_sum_nt_prc_amt"), sum("sum_ord_itm_qty").as("oa_sum_ord_itm_qty"), sum("sum_nt_prc_usd_amt").as("oa_sum_nt_prc_usd_amt"), sum("sum_ord_base_qty").as("oa_sum_ord_base_qty"), sum("sum_grs_rvn_amt").as("oa_sum_grs_rvn_amt"), sum("sum_grs_rvn_usd_amt").as("oa_sum_grs_rvn_usd_amt"), sum("sum_cp_grs_rvn_amt").as("oa_sum_cp_grs_rvn_amt"), sum("sum_cp_grs_rvn_usd_amt").as("oa_sum_cp_grs_rvn_usd_amt"), sum("sum_ttl_cst_sls_amt").as("oa_sum_ttl_cst_sls_amt"), sum("sum_cp_ttl_cst_sls_amt").as("oa_sum_cp_ttl_cst_sls_amt"), sum("sum_entrprs_stndrd_cst").as("oa_sum_entrprs_stndrd_cst"), sum("sum_entprs_std_cst_usd_amt").as("oa_sum_entprs_std_cst_usd_amt"), sum("sum_cp_entrprs_stndrd_cst").as("oa_sum_cp_entrprs_stndrd_cst"), sum("sum_actl_qty_dlvrd_stockkeeping_unts").as("oa_sum_actl_qty_dlvrd_stockkeeping_unts"), sum("sum_ord_optn_qty").as("oa_sum_ord_optn_qty"), sum("sum_ord_ttl_qty").as("oa_sum_ord_ttl_qty"), sum("sum_nt_rvn_amt").as("oa_sum_nt_rvn_amt"), sum("sum_nt_rvn_usd_amt").as("oa_sum_nt_rvn_usd_amt"))

    // 2020-05-13: updated
    val layer1dfper = layer1dfsum.alias("l1sum").join(overAllSum.alias("l1"), layer1dfsum("ctry_geo_allct_nm") === layer1df("ctry_geo_allct_nm") && layer1dfsum("fscl_yr_prd_cd") === layer1df("fscl_yr_prd_cd") &&
      layer1dfsum("cp_rtm_nm") === layer1df("cp_rtm_nm") && layer1dfsum("cp_fnl_eg_ctg") === layer1df("cp_fnl_eg_ctg"), "inner").select(
      "l1sum.ctry_geo_allct_nm",
      "l1sum.fscl_yr_prd_cd",
      "l1sum.cp_rtm_nm",
      "l1sum.cp_fnl_eg_ctg",
      "l1sum.cp_prod_char",
      "l1sum.sum_cp_nt_rvn_usd_amt",
      "l1sum.sum_cp_grs_inv_usd_amt",
      "l1sum.sum_ttl_cst_sls_usd_amt",
      "l1sum.sum_unt_qty",
      "l1sum.sum_cp_entprs_std_cst_usd_amt",
      "l1sum.sum_grs_mrgn_usd_amt",
      "l1sum.sum_ttl_rvn_amt",
      "l1sum.sum_cp_nt_rvn_amt",
      "l1sum.sum_nt_rvn_amt",
      "l1sum.sum_nt_rvn_usd_amt",
      "l1.oa_sum_cp_nt_rvn_usd_amt",
      "l1.oa_sum_cp_grs_inv_usd_amt",
      "l1.oa_sum_ttl_cst_sls_usd_amt",
      "l1.oa_sum_unt_qty",
      "l1.oa_sum_ttl_cst_sls_usd_amt",
      "l1.oa_sum_grs_mrgn_usd_amt",
      "l1.oa_sum_ttl_rvn_amt",
      "l1.oa_sum_cp_nt_rvn_amt",
      "l1sum.sum_ord_net_vl_amt",
      "l1sum.sum_nt_prc_amt",
      "l1sum.sum_ord_itm_qty",
      "l1sum.sum_nt_prc_usd_amt",
      "l1sum.sum_ord_base_qty",
      "l1sum.sum_grs_rvn_amt",
      "l1sum.sum_grs_rvn_usd_amt",
      "l1sum.sum_cp_grs_rvn_amt",
      "l1sum.sum_cp_grs_rvn_usd_amt",
      "l1sum.sum_ttl_cst_sls_amt",
      "l1sum.sum_cp_ttl_cst_sls_amt",
      "l1sum.sum_entrprs_stndrd_cst",
      "l1sum.sum_entprs_std_cst_usd_amt",
      "l1sum.sum_cp_entrprs_stndrd_cst",
      "l1sum.sum_actl_qty_dlvrd_stockkeeping_unts",
      "l1sum.sum_ord_optn_qty",
      "l1sum.sum_ord_ttl_qty",
      "l1.oa_sum_ord_net_vl_amt",
      "l1.oa_sum_nt_prc_amt",
      "l1.oa_sum_ord_itm_qty",
      "l1.oa_sum_nt_prc_usd_amt",
      "l1.oa_sum_ord_base_qty",
      "l1.oa_sum_grs_rvn_amt",
      "l1.oa_sum_grs_rvn_usd_amt",
      "l1.oa_sum_cp_grs_rvn_amt",
      "l1.oa_sum_cp_grs_rvn_usd_amt",
      "l1.oa_sum_ttl_cst_sls_amt",
      "l1.oa_sum_cp_ttl_cst_sls_amt",
      "l1.oa_sum_entrprs_stndrd_cst",
      "l1.oa_sum_entprs_std_cst_usd_amt",
      "l1.oa_sum_cp_entrprs_stndrd_cst",
      "l1.oa_sum_actl_qty_dlvrd_stockkeeping_unts",
      "l1.oa_sum_ord_optn_qty",
      "l1.oa_sum_ord_ttl_qty",
      "l1.oa_sum_nt_rvn_amt",
      "l1.oa_sum_nt_rvn_usd_amt",
      "l1.oa_sum_cp_entprs_std_cst_usd_amt")

    // 2020-05-13: updated
    val layer1dfperfinal = layer1dfper.withColumn("percentage_rvn", ((col("sum_cp_nt_rvn_usd_amt") / col("oa_sum_cp_nt_rvn_usd_amt")))).
      withColumn("percentage_grs", ((col("sum_cp_grs_inv_usd_amt") / col("oa_sum_cp_grs_inv_usd_amt")))).
      withColumn("percentage_ttl", ((col("sum_ttl_cst_sls_usd_amt") / col("oa_sum_ttl_cst_sls_usd_amt")))).
      withColumn("percentage_qty", ((col("sum_unt_qty") / col("oa_sum_unt_qty")))).
      withColumn("percentage_entprs", ((col("sum_cp_entprs_std_cst_usd_amt") / col("oa_sum_cp_entprs_std_cst_usd_amt")))).
      withColumn("percentage_mrgn", ((col("sum_grs_mrgn_usd_amt") / col("oa_sum_grs_mrgn_usd_amt")))).
      withColumn("percentage_ttl_rvn", col("sum_ttl_rvn_amt") / col("oa_sum_ttl_rvn_amt")).
      withColumn("percentage_rvn_amt", col("sum_cp_nt_rvn_amt") / col("oa_sum_cp_nt_rvn_amt")).
      withColumn("percentage_net_vl_amt", col("sum_ord_net_vl_amt") / col("oa_sum_ord_net_vl_amt")).
      withColumn("percentage_prc_amt", col("sum_nt_prc_amt") / col("oa_sum_nt_prc_amt")).
      withColumn("percentage_ord_itm_qty", col("sum_ord_itm_qty") / col("oa_sum_ord_itm_qty")).
      withColumn("percentage_nt_prc_usd_amt", col("sum_nt_prc_usd_amt") / col("oa_sum_nt_prc_usd_amt")).
      withColumn("percentage_base_qty", col("sum_ord_base_qty") / col("oa_sum_ord_base_qty")).
      withColumn("percentage_grs_rvn_amt", col("sum_grs_rvn_amt") / col("oa_sum_grs_rvn_amt")).
      withColumn("percentage_grs_rvn_usd_amt", col("sum_grs_rvn_usd_amt") / col("oa_sum_grs_rvn_usd_amt")).
      withColumn("percentage_cp_grs_rvn_amt", col("sum_cp_grs_rvn_amt") / col("oa_sum_cp_grs_rvn_amt")).
      withColumn("percentage_cp_grs_rvn_usd_amt", col("sum_cp_grs_rvn_usd_amt") / col("oa_sum_cp_grs_rvn_usd_amt")).
      withColumn("percentage_ttl_cst_sls_amt", col("sum_ttl_cst_sls_amt") / col("oa_sum_ttl_cst_sls_amt")).
      withColumn("percentage_cp_ttl_cst_sls_amt", col("sum_cp_ttl_cst_sls_amt") / col("oa_sum_cp_ttl_cst_sls_amt")).
      withColumn("percentage_entrprs_stndrd_cst", col("sum_entrprs_stndrd_cst") / col("oa_sum_entrprs_stndrd_cst")).
      withColumn("percentage_entprs_std_cst_usd_amt", col("sum_entprs_std_cst_usd_amt") / col("oa_sum_entprs_std_cst_usd_amt")).
      withColumn("percentage_cp_entrprs_stndrd_cst", col("sum_cp_entrprs_stndrd_cst") / col("oa_sum_cp_entrprs_stndrd_cst")).
      withColumn("percentage_stockkeeping_unts", col("sum_actl_qty_dlvrd_stockkeeping_unts") / col("oa_sum_actl_qty_dlvrd_stockkeeping_unts")).
      withColumn("percentage_optn_qty", col("sum_ord_optn_qty") / col("oa_sum_ord_optn_qty")).
      withColumn("percentage_ttl_qty", col("sum_ord_ttl_qty") / col("oa_sum_ord_ttl_qty")).
      withColumn("percentage_nt", col("sum_nt_rvn_amt") / col("oa_sum_nt_rvn_amt")).
      withColumn("percentage_nt_usd", col("sum_nt_rvn_usd_amt") / col("oa_sum_nt_rvn_usd_amt")).select(col("*"))

    logger.info("++++++++++++############# ISS Option up Platform layer 2 load data started #############++++++++++++")

    val layer2df = spark.sql(s"""select * from ${tgtTblName} where allc_lyr='Layer 2'""").withColumnRenamed("cp_prod_char", "cp_prod_char_orgn")

    val joindf = layer2df.alias("l2").join(layer1dfperfinal.alias("l1"), layer2df("ctry_geo_allct_nm") === layer1dfperfinal("ctry_geo_allct_nm")
      && layer2df("fscl_yr_prd_cd") === layer1dfperfinal("fscl_yr_prd_cd") && layer2df("cp_rtm_nm") === layer1dfperfinal("cp_rtm_nm") &&
      layer2df("cp_fnl_eg_ctg") === layer1dfperfinal("cp_fnl_eg_ctg"), "leftouter").
      selectExpr("l2.*", "case when l1.cp_prod_char is not null and length(l1.cp_prod_char) <> 0 then l1.cp_prod_char when l2.cp_prod_char_orgn is not null and length(l2.cp_prod_char_orgn) <> 0 then l2.cp_prod_char_orgn else 'Other' end as cp_prod_char", "l1.percentage_rvn",
        "l1.percentage_grs", "l1.percentage_ttl", "l1.percentage_qty", "l1.percentage_entprs", "l1.percentage_mrgn",
        "l1.percentage_ttl_rvn", "l1.percentage_rvn_amt", "percentage_net_vl_amt", "percentage_prc_amt", "percentage_ord_itm_qty", "percentage_nt_prc_usd_amt", "percentage_base_qty", "percentage_grs_rvn_amt", "percentage_grs_rvn_usd_amt", "percentage_cp_grs_rvn_amt", "percentage_cp_grs_rvn_usd_amt", "percentage_ttl_cst_sls_amt", "percentage_cp_ttl_cst_sls_amt", "percentage_entrprs_stndrd_cst", "percentage_entprs_std_cst_usd_amt", "percentage_cp_entrprs_stndrd_cst", "percentage_stockkeeping_unts", "percentage_optn_qty", "percentage_ttl_qty", "percentage_nt", "percentage_nt_usd")

    var joindf_final = joindf.withColumn("revenue", col("cp_nt_rvn_usd_amt") * col("percentage_rvn")).
      withColumn("gross", col("cp_grs_inv_usd_amt") * col("percentage_grs")).
      withColumn("ttl_cst", col("ttl_cst_sls_usd_amt") * col("percentage_ttl")).
      withColumn("qty", col("unt_qty") * col("percentage_qty")).
      withColumn("entprs_std", col("cp_entprs_std_cst_usd_amt") * col("percentage_entprs")).
      withColumn("gross_mrgn", col("grs_mrgn_usd_amt") * col("percentage_mrgn")).
      withColumn("total_rvn", col("ttl_rvn_amt") * col("percentage_ttl_rvn")).
      withColumn("revenue_amt", col("cp_nt_rvn_amt") * col("percentage_rvn_amt")).
      withColumn("net_revenue", col("ord_net_vl_amt") * col("percentage_net_vl_amt")).
      withColumn("price_amt", col("nt_prc_amt") * col("percentage_prc_amt")).
      withColumn("item_qty", col("ord_itm_qty") * col("percentage_ord_itm_qty")).
      withColumn("price_usd_amt", col("nt_prc_usd_amt") * col("percentage_nt_prc_usd_amt")).
      withColumn("base_qty", col("ord_base_qty") * col("percentage_base_qty")).
      withColumn("gross_revenue", col("grs_rvn_amt") * col("percentage_grs_rvn_amt")).
      withColumn("gross_revenue_usd", col("grs_rvn_usd_amt") * col("percentage_grs_rvn_usd_amt")).
      withColumn("cp_gross_revenue", col("cp_grs_rvn_amt") * col("percentage_cp_grs_rvn_amt")).
      withColumn("cp_gross_revenue_usd", col("cp_grs_rvn_usd_amt") * col("percentage_cp_grs_rvn_usd_amt")).
      withColumn("total_cost_sls", col("ttl_cst_sls_amt") * col("percentage_ttl_cst_sls_amt")).
      withColumn("cp_total_cost_sls", col("cp_ttl_cst_sls_amt") * col("percentage_cp_ttl_cst_sls_amt")).
      withColumn("entrprs_stnd_cst", col("entrprs_stndrd_cst") * col("percentage_entrprs_stndrd_cst")).
      withColumn("entrprs_stnd_usd_cst", col("entprs_std_cst_usd_amt") * col("percentage_entprs_std_cst_usd_amt")).
      withColumn("cp_entrprs_stnd_cst", col("cp_entrprs_stndrd_cst") * col("percentage_cp_entrprs_stndrd_cst")).
      withColumn("actl_qty_dlvrd", col("actl_qty_dlvrd_stockkeeping_unts") * col("percentage_stockkeeping_unts")).
      withColumn("optn_qty", col("ord_optn_qty") * col("percentage_optn_qty")).
      withColumn("ttl_qty", col("ord_ttl_qty") * col("percentage_ttl_qty")).
      withColumn("net", col("nt_rvn_amt") * col("percentage_nt")).
      withColumn("net_usd", col("nt_rvn_usd_amt") * col("percentage_nt_usd")).select(col("*"))

    var joindf_final1 = joindf_final.select(
      col("*"),
      expr("case when revenue is null then cp_nt_rvn_usd_amt " + "else revenue end ").alias("final_revenue"),
      expr("case when gross is null then cp_grs_inv_usd_amt " + "else gross end ").alias("final_gross"),
      expr("case when ttl_cst is null then ttl_cst_sls_usd_amt " + "else ttl_cst end ").alias("final_ttl_cst"),
      expr("case when qty is null then unt_qty " + "else qty end ").alias("final_qty"),
      expr("case when entprs_std is null then cp_entprs_std_cst_usd_amt " + "else entprs_std end ").alias("final_entprs_std"),
      expr("case when gross_mrgn is null then grs_mrgn_usd_amt " + "else gross_mrgn end ").alias("final_gross_mrgn"),
      expr("case when total_rvn is null then ttl_rvn_amt " + "else total_rvn end").alias("final_total_rvn"),
      expr("case when revenue_amt is null then cp_nt_rvn_amt " + "else revenue_amt end").alias("final_revenue_amt"),
      expr("case when net_revenue is null then ord_net_vl_amt " + "else net_revenue end").alias("final_ord_net_vl_amt"),
      expr("case when price_amt is null then nt_prc_amt " + "else price_amt end").alias("final_nt_prc_amt"),
      expr("case when item_qty is null then ord_itm_qty " + "else item_qty end").alias("final_ord_itm_qty"),
      expr("case when price_usd_amt is null then nt_prc_usd_amt " + "else price_usd_amt end").alias("final_nt_prc_usd_amt"),
      expr("case when base_qty is null then ord_base_qty " + "else base_qty end").alias("final_ord_base_qty"),
      expr("case when gross_revenue is null then grs_rvn_amt " + "else gross_revenue end").alias("final_grs_rvn_amt"),
      expr("case when gross_revenue_usd is null then grs_rvn_usd_amt " + "else gross_revenue_usd end").alias("final_grs_rvn_usd_amt"),
      expr("case when cp_gross_revenue is null then cp_grs_rvn_amt " + "else cp_gross_revenue end").alias("final_cp_grs_rvn_amt"),
      expr("case when cp_gross_revenue_usd is null then cp_grs_rvn_usd_amt " + "else cp_gross_revenue_usd end").alias("final_cp_grs_rvn_usd_amt"),
      expr("case when total_cost_sls is null then ttl_cst_sls_amt " + "else total_cost_sls end").alias("final_rttl_cst_sls_amt"),
      expr("case when cp_total_cost_sls is null then cp_ttl_cst_sls_amt " + "else cp_total_cost_sls end").alias("final_cp_ttl_cst_sls_amt"),
      expr("case when entrprs_stnd_cst is null then entrprs_stndrd_cst " + "else entrprs_stnd_cst end").alias("final_entrprs_stndrd_cst"),
      expr("case when entrprs_stnd_usd_cst is null then entprs_std_cst_usd_amt " + "else entrprs_stnd_usd_cst end").alias("final_entprs_std_cst_usd_amt"),
      expr("case when cp_entrprs_stnd_cst is null then cp_entrprs_stndrd_cst " + "else cp_entrprs_stnd_cst end").alias("final_cp_entrprs_stndrd_cst"),
      expr("case when actl_qty_dlvrd is null then actl_qty_dlvrd_stockkeeping_unts " + "else actl_qty_dlvrd end").alias("final_actl_qty_dlvrd_stockkeeping_unts"),
      expr("case when optn_qty is null then ord_optn_qty " + "else optn_qty end").alias("final_ord_optn_qty"),
      expr("case when ttl_qty is null then ord_ttl_qty " + "else ttl_qty end").alias("final_ord_ttl_qty"),
      expr("case when net is null then nt_rvn_amt " + "else net end").alias("final_nt_rvn_amt"),
      expr("case when net_usd is null then nt_rvn_usd_amt " + "else net_usd end").alias("final_nt_rvn_usd_amt"))

    joindf_final1 = joindf_final1.drop("cp_nt_rvn_usd_amt", "cp_grs_inv_usd_amt", "ttl_cst_sls_usd_amt", "unt_qty",
      "cp_entprs_std_cst_usd_amt", "grs_mrgn_usd_amt", "ord_net_vl_amt", "ord_itm_qty", "nt_prc_amt", "nt_prc_usd_amt", "ord_base_qty", "grs_rvn_amt", "grs_rvn_usd_amt", "cp_grs_rvn_amt", "cp_grs_rvn_usd_amt", "ttl_cst_sls_amt", "cp_ttl_cst_sls_amt", "entrprs_stndrd_cst", "entprs_std_cst_usd_amt", "cp_entrprs_stndrd_cst", "actl_qty_dlvrd_stockkeeping_unts", "ord_optn_qty", "ord_ttl_qty", "percentage_rvn", "percentage_grs", "percentage_ttl", "percentage_qty", "percentage_entprs", "percentage_mrgn", "revenue", "gross", "ttl_cst", "qty", "entprs_std", "gross_mrgn", "ttl_rvn_amt", "cp_nt_rvn_amt", "total_rvn", "revenue_amt", "net_revenue", "price_amt", "item_qty", "price_usd_amt", "base_qty", "gross_revenue", "gross_revenue_usd", "cp_gross_revenue", "cp_gross_revenue_usd", "total_cost_sls", "cp_total_cost_sls", "entrprs_stnd_cst", "entrprs_stnd_usd_cst", "cp_entrprs_stnd_cst", "actl_qty_dlvrd", "optn_qty", "ttl_qty", "nt_rvn_amt", "nt_rvn_usd_amt").withColumnRenamed("final_revenue", "cp_nt_rvn_usd_amt").withColumnRenamed("final_gross", "cp_grs_inv_usd_amt").withColumnRenamed("final_ttl_cst", "ttl_cst_sls_usd_amt").withColumnRenamed("final_qty", "unt_qty").
      withColumnRenamed("final_entprs_std", "cp_entprs_std_cst_usd_amt").withColumnRenamed("final_gross_mrgn", "grs_mrgn_usd_amt").
      withColumnRenamed("final_total_rvn", "ttl_rvn_amt").withColumnRenamed("final_revenue_amt", "cp_nt_rvn_amt").
      withColumnRenamed("final_ord_net_vl_amt", "ord_net_vl_amt").withColumnRenamed("final_nt_prc_amt", "nt_prc_amt").
      withColumnRenamed("final_ord_itm_qty", "ord_itm_qty").withColumnRenamed("final_nt_prc_usd_amt", "nt_prc_usd_amt").
      withColumnRenamed("final_ord_base_qty", "ord_base_qty").withColumnRenamed("final_grs_rvn_amt", "grs_rvn_amt").
      withColumnRenamed("final_grs_rvn_usd_amt", "grs_rvn_usd_amt").withColumnRenamed("final_cp_grs_rvn_amt", "cp_grs_rvn_amt").
      withColumnRenamed("final_cp_grs_rvn_usd_amt", "cp_grs_rvn_usd_amt").withColumnRenamed("final_rttl_cst_sls_amt", "ttl_cst_sls_amt").
      withColumnRenamed("final_cp_ttl_cst_sls_amt", "cp_ttl_cst_sls_amt").withColumnRenamed("final_entrprs_stndrd_cst", "entrprs_stndrd_cst").
      withColumnRenamed("final_entprs_std_cst_usd_amt", "entprs_std_cst_usd_amt").withColumnRenamed("final_cp_entrprs_stndrd_cst", "cp_entrprs_stndrd_cst").
      withColumnRenamed("final_actl_qty_dlvrd_stockkeeping_unts", "actl_qty_dlvrd_stockkeeping_unts").withColumnRenamed("final_ord_optn_qty", "ord_optn_qty").
      withColumnRenamed("final_ord_ttl_qty", "ord_ttl_qty").
      withColumnRenamed("final_nt_rvn_amt", "nt_rvn_amt").
      withColumnRenamed("final_nt_rvn_usd_amt", "nt_rvn_usd_amt")

    logger.info("++++++++++++############# ISS Option up Platform layer 3 load data started #############++++++++++++")

    val layer3df = spark.sql(s"""select * from ${tgtTblName} where allc_lyr='Layer 3'""").withColumnRenamed("cp_prod_char", "cp_prod_char_orgn")

    val joindfl3 = layer3df.alias("l3").join(layer1dfperfinal.alias("l1"), layer3df("ctry_geo_allct_nm") === layer1dfperfinal("ctry_geo_allct_nm") && layer3df("fscl_yr_prd_cd") === layer1dfperfinal("fscl_yr_prd_cd") && layer3df("cp_rtm_nm") === layer1dfperfinal("cp_rtm_nm") &&
      layer3df("cp_fnl_eg_ctg") === layer1dfperfinal("cp_fnl_eg_ctg"), "leftouter").selectExpr(
      "l3.*", "case when l1.cp_prod_char is not null and length(l1.cp_prod_char) <> 0 then l1.cp_prod_char when l3.cp_prod_char_orgn is not null and length(l3.cp_prod_char_orgn) <> 0 then l3.cp_prod_char_orgn else 'Other' end as cp_prod_char",
      "l1.percentage_rvn", "l1.percentage_grs", "l1.percentage_ttl", "l1.percentage_qty", "l1.percentage_entprs",
      "l1.percentage_mrgn", "l1.percentage_ttl_rvn", "l1.percentage_rvn_amt", "percentage_net_vl_amt", "percentage_prc_amt", "percentage_ord_itm_qty", "percentage_nt_prc_usd_amt", "percentage_base_qty", "percentage_grs_rvn_amt", "percentage_grs_rvn_usd_amt", "percentage_cp_grs_rvn_amt", "percentage_cp_grs_rvn_usd_amt", "percentage_ttl_cst_sls_amt", "percentage_cp_ttl_cst_sls_amt", "percentage_entrprs_stndrd_cst", "percentage_entprs_std_cst_usd_amt", "percentage_cp_entrprs_stndrd_cst", "percentage_stockkeeping_unts", "percentage_optn_qty", "percentage_ttl_qty", "percentage_nt", "percentage_nt_usd")

    var joindf_finall3 = joindfl3.withColumn("revenue", col("cp_nt_rvn_usd_amt") * col("percentage_rvn")).
      withColumn("gross", col("cp_grs_inv_usd_amt") * col("percentage_grs")).
      withColumn("ttl_cst", col("ttl_cst_sls_usd_amt") * col("percentage_ttl")).withColumn("qty", col("unt_qty") * col("percentage_qty")).
      withColumn("entprs_std", col("cp_entprs_std_cst_usd_amt") * col("percentage_entprs")).
      withColumn("gross_mrgn", col("grs_mrgn_usd_amt") * col("percentage_mrgn")).
      withColumn("total_rvn", col("ttl_rvn_amt") * col("percentage_ttl_rvn")).
      withColumn("revenue_amt", col("cp_nt_rvn_amt") * col("percentage_rvn_amt")).
      withColumn("net_revenue", col("ord_net_vl_amt") * col("percentage_net_vl_amt")).
      withColumn("price_amt", col("nt_prc_amt") * col("percentage_prc_amt")).
      withColumn("item_qty", col("ord_itm_qty") * col("percentage_ord_itm_qty")).
      withColumn("price_usd_amt", col("nt_prc_usd_amt") * col("percentage_nt_prc_usd_amt")).
      withColumn("base_qty", col("ord_base_qty") * col("percentage_base_qty")).
      withColumn("gross_revenue", col("grs_rvn_amt") * col("percentage_grs_rvn_amt")).
      withColumn("gross_revenue_usd", col("grs_rvn_usd_amt") * col("percentage_grs_rvn_usd_amt")).
      withColumn("cp_gross_revenue", col("cp_grs_rvn_amt") * col("percentage_cp_grs_rvn_amt")).
      withColumn("cp_gross_revenue_usd", col("cp_grs_rvn_usd_amt") * col("percentage_cp_grs_rvn_usd_amt")).
      withColumn("total_cost_sls", col("ttl_cst_sls_amt") * col("percentage_ttl_cst_sls_amt")).
      withColumn("cp_total_cost_sls", col("cp_ttl_cst_sls_amt") * col("percentage_cp_ttl_cst_sls_amt")).
      withColumn("entrprs_stnd_cst", col("entrprs_stndrd_cst") * col("percentage_entrprs_stndrd_cst")).
      withColumn("entrprs_stnd_usd_cst", col("entprs_std_cst_usd_amt") * col("percentage_entprs_std_cst_usd_amt")).
      withColumn("cp_entrprs_stnd_cst", col("cp_entrprs_stndrd_cst") * col("percentage_cp_entrprs_stndrd_cst")).
      withColumn("actl_qty_dlvrd", col("actl_qty_dlvrd_stockkeeping_unts") * col("percentage_stockkeeping_unts")).
      withColumn("optn_qty", col("ord_optn_qty") * col("percentage_optn_qty")).
      withColumn("ttl_qty", col("ord_ttl_qty") * col("percentage_ttl_qty")).
      withColumn("net", col("nt_rvn_amt") * col("percentage_nt")).
      withColumn("net_usd", col("nt_rvn_usd_amt") * col("percentage_nt_usd")).select(col("*"))

    var joindf_final13 = joindf_finall3.select(
      col("*"),
      expr("case when revenue is null then cp_nt_rvn_usd_amt " + "else revenue end ").alias("final_revenue"),
      expr("case when gross is null then cp_grs_inv_usd_amt " + "else gross end ").alias("final_gross"),
      expr("case when ttl_cst is null then ttl_cst_sls_usd_amt " + "else ttl_cst end ").alias("final_ttl_cst"),
      expr("case when qty is null then unt_qty " + "else qty end ").alias("final_qty"),
      expr("case when entprs_std is null then cp_entprs_std_cst_usd_amt " + "else entprs_std end ").alias("final_entprs_std"),
      expr("case when gross_mrgn is null then grs_mrgn_usd_amt " + "else gross_mrgn end ").alias("final_gross_mrgn"),
      expr("case when total_rvn is null then ttl_rvn_amt " + "else total_rvn end").alias("final_total_rvn"),
      expr("case when revenue_amt is null then cp_nt_rvn_amt " + "else revenue_amt end").alias("final_revenue_amt"),
      expr("case when net_revenue is null then ord_net_vl_amt " + "else net_revenue end").alias("final_ord_net_vl_amt"),
      expr("case when price_amt is null then nt_prc_amt " + "else price_amt end").alias("final_nt_prc_amt"),
      expr("case when item_qty is null then ord_itm_qty " + "else item_qty end").alias("final_ord_itm_qty"),
      expr("case when price_usd_amt is null then nt_prc_usd_amt " + "else price_usd_amt end").alias("final_nt_prc_usd_amt"),
      expr("case when base_qty is null then ord_base_qty " + "else base_qty end").alias("final_ord_base_qty"),
      expr("case when gross_revenue is null then grs_rvn_amt " + "else gross_revenue end").alias("final_grs_rvn_amt"),
      expr("case when gross_revenue_usd is null then grs_rvn_usd_amt " + "else gross_revenue_usd end").alias("final_grs_rvn_usd_amt"),
      expr("case when cp_gross_revenue is null then cp_grs_rvn_amt " + "else cp_gross_revenue end").alias("final_cp_grs_rvn_amt"),
      expr("case when cp_gross_revenue_usd is null then cp_grs_rvn_usd_amt " + "else cp_gross_revenue_usd end").alias("final_cp_grs_rvn_usd_amt"),
      expr("case when total_cost_sls is null then ttl_cst_sls_amt " + "else total_cost_sls end").alias("final_rttl_cst_sls_amt"),
      expr("case when cp_total_cost_sls is null then cp_ttl_cst_sls_amt " + "else cp_total_cost_sls end").alias("final_cp_ttl_cst_sls_amt"),
      expr("case when entrprs_stnd_cst is null then entrprs_stndrd_cst " + "else entrprs_stnd_cst end").alias("final_entrprs_stndrd_cst"),
      expr("case when entrprs_stnd_usd_cst is null then entprs_std_cst_usd_amt " + "else entrprs_stnd_usd_cst end").alias("final_entprs_std_cst_usd_amt"),
      expr("case when cp_entrprs_stnd_cst is null then cp_entrprs_stndrd_cst " + "else cp_entrprs_stnd_cst end").alias("final_cp_entrprs_stndrd_cst"),
      expr("case when actl_qty_dlvrd is null then actl_qty_dlvrd_stockkeeping_unts " + "else actl_qty_dlvrd end").alias("final_actl_qty_dlvrd_stockkeeping_unts"),
      expr("case when optn_qty is null then ord_optn_qty " + "else optn_qty end").alias("final_ord_optn_qty"),
      expr("case when ttl_qty is null then ord_ttl_qty " + "else ttl_qty end").alias("final_ord_ttl_qty"),
      expr("case when net is null then nt_rvn_amt " + "else net end").alias("final_nt_rvn_amt"),
      expr("case when net_usd is null then nt_rvn_usd_amt " + "else net_usd end").alias("final_nt_rvn_usd_amt"))

    joindf_final13 = joindf_final13.drop("cp_nt_rvn_usd_amt", "cp_grs_inv_usd_amt", "ttl_cst_sls_usd_amt", "unt_qty",
      "cp_entprs_std_cst_usd_amt", "grs_mrgn_usd_amt", "ord_net_vl_amt", "ord_itm_qty", "nt_prc_amt", "nt_prc_usd_amt", "ord_base_qty", "grs_rvn_amt", "grs_rvn_usd_amt", "cp_grs_rvn_amt", "cp_grs_rvn_usd_amt", "ttl_cst_sls_amt", "cp_ttl_cst_sls_amt", "entrprs_stndrd_cst", "entprs_std_cst_usd_amt", "cp_entrprs_stndrd_cst", "actl_qty_dlvrd_stockkeeping_unts", "ord_optn_qty", "ord_ttl_qty", "percentage_rvn", "percentage_grs", "percentage_ttl", "percentage_qty", "percentage_entprs", "percentage_mrgn", "revenue", "gross", "ttl_cst", "qty", "entprs_std", "gross_mrgn", "ttl_rvn_amt", "cp_nt_rvn_amt", "total_rvn", "revenue_amt", "net_revenue", "price_amt", "item_qty", "price_usd_amt", "base_qty", "gross_revenue", "gross_revenue_usd", "cp_gross_revenue", "cp_gross_revenue_usd", "total_cost_sls", "cp_total_cost_sls", "entrprs_stnd_cst", "entrprs_stnd_usd_cst", "cp_entrprs_stnd_cst", "actl_qty_dlvrd", "optn_qty", "ttl_qty", "nt_rvn_amt", "nt_rvn_usd_amt").withColumnRenamed("final_revenue", "cp_nt_rvn_usd_amt").withColumnRenamed("final_gross", "cp_grs_inv_usd_amt").withColumnRenamed("final_ttl_cst", "ttl_cst_sls_usd_amt").withColumnRenamed("final_qty", "unt_qty").
      withColumnRenamed("final_entprs_std", "cp_entprs_std_cst_usd_amt").withColumnRenamed("final_gross_mrgn", "grs_mrgn_usd_amt").
      withColumnRenamed("final_total_rvn", "ttl_rvn_amt").withColumnRenamed("final_revenue_amt", "cp_nt_rvn_amt").
      withColumnRenamed("final_ord_net_vl_amt", "ord_net_vl_amt").withColumnRenamed("final_nt_prc_amt", "nt_prc_amt").
      withColumnRenamed("final_ord_itm_qty", "ord_itm_qty").withColumnRenamed("final_nt_prc_usd_amt", "nt_prc_usd_amt").
      withColumnRenamed("final_ord_base_qty", "ord_base_qty").withColumnRenamed("final_grs_rvn_amt", "grs_rvn_amt").
      withColumnRenamed("final_grs_rvn_usd_amt", "grs_rvn_usd_amt").withColumnRenamed("final_cp_grs_rvn_amt", "cp_grs_rvn_amt").
      withColumnRenamed("final_cp_grs_rvn_usd_amt", "cp_grs_rvn_usd_amt").withColumnRenamed("final_rttl_cst_sls_amt", "ttl_cst_sls_amt").
      withColumnRenamed("final_cp_ttl_cst_sls_amt", "cp_ttl_cst_sls_amt").withColumnRenamed("final_entrprs_stndrd_cst", "entrprs_stndrd_cst").
      withColumnRenamed("final_entprs_std_cst_usd_amt", "entprs_std_cst_usd_amt").withColumnRenamed("final_cp_entrprs_stndrd_cst", "cp_entrprs_stndrd_cst").
      withColumnRenamed("final_actl_qty_dlvrd_stockkeeping_unts", "actl_qty_dlvrd_stockkeeping_unts").withColumnRenamed("final_ord_optn_qty", "ord_optn_qty").
      withColumnRenamed("final_ord_ttl_qty", "ord_ttl_qty").
      withColumnRenamed("final_nt_rvn_amt", "nt_rvn_amt").
      withColumnRenamed("final_nt_rvn_usd_amt", "nt_rvn_usd_amt")

    logger.info("++++++++++++############# ISS Option up Platform layer 4 load data started #############++++++++++++")

    val layer4df = spark.sql(s"""select * from ${tgtTblName} where allc_lyr='Layer 4'""").withColumnRenamed("cp_prod_char", "cp_prod_char_orgn")

    val joindfl4 = layer4df.alias("l3").join(layer1dfperfinal.alias("l1"), layer4df("ctry_geo_allct_nm") === layer1dfperfinal("ctry_geo_allct_nm") && layer4df("fscl_yr_prd_cd") === layer1dfperfinal("fscl_yr_prd_cd") && layer4df("cp_rtm_nm") === layer1dfperfinal("cp_rtm_nm") &&
      layer4df("cp_fnl_eg_ctg") === layer1dfperfinal("cp_fnl_eg_ctg"), "leftouter").
      selectExpr("l3.*", "case when l1.cp_prod_char is not null and length(l1.cp_prod_char) <> 0 then l1.cp_prod_char when l3.cp_prod_char_orgn is not null and length(l3.cp_prod_char_orgn) <> 0 then l3.cp_prod_char_orgn else 'Other' end as cp_prod_char", "l1.percentage_rvn",
        "l1.percentage_grs", "l1.percentage_ttl", "l1.percentage_qty", "l1.percentage_entprs", "l1.percentage_mrgn",
        "l1.percentage_ttl_rvn", "l1.percentage_rvn_amt", "percentage_net_vl_amt", "percentage_prc_amt", "percentage_ord_itm_qty", "percentage_nt_prc_usd_amt", "percentage_base_qty", "percentage_grs_rvn_amt", "percentage_grs_rvn_usd_amt", "percentage_cp_grs_rvn_amt", "percentage_cp_grs_rvn_usd_amt", "percentage_ttl_cst_sls_amt", "percentage_cp_ttl_cst_sls_amt", "percentage_entrprs_stndrd_cst", "percentage_entprs_std_cst_usd_amt", "percentage_cp_entrprs_stndrd_cst", "percentage_stockkeeping_unts", "percentage_optn_qty", "percentage_ttl_qty", "percentage_nt", "percentage_nt_usd")

    var joindf_finall4 = joindfl4.withColumn("revenue", col("cp_nt_rvn_usd_amt") * col("percentage_rvn")).
      withColumn("gross", col("cp_grs_inv_usd_amt") * col("percentage_grs")).
      withColumn("ttl_cst", col("ttl_cst_sls_usd_amt") * col("percentage_ttl")).
      withColumn("qty", col("unt_qty") * col("percentage_qty")).
      withColumn("entprs_std", col("cp_entprs_std_cst_usd_amt") * col("percentage_entprs")).
      withColumn("gross_mrgn", col("grs_mrgn_usd_amt") * col("percentage_mrgn")).
      withColumn("total_rvn", col("ttl_rvn_amt") * col("percentage_ttl_rvn")).
      withColumn("revenue_amt", col("cp_nt_rvn_amt") * col("percentage_rvn_amt")).
      withColumn("net_revenue", col("ord_net_vl_amt") * col("percentage_net_vl_amt")).
      withColumn("price_amt", col("nt_prc_amt") * col("percentage_prc_amt")).
      withColumn("item_qty", col("ord_itm_qty") * col("percentage_ord_itm_qty")).
      withColumn("price_usd_amt", col("nt_prc_usd_amt") * col("percentage_nt_prc_usd_amt")).
      withColumn("base_qty", col("ord_base_qty") * col("percentage_base_qty")).
      withColumn("gross_revenue", col("grs_rvn_amt") * col("percentage_grs_rvn_amt")).
      withColumn("gross_revenue_usd", col("grs_rvn_usd_amt") * col("percentage_grs_rvn_usd_amt")).
      withColumn("cp_gross_revenue", col("cp_grs_rvn_amt") * col("percentage_cp_grs_rvn_amt")).
      withColumn("cp_gross_revenue_usd", col("cp_grs_rvn_usd_amt") * col("percentage_cp_grs_rvn_usd_amt")).
      withColumn("total_cost_sls", col("ttl_cst_sls_amt") * col("percentage_ttl_cst_sls_amt")).
      withColumn("cp_total_cost_sls", col("cp_ttl_cst_sls_amt") * col("percentage_cp_ttl_cst_sls_amt")).
      withColumn("entrprs_stnd_cst", col("entrprs_stndrd_cst") * col("percentage_entrprs_stndrd_cst")).
      withColumn("entrprs_stnd_usd_cst", col("entprs_std_cst_usd_amt") * col("percentage_entprs_std_cst_usd_amt")).
      withColumn("cp_entrprs_stnd_cst", col("cp_entrprs_stndrd_cst") * col("percentage_cp_entrprs_stndrd_cst")).
      withColumn("actl_qty_dlvrd", col("actl_qty_dlvrd_stockkeeping_unts") * col("percentage_stockkeeping_unts")).
      withColumn("optn_qty", col("ord_optn_qty") * col("percentage_optn_qty")).
      withColumn("ttl_qty", col("ord_ttl_qty") * col("percentage_ttl_qty")).
      withColumn("net", col("nt_rvn_amt") * col("percentage_nt")).
      withColumn("net_usd", col("nt_rvn_usd_amt") * col("percentage_nt_usd")).select(col("*"))

    var joindf_final14 = joindf_finall4.select(
      col("*"),
      expr("case when revenue is null then cp_nt_rvn_usd_amt " + "else revenue end ").alias("final_revenue"),
      expr("case when gross is null then cp_grs_inv_usd_amt " + "else gross end ").alias("final_gross"),
      expr("case when ttl_cst is null then ttl_cst_sls_usd_amt " + "else ttl_cst end ").alias("final_ttl_cst"),
      expr("case when qty is null then unt_qty " + "else qty end ").alias("final_qty"),
      expr("case when entprs_std is null then cp_entprs_std_cst_usd_amt " + "else entprs_std end ").alias("final_entprs_std"),
      expr("case when gross_mrgn is null then grs_mrgn_usd_amt " + "else gross_mrgn end ").alias("final_gross_mrgn"),
      expr("case when total_rvn is null then ttl_rvn_amt " + "else total_rvn end").alias("final_total_rvn"),
      expr("case when revenue_amt is null then cp_nt_rvn_amt " + "else revenue_amt end").alias("final_revenue_amt"),
      expr("case when net_revenue is null then ord_net_vl_amt " + "else net_revenue end").alias("final_ord_net_vl_amt"),
      expr("case when price_amt is null then nt_prc_amt " + "else price_amt end").alias("final_nt_prc_amt"),
      expr("case when item_qty is null then ord_itm_qty " + "else item_qty end").alias("final_ord_itm_qty"),
      expr("case when price_usd_amt is null then nt_prc_usd_amt " + "else price_usd_amt end").alias("final_nt_prc_usd_amt"),
      expr("case when base_qty is null then ord_base_qty " + "else base_qty end").alias("final_ord_base_qty"),
      expr("case when gross_revenue is null then grs_rvn_amt " + "else gross_revenue end").alias("final_grs_rvn_amt"),
      expr("case when gross_revenue_usd is null then grs_rvn_usd_amt " + "else gross_revenue_usd end").alias("final_grs_rvn_usd_amt"),
      expr("case when cp_gross_revenue is null then cp_grs_rvn_amt " + "else cp_gross_revenue end").alias("final_cp_grs_rvn_amt"),
      expr("case when cp_gross_revenue_usd is null then cp_grs_rvn_usd_amt " + "else cp_gross_revenue_usd end").alias("final_cp_grs_rvn_usd_amt"),
      expr("case when total_cost_sls is null then ttl_cst_sls_amt " + "else total_cost_sls end").alias("final_rttl_cst_sls_amt"),
      expr("case when cp_total_cost_sls is null then cp_ttl_cst_sls_amt " + "else cp_total_cost_sls end").alias("final_cp_ttl_cst_sls_amt"),
      expr("case when entrprs_stnd_cst is null then entrprs_stndrd_cst " + "else entrprs_stnd_cst end").alias("final_entrprs_stndrd_cst"),
      expr("case when entrprs_stnd_usd_cst is null then entprs_std_cst_usd_amt " + "else entrprs_stnd_usd_cst end").alias("final_entprs_std_cst_usd_amt"),
      expr("case when cp_entrprs_stnd_cst is null then cp_entrprs_stndrd_cst " + "else cp_entrprs_stnd_cst end").alias("final_cp_entrprs_stndrd_cst"),
      expr("case when actl_qty_dlvrd is null then actl_qty_dlvrd_stockkeeping_unts " + "else actl_qty_dlvrd end").alias("final_actl_qty_dlvrd_stockkeeping_unts"),
      expr("case when optn_qty is null then ord_optn_qty " + "else optn_qty end").alias("final_ord_optn_qty"),
      expr("case when ttl_qty is null then ord_ttl_qty " + "else ttl_qty end").alias("final_ord_ttl_qty"),
      expr("case when net is null then nt_rvn_amt " + "else net end").alias("final_nt_rvn_amt"),
      expr("case when net_usd is null then nt_rvn_usd_amt " + "else net_usd end").alias("final_nt_rvn_usd_amt"))

    joindf_final14 = joindf_final14.drop("cp_nt_rvn_usd_amt", "cp_grs_inv_usd_amt", "ttl_cst_sls_usd_amt", "unt_qty",
      "cp_entprs_std_cst_usd_amt", "grs_mrgn_usd_amt", "ord_net_vl_amt", "ord_itm_qty", "nt_prc_amt", "nt_prc_usd_amt", "ord_base_qty", "grs_rvn_amt", "grs_rvn_usd_amt", "cp_grs_rvn_amt", "cp_grs_rvn_usd_amt", "ttl_cst_sls_amt", "cp_ttl_cst_sls_amt", "entrprs_stndrd_cst", "entprs_std_cst_usd_amt", "cp_entrprs_stndrd_cst", "actl_qty_dlvrd_stockkeeping_unts", "ord_optn_qty", "ord_ttl_qty", "percentage_rvn", "percentage_grs", "percentage_ttl", "percentage_qty", "percentage_entprs", "percentage_mrgn", "revenue", "gross", "ttl_cst", "qty", "entprs_std", "gross_mrgn", "ttl_rvn_amt", "cp_nt_rvn_amt", "total_rvn", "revenue_amt", "net_revenue", "price_amt", "item_qty", "price_usd_amt", "base_qty", "gross_revenue", "gross_revenue_usd", "cp_gross_revenue", "cp_gross_revenue_usd", "total_cost_sls", "cp_total_cost_sls", "entrprs_stnd_cst", "entrprs_stnd_usd_cst", "cp_entrprs_stnd_cst", "actl_qty_dlvrd", "optn_qty", "ttl_qty", "nt_rvn_amt", "nt_rvn_usd_amt").withColumnRenamed("final_revenue", "cp_nt_rvn_usd_amt").withColumnRenamed("final_gross", "cp_grs_inv_usd_amt").withColumnRenamed("final_ttl_cst", "ttl_cst_sls_usd_amt").withColumnRenamed("final_qty", "unt_qty").
      withColumnRenamed("final_entprs_std", "cp_entprs_std_cst_usd_amt").withColumnRenamed("final_gross_mrgn", "grs_mrgn_usd_amt").
      withColumnRenamed("final_total_rvn", "ttl_rvn_amt").withColumnRenamed("final_revenue_amt", "cp_nt_rvn_amt").
      withColumnRenamed("final_ord_net_vl_amt", "ord_net_vl_amt").withColumnRenamed("final_nt_prc_amt", "nt_prc_amt").
      withColumnRenamed("final_ord_itm_qty", "ord_itm_qty").withColumnRenamed("final_nt_prc_usd_amt", "nt_prc_usd_amt").
      withColumnRenamed("final_ord_base_qty", "ord_base_qty").withColumnRenamed("final_grs_rvn_amt", "grs_rvn_amt").
      withColumnRenamed("final_grs_rvn_usd_amt", "grs_rvn_usd_amt").withColumnRenamed("final_cp_grs_rvn_amt", "cp_grs_rvn_amt").
      withColumnRenamed("final_cp_grs_rvn_usd_amt", "cp_grs_rvn_usd_amt").withColumnRenamed("final_rttl_cst_sls_amt", "ttl_cst_sls_amt").
      withColumnRenamed("final_cp_ttl_cst_sls_amt", "cp_ttl_cst_sls_amt").withColumnRenamed("final_entrprs_stndrd_cst", "entrprs_stndrd_cst").
      withColumnRenamed("final_entprs_std_cst_usd_amt", "entprs_std_cst_usd_amt").withColumnRenamed("final_cp_entrprs_stndrd_cst", "cp_entrprs_stndrd_cst").
      withColumnRenamed("final_actl_qty_dlvrd_stockkeeping_unts", "actl_qty_dlvrd_stockkeeping_unts").withColumnRenamed("final_ord_optn_qty", "ord_optn_qty").
      withColumnRenamed("final_ord_ttl_qty", "ord_ttl_qty").
      withColumnRenamed("final_nt_rvn_amt", "nt_rvn_amt").
      withColumnRenamed("final_nt_rvn_usd_amt", "nt_rvn_usd_amt")

    val tgtColumns = spark.sql(s"select * from ${tgtTblName} limit 0").columns

    // 2020-03-26: added
    val dataLoadFactDF = layer1df.union(joindf_final1.select(Utilities.loadSelectExpr(joindf_final1.columns, tgtColumns): _*)).
      union(joindf_final13.select(Utilities.loadSelectExpr(joindf_final13.columns, tgtColumns): _*)).
      union(joindf_final14.select(Utilities.loadSelectExpr(joindf_final14.columns, tgtColumns): _*)).
      union(spark.sql(s"select * from ${tgtTblName} where allc_lyr is null"))

    dataLoadFactDF.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblName)

    val tgtCount = spark.sql(s"select * from ${tgtTblName}").count.toLong

    tgtCount match {
      case 0 =>
        logger.info("//************* No Data To Load")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudObjectName(objName)
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblName + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudObjectName(objName)
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

    val secrdRptIssSnpshtDF = spark.sql(s"""
    select *,
    CURRENT_TIMESTAMP as snpsht_ins_ts,
    CASE WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('12:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('08:00 AM',"hh:mm a") THEN 1 
    WHEN unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") >= unix_timestamp('08:00 AM',"hh:mm a") AND unix_timestamp(from_unixtime(unix_timestamp(CURRENT_TIMESTAMP,'HH:mm:ss'),"hh:mm a"),"hh:mm a") < unix_timestamp('04:00 PM',"hh:mm a") THEN 2 
    ELSE 3 END as snpsht_nr 
    from ${tgtTblName}
    """)

    val tgtSnpShtColumns = spark.sql(s"select * from ${dbNameConsmtn}.secrd_rpt_iss_snpsht_fact limit 0").columns

    val dataSnpShtLoadDF = secrdRptIssSnpshtDF.select(Utilities.loadSelectExpr(secrdRptIssSnpshtDF.columns, tgtSnpShtColumns): _*)

    dataSnpShtLoadDF.repartition(10).write.mode("append").format("orc").insertInto(dbNameConsmtn + ".secrd_rpt_iss_snpsht_fact")

    val tgtCountSnpsht = spark.sql(s"select * from ${tgtTblName}").count.toLong

    tgtCountSnpsht match {
      case 0 =>
        logger.info("//************* No Data To Load")
        auditObj.setAudObjectName(objName + "SnpSht")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(tgtCount)
        auditObj.setAudTgtRowCount(tgtCountSnpsht)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblName + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudObjectName(objName + "SnpSht")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

    logger.info("+++++++++########### secrd_rpt_iss_snpsht_fact table loaded ###########+++++++++")

    logger.info("********************************************* ISS Option up Platform load data inserted")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case allException: Exception => {
      logger.error("All Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } finally {
    logger.info("//*********************** Log End for ISSOptionedUp.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
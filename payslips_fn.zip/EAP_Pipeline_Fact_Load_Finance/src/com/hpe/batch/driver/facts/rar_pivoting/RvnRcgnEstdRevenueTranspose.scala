package com.hpe.batch.driver.facts.rar_pivoting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object RvnRcgnEstdRevenueTranspose extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")

  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
  }

  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("RvnRcgEstimatedRevenueTranspose")
  auditObj.setAudObjectName(propertiesObject.getObjName())
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)

  try {
    
    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    /*
     * getLatestRecs to get the latest records
     * @Param df: Data frame on which operations needs to be performed
     * @Param partition_col: List of columns required to create partition
     * @Param sortCols: column name to get the latest record for each partition
     */

    def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
      val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*))
      val rowDF = df.withColumn("rn", row_number().over(part))
      val res = rowDF.filter("rn==1").drop("rn")
      res
    }

    logger.info("Initializing log for RAR Estd. Revenue TRANSPOSE, object_id : " + propertiesObject.getObjName())
    var dbNameConsmtn: String = null
    var consmptnTable: String = null
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {

      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)

    } else {

      logger.error("Please update tgtTblConsmtn properties to add database name!")

    }

    val dbNameITG = propertiesObject.getDbName().split(",")(0).trim
    val dbNameUAT = propertiesObject.getDbName().split(",")(1).trim

    val srcDF = spark.sql(s"select * from ${dbNameConsmtn}.rvn_rcgn_est_rvn_dmnsn")

    val src_count = srcDF.count.toLong
    //Initiating queries to load the tables for Secured Report Allocations

    val fahselectDF = spark.sql(s"select * from ${dbNameITG}.fnctl_ar_std_hrchy")

    val glselectDF = spark.sql(s"select distinct cast(gnrl_ldgr_acct_nr as bigint) as gnrl_ldgr_acct_nr,funtional_ar_cd from ${dbNameUAT}.gnrl_ldgr_acct_dmnsn")
    
    val srcTrsnDF = getLatestRecs(srcDF, List("rcncltn_ky", "prfm_obgn_id", "rvn_rcgn_cntrct_id", "fnctl_ar_cd"), List("ins_gmt_ts"))

    var estdRvnTrsnDF_net_revenue = srcTrsnDF.as("a").join(glselectDF.as("c"), col("a.gl_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").
      select("rvn_rcgn_cntrct_id", "prfm_obgn_id", "rcncltn_ky", "rvn_dlta_amt", "fa_level_7", "fa_level_7_desc", "fa_level_8", "fa_level_8_desc", "fa_level_11", "fa_level_11_desc", "curr_ky").
      filter(col("fa_level_7_desc").isNotNull).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rcncltn_ky"), col("curr_ky")).
      pivot("fa_level_7_desc").
      sum("rvn_dlta_amt")

    estdRvnTrsnDF_net_revenue = estdRvnTrsnDF_net_revenue.columns.foldLeft(estdRvnTrsnDF_net_revenue) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")) }

    var estdRvnTrsnDF_gross_discount = srcTrsnDF.as("a").join(glselectDF.as("c"), col("a.gl_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").
      select("rvn_rcgn_cntrct_id", "prfm_obgn_id", "rcncltn_ky", "rvn_dlta_amt", "fa_level_7", "fa_level_7_desc", "fa_level_8", "fa_level_8_desc", "fa_level_11", "fa_level_11_desc", "curr_ky").
      filter(col("fa_level_8_desc").isNotNull).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rcncltn_ky"), col("curr_ky")).
      pivot("fa_level_8_desc").
      sum("rvn_dlta_amt")

    estdRvnTrsnDF_gross_discount = estdRvnTrsnDF_gross_discount.columns.foldLeft(estdRvnTrsnDF_gross_discount) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")) }

    var estdRvnTrsnDF_Estimated_Standard_Cost = srcTrsnDF.as("a").join(glselectDF.as("c"), col("a.gl_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").
      select("rvn_rcgn_cntrct_id", "prfm_obgn_id", "rcncltn_ky", "rvn_dlta_amt", "fa_level_7", "fa_level_7_desc", "fa_level_8", "fa_level_8_desc", "fa_level_11", "fa_level_11_desc", "curr_ky").
      filter(col("fa_level_11_desc").isNotNull).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rcncltn_ky"), col("curr_ky")).
      pivot("fa_level_11_desc").
      sum("rvn_dlta_amt")

    estdRvnTrsnDF_Estimated_Standard_Cost = estdRvnTrsnDF_Estimated_Standard_Cost.columns.foldLeft(estdRvnTrsnDF_Estimated_Standard_Cost) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")) }

    val Keys = "rvn_rcgn_cntrct_id,rcncltn_ky,prfm_obgn_id"

    val joinKeys = Keys.split(",").toSeq

    var final_df2 = estdRvnTrsnDF_net_revenue.as("a").join(estdRvnTrsnDF_gross_discount.as("b"), joinKeys).
      join(estdRvnTrsnDF_Estimated_Standard_Cost.as("c"), joinKeys)

    //var final_df2 = dfrdTrsnDF_net_revenue.as("a").join(dfrdTrsnDF_gross_discount.as("b"), col("a.rvn_rcgn_cntrct_id") === col("b.rvn_rcgn_cntrct_id") && col("a.prfm_obgn_id") === col("b.prfm_obgn_id") && col("a.rcncltn_ky") === col("b.rcncltn_ky") && col("a.curr_ky") === col("b.curr_ky")).join(dfrdTrsnDF_Estimated_Standard_Cost.as("c"), col("b.rvn_rcgn_cntrct_id") === col("c.rvn_rcgn_cntrct_id") && col("b.prfm_obgn_id") === col("c.prfm_obgn_id") && col("b.rcncltn_ky") === col("c.rcncltn_ky") && col("b.curr_ky") === col("c.curr_ky"))

    val final_estd_rvn_df = final_df2.selectExpr(
      "crc64(concat(coalesce(a.rvn_rcgn_cntrct_id,''),coalesce(a.prfm_obgn_id,''),coalesce(a.rcncltn_ky,a.curr_ky,''))) as rvn_rcgn_estd_rvn_ky",
      "a.rvn_rcgn_cntrct_id",
      "a.prfm_obgn_id",
      "a.rcncltn_ky",
      "Net_Revenues",
      "Gross_Trade_Revenues",
      "Trade_Sales_LEM",
      "a.curr_ky",
      "Total_Cost_of_Sales",
      "Enterprise_Standard_Cost_Total").
      withColumn("total_cost_of_sales",lit(0)).
      withColumn("enterprise_standard_cost",lit(0)).
      withColumn("intgtn_fbrc_msg_id", lit(null)).
      withColumn("src_sys_upd_ts", lit(null)).
      withColumn("src_sys_ky", lit(null)).
      withColumn("lgcl_dlt_ind", lit(null)).
      withColumn("ins_gmt_ts", current_timestamp()).
      withColumn("upd_gmt_ts", current_timestamp()).
      withColumn("src_sys_extrc_gmt_ts", current_timestamp()).
      withColumn("src_sys_btch_nr", lit(null)).
      withColumn("fl_nm", lit(null)).
      withColumn("ld_jb_nr", lit(null))

    val DFcolNames = final_estd_rvn_df.columns.toList

    val transformedDF = DFcolNames.foldLeft(final_estd_rvn_df)((final_dfrd_df, c) =>
      final_dfrd_df.withColumnRenamed(c.toString.split(",")(0), c.toString.toLowerCase()))

    val tgtColumns = spark.sql(s"select * from ${dbNameConsmtn}.rvn_rcgn_estd_pvt_dmnsn").columns

    val finalLoadDF = transformedDF.select(Utilities.loadSelectExpr(transformedDF.columns, tgtColumns): _*)

    finalLoadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn+".rvn_rcgn_estd_pvt_dmnsn")

    val tgt_count = spark.sql(s"select * from ${dbNameConsmtn}.rvn_rcgn_estd_pvt_dmnsn").count.toInt

    if (tgt_count <= 0) {
      logger.error("No records to process !")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    } else {
      logger.info("CDC process completed !")
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }

  } finally {
    sqlCon.close()
    spark.close()

  }
}
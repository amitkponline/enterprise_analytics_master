package com.hpe.batch.driver.facts.fixed_asset

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object asst_mstr_rcrd_sgmnt_serp_dmnsn extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var srcCount = 0
  var tgtCount = 0
  var jobStatusFlag = true
  var incrementalDf = spark.emptyDataFrame

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  //************************Set Audit Entries*******************************//

  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(propertiesObject.getObjName())
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(srcCount)
  auditObj.setAudTgtRowCount(tgtCount)

  try {

    var ref_btch_id = Utilities.readRefBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)
    var cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)

    logger.info("ref_btch_id :- " + ref_btch_id + " cnsmptn_btch_id :- " + cnsmptn_btch_id)

    logger.info("Initializing log for ASSET RECORD MASTER SEGMENT SERP DIMENSION, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ref_btch_id)

    val consmptnTable = new StringBuilder()
    val dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    /* *************************************** Selecting source count ****************************** */
    var ins_gmt_date = ""

    if (cnsmptn_btch_id == "1900-01-01 00:00:00") {
      ins_gmt_date = cnsmptn_btch_id.substring(0, 4) + "-" + cnsmptn_btch_id.substring(5, 7) + "-" + cnsmptn_btch_id.substring(8, 10)
    } else {
      ins_gmt_date = cnsmptn_btch_id.substring(19, 23) + "-" + cnsmptn_btch_id.substring(23, 25) + "-" + cnsmptn_btch_id.substring(25, 27)
    }

    val srcCount = spark.sql(s"""select count(*) from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""").first().getLong(0).toInt
    logger.info(s"""select count(*) from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""")
    logger.info("source count: " + srcCount)
    var tgtTbl = consmptnTable
    if (srcCount > 0) {
      auditObj.setAudSrcRowCount(srcCount)

      spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'com.hpe.batch.hive.udfs.CRC64'""")

      /* ************************** Creating data frame for latest data ************************* */
      incrementalDf = spark.sql(s"""SELECT crc64(concat(COALESCE(trim(lgl_co_cd),""),COALESCE(trim(mn_asst_nr),""))) as cmpny_cd_mn_asst_nmbr_ky ,coalesce(lgl_co_cd,'') as lgl_co_cd ,coalesce(mn_asst_nr,'') as mn_asst_nr ,coalesce(asst_sb_nr,'') as asst_sb_nr ,asst_clss_cd ,tchnl_asst_nr ,asst_typ_cd ,crtd_by_usr_id ,rec_crtd_dt ,chgd_by_usr_id ,chgd_dt ,acct_dlt_ind ,acct_pstg_blckd_ind ,asst_mstr_dta_lyt_cd ,acct_dtrmn_cd ,asst_undr_cnstn_ind ,asst_cgy_cd ,asst_aqstn_yr_nr ,aqstn_pstg_prd_nr ,asst_vl_frst_pstg_dt ,asst_cptlzn_dt ,last_rtrmnt_asst_vl_dt ,dactvn_dt ,plnd_rtrmnt_dt ,asst_po_dt ,evltn_grp_1_cd ,evltn_grp_2_cd ,evltn_grp_3_cd ,evltn_grp_4_cd ,asst_spr_nr ,asngmt_nr_ky ,mng_h_ind ,asst_cmplts_ind ,vndr_acct_nr ,asst_orgn_ctry_cd ,splyr_nm ,mfrr_nm ,prpt_law_asst_clsfn_ind ,orgl_asst_id ,orgl_asst_sb_id ,auc_orgl_aqstn_dt ,orgl_aqstn_fscl_yr ,aqstn_amt ,ihse_prdn_pct ,old_prj_nr ,ivstmt_ord_cd ,bs_unt_of_msr_cd ,qty ,asst_typ_dn ,ivstmt_rsn_cd ,phy_invy_ind ,invy_last_dt ,addnl_asst_inf_txt ,prpt_clsfn_ky ,mnl_prpt_vl_amt_ind ,mnl_prpt_vl_amt ,assd_vl_amt ,cnvync_dt ,asmnt_notc_chgd_dt ,tx_nr ,lnd_rgst_dt ,lnd_rgst_etry_dt ,lnd_rgstr_vol ,lnd_rgstr_pg_id ,lnd_rgstr_etry_sqn_nr ,lnd_rgstr_mp_nr ,lnd_rgstr_plt_nr ,tx_ofc_nm ,mncplty_nm ,mnl_valtn_rsn_cd ,ar_unt_of_msr_cd ,srfc_ar_qty ,invy_nr ,trdg_ptnr_co_cd ,lng_ky ,asst_dn ,asst_addnl_dn ,lg_txt_actv_ind ,prpt_values_lg_txt_ind ,tchnl_vw_lg_txt_ind ,lg_txt_actv_in ,lg_txt_exss_ind ,lsng_dta_lg_txt_ind ,lsng_co_nm ,lsng_agrmnt_dt ,lsng_agrmnt_notc_dt ,ls_strt_dt ,ls_durtn_yr_qty ,ls_durtn_prd_qty ,ls_pmnt_cyc_nr ,prdc_ls_pmnt_qty ,ls_bs_vl_amt ,ls_asst_prch_prc_amt ,lsng_mthly_int_rt ,lsng_int_rt ,last_ls_pmnt_pstg_dt ,pstd_lsng_pymnt_amt ,lsng_int_pstd_amt ,longterm_lsng_liblty_amt ,totl_ls_pmnt_qty ,lsng_agrmnt_nr ,lsng_txt ,asst_cptlzn_ind ,rec_chg_ind ,last_doc_nr ,vw_0_chg_dt ,vw_0_mdfr ,vw_chg_dt ,vw_mdfr ,vw_2_chg_dt ,vw_2_mdfr ,vw_3_chg_dt ,vw_3_mdfr ,vw_4_chg_dt ,vw_4_mdfr ,vw_5_chg_dt ,vw_5_mdfr ,vw_6_chg_dt ,vw_6_mdfr ,real_estte_ind ,obj_nr ,lsng_typ_cd ,adv_pmnt_ind ,evltn_grp_5_cd ,wbs_elmt_cd ,invd_mmo_ind ,asst_acqr_used_ind ,grp_asst_ind ,matchcode_srch_trm ,cptl_ivstmt_ind ,mfrr_srl_nr ,envl_ivstmt_rsn_cd ,last_rvaltn_dt ,asst_mstr_rcrd_chg_ind ,timedependent_valtn_asst_parameters ,last_reorg_dt ,lgcy_dta_trnsfr_dt ,lgcy_dta_trnsfr_sqn_nr ,asst_worklist_dta_elmt_xtsn ,inrn_cd ,aprvl_dcmt_nr ,aprvl_vrsn ,bogus_asst_nr ,asst_vrsn ,intgtn_fbrc_msg_id ,src_sys_upd_ts ,src_sys_ky ,lgcl_dlt_ind ,ins_gmt_ts ,upd_gmt_ts ,src_sys_extrc_gmt_ts ,src_sys_btch_nr ,fl_nm ,ld_jb_nr,cast(concat(substr(ins_gmt_dt,0,7),"-01") as date) as ins_gmt_dt FROM (select *,row_number() over (partition by  lgl_co_cd,mn_asst_nr,asst_sb_nr order by ins_gmt_ts desc) as rownum from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}')a where a.rownum = 1""")
      logger.info(s"""SELECT crc64(concat(COALESCE(trim(lgl_co_cd),""),COALESCE(trim(mn_asst_nr),""))) as cmpny_cd_mn_asst_nmbr_ky ,coalesce(lgl_co_cd,'') as lgl_co_cd ,coalesce(mn_asst_nr,'') as mn_asst_nr ,coalesce(asst_sb_nr,'') as asst_sb_nr ,asst_clss_cd ,tchnl_asst_nr ,asst_typ_cd ,crtd_by_usr_id ,rec_crtd_dt ,chgd_by_usr_id ,chgd_dt ,acct_dlt_ind ,acct_pstg_blckd_ind ,asst_mstr_dta_lyt_cd ,acct_dtrmn_cd ,asst_undr_cnstn_ind ,asst_cgy_cd ,asst_aqstn_yr_nr ,aqstn_pstg_prd_nr ,asst_vl_frst_pstg_dt ,asst_cptlzn_dt ,last_rtrmnt_asst_vl_dt ,dactvn_dt ,plnd_rtrmnt_dt ,asst_po_dt ,evltn_grp_1_cd ,evltn_grp_2_cd ,evltn_grp_3_cd ,evltn_grp_4_cd ,asst_spr_nr ,asngmt_nr_ky ,mng_h_ind ,asst_cmplts_ind ,vndr_acct_nr ,asst_orgn_ctry_cd ,splyr_nm ,mfrr_nm ,prpt_law_asst_clsfn_ind ,orgl_asst_id ,orgl_asst_sb_id ,auc_orgl_aqstn_dt ,orgl_aqstn_fscl_yr ,aqstn_amt ,ihse_prdn_pct ,old_prj_nr ,ivstmt_ord_cd ,bs_unt_of_msr_cd ,qty ,asst_typ_dn ,ivstmt_rsn_cd ,phy_invy_ind ,invy_last_dt ,addnl_asst_inf_txt ,prpt_clsfn_ky ,mnl_prpt_vl_amt_ind ,mnl_prpt_vl_amt ,assd_vl_amt ,cnvync_dt ,asmnt_notc_chgd_dt ,tx_nr ,lnd_rgst_dt ,lnd_rgst_etry_dt ,lnd_rgstr_vol ,lnd_rgstr_pg_id ,lnd_rgstr_etry_sqn_nr ,lnd_rgstr_mp_nr ,lnd_rgstr_plt_nr ,tx_ofc_nm ,mncplty_nm ,mnl_valtn_rsn_cd ,ar_unt_of_msr_cd ,srfc_ar_qty ,invy_nr ,trdg_ptnr_co_cd ,lng_ky ,asst_dn ,asst_addnl_dn ,lg_txt_actv_ind ,prpt_values_lg_txt_ind ,tchnl_vw_lg_txt_ind ,lg_txt_actv_in ,lg_txt_exss_ind ,lsng_dta_lg_txt_ind ,lsng_co_nm ,lsng_agrmnt_dt ,lsng_agrmnt_notc_dt ,ls_strt_dt ,ls_durtn_yr_qty ,ls_durtn_prd_qty ,ls_pmnt_cyc_nr ,prdc_ls_pmnt_qty ,ls_bs_vl_amt ,ls_asst_prch_prc_amt ,lsng_mthly_int_rt ,lsng_int_rt ,last_ls_pmnt_pstg_dt ,pstd_lsng_pymnt_amt ,lsng_int_pstd_amt ,longterm_lsng_liblty_amt ,totl_ls_pmnt_qty ,lsng_agrmnt_nr ,lsng_txt ,asst_cptlzn_ind ,rec_chg_ind ,last_doc_nr ,vw_0_chg_dt ,vw_0_mdfr ,vw_chg_dt ,vw_mdfr ,vw_2_chg_dt ,vw_2_mdfr ,vw_3_chg_dt ,vw_3_mdfr ,vw_4_chg_dt ,vw_4_mdfr ,vw_5_chg_dt ,vw_5_mdfr ,vw_6_chg_dt ,vw_6_mdfr ,real_estte_ind ,obj_nr ,lsng_typ_cd ,adv_pmnt_ind ,evltn_grp_5_cd ,wbs_elmt_cd ,invd_mmo_ind ,asst_acqr_used_ind ,grp_asst_ind ,matchcode_srch_trm ,cptl_ivstmt_ind ,mfrr_srl_nr ,envl_ivstmt_rsn_cd ,last_rvaltn_dt ,asst_mstr_rcrd_chg_ind ,timedependent_valtn_asst_parameters ,last_reorg_dt ,lgcy_dta_trnsfr_dt ,lgcy_dta_trnsfr_sqn_nr ,asst_worklist_dta_elmt_xtsn ,inrn_cd ,aprvl_dcmt_nr ,aprvl_vrsn ,bogus_asst_nr ,asst_vrsn ,intgtn_fbrc_msg_id ,src_sys_upd_ts ,src_sys_ky ,lgcl_dlt_ind ,ins_gmt_ts ,upd_gmt_ts ,src_sys_extrc_gmt_ts ,src_sys_btch_nr ,fl_nm ,ld_jb_nr,cast(concat(substr(ins_gmt_dt,0,7),"-01") as date) as ins_gmt_dt FROM (select *,row_number() over (partition by  lgl_co_cd,mn_asst_nr,asst_sb_nr order by ins_gmt_ts desc) as rownum from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}')a where a.rownum = 1""")

      incrementalDf = incrementalDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

      //***************************incremental CDC*********************************//

      val existingDmnsnDF = spark.sql(f"""select cmpny_cd_mn_asst_nmbr_ky,coalesce(lgl_co_cd,'') as lgl_co_cd ,coalesce(mn_asst_nr,'') as mn_asst_nr ,coalesce(asst_sb_nr,'') as asst_sb_nr,asst_clss_cd,tchnl_asst_nr,asst_typ_cd,crtd_by_usr_id,rec_crtd_dt,chgd_by_usr_id,chgd_dt,acct_dlt_ind,acct_pstg_blckd_ind,asst_mstr_dta_lyt_cd,acct_dtrmn_cd,asst_undr_cnstn_ind,asst_cgy_cd,asst_aqstn_yr_nr,aqstn_pstg_prd_nr,asst_vl_frst_pstg_dt,asst_cptlzn_dt,last_rtrmnt_asst_vl_dt,dactvn_dt,plnd_rtrmnt_dt,asst_po_dt,evltn_grp_1_cd,evltn_grp_2_cd,evltn_grp_3_cd,evltn_grp_4_cd,asst_spr_nr,asngmt_nr_ky,mng_h_ind,asst_cmplts_ind,vndr_acct_nr,asst_orgn_ctry_cd,splyr_nm,mfrr_nm,prpt_law_asst_clsfn_ind,orgl_asst_id,orgl_asst_sb_id,auc_orgl_aqstn_dt,orgl_aqstn_fscl_yr,aqstn_amt,ihse_prdn_pct,old_prj_nr,ivstmt_ord_cd,bs_unt_of_msr_cd,qty,asst_typ_dn,ivstmt_rsn_cd,phy_invy_ind,invy_last_dt,addnl_asst_inf_txt,prpt_clsfn_ky,mnl_prpt_vl_amt_ind,mnl_prpt_vl_amt,assd_vl_amt,cnvync_dt,asmnt_notc_chgd_dt,tx_nr,lnd_rgst_dt,lnd_rgst_etry_dt,lnd_rgstr_vol,lnd_rgstr_pg_id,lnd_rgstr_etry_sqn_nr,lnd_rgstr_mp_nr,lnd_rgstr_plt_nr,tx_ofc_nm,mncplty_nm,mnl_valtn_rsn_cd,ar_unt_of_msr_cd,srfc_ar_qty,invy_nr,trdg_ptnr_co_cd,lng_ky,asst_dn,asst_addnl_dn,lg_txt_actv_ind,prpt_values_lg_txt_ind,tchnl_vw_lg_txt_ind,lg_txt_actv_in,lg_txt_exss_ind,lsng_dta_lg_txt_ind,lsng_co_nm,lsng_agrmnt_dt,lsng_agrmnt_notc_dt,ls_strt_dt,ls_durtn_yr_qty,ls_durtn_prd_qty,ls_pmnt_cyc_nr,prdc_ls_pmnt_qty,ls_bs_vl_amt,ls_asst_prch_prc_amt,lsng_mthly_int_rt,lsng_int_rt,last_ls_pmnt_pstg_dt,pstd_lsng_pymnt_amt,lsng_int_pstd_amt,longterm_lsng_liblty_amt,totl_ls_pmnt_qty,lsng_agrmnt_nr,lsng_txt,asst_cptlzn_ind,rec_chg_ind,last_doc_nr,vw_0_chg_dt,vw_0_mdfr,vw_chg_dt,vw_mdfr,vw_2_chg_dt,vw_2_mdfr,vw_3_chg_dt,vw_3_mdfr,vw_4_chg_dt,vw_4_mdfr,vw_5_chg_dt,vw_5_mdfr,vw_6_chg_dt,vw_6_mdfr,real_estte_ind,obj_nr,lsng_typ_cd,adv_pmnt_ind,evltn_grp_5_cd,wbs_elmt_cd,invd_mmo_ind,asst_acqr_used_ind,grp_asst_ind,matchcode_srch_trm,cptl_ivstmt_ind,mfrr_srl_nr,envl_ivstmt_rsn_cd,last_rvaltn_dt,asst_mstr_rcrd_chg_ind,timedependent_valtn_asst_parameters,last_reorg_dt,lgcy_dta_trnsfr_dt,lgcy_dta_trnsfr_sqn_nr,asst_worklist_dta_elmt_xtsn,inrn_cd,aprvl_dcmt_nr,aprvl_vrsn,bogus_asst_nr,asst_vrsn,intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_gmt_dt from ${dbNameConsmtn}.${tgtTbl}""")
      logger.info(f"""select cmpny_cd_mn_asst_nmbr_ky,coalesce(lgl_co_cd,'') as lgl_co_cd ,coalesce(mn_asst_nr,'') as mn_asst_nr ,coalesce(asst_sb_nr,'') as asst_sb_nr,asst_clss_cd,tchnl_asst_nr,asst_typ_cd,crtd_by_usr_id,rec_crtd_dt,chgd_by_usr_id,chgd_dt,acct_dlt_ind,acct_pstg_blckd_ind,asst_mstr_dta_lyt_cd,acct_dtrmn_cd,asst_undr_cnstn_ind,asst_cgy_cd,asst_aqstn_yr_nr,aqstn_pstg_prd_nr,asst_vl_frst_pstg_dt,asst_cptlzn_dt,last_rtrmnt_asst_vl_dt,dactvn_dt,plnd_rtrmnt_dt,asst_po_dt,evltn_grp_1_cd,evltn_grp_2_cd,evltn_grp_3_cd,evltn_grp_4_cd,asst_spr_nr,asngmt_nr_ky,mng_h_ind,asst_cmplts_ind,vndr_acct_nr,asst_orgn_ctry_cd,splyr_nm,mfrr_nm,prpt_law_asst_clsfn_ind,orgl_asst_id,orgl_asst_sb_id,auc_orgl_aqstn_dt,orgl_aqstn_fscl_yr,aqstn_amt,ihse_prdn_pct,old_prj_nr,ivstmt_ord_cd,bs_unt_of_msr_cd,qty,asst_typ_dn,ivstmt_rsn_cd,phy_invy_ind,invy_last_dt,addnl_asst_inf_txt,prpt_clsfn_ky,mnl_prpt_vl_amt_ind,mnl_prpt_vl_amt,assd_vl_amt,cnvync_dt,asmnt_notc_chgd_dt,tx_nr,lnd_rgst_dt,lnd_rgst_etry_dt,lnd_rgstr_vol,lnd_rgstr_pg_id,lnd_rgstr_etry_sqn_nr,lnd_rgstr_mp_nr,lnd_rgstr_plt_nr,tx_ofc_nm,mncplty_nm,mnl_valtn_rsn_cd,ar_unt_of_msr_cd,srfc_ar_qty,invy_nr,trdg_ptnr_co_cd,lng_ky,asst_dn,asst_addnl_dn,lg_txt_actv_ind,prpt_values_lg_txt_ind,tchnl_vw_lg_txt_ind,lg_txt_actv_in,lg_txt_exss_ind,lsng_dta_lg_txt_ind,lsng_co_nm,lsng_agrmnt_dt,lsng_agrmnt_notc_dt,ls_strt_dt,ls_durtn_yr_qty,ls_durtn_prd_qty,ls_pmnt_cyc_nr,prdc_ls_pmnt_qty,ls_bs_vl_amt,ls_asst_prch_prc_amt,lsng_mthly_int_rt,lsng_int_rt,last_ls_pmnt_pstg_dt,pstd_lsng_pymnt_amt,lsng_int_pstd_amt,longterm_lsng_liblty_amt,totl_ls_pmnt_qty,lsng_agrmnt_nr,lsng_txt,asst_cptlzn_ind,rec_chg_ind,last_doc_nr,vw_0_chg_dt,vw_0_mdfr,vw_chg_dt,vw_mdfr,vw_2_chg_dt,vw_2_mdfr,vw_3_chg_dt,vw_3_mdfr,vw_4_chg_dt,vw_4_mdfr,vw_5_chg_dt,vw_5_mdfr,vw_6_chg_dt,vw_6_mdfr,real_estte_ind,obj_nr,lsng_typ_cd,adv_pmnt_ind,evltn_grp_5_cd,wbs_elmt_cd,invd_mmo_ind,asst_acqr_used_ind,grp_asst_ind,matchcode_srch_trm,cptl_ivstmt_ind,mfrr_srl_nr,envl_ivstmt_rsn_cd,last_rvaltn_dt,asst_mstr_rcrd_chg_ind,timedependent_valtn_asst_parameters,last_reorg_dt,lgcy_dta_trnsfr_dt,lgcy_dta_trnsfr_sqn_nr,asst_worklist_dta_elmt_xtsn,inrn_cd,aprvl_dcmt_nr,aprvl_vrsn,bogus_asst_nr,asst_vrsn,intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_gmt_dt from ${dbNameConsmtn}.${tgtTbl}""")

      if (!existingDmnsnDF.head(1).isEmpty) {
        //************************For incremental load*****************************//
        var overWritePrtition = existingDmnsnDF.join(
          incrementalDf,
          existingDmnsnDF("lgl_co_cd") === incrementalDf("lgl_co_cd") &&
            existingDmnsnDF("mn_asst_nr") === incrementalDf("mn_asst_nr") &&
            existingDmnsnDF("asst_sb_nr") === incrementalDf("asst_sb_nr")).select(existingDmnsnDF("ins_gmt_dt").cast(StringType)).
          distinct.collect.map(row => row.getString(0).toString()).toSeq
          
        if (overWritePrtition.size == 0) { overWritePrtition = incrementalDf.select(incrementalDf("ins_gmt_dt").cast(StringType)).distinct.collect.map(row => row.getString(0).toString()).toSeq }

        val dmnsnNonMatchDF = existingDmnsnDF.where(existingDmnsnDF("ins_gmt_dt").isin(overWritePrtition: _*)).join(
          incrementalDf,
          existingDmnsnDF("lgl_co_cd") === incrementalDf("lgl_co_cd") &&
            existingDmnsnDF("mn_asst_nr") === incrementalDf("mn_asst_nr") &&
            existingDmnsnDF("asst_sb_nr") === incrementalDf("asst_sb_nr"), "left_anti")

        val finalDmnsnDF = incrementalDf.union(dmnsnNonMatchDF)

        finalDmnsnDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + tgtTbl)

      } else {
        //**************************For initial load*****************************//
        incrementalDf.write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + tgtTbl)
      }
      /* ************************ selecting target count ****************************************** */
      tgtCount = incrementalDf.count().toInt
      logger.info("target count: " + tgtCount)

      logger.info("+++++++++++############# Load Successful #############+++++++++++")
      auditObj.setAudTgtRowCount(tgtCount)
      auditObj.setAudJobStatusCode("success")
    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("failed")
    }
    /* ********************************************* Completion audit entries ************************** */

    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    incrementalDf.unpersist()
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) {
      System.exit(1)
    }

  }
}

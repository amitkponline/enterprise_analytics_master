package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source

object QuotesSecuredReport extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  logger.info("+++++++++++++############## properties file:" + propertiesFilePath)
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  logger.info("+++++++++++++############## environment properties file:" + envPropertiesFilePath)
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  logger.info("+++++++++++++############## audit table:" + auditTbl)
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  if (sqlCon == null) {
    logger.error("+++++++++++++############## MYSQL Connection Not Established")
    throw new NullPointerException("Please update tgtTblConsmtn properties to add database name!")
  }

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val objName = propertiesObject.getObjName()
  val dbName = propertiesObject.getDbName().trim()

  try {

    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn))

    //***************************Audit Properties********************************//
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_secrd_quotes_fact_load")
    auditObj.setAudObjectName(objName)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)

    if (tgtTblConsmtn.split("\\.", -1).size != 2) {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val dbCommon = dbName.split(",")(0)
    val dbCommonUAT = dbName.split(",")(1)
    val tgtColumns = spark.sql("select * from " + tgtTblConsmtn + " limit 0").columns
    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    /*
 * For load testing we have removed the filters
 *
 */

    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    val quotesSelectDF = spark.sql(s"""
SELECT
	crc64(LOWER(CONCAT(COALESCE(quotes_fact.quotes_fact_ky, ""), COALESCE(hpe_qt_flags_dmnsn.hpe_qt_flags_ky,""),COALESCE(quotes_fact.asset_quote_nr_cd, ""),COALESCE(quotes_fact.asset_quote_vrsn_cd,""),COALESCE(prty_asscn_dmnsn.prty_asscn_prty_id,"")))) AS secrd_rpt_fact_ky,
	crc32(LOWER(COALESCE(quote_header_deal_nr_cd, ""))) AS deal_ky,
	crc32(LOWER(CONCAT(COALESCE(quotes_fact.asset_quote_nr_cd, ""),COALESCE(quotes_fact.asset_quote_vrsn_cd,"")))) AS quote_ky,
	crc32(LOWER(COALESCE(opportunity_id_id, ""))) AS opty_ky,
	quote_header_deal_nr_cd AS deal_id,
	opportunity_id_id AS opty_id,
	'QUOTES' AS src_sys_cd,
	CAST (quote_header_sls_qtn_id_id AS VARCHAR(20)) AS quote_id,
	mdcp_customer_segment_cd AS cust_sgm_cd,
	CURRENT_TIMESTAMP AS ins_ts,
	customer_engagement_cd AS bsn_rshp_typ_cd,
	quotes_fact.quote_header_sls_qtn_vrsn_sqn_nr_cd AS quote_header_sls_qtn_vrsn_sqn_nr_cd,
	quotes_fact.asset_quote_nr_cd AS asset_quote_nr_cd,
	quotes_fact.asset_quote_vrsn_cd AS asset_quote_vrsn_cd,
	quotes_fact.modified_ts_cd AS modified_ts_cd,
	quotes_fact.creation_person_id_id AS crtd_by_usr_id,
	quotes_fact.sfdc_status_cd AS sfdc_status_cd,
	quotes_fact.total_amt_cd AS total_amt,
	quotes_fact.total_list_price_amt_cd AS total_list_price_amt,
	quotes_fact.bmi_id_id AS bmi_id_id,
	quotes_fact.nm AS nm,
	quotes_fact.price_geo_cd AS price_geo_cd,
	quotes_fact.asset_quote_nr_and_vrsn_cd AS asset_quote_nr_and_vrsn_cd,
	quotes_fact.org_id_id AS org_id_id,
	quotes_fact.creation_ts_cd AS creation_ts_cd,
	quotes_fact.currency_cd_cd AS currency_cd_cd,
	quotes_fact.sls_qtn_vrsn_typ_cd_cd AS sls_qtn_vrsn_typ_cd_cd,
	quotes_fact.cty_cd AS cty_cd,
	quotes_fact.quoteowner_cd AS quoteowner_cd,
	hpe_qt_flags_dmnsn.flg_typ_cd AS flg_typ_cd,
	hpe_qt_flags_dmnsn.flg_vl_cd AS flg_vl_cd,
	quotes_fact.sls_qtn_vrsn_stts_cd_cd AS sls_qtn_vrsn_stts_cd_cd,
	quotes_fact. partner_id_id AS partner_id_id,
	quotes_fact.orig_asset_cd AS orig_asset_cd,
	quotes_fact.modified_person_id_id AS modified_person_id_id,
	quotes_fact.lead_bu_cd AS lead_bu_cd,
	quotes_fact.last_modifier_ngq_profile_cd AS last_modifier_ngq_profile_cd ,
	quotes_fact.customer_mdcp_org_id_id AS customer_mdcp_org_id_id,
	quotes_fact.mdcp_opsi_id_id AS mdcp_opsi_id_id,
	quotes_fact.creator_ngq_profile_cd AS creator_ngq_profile_cd,
	quotes_fact.creation_person_id_id AS creation_person_id_id,
	quotes_fact.completion_ts_cd AS completion_ts_cd,
	quotes_fact.quote_items_product_line_cd AS quote_items_product_line_cd,
	quotes_fact.lcl_xtnd_nt_amt_cd AS lcl_xtnd_nt_amt_cd,
	quotes_fact.qty_cd AS qty_cd,
	hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_id_id AS hpe_quote_flags_sls_qtn_id,
	hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd AS hpe_quote_flags_sls_qtn_vrsn_sqn_nr,
	quotes_fact.ins_gmt_ts AS ins_gmt_ts,
	quotes_fact.region_cd_cd as rgn_cd,
	quotes_fact.service_agrmnt_id_id as srv_agrmnt_id,
	quotes_fact.sales_org_cd as sales_org_cd,
	quotes_fact.ctry_cd as ctry_cd,
	quotes_fact.customer_name_nm as soldto_prty_nm,
	quotes_fact.product_id_id as mtrl_nr,
	deal_vrsn_cd AS deal_vrsn_nr  -- changed 2/19
  ,customer_name_nm AS quotes_cust_nm
  ,chanel_partner_id_reseller_id AS rslr_nr
  ,customer_mdcp_site_id_id AS quotes_cust_mdcp_site_id
  ,distributor_partner_id_id AS quotes_dist_ptnr_id
  ,sold_to_staid_id AS sold_to_staid_id
  ,rtm AS mkt_rte_cd
  ,prty_asscn_dmnsn.prty_asscn_prty_id AS mdm_id
  ,quote_items_pa_nr_cd as ord_prch_cd
FROM
	(
	SELECT a.*
	FROM
		(
		SELECT
			quotes.*,
			ROW_NUMBER() OVER(PARTITION BY quotes.asset_quote_nr_cd
		ORDER BY
			quotes.asset_quote_vrsn_cd DESC ) AS RANK
		FROM
			${dbCommonUAT}.quotes_fact quotes) a
	WHERE
		a.rank = 1) quotes_fact
LEFT OUTER JOIN (select * from (select *,row_number() over (partition by hpe_quote_flags_sls_qtn_id_id,hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd order by ins_gmt_ts) as rw_nm from ${dbCommonUAT}.hpe_qt_flags_dmnsn) x where rw_nm = 1) hpe_qt_flags_dmnsn ON
	quotes_fact.quote_header_sls_qtn_id_id = hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_id_id
	AND quotes_fact.quote_header_sls_qtn_vrsn_sqn_nr_cd = hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd
LEFT OUTER JOIN ${dbCommonUAT}.prty_asscn_dmnsn prty_asscn_dmnsn ON quotes_fact.mdcp_org_id_id = prty_asscn_dmnsn.prty_asscn_vl_cd
WHERE
  quote_header_deal_nr_cd IS NULL
	AND creation_ts_cd >= date_sub(to_date(from_unixtime(unix_timestamp())),
	730)
	AND quotes_fact.quote_header_deal_nr_cd NOT IN (
	SELECT
		CAST(deal_dmnsn.deal_id AS VARCHAR(10)) AS deal_id
	FROM
		${dbCommonUAT}.deal_dmnsn
UNION
	SELECT
		sales_shipment_ref.deal_id_nm
	FROM
		${dbCommon}.sales_shipment_ref)    """).distinct

    val quotesFinalLoad = quotesSelectDF.select(Utilities.loadSelectExpr(quotesSelectDF.columns, tgtColumns): _*)
    quotesFinalLoad.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblConsmtn)

    val tgtCount = spark.sql(s"select * from ${tgtTblConsmtn} where src_sys_cd = 'QUOTES'").count.toInt

    tgtCount match {
      case 0 =>
        logger.info("//************* Data Load Failed")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } finally {
    sqlCon.close()
    spark.close()
  }

}
package com.hpe.batch.driver.facts.fixed_asset

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object dprctn_trms_serp_dmnsn extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var srcCount = 0
  var tgtCount = 0
  var jobStatusFlag = true
  var incrementalDf = spark.emptyDataFrame

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  //************************Set Audit Entries*******************************//

  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(propertiesObject.getObjName())
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(srcCount)
  auditObj.setAudTgtRowCount(tgtCount)

  try {

    var ref_btch_id = Utilities.readRefBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)
    var cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)

    logger.info("ref_btch_id :- " + ref_btch_id + " cnsmptn_btch_id :- " + cnsmptn_btch_id)

    logger.info("Initializing log for DEPRECIATION TERM SERP DIMENSION, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ref_btch_id)

    val consmptnTable = new StringBuilder()
    val dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    /* *************************************** Selecting source count ****************************** */
    var ins_gmt_date = ""

    if (cnsmptn_btch_id == "1900-01-01 00:00:00") {
      ins_gmt_date = cnsmptn_btch_id.substring(0, 4) + "-" + cnsmptn_btch_id.substring(5, 7) + "-" + cnsmptn_btch_id.substring(8, 10)
    } else {
      ins_gmt_date = cnsmptn_btch_id.substring(19, 23) + "-" + cnsmptn_btch_id.substring(23, 25) + "-" + cnsmptn_btch_id.substring(25, 27)
    }

    srcCount = spark.sql(s"""select count(*) from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""").first().getLong(0).toInt
    logger.info(s"""select count(*) from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""")
    logger.info("source count: " + srcCount)
    var tgtTbl = consmptnTable
    if (srcCount > 0) {
      auditObj.setAudSrcRowCount(srcCount)
      
      spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'com.hpe.batch.hive.udfs.CRC64'""")

      /* ************************** Creating data frame for latest data ************************* */
      incrementalDf = spark.sql(s"""SELECT crc64(concat(COALESCE(trim(lgl_co_cd),""),COALESCE(trim(mn_asst_nr),""),COALESCE(trim(real_dprc_ar_cd),""))) as cmpny_cd_mn_asst_nmbr_dprctn_ara_ky ,coalesce(lgl_co_cd,'') as lgl_co_cd,coalesce(mn_asst_nr,'') as mn_asst_nr,coalesce(asst_sb_nr,'') as asst_sb_nr,coalesce(real_dprc_ar_cd,'') as real_dprc_ar_cd,coalesce(dt_vldty_ends,'') as dt_vldty_ends ,dt_vldty_begins ,obj_crto ,rec_crtn_dt ,obj_mdfr ,chgd_on ,acct_marked_for_dltn_ind ,acct_blckd_ind ,scn_lyt_asst_acctng ,ngtv_values_allwd_ind ,low_vl_asst_qty_amt_chk ,depreciate_mn_asst_nr_totally_ind ,dprc_cltn_strt_dt ,int_cltn_strt_dt ,spcl_dprc_strt_dt ,ivstmt_sprt_ky ,dprc_ky ,plnd_useful_lf_yrs_qty ,plnd_useful_lf_periods_qty ,ordnry_dprc_pct_rt ,spcl_dprc_pct_rt ,rplm_values_idx ,rplm_values_age_idx ,vrbl_dprc_portn ,changeover_yr_dprc_ky ,orgl_useful_lf_yrs_qty ,orgl_useful_lf_periods_qty ,asst_scrp_vl ,asst_acct_annl_vl_last_fy ,dprc_strt_yr_prd_scaling ,tbl_typ_chg_ind ,rvaltn ,dprc_ar_deactivated_ind ,grp_asst ,grp_asst_sb_nr ,asser_aqstn_yr_nr ,asst_acctng_acquis_mth ,optg_readiness_dt ,vl_dt_of_last_rtrmnt_for_the_dprc_ar ,dprc_ar_dactvn_dt ,rvaltn_ky ,last_rvaltn_dt ,last_idx_used ,apc_scrp_vl_pct ,dprc_ky_changeover_prd ,intgtn_fbrc_msg_id ,src_sys_upd_ts ,src_sys_ky ,lgcl_dlt_ind ,ins_gmt_ts ,upd_gmt_ts ,src_sys_extrc_gmt_ts ,src_sys_btch_nr ,fl_nm ,ld_jb_nr,cast(concat(substr(ins_gmt_dt,0,7),"-01") as date) as ins_gmt_dt FROM (select *,row_number() over (partition by  lgl_co_cd,mn_asst_nr,asst_sb_nr,real_dprc_ar_cd,dt_vldty_ends order by ins_gmt_ts desc) as rownum from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}' )a where a.rownum = 1""")
      logger.info(s"""SELECT crc64(concat(COALESCE(trim(lgl_co_cd),""),COALESCE(trim(mn_asst_nr),""),COALESCE(trim(real_dprc_ar_cd),""))) as cmpny_cd_mn_asst_nmbr_dprctn_ara_ky ,coalesce(lgl_co_cd,'') as lgl_co_cd,coalesce(mn_asst_nr,'') as mn_asst_nr,coalesce(asst_sb_nr,'') as asst_sb_nr,coalesce(real_dprc_ar_cd,'') as real_dprc_ar_cd,coalesce(dt_vldty_ends,'') as dt_vldty_ends ,dt_vldty_begins ,obj_crto ,rec_crtn_dt ,obj_mdfr ,chgd_on ,acct_marked_for_dltn_ind ,acct_blckd_ind ,scn_lyt_asst_acctng ,ngtv_values_allwd_ind ,low_vl_asst_qty_amt_chk ,depreciate_mn_asst_nr_totally_ind ,dprc_cltn_strt_dt ,int_cltn_strt_dt ,spcl_dprc_strt_dt ,ivstmt_sprt_ky ,dprc_ky ,plnd_useful_lf_yrs_qty ,plnd_useful_lf_periods_qty ,ordnry_dprc_pct_rt ,spcl_dprc_pct_rt ,rplm_values_idx ,rplm_values_age_idx ,vrbl_dprc_portn ,changeover_yr_dprc_ky ,orgl_useful_lf_yrs_qty ,orgl_useful_lf_periods_qty ,asst_scrp_vl ,asst_acct_annl_vl_last_fy ,dprc_strt_yr_prd_scaling ,tbl_typ_chg_ind ,rvaltn ,dprc_ar_deactivated_ind ,grp_asst ,grp_asst_sb_nr ,asser_aqstn_yr_nr ,asst_acctng_acquis_mth ,optg_readiness_dt ,vl_dt_of_last_rtrmnt_for_the_dprc_ar ,dprc_ar_dactvn_dt ,rvaltn_ky ,last_rvaltn_dt ,last_idx_used ,apc_scrp_vl_pct ,dprc_ky_changeover_prd ,intgtn_fbrc_msg_id ,src_sys_upd_ts ,src_sys_ky ,lgcl_dlt_ind ,ins_gmt_ts ,upd_gmt_ts ,src_sys_extrc_gmt_ts ,src_sys_btch_nr ,fl_nm ,ld_jb_nr,cast(concat(substr(ins_gmt_dt,0,7),"-01") as date) as ins_gmt_dt FROM (select *,row_number() over (partition by  lgl_co_cd,mn_asst_nr,asst_sb_nr,real_dprc_ar_cd,dt_vldty_ends order by ins_gmt_ts desc) as rownum from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}' )a where a.rownum = 1""")

      incrementalDf = incrementalDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

      //***************************incremental CDC*********************************//

      val existingDmnsnDF = spark.sql(f"""select cmpny_cd_mn_asst_nmbr_dprctn_ara_ky,coalesce(lgl_co_cd,'') as lgl_co_cd,coalesce(mn_asst_nr,'') as mn_asst_nr,coalesce(asst_sb_nr,'') as asst_sb_nr,coalesce(real_dprc_ar_cd,'') as real_dprc_ar_cd,coalesce(dt_vldty_ends,'') as dt_vldty_ends,dt_vldty_begins,obj_crto,rec_crtn_dt,obj_mdfr,chgd_on,acct_marked_for_dltn_ind,acct_blckd_ind,scn_lyt_asst_acctng,ngtv_values_allwd_ind,low_vl_asst_qty_amt_chk,depreciate_mn_asst_nr_totally_ind,dprc_cltn_strt_dt,int_cltn_strt_dt,spcl_dprc_strt_dt,ivstmt_sprt_ky,dprc_ky,plnd_useful_lf_yrs_qty,plnd_useful_lf_periods_qty,ordnry_dprc_pct_rt,spcl_dprc_pct_rt,rplm_values_idx,rplm_values_age_idx,vrbl_dprc_portn,changeover_yr_dprc_ky,orgl_useful_lf_yrs_qty,orgl_useful_lf_periods_qty,asst_scrp_vl,asst_acct_annl_vl_last_fy,dprc_strt_yr_prd_scaling,tbl_typ_chg_ind,rvaltn,dprc_ar_deactivated_ind,grp_asst,grp_asst_sb_nr,asser_aqstn_yr_nr,asst_acctng_acquis_mth,optg_readiness_dt,vl_dt_of_last_rtrmnt_for_the_dprc_ar,dprc_ar_dactvn_dt,rvaltn_ky,last_rvaltn_dt,last_idx_used,apc_scrp_vl_pct,dprc_ky_changeover_prd,intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_gmt_dt from ${dbNameConsmtn}.${tgtTbl}""")
      logger.info(f"""select cmpny_cd_mn_asst_nmbr_dprctn_ara_ky,coalesce(lgl_co_cd,'') as lgl_co_cd,coalesce(mn_asst_nr,'') as mn_asst_nr,coalesce(asst_sb_nr,'') as asst_sb_nr,coalesce(real_dprc_ar_cd,'') as real_dprc_ar_cd,coalesce(dt_vldty_ends,'') as dt_vldty_ends,dt_vldty_begins,obj_crto,rec_crtn_dt,obj_mdfr,chgd_on,acct_marked_for_dltn_ind,acct_blckd_ind,scn_lyt_asst_acctng,ngtv_values_allwd_ind,low_vl_asst_qty_amt_chk,depreciate_mn_asst_nr_totally_ind,dprc_cltn_strt_dt,int_cltn_strt_dt,spcl_dprc_strt_dt,ivstmt_sprt_ky,dprc_ky,plnd_useful_lf_yrs_qty,plnd_useful_lf_periods_qty,ordnry_dprc_pct_rt,spcl_dprc_pct_rt,rplm_values_idx,rplm_values_age_idx,vrbl_dprc_portn,changeover_yr_dprc_ky,orgl_useful_lf_yrs_qty,orgl_useful_lf_periods_qty,asst_scrp_vl,asst_acct_annl_vl_last_fy,dprc_strt_yr_prd_scaling,tbl_typ_chg_ind,rvaltn,dprc_ar_deactivated_ind,grp_asst,grp_asst_sb_nr,asser_aqstn_yr_nr,asst_acctng_acquis_mth,optg_readiness_dt,vl_dt_of_last_rtrmnt_for_the_dprc_ar,dprc_ar_dactvn_dt,rvaltn_ky,last_rvaltn_dt,last_idx_used,apc_scrp_vl_pct,dprc_ky_changeover_prd,intgtn_fbrc_msg_id,src_sys_upd_ts,src_sys_ky,lgcl_dlt_ind,ins_gmt_ts,upd_gmt_ts,src_sys_extrc_gmt_ts,src_sys_btch_nr,fl_nm,ld_jb_nr,ins_gmt_dt from ${dbNameConsmtn}.${tgtTbl}""")

      if (!existingDmnsnDF.head(1).isEmpty) {
        //************************For incremental load*****************************//
        var overWritePrtition = existingDmnsnDF.join(
          incrementalDf,
          existingDmnsnDF("lgl_co_cd") === incrementalDf("lgl_co_cd") &&
            existingDmnsnDF("mn_asst_nr") === incrementalDf("mn_asst_nr") &&
            existingDmnsnDF("asst_sb_nr") === incrementalDf("asst_sb_nr") &&
            existingDmnsnDF("real_dprc_ar_cd") === incrementalDf("real_dprc_ar_cd") &&
            existingDmnsnDF("dt_vldty_ends") === incrementalDf("dt_vldty_ends")).select(existingDmnsnDF("ins_gmt_dt").cast(StringType)).
          distinct.collect.map(row => row.getString(0).toString()).toSeq
        
        if (overWritePrtition.size == 0) { overWritePrtition = incrementalDf.select(incrementalDf("ins_gmt_dt").cast(StringType)).distinct.collect.map(row => row.getString(0).toString()).toSeq }

        val dmnsnNonMatchDF = existingDmnsnDF.where(existingDmnsnDF("ins_gmt_dt").isin(overWritePrtition: _*)).join(
          incrementalDf,
          existingDmnsnDF("lgl_co_cd") === incrementalDf("lgl_co_cd") &&
            existingDmnsnDF("mn_asst_nr") === incrementalDf("mn_asst_nr") &&
            existingDmnsnDF("asst_sb_nr") === incrementalDf("asst_sb_nr") &&
            existingDmnsnDF("real_dprc_ar_cd") === incrementalDf("real_dprc_ar_cd") &&
            existingDmnsnDF("dt_vldty_ends") === incrementalDf("dt_vldty_ends"), "left_anti")

        val finalDmnsnDF = incrementalDf.union(dmnsnNonMatchDF)

        finalDmnsnDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + tgtTbl)

      } else {
        //**************************For initial load*****************************//
        incrementalDf.write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + tgtTbl)
      }
      /* ************************ selecting target count ****************************************** */
      tgtCount = incrementalDf.count().toInt
      logger.info("target count: " + tgtCount)

      logger.info("+++++++++++############# Load Successful #############+++++++++++")
      auditObj.setAudTgtRowCount(tgtCount)
      auditObj.setAudJobStatusCode("success")
    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("failed")
    }
    /* ********************************************* Completion audit entries ************************** */

    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    incrementalDf.unpersist()
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) {
      System.exit(1)
    }

  }
}

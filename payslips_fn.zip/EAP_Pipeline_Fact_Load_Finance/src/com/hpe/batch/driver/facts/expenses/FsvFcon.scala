package com.hpe.batch.driver.facts.expenses

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import org.apache.hadoop.fs.{FileSystem, Path}
object FsvFcon extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = "hdfs://EAP-PROD/user/srvc_nextgen_hpro/properties/expense_fact.properties"
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  println("akhila")
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val ins_ts=Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
  val upd_ts=null
  val ld_jb_id=ld_jb_nr+'_'+batchId
  logger.info("First log")

import spark.implicits._
  try {
  val df = spark.sql("""select fsv_level_1_desc,fsv_level_2_desc,fsv_level_3_desc,
fsv_level_4_desc,fsv_level_5_desc,fsv_level_6_desc,fsv_level_7_desc,fsv_level_8_desc,
fsv_level_9_desc,fsv_level_10_desc,cast(fsv_account_lower_val as int),
cast(fsv_account_upper_val as int) from ea_common.fsv_FCON_hrchy""")
  var fin_col_list=List[String]()
  for (i<-df.collect()){
    val fsv_level_1_desc=i.getAs[String](0)
    val fsv_level_2_desc=i.getAs[String](1)
    val fsv_level_3_desc=i.getAs[String](2)
    val fsv_level_4_desc=i.getAs[String](3)
    val fsv_level_5_desc=i.getAs[String](4)
    val fsv_level_6_desc=i.getAs[String](5)
    val fsv_level_7_desc=i.getAs[String](6)
    val fsv_level_8_desc=i(7)
    val fsv_level_9_desc=i(8)
    val fsv_level_10_desc=i.getAs[String](9)
    val fsv_account_lower_val=i.getAs[Int](10)
    val fsv_account_upper_val=i.getAs[Int](11)
    println("int values ",fsv_account_lower_val,fsv_account_upper_val)
    if (fsv_account_lower_val==fsv_account_upper_val){
    println("inside int values",fsv_account_lower_val,fsv_account_upper_val)
    val string_lower=fsv_account_lower_val.toString
    val lower="000000"+string_lower
    val string_upper=fsv_account_upper_val.toString
    val upper="000000"+string_upper
    val fin_value=fsv_level_1_desc+'#'+fsv_level_2_desc+'#'+fsv_level_3_desc+'#'+fsv_level_4_desc+'#'+fsv_level_5_desc+'#'+fsv_level_6_desc+'#'+
    fsv_level_7_desc+'#'+fsv_level_8_desc+'#'+fsv_level_9_desc+'#'+fsv_level_10_desc+'#'+lower+'#'+upper
    println("inside if loop",fin_value)
    fin_col_list=fin_value::fin_col_list
    }
    else{
      for (i<-fsv_account_lower_val to fsv_account_upper_val){
        println("inside else loop int values",i)
        val string_i=i.toString
        val tmp="000000"+string_i
        val fin_value=fsv_level_1_desc+'#'+fsv_level_2_desc+'#'+fsv_level_3_desc+'#'+fsv_level_4_desc+'#'+fsv_level_5_desc+'#'+fsv_level_6_desc+'#'+
    fsv_level_7_desc+'#'+fsv_level_8_desc+'#'+fsv_level_9_desc+'#'+fsv_level_10_desc+'#'+tmp+'#'+tmp
    println("inside if else loop",fin_value)
    fin_col_list=fin_value::fin_col_list
    }
  }
  }
  println("final list",fin_col_list)
  //var tmplist=List(ctry_cd,countrygroup_cd).transpose()
  var fin_df=fin_col_list.toDF("fsv")
  var fin_df_1=fin_df.withColumn("fsv_level_1_desc", split(col("fsv"), "\\#").getItem(0))
  .withColumn("fsv_level_2_desc", split(col("fsv"), "\\#").getItem(1))
  .withColumn("fsv_level_3_desc", split(col("fsv"), "\\#").getItem(2))
  .withColumn("fsv_level_4_desc", split(col("fsv"), "\\#").getItem(3))
  .withColumn("fsv_level_5_desc", split(col("fsv"), "\\#").getItem(4))
  .withColumn("fsv_level_6_desc", split(col("fsv"), "\\#").getItem(5))
  .withColumn("fsv_level_7_desc", split(col("fsv"), "\\#").getItem(6))
  .withColumn("fsv_level_8_desc", split(col("fsv"), "\\#").getItem(7))
  .withColumn("fsv_level_9_desc", split(col("fsv"), "\\#").getItem(8))
  .withColumn("fsv_level_10_desc", split(col("fsv"), "\\#").getItem(9))
  .withColumn("fsv_account_lower_val", split(col("fsv"), "\\#").getItem(10))
  .withColumn("fsv_account_upper_val", split(col("fsv"), "\\#").getItem(11))
  .withColumn("ins_ts", current_timestamp)
  var fin_df_2=fin_df_1.drop("fsv")
  fin_df_2.show(10,false)
  fin_df_2.createOrReplaceTempView("fsv_fcon_temptable")
  val fs = FileSystem.get(spark.sparkContext.hadoopConfiguration)
  val outPutPath = new Path("/EA/common/consumption/fsv_fcon_hrchy_dlt")
  if (fs.exists(outPutPath))
  fs.delete(outPutPath, true)
  println("deleted")
  spark.sql("drop table if exists ea_common.fsv_fcon_hrchy_dlt")
  spark.sql("""
    CREATE EXTERNAL TABLE ea_common.fsv_fcon_hrchy_dlt(
   fsv_level_1_desc varchar(45),
   fsv_level_2_desc varchar(45),
   fsv_level_3_desc varchar(45),
   fsv_level_4_desc varchar(45),
   fsv_level_5_desc varchar(45),
   fsv_level_6_desc varchar(45),
   fsv_level_7_desc varchar(45),
   fsv_level_8_desc varchar(45),
   fsv_level_9_desc varchar(45),
   fsv_level_10_desc varchar(45),
   fsv_account_lower_val varchar(10),
   fsv_account_upper_val varchar(10),
   ins_ts timestamp)
ROW FORMAT SERDE
  'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
 STORED AS INPUTFORMAT
   'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
 OUTPUTFORMAT
   'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'
 LOCATION
   'hdfs://EAP-PROD/EA/common/consumption/fsv_fcon_hrchy_dlt'
    """)
  spark.sql("insert into table ea_common.fsv_fcon_hrchy_dlt select * from fsv_fcon_temptable");
  //df.show(10,false)
  val transformeSrcdDF = spark.sql("""select count(*) from """ + "ea_common.fsv_fcon_hrchy_dlt")
  

  val src_count = transformeSrcdDF.count().toInt
var loadStatus =src_count


    //************************Completion Audit Entries*******************************//
    val tgt_count = fin_df_2.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    auditObj.setAudObjectName("fsv_FCON_hrchy")
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus!=0) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    //auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } 
  
  catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}

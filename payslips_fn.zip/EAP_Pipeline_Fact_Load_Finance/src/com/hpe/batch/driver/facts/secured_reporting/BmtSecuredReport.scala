package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object BmtSecuredReport extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val logger = Logger.getLogger(getClass.getName)
  logger.info("//*************************** Log start for BmtSecuredReport.scala **************************//")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  logger.info("+++++++++++++############## properties file:" + propertiesFilePath)
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  logger.info("+++++++++++++############## environment properties file:" + envPropertiesFilePath)
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val objName = propertiesObject.getObjName()
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val tgtTableName = propertiesObject.getTgtTblConsmtn().trim()
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val dbCommonNameR2_2 = propertiesObject.getDbName().trim().split(",")(0)
  val dbCommonNameR2_3 = propertiesObject.getDbName().trim().split(",")(1)
  
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  logger.info("+++++++++++++############## audit table:" + auditTbl)
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  if (sqlCon == null) {
    logger.error("+++++++++++++############## MYSQL Connection Not Established")
    throw new NullPointerException("Please update tgtTblConsmtn properties to add database name!")
  }

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  try {

    Utilities.paramCheck(Seq(objName, ld_jb_nr, srcTableName, dbCommonNameR2_2,dbCommonNameR2_3, tgtTableName))

    //***************************Audit Properties********************************//
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_secured_bmt_fact_load")
    auditObj.setAudObjectName(objName)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)

    if (tgtTableName.split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    // Filter condition for Current, Future and previous quarter(only till first month of current quarter) data
    val cal = Calendar.getInstance()
    val Year = cal.get(Calendar.YEAR)
    val Month1 = cal.get(Calendar.MONTH)
    var Month = Month1 + 1
    val prev_year = Year - 1
    val prev_year_str = prev_year.toString()
    val year1 = Year + 1
    var Month_val = Month.toString()
    var year_val = Year.toString()
    var next_year = year1.toString()

    var fscl_yr_prd = ""

    if ((Month_val == "11") || (Month_val == "12")) {
      if (Month_val == "11") {
        fscl_yr_prd = year_val + "4"
      } else {
        fscl_yr_prd = next_year + "1"
      } //year+Q
    } else if (Month_val == "1") { fscl_yr_prd = year_val + "1" }

    else if ((Month_val == "2") || (Month_val == "3") || (Month_val == "4")) {
      if (Month_val == "2") {
        fscl_yr_prd = year_val + "1"
      } else {
        fscl_yr_prd = year_val + "2"
      }
    } else if ((Month_val == "5") || (Month_val == "6") || (Month_val == "7")) {
      if (Month_val == "5") {
        fscl_yr_prd = year_val + "2"
      } else {
        fscl_yr_prd = year_val + "3"
      }
    } else if ((Month_val == "8") || (Month_val == "9") || (Month_val == "10")) {
      if (Month_val == "8") {
        fscl_yr_prd = year_val + "3"
      } else {
        fscl_yr_prd = year_val + "4"
      }
    }
    val fscl_yr_prd_con = fscl_yr_prd.toInt

    logger.info("****************fiscal period value after calculation:" + fscl_yr_prd_con)
    
    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    val hive_tgt_table = consmptnTable

    val tgtTblName = dbNameConsmtn + "." + consmptnTable

    val bmtcntrynm = spark.sql(s"select * from ${dbCommonNameR2_3}.bmt_cntry_nm_dmnsn order by rl_id asc")

    val bmtcntrynmrefined = bmtcntrynm.withColumn("input_table", when(col("inp_tl") === "NA", col("inp_fld")).
      otherwise(concat(col("inp_tl"), lit("."), col("inp_fld")))).withColumn("output_field", when(col("opt_tbl") === "NA", col("opt_fld")).
      otherwise(concat(col("opt_tbl"), lit("."), col("opt_fld"))))

    val bmtcntrynmds = bmtcntrynmrefined.collect.map(c => " when " + c(19) + " " + c(5) + " (" + c(6) + ") then " + c(20))

    var countryname = "case"

    for (i <- 0 to (bmtcntrynmds.length - 1)) { if (bmtcntrynmds(i).contains("'Unknown GEO'")) countryname += " else 'unkown geo' end" else countryname += bmtcntrynmds(i) }

    val finalCountry = countryname.replace("bmt_pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd", "ord_ins_dmnsn.pft_cntr_cd")

    spark.sql(s"""select * from ${dbCommonNameR2_3}.bmt_ord_ins_dmnsn""").write.mode("append").format("orc").insertInto(dbCommonNameR2_3 + ".bmt_ord_ins_dmnsn_merged")

    val ordInsSelectDf = spark.sql(s"""
  SELECT distinct 
	crc64(LOWER(CONCAT(COALESCE(ord_ins_dmnsn.sls_ord_id, ""),COALESCE(ord_ins_dmnsn.so_itm_id,""),COALESCE(ord_ins_dmnsn.ins_gmt_ts,"")))) AS secrd_rpt_fact_ky,
	crc32(COALESCE(ord_ins_dmnsn.end_cust_prty_id,
	"")) AS mdm_cust_ky,
	crc32(LOWER(COALESCE(ord_ins_dmnsn.pft_cntr_cd, ""))) AS pft_cntr_ky,
	crc32(LOWER(COALESCE(ord_ins_dmnsn.sgm_cd, ""))) AS mgmt_grphy_unt_ky,
	crc32(LOWER(COALESCE(ord_ins_dmnsn.sls_ord_id, ""))) AS ord_hddr_ky,
	ord_ins_dmnsn.sls_ord_id AS sls_ord_id,
	ord_ins_dmnsn.so_itm_id AS sls_ord_ln_itm_id,
	ord_ins_dmnsn.mkt_rte_cd AS mkt_rte_cd,
  CASE
		WHEN ln_itm_src_typ_cd IS NULL THEN 'BMT'
		ELSE UPPER(ln_itm_src_typ_cd)
  END AS src_sys_cd,
	dcmt_curr AS ord_dcmnt_curr_cd,
	fncl_own AS fncl_ownr_cd,
	ord_ins_dmnsn.sldt_prty_id AS sld_to_cd,
	ord_ins_dmnsn.shp_to_prty_id AS shp_to_cd,
	ord_ins_dmnsn.end_cust_prty_id AS end_cust_cd,
	dcmt_cuur_amt AS ord_itm_nt_vl_amt,
	nt_usd_amt AS ord_itm_nt_vl_usd_amt,
	ord_ins_dmnsn.pft_cntr_cd AS prft_cntr_cd,
	ord_ins_dmnsn.sgm_cd AS sgmtl_rptg_cd,
	segment_std_hrchy.sg_level_3 AS sgm_lvl_2,
	segment_std_hrchy.sg_level_4 AS sgm_lvl_3,
	segment_std_hrchy.sg_level_5 AS sgm_lvl_4,
	segment_std_hrchy.sg_level_6 AS sgm_lvl_5,
	segment_std_hrchy.sg_level_7 AS sgm_lvl_6,
	segment_std_hrchy.sg_level_8 AS sgm_lvl_7,
	CASE
		WHEN pn_disa_flg_dmnsn.sld_to_id IS NULL THEN 'N'
		ELSE 'Y'
  END AS disa_ind,
	CASE
		WHEN dscnt_flg IS NULL THEN 'N'
		ELSE dscnt_flg
  END AS dscnt_ind,
	CASE
		WHEN hw_fc_flg IS NULL THEN 'N'
		ELSE hw_fc_flg
  END AS grn_lake_ind,
	--CASE WHEN pn_greenlake_flg_dmnsn.greenlake_flg_cd IS NULL THEN 'N' ELSE 'Y' END as grn_lake_ind,  
  CASE
		WHEN UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.source) LIKE '%DXC%' THEN 'Y'
		ELSE 'N'
  END AS dxc_ind,
	CASE
		WHEN UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.source) LIKE '%HPC%' THEN 'Y'
		ELSE 'N'
  END AS hpc_ind,
	CASE
		WHEN UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.source) LIKE '%Hyperconverged%' THEN 'Y'
		ELSE 'N'
  END AS hyperconverged_ind,
	CASE
		WHEN icoem_flg IS NULL THEN 'N'
		ELSE icoem_flg
  END AS icoem_ind,
	ptfl_dmnsn_li1 AS ln_itm_1_cd,
	ptfl_dmnsn_li2 AS ln_itm_2_cd,
	ptfl_dmnsn_li3 AS ln_itm_3_cd,
	ptfl_dmnsn_li4 AS ln_itm_4_ofr_cd,
	ptfl_dmnsn_li5 AS ln_itm_5_sla_cvrg_cd,
	ptfl_dmnsn_li6 AS ln_itm_6_typ_cd,
	ptfl_dmnsn_li7 AS ln_itm_7_durtn_cd,
	slng_mtn_dmnsn_li1 AS slng_mtn_lvl_1_cd,
	slng_mtn_dmnsn_li2 AS slng_mtn_lvl_2_cd,
	slng_mtn_dmnsn_li3 AS slng_mtn_lvl_3_cd,
	slng_mtn_dmnsn_li4 AS slng_mtn_lvl_4_cd,
	slng_mtn_dmnsn_li5 AS slng_mtn_lvl_5_cd,
	eg_hw_dmnsn_li1 AS hw_lvl_1_cd,
	eg_hw_dmnsn_li2 AS hw_lvl_2_cd,
	eg_hw_dmnsn_li3 AS hw_lvl_3_cd,
	eg_hw_dmnsn_li4 AS hw_lvl_4_cd,
	eg_hw_dmnsn_li5 AS hw_lvl_5_cd,
	eg_hw_dmnsn_li6 AS hw_lvl_6_cd,
	bus_cat_dmnsn_li1 AS bsn_cgy_lvl_1_cd,
	bus_cat_dmnsn_li2 AS bsn_cgy_lvl_2_cd,
	bus_cat_dmnsn_li3 AS bsn_cgy_lvl_3_cd,
	NULL AS cntrct_id,
	NULL AS pob_id,
	NULL AS recon_ky_cd,
	CAST(ord_ins_dmnsn.fscl_yr_nr AS VARCHAR(4)) AS fscl_yr_nr,
	CASE
		WHEN CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4)) IN ('1','2','3','4','5','6','7','8','9') THEN CONCAT ('0',		CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4)) )
		ELSE CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4))
  END AS fscl_prd_nr,
	CONCAT ('FY',
	CAST(ord_ins_dmnsn.fscl_yr_nr AS VARCHAR(4)),
	'-',
	CASE
		WHEN CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4)) IN ('1','2','3','4','5','6','7','8','9') THEN CONCAT ('0',	CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4)) )
		ELSE CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4))
  END ) AS fscl_yr_prd_cd,
	CASE
		WHEN CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4)) IN ('1','2','3') THEN 'Q1'
		WHEN CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4)) IN ('4','5','6') THEN 'Q2'
		WHEN CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4)) IN ('7','8','9') THEN 'Q3'
		WHEN CAST(ord_ins_dmnsn.pstg_prd_nr AS VARCHAR(4)) IN ('10','11','12') THEN 'Q4'
		ELSE NULL
  END AS fscl_qtr_nr,
  dcmt_cuur_amt as cp_nt_rvn_amt,
  nt_usd_amt as cp_nt_rvn_usd_amt,
  CURRENT_TIMESTAMP as ins_ts,
  NULL as scra_cgy_cd,
  ord_ins_dmnsn.pstg_prd_nr as pstg_prd_nr,
  'N' as fnc_adjmt_ind,
  'Y' as fnc_insrt_ind,
  ord_ins_dmnsn.usg_nm as fnc_insrt_rsn_cd,
  ord_ins_dmnsn.end_cust_prty_id as cp_end_cust_prty_id,
  prty.prty_nm as cp_end_cust_prty_nm,
  ord_ins_dmnsn.mkt_rte_cd as cp_rtm_nm,
  ord_ins_dmnsn.sldt_prty_id as cp_sldt_prty_id,
  ord_ins_dmnsn.shp_to_prty_id as cp_shpt_prty_id,
  ord_ins_dmnsn.pft_cntr_cd as cp_prft_ctr_cd,
  ord_ins_dmnsn.sgm_cd as cp_segment_cd,
  ord_ins_dmnsn.nt_dlr_amt as cp_ndp_usd_amt,
  ord_ins_dmnsn.grs_rvn_amt as cp_grs_usd_amt,
  ord_ins_dmnsn.grs_rvn_amt as cp_grs_rvn_usd_amt,
  ord_ins_dmnsn.entrs_std_amt as cp_entprs_std_cst_usd_amt,
  ord_ins_dmnsn.sls_amt as cp_tot_cst_of_sls_usd_amt,
  ord_ins_dmnsn.unt_qty as cp_unit_qty,
  ord_ins_dmnsn.bs_qty as cp_base_qty,
  ord_ins_dmnsn.usg_nm as use_nm,
  ord_ins_dmnsn.rvn_rcgn_cgy_cd as cp_rev_recgn_cgy_cd,
  CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.rev_hd_cd ELSE 'Load' END as cp_rev_hdr_nm,
  ord_ins_dmnsn.rvn_rcgn_cgy_cd as rvn_rcgn_cgy_cd,  
  CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.incd_excld_cd ELSE NULL END as cp_incd_excld,
  CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.rev_hd_cd ELSE 'Load' END as rev_hd_cd,
  ${finalCountry} as ctry_nm,
  fncl_frmwk_ln_itm_li0 as FF_LI0,
  fncl_frmwk_ln_itm_li1 as FF_LI1,
  fncl_frmwk_ln_itm_li2 as FF_LI2,
  fncl_frmwk_ln_itm_li3 as FF_LI3,
  fncl_frmwk_ln_itm_li4 as FF_LI4,
  fncl_frmwk_ln_itm_li5 as FF_LI5,
  fncl_frmwk_ln_itm_li6 as FF_LI6,
  fncl_frmwk_ln_itm_li7 as FF_LI7,
  gtm_dmnsn as cust_sgmt_gtm,
  us_geo_sgmt as us_geo_sgmt,
  hst_grp_nm as hst_grp_nm,
  mru_cd as mru_cd,
  cst_pl as cst_pl,
  ord_ins_dmnsn.src_sys_upd_ts as src_sys_upd_ts,
  ord_ins_dmnsn.src_sys_ky as src_sys_ky,
  ord_ins_dmnsn.lgcl_dlt_ind as lgcl_dlt_ind,
  ord_ins_dmnsn.ins_gmt_ts as ins_gmt_ts,
  ord_ins_dmnsn.upd_gmt_ts as upd_gmt_ts,
  ord_ins_dmnsn.src_sys_extrc_gmt_ts as src_sys_extrc_gmt_ts,
  ord_ins_dmnsn.src_sys_btch_nr as src_sys_btch_nr,
  ord_ins_dmnsn.fl_nm as fl_nm,
  ord_ins_dmnsn.ld_jb_nr as ld_jb_nr
  FROM
	  ${dbCommonNameR2_3}.bmt_ord_ins_dmnsn_merged ord_ins_dmnsn
  LEFT OUTER JOIN ${dbCommonNameR2_3}.bmt_rev_rec_cgy_snp_dmnsn rev_rec_cgy_snp_dmnsn ON
	  ord_ins_dmnsn.rvn_rcgn_cgy_cd = rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd
  LEFT OUTER JOIN ${dbCommonNameR2_2}.bmt_pn_disa_flg_dmnsn pn_disa_flg_dmnsn ON
	  ord_ins_dmnsn.pft_cntr_cd = pn_disa_flg_dmnsn.pft_cntr_cd
	  AND ord_ins_dmnsn.sldt_prty_id = pn_disa_flg_dmnsn.sld_to_id
  LEFT OUTER JOIN ${dbCommonNameR2_3}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn pn_so_hypr_hpc_dxc_flg_dmnsn_dxc ON
	  ord_ins_dmnsn.sls_ord_id = pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.sls_ord_id
	  AND UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.source) LIKE '%DXC%'
  LEFT OUTER JOIN ${dbCommonNameR2_3}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn pn_so_hypr_hpc_dxc_flg_dmnsn_hpc ON
	  ord_ins_dmnsn.sls_ord_id = pn_so_hypr_hpc_dxc_flg_dmnsn_hpc.sls_ord_id
	  AND UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_hpc.source) LIKE '%HPC%'
  LEFT OUTER JOIN ${dbCommonNameR2_3}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn pn_so_hypr_hpc_dxc_flg_dmnsn_hyp ON
	  ord_ins_dmnsn.sls_ord_id = pn_so_hypr_hpc_dxc_flg_dmnsn_hyp.sls_ord_id
	  AND UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_hyp.source) LIKE '%HYPERCONVERGED%'
  LEFT OUTER JOIN ${dbCommonNameR2_2}.segment_std_hrchy segment_std_hrchy ON
	  segment_std_hrchy.sg_level_8 = ord_ins_dmnsn.sgm_cd
  LEFT OUTER JOIN ${dbCommonNameR2_2}.prty_fact prty ON
	  ord_ins_dmnsn.end_cust_prty_id = prty.mdm_id
	  --left outer join ${dbCommonNameR2_3}.bmt_pn_greenlake_flg_dmnsn pn_greenlake_flg_dmnsn 
	  --on ord_ins_dmnsn.prft_cntr_cd = pn_greenlake_flg_dmnsn.pft_cntr_cd 
	  --and (pn_greenlake_flg_dmnsn.bsn_cgy_lvl_2_cd = ord_ins_dmnsn.bsn_cgy_lvl_2_cd 
	  --or ord_ins_dmnsn.bsn_cgy_lvl_2_cd = "all" ) 
  LEFT OUTER JOIN ${dbCommonNameR2_3}.bmt_sab_cut_off_fd_srtr_dmnsn sab_cut_off_fd_srtr_dmnsn ON
	  sab_cut_off_fd_srtr_dmnsn.fscl_yr_qtr_dsply_cd = concat( ord_ins_dmnsn.fscl_yr_nr,
	  "-" ,
	  CASE
		  WHEN CAST(ord_ins_dmnsn.fscl_yr_nr AS VARCHAR(4)) IN ('1','2','3') THEN 'Q1'
		  WHEN CAST(ord_ins_dmnsn.fscl_yr_nr AS VARCHAR(4)) IN ('4','5','6') THEN 'Q2'
		  WHEN CAST(ord_ins_dmnsn.fscl_yr_nr AS VARCHAR(4)) IN ('7','8','9') THEN 'Q3'
		  WHEN CAST(ord_ins_dmnsn.fscl_yr_nr AS VARCHAR(4)) IN ('10','11','12') THEN 'Q4'
		  ELSE NULL
    END )
	  AND sab_cut_off_fd_srtr_dmnsn.sgm_cd = ord_ins_dmnsn.sgm_cd
  LEFT OUTER JOIN ${dbCommonNameR2_3}.bmt_sgm_alt_hrchy_dmnsn bmt_sgm_alt_hrchy_dmnsn ON
	  ord_ins_dmnsn.sgm_cd = bmt_sgm_alt_hrchy_dmnsn.sgm_cd
  LEFT OUTER JOIN ${dbCommonNameR2_3}.bmt_pft_cntr_alt_hrchy_dmnsn bmt_pft_cntr_alt_hrchy_dmnsn ON
	  ord_ins_dmnsn.pft_cntr_cd = bmt_pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd
  LEFT OUTER JOIN ${dbCommonNameR2_3}.bmt_cust_alt_hrchy_dmnsn bmt_cust_alt_hrchy_dmnsn ON
	  ord_ins_dmnsn.sldt_prty_id = bmt_cust_alt_hrchy_dmnsn.prty_id
""")

    ordInsSelectDf.createOrReplaceTempView("bmtTempTable1")

    val ordInsCrrntDf = spark.sql(s"""select * from bmtTempTable1 where CAST(concat(fscl_yr_nr, substr(fscl_qtr_nr,2,1)) AS INT) >= """ + fscl_yr_prd_con + """ or fscl_yr_nr is NULL""")

    val tgtTempColumns = spark.sql(s"select * from  ${dbNameConsmtn}.secrd_rpt_bmt_filter_tmp limit 0").columns

    val dataTempLoadDF = ordInsCrrntDf.select(Utilities.loadSelectExpr(ordInsCrrntDf.columns, tgtTempColumns): _*)

    dataTempLoadDF.repartition(10).write.mode("Overwrite").insertInto(dbNameConsmtn + ".secrd_rpt_bmt_filter_tmp")

    val filteredDf = spark.sql(s"select * from ${dbNameConsmtn}.secrd_rpt_bmt_filter_tmp").repartition(col("sls_ord_id")).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.info("**********count in filteredDf" + filteredDf.count.toInt)

    val filteredDf_NotNull = filteredDf.filter("sls_ord_id is not null")
    val filteredDf_NullOnly = filteredDf.filter("sls_ord_id is null")

    val pnNnFcsDmnsnDf = spark.sql(s"""select a.* from (select tbl.* ,row_number() over (partition by tbl.ba_cd,tbl.prft_ctr_cd,tbl.sgmt_lvl_2_cd,tbl.sgmt_lvl_3_cd,tbl.sgmt_lvl_4_cd,tbl.sgmt_lvl_5_cd order by tbl.inrn_id) seq_id 
    from ${dbCommonNameR2_3}.bmt_pn_nn_fcus_flg_ord_dmnsn tbl) a where a.seq_id=1""")

    val pnNnFcsDmnsnDf1 = spark.sql(s"""select a.* from (select tbl.*, row_number() over (partition by tbl.ba_cd,tbl.prft_ctr_cd,tbl.sgmt_lvl_2_cd,tbl.sgmt_lvl_3_cd,tbl.sgmt_lvl_4_cd,tbl.sgmt_lvl_5_cd,tbl.ff_l15_cd order by tbl.inrn_id) seq_id 
    from ${dbCommonNameR2_3}.bmt_pn_nn_fcus_flg_actl_dmnsn tbl) a where a.seq_id=1""")

    val bmtSelectDf_NotNull = filteredDf_NotNull.select("sls_ord_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5").distinct
    val bmtSelectDf_Null = filteredDf_NullOnly.select("sls_ord_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5").distinct

    /*
     * Joining SERP base table with Point Next BMT Step 1
     *
     * 1.a Match the identified joining column between two dataset
     * 1.b if value all is passed then data set should be joined on all the available records
     */

    val ordInsJoinpnNnFcsStgDF_NN = bmtSelectDf_NotNull.alias("bmtCol").join(
      (pnNnFcsDmnsnDf).alias("pnNnFcsDmnsnCol"),
      (bmtSelectDf_NotNull("prft_cntr_cd") === pnNnFcsDmnsnDf("prft_ctr_cd") || pnNnFcsDmnsnDf("prft_ctr_cd") === "all")
        && (bmtSelectDf_NotNull("sgm_lvl_2") === pnNnFcsDmnsnDf("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf("sgmt_lvl_2_cd") === "all")
        && (bmtSelectDf_NotNull("sgm_lvl_3") === pnNnFcsDmnsnDf("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf("sgmt_lvl_3_cd") === "all")
        && (bmtSelectDf_NotNull("sgm_lvl_4") === pnNnFcsDmnsnDf("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf("sgmt_lvl_4_cd") === "all")
        && (bmtSelectDf_NotNull("sgm_lvl_5") === pnNnFcsDmnsnDf("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf("sgmt_lvl_5_cd") === "all")
        && (bmtSelectDf_NotNull("sgm_lvl_2") != pnNnFcsDmnsnDf("sgmt_lvl_2_cd_exclude"))
        && (bmtSelectDf_NotNull("sgm_lvl_3") != pnNnFcsDmnsnDf("sgmt_lvl_3_cd_exclude"))
        && (bmtSelectDf_NotNull("sgm_lvl_4") != pnNnFcsDmnsnDf("sgmt_lvl_4_cd_exclude"))
        && (bmtSelectDf_NotNull("sgm_lvl_5") != pnNnFcsDmnsnDf("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf("inrn_id").isNotNull).select("bmtCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry", "pnNnFcsDmnsnCol.inrn_id").distinct

    val ordInsJoinpnNnFcsDeDupDF_NN = Utilities.getLatestRecs(ordInsJoinpnNnFcsStgDF_NN, List("sls_ord_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5"), List("inrn_id"))
    ordInsJoinpnNnFcsDeDupDF_NN.persist(StorageLevel.MEMORY_AND_DISK)

    /*
     * Joining SERP base table with Point Next BMT Step 2
     *
     * 2.a join back the data set prepared in
     * 2.b if value all is passed then data set should be joined on all the available records
     */

    var ordInsJoinpnNnFcsFinalDF_NN = filteredDf_NotNull.alias("serpJoindCol").join(
      (ordInsJoinpnNnFcsDeDupDF_NN).alias("pnNnFcsDmnsnCol"),
      filteredDf_NotNull("sls_ord_id") === ordInsJoinpnNnFcsDeDupDF_NN("sls_ord_id")
        && ((filteredDf_NotNull("prft_cntr_cd").isNull && ordInsJoinpnNnFcsDeDupDF_NN("prft_cntr_cd").isNull) || filteredDf_NotNull("prft_cntr_cd") === ordInsJoinpnNnFcsDeDupDF_NN("prft_cntr_cd"))
        && ((filteredDf_NotNull("sgm_lvl_2").isNull && ordInsJoinpnNnFcsDeDupDF_NN("sgm_lvl_2").isNull) || filteredDf_NotNull("sgm_lvl_2") === ordInsJoinpnNnFcsDeDupDF_NN("sgm_lvl_2"))
        && ((filteredDf_NotNull("sgm_lvl_3").isNull && ordInsJoinpnNnFcsDeDupDF_NN("sgm_lvl_3").isNull) || filteredDf_NotNull("sgm_lvl_3") === ordInsJoinpnNnFcsDeDupDF_NN("sgm_lvl_3"))
        && ((filteredDf_NotNull("sgm_lvl_4").isNull && ordInsJoinpnNnFcsDeDupDF_NN("sgm_lvl_4").isNull) || filteredDf_NotNull("sgm_lvl_4") === ordInsJoinpnNnFcsDeDupDF_NN("sgm_lvl_4"))
        && ((filteredDf_NotNull("sgm_lvl_5").isNull && ordInsJoinpnNnFcsDeDupDF_NN("sgm_lvl_5").isNull) || filteredDf_NotNull("sgm_lvl_5") === ordInsJoinpnNnFcsDeDupDF_NN("sgm_lvl_5")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry")

    ordInsJoinpnNnFcsFinalDF_NN = ordInsJoinpnNnFcsFinalDF_NN.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_ord")

    //val finalDf1Tbl = finalDf1
    val bmtSelectDf = ordInsJoinpnNnFcsFinalDF_NN.select("sls_ord_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "FF_LI5").distinct

    var ordInsJoinpnNnFcsSecuredStgDF_NN = bmtSelectDf.alias("bmtJoindCol1").join(
      broadcast(pnNnFcsDmnsnDf1).alias("pnNnFcsDmnsnCol1"),
      (bmtSelectDf("prft_cntr_cd") === pnNnFcsDmnsnDf1("prft_ctr_cd") || pnNnFcsDmnsnDf1("prft_ctr_cd") === "all")
        && (bmtSelectDf("sgm_lvl_2") === pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") === "all")
        && (bmtSelectDf("sgm_lvl_3") === pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") === "all")
        && (bmtSelectDf("sgm_lvl_4") === pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") === "all")
        && (bmtSelectDf("sgm_lvl_5") === pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") === "all")
        && (bmtSelectDf("FF_LI5") === pnNnFcsDmnsnDf1("ff_l15_cd") || pnNnFcsDmnsnDf1("ff_l15_cd") === "all")
        && (bmtSelectDf("sgm_lvl_2") != pnNnFcsDmnsnDf1("sgmt_lvl_2_cd_exclude"))
        && (bmtSelectDf("sgm_lvl_3") != pnNnFcsDmnsnDf1("sgmt_lvl_3_cd_exclude"))
        && (bmtSelectDf("sgm_lvl_4") != pnNnFcsDmnsnDf1("sgmt_lvl_4_cd_exclude"))
        && (bmtSelectDf("sgm_lvl_5") != pnNnFcsDmnsnDf1("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf1("inrn_id").isNotNull).select("bmtJoindCol1.*", "pnNnFcsDmnsnCol1.nn_fcs_cntry", "pnNnFcsDmnsnCol1.inrn_id")

    ordInsJoinpnNnFcsSecuredStgDF_NN = ordInsJoinpnNnFcsSecuredStgDF_NN.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_actl")

    val ordInsJoinpnNnFcsSecuredDeDupDF_NN = Utilities.getLatestRecs(ordInsJoinpnNnFcsSecuredStgDF_NN, List("sls_ord_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "FF_LI5"), List("inrn_id"))

    var ordInsJoinpnNnFcsSecuredFinalDF_NN = ordInsJoinpnNnFcsFinalDF_NN.alias("serpJoindCol").join(
      (ordInsJoinpnNnFcsSecuredDeDupDF_NN).alias("pnNnFcsDmnsnCol"),
      ordInsJoinpnNnFcsFinalDF_NN("sls_ord_id") === ordInsJoinpnNnFcsSecuredDeDupDF_NN("sls_ord_id")
        && ((ordInsJoinpnNnFcsFinalDF_NN("prft_cntr_cd").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NN("prft_cntr_cd").isNull) || ordInsJoinpnNnFcsFinalDF_NN("prft_cntr_cd") === ordInsJoinpnNnFcsSecuredDeDupDF_NN("prft_cntr_cd"))
        && ((ordInsJoinpnNnFcsFinalDF_NN("sgm_lvl_2").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NN("sgm_lvl_2").isNull) || ordInsJoinpnNnFcsFinalDF_NN("sgm_lvl_2") === ordInsJoinpnNnFcsSecuredDeDupDF_NN("sgm_lvl_2"))
        && ((ordInsJoinpnNnFcsFinalDF_NN("sgm_lvl_3").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NN("sgm_lvl_3").isNull) || ordInsJoinpnNnFcsFinalDF_NN("sgm_lvl_3") === ordInsJoinpnNnFcsSecuredDeDupDF_NN("sgm_lvl_3"))
        && ((ordInsJoinpnNnFcsFinalDF_NN("sgm_lvl_4").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NN("sgm_lvl_4").isNull) || ordInsJoinpnNnFcsFinalDF_NN("sgm_lvl_4") === ordInsJoinpnNnFcsSecuredDeDupDF_NN("sgm_lvl_4"))
        && ((ordInsJoinpnNnFcsFinalDF_NN("sgm_lvl_5").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NN("sgm_lvl_5").isNull) || ordInsJoinpnNnFcsFinalDF_NN("sgm_lvl_5") === ordInsJoinpnNnFcsSecuredDeDupDF_NN("sgm_lvl_5"))
        && ((ordInsJoinpnNnFcsFinalDF_NN("FF_LI5").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NN("FF_LI5").isNull) || ordInsJoinpnNnFcsFinalDF_NN("FF_LI5") === ordInsJoinpnNnFcsSecuredDeDupDF_NN("FF_LI5")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry_actl")

    val ordInsJoinpnNnFcsStgDF_NO = bmtSelectDf_Null.alias("bmtCol").join(
      (pnNnFcsDmnsnDf).alias("pnNnFcsDmnsnCol"),
      (bmtSelectDf_Null("prft_cntr_cd") === pnNnFcsDmnsnDf("prft_ctr_cd") || pnNnFcsDmnsnDf("prft_ctr_cd") === "all")
        && (bmtSelectDf_Null("sgm_lvl_2") === pnNnFcsDmnsnDf("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf("sgmt_lvl_2_cd") === "all")
        && (bmtSelectDf_Null("sgm_lvl_3") === pnNnFcsDmnsnDf("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf("sgmt_lvl_3_cd") === "all")
        && (bmtSelectDf_Null("sgm_lvl_4") === pnNnFcsDmnsnDf("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf("sgmt_lvl_4_cd") === "all")
        && (bmtSelectDf_Null("sgm_lvl_5") === pnNnFcsDmnsnDf("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf("sgmt_lvl_5_cd") === "all")
        && (bmtSelectDf_Null("sgm_lvl_2") != pnNnFcsDmnsnDf("sgmt_lvl_2_cd_exclude"))
        && (bmtSelectDf_Null("sgm_lvl_3") != pnNnFcsDmnsnDf("sgmt_lvl_3_cd_exclude"))
        && (bmtSelectDf_Null("sgm_lvl_4") != pnNnFcsDmnsnDf("sgmt_lvl_4_cd_exclude"))
        && (bmtSelectDf_Null("sgm_lvl_5") != pnNnFcsDmnsnDf("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf("inrn_id").isNotNull).select("bmtCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry", "pnNnFcsDmnsnCol.inrn_id").distinct

    val ordInsJoinpnNnFcsDeDupDF_NO = Utilities.getLatestRecs(ordInsJoinpnNnFcsStgDF_NO, List("sls_ord_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5"), List("inrn_id"))
    ordInsJoinpnNnFcsDeDupDF_NO.persist(StorageLevel.MEMORY_AND_DISK)

    var ordInsJoinpnNnFcsFinalDF_NO = filteredDf_NullOnly.alias("serpJoindCol").join(
      (ordInsJoinpnNnFcsDeDupDF_NO).alias("pnNnFcsDmnsnCol"),
      (filteredDf_NullOnly("sls_ord_id").isNull && ordInsJoinpnNnFcsDeDupDF_NO("sls_ord_id").isNull)
        && ((filteredDf_NullOnly("prft_cntr_cd").isNull && ordInsJoinpnNnFcsDeDupDF_NO("prft_cntr_cd").isNull) || filteredDf_NullOnly("prft_cntr_cd") === ordInsJoinpnNnFcsDeDupDF_NO("prft_cntr_cd"))
        && ((filteredDf_NullOnly("sgm_lvl_2").isNull && ordInsJoinpnNnFcsDeDupDF_NO("sgm_lvl_2").isNull) || filteredDf_NullOnly("sgm_lvl_2") === ordInsJoinpnNnFcsDeDupDF_NO("sgm_lvl_2"))
        && ((filteredDf_NullOnly("sgm_lvl_3").isNull && ordInsJoinpnNnFcsDeDupDF_NO("sgm_lvl_3").isNull) || filteredDf_NullOnly("sgm_lvl_3") === ordInsJoinpnNnFcsDeDupDF_NO("sgm_lvl_3"))
        && ((filteredDf_NullOnly("sgm_lvl_4").isNull && ordInsJoinpnNnFcsDeDupDF_NO("sgm_lvl_4").isNull) || filteredDf_NullOnly("sgm_lvl_4") === ordInsJoinpnNnFcsDeDupDF_NO("sgm_lvl_4"))
        && ((filteredDf_NullOnly("sgm_lvl_5").isNull && ordInsJoinpnNnFcsDeDupDF_NO("sgm_lvl_5").isNull) || filteredDf_NullOnly("sgm_lvl_5") === ordInsJoinpnNnFcsDeDupDF_NO("sgm_lvl_5")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry")

    ordInsJoinpnNnFcsFinalDF_NO = ordInsJoinpnNnFcsFinalDF_NO.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_ord")

    //val finalDf1Tbl = finalDf1
    val bmtSelectDf1 = ordInsJoinpnNnFcsFinalDF_NO.select("sls_ord_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "FF_LI5").distinct

    var ordInsJoinpnNnFcsSecuredStgDF_NO = bmtSelectDf1.alias("bmtJoindCol1").join(
      broadcast(pnNnFcsDmnsnDf1).alias("pnNnFcsDmnsnCol1"),
      (bmtSelectDf1("prft_cntr_cd") === pnNnFcsDmnsnDf1("prft_ctr_cd") || pnNnFcsDmnsnDf1("prft_ctr_cd") === "all")
        && (bmtSelectDf1("sgm_lvl_2") === pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") === "all")
        && (bmtSelectDf1("sgm_lvl_3") === pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") === "all")
        && (bmtSelectDf1("sgm_lvl_4") === pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") === "all")
        && (bmtSelectDf1("sgm_lvl_5") === pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") === "all")
        && (bmtSelectDf1("FF_LI5") === pnNnFcsDmnsnDf1("ff_l15_cd") || pnNnFcsDmnsnDf1("ff_l15_cd") === "all")
        && (bmtSelectDf1("sgm_lvl_2") != pnNnFcsDmnsnDf1("sgmt_lvl_2_cd_exclude"))
        && (bmtSelectDf1("sgm_lvl_3") != pnNnFcsDmnsnDf1("sgmt_lvl_3_cd_exclude"))
        && (bmtSelectDf1("sgm_lvl_4") != pnNnFcsDmnsnDf1("sgmt_lvl_4_cd_exclude"))
        && (bmtSelectDf1("sgm_lvl_5") != pnNnFcsDmnsnDf1("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf1("inrn_id").isNotNull).select("bmtJoindCol1.*", "pnNnFcsDmnsnCol1.nn_fcs_cntry", "pnNnFcsDmnsnCol1.inrn_id")

    ordInsJoinpnNnFcsSecuredStgDF_NO = ordInsJoinpnNnFcsSecuredStgDF_NO.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_actl")

    val ordInsJoinpnNnFcsSecuredDeDupDF_NO = Utilities.getLatestRecs(ordInsJoinpnNnFcsSecuredStgDF_NO, List("sls_ord_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "FF_LI5"), List("inrn_id"))

    var ordInsJoinpnNnFcsSecuredFinalDF_NO = ordInsJoinpnNnFcsFinalDF_NO.alias("serpJoindCol").join(
      (ordInsJoinpnNnFcsSecuredDeDupDF_NO).alias("pnNnFcsDmnsnCol"),
      (ordInsJoinpnNnFcsFinalDF_NO("sls_ord_id").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NO("sls_ord_id").isNull)
        && ((ordInsJoinpnNnFcsFinalDF_NO("prft_cntr_cd").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NO("prft_cntr_cd").isNull) || ordInsJoinpnNnFcsFinalDF_NO("prft_cntr_cd") === ordInsJoinpnNnFcsSecuredDeDupDF_NO("prft_cntr_cd"))
        && ((ordInsJoinpnNnFcsFinalDF_NO("sgm_lvl_2").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NO("sgm_lvl_2").isNull) || ordInsJoinpnNnFcsFinalDF_NO("sgm_lvl_2") === ordInsJoinpnNnFcsSecuredDeDupDF_NO("sgm_lvl_2"))
        && ((ordInsJoinpnNnFcsFinalDF_NO("sgm_lvl_3").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NO("sgm_lvl_3").isNull) || ordInsJoinpnNnFcsFinalDF_NO("sgm_lvl_3") === ordInsJoinpnNnFcsSecuredDeDupDF_NO("sgm_lvl_3"))
        && ((ordInsJoinpnNnFcsFinalDF_NO("sgm_lvl_4").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NO("sgm_lvl_4").isNull) || ordInsJoinpnNnFcsFinalDF_NO("sgm_lvl_4") === ordInsJoinpnNnFcsSecuredDeDupDF_NO("sgm_lvl_4"))
        && ((ordInsJoinpnNnFcsFinalDF_NO("sgm_lvl_5").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NO("sgm_lvl_5").isNull) || ordInsJoinpnNnFcsFinalDF_NO("sgm_lvl_5") === ordInsJoinpnNnFcsSecuredDeDupDF_NO("sgm_lvl_5"))
        && ((ordInsJoinpnNnFcsFinalDF_NO("FF_LI5").isNull && ordInsJoinpnNnFcsSecuredDeDupDF_NO("FF_LI5").isNull) || ordInsJoinpnNnFcsFinalDF_NO("FF_LI5") === ordInsJoinpnNnFcsSecuredDeDupDF_NO("FF_LI5")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry_actl")

    val bmtFinal = ordInsJoinpnNnFcsSecuredFinalDF_NN.union(ordInsJoinpnNnFcsSecuredFinalDF_NO)

    val tgtColumns = spark.sql("select * from " + tgtTableName + " limit 0").columns

    val finalDataLoadDF = bmtFinal.select(Utilities.loadSelectExpr(bmtFinal.columns, tgtColumns): _*)

    finalDataLoadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTableName)

    val tgtCount = spark.sql(s"select * from ${tgtTableName}").count.toInt

    tgtCount match {
      case 0 =>
        logger.info("//************* Data Load Failed")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* Data Loaded into " + tgtTableName + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

    logger.info("//*************** Data loaded into:" + tgtTableName)

    spark.catalog.dropTempView("bmtTempTable")
    spark.catalog.dropTempView("bmtTempTable1")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_BMT_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_BMT_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_BMT_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_BMT_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_BMT_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } finally {
    logger.info("//*********************** Log End for BmtSecuredReport.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}  
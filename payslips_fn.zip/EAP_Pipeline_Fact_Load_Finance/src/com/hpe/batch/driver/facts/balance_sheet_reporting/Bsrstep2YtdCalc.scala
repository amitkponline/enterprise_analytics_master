package com.hpe.batch.driver.facts.balance_sheet_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
object Bsrstep2YtdCalc extends App {
 //**************************Driver properties******************************//
  
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val ins_ts=Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
  val upd_ts=null
  val ld_jb_id=ld_jb_nr+'_'+batchId
  logger.info("First log")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }
  var dbNameSrcTbl = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0) 
  logger.info("Source DataBase: "+dbNameSrcTbl) 
  
  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

  val transformeSrcdDF = spark.sql("""select count(*) from """ + propertiesObject.getSrcTblConsmtn() )

  val src_count = transformeSrcdDF.count().toInt  

import spark.implicits._

  val CurrentQuarter=propertiesObject.getCurrentQuarter()
  val PreviousQuarter=propertiesObject.getPreviousQuarter()
  val CurrentYear=propertiesObject.getCurrentYear()
  val PreviousYear=propertiesObject.getPreviousYear()
  try{
  var curr_ytd_val="(1)"
  var prev_ytd_val="(1)"
  var curr_period="(1)"
  var prev_period="(1)"
  var curr_prev_qrtr_query="select"
  var curr_prev_ytd_query="select"
  //var loadStatus =0
  if (CurrentQuarter=="1"){
      curr_ytd_val="(0,1,2,3)"
      curr_period="(1,2,3)"
    }
    else if(CurrentQuarter=="2"){
      curr_ytd_val="(0,1,2,3,4,5,6)"
      curr_period="(4,5,6)"
    }
    else if(CurrentQuarter=="3"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
      curr_period="(7,8,9)"
    }
    else if(CurrentQuarter=="4"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
      curr_period="(10,11,12)"
    }
    if (PreviousQuarter=="1"){
      prev_ytd_val="(0,1,2,3)"
      prev_period="(1,2,3)"
    }
    else if(PreviousQuarter=="2"){
      prev_ytd_val="(0,1,2,3,4,5,6)"
      prev_period="(4,5,6)"
    }
    else if(PreviousQuarter=="3"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
      prev_period="(7,8,9)"
    }
    else if(PreviousQuarter=="4"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
      prev_period="(10,11,12)"
    }

//creating aggregated table with period filter conditions
//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_gn_ldgr_itm_aggr_temp")

  val gnldgritmaggrtempDF =  spark.sql(s"""
  --create table ea_fin_r2_2itg.bsr_gn_ldgr_itm_aggr_temp as 
  select entrs_lgl_ent_ldgr_cd, grp_acct_nr,acct_nr,qrtr_attrbt,fscl_yr_nr,
case when fscl_yr_nr ='"""+CurrentYear+"""' and pstg_prd_nr in """+curr_ytd_val+""" then round(sum(gbl_curr_amt),2) else null end as Current_Qtr_YTD,
case when fscl_yr_nr ='"""+PreviousYear+"""' and pstg_prd_nr in """+prev_ytd_val+""" then round(sum(gbl_curr_amt),2) else null end as Prior_Qtr_YTD 
from """+dbNameConsmtn + "." +"""gnrl_ldgr_ln_itm_acct_number2 where gnrl_ldgr_acctng_cd='0L' 
group by entrs_lgl_ent_ldgr_cd, grp_acct_nr,acct_nr, fscl_yr_nr, qrtr_attrbt,pstg_prd_nr
  """)

  gnldgritmaggrtempDF.createOrReplaceTempView("bsr_gn_ldgr_itm_aggr_temp")
  
//group by company code and group account number

//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_grp_ldgr_aggrt")
val bsrgrpldgraggrtDF = spark.sql(s"""
  --create table ea_fin_r2_2itg.bsr_grp_ldgr_aggrt as 
  select grp_acct_nr, entrs_lgl_ent_ldgr_cd, 
sum(current_qtr_ytd) as current_qtr_ytd, 
sum(prior_qtr_ytd) as prior_qtr_ytd
from bsr_gn_ldgr_itm_aggr_temp group by grp_acct_nr, entrs_lgl_ent_ldgr_cd
  """)

bsrgrpldgraggrtDF.createOrReplaceTempView("bsr_grp_ldgr_aggrt")  
  
//blnce_sht_reprtg_audit_fact table creation to calculate YTD 
  
//spark.sql("drop table if exists ea_fin_r2_2itg.blnce_sht_reprtg_audit_fact")

//val blnce_sht_reprtg_audit_fact = "blnce_sht_reprtg_audit_fact"

val BSRAuditDF = spark.sql(s"""
  --create table ea_fin_r2_2itg.blnce_sht_reprtg_audit_fact as
select a.zbpc_acdocc_c_1_cd as legalcompanycode_cd,
a.grp_acct_nr, 
b.mapping_country_with_threshold_ctry_cd as ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd as countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd as rgn_cd, 
b.tr_cd as tr_cd,
b.thresholdtext_cd as thresholdtext_cd,
b.thresholdvalue_cd, 
b.thresholdpercent_cd,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+""" then zbpc_acdocc_fscl_yr_nr else null end as curr_year,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" then zbpc_acdocc_fscl_yr_nr else null end as prev_year,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+""" then """+CurrentQuarter+""" else null end as curr_quarter,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" then """+PreviousQuarter+""" else null end as prev_quarter,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+"""  and a.zbpc_acdocc_pstg_prd_nr in """+curr_ytd_val+""" and a.zbpc_acdocc_adt_Trail_nm in ( 'TOPSIDE_ADJ', 'PRE_CONS_ADJ', 'PRE_CONS_ADJ_HIST', 'RECLASS_PRE', 'ALLOC_ADJ_HIST') then round(sum(amt_grp_curr),2) else null end as CurrQtr_YTD_PL10,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+prev_ytd_val+""" and a.zbpc_acdocc_adt_Trail_nm in ( 'TOPSIDE_ADJ', 'PRE_CONS_ADJ', 'PRE_CONS_ADJ_HIST', 'RECLASS_PRE', 'ALLOC_ADJ_HIST') then round(sum(amt_grp_curr),2) else null end as PriorQtr_YTD_PL10,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+curr_ytd_val+""" and a.zbpc_acdocc_adt_Trail_nm in ('ELIM_ADJ_HIST', 'RECLASS_ELIM', 'ELIM_ADJ') then round(sum(amt_grp_curr),2) else null end as CurrQtr_YTD_PL20,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+prev_ytd_val+""" and a.zbpc_acdocc_adt_Trail_nm in ('ELIM_ADJ_HIST', 'RECLASS_ELIM', 'ELIM_ADJ') then round(sum(amt_grp_curr),2) else null end as PriorQtr_YTD_PL20,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+"""  and a.zbpc_acdocc_pstg_prd_nr in """+curr_period+"""  and a.zbpc_acdocc_adt_Trail_nm in ( 'TOPSIDE_ADJ', 'PRE_CONS_ADJ', 'PRE_CONS_ADJ_HIST', 'RECLASS_PRE', 'ALLOC_ADJ_HIST') and a.zbpc_acdocc_trsn_typ_cd = 999  then round(sum(amt_grp_curr),2) else null end as CurrQtr_MM_PL10,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+prev_period+""" and a.zbpc_acdocc_adt_Trail_nm in ( 'TOPSIDE_ADJ', 'PRE_CONS_ADJ', 'PRE_CONS_ADJ_HIST', 'RECLASS_PRE', 'ALLOC_ADJ_HIST') and a.zbpc_acdocc_trsn_typ_cd = 999 then round(sum(amt_grp_curr),2) else null end as PriorQtr_MM_PL10,
case when a.zbpc_acdocc_fscl_yr_nr = """+CurrentYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+curr_period+""" and a.zbpc_acdocc_adt_Trail_nm in ('ELIM_ADJ_HIST', 'RECLASS_ELIM', 'ELIM_ADJ') and 
a.zbpc_acdocc_trsn_typ_cd = 999 then round(sum(amt_grp_curr),2) else null end as CurrQtr_MM_PL20,
case when a.zbpc_acdocc_fscl_yr_nr = """+PreviousYear+""" and a.zbpc_acdocc_pstg_prd_nr in """+prev_period+""" and a.zbpc_acdocc_adt_Trail_nm in ('ELIM_ADJ_HIST', 'RECLASS_ELIM', 'ELIM_ADJ') 
and a.zbpc_acdocc_trsn_typ_cd = 999 then round(sum(amt_grp_curr),2) else null end as PriorQtr_MM_PL20
from """+dbNameConsmtn + "." +"""bpc_cnsldtn_trsn_0107  a inner join """+dbNameConsmtn + "." +"""cntry_thrs_mpng_cmpny_code b on a.zbpc_acdocc_c_1_cd = b.legalcompanycode_cd
where 
a.cnsldtn_grp_1_nm = 'G_HPE' group by a.zbpc_acdocc_c_1_cd, a.grp_acct_nr, a.zbpc_acdocc_fscl_yr_nr, a.zbpc_acdocc_pstg_prd_nr, a.zbpc_acdocc_adt_Trail_nm,
b.mapping_country_with_threshold_ctry_cd,
b.mapping_country_with_threshold_countrygroup_cd, 
b.mapping_country_with_threshold_rgn_cd,
b.tr_cd,
b.thresholdtext_cd, 
a.zbpc_acdocc_trsn_typ_cd,
b.thresholdvalue_cd,
b.thresholdpercent_cd
  """)
  
BSRAuditDF.createOrReplaceTempView("blnce_sht_reprtg_audit_fact")  
  
 //var loadStatus = Utilities.storeDataFrame(BSRAuditDF, "overwrite", "ORC", dbNameConsmtn + "." + blnce_sht_reprtg_audit_fact, configObject)
 
logger.info("Created view: blnce_sht_reprtg_audit_fact")
 
//creating aggregated table of BSR audit fact
  
//spark.sql("drop table if exists ea_fin_r2_2itg.blnce_sht_reprtg_audit_aggrt")

val blnce_sht_reprtg_audit_aggrt = "blnce_sht_reprtg_audit_aggrt"

val BSRAuditAggDF = spark.sql(s"""
  --create table ea_fin_r2_2itg.blnce_sht_reprtg_audit_aggrt as 
select legalcompanycode_cd, grp_acct_nr, ctry_cd, countrygroup_cd, rgn_cd, tr_cd, thresholdtext_cd, thresholdvalue_cd, thresholdpercent_cd,
round(sum(currqtr_ytd_pl10),2) as currqtr_ytd_pl10, 
round(sum(priorqtr_ytd_pl10),2) as priorqtr_ytd_pl10, 
round(sum(currqtr_ytd_pl20),2) as currqtr_ytd_pl20,
round(sum(priorqtr_ytd_pl20),2) as priorqtr_ytd_pl20 
from blnce_sht_reprtg_audit_fact group by legalcompanycode_cd, grp_acct_nr, ctry_cd, countrygroup_cd, rgn_cd, tr_cd, thresholdtext_cd, thresholdvalue_cd, thresholdpercent_cd
  """)

var loadStatus = Utilities.storeDataFrame(BSRAuditAggDF, "overwrite", "ORC", dbNameConsmtn + "." + blnce_sht_reprtg_audit_aggrt, configObject)
 
logger.info("Created table: blnce_sht_reprtg_audit_aggrt")
   
  
//calculating closing quarter balances and variance

//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_threshold_input")

val bsr_threshold_input= "bsr_threshold_input"

val bsrThresholdInputDF = spark.sql(s"""
   -- create table ea_fin_r2_2itg.bsr_threshold_input as 
select a.legalcompanycode_cd, a.grp_acct_nr, 
a.thresholdtext_cd,
a.ctry_cd,
a.countrygroup_cd,
a.rgn_cd,
a.tr_cd,
a.thresholdvalue_cd,
a.thresholdpercent_cd,
round(sum(a.currqtr_ytd_pl10),2) as PL10_CurrQtr,
round(sum(a.currqtr_ytd_pl20),2) as PL20_CurrQtr,
round(sum(a.priorqtr_ytd_pl10),2) as PL10_PriQtr,
round(sum(a.priorqtr_ytd_pl20),2) as PL20_PriQtr,
(round (COALESCE(SUM(a.currqtr_ytd_pl10),0) ,2) + round(COALESCE(sum(b.current_qtr_ytd),0),2) ) as close_blc_CurrQtr,
(round (COALESCE(sum(a.priorqtr_ytd_pl10),0),2) + round(COALESCE(sum(b.prior_qtr_ytd),0),2) ) as close_blc_PreQtr, 
abs( (round (COALESCE(SUM(a.currqtr_ytd_pl10),0) ,2) + round(COALESCE(sum(b.current_qtr_ytd),0),2) ) - (round (COALESCE(sum(a.priorqtr_ytd_pl10),0),2) + round(COALESCE(sum(b.prior_qtr_ytd),0),2) ) ) as variance,
( abs(( (round(sum(a.currqtr_ytd_pl10),2) + round(sum(b.current_qtr_ytd),2) ) - (round(sum(a.priorqtr_ytd_pl10),2) + round(sum(b.prior_qtr_ytd),2) )))/abs((round(sum(a.priorqtr_ytd_pl10),2) + round(sum(b.prior_qtr_ytd),2) )) ) as var_Percent
from """+dbNameConsmtn + "." +"""blnce_sht_reprtg_audit_aggrt a full outer join bsr_grp_ldgr_aggrt b
on a.legalcompanycode_cd = b.entrs_lgl_ent_ldgr_cd and a.grp_acct_nr = b.grp_acct_nr where a.grp_acct_nr > '0000001099' and a.grp_acct_nr < '0000002999' and a.grp_acct_nr not in 
('0000001228','0000001229','0000001230','0000001231','0000001234','0000001235','0000001237','0000001238','0000001240','0000001251','0000001293','0000001294','0000001297','0000001299','0000001370','0000001371','0000001375','0000001376','0000001389','0000001390','0000001391','0000001392','0000001393','0000001394','0000001395','0000001430','0000001438','0000001471','0000001472','0000001473','0000001474','0000001475','0000001476','0000001477','0000001478','0000001600','0000001601','0000001610','0000001611','0000001612','0000001613','0000001614','0000001650','0000001690','0000001917','0000001945','0000002328','0000002330','0000002331','0000002334','0000002335','0000002337','0000002351','0000002409','0000002430','0000002431','0000002433','0000002528','0000002529','0000002530','0000002730','0000002731','0000002812','0000002818','0000002910','0000002911','0000002912','0000002913','0000002914','0000002930','0000002939','0000002940','0000002941','0000002942','0000002944','0000002945','0000002947','0000002948','0000002949','0000002950','0000002951','0000002959','0000002960','0000002961','0000002964','0000002965','0000002966','0000002967','0000002971','0000002980','0000002985','0000002998','0000002999') group by a.legalcompanycode_cd, a.grp_acct_nr, a.thresholdtext_cd, a.ctry_cd, 
a.countrygroup_cd, a.rgn_cd, a.tr_cd, a.thresholdvalue_cd, a.thresholdpercent_cd
    """)

loadStatus = Utilities.storeDataFrame(bsrThresholdInputDF, "overwrite", "ORC", dbNameConsmtn + "." + bsr_threshold_input, configObject)
 
logger.info("Created table: bsr_threshold_input")
     
    
//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_threshold_input_aggrt")

val bsr_threshold_input_aggrt = "bsr_threshold_input_aggrt"

val bsrThresholdInputAggDF = spark.sql(s"""
--  create table ea_fin_r2_2itg.bsr_threshold_input_aggrt as 
select
grp_acct_nr,
countrygroup_cd,
thresholdvalue_cd,
thresholdpercent_cd,
sum(close_blc_CurrQtr) as close_blc_CurrQtr,
sum(close_blc_PreQtr) as close_blc_PreQtr, 
abs( sum(close_blc_CurrQtr) - sum(close_blc_PreQtr)) as var_country,
COALESCE((abs( sum(close_blc_CurrQtr) - sum(close_blc_PreQtr))/abs(sum(close_blc_PreQtr))) , 1) as var_percent_country
from """+dbNameConsmtn + "." +"""bsr_threshold_input group by countrygroup_cd,thresholdvalue_cd,thresholdpercent_cd ,grp_acct_nr
  """)

loadStatus = Utilities.storeDataFrame(bsrThresholdInputAggDF, "overwrite", "ORC", dbNameConsmtn + "." + bsr_threshold_input_aggrt, configObject)
 
logger.info("Created table: bsr_threshold_input_aggrt")
    
  
//checking threshold value 
  
//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_threshold_input_aggrt_check")

val bsr_threshold_input_aggrt_check = "bsr_threshold_input_aggrt_check"

val thresholdCheckDF = spark.sql(s"""
 -- create table ea_fin_r2_2itg.bsr_threshold_input_aggrt_check as 
select
grp_acct_nr,
countrygroup_cd,
thresholdvalue_cd,
thresholdpercent_cd,
close_blc_CurrQtr,
close_blc_PreQtr,
var_country,
var_percent_country
from """+dbNameConsmtn + "." +"""bsr_threshold_input_aggrt where var_country >= cast (thresholdvalue_cd as double) and var_percent_country >cast (thresholdpercent_cd as double)
  """)

loadStatus = Utilities.storeDataFrame(thresholdCheckDF, "overwrite", "ORC", dbNameConsmtn + "." + bsr_threshold_input_aggrt_check, configObject)
 
logger.info("Created table: bsr_threshold_input_aggrt_check")
  
  
//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_threshold_output_fact")

val bsr_threshold_output_fact = "bsr_threshold_output_fact"

val thresholdOutputFactDF = spark.sql(s"""
--  create table ea_fin_r2_2itg.bsr_threshold_output_fact as 
select a.legalcompanycode_cd, a.grp_acct_nr, 
a.thresholdtext_cd,
a.ctry_cd,
a.countrygroup_cd,
a.rgn_cd,
a.tr_cd,
a.thresholdvalue_cd,
a.thresholdpercent_cd,
a.PL10_CurrQtr,
a.PL20_CurrQtr,
a.PL10_PriQtr,
a.PL20_PriQtr,
a.close_blc_CurrQtr,
a.close_blc_PreQtr,
a.variance,
a.var_Percent
from """+dbNameConsmtn + "." +"""bsr_threshold_input a join """+dbNameConsmtn + "." +"""bsr_threshold_input_aggrt_check b on a.grp_acct_nr = b.grp_acct_nr and a.countrygroup_cd = b.countrygroup_cd
  """)

loadStatus = Utilities.storeDataFrame(thresholdOutputFactDF, "overwrite", "ORC", dbNameConsmtn + "." + bsr_threshold_output_fact, configObject)
 
logger.info("Created table: bsr_threshold_output_fact")
  
  
//joining this threshold table with sourcing logics table .this table would be input to all other BSR scala codes driver,customer,profit center,vendor

//spark.sql("drop table if exists ea_fin_r2_2itg.bsr_temp")

val bsr_temp = "bsr_temp"

val BSRtempDF = spark.sql(s"""
 -- create table ea_fin_r2_2itg.bsr_temp as 
select a.legalcompanycode_cd,
a.grp_acct_nr,
a.thresholdtext_cd,
a.ctry_cd,
a.countrygroup_cd,
a.rgn_cd,
a.tr_cd,
a.thresholdvalue_cd,
a.thresholdpercent_cd,
a.pl10_currqtr,
a.pl20_currqtr,
a.pl10_priqtr,
a.pl20_priqtr,
a.close_blc_currqtr,
a.close_blc_preqtr,
a.variance,
a.var_percent,
b.driver_name,
b.logic,
b.ytd from """+dbNameConsmtn + "." +"""bsr_threshold_output_fact a inner join """+dbNameConsmtn + "." +"""group_acct_driver_cmpny_cd_mapng b on (a.grp_acct_nr=b.group_accnt_nm and a.legalcompanycode_cd=b.legalcompanycode_cd)
  """)
  
loadStatus = Utilities.storeDataFrame(BSRtempDF, "overwrite", "ORC", dbNameConsmtn + "." + bsr_temp, configObject)
 
logger.info("Created table: bsr_temp")
    

    //************************Completion Audit Entries*******************************//

val tgt_count = BSRtempDF.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    //auditObj.setAudObjectName("blnce_sht_reprtg_driver_fact")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(0)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } 
  
  catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}

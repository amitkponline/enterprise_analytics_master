package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object JournalVouchersSecuredReport extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"

  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  val dbNameEACOMMON = propertiesObject.getDbName().trim().split(",")(0)
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val objName = propertiesObject.getObjName()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val logger = Logger.getLogger(getClass.getName)

  logger.info("//*********************** Log Start for JournalVouchersSecuredReport.scala ************************//")
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  try {

   
    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn))

    //***************************Audit Properties********************************//
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_secrd_journal_voucher_fact_load")
    auditObj.setAudObjectName(objName)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)

    if (tgtTblConsmtn.split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    val tgtColumns = spark.sql("select * from " + tgtTblConsmtn + " limit 0").columns
    //val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    val srcCount = 0
    def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
      val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*))
      val rowDF = df.withColumn("rn", row_number().over(part))
      val res = rowDF.filter("rn==1").drop("rn")
      res
    }

    // fiscal year period calculation
    val cal = Calendar.getInstance()
    val Year = cal.get(Calendar.YEAR)
    val Month1 = cal.get(Calendar.MONTH)
    var Month = Month1 + 1
    val prev_year = Year - 1
    val prev_year_str = prev_year.toString()
    val year1 = Year + 1
    var Month_val = Month.toString()
    var year_val = Year.toString()
    var next_year = year1.toString()
    println("current year", Year, Month1, Month)
    var fscl_yr_prd = ""

    if ((Month_val == "11") || (Month_val == "12")) {
      if (Month_val == "11") {
        fscl_yr_prd = year_val + "4"
      } else {
        fscl_yr_prd = next_year + "1"
      } //year+Q
    } else if (Month_val == "1") { fscl_yr_prd = year_val + "1" }

    else if ((Month_val == "2") || (Month_val == "3") || (Month_val == "4")) {
      if (Month_val == "2") {
        fscl_yr_prd = year_val + "1"
      } else {
        fscl_yr_prd = year_val + "2"
      }
    } else if ((Month_val == "5") || (Month_val == "6") || (Month_val == "7")) {
      if (Month_val == "5") {
        fscl_yr_prd = year_val + "2"
      } else {
        fscl_yr_prd = year_val + "3"
      }
    } else if ((Month_val == "8") || (Month_val == "9") || (Month_val == "10")) {
      if (Month_val == "8") {
        fscl_yr_prd = year_val + "3"
      } else {
        fscl_yr_prd = year_val + "4"
      }
    }

    val fscl_yr_prd_con = fscl_yr_prd.toInt

    logger.info("//*********************** fiscal year period value: " + fscl_yr_prd_con)

    val hive_tgt_table = consmptnTable
 
    val jvSrcDF = spark.sql(s"""
      select gnrl_ldgr_ln_itm_ky as secrd_rpt_fact_ky,
crc32(LOWER(COALESCE(end_cust_cd,"")) )as mdm_cust_ky,
crc32(LOWER(COALESCE(gds_bsn_actvy_dn,""))) as pdm_mtrl_mstr_grp_ky,
crc32(LOWER(COALESCE(fnctl_ar_cd,"")) )as fnctl_ar_ky,
crc32(LOWER(COALESCE(vndr_id,""))) as vndr_ky,
crc32(LOWER(COALESCE(ord_nr,""))) as ord_hddr_ky,
crc32(LOWER(COALESCE(pft_cntr_cd,""))) as pft_cntr_ky,
crc32(LOWER(COALESCE(cst_cntr_cd,""))) as cst_cntr_ky,
crc32(LOWER(COALESCE(acct_nr,""))) as gl_acct_ky,
sls_ord_itm_nr as sls_ord_ln_itm_id,
sls_ord_nr as sls_ord_id,
mrkt_rte_id as mkt_rte_cd,
mtrl_grp_cd as mtrl_nr,
'JOURNAL_VOUCHERS' as src_sys_cd,
cst_cntr_cd as cst_cntr_cd,
soldto_prty_nm as sld_to_cd,
end_cust_cd as end_cust_cd,
prchg_dcmt_nr as ord_prch_cd,
dcmt_typ_cd as sls_dcmt_itm_cgy_cd,
plnt_nm as plnt_cd,
pft_cntr_cd as prft_cntr_cd,
mgmt_grphy_unt_cd as sgmtl_rptg_cd,
prchg_dcmt_itm_nr as ord_itm_prch_cd,
pmnt_trms_cd as pmnt_trms_cd,
dbt_crdt_ind as crdt_dbt_ind,
fscl_yr_nr as fscl_yr_nr,
fscl_prd_cd as fscl_prd_nr,
CASE WHEN (gnrl_ldgr_ln_itm_trsn.fscl_prd_cd) IN ('1','2','3') THEN 'Q1' WHEN (gnrl_ldgr_ln_itm_trsn.fscl_prd_cd) IN ('4','5','6') THEN 'Q2' WHEN (gnrl_ldgr_ln_itm_trsn.fscl_prd_cd) IN ('7','8','9' ) THEN 'Q3' WHEN (gnrl_ldgr_ln_itm_trsn.fscl_prd_cd) IN ('10','11','12' ) THEN 'Q4' else NULL end as fscl_qtr_nr,
acct_nr as gl_acct_nr,
pftblty_sgm_nr as pftblty_sgm_copa_nr,
pstg_dt as pstg_dt,
entrs_lgl_ent_ldgr_cd as co_cd,
fnctl_ar_cd as fnctl_ar_cd,
CURRENT_TIMESTAMP as ins_ts,
usr_nm as use_nm,
shp_to_ctry_cd as shp_to_ctry_cd,
cust_nr as cust_nr,
gc_exch_rate as gc_exch_rate,
tx_exch_rate as tx_exch_rate,
lcr_tx_rate as lcr_tx_rate,
acctng_dcmt_id as acctng_dcmt_id,
ptnr_mgmt_grphy_unt_cd as ptnr_mgmt_grphy_unt_cd,
frly_dfnd_curr_3_amt as frly_dfnd_curr_3_amt,
frly_dfnd_curr_4_amt as frly_dfnd_curr_4_amt,
frly_dfnd_curr_5_amt as frly_dfnd_curr_5_amt,
frly_dfnd_curr_6_amt as frly_dfnd_curr_6_amt,
exch_rate as exch_rate,
exch_rate_dt as exch_rate_dt,
acct_nr as acct_nr,
ptnr_fnctl_ar_cd as ptnr_fnctl_ar_cd,
tc_blc_amt as tc_blc_amt,
tc_amt as tc_amt,
co_cd_curr_amt as co_cd_curr_amt,
gbl_curr_amt as gbl_curr_amt,
dcmt_pstg_dt as dcmt_pstg_dt,
dcmt_dt as dcmt_dt,
lcr_cd as lcr_cd,
ldgr_grp_cd as ldgr_grp_cd,
lgcl_sys_cd as lgcl_sys_cd,
ofst_acct_nr as ofst_acct_nr,
ptnr_cst_obj_cd as ptnr_cst_obj_cd,
ptnr_entrs_lgl_ent_ldgr_cd as ptnr_entrs_lgl_ent_ldgr_cd,
rvrsd_itm_ind as rvrsd_itm_ind,
sndr_lgcl_sys_cd as sndr_lgcl_sys_cd,
tc_cd as tc_cd,
ln_itm_txt as ln_itm_txt,
src_dcmt_nr as src_dcmt_nr,
rfnc_dcmt_ln_itm_nr,
rfnc_dcmt_nr,
vndr_id,
dcmt_etry_ts,
gds_bsn_actvy_dn,
sls_dcmt_cd,
shp_to_ptnr_id,
dcmt_typ_cd,
gnrl_ldgr_ln_itm_trsn.src_sys_upd_ts as src_sys_upd_ts,
gnrl_ldgr_ln_itm_trsn.src_sys_ky as src_sys_ky,
gnrl_ldgr_ln_itm_trsn.lgcl_dlt_ind as lgcl_dlt_ind,
gnrl_ldgr_ln_itm_trsn.ins_gmt_ts as ins_gmt_ts,
gnrl_ldgr_ln_itm_trsn.upd_gmt_ts as upd_gmt_ts,
gnrl_ldgr_ln_itm_trsn.src_sys_extrc_gmt_ts as src_sys_extrc_gmt_ts,
gnrl_ldgr_ln_itm_trsn.src_sys_btch_nr as src_sys_btch_nr,
gnrl_ldgr_ln_itm_trsn.fl_nm as fl_nm,
gnrl_ldgr_ln_itm_trsn.ld_jb_nr as ld_jb_nr,
gnrl_ldgr_ln_itm_trsn.three_mnth_avg_amt as grs_rvn_three_mnth_avg_amt,
gnrl_ldgr_ln_itm_trsn.twelve_mnth_avg_amt as grs_rvn_twelve_mnth_avg_amt,
gnrl_ldgr_ln_itm_trsn.rvn_amt_usd_rsttd_bdgt_rate_cd as grs_rvn_amt_usd_rsttd_bdgt_rate_cd
from ${srcTableName} WHERE 
gnrl_ldgr_ln_itm_trsn.dcmt_typ_cd not in ('ZB')
and gnrl_ldgr_ln_itm_trsn.ldgr_grp_cd = '0L'
and gnrl_ldgr_ln_itm_trsn.fnctl_ar_cd is not null 
and (gnrl_ldgr_ln_itm_trsn.acct_nr not like '001%' or gnrl_ldgr_ln_itm_trsn.acct_nr not like '002%')
and yr_nr = substring(${fscl_yr_prd_con},1,4)
and CAST(CASE WHEN (prd_nr) IN ('1','2','3') THEN '1' WHEN (prd_nr) IN ('4','5','6') THEN '2' WHEN (prd_nr) IN ('7','8','9' ) THEN '3' WHEN (prd_nr) IN ('10','11','12' ) THEN '4' else NULL end AS INT)>= substring(${fscl_yr_prd_con},5,1)""").distinct

jvSrcDF.createOrReplaceTempView("gnrl_ldgr_ln_itm_trsn")

val jvSelectDF = spark.sql(s"""
select  
secrd_rpt_fact_ky
,mdm_cust_ky
,pdm_mtrl_mstr_grp_ky
,fnctl_ar_ky
,vndr_ky
,ord_hddr_ky
,pft_cntr_ky
,gnrl_ldgr_ln_itm_trsn.cst_cntr_ky
,gl_acct_ky
,sls_ord_ln_itm_id
,sls_ord_id
,mkt_rte_cd
,mtrl_nr
,src_sys_cd
,cst_cntr_cd
,coalesce(CASE WHEN cst_cntr_grp_hrchy_dmnsn.cch_level_8 is NULL then "FO70000038" else cst_cntr_grp_hrchy_dmnsn.cch_level_8  end,"FO70000038") as fncl_ownr_cd
,sld_to_cd
,end_cust_cd
,ord_prch_cd
,sls_dcmt_itm_cgy_cd
,plnt_cd
,prft_cntr_cd
,sgmtl_rptg_cd
,ord_itm_prch_cd
,pmnt_trms_cd
,crdt_dbt_ind
,fscl_yr_nr
,fscl_prd_nr
,fscl_qtr_nr
,gl_acct_nr
,pftblty_sgm_copa_nr
,pstg_dt
,co_cd
,fnctl_ar_cd
,gnrl_ldgr_ln_itm_trsn.ins_ts
,use_nm
,shp_to_ctry_cd
,cust_nr
,gc_exch_rate
,tx_exch_rate
,lcr_tx_rate
,acctng_dcmt_id
,ptnr_mgmt_grphy_unt_cd
,frly_dfnd_curr_3_amt
,frly_dfnd_curr_4_amt
,frly_dfnd_curr_5_amt
,frly_dfnd_curr_6_amt
,exch_rate
,exch_rate_dt
,acct_nr
,ptnr_fnctl_ar_cd
,tc_blc_amt
,tc_amt
,co_cd_curr_amt
,gbl_curr_amt
,dcmt_pstg_dt
,dcmt_dt
,lcr_cd
,ldgr_grp_cd
,lgcl_sys_cd
,ofst_acct_nr
,ptnr_cst_obj_cd
,ptnr_entrs_lgl_ent_ldgr_cd
,rvrsd_itm_ind
,sndr_lgcl_sys_cd
,tc_cd
,ln_itm_txt
,src_dcmt_nr
,rfnc_dcmt_ln_itm_nr
,rfnc_dcmt_nr
,vndr_id
,dcmt_etry_ts
,gds_bsn_actvy_dn
,sls_dcmt_cd
,shp_to_ptnr_id
,spnd.ff_ln_itm_6
,spnd.ff_ln_itm_7
,dcmt_typ_cd
,cst.cch_level_5 as MRU
,cp_hrchy.cch_level_2 as cst_pl
,gnrl_ldgr_ln_itm_trsn.src_sys_upd_ts
,gnrl_ldgr_ln_itm_trsn.src_sys_ky
,gnrl_ldgr_ln_itm_trsn.lgcl_dlt_ind
,gnrl_ldgr_ln_itm_trsn.ins_gmt_ts
,gnrl_ldgr_ln_itm_trsn.upd_gmt_ts
,gnrl_ldgr_ln_itm_trsn.src_sys_extrc_gmt_ts
,gnrl_ldgr_ln_itm_trsn.src_sys_btch_nr
,gnrl_ldgr_ln_itm_trsn.fl_nm
,gnrl_ldgr_ln_itm_trsn.ld_jb_nr
FROM gnrl_ldgr_ln_itm_trsn
left join ${dbNameEACOMMON}.cst_cntr_MRU_hrchy cst on gnrl_ldgr_ln_itm_trsn.cst_cntr_cd=cst.cch_level_8
left join ${dbNameEACOMMON}.bmt_pn_ff_spnd_lvl_dmnsn spnd on substring(gnrl_ldgr_ln_itm_trsn.acct_nr,3,8)= spnd.acct_cd
left outer join ${dbNameEACOMMON}.cst_cntr_fo_hrchy cst_cntr_grp_hrchy_dmnsn on cst_cntr_grp_hrchy_dmnsn.cch_level_9=gnrl_ldgr_ln_itm_trsn.cst_cntr_cd
left outer join ${dbNameEACOMMON}.cst_cntr_cp_hrchy cp_hrchy on cp_hrchy.cch_level_3 = gnrl_ldgr_ln_itm_trsn.cst_cntr_cd
""").distinct


    val tgtColumnsJVtbl = spark.sql("select * from " + dbNameConsmtn + ".secrd_rpt_fact_jv_tmp limit 0").columns

    jvSelectDF.select(Utilities.loadSelectExpr(jvSelectDF.columns, tgtColumnsJVtbl): _*).repartition(10).write.format("orc").mode("Overwrite").insertInto(dbNameConsmtn + ".secrd_rpt_fact_jv_tmp")

    val filteredDf = spark.sql(s"select * from ${dbNameConsmtn}.secrd_rpt_fact_jv_tmp").withColumn("fnc_insrt_ind", lit("N")).withColumn("fnc_insrt_rsn_cd", lit("NA"))

    val serpSelectDfpnFnclFrmwk = filteredDf.select("secrd_rpt_fact_ky", "prft_cntr_cd", "gl_acct_nr", "MRU", "cst_cntr_cd", "fnctl_ar_cd").distinct
    val pnFnclFrmwkDf = spark.sql(s"""select a.* from (select tbl.*,row_number() over (partition by tbl.pft_cntr,tbl.acct_cd,tbl.mru_cd,tbl.cst_obj,tbl.fnctl_ar order by tbl.precedence) seq_id
    from ${dbNameEACOMMON}.bmt_pn_fncl_frmwk_dmnsn tbl)a where a.seq_id=1""")

    var jvpnFnclFrmwkJoinStg = serpSelectDfpnFnclFrmwk.alias("serpJoindCol2").join(
      pnFnclFrmwkDf.alias("pnFnclFrmwkCol"),
      (serpSelectDfpnFnclFrmwk("prft_cntr_cd") === pnFnclFrmwkDf("pft_cntr") || pnFnclFrmwkDf("pft_cntr") === "all")
        && (substring(serpSelectDfpnFnclFrmwk("gl_acct_nr"), 3, 8) === pnFnclFrmwkDf("acct_cd") || pnFnclFrmwkDf("acct_cd") === "all")
        && (serpSelectDfpnFnclFrmwk("MRU") === pnFnclFrmwkDf("mru_cd") || pnFnclFrmwkDf("mru_cd") === "all")
        && (serpSelectDfpnFnclFrmwk("cst_cntr_cd") === pnFnclFrmwkDf("cst_obj") || pnFnclFrmwkDf("cst_obj") === "all")
        && (serpSelectDfpnFnclFrmwk("fnctl_ar_cd") === pnFnclFrmwkDf("fnctl_ar") || pnFnclFrmwkDf("fnctl_ar") === "all"), "leftouter").filter(pnFnclFrmwkDf("precedence").isNotNull).select("serpJoindCol2.*", "pnFnclFrmwkCol.ff_ln_itm_0", "pnFnclFrmwkCol.ff_ln_itm_1", "pnFnclFrmwkCol.ff_ln_itm_2",
        "pnFnclFrmwkCol.ff_ln_itm_3", "pnFnclFrmwkCol.ff_ln_itm_4", "pnFnclFrmwkCol.ff_ln_itm_5", "pnFnclFrmwkCol.precedence")

    val jvpnFnclFrmwkJoinDeDup = getLatestRecs(jvpnFnclFrmwkJoinStg, List("secrd_rpt_fact_ky", "prft_cntr_cd", "gl_acct_nr", "MRU", "cst_cntr_cd", "fnctl_ar_cd"), List("precedence"))

    var jvpnFnclFrmwkJoinFinal = filteredDf.alias("serpJoindCol").join(
      (jvpnFnclFrmwkJoinDeDup).alias("pnFnclFrmwkCol1"),
      filteredDf("secrd_rpt_fact_ky") === jvpnFnclFrmwkJoinDeDup("secrd_rpt_fact_ky") &&
        ((filteredDf("prft_cntr_cd").isNull && jvpnFnclFrmwkJoinDeDup("prft_cntr_cd").isNull) || filteredDf("prft_cntr_cd") === jvpnFnclFrmwkJoinDeDup("prft_cntr_cd"))
        && ((filteredDf("gl_acct_nr").isNull && jvpnFnclFrmwkJoinDeDup("gl_acct_nr").isNull) || filteredDf("gl_acct_nr") === jvpnFnclFrmwkJoinDeDup("gl_acct_nr"))
        && ((filteredDf("MRU").isNull && jvpnFnclFrmwkJoinDeDup("MRU").isNull) || filteredDf("MRU") === jvpnFnclFrmwkJoinDeDup("MRU"))
        && ((filteredDf("cst_cntr_cd").isNull && jvpnFnclFrmwkJoinDeDup("cst_cntr_cd").isNull) || filteredDf("cst_cntr_cd") === jvpnFnclFrmwkJoinDeDup("cst_cntr_cd"))
        && ((filteredDf("fnctl_ar_cd").isNull && jvpnFnclFrmwkJoinDeDup("fnctl_ar_cd").isNull) || filteredDf("fnctl_ar_cd") === jvpnFnclFrmwkJoinDeDup("fnctl_ar_cd")), "leftouter").select("serpJoindCol.*", "pnFnclFrmwkCol1.ff_ln_itm_0", "pnFnclFrmwkCol1.ff_ln_itm_1", "pnFnclFrmwkCol1.ff_ln_itm_2", "pnFnclFrmwkCol1.ff_ln_itm_3", "pnFnclFrmwkCol1.ff_ln_itm_4", "pnFnclFrmwkCol1.ff_ln_itm_5", "pnFnclFrmwkCol1.precedence")

    jvpnFnclFrmwkJoinFinal = jvpnFnclFrmwkJoinFinal.drop("FF_LI0").drop("FF_LI1").drop("FF_LI2").drop("FF_LI3").drop("FF_LI4").drop("FF_LI5").drop("FF_LI6").drop("FF_LI7")

    jvpnFnclFrmwkJoinFinal = jvpnFnclFrmwkJoinFinal.withColumnRenamed("ff_ln_itm_0", "ff_li0").withColumnRenamed("ff_ln_itm_1", "ff_li1").withColumnRenamed("ff_ln_itm_2", "ff_li2").withColumnRenamed("ff_ln_itm_3", "ff_li3").withColumnRenamed("ff_ln_itm_4", "ff_li4").withColumnRenamed("ff_ln_itm_5", "ff_li5").withColumnRenamed("ff_ln_itm_6", "ff_li6").withColumnRenamed("ff_ln_itm_7", "ff_li7")
    val jvFinalLoad = jvpnFnclFrmwkJoinFinal.distinct.select(Utilities.loadSelectExpr(jvpnFnclFrmwkJoinFinal.columns, tgtColumns): _*)

    jvFinalLoad.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + consmptnTable)

    //jvFinalLoad.write.mode("append").format("orc").insertInto(dbNameConsmtn+".secrd_rpt_fact_test_1611")
    logger.info("//*********************** Data inserted into final Table ************************//")

    val tgtCount = spark.sql(s"select * from " + dbNameConsmtn + "." + consmptnTable + " where src_sys_cd = 'JOURNAL_VOUCHERS'").count.toInt

    tgtCount match {
      case 0 =>
        logger.info("//************* Data Load Failed")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* Data Loaded into " + dbNameConsmtn + "." + consmptnTable + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } finally {
    logger.info("//*********************** Log End for JournalVouchersSecuredReport.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object SerpDf extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  logger.info("//*********************** Log Start for SerpDf.scala ************************//")
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val dbCommonName = propertiesObject.getDbName().trim().split(",")(0)
  val dbCommonUATName = propertiesObject.getDbName().trim().split(",")(1)
  logger.info("First log")
  val tgtTblName = propertiesObject.getTgtTblConsmtn().trim()

  var dbNameConsmtn: String = null
  var consmptnTable: String = null

  try {
    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
    }

        /*
     * getLatestRecs to get the latest records
     * @Param df: Data frame on which operations needs to be performed
     * @Param partition_col: List of columns required to create partition
     * @Param sortCols: column name to get the latest record for each partition
     */
    
      def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
        val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*))
        val rowDF = df.withColumn("rn", row_number().over(part))
        val res = rowDF.filter("rn==1").drop("rn")
        res
      }

    val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())
    val cal = Calendar.getInstance()
    val Year = cal.get(Calendar.YEAR)
    val Month1 = cal.get(Calendar.MONTH)
    var Month = Month1 + 1
    val prev_year = Year - 1
    val year1 = Year + 1
    val prev_year_str = prev_year.toString()
    var Month_val = Month.toString()
    var year_val = Year.toString()
    var next_year = year1.toString()
    var fscl_yr_prd = ""

  
    //Filter condition for Current, Future and previous quarter(only till first month of current quarter) data
    if ((Month_val == "11") || (Month_val == "12")) {
      if (Month_val == "11") {
        fscl_yr_prd = year_val + "4"
      } else {
        fscl_yr_prd = next_year + "1"
      } //year+Q
    } else if (Month_val == "1") { fscl_yr_prd = year_val + "1" }

    else if ((Month_val == "2") || (Month_val == "3") || (Month_val == "4")) {
      if (Month_val == "2") {
        fscl_yr_prd = year_val + "1"
      } else {
        fscl_yr_prd = year_val + "2"
      }
    } else if ((Month_val == "5") || (Month_val == "6") || (Month_val == "7")) {
      if (Month_val == "5") {
        fscl_yr_prd = year_val + "2"
      } else {
        fscl_yr_prd = year_val + "3"
      }
    } else if ((Month_val == "8") || (Month_val == "9") || (Month_val == "10")) {
      if (Month_val == "8") {
        fscl_yr_prd = year_val + "3"
      } else {
        fscl_yr_prd = year_val + "4"
      }
    }

    val fscl_yr_prd_con = fscl_yr_prd.toInt


    val hive_tgt_table = consmptnTable
   
    /*
     * Query part to derive Rate Code from BMTs(Product Rates, Customer Rates, PL Rates, Sales Order Rates, Partner Rates )
     *
     */
    
    var rate_cd = """CASE when sls_ord_rates_dmnsn.fscl_yr_mth_cd <> "?" and sls_ord_rates_dmnsn.fscl_yr_mth_cd <> 'all' and sls_ord_rates_dmnsn.fscl_yr_mth_cd is not null and sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = sls_ord_rates_dmnsn.fscl_yr_mth_cd then sls_ord_rates_dmnsn.rate_cd
when sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd then sls_ord_rates_dmnsn.rate_cd 
when prod_rates_dmnsn.fscl_yr_mth_cd <> "?" and prod_rates_dmnsn.fscl_yr_mth_cd <> 'all' and prod_rates_dmnsn.fscl_yr_mth_cd is not null and
 sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = prod_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then prod_rates_dmnsn.rate_cd
 when sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then prod_rates_dmnsn.rate_cd 
 when cust_rates_dmnsn.fscl_yr_mth_cd <> "?" and cust_rates_dmnsn.fscl_yr_mth_cd <> 'all' and cust_rates_dmnsn.fscl_yr_mth_cd is not null and
 ord_dmnsn_adjmt_dmnsn.end_cust_prty_id  = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = cust_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then cust_rates_dmnsn.rate_cd
 when ord_dmnsn_adjmt_dmnsn.end_cust_prty_id  = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and  sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then cust_rates_dmnsn.rate_cd 
 WHEN ptnr_rates_dmnsn.fscl_yr_mth_cd <> "?" and ptnr_rates_dmnsn.fscl_yr_mth_cd <> 'all' and ptnr_rates_dmnsn.fscl_yr_mth_cd is not null and
sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = ptnr_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then ptnr_rates_dmnsn.rate_cd
when sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then ptnr_rates_dmnsn.rate_cd 
WHEN pl_rates_dmnsn.fscl_yr_mth_cd <> "?" and pl_rates_dmnsn.fscl_yr_mth_cd <> 'all' and pl_rates_dmnsn.fscl_yr_mth_cd is not null and 
sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = pl_rates_dmnsn.fscl_yr_mth_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then pl_rates_dmnsn.rt 
WHEN sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then pl_rates_dmnsn.rt ELSE 1 END"""

    var ttl_cst_sls_rt = """CASE when sls_ord_rates_dmnsn.fscl_yr_mth_cd <> "?" and sls_ord_rates_dmnsn.fscl_yr_mth_cd <> 'all' and sls_ord_rates_dmnsn.fscl_yr_mth_cd is not null and sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd  IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = sls_ord_rates_dmnsn.fscl_yr_mth_cd then sls_ord_rates_dmnsn.totl_cst_sls_rate_cd
when sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd then sls_ord_rates_dmnsn.totl_cst_sls_rate_cd 
when prod_rates_dmnsn.fscl_yr_mth_cd <> "?" and prod_rates_dmnsn.fscl_yr_mth_cd <> 'all' and prod_rates_dmnsn.fscl_yr_mth_cd is not null and
 sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = prod_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then prod_rates_dmnsn.totl_cst_sls_rate_cd
 when sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then prod_rates_dmnsn.totl_cst_sls_rate_cd 
 when cust_rates_dmnsn.fscl_yr_mth_cd <> "?" and cust_rates_dmnsn.fscl_yr_mth_cd <> 'all' and cust_rates_dmnsn.fscl_yr_mth_cd is not null and
 ord_dmnsn_adjmt_dmnsn.end_cust_prty_id  = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = cust_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then cust_rates_dmnsn.totl_cst_sls_rate_cd
 when ord_dmnsn_adjmt_dmnsn.end_cust_prty_id  = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and  sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then cust_rates_dmnsn.totl_cst_sls_rate_cd 
 WHEN ptnr_rates_dmnsn.fscl_yr_mth_cd <> "?" and ptnr_rates_dmnsn.fscl_yr_mth_cd <> 'all' and ptnr_rates_dmnsn.fscl_yr_mth_cd is not null and
sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = ptnr_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then ptnr_rates_dmnsn.totl_cst_sls_rate_cd
when sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then ptnr_rates_dmnsn.totl_cst_sls_rate_cd 
WHEN pl_rates_dmnsn.fscl_yr_mth_cd <> "?" and pl_rates_dmnsn.fscl_yr_mth_cd <> 'all' and pl_rates_dmnsn.fscl_yr_mth_cd is not null and 
sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = pl_rates_dmnsn.fscl_yr_mth_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then pl_rates_dmnsn.totl_cst_sls_rate_cd 
WHEN sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then pl_rates_dmnsn.totl_cst_sls_rate_cd ELSE 1 END"""

    var entrs_std_cst_rate_cd = """CASE when sls_ord_rates_dmnsn.fscl_yr_mth_cd <> "?" and sls_ord_rates_dmnsn.fscl_yr_mth_cd <> 'all' and sls_ord_rates_dmnsn.fscl_yr_mth_cd is not null and sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd  IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = sls_ord_rates_dmnsn.fscl_yr_mth_cd then sls_ord_rates_dmnsn.entrs_std_cst_rate_cd
when sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd then sls_ord_rates_dmnsn.entrs_std_cst_rate_cd 
when prod_rates_dmnsn.fscl_yr_mth_cd <> "?" and prod_rates_dmnsn.fscl_yr_mth_cd <> 'all' and prod_rates_dmnsn.fscl_yr_mth_cd is not null and
 sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = prod_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then prod_rates_dmnsn.entrs_std_cst_rate_cd
 when sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then prod_rates_dmnsn.entrs_std_cst_rate_cd 
 when cust_rates_dmnsn.fscl_yr_mth_cd <> "?" and cust_rates_dmnsn.fscl_yr_mth_cd <> 'all' and cust_rates_dmnsn.fscl_yr_mth_cd is not null and
 ord_dmnsn_adjmt_dmnsn.end_cust_prty_id  = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = cust_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then cust_rates_dmnsn.entrs_std_cst_rate_cd
 when ord_dmnsn_adjmt_dmnsn.end_cust_prty_id  = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and  sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then cust_rates_dmnsn.entrs_std_cst_rate_cd 
 WHEN ptnr_rates_dmnsn.fscl_yr_mth_cd <> "?" and ptnr_rates_dmnsn.fscl_yr_mth_cd <> 'all' and ptnr_rates_dmnsn.fscl_yr_mth_cd is not null and
sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = ptnr_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then ptnr_rates_dmnsn.entrs_std_cst_rate_cd
when sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then ptnr_rates_dmnsn.entrs_std_cst_rate_cd 
WHEN pl_rates_dmnsn.fscl_yr_mth_cd <> "?" and pl_rates_dmnsn.fscl_yr_mth_cd <> 'all' and pl_rates_dmnsn.fscl_yr_mth_cd is not null and 
sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = pl_rates_dmnsn.fscl_yr_mth_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then pl_rates_dmnsn.entrs_std_cst_rate_cd 
WHEN sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then pl_rates_dmnsn.entrs_std_cst_rate_cd ELSE 1 END"""

    var exch_rt = """CASE WHEN frm_curr_unts_rto_2_nr = to_curr_unts_rto_2_nr 
THEN CAST(((frm_curr_unts_rto_2_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_2_nr) AS DOUBLE) 
WHEN frm_curr_unts_rto_2_nr > to_curr_unts_rto_2_nr 
THEN CAST(((to_curr_unts_rto_2_nr/indrt_qted_exch_rate_nr)*frm_curr_unts_rto_2_nr) AS DOUBLE) 
WHEN frm_curr_unts_rto_2_nr < to_curr_unts_rto_2_nr THEN CAST(((frm_curr_unts_rto_2_nr/indrt_qted_exch_rate_nr)*to_curr_unts_rto_2_nr) AS DOUBLE) END"""

    var query = """
COALESCE(sls_spmt.e1edp01_itm_nr,""),COALESCE(sls_spmt.sm_dtl_sm_id,""),COALESCE(sls_spmt.sm_dtl_sm_itm_nr,""),COALESCE(sls_spmt.sm_sm_id,""),COALESCE(sls_spmt.e1edk01_idoc_dcmt_nr,""),COALESCE(sls_spmt.e1edp01_itm_nr,""),COALESCE(rvn_rcgn_mppg_trsn.rvn_rcgn_cntrct_id,""),COALESCE(rvn_rcgn_mppg_trsn.prfm_obgn_id,"")))) as secrd_rpt_fact_ky,
crc32(LOWER(COALESCE(sls_spmt.e1edka1_ptnr_nr_ZC,""))) as mdm_cust_ky,
crc32(LOWER(COALESCE(sls_spmt.cst_cntr_cd,""))) as cst_cntr_ky,
crc32(LOWER(COALESCE(sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2,""))) as pdm_mtrl_mstr_grp_ky,
crc32(LOWER(COALESCE(sls_spmt.pft_cntr_nm,""))) as pft_cntr_ky,
crc32(LOWER(COALESCE(sls_spmt.sgmnt_cd,""))) as mgmt_grphy_unt_ky,
crc32(LOWER(COALESCE(rvn_rcgn_pstg_trsn.fnctl_ar_cd,""))) as fnctl_ar_ky,
NULL as cntry_ky,
crc32(LOWER(COALESCE(sls_spmt.e1edka1_ptnr_nr_AG,""))) as sld_to_ky,
crc32(LOWER(COALESCE(sls_spmt.e1edka1_ptnr_nr_WE,""))) as shp_to_ky,
crc32(LOWER(COALESCE(sls_spmt.e1edka1_ptnr_nr_RE,""))) as bll_to_ky,
NULL as vndr_ky,
crc32(LOWER(COALESCE(rvn_rcgn_pstg_trsn.gnrl_ldgr_acct_nr,""))) as gl_acct_ky,
crc32(LOWER(COALESCE(sls_spmt.pypl_pch_level_8,""))) as py_pft_cntr_ky,
crc32(LOWER(COALESCE(sls_spmt.oypl_pch_level_8,"")) )as oy_pft_cntr_ky,
crc32(LOWER(COALESCE(sls_spmt.fypl_pch_level_8,""))) as fy_pft_cntr_ky,
crc32(LOWER(COALESCE(sls_spmt.deal_id_nm,""))) as deal_ky,
crc32(LOWER(COALESCE(sls_spmt.lgcy_qt_nr,""))) as quote_ky,
crc32(LOWER(COALESCE(sls_spmt.zord_header_opty_id,""))) as opty_ky,
crc32(LOWER(COALESCE(sls_spmt.e1edk01_idoc_dcmt_nr,""))) as ord_hddr_ky,
crc32(LOWER(concat(COALESCE(sls_spmt.e1edk01_idoc_dcmt_nr,""),COALESCE(sls_spmt.e1edp01_itm_nr,"")))) as ord_itm_ky, 
sls_spmt.pftblty_anlys_hdr_tbl_co_cd as entrs_lgl_ent_ldgr_ky,
sls_spmt.e1edk03_ido_1_id_25 as cldr_rpt_ky,
sls_spmt.dt_and_ts as HP_rcvd_dt_txt,
sls_spmt.e1edp01_itm_nr as sls_ord_ln_itm_id,
sls_spmt.e1edk01_idoc_dcmt_nr as sls_ord_id,
sls_spmt.deal_id_nm as deal_id,
sls_spmt.collective_sd_nr as mkt_rte_cd,
sls_spmt.zord_header_opty_id as opty_id,
sls_spmt.e1edk14_idoc_org_nm_12 as ord_typ_cd,
sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 as mtrl_nr,
'SERP' as src_sys_cd,
cast(from_unixtime(unix_timestamp(cast(sls_spmt.utc_ts_lg_form_cd as string), 'yyyyMMddHHmmss')) as timestamp) as src_sys_ts,
from_unixtime(unix_timestamp(sls_spmt.e1edk03_ido_1_id_25,'yyyyMMdd'),'yyyy-MM-dd') as ord_crt_dt,
cast(from_unixtime(unix_timestamp(concat(sls_spmt.e1edk03_ido_1_id_25,sls_spmt.e1edk03_ido_2_id_25),'yyyyMMddHHmmss'))as timestamp) as ord_crt_ts,
sls_spmt.last_chg_dt as ord_last_chg_dt,
from_unixtime(unix_timestamp(sls_spmt.dt_and_ts,'yyyyMMddHHmmss'),'yyyy-MM-dd HH:mm:ss') as HP_rcvd_dt,
sls_spmt.lgcy_qt_nr as quote_id,
sls_spmt.e1eds01_totl_vl_sum_sgm_nm_2 as ord_net_vl_amt,
sls_spmt.e1edk01_curr_cd as ord_dcmnt_curr_cd,
case when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else (sls_spmt.e1eds01_totl_vl_sum_sgm_nm_2 * sls_spmt.exch_rate_0MM ) end as ord_hddr_nt_vl_usd_amt,
sls_spmt.e1edk14_idoc_org_nm_8 as sls_orgn_cd,
sls_spmt.e1edk14_idoc_org_nm_7 as dstbn_chnl_cd,
sls_spmt.e1edk14_idoc_org_nm_6 as dvsn_cd,
sls_spmt.e1edk14_idoc_org_nm_10 as sls_grp_cd,
sls_spmt.e1edk14_idoc_org_nm_16 as sls_offc_cd,
sls_spmt.cst_cntr_cd as cst_cntr_cd,
sls_spmt.e1edp02_idoc_dcmt_nr_1 as cust_po_nr,
sls_spmt.e1edk14_idoc_org_nm_19 as cust_po_typ_cd,
sls_spmt.po_cgy_nm as cust_po_cgy_cd,
sls_spmt.e1edka1_ptnr_nr_AG as sld_to_cd,
sls_spmt.e1edka1_ptnr_nr_WE as shp_to_cd,
sls_spmt.e1edka1_ptnr_nr_ZC as end_cust_cd,
sls_spmt.e1edka1_ptnr_nr_RE as bll_to_cd,
sls_spmt.e1edk01_dlvry_blck_dcmt_hdr_cd as ord_dlvry_cd,
sls_spmt.blng_grp_cd  as bll_grp_cd,
sls_spmt.prchg_agrmnt_nm as ord_prch_cd,
sls_spmt.dc_cd as dc_cd,
sls_spmt.sls_rep_cd as sls_rep_cd,
sls_spmt.zord_header_usr_stts_nm as ord_hddr_stts_cd,
sls_spmt.zord_itm_usr_status as ord_itm_stts_cd,
sls_spmt.e1edp01_sls_dcmt_itm_cgy_cd as sls_dcmt_itm_cgy_cd,
sls_spmt.hgh_lvl_itm_lnkg_cd as mtrl_str_cd,
(case when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else sls_spmt.e1edp01_qty_nm end) as ord_itm_qty,
sls_spmt.e1edp01_unt_msr_cd as unt_msr_cd,
sls_spmt.e1edp01_prc_nt_nm as nt_prc_amt,
(case when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else sls_spmt.e1edp01_itm_vl_nt_nm end) as ord_itm_nt_vl_amt,
sls_spmt.e1edp01_curr_cd as ord_itm_dcmt_curr_cd,
(sls_spmt.e1edp01_prc_nt_nm * sls_spmt.exch_rate_0MM) as nt_prc_usd_amt,
((case when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else sls_spmt.e1edp01_itm_vl_nt_nm end) * sls_spmt.exch_rate_0MM) as ord_itm_nt_vl_usd_amt,
sls_spmt.cust_po_ln_nr as cust_ord_itm_po_nr,
sls_spmt.e1edp01_plnt_cd as plnt_cd,
sls_spmt.e1edp01_storg_lctn_cd as strg_loc_cd,
sls_spmt.e1edp01_shpg_pointreceiving_pnt_cd as shpg_pt_cd,
sls_spmt.derived_route as rte_cd,
from_unixtime(unix_timestamp(sls_spmt.e1edp03_dt_25,'yyyyMMdd'),'yyyy-MM-dd') as ord_itm_crt_dt,
cast(from_unixtime(unix_timestamp(concat(sls_spmt.e1edp03_dt_25,sls_spmt.e1edp03_tm_cd_25),'yyyyMMddHHmmss'))as timestamp) as ord_itm_crt_ts,
sls_spmt.pft_cntr_nm as prft_cntr_cd,
sls_spmt.cypl_pch_level_3 as pch_lvl_3,
sls_spmt.cypl_pch_level_4 as pch_lvl_4,
sls_spmt.cypl_pch_level_5 as pch_lvl_5,
sls_spmt.cypl_pch_level_6 as pch_lvl_6,
sls_spmt.cypl_pch_level_7 as pch_lvl_7,
sls_spmt.cypl_pch_level_8 as pch_lvl_8,
sls_spmt.oypl_pch_level_1 as oypl_pch_level_1,
sls_spmt.oypl_pch_level_2 as oypl_pch_level_2,
sls_spmt.oypl_pch_level_3 as oypl_pch_level_3,
sls_spmt.oypl_pch_level_4 as oypl_pch_level_4,
sls_spmt.oypl_pch_level_5 as oypl_pch_level_5,
sls_spmt.oypl_pch_level_6 as oypl_pch_level_6,
sls_spmt.oypl_pch_level_7 as oypl_pch_level_7,
sls_spmt.oypl_pch_level_8 as oypl_pch_level_8,
sls_spmt.oypl_pch_level_1_desc as oypl_pch_level_1_desc,
sls_spmt.oypl_pch_level_2_desc as oypl_pch_level_2_desc,
sls_spmt.oypl_pch_level_3_desc as oypl_pch_level_3_desc,
sls_spmt.oypl_pch_level_4_desc as oypl_pch_level_4_desc,
sls_spmt.oypl_pch_level_5_desc as oypl_pch_level_5_desc,
sls_spmt.oypl_pch_level_6_desc as oypl_pch_level_6_desc,
sls_spmt.oypl_pch_level_7_desc as oypl_pch_level_7_desc,
sls_spmt.oypl_pch_level_8_desc as oypl_pch_level_8_desc,
sls_spmt.pypl_pch_level_8 as py_pft_cntr_cd,
sls_spmt.fypl_pch_level_8 as fy_pft_cntr_cd,
sls_spmt.sgmnt_cd as sgmtl_rptg_cd,
segment_std_hrchy.sg_level_3 as sgm_lvl_2,
segment_std_hrchy.sg_level_4 as sgm_lvl_3,
segment_std_hrchy.sg_level_5 as sgm_lvl_4,
segment_std_hrchy.sg_level_6 as sgm_lvl_5,
segment_std_hrchy.sg_level_7 as sgm_lvl_6,
segment_std_hrchy.sg_level_8 as sgm_lvl_7,
NULL as sgm_lvl_8,
sls_spmt.mfrg_vsblty_stts_cd as ord_itm_vsblty_stts_cd,
sls_spmt.bndl_qty as ord_itm_bndl_qty,
sls_spmt.prmtn_cd as ord_itm_prmtn_cd,
sls_spmt.zord_item_opty_id_nm as ord_itm_opty_cd,
sls_spmt.zord_item_prch_agrmnt_nr as  ord_itm_prch_cd,
sls_spmt.cust_po_ln_nr as cust_po_ln_nr,
sls_spmt.zord_header_sys_stts_ln_nm as zord_header_sys_stts_ln_nm,
sls_spmt.zord_item_sys_stts_ln_nm as zord_item_sys_stts_ln_nm,
rvn_rcgn_mppg_trsn.rvn_acctng_itm_src_dcmt_hdr_id as rvn_acctng_itm_src_dcmt_hdr_id,
sls_spmt.blng_blck_cd as blng_blck_sd_dcmt_cd,
sls_spmt.zord_item_prch_agrmnt_nr as prch_agrmnt_nr,
sls_spmt.ppr_ctrl_cd as ppr_cd,
sls_spmt.e1edk14_idoc_org_nm_19 as prch_ord_typ,
sls_spmt.pmnt_trms_cd as pmnt_trms_cd,
sls_spmt.zord_header01_ovrl_stts_crdt_chks_cd as crdt_stts,
from_unixtime(unix_timestamp(sls_spmt.e1edk03_ido_1_id_2,'yyyyMMdd'),'yyyy-MM-dd') as crdd_cust_rqst_dt,
from_unixtime(unix_timestamp(sls_spmt.dt_and_ts,'yyyyMMdd'),'yyyy-MM-dd') as ord_etry_dt,
sls_spmt.e1edka1_ptnr_nr_Z1 as rslr_nr,
sls_spmt.bndl_dn as bndl_dn,
sls_spmt.e1edl24_bom_explsn_nr as sr_nr,
sls_spmt.zord_item_bndl_id as bndl_id,
sls_spmt.bndl_qty as bndl_qty,
sls_spmt.e1edl24_mtrl_belonging_to_cus_1_nm as mtrl_belonging_to_cus_nm,
sls_spmt.zord_header_alrt_sls_ord_to_sfd_2_nm as hdr_hold_cd,
sls_spmt.sls_ord_itm_lvl_hld_cd as itm_hold_cd,
sls_spmt.estmd_inv_dt as estmd_inv_dt,
sls_spmt.opt_Shipment_qty as opt_Shipment_qty,
sls_spmt.quote_distribution_date as quote_distribution_date,
sls_spmt.srv_agrmnt_id_SA_id_id  as srv_agrmnt_id,
sls_spmt.e1edk01_shpg_cnd_cd as shpg_cnd_cd,
sls_spmt.ord_vl as ord_vl,
sls_spmt.sls_tty_id as sls_tty_id,
sls_spmt.dlvry_typ_cd as dlvry_typ_cd,
sls_spmt.sm_sm_id as dlvry_id,
sls_spmt.sm_dtl_sm_itm_nr as dlvry_itm_id,
sls_spmt.e1edt13_cnstr_actvy_strt_bsc_dt_6 as actl_dlvry_dt,
sls_spmt.sm_dtl_sls_dcmt_itm_cgy_cd as dlvry_itm_cgy_cd,
sls_spmt.sm_nr as shpmt_id,
sls_spmt.itm_rfnc_itm_nr as shpmt_itm_id,
sls_spmt.e1edt10_actl_exctn_strt_tm_ts_5 as plnd_shp_strt_dt,
sls_spmt.e1edt10_actl_exctn_end_tm_ts_5 as plnd_shp_end_dt,
sls_spmt.e1edt13_cnstr_actvy_strt_bsc_dt_6 as sm_actl_gds_mvmt_dt,
sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr as invc_id,
sls_spmt.sls_blng_itm_e1edp01_itm_nr as invc_ln_itm_id,
sls_spmt.blng_typ_cd as blng_typ_cd,
from_unixtime(unix_timestamp(sls_spmt.e1edp03_dt_25,'yyyyMMdd'),'yyyy-MM-dd') as actl_inv_dt,
case when sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 like '%#%' then 0 else (case when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else sls_spmt.e1edp01_qty_nm end) end as base_qty, 
sls_spmt.Sales_Shipment_Unit_Quantity as unt_qty,
sls_spmt.e1edp01_wght_unt_cd as wght_cd,
sls_spmt.e1edp26_totl_vl_sum_sgm_nm_3 as nt_inv_vl_amt,
sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 as grs_inv_vl_amt,
(sls_spmt.e1edp26_totl_vl_sum_sgm_nm_3 * sls_spmt.exch_rate_0MM) as cp_net_inv_usd_amt,
(sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 * sls_spmt.exch_rate_0MM) as cp_grs_inv_usd_amt,
CASE WHEN (case when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else sls_spmt.e1edp01_itm_vl_nt_nm end) = sls_spmt.Discount_Sales_Shipment_Document_Currency_Amount and sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 =0.00 or sls_spmt.e1edp26_totl_vl_sum_sgm_nm_2 is NULL THEN 'N' ELSE 'Y' END as crdt_dbt_ind,
CASE WHEN sls_spmt.Discount_Sales_Shipment_Document_Currency_Amount = 0 or Discount_Sales_Shipment_Document_Currency_Amount IS NULL THEN 'N' ELSE 'Y' END as dscnt_ind,
CASE WHEN UPPER(sls_spmt.e1edk02_idoc_dcmt_nr_1) like '%ICOEM%' THEN 'Y' ELSE 'N' END as icoem_ind,
case when sls_spmt.multiyear_po_typ_cd ='0' then 'N' when sls_spmt.multiyear_po_typ_cd ='1'then 'Y' else sls_spmt.multiyear_po_typ_cd end as mlt_yr_ind,
sls_spmt.prepaid_cntrct_flg_id as prepaid_ind,
rvn_rcgn_mppg_trsn.rvn_rcgn_cntrct_id as cntrct_id,
rvn_rcgn_mppg_trsn.prfm_obgn_id as pob_id,
rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky as recon_ky_cd,
substr(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,0,4) as fscl_yr_nr,
substr(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,5,3) as fscl_prd_nr,
concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) as fscl_yr_prd_cd,
CASE WHEN (substr(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,5,3)) IN ('001','002','003') THEN 'Q1' WHEN (substr(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,5,3)) IN ('004','005','006') THEN 'Q2' WHEN (substr(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,5,3)) IN ('007','008','009' ) THEN 'Q3' WHEN (substr(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,5,3)) IN ('010','011','012' ) THEN 'Q4' else NULL end as fscl_qtr_nr,
rvn_rcgn_dfrd_itm_trsn.cndn_typ_cd as cndn_typ_cd,
rvn_rcgn_pstg_trsn.gnrl_ldgr_acct_nr as gl_acct_nr,
CASE WHEN eurofit_flag in ('O', 'X', 'Y','Z') and eurofit_split_percentage is NOT NULL then rvn_rcgn_pstg_trsn.trsn_curr_amt * (eurofit_split_percentage/100) else rvn_rcgn_pstg_trsn.trsn_curr_amt END as pstd_rvn_amt,
rvn_rcgn_pstg_trsn.curr_ky as pstd_rvn_curr,
CASE WHEN eurofit_flag in ('O', 'X', 'Y','Z') and eurofit_split_percentage is NOT NULL then rvn_rcgn_pstg_trsn.scnd_prll_lcl_curr_amt * (eurofit_split_percentage/100) else rvn_rcgn_pstg_trsn.scnd_prll_lcl_curr_amt END as pstd_rvn_usd_amt,
CASE WHEN eurofit_flag in ('O', 'X', 'Y','Z') and eurofit_split_percentage is NOT NULL then rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt * (eurofit_split_percentage/100) else rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt END as estmd_rvn_amt,
CASE WHEN eurofit_flag in ('O', 'X', 'Y','Z') and eurofit_split_percentage is NOT NULL then rvn_rcgn_dfrd_itm_trsn.rvn_dlta_qty * (eurofit_split_percentage/100) else rvn_rcgn_dfrd_itm_trsn.rvn_dlta_qty END as rvn_dlta_qty,
rvn_rcgn_dfrd_itm_trsn.curr_ky as estmd_rvn_curr,
CASE WHEN eurofit_flag in ('O', 'X', 'Y','Z') and eurofit_split_percentage is NOT NULL then (CASE WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky = 'USD' THEN (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / 1)
WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky is NULL THEN NULL 
ELSE (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / (""" + exch_rt + """)) END) * (eurofit_split_percentage/100) else (CASE WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky = 'USD' THEN (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / 1)
WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky is NULL THEN NULL 
ELSE (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / (""" + exch_rt + """)) END) end as estmd_rvn_usd_amt,
CASE WHEN eurofit_flag in ('O', 'X', 'Y','Z') and eurofit_split_percentage is NOT NULL then (COALESCE(rvn_rcgn_pstg_trsn.trsn_curr_amt,0)+COALESCE(rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt,0)) * (eurofit_split_percentage/100) else (COALESCE(rvn_rcgn_pstg_trsn.trsn_curr_amt,0)+COALESCE(rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt,0)) end as ttl_rvn_amt,
CASE WHEN eurofit_flag in ('O', 'X', 'Y','Z') and eurofit_split_percentage is NOT NULL then (COALESCE(rvn_rcgn_pstg_trsn.scnd_prll_lcl_curr_amt,0)  + (CASE WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky = 'USD' THEN (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / 1)
WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky is NULL THEN NULL 
ELSE (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / (""" + exch_rt + """)) END) ) * (eurofit_split_percentage/100) else (COALESCE(rvn_rcgn_pstg_trsn.scnd_prll_lcl_curr_amt,0)  + (CASE WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky = 'USD' THEN (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / 1)
WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky is NULL THEN NULL 
ELSE (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / (""" + exch_rt + """)) END) ) end as ttl_rvn_usd_amt,
sls_spmt.ln_itm_dcmt_nr as ln_itm_dcmt_nr,
sls_spmt.itm_ln_itm_nr as ln_itm_nr,
sls_spmt.itm_subnumber_ln_itm_nr as ln_itm_sub_nr,
sls_spmt.rec_typ_cd as rec_typ_cd,
sls_spmt.pftblty_sgm_copa_nr as pftblty_sgm_copa_nr,
sls_spmt.pln_vrsn_copa_cd as pln_vrsn_copa_cd,
sls_spmt.crtd_by_cd as crtd_by,
sls_spmt.dcmt_crtd_dt as dcmt_crtd_dt,
sls_spmt.crtd_at_cd as crtd_at,
sls_spmt.utc_tm_stamp_cd as utc_tm_stamp,
sls_spmt.pstg_dt as pstg_dt,
sls_spmt.gds_iss_dt as gds_iss_dt,
sls_spmt.inv_crtd_dt as inv_crtd_dt,
sls_spmt.copa_pnt_valtn_cd as copa_pnt_valtn_cd,
sls_spmt.ind_blld_cd as blld_ind,
sls_spmt.blng_prd_cd as blng_prd_cd,
sls_spmt.rfnc_prcgr_cd as rfnc_prcgr_cd,
sls_spmt.rfnc_orgnl_unt_cd as rfnc_orgnl_unt_cd,
sls_spmt.lgcl_sys_src_dcmt_cd as lgcl_sys_src_dcmt_cd,
sls_spmt.rfnc_dcmt_copa_ln_itm_nr as rfnc_dcmt_copa_ln_itm_cd,
sls_spmt.itm_frm_rfnc_dcmt_copa_nr as itm_frm_rfnc_dcmt_copa_cd,
sls_spmt.rfnc_subitem_nr as rfnc_subitem_cd,
sls_spmt.cnld_dcmt_cd as cnld_dcmt_cd,
sls_spmt.cnld_dcmt_it_1_cd as cnld_dcmt_it_1_cd,
sls_spmt.cnld_subnumber_ln_itm_nr as cnld_subnumber_ln_itm_cd,
sls_spmt.dltd_by_dcmt_cd as dltd_by_dcmt_cd,
sls_spmt.dltd_by_itm_cd as dltd_by_itm_cd,
sls_spmt.cnld_by_dcmt_cd as cnld_by_dcmt_cd,
sls_spmt.cnld_dcmt_it_2_cd as cnld_dcmt_it_2_cd,
sls_spmt.pftblty_anlys_hdr_tbl_co_cd as co_cd,
sls_spmt.ctrlng_ar_cd as ctrlng_ar_cd,
sls_spmt.bsn_ar_cd as bsn_ar_cd,
rvn_rcgn_pstg_trsn.fnctl_ar_cd as fnctl_ar_cd,
sls_spmt.ptnr_pft_cntr_cd as ptnr_pft_cntr_cd,
sls_spmt.sndr_cst_cntr_cd as sndr_cst_cntr_cd,
sls_spmt.sndr_bsn_prs_cd as sndr_bsn_prs_cd,
sls_spmt.cst_obj_cd as cst_obj_cd,
sls_spmt.wrk_brkdwn_srtr_elmt_wbs_elmt_cd as wbs_elmt_cd,
sls_spmt.eqpmnt_nr as eqpmnt_cd,
sls_spmt.sales_doc_orignal_cd as sls_doc_original_cd,
sls_spmt.srv_cntrct_cd as srv_cntrct_cd,
sls_spmt.otc_cd as otc_cd,
sls_spmt.srv_evt_id as srv_evt_id,
sls_spmt.ts_sls_mtn_cd as ts_sls_mtn_cd,
NULL as po_odm_ic_sto_lbr_cd,
sls_spmt.po_itm_cd as po_itm_cd,
sls_spmt.ven_odm_ic_pn_labr_cd as ven_odm_ic_pn_labr_cd,
sls_spmt.poem_cd as poem_cd,
sls_spmt.emr_new_mtrl_cd as emr_new_mtrl_cd,
sls_spmt.go_mkt_ofr_id as go_mkt_ofr_id,
NULL as hpe_fllfillg_plnt_cd,
sls_spmt.sltn_3_cd as sltn_3_cd,
sls_spmt.sltn_1_cd as sltn_1_cd,
sls_spmt.cust_sgm_cd as cust_sgm_cd,
sls_spmt.sltn_2_cd as sltn_2_cd,
sls_spmt.e1edp01_higherlevel_itm_bom_structures_cd as hghr_lvl_itm_no_cd,
sls_spmt.e1edk01_ord_rsn_rsn_bsn_trsn_cd as ord_rsn_cd,
NULL as valtn_clss_cd,
sls_spmt.src_itm_nr as src_itm_cd,
sls_spmt.mkt_sgm_cd as mkt_sgm_cd,
sls_spmt.mkt_ofrng_cd as mkt_ofrng_cd,
sls_spmt.curr_typ_and_valtn_vw_cd as curr_typ_valtn_vw_cd,
sls_spmt.curr_dta_rec_cd as curr_dta_rec_cd,
sls_spmt.a3_rbt_amt,
sls_spmt.70r_rbt_amt,
sls_spmt.69r_rbt_amt,
sls_spmt.69t_rbt_amt,
sls_spmt.15_rbt_amt,
sls_spmt.4_rmktd_dm_elvtn_amt,
sls_spmt.15r_pmnt_prd_stlmnt_amt,
sls_spmt.72_deal_rgst_amt,
sls_spmt.74tier_deals_amt,
sls_spmt.0709r_prod_prmtns_amt,
sls_spmt.26raingstock_amt,
sls_spmt.77eend_sls_amt,
sls_spmt.77prtnr_spcf_amt,
sls_spmt.10spngtdendcusd_oem_amt,
sls_spmt.79lwmghiendcustdisc_amt,
sls_spmt.72sp_ngtd_endcust_d_amt,
sls_spmt.Discount_Sales_Shipment_Document_Currency_Amount as dscnt_amt,
sls_spmt.qty_dscnt_amt,
sls_spmt.prc_rdctn_amt,
sls_spmt.rvn_amt,
sls_spmt.otgng_frgt_amt,
sls_spmt.vrnc_adjmt_amt,
sls_spmt.93pur_agmnt_disc_amt,
sls_spmt.2x_shpng_hndl_amt,
sls_spmt.2yspl_hndl_amt,
sls_spmt.22basic_frgt_amt,
sls_spmt.60listnet_pr_adjmt_amt,
sls_spmt.35pen_feent_rchd_amt,
sls_spmt.75misc_chg_amt,
sls_spmt.a8bklog_prdcr_prtn_amt,
sls_spmt.12hpe_acmgmt_supprt_amt,
sls_spmt.rw_matspare_prts_amt,
sls_spmt.emr_cst_amt,
sls_spmt.pkgg_amt,
sls_spmt.sub_asbly_contmfg_amt,
sls_spmt.fin_brdn_amt,
sls_spmt.fnshd_mtrls_amt,
sls_spmt.lohp_amt,
sls_spmt.hpe_ovrhd_amt,
sls_spmt.rylty_amt,
sls_spmt.vndr_rebates_amt,
sls_spmt.masking_amt,
sls_spmt.fees_frgt_duty_amt,
sls_spmt.cst_elmt_cd,
sls_spmt.totl_vl_ldgr_curr,
sls_spmt.fix_vl_ldgr_curr,
sls_spmt.eurofit_flag as eurofit_flag,
sls_spmt.eurofit_split_percentage as eurofit_split_percentage,
sls_spmt.acctng_dcmt_nr as acctng_dcmt_cd,
sls_spmt.ln_itm_within_acctng_dcmt_nr as ln_itm_within_acctng_dcmt_cd,
NULL as pftblty_anlys_qty_tbl_src_cst_elmt_cd,
sls_spmt.scndry_cst_elmt_cd as scndry_cst_elmt_cd,
sls_spmt.sls_qty_amt as sls_qty_amt,                
sls_spmt.transaction_country as ctry_cd,
NULL as rgn_cd,
NULL as mtrl_lng_mtrl_dn,
NULL as mtrc_cd,
NULL as mtrc_dn,
NULL as icost_dtl_amt,
NULL as curr_ky,
NULL as dlt_ind,
NULL as rec_ts,
NULL as icost_dtl_oth_fix_cst_amt,
NULL as icost_dtl_var_ryl_cst_amt,   
NULL as icost_dtl_var_trd_exp_cst_amt,   
NULL as icost_dtl_var_warr_cst_amt,    
NULL as icost_dtl_oth_var_cst_amt,
sls_spmt.estimated_sales_cost as entrprs_stndrd_cst_grp_curr_usd_amt, 
icost_dtl_burden_aggregate.icost_dtl_amt as brdn_cst,
(icost_dtl_burden_aggregate.icost_dtl_amt*sls_spmt.e1edp01_qty_nm) as ttl_brdn_cst,
(icost_dtl_burden_aggregate.icost_dtl_amt*sls_spmt.sales_shipment_sales_qy) as ttl_dly_brdn_cst,
(icost_dtl_burden_aggregate.icost_dtl_amt*sls_spmt.sales_shipment_base_quantity) as ttl_base_qty_brdn_cst,
(icost_dtl_burden_aggregate.icost_dtl_amt*sls_spmt.e1edp01_qty_nm_inv) as ttl_inv_brdn_cst,
NULL as ttl_cst_sls_amt,
NULL as ttl_cst_sls_usd_amt,
((((COALESCE(rvn_rcgn_pstg_trsn.trsn_curr_amt,0)+COALESCE(rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt,0))) * (""" + rate_cd + """)) - sls_spmt.estimated_sales_cost) as fctry_mrgn_amt,
NULL as grs_mrgn_amt,
NULL as grs_mrgn_usd_amt,
CASE when sls_ord_rates_dmnsn.fscl_yr_mth_cd <> "?" and sls_ord_rates_dmnsn.fscl_yr_mth_cd <> 'all' and sls_ord_rates_dmnsn.fscl_yr_mth_cd is not null and sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = sls_ord_rates_dmnsn.fscl_yr_mth_cd then 'Sales Order Rates'
when sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd then 'Sales Order Rates' 
when prod_rates_dmnsn.fscl_yr_mth_cd <> "?" and prod_rates_dmnsn.fscl_yr_mth_cd <> 'all' and prod_rates_dmnsn.fscl_yr_mth_cd is not null and
 sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = prod_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then 'Product Rates'
 when sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then 'Product Rates' 
 when cust_rates_dmnsn.fscl_yr_mth_cd <> "?" and cust_rates_dmnsn.fscl_yr_mth_cd <> 'all' and cust_rates_dmnsn.fscl_yr_mth_cd is not null and
 ord_dmnsn_adjmt_dmnsn.end_cust_prty_id = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = cust_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then 'Customer Rates'
 when ord_dmnsn_adjmt_dmnsn.end_cust_prty_id  = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and  sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then 'Customer Rates' 
 WHEN ptnr_rates_dmnsn.fscl_yr_mth_cd <> "?" and ptnr_rates_dmnsn.fscl_yr_mth_cd <> 'all' and ptnr_rates_dmnsn.fscl_yr_mth_cd is not null and
sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = ptnr_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then 'Partner Rates'
when sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then 'Partner Rates' 
WHEN pl_rates_dmnsn.fscl_yr_mth_cd <> "?" and pl_rates_dmnsn.fscl_yr_mth_cd <> 'all' and pl_rates_dmnsn.fscl_yr_mth_cd is not null and 
sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = pl_rates_dmnsn.fscl_yr_mth_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then 'Pl_rates' 
WHEN sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then 'Pl_rates' ELSE NULL END as rt_cnvsn_src,
""" + rate_cd + """ as rvn_cnvrsn_rt,
""" + entrs_std_cst_rate_cd + """ as entrprs_stndrd_cst_rt,
""" + ttl_cst_sls_rt + """ as ttl_cst_sls_rt, """

    val SalesShipmentDF = spark.sql("""
 select distinct crc32(LOWER(CONCAT(COALESCE(sls_spmt.e1edk01_idoc_dcmt_nr,""),
""" + query + """
(((COALESCE(rvn_rcgn_pstg_trsn.trsn_curr_amt,0)+COALESCE(rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt,0))) * (""" + rate_cd + """)) as cp_nt_rvn_amt,
((COALESCE(rvn_rcgn_pstg_trsn.scnd_prll_lcl_curr_amt,0) +  (CASE WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky = 'USD' THEN (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / 1)
WHEN rvn_rcgn_dfrd_itm_trsn.curr_ky is NULL THEN NULL 
ELSE (rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt / (""" + exch_rt + """)) END) ) * (""" + rate_cd + """)) as cp_nt_rvn_usd_amt,
case when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else sls_spmt.NDP_Sales_Shipment_USD_Currency_Amount end as cp_ndp_usd_amt,
case when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else sls_spmt.Gross_Sales_Shipment_USD_Currency_Amount end as cp_grs_usd_amt,
((""" + entrs_std_cst_rate_cd + """) * sls_spmt.estimated_sales_cost) as cp_entprs_std_cst_usd_amt,
((""" + ttl_cst_sls_rt + """) * sls_spmt.sls_qty_amt) as cp_tot_cst_of_sls_usd_amt,
CASE WHEN sls_spmt.sm_sm_id IS NOT NULL AND sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NOT NULL THEN "Revenue" WHEN sls_spmt.sm_sm_id IS NOT NULL AND sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL THEN "SNI" WHEN sls_spmt.sm_sm_id IS NULL AND sls_spmt.sls_blng_itm_e1edk01_idoc_dcmt_nr IS NULL THEN "Backlog" ELSE NULL END as cp_bklg_sni_rvn,
sls_spmt.shp_to_ctry_cd as shp_to_ctry_cd,
sls_spmt.bsn_typ_cd as bsn_typ_cd,
sls_spmt.bsn_rshp_typ_cd as bsn_rshp_typ_cd,
sls_spmt.e1edk17_idoc_dlvry_cndn_txt_nm_1 as inctrms_prt_1_cndtn_txt,
sls_spmt.prtl_dlvry_at_itm_lvl_cd as prtl_dlvry_itm_lvl,  
sls_spmt.shrt_txt_sls_ord_itm_nm as shrt_txt_sls_ord_itm_nm,
sls_spmt.e1edk17_idoc_dlvry_cndn_cd_1 as inctrms_prt_1_cndtn_cd,
sls_spmt.idoc_nr as src_idoc_nr,
sls_spmt.upd_gmt_ts as idoc_crt_dt_ts,
sls_spmt.dlvry_pri_cd as dlvry_pri_hddr_cd,
sls_spmt.e1edp01_dlvry_pri as dlvry_pri_itm_cd,
sls_spmt.e1edp01_d_2_nm as dlvry_pri_dn,
sls_spmt.prod_base_id as prod_base_id,
sls_spmt.e1edk17_idoc_dlvry_cndn_txt_nm_2 as inctrms_prt_2_cndtn_txt,
sls_spmt.fan_nr,
sls_spmt.zord_item01_mtrl_acct_asngmt_cd_grp,
sls_spmt.e1edk17_idoc_dlvry_cndn_cd_2 as inctrms_prt_2_cndtn_cd,
sls_spmt.e1edp01_qty_nm,
sls_spmt.ord_bndl_conf_id,
sls_spmt.estmd_invc_date,
sls_spmt.sls_mtrc_cd,
sls_spmt.ord_durtn_cd,
split(case when (sls_spmt.prod_bs_and_opt_nr is null and sls_spmt.src_type='DOR Orders') then sls_spmt.prod_bs_and_opt_nr 
when sls_spmt.src_type='S4 Orders' then sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 else sls_spmt.prod_bs_and_opt_nr end,'#')[0] as  prod_bs_and_opt_nr,
case when (sls_spmt.prod_id is null and sls_spmt.src_type='DOR Orders') then sls_spmt.prod_id 
when sls_spmt.src_type='S4 Orders' then sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 else sls_spmt.prod_id end as prod_id,
sls_spmt.srvc_gds_prod_id,
sls_spmt.pkg_prod_id,
sls_spmt.e1edka1_ctry_ky_cd_ZC,
sls_spmt.e1edka1_ctry_ky_cd_RE,
sls_spmt.e1edka1_ctry_ky_cd_Z1,
sls_spmt.e1edka1_ctry_ky_cd_WE,
sls_spmt.e1edka1_ctry_ky_cd_AG,
sls_spmt.e1edp19_idoc_mtrl_i_1_nm_1,
sls_spmt.e1edt13_cnstr_actvy_strt_bsc_dt_7,
sls_spmt.spmt_prf_dlvry_dt as sm_prf_dlvry_cfrn_dt,
sls_spmt.e1edk03_ido_1_id_22,
sls_spmt.rsn_at_ln_itm_cd,
sls_spmt.intangible_ln_itm_stts_cd,
sls_spmt.e1edk03_ido_1_id_2,
sls_spmt.cust_grp_3_cd,
sls_spmt.e1edk01_cmplt_dlvry_dfnd_each_sls_ord_cd,
sls_spmt.e1edk01_idoc_dcmt_nr,
sls_spmt.blng_stts_orderrelated_blng_dcmt_cd,
sls_spmt.itm_stts_cd ,
sls_spmt.ois_trsn_nr,
sls_spmt.ord_st_cd,
sls_spmt.e1edk18_txt_ln_nm_1,
sls_spmt.atp_chk_flg_cd,
sls_spmt.sm_dtl_dlvry_grp_nr ,
sls_spmt.sm_dlvry_trns_stts_cd,
sls_spmt.shp_athzn_ltr_nm,
sls_spmt.cntrct_strt_dt,
sls_spmt.cntrct_end_dt,
sls_spmt.e1edk02_idoc_qlfr_rfnc_dcmt_id_11 as rfrnc_dcmt_nr_qlfr,
sls_spmt.e1edk02_idoc_dcmt_nr_11 as rfrnc_dcmt_nr,
sls_spmt.e1edk02_itm_nr_11 as rfrnc_dcmt_itm_nr,
from_unixtime(unix_timestamp(sls_spmt.e1edk02_ido_1_id_11,'yyyyMMdd'),'yyyy-MM-dd') as rfrnc_dcmt_nr_dt,
sls_spmt.e1edk02_ido_2_id_11 as rfrnc_dcmt_nr_tm,
ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm as Calc_cst_EK02_amt,
ord_conditional_itm_dmnsn.e1edp05_fx_surchargediscount_totl_grs_nm_usd as Calc_cst_EK02_usd_amt,
sls_spmt.src_sys_upd_ts as src_sys_upd_ts,
sls_spmt.src_sys_ky as src_sys_ky,
sls_spmt.lgcl_dlt_ind as lgcl_dlt_ind,
sls_spmt.ins_gmt_ts as ins_gmt_ts,
sls_spmt.upd_gmt_ts as upd_gmt_ts,
sls_spmt.src_sys_extrc_gmt_ts as src_sys_extrc_gmt_ts,
sls_spmt.src_sys_btch_nr as src_sys_btch_nr,
sls_spmt.fl_nm as fl_nm,
CASE WHEN ord_dmnsn_adjmt_dmnsn.end_cust_prty_id IS NULL THEN sls_spmt.e1edka1_ptnr_nr_ZC ELSE ord_dmnsn_adjmt_dmnsn.end_cust_prty_id END as cp_end_cust_prty_id,
prty.prty_nm as cp_end_cust_prty_nm,
CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END as cp_rtm_nm,
sls_spmt.e1edka1_ptnr_nr_AG as cp_sldt_prty_id,
sls_spmt.e1edka1_ptnr_nr_WE as cp_shpt_prty_id,
sls_spmt.pft_cntr_nm as cp_prft_ctr_cd,
sls_spmt.sgmnt_cd as cp_segment_cd,
cast ((case when sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd is not null then 0 else sls_spmt.e1edp01_qty_nm end) as double) as cp_unit_qty,
CASE WHEN ord_dmnsn_adjmt_dmnsn.sls_ord_id IS NULL THEN 'N' ELSE 'Y' END as fnc_adjmt_ind,
sls_spmt.exch_rate_nm,
sls_spmt.cust_cndn_grp_1_cd,
sls_spmt.cust_cndn_grp_2_cd,
sls_spmt.cust_cndn_grp_3_cd,
sls_spmt.cust_cndn_grp_4_cd,
sls_spmt.cust_cndn_grp_5_cd,
sls_spmt.cust_cndn_grp_1_cd_1,
sls_spmt.cust_cndn_grp_2_cd_1,
sls_spmt.cust_cndn_grp_3_cd_1,
sls_spmt.cust_cndn_grp_4_cd_1,
sls_spmt.cust_cndn_grp_5_cd_1,
sls_spmt.exch_rate_12MM,
sls_spmt.exch_rate_3MM,
sls_spmt.exch_rate_0MM,
sls_spmt.exch_rate_typ_id,
sls_spmt.ope_bmt_rslr_prty_id,
sls_spmt.mdm_ship_to_prty,
sls_spmt.mdm_sld_to_prty_nm,
sls_spmt.ld_jb_nr as ld_jb_nr,
sls_spmt.rsn_rjctn_quotations_and_sls_orders_cd,
sls_spmt.zord_hdr_ovrl_status as zord_hdr_ovrl_status
FROM """+dbCommonName+""".sales_shipment_dmnsn sls_spmt 
left outer join """+dbNameConsmtn+""".rvn_rcgn_mppg_dmnsn rvn_rcgn_mppg_trsn on sls_spmt.e1edk01_idoc_dcmt_nr=substring(rvn_rcgn_mppg_trsn.src_itm_id,1,10) and sls_spmt.e1edp01_itm_nr=substring(rvn_rcgn_mppg_trsn.src_itm_id,(length(rvn_rcgn_mppg_trsn.src_itm_id)-5),6) 
left outer join """+dbNameConsmtn+""".rvn_rcgn_cntrct_dmnsn rvn_rcgn_cntrct_trsn on rvn_rcgn_mppg_trsn.rvn_rcgn_cntrct_id=rvn_rcgn_cntrct_trsn.rvn_rcgn_cntrct_id 
left outer join """+dbNameConsmtn+""".rvn_rcgn_dfrd_itm_dmnsn rvn_rcgn_dfrd_itm_trsn on rvn_rcgn_mppg_trsn.rvn_rcgn_cntrct_id=rvn_rcgn_dfrd_itm_trsn.rvn_rcgn_cntrct_id and rvn_rcgn_mppg_trsn.prfm_obgn_id=rvn_rcgn_dfrd_itm_trsn.prfm_obgn_id and rvn_rcgn_dfrd_itm_trsn.cndn_typ_cd='Z101' and rvn_rcgn_dfrd_itm_trsn.etry_ltst_ind='X' and rvn_rcgn_dfrd_itm_trsn.rvn_dlta_amt<>0 
left outer join """+dbNameConsmtn+""".rvn_rcgn_pstg_dmnsn rvn_rcgn_pstg_trsn on rvn_rcgn_dfrd_itm_trsn.prfm_obgn_id=rvn_rcgn_pstg_trsn.prfm_obgn_id and rvn_rcgn_dfrd_itm_trsn.rvn_rcgn_cntrct_id=rvn_rcgn_pstg_trsn.rvn_rcgn_cntrct_id and rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky=rvn_rcgn_pstg_trsn.rvn_rcncltn_ky and rvn_rcgn_dfrd_itm_trsn.cndn_typ_cd=rvn_rcgn_pstg_trsn.cndn_typ_cd
left outer join (select * from """+dbCommonName+""".ord_conditional_itm_dmnsn where e1edp05_cndn_typ_coded_cd='EK02') ord_conditional_itm_dmnsn on sls_spmt.e1edk01_idoc_dcmt_nr=ord_conditional_itm_dmnsn.e1edk01_idoc_dcmt_nr and sls_spmt.e1edp01_itm_nr=ord_conditional_itm_dmnsn.e1edp01_itm_nr and sls_spmt.idoc_nr=ord_conditional_itm_dmnsn.idoc_nr
LEFT JOIN 
(select * from """+dbNameConsmtn+""".exch_rates_dmnsn exch where exch_rate_typ_cd = 'M' and to_curr_cd = 'USD' and  DAY(etry_vld_frm_ts) = 1) exch 
on
rvn_rcgn_dfrd_itm_trsn.curr_ky = exch.frm_curr_cd and 
month(to_date(from_unixtime(UNIX_TIMESTAMP(rvn_rcgn_cntrct_trsn.cntrct_crtn_ts,'yyyyMMdd')))) = month(exch.etry_vld_frm_ts) and 
year(to_date(from_unixtime(UNIX_TIMESTAMP(rvn_rcgn_cntrct_trsn.cntrct_crtn_ts,'yyyyMMdd')))) = year(exch.etry_vld_frm_ts) 
left outer join """+dbCommonName+""".bmt_ord_dmnsn_adjmt_dmnsn ord_dmnsn_adjmt_dmnsn on sls_spmt.e1edk01_idoc_dcmt_nr = ord_dmnsn_adjmt_dmnsn.sls_ord_id 
left outer join """+dbCommonName+""".segment_std_hrchy segment_std_hrchy on segment_std_hrchy.sg_level_8 = sls_spmt.sgmnt_cd
left outer join """+dbNameConsmtn+""".icost_dtl_burden_aggregate icost_dtl_burden_aggregate on icost_dtl_burden_aggregate.ctry_cd=sls_spmt.e1edka1_ctry_ky_cd_AG and icost_dtl_burden_aggregate.mtrl_mstr_mtrl_id=sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 and icost_dtl_burden_aggregate.clndr_yr_prd=((case when substr(substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7),6,7)=='01' 
then concat(cast((cast(substr(substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7),1,4) as int))-1 as string),'11')
when substr(substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7),6,7)=='02' 
then concat(cast((cast(substr(substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7),1,4) as int))-1 as string),'12')
else concat(substr(substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7),1,4),
case when ((cast(substr(substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7),6,7) as int))-2)<10 then concat('0',cast((cast(substr(substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7),6,7) as int))-2 as string))
else 
cast((cast(substr(substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7),6,7) as int))-2 as string) end) end))
left outer join """+dbCommonName+""".bmt_sls_ord_rates_dmnsn sls_ord_rates_dmnsn on 
case 
when sls_ord_rates_dmnsn.fscl_yr_mth_cd <> "?" and sls_ord_rates_dmnsn.fscl_yr_mth_cd <> 'all' and sls_ord_rates_dmnsn.fscl_yr_mth_cd is not null and sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = sls_ord_rates_dmnsn.fscl_yr_mth_cd then 1
when sls_spmt.e1edk01_idoc_dcmt_nr = sls_ord_rates_dmnsn.sls_ord_id and sls_spmt.pft_cntr_nm=sls_ord_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=sls_ord_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=sls_ord_rates_dmnsn.rte_to_mkt_cd then 1
else 0 end = 1
left outer join """+dbCommonName+""".bmt_prod_rates_dmnsn prod_rates_dmnsn on
case 
when prod_rates_dmnsn.fscl_yr_mth_cd <> "?" and prod_rates_dmnsn.fscl_yr_mth_cd <> 'all' and prod_rates_dmnsn.fscl_yr_mth_cd is not null and
 sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = prod_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then 1
 when sls_spmt.e1edp19_idoc_mtrl_i_1_nm_2 = prod_rates_dmnsn.prod_id and segment_std_hrchy.sg_level_3=prod_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=prod_rates_dmnsn.rte_to_mkt_cd and sls_spmt.pft_cntr_nm = prod_rates_dmnsn.pft_cntr_cd then 1 else 0 end = 1
left outer join """+dbCommonName+""".bmt_cust_rates_dmnsn cust_rates_dmnsn on
case 
when cust_rates_dmnsn.fscl_yr_mth_cd <> "?" and cust_rates_dmnsn.fscl_yr_mth_cd <> 'all' and cust_rates_dmnsn.fscl_yr_mth_cd is not null and
 ord_dmnsn_adjmt_dmnsn.end_cust_prty_id = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd  IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = cust_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then 1
 when ord_dmnsn_adjmt_dmnsn.end_cust_prty_id = cust_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=cust_rates_dmnsn.pft_cntr_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=cust_rates_dmnsn.rte_to_mkt_cd and  sls_spmt.e1edk14_idoc_org_nm_12=cust_rates_dmnsn.prmry_sls_ord_adjmt_cd and segment_std_hrchy.sg_level_3=cust_rates_dmnsn.sgm_lvl_3_cd then 1 else 0 end = 1
left outer join """+dbCommonName+""".bmt_ptnr_rates_dmnsn ptnr_rates_dmnsn on 
case 
when ptnr_rates_dmnsn.fscl_yr_mth_cd <> "?" and ptnr_rates_dmnsn.fscl_yr_mth_cd <> 'all' and ptnr_rates_dmnsn.fscl_yr_mth_cd is not null and
sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = ptnr_rates_dmnsn.fscl_yr_mth_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then 1
when sls_spmt.e1edka1_ptnr_nr_AG  = ptnr_rates_dmnsn.prty_id and sls_spmt.pft_cntr_nm=ptnr_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=ptnr_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=ptnr_rates_dmnsn.rte_to_mkt_cd and sls_spmt.e1edk14_idoc_org_nm_12=ptnr_rates_dmnsn.prmry_sls_ord_adjmt_cd then 1 else 0 end = 1
left outer join """+dbCommonName+""".bmt_pl_rates_dmnsn pl_rates_dmnsn on
case 
when pl_rates_dmnsn.fscl_yr_mth_cd <> "?" and pl_rates_dmnsn.fscl_yr_mth_cd <> 'all' and pl_rates_dmnsn.fscl_yr_mth_cd is not null and 
sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and concat(substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),1,6),"-",substr(concat('FY',substring(rvn_rcgn_dfrd_itm_trsn.rvn_rcncltn_ky,1,7)),8,9)) = pl_rates_dmnsn.fscl_yr_mth_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then 1 
when sls_spmt.pft_cntr_nm  = pl_rates_dmnsn.pft_cntr_cd and segment_std_hrchy.sg_level_3=pl_rates_dmnsn.sgm_lvl_3_cd and (CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_spmt.collective_sd_nr ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END)=pl_rates_dmnsn.rte_to_mkt_cd and pl_rates_dmnsn.prmry_sls_ord_adjmt_cd= sls_spmt.e1edk14_idoc_org_nm_12 then 1 else 0 end = 1
left outer join """+dbCommonName+""".prty_fact prty on (CASE WHEN ord_dmnsn_adjmt_dmnsn.end_cust_prty_id IS NULL THEN sls_spmt.e1edka1_ptnr_nr_ZC ELSE ord_dmnsn_adjmt_dmnsn.end_cust_prty_id END) = prty.mdm_id 
""")
 
    SalesShipmentDF.createOrReplaceTempView("serpTempTable1")
    
    logger.info("/***************++++++++ serpTempTable1 Loaded++++++++***************/")

    val SalesShipmentPDMDF = spark.sql(s"""
select distinct 
serp1.*,
prod_mstr_dmnsn.mtrl_mstr_sls_dvsn_cd as pmd_mtrl_mstr_sls_dvsn_cd,
prod_mstr.mtrl_mstr_sls_dvsn_cd as pm_mtrl_mstr_sls_dvsn_cd,
current_prod_hrchy_dmnsn.prod_hrchy_prod_fmly_cd,
bmt_gbl_carepack_dmnsn.gbl_carepack_hw_prod_ln_id,
current_prod.prod_hrchy_prod_typ_cd,
coalesce(CASE WHEN cst_cntr_grp_hrchy_dmnsn.cch_level_8 is NULL then "FO70000038" else cst_cntr_grp_hrchy_dmnsn.cch_level_8  end,"FO70000038") as fncl_ownr_cd,
doc_typ_dmnsn.sd_dcmt_cgy_cd as ord_cgy_cd,
doc_typ_dmnsn.sls_dcmt_typ_dn as ord_cgy_dn,
CASE WHEN pn_disa_flg_dmnsn.flg_cd is NULL THEN 'N' ELSE 'Y' END as disa_ind,
CASE WHEN UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.source) like '%DXC%' THEN 'Y' ELSE 'N' END as dxc_ind,
CASE WHEN UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_hpc.source) like '%HPC%' THEN 'Y' ELSE 'N' END as hpc_ind,
CASE WHEN UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_hyp.source) like '%HYPERCONVERGED%' THEN 'Y' ELSE 'N' END as hyperconverged_ind,
CASE WHEN pn_srv_intensity_dmnsn.srv_intensity_flg_cd IS NULL THEN 'N' ELSE 'Y' END as srv_intensity_ind
from serpTempTable1 serp1
left outer join ${dbCommonName}.prod_mstr_dmnsn prod_mstr_dmnsn on prod_mstr_dmnsn.mtrl_mstr_mtrl_id = serp1.prod_id
left outer join ${dbCommonName}.prod_mstr_dmnsn prod_mstr on prod_mstr.mtrl_mstr_mtrl_id=serp1.srvc_gds_prod_id
left outer join ${dbCommonName}.current_prod_hrchy_dmnsn current_prod_hrchy_dmnsn on current_prod_hrchy_dmnsn.mtrl_mstr_mtrl_id =serp1.prod_id
left outer join ${dbCommonName}.bmt_gbl_carepack_dmnsn bmt_gbl_carepack_dmnsn on bmt_gbl_carepack_dmnsn.mfrg_prod_id=serp1.prod_id
left outer join ${dbCommonName}.current_prod_hrchy_dmnsn current_prod on current_prod.mtrl_mstr_mtrl_id =serp1.prod_bs_and_opt_nr
left outer join ${dbCommonName}.cst_cntr_fo_hrchy cst_cntr_grp_hrchy_dmnsn on cst_cntr_grp_hrchy_dmnsn.cch_level_9=serp1.cst_cntr_cd
left outer join ${dbCommonName}.doc_typ_dmnsn doc_typ_dmnsn on doc_typ_dmnsn.sls_dcmt_typ_cd=serp1.ord_typ_cd
left outer join ${dbCommonName}.bmt_pn_disa_flg_dmnsn pn_disa_flg_dmnsn on serp1.prft_cntr_cd=pn_disa_flg_dmnsn.pft_cntr_cd AND serp1.sld_to_cd = pn_disa_flg_dmnsn.sld_to_id
left outer join ${dbCommonName}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn pn_so_hypr_hpc_dxc_flg_dmnsn_dxc on serp1.e1edk01_idoc_dcmt_nr=pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.sls_ord_id and UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_dxc.source) like '%DXC%'
left outer join ${dbCommonName}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn pn_so_hypr_hpc_dxc_flg_dmnsn_hpc on serp1.e1edk01_idoc_dcmt_nr=pn_so_hypr_hpc_dxc_flg_dmnsn_hpc.sls_ord_id and UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_hpc.source) like '%HPC%'
left outer join ${dbCommonName}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn pn_so_hypr_hpc_dxc_flg_dmnsn_hyp on serp1.e1edk01_idoc_dcmt_nr=pn_so_hypr_hpc_dxc_flg_dmnsn_hyp.sls_ord_id and UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn_hyp.source) like '%HYPERCONVERGED%'
left outer join ${dbCommonName}.bmt_pn_srv_intensity_dmnsn pn_srv_intensity_dmnsn on serp1.prod_bs_and_opt_nr = pn_srv_intensity_dmnsn.prod_id
""")

    SalesShipmentPDMDF.createOrReplaceTempView("serpTempTable2")

    logger.info("/***************++++++++ serpTempTable2 Loaded++++++++***************/")
    
    
    val SalesShipmentOrdAdjDF = spark.sql(s"""
  select distinct serp2.*, 
ob_scra_fd_srtr_dmnsn.sc_bklg_cgy_cd as scra_cgy_cd,
ord_sni_dmnsn.in_out_omc_rsk_bkt AS sni_risk_asmnt_cgy_cd,
CASE WHEN ord_adjmt_dmnsn.rvn_rcgn_cgy_cd IS NULL OR UPPER(ord_adjmt_dmnsn.rvn_rcgn_cgy_cd) in ('INCLUDE','NULL') THEN CASE WHEN scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd IS NOT NULL THEN scra_rev_rec_cgy_dmnsn.rev_recgn_cgy_cd ELSE NULL END ELSE ord_adjmt_dmnsn.rvn_rcgn_cgy_cd END as cp_rev_recgn_cgy_cd_temp,
scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd as sc_bklg_cgy_cd_scra,
ord_adjmt_dmnsn.rvn_rcgn_cgy_cd as rvn_rcgn_cgy_cd_ord_adj,
scra_rev_rec_cgy_dmnsn.rev_recgn_cgy_cd as rvn_rcgn_cgy_cd_scra,
fscl_cldr_dmnsn.week_in_qtr_cd as fscl_week_cd,
--CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.incd_excld_cd ELSE NULL END as cp_incd_excld,
NULL AS cp_incd_excld,
--CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.rev_hd_cd ELSE 'Load' END as rev_hd_cd,
NULL AS rev_hd_cd,
--CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.rev_hd_cd ELSE 'Load' END as cp_rev_hdr_nm, 
NULL AS cp_rev_hdr_nm,
CASE                                                                                    
WHEN sahd.sgm_mppg_3_cd NOT IN ('United States') THEN sahd.sgm_mppg_4_cd                                                                                                                                                            
WHEN serp2.oypl_pch_level_7 IN ('7A00','1087','RG00','1088','1089','1090','1091','1070','1069') THEN 'US Other'
WHEN pcahd.pc_map_4 in ('Compute') and pcahd.pc_map_6 not in ('Mission Critical') and cahd.cust_mppg_23_cd in ('Tier 1 SP') then 'US-Tier 1 SP'
WHEN cahd.cust_mppg_21_Cd IN ('Brazil', 'Canada', 'MCA', 'Mexico') THEN 'US Unknown GEO'        
WHEN UPPER(cahd.cust_mppg_21_Cd) NOT IN ('TBD','','AUDEFAULT','DIRECT TO RESELLER','NON US') THEN cahd.cust_mppg_21_cd
WHEN sahd.sgm_mppg_3_cd IN ('United States') THEN 'US Unknown GEO'
ELSE 'Unknown GEO' END AS ctry_nm,  
cust_alt_hrchy_dmnsn.cust_mppg_23_cd as cust_sgm_nm
from serpTempTable2 serp2
left outer join ${dbCommonName}.bmt_ord_dmnsn_adjmt_dmnsn ord_adjmt_dmnsn on serp2.e1edk01_idoc_dcmt_nr = ord_adjmt_dmnsn.sls_ord_id
left outer join ${dbCommonName}.bmt_ob_scra_fd_srtr_dmnsn ob_scra_fd_srtr_dmnsn on serp2.e1edk01_idoc_dcmt_nr = ob_scra_fd_srtr_dmnsn.so_id and serp2.sls_ord_ln_itm_id = (CASE WHEN LENGTH(ob_scra_fd_srtr_dmnsn.so_ln_itm_id) <=6 THEN LPAD(ob_scra_fd_srtr_dmnsn.so_ln_itm_id,6,"0")  ELSE ob_scra_fd_srtr_dmnsn.so_ln_itm_id END)
left outer join ${dbCommonName}.bmt_scra_rev_rec_cgy_dmnsn scra_rev_rec_cgy_dmnsn on ob_scra_fd_srtr_dmnsn.sc_bklg_cgy_cd = scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd
left outer join ${dbCommonName}.bmt_fscl_cldr_dmnsn fscl_cldr_dmnsn on serp2.cldr_rpt_ky = from_unixtime(unix_timestamp(fscl_cldr_dmnsn.fscl_cldr_dt,'yyyy-MM-dd HH:mm:ss.SS'),'yyyyMMdd')
--left outer join ${dbCommonName}.bmt_rev_rec_cgy_snp_dmnsn rev_rec_cgy_snp_dmnsn on (CASE WHEN ord_adjmt_dmnsn.rvn_rcgn_cgy_cd IS NULL OR UPPER(ord_adjmt_dmnsn.rvn_rcgn_cgy_cd) in ('INCLUDE','NULL') THEN CASE WHEN scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd IS NOT NULL THEN scra_rev_rec_cgy_dmnsn.rev_recgn_cgy_cd ELSE NULL END ELSE ord_adjmt_dmnsn.rvn_rcgn_cgy_cd END)  = rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd 
left outer join ${dbCommonName}.bmt_sls_chnl_dmnsn sls_chnl_dmnsn on serp2.mkt_rte_cd=sls_chnl_dmnsn.sls_chnl_cd
left outer join ${dbCommonName}.bmt_cust_alt_hrchy_dmnsn cust_alt_hrchy_dmnsn on crc32(COALESCE(serp2.end_cust_cd,""))=cust_alt_hrchy_dmnsn.cust_alt_hrchy_ky
left outer join ${dbCommonName}.bmt_sgm_alt_hrchy_dmnsn sahd on serp2.sgmtl_rptg_cd = sahd.sgm_cd
left outer join ${dbCommonName}.bmt_pft_cntr_alt_hrchy_dmnsn pcahd on serp2.prft_cntr_cd = pcahd.pft_cntr_cd
left outer join ${dbCommonName}.bmt_cust_alt_hrchy_dmnsn cahd on serp2.cp_end_cust_prty_id = cahd.prty_id
left outer join ${dbCommonName}.ord_sni_dmnsn ord_sni_dmnsn on 
ord_sni_dmnsn.idoc_nr=serp2.src_idoc_nr and ord_sni_dmnsn.e1edk01_idoc_dcmt_nr= serp2.e1edk01_idoc_dcmt_nr and ord_sni_dmnsn.e1edp01_itm_nr= serp2.sls_ord_ln_itm_id
""")


    SalesShipmentOrdAdjDF.createOrReplaceTempView("serpTempTable3")
    logger.info("/***************++++++++ serpTempTable3 Loaded++++++++***************/")

    val SalesShipmentDealQuotesDF = spark.sql(s"""
  select distinct serp3.*,
deal_dmnsn.deal_acct_mgmt_lvl_2_id,
deal_dmnsn.deal_acct_mgmt_lvl_2_nm,
deal_dmnsn.deal_bsn_mdl_cd,
deal_dmnsn.deal_bsn_mdl_dn,
deal_dmnsn.deal_cust_ltn_nm,
deal_dmnsn.deal_cust_nn_ltn_nm,
deal_dmnsn.deal_rgst_id,
deal_dmnsn.deal_src_sys_cd,
deal_dmnsn.deal_deal_src_sys_dn,
deal_dmnsn.deal_stts_nm,
deal_dmnsn.deal_sb_typ_cd,
deal_dmnsn.deal_typ_cd,
deal_dmnsn.deal_vrsn_nr,
deal_dmnsn.deal_vrsn_stts_nm,
deal_dmnsn.deal_grphc_scp_nm,
deal_dmnsn.deal_indy_id,
deal_dmnsn.deal_last_updd_by_eml_id,
deal_dmnsn.deal_lead_bsn_unt_cd,
deal_dmnsn.deal_misc_crg_cd,
deal_dmnsn.deal_prnt_org_id,
deal_dmnsn.deal_prnt_org_nm,
deal_dmnsn.deal_pyr_prty_id,
deal_dmnsn.deal_sls_tty_acct_cnflct_ind,
deal_dmnsn.deal_sls_tty_acct_nm,
deal_dmnsn.deal_src_deal_id,
deal_dmnsn.deal_vld_end_ts,
deal_dmnsn.deal_vld_strt_ts,
deal_dmnsn.deal_ins_ts,
deal_dmnsn.deal_upd_ts,
quotes_fact.quote_header_sls_qtn_vrsn_sqn_nr_cd as quote_header_sls_qtn_vrsn_sqn_nr_cd,
quotes_fact.asset_quote_nr_cd as asset_quote_nr_cd,
quotes_fact.asset_quote_vrsn_cd as asset_quote_vrsn_cd,
quotes_fact.modified_ts_cd as modified_ts_cd,
quotes_fact.creation_person_id_id as creation_person_id_id,
quotes_fact.sfdc_status_cd as sfdc_status_cd,
quotes_fact.total_amt_cd as total_amt,
quotes_fact.total_list_price_amt_cd as total_list_price_amt,
quotes_fact.bmi_id_id as bmi_id_id,
quotes_fact.nm as nm,
quotes_fact.price_geo_cd as price_geo_cd,
quotes_fact.asset_quote_nr_and_vrsn_cd as asset_quote_nr_and_vrsn_cd,
quotes_fact.org_id_id as org_id_id,
quotes_fact.creation_ts_cd as creation_ts_cd,
quotes_fact.currency_cd_cd as currency_cd_cd,
quotes_fact.sls_qtn_vrsn_typ_cd_cd as sls_qtn_vrsn_typ_cd_cd,
quotes_fact.cty_cd as cty_cd,
quotes_fact.quoteowner_cd as quoteowner_cd,
quotes_fact.partner_id_id,
quotes_fact.orig_asset_cd,
quotes_fact.modified_person_id_id,
quotes_fact.lead_bu_cd,
quotes_fact.last_modifier_ngq_profile_cd ,
quotes_fact.customer_mdcp_org_id_id ,
quotes_fact.mdcp_opsi_id_id,
quotes_fact.creator_ngq_profile_cd,
quotes_fact.completion_ts_cd,
NULL as quote_items_product_line_cd,
NULL as lcl_xtnd_nt_amt_cd,
NULL as qty_cd ,
hpe_qt_flags_dmnsn.flg_typ_cd as flg_typ_cd,
hpe_qt_flags_dmnsn.flg_vl_cd as flg_vl_cd,
hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_id_id,
hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd,
opty_fact.acct_i_20_nm ,
opty_fact.totl_opty_v_cd,
opty_fact.expctd_amt_cd,
opty_fact.opty_totl_amt_cd,
opty_fact.opty_totl_amt_cd as opty_totl_amt_cd1 ,
NULL as bookshi_2_dt,
NULL as last_mfy_205_dt,
NULL as sys_modstam_4_cd,
NULL as b_3_nm,
NULL as gb_15_nm,
NULL as opportunitystage_nm,
NULL as pro_283_nm,
NULL as prod_l_5_nm,
NULL as sb_prod_l_2_nm,
ord_sni_dmnsn.instln_ord_flg,
ord_sni_dmnsn.prj_ord,
ord_sni_dmnsn.dlvy_inv_cd,
ord_sni_dmnsn.inv_bvr,
ord_sni_dmnsn.pld_inv_dt,
ord_sni_dmnsn.hg_vw_bkt,
ord_sni_dmnsn.sni_alt_bkt,
ord_sni_dmnsn.in_out,
ord_sni_dmnsn.pri_bkt,
ord_sni_dmnsn.in_out_omc_rsk_bkt,
case when serp3.ord_crt_dt<=sab_cut_off_fd_srtr_dmnsn.beg_sab_cutoff_dt then 'Y' else 'N' end as beg_bklg_nm,
NULL as ucid_id,
CTO.CTO_BTO as bto_cto_flg,
mtrl_plnt.mtrl_plnt_pft_cntr_cd as curnt_sls_div_pft_cntr_cd,
sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt,
bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind,
bmt_sni_asmnt_fd_srtr_dmnsn.rev_rec_cd,
bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt as pri_bkt_sni,
bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt as in_out_omc_rsk_bkt_sni,
estmtd_inv_dt_ind as estmtd_inv_dt_ind,
CASE WHEN actl_dlvry_dt IS NULL THEN serp3.rvn_rcgn_cgy_cd_scra
     ELSE 
		CASE 
		     WHEN (serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt AND rvn_rcgn_pstg_dmnsn.prfm_obgn_id IS NOT NULL  AND ( ( concat(substr(serp3.recon_ky_cd,0,4),  CASE WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('001','002','003') THEN '1' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('004','005','006') THEN '2' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('007','008','009' ) THEN '3' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('010','011','012' ) THEN '4' else NULL end 
))<=${fscl_yr_prd_con} ) )  THEN 'REV'
		     WHEN (ord_sni_dmnsn.pri_bkt IS NULL AND ord_sni_dmnsn.in_out_omc_rsk_bkt IS NULL AND serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt   AND ( (CASE WHEN Month(estmd_inv_dt)==11 OR Month(estmd_inv_dt)==12 THEN CONCAT((Year(estmd_inv_dt)+1) , '1') WHEN Month(estmd_inv_dt)==2 OR Month(estmd_inv_dt)==3 OR Month(estmd_inv_dt)==4 THEN CONCAT(Year(estmd_inv_dt), '2') WHEN Month(estmd_inv_dt)==5 OR Month(estmd_inv_dt)==6 OR Month(estmd_inv_dt)==7 THEN CONCAT(Year(estmd_inv_dt),'3') WHEN Month(estmd_inv_dt)==8 OR Month(estmd_inv_dt)==9 OR Month(estmd_inv_dt)==10 THEN CONCAT(Year(estmd_inv_dt), '4') WHEN Month(estmd_inv_dt)==1 THEN CONCAT(Year(estmd_inv_dt), '1') END)<=${fscl_yr_prd_con}  ) AND rvn_rcgn_pstg_dmnsn.prfm_obgn_id IS NULL	 AND ( ( concat(substr(serp3.recon_ky_cd,0,4), CASE WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('001','002','003') THEN '1' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('004','005','006') THEN '2' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('007','008','009' ) THEN '3' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('010','011','012' ) THEN '4' else NULL end 
))>${fscl_yr_prd_con}  ))  THEN 'KLD'
		     WHEN ( ((CASE WHEN ord_sni_dmnsn.pri_bkt is null then 'NULL' ELSE ord_sni_dmnsn.pri_bkt END)==(CASE WHEN bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt IS NULL THEN 'NULL' ELSE bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt END)) AND ((CASE WHEN ord_sni_dmnsn.in_out_omc_rsk_bkt IS NULL THEN 'NULL' ELSE ord_sni_dmnsn.in_out_omc_rsk_bkt END)==(CASE WHEN bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt IS NULL THEN 'NULL' ELSE bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt END )) AND ( CASE WHEN (bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind=='N' AND serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt) OR (bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind=='Y' ) THEN TRUE  ELSE FALSE END) AND  
			 ( CASE WHEN (bmt_sni_asmnt_fd_srtr_dmnsn.estmtd_inv_dt_ind=='N' AND ( CASE WHEN Month(estmd_inv_dt)==11 OR Month(estmd_inv_dt)==12 THEN CONCAT((Year(estmd_inv_dt)+1) , '1') WHEN Month(estmd_inv_dt)==2 OR Month(estmd_inv_dt)==3 OR Month(estmd_inv_dt)==4 THEN CONCAT(Year(estmd_inv_dt), '2') WHEN Month(estmd_inv_dt)==5 OR Month(estmd_inv_dt)==6 OR Month(estmd_inv_dt)==7 THEN CONCAT(Year(estmd_inv_dt),'3') WHEN Month(estmd_inv_dt)==8 OR Month(estmd_inv_dt)==9 OR Month(estmd_inv_dt)==10 THEN CONCAT(Year(estmd_inv_dt), '4') WHEN Month(estmd_inv_dt)==1 THEN CONCAT(Year(estmd_inv_dt), '1') END<=${fscl_yr_prd_con} )) OR bmt_sni_asmnt_fd_srtr_dmnsn.estmtd_inv_dt_ind=='Y' THEN TRUE  ELSE FALSE END) AND ( ( concat(substr(serp3.recon_ky_cd,0,4), CASE WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('001','002','003') THEN '1' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('004','005','006') THEN '2' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('007','008','009' ) THEN '3' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('010','011','012' ) THEN '4' else NULL end 
))>${fscl_yr_prd_con}  ))  THEN bmt_sni_asmnt_fd_srtr_dmnsn.rev_rec_cd
		ELSE 'KOP' END END  as rvn_rcgn_cgy_cd,
CASE WHEN rvn_rcgn_cgy_cd_ord_adj IS NULL OR UPPER(rvn_rcgn_cgy_cd_ord_adj) in ('INCLUDE','NULL')
 THEN  (CASE WHEN actl_dlvry_dt IS NULL THEN serp3.rvn_rcgn_cgy_cd_scra
     ELSE 
		CASE 
		     WHEN (serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt AND rvn_rcgn_pstg_dmnsn.prfm_obgn_id IS NOT NULL  AND ( ( concat(substr(serp3.recon_ky_cd,0,4),  CASE WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('001','002','003') THEN '1' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('004','005','006') THEN '2' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('007','008','009' ) THEN '3' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('010','011','012' ) THEN '4' else NULL end 
))<=${fscl_yr_prd_con} ) )  THEN 'REV'
		     WHEN (ord_sni_dmnsn.pri_bkt IS NULL AND ord_sni_dmnsn.in_out_omc_rsk_bkt IS NULL AND serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt   AND ( (CASE WHEN Month(estmd_inv_dt)==11 OR Month(estmd_inv_dt)==12 THEN CONCAT((Year(estmd_inv_dt)+1) , '1') WHEN Month(estmd_inv_dt)==2 OR Month(estmd_inv_dt)==3 OR Month(estmd_inv_dt)==4 THEN CONCAT(Year(estmd_inv_dt), '2') WHEN Month(estmd_inv_dt)==5 OR Month(estmd_inv_dt)==6 OR Month(estmd_inv_dt)==7 THEN CONCAT(Year(estmd_inv_dt),'3') WHEN Month(estmd_inv_dt)==8 OR Month(estmd_inv_dt)==9 OR Month(estmd_inv_dt)==10 THEN CONCAT(Year(estmd_inv_dt), '4') WHEN Month(estmd_inv_dt)==1 THEN CONCAT(Year(estmd_inv_dt), '1') END)<=${fscl_yr_prd_con}  ) AND rvn_rcgn_pstg_dmnsn.prfm_obgn_id IS NULL	 AND ( ( concat(substr(serp3.recon_ky_cd,0,4), CASE WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('001','002','003') THEN '1' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('004','005','006') THEN '2' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('007','008','009' ) THEN '3' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('010','011','012' ) THEN '4' else NULL end 
))>${fscl_yr_prd_con} ))  THEN 'KLD'
		     WHEN ( ((CASE WHEN ord_sni_dmnsn.pri_bkt is null then 'NULL' ELSE ord_sni_dmnsn.pri_bkt END)==(CASE WHEN bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt IS NULL THEN 'NULL' ELSE bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt END)) AND ((CASE WHEN ord_sni_dmnsn.in_out_omc_rsk_bkt IS NULL THEN 'NULL' ELSE ord_sni_dmnsn.in_out_omc_rsk_bkt END)==(CASE WHEN bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt IS NULL THEN 'NULL' ELSE bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt END )) AND ( CASE WHEN (bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind=='N' AND serp3.actl_dlvry_dt<= sab_cut_off_fd_srtr_dmnsn.end_sab_cutoff_dt) OR (bmt_sni_asmnt_fd_srtr_dmnsn.shp_dt_ind=='Y' ) THEN TRUE  ELSE FALSE END) AND  
			 ( CASE WHEN (bmt_sni_asmnt_fd_srtr_dmnsn.estmtd_inv_dt_ind=='N' AND ( CASE WHEN Month(estmd_inv_dt)==11 OR Month(estmd_inv_dt)==12 THEN CONCAT((Year(estmd_inv_dt)+1) , '1') WHEN Month(estmd_inv_dt)==2 OR Month(estmd_inv_dt)==3 OR Month(estmd_inv_dt)==4 THEN CONCAT(Year(estmd_inv_dt), '2') WHEN Month(estmd_inv_dt)==5 OR Month(estmd_inv_dt)==6 OR Month(estmd_inv_dt)==7 THEN CONCAT(Year(estmd_inv_dt),'3') WHEN Month(estmd_inv_dt)==8 OR Month(estmd_inv_dt)==9 OR Month(estmd_inv_dt)==10 THEN CONCAT(Year(estmd_inv_dt), '4') WHEN Month(estmd_inv_dt)==1 THEN CONCAT(Year(estmd_inv_dt), '1') END<=${fscl_yr_prd_con} )) OR bmt_sni_asmnt_fd_srtr_dmnsn.estmtd_inv_dt_ind=='Y' THEN TRUE  ELSE FALSE END) AND ( ( concat(substr(serp3.recon_ky_cd,0,4), CASE WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('001','002','003') THEN '1' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('004','005','006') THEN '2' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('007','008','009' ) THEN '3' WHEN (substr(serp3.recon_ky_cd,5,3)) IN ('010','011','012' ) THEN '4' else NULL end 
))>${fscl_yr_prd_con}  ))  THEN bmt_sni_asmnt_fd_srtr_dmnsn.rev_rec_cd
		ELSE 'KOP' END END) ELSE rvn_rcgn_cgy_cd_ord_adj END as cp_rev_recgn_cgy_cd 
	from serpTempTable3 serp3
left outer join (select * from (select deals.*,Row_number() over(partition by deals.deal_id order by deals.deal_vrsn_nr desc) as rank from ${dbCommonName}.deal_dmnsn deals)a where a.rank=1) deal_dmnsn  on deal_dmnsn.deal_id = serp3.deal_id
left outer join (select * from  (select quotes.*, Row_number() over(partition by quotes.asset_quote_nr_cd order by quotes.asset_quote_vrsn_cd desc ) as rank from ${dbCommonUATName}.quotes_fact quotes) a where a.rank=1) quotes_fact on quotes_fact.asset_quote_nr_cd= split(serp3.quote_id,'-')[0]
left outer join ${dbCommonUATName}.hpe_qt_flags_dmnsn hpe_qt_flags_dmnsn on quotes_fact.quote_header_sls_qtn_id_id=hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_id_id and quotes_fact.quote_header_sls_qtn_vrsn_sqn_nr_cd=hpe_qt_flags_dmnsn.hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd 
left outer join (select case when count(distinct case when ucid_id is null then null else ucid_id end) >= 1 then 'CTO' else 'BTO' end as CTO_BTO ,asset_quote_nr_cd from  ${dbCommonUATName}.quotes_fact group by asset_quote_nr_cd) CTO on CTO.asset_quote_nr_cd=split(serp3.quote_id,'-')[0]
left outer join ${dbCommonName}.opty_fact opty_fact on opty_fact.hpe_opty_i_nm = serp3.opty_id
left outer join ${dbCommonName}.pdm_mtrl_plnt_grp_dmnsn mtrl_plnt on mtrl_plnt.mtrl_plnt_mtrl_id=serp3.mtrl_nr and mtrl_plnt.mtrl_plnt_cd=serp3.plnt_cd
left outer join ${dbCommonName}.ord_sni_dmnsn ord_sni_dmnsn on 
ord_sni_dmnsn.idoc_nr=serp3.src_idoc_nr and ord_sni_dmnsn.e1edk01_idoc_dcmt_nr= serp3.e1edk01_idoc_dcmt_nr and ord_sni_dmnsn.e1edp01_itm_nr= serp3.sls_ord_ln_itm_id
left outer join ${dbCommonName}.bmt_sni_asmnt_fd_srtr_dmnsn  bmt_sni_asmnt_fd_srtr_dmnsn on 
(CASE WHEN bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt IS NULL THEN 'NULL' ELSE bmt_sni_asmnt_fd_srtr_dmnsn.pri_bkt END) = (CASE WHEN ord_sni_dmnsn.pri_bkt is null then 'NULL' ELSE ord_sni_dmnsn.pri_bkt END) and
(CASE WHEN bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt IS NULL THEN 'NULL' ELSE bmt_sni_asmnt_fd_srtr_dmnsn.in_out_omc_rsk_bkt END ) = (CASE WHEN ord_sni_dmnsn.in_out_omc_rsk_bkt IS NULL THEN 'NULL' ELSE ord_sni_dmnsn.in_out_omc_rsk_bkt END) 
left outer join ${dbCommonName}.bmt_sab_cut_off_fd_srtr_dmnsn sab_cut_off_fd_srtr_dmnsn on sab_cut_off_fd_srtr_dmnsn.fscl_yr_qtr_dsply_cd = (CASE WHEN Month(serp3.actl_dlvry_dt)==11 OR Month(serp3.actl_dlvry_dt)==12 THEN CONCAT((Year(serp3.actl_dlvry_dt)+1) , '-Q1') WHEN Month(serp3.actl_dlvry_dt)==2 OR Month(serp3.actl_dlvry_dt)==3 OR Month(serp3.actl_dlvry_dt)==4 THEN CONCAT(Year(serp3.actl_dlvry_dt), '-Q2') WHEN Month(serp3.actl_dlvry_dt)==5 OR Month(serp3.actl_dlvry_dt)==6 OR Month(serp3.actl_dlvry_dt)==7 THEN CONCAT(Year(serp3.actl_dlvry_dt),'-Q3') WHEN Month(serp3.actl_dlvry_dt)==8 OR Month(serp3.actl_dlvry_dt)==9 OR Month(serp3.actl_dlvry_dt)==10 THEN CONCAT(Year(serp3.actl_dlvry_dt), '-Q4') WHEN Month(serp3.actl_dlvry_dt)==1 THEN CONCAT(Year(serp3.actl_dlvry_dt), '-Q1') END) and 
sab_cut_off_fd_srtr_dmnsn.sgm_cd = serp3.sgmtl_rptg_cd
left outer join ${dbNameConsmtn}.rvn_rcgn_pstg_dmnsn rvn_rcgn_pstg_dmnsn on serp3.pob_id=rvn_rcgn_pstg_dmnsn.prfm_obgn_id and serp3.cntrct_id=rvn_rcgn_pstg_dmnsn.rvn_rcgn_cntrct_id and serp3.recon_ky_cd=rvn_rcgn_pstg_dmnsn.rvn_rcncltn_ky and serp3.cndn_typ_cd=rvn_rcgn_pstg_dmnsn.cndn_typ_cd
 """)

    SalesShipmentDealQuotesDF.repartition(10).distinct().write.mode("overwrite").insertInto(dbNameConsmtn+".secrd_intermediate")

    logger.info("/***************++++++++ secrd_intermediate Loaded++++++++***************/")

    val serpDF = spark.sql(s"""select  df4.*,cst.cch_level_2 as MRU,spnd.ff_ln_itm_6,spnd.ff_ln_itm_7 
 from ${dbNameConsmtn}.secrd_intermediate df4 
left join ${dbCommonName}.cst_cntr_MRU_hrchy cst on df4.cst_cntr_cd=cst.cch_level_8
left join ${dbCommonName}.bmt_pn_ff_spnd_lvl_dmnsn spnd on substring(df4.gl_acct_nr,3,8)= spnd.acct_cd
""")

    val pnPtflFrmwkDmnsn = spark.sql(s""" select  a.*,pkg_prod_id as bmt_pkg_prod_id from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.bs_prod_id, tbl.sgm_cd, tbl.pkg_prod_id order by tbl.inrn_id) seq_id
from ${dbCommonName}.bmt_pn_ptfl_frmwk_dmnsn tbl) a where a.seq_id =1 """)

    val pnSlngMtnFrmwkDmnsnDf = spark.sql(s"""select a.* from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.sls_ord_typ_cd ,tbl.bsn_typ_cd, tbl.sgm_cd, tbl.bs_prod_id, tbl.mfrg_prod_fmly_id order by tbl.inrn_id) seq_id
from ${dbCommonName}.bmt_pn_slng_mtn_frmwk_dmnsn tbl) a where a.seq_id =1 """)

    val pnHwFrmwkDmnsnDf = spark.sql(s"""select a.* from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.sgm_cd, tbl.gbl_carepack_hw_prod_ln_id, tbl.hw_prod_ln_cd ,tbl.srv_gds_prod_ln_id, tbl.mfrg_prod_prod_ln_id,tbl.bs_prod_typ_cd,tbl.bs_prod_id order by tbl.inrn_id) seq_id
from ${dbCommonName}.bmt_pn_hw_frmwk_dmnsn tbl) a  where a.seq_id =1 """)

    val pnBsnCatFrmwkDmnsn = spark.sql(s"""select a.* from (SELECT tbl.*, row_number() over (partition by tbl.pft_cntr_cd , tbl.hw_lvl_4_cd ,tbl.bsn_typ_cd, tbl.bs_prod_id, tbl.sgm_cd, tbl.ln_itm_3_cd, tbl.mfrg_prod_fmly_id order by tbl.inrn_id) seq_id 
  from ${dbCommonName}.bmt_pn_bsn_cat_frmwk_dmnsn tbl) a where a.seq_id =1 """)

    val pnNnFcsDmnsnDf = spark.sql(s"""select a.* from (select tbl.* ,row_number() over (partition by tbl.ba_cd,tbl.prft_ctr_cd,tbl.sgmt_lvl_2_cd,tbl.sgmt_lvl_3_cd,tbl.sgmt_lvl_4_cd,tbl.sgmt_lvl_5_cd order by tbl.inrn_id) seq_id 
  from ${dbCommonName}.bmt_pn_nn_fcus_flg_ord_dmnsn tbl) a where a.seq_id=1""")

    val pnNnFcsDmnsnDf1 = spark.sql(s"""select a.* from (select tbl.*, row_number() over (partition by tbl.ba_cd,tbl.prft_ctr_cd,tbl.sgmt_lvl_2_cd,tbl.sgmt_lvl_3_cd,tbl.sgmt_lvl_4_cd,tbl.sgmt_lvl_5_cd,tbl.ff_l15_cd order by tbl.inrn_id) seq_id 
  from ${dbCommonName}.bmt_pn_nn_fcus_flg_actl_dmnsn tbl) a where a.seq_id=1""")

    val pnFnclFrmwkDf = spark.sql(s"""select a.* from (select tbl.*,row_number() over (partition by tbl.pft_cntr,tbl.acct_cd,tbl.mru_cd,tbl.cst_obj,tbl.fnctl_ar order by tbl.precedence) seq_id
  from ${dbCommonName}.bmt_pn_fncl_frmwk_dmnsn tbl)a where a.seq_id=1""")

    val serpSelectDf = serpDF.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "mkt_sgm_cd", "pkg_prod_id", "prod_bs_and_opt_nr").distinct

    val serpJoinedDf = serpSelectDf.alias("serpCol").join(
      (pnPtflFrmwkDmnsn).alias("pnPtflFrmwkCol"),
      (serpSelectDf("prft_cntr_cd") === pnPtflFrmwkDmnsn("pft_cntr_cd") || pnPtflFrmwkDmnsn("pft_cntr_cd") === "all")
        && (serpSelectDf("mkt_sgm_cd") === pnPtflFrmwkDmnsn("sgm_cd") || pnPtflFrmwkDmnsn("sgm_cd") === "all")
        && (serpSelectDf("pkg_prod_id") === pnPtflFrmwkDmnsn("bmt_pkg_prod_id") || pnPtflFrmwkDmnsn("bmt_pkg_prod_id") === "all")
        && (serpSelectDf("prod_bs_and_opt_nr") === pnPtflFrmwkDmnsn("bs_prod_id") || pnPtflFrmwkDmnsn("bs_prod_id") === "all"), "leftouter").filter(pnPtflFrmwkDmnsn("inrn_id").isNotNull).select("serpCol.*", "pnPtflFrmwkCol.ln_itm_1_cd", "pnPtflFrmwkCol.ln_itm_2_cd", "pnPtflFrmwkCol.ln_itm_3_cd", "pnPtflFrmwkCol.ln_itm_4_ofr_cd", "pnPtflFrmwkCol.ln_itm_5_sla_cvrg_cd", "pnPtflFrmwkCol.ln_itm_6_typ_cd", "pnPtflFrmwkCol.ln_itm_7_durtn_cd", "pnPtflFrmwkCol.inrn_id", "pnPtflFrmwkCol.pft_cntr_cd", "pnPtflFrmwkCol.sgm_cd", "pnPtflFrmwkCol.bmt_pkg_prod_id", "pnPtflFrmwkCol.bs_prod_id")

    logger.info("********************************************* serpJoinedDf write to table")

    serpJoinedDf.write.mode("Overwrite").format("ORC").insertInto(dbCommonName+".serpjoineddftbl_test_temp")
    
    val serpJoinedDfTblSelect = spark.sql(s"select * from ${dbCommonName}.serpjoineddftbl_test_temp")
    val serpJoinedDfTblDeDup = getLatestRecs(serpJoinedDfTblSelect, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "mkt_sgm_cd", "pkg_prod_id", "prod_bs_and_opt_nr"), List("inrn_id"))
    serpJoinedDfTblDeDup.write.mode("Overwrite").format("ORC").insertInto(dbCommonName+".serpBmtdf2_test")
    logger.info("********************************************* SERP join data ")

    val serpJoinedDfTblFinal = serpDF.alias("serpCol").join(
      (serpJoinedDfTblDeDup).alias("JoinedDfCol"),
      serpDF("sls_ord_id") === serpJoinedDfTblDeDup("sls_ord_id") && serpDF("sls_ord_ln_itm_id") === serpJoinedDfTblDeDup("sls_ord_ln_itm_id") &&
        ((serpDF("prft_cntr_cd").isNull && serpJoinedDfTblDeDup("prft_cntr_cd").isNull) || serpDF("prft_cntr_cd") === serpJoinedDfTblDeDup("prft_cntr_cd"))
        && ((serpDF("mkt_sgm_cd").isNull && serpJoinedDfTblDeDup("mkt_sgm_cd").isNull) || serpDF("mkt_sgm_cd") === serpJoinedDfTblDeDup("mkt_sgm_cd"))
        && ((serpDF("pkg_prod_id").isNull && serpJoinedDfTblDeDup("pkg_prod_id").isNull) || serpDF("pkg_prod_id") === serpJoinedDfTblDeDup("pkg_prod_id"))
        && ((serpDF("prod_bs_and_opt_nr").isNull && serpJoinedDfTblDeDup("prod_bs_and_opt_nr").isNull) || serpDF("prod_bs_and_opt_nr") === serpJoinedDfTblDeDup("prod_bs_and_opt_nr")), "leftouter").select("serpCol.*", "JoinedDfCol.ln_itm_1_cd", "JoinedDfCol.ln_itm_2_cd", "JoinedDfCol.ln_itm_3_cd", "JoinedDfCol.ln_itm_4_ofr_cd", "JoinedDfCol.ln_itm_5_sla_cvrg_cd", "JoinedDfCol.ln_itm_6_typ_cd", "JoinedDfCol.ln_itm_7_durtn_cd", "JoinedDfCol.inrn_id", "JoinedDfCol.pft_cntr_cd", "JoinedDfCol.sgm_cd", "JoinedDfCol.bmt_pkg_prod_id", "JoinedDfCol.bs_prod_id")

    logger.info("********************************************* finalDf write to table")
    serpJoinedDfTblFinal.write.mode("Overwrite").format("ORC").saveAsTable(dbCommonName+".serpBmtJoinTbl_test")
    
    val serpBmtJoinTblSelect = spark.sql(s"select * from ${dbCommonName}.serpBmtJoinTbl_test")
    
    val serpSelectDfpnHwFrmwk = serpBmtJoinTblSelect.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "gbl_carepack_hw_prod_ln_id", "pm_mtrl_mstr_sls_dvsn_cd", "pmd_mtrl_mstr_sls_dvsn_cd", "prod_hrchy_prod_typ_cd", "prod_bs_and_opt_nr").distinct

    val serpSelectDfpnHwFrmwkJoin = serpSelectDfpnHwFrmwk.alias("serpDF").join(
      broadcast(pnHwFrmwkDmnsnDf).alias("pnHwFrmwkCol"),
      (serpSelectDfpnHwFrmwk("prft_cntr_cd") === pnHwFrmwkDmnsnDf("pft_cntr_cd") || pnHwFrmwkDmnsnDf("pft_cntr_cd") === "all") && (serpSelectDfpnHwFrmwk("sgmtl_rptg_cd") === pnHwFrmwkDmnsnDf("sgm_cd") || pnHwFrmwkDmnsnDf("sgm_cd") === "all") && ((pnHwFrmwkDmnsnDf("gbl_carepack_hw_prod_ln_id") === "all" && ((serpSelectDfpnHwFrmwk("gbl_carepack_hw_prod_ln_id") === pnHwFrmwkDmnsnDf("hw_prod_ln_cd")) || pnHwFrmwkDmnsnDf("hw_prod_ln_cd") === "all")) || (pnHwFrmwkDmnsnDf("srv_gds_prod_ln_id") === "all" && ((serpSelectDfpnHwFrmwk("pm_mtrl_mstr_sls_dvsn_cd") === pnHwFrmwkDmnsnDf("hw_prod_ln_cd")) || pnHwFrmwkDmnsnDf("hw_prod_ln_cd") === "all")) || (pnHwFrmwkDmnsnDf("mfrg_prod_prod_ln_id") === "all" && ((serpSelectDfpnHwFrmwk("pmd_mtrl_mstr_sls_dvsn_cd") === pnHwFrmwkDmnsnDf("hw_prod_ln_cd")) || pnHwFrmwkDmnsnDf("hw_prod_ln_cd") === "all")))
        && (serpSelectDfpnHwFrmwk("prod_hrchy_prod_typ_cd") === pnHwFrmwkDmnsnDf("bs_prod_typ_cd") || pnHwFrmwkDmnsnDf("bs_prod_typ_cd") === "all") && (serpSelectDfpnHwFrmwk("prod_bs_and_opt_nr") === pnHwFrmwkDmnsnDf("bs_prod_id") || pnHwFrmwkDmnsnDf("bs_prod_id") === "all"), "leftouter").filter(pnHwFrmwkDmnsnDf("inrn_id").isNotNull).select("serpDF.*", "pnHwFrmwkCol.hw_lvl_1_cd", "pnHwFrmwkCol.hw_lvl_2_cd", "pnHwFrmwkCol.hw_lvl_3_cd", "pnHwFrmwkCol.hw_lvl_4_cd", "pnHwFrmwkCol.hw_lvl_5_cd", "pnHwFrmwkCol.hw_lvl_6_cd", "pnHwFrmwkCol.inrn_id", "pnHwFrmwkCol.hw_prod_ln_cd")

    val joinCondition = when(serpSelectDfpnHwFrmwkJoin("gbl_carepack_hw_prod_ln_id").isNotNull && serpSelectDfpnHwFrmwkJoin("gbl_carepack_hw_prod_ln_id") === serpSelectDfpnHwFrmwkJoin("hw_prod_ln_cd"), "1").when(serpSelectDfpnHwFrmwkJoin("pm_mtrl_mstr_sls_dvsn_cd").isNotNull && serpSelectDfpnHwFrmwkJoin("pm_mtrl_mstr_sls_dvsn_cd") === serpSelectDfpnHwFrmwkJoin("hw_prod_ln_cd"), "2").when(serpSelectDfpnHwFrmwkJoin("pmd_mtrl_mstr_sls_dvsn_cd").isNotNull && serpSelectDfpnHwFrmwkJoin("pmd_mtrl_mstr_sls_dvsn_cd") === serpSelectDfpnHwFrmwkJoin("hw_prod_ln_cd"), "3").otherwise("4")

    val serpSelectDfpnHwFrmwkJoinWithHWPL = serpSelectDfpnHwFrmwkJoin.withColumn("valid_hw_pl", joinCondition)


    val serpSelectDfpnHwFrmwkJoinDeDup = getLatestRecs(serpSelectDfpnHwFrmwkJoinWithHWPL, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "gbl_carepack_hw_prod_ln_id", "pm_mtrl_mstr_sls_dvsn_cd", "pmd_mtrl_mstr_sls_dvsn_cd",
      "prod_hrchy_prod_typ_cd", "prod_bs_and_opt_nr"), List("inrn_id", "valid_hw_pl"))

    val serpSelectDfpnHwFrmwkFinal = serpBmtJoinTblSelect.alias("serpDF").join(
      (serpSelectDfpnHwFrmwkJoinDeDup).alias("pnHwFrmwkCol"),
      serpBmtJoinTblSelect("sls_ord_id") === serpSelectDfpnHwFrmwkJoinDeDup("sls_ord_id") && serpBmtJoinTblSelect("sls_ord_ln_itm_id") === serpSelectDfpnHwFrmwkJoinDeDup("sls_ord_ln_itm_id") &&
        ((serpBmtJoinTblSelect("prft_cntr_cd").isNull && serpSelectDfpnHwFrmwkJoinDeDup("prft_cntr_cd").isNull) || serpBmtJoinTblSelect("prft_cntr_cd") === serpSelectDfpnHwFrmwkJoinDeDup("prft_cntr_cd"))
        && ((serpBmtJoinTblSelect("sgmtl_rptg_cd").isNull && serpSelectDfpnHwFrmwkJoinDeDup("sgmtl_rptg_cd").isNull) || serpBmtJoinTblSelect("sgmtl_rptg_cd") === serpSelectDfpnHwFrmwkJoinDeDup("sgmtl_rptg_cd"))
        && ((serpBmtJoinTblSelect("gbl_carepack_hw_prod_ln_id").isNull && serpSelectDfpnHwFrmwkJoinDeDup("gbl_carepack_hw_prod_ln_id").isNull) || serpBmtJoinTblSelect("gbl_carepack_hw_prod_ln_id") === serpSelectDfpnHwFrmwkJoinDeDup("gbl_carepack_hw_prod_ln_id"))
        && ((serpBmtJoinTblSelect("pm_mtrl_mstr_sls_dvsn_cd").isNull && serpSelectDfpnHwFrmwkJoinDeDup("pm_mtrl_mstr_sls_dvsn_cd").isNull) || serpBmtJoinTblSelect("pm_mtrl_mstr_sls_dvsn_cd") === serpSelectDfpnHwFrmwkJoinDeDup("pm_mtrl_mstr_sls_dvsn_cd"))
        && ((serpBmtJoinTblSelect("pmd_mtrl_mstr_sls_dvsn_cd").isNull && serpSelectDfpnHwFrmwkJoinDeDup("pmd_mtrl_mstr_sls_dvsn_cd").isNull) || serpBmtJoinTblSelect("pmd_mtrl_mstr_sls_dvsn_cd") === serpSelectDfpnHwFrmwkJoinDeDup("pmd_mtrl_mstr_sls_dvsn_cd"))
        && ((serpBmtJoinTblSelect("prod_hrchy_prod_typ_cd").isNull && serpSelectDfpnHwFrmwkJoinDeDup("prod_hrchy_prod_typ_cd").isNull) || serpBmtJoinTblSelect("prod_hrchy_prod_typ_cd") === serpSelectDfpnHwFrmwkJoinDeDup("prod_hrchy_prod_typ_cd"))
        && ((serpBmtJoinTblSelect("prod_bs_and_opt_nr").isNull && serpSelectDfpnHwFrmwkJoinDeDup("prod_bs_and_opt_nr").isNull) || serpBmtJoinTblSelect("prod_bs_and_opt_nr") === serpSelectDfpnHwFrmwkJoinDeDup("prod_bs_and_opt_nr")), "leftouter").select("serpDF.*", "pnHwFrmwkCol.hw_lvl_1_cd", "pnHwFrmwkCol.hw_lvl_2_cd", "pnHwFrmwkCol.hw_lvl_3_cd", "pnHwFrmwkCol.hw_lvl_4_cd", "pnHwFrmwkCol.hw_lvl_5_cd", "pnHwFrmwkCol.hw_lvl_6_cd").distinct

    serpSelectDfpnHwFrmwkFinal.write.mode("Overwrite").format("ORC").saveAsTable(dbCommonName+".serpBmtJoinTbl2_test")
    val serpSelectDfpnHwFrmwkFinalT = spark.sql(s"select * from ${dbCommonName}.serpBmtJoinTbl2_test")
    val serpSelectDfpnSlngMtnFrmwk = serpSelectDfpnHwFrmwkFinalT.select("sls_ord_id", "sls_ord_ln_itm_id", "ord_typ_cd", "sls_mtrc_cd", "prft_cntr_cd", "sgmtl_rptg_cd", "prod_bs_and_opt_nr", "prod_hrchy_prod_fmly_cd").distinct

    val serpSelectDfpnSlngMtnFrmwkJoin = serpSelectDfpnSlngMtnFrmwk.alias("serpDF").join(
      broadcast(pnSlngMtnFrmwkDmnsnDf).alias("pnSlngMtnFrmwkCol"),
      (serpSelectDfpnSlngMtnFrmwk("ord_typ_cd") === pnSlngMtnFrmwkDmnsnDf("sls_ord_typ_cd") || pnSlngMtnFrmwkDmnsnDf("sls_ord_typ_cd") === "all")
        && (serpSelectDfpnSlngMtnFrmwk("sls_mtrc_cd") === pnSlngMtnFrmwkDmnsnDf("bsn_typ_cd") || pnSlngMtnFrmwkDmnsnDf("bsn_typ_cd") === "all")
        && (serpSelectDfpnSlngMtnFrmwk("prft_cntr_cd") === pnSlngMtnFrmwkDmnsnDf("pft_cntr_cd") || pnSlngMtnFrmwkDmnsnDf("pft_cntr_cd") === "all")
        && (serpSelectDfpnSlngMtnFrmwk("sgmtl_rptg_cd") === pnSlngMtnFrmwkDmnsnDf("sgm_cd") || pnSlngMtnFrmwkDmnsnDf("sgm_cd") === "all")
        && ((serpSelectDfpnSlngMtnFrmwk("prod_bs_and_opt_nr") === pnSlngMtnFrmwkDmnsnDf("bs_prod_id") || (substring(trim(serpSelectDfpnSlngMtnFrmwk("prod_bs_and_opt_nr")), -2, 2) === substring(trim(pnSlngMtnFrmwkDmnsnDf("bs_prod_id")), -2, 2)
          && (pnSlngMtnFrmwkDmnsnDf("bs_prod_id").like("*%")))) || pnSlngMtnFrmwkDmnsnDf("bs_prod_id") === "all")
          && (serpSelectDfpnSlngMtnFrmwk("prod_hrchy_prod_fmly_cd") === pnSlngMtnFrmwkDmnsnDf("mfrg_prod_fmly_id") || pnSlngMtnFrmwkDmnsnDf("mfrg_prod_fmly_id") === "all"), "leftouter").filter(pnSlngMtnFrmwkDmnsnDf("inrn_id").isNotNull).select("serpDF.*", "pnSlngMtnFrmwkCol.slng_mtn_lvl_1_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_2_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_3_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_4_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_5_cd", "pnSlngMtnFrmwkCol.inrn_id")

    val serpSelectDfpnSlngMtnFrmwkDeDup = getLatestRecs(serpSelectDfpnSlngMtnFrmwkJoin, List("sls_ord_id", "sls_ord_ln_itm_id", "ord_typ_cd", "sls_mtrc_cd", "prft_cntr_cd", "sgmtl_rptg_cd", "prod_bs_and_opt_nr",
      "prod_hrchy_prod_fmly_cd"), List("inrn_id"))

    val serpSelectDfpnSlngMtnFrmwkFinal = serpSelectDfpnHwFrmwkFinalT.alias("serpCol").join(
      (serpSelectDfpnSlngMtnFrmwkDeDup).alias("pnSlngMtnFrmwkCol"),
      (serpSelectDfpnHwFrmwkFinalT("sls_ord_id") === serpSelectDfpnSlngMtnFrmwkDeDup("sls_ord_id") && serpSelectDfpnHwFrmwkFinalT("sls_ord_ln_itm_id") === serpSelectDfpnSlngMtnFrmwkDeDup("sls_ord_ln_itm_id")) &&
        ((serpSelectDfpnHwFrmwkFinalT("ord_typ_cd").isNull && serpSelectDfpnSlngMtnFrmwkDeDup("ord_typ_cd").isNull) || serpSelectDfpnHwFrmwkFinalT("ord_typ_cd") === serpSelectDfpnSlngMtnFrmwkDeDup("ord_typ_cd"))
        && ((serpSelectDfpnHwFrmwkFinalT("sls_mtrc_cd").isNull && serpSelectDfpnSlngMtnFrmwkDeDup("sls_mtrc_cd").isNull) || serpSelectDfpnHwFrmwkFinalT("sls_mtrc_cd") === serpSelectDfpnSlngMtnFrmwkDeDup("sls_mtrc_cd"))
        && ((serpSelectDfpnHwFrmwkFinalT("prft_cntr_cd").isNull && serpSelectDfpnSlngMtnFrmwkDeDup("prft_cntr_cd").isNull) || serpSelectDfpnHwFrmwkFinalT("prft_cntr_cd") === serpSelectDfpnSlngMtnFrmwkDeDup("prft_cntr_cd"))
        && ((serpSelectDfpnHwFrmwkFinalT("sgmtl_rptg_cd").isNull && serpSelectDfpnSlngMtnFrmwkDeDup("sgmtl_rptg_cd").isNull) || serpSelectDfpnHwFrmwkFinalT("sgmtl_rptg_cd") === serpSelectDfpnSlngMtnFrmwkDeDup("sgmtl_rptg_cd"))
        && ((serpSelectDfpnHwFrmwkFinalT("prod_bs_and_opt_nr").isNull && serpSelectDfpnSlngMtnFrmwkDeDup("prod_bs_and_opt_nr").isNull) || serpSelectDfpnHwFrmwkFinalT("prod_bs_and_opt_nr") === serpSelectDfpnSlngMtnFrmwkDeDup("prod_bs_and_opt_nr"))
        && ((serpSelectDfpnHwFrmwkFinalT("prod_hrchy_prod_fmly_cd").isNull && serpSelectDfpnSlngMtnFrmwkDeDup("prod_hrchy_prod_fmly_cd").isNull) || serpSelectDfpnHwFrmwkFinalT("prod_hrchy_prod_fmly_cd") === serpSelectDfpnSlngMtnFrmwkDeDup("prod_hrchy_prod_fmly_cd")), "leftouter").select("serpCol.*", "pnSlngMtnFrmwkCol.slng_mtn_lvl_1_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_2_cd",
        "pnSlngMtnFrmwkCol.slng_mtn_lvl_3_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_4_cd", "pnSlngMtnFrmwkCol.slng_mtn_lvl_5_cd").distinct

    serpSelectDfpnSlngMtnFrmwkFinal.write.mode("Overwrite").format("ORC").saveAsTable(dbCommonName+".serpBmtJoinTbl3_test")

    val serpSelectDfpnSlngMtnFrmwkFinalT = spark.sql(s"select * from ${dbCommonName}.serpBmtJoinTbl3_test")
    val serpSelectDfpnBsnCatFrmwk = serpSelectDfpnSlngMtnFrmwkFinalT.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "hw_lvl_4_cd", "sls_mtrc_cd", "prod_bs_and_opt_nr", "prod_hrchy_prod_fmly_cd", "ln_itm_3_cd").distinct

    val serpSelectDfpnBsnCatFrmwkJoin = serpSelectDfpnBsnCatFrmwk.alias("serpDF").join(
      broadcast(pnBsnCatFrmwkDmnsn).alias("pnBsnCatFrmwkCol"),
      (serpSelectDfpnBsnCatFrmwk("prft_cntr_cd") === pnBsnCatFrmwkDmnsn("pft_cntr_cd") || pnBsnCatFrmwkDmnsn("pft_cntr_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("sgmtl_rptg_cd") === pnBsnCatFrmwkDmnsn("sgm_cd") || pnBsnCatFrmwkDmnsn("sgm_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("hw_lvl_4_cd") === pnBsnCatFrmwkDmnsn("hw_lvl_4_cd") || pnBsnCatFrmwkDmnsn("hw_lvl_4_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("sls_mtrc_cd") === pnBsnCatFrmwkDmnsn("bsn_typ_cd") || pnBsnCatFrmwkDmnsn("bsn_typ_cd") === "all")
        && (serpSelectDfpnBsnCatFrmwk("prod_bs_and_opt_nr") === pnBsnCatFrmwkDmnsn("bs_prod_id") || ((pnBsnCatFrmwkDmnsn("bs_prod_id").like("*%")) && (serpSelectDfpnBsnCatFrmwk("prod_bs_and_opt_nr").rlike((concat(lit("."), trim(pnBsnCatFrmwkDmnsn("bs_prod_id"))).toString())))) || pnBsnCatFrmwkDmnsn("bs_prod_id") === "all")
        && (serpSelectDfpnBsnCatFrmwk("prod_hrchy_prod_fmly_cd") === pnBsnCatFrmwkDmnsn("mfrg_prod_fmly_id") || pnBsnCatFrmwkDmnsn("mfrg_prod_fmly_id") === "all")
        && (serpSelectDfpnBsnCatFrmwk("ln_itm_3_cd") === pnBsnCatFrmwkDmnsn("ln_itm_3_cd") || pnBsnCatFrmwkDmnsn("ln_itm_3_cd") === "all"), "leftouter").filter(pnBsnCatFrmwkDmnsn("inrn_id").isNotNull).select("serpDF.*", "pnBsnCatFrmwkCol.bsn_cgy_lvl_1_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_2_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_3_cd", "pnBsnCatFrmwkCol.inrn_id")


    val serpSelectDfpnBsnCatFrmwkDeDup = getLatestRecs(serpSelectDfpnBsnCatFrmwkJoin, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgmtl_rptg_cd", "hw_lvl_4_cd", "sls_mtrc_cd", "prod_bs_and_opt_nr", "prod_hrchy_prod_fmly_cd", "ln_itm_3_cd"), List("inrn_id"))

    val serpSelectDfpnBsnCatFrmwkFinal = serpSelectDfpnSlngMtnFrmwkFinalT.alias("serpJoindCol").join(
      (serpSelectDfpnBsnCatFrmwkDeDup).alias("pnBsnCatFrmwkCol"),
      serpSelectDfpnSlngMtnFrmwkFinalT("sls_ord_id") === serpSelectDfpnBsnCatFrmwkDeDup("sls_ord_id") && serpSelectDfpnSlngMtnFrmwkFinalT("sls_ord_ln_itm_id") === serpSelectDfpnBsnCatFrmwkDeDup("sls_ord_ln_itm_id") &&
        ((serpSelectDfpnSlngMtnFrmwkFinalT("prft_cntr_cd").isNull && serpSelectDfpnBsnCatFrmwkDeDup("prft_cntr_cd").isNull) || serpSelectDfpnSlngMtnFrmwkFinalT("prft_cntr_cd") === serpSelectDfpnBsnCatFrmwkDeDup("prft_cntr_cd"))
        && ((serpSelectDfpnSlngMtnFrmwkFinalT("sgmtl_rptg_cd").isNull && serpSelectDfpnBsnCatFrmwkDeDup("sgmtl_rptg_cd").isNull) || serpSelectDfpnSlngMtnFrmwkFinalT("sgmtl_rptg_cd") === serpSelectDfpnBsnCatFrmwkDeDup("sgmtl_rptg_cd"))
        && ((serpSelectDfpnSlngMtnFrmwkFinalT("hw_lvl_4_cd").isNull && serpSelectDfpnBsnCatFrmwkDeDup("hw_lvl_4_cd").isNull) || serpSelectDfpnSlngMtnFrmwkFinalT("hw_lvl_4_cd") === serpSelectDfpnBsnCatFrmwkDeDup("hw_lvl_4_cd"))
        && ((serpSelectDfpnSlngMtnFrmwkFinalT("sls_mtrc_cd").isNull && serpSelectDfpnBsnCatFrmwkDeDup("sls_mtrc_cd").isNull) || serpSelectDfpnSlngMtnFrmwkFinalT("sls_mtrc_cd") === serpSelectDfpnBsnCatFrmwkDeDup("sls_mtrc_cd"))
        && ((serpSelectDfpnSlngMtnFrmwkFinalT("prod_bs_and_opt_nr").isNull && serpSelectDfpnBsnCatFrmwkDeDup("prod_bs_and_opt_nr").isNull) || serpSelectDfpnSlngMtnFrmwkFinalT("prod_bs_and_opt_nr") === serpSelectDfpnBsnCatFrmwkDeDup("prod_bs_and_opt_nr"))
        && ((serpSelectDfpnSlngMtnFrmwkFinalT("prod_hrchy_prod_fmly_cd").isNull && serpSelectDfpnBsnCatFrmwkDeDup("prod_hrchy_prod_fmly_cd").isNull) || serpSelectDfpnSlngMtnFrmwkFinalT("prod_hrchy_prod_fmly_cd") === serpSelectDfpnBsnCatFrmwkDeDup("prod_hrchy_prod_fmly_cd"))
        && ((serpSelectDfpnSlngMtnFrmwkFinalT("ln_itm_3_cd").isNull && serpSelectDfpnBsnCatFrmwkDeDup("ln_itm_3_cd").isNull) || serpSelectDfpnSlngMtnFrmwkFinalT("ln_itm_3_cd") === serpSelectDfpnBsnCatFrmwkDeDup("ln_itm_3_cd")), "leftouter").select("serpJoindCol.*", "pnBsnCatFrmwkCol.bsn_cgy_lvl_1_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_2_cd", "pnBsnCatFrmwkCol.bsn_cgy_lvl_3_cd")

    serpSelectDfpnBsnCatFrmwkFinal.write.mode("Overwrite").format("ORC").saveAsTable(dbCommonName+".serpBmtJoinTbl4_test")
    val serpSelectDfpnBsnCatFrmwkFinalT = spark.sql(s"select * from ${dbCommonName}.serpBmtJoinTbl4_test")
    val serpSelectDfpnNnFcsDmnsn = serpSelectDfpnBsnCatFrmwkFinalT.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5").distinct

    val serpSelectDfpnNnFcsDmnsn1Join = serpSelectDfpnNnFcsDmnsn.alias("serpJoindCol1").join(
      broadcast(pnNnFcsDmnsnDf).alias("pnNnFcsDmnsnCol"),
      (serpSelectDfpnNnFcsDmnsn("prft_cntr_cd") === pnNnFcsDmnsnDf("prft_ctr_cd") || pnNnFcsDmnsnDf("prft_ctr_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_2") === pnNnFcsDmnsnDf("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf("sgmt_lvl_2_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_3") === pnNnFcsDmnsnDf("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf("sgmt_lvl_3_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_4") === pnNnFcsDmnsnDf("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf("sgmt_lvl_4_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_5") === pnNnFcsDmnsnDf("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf("sgmt_lvl_5_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_2") != pnNnFcsDmnsnDf("sgmt_lvl_2_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_3") != pnNnFcsDmnsnDf("sgmt_lvl_3_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_4") != pnNnFcsDmnsnDf("sgmt_lvl_4_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn("sgm_lvl_5") != pnNnFcsDmnsnDf("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf("inrn_id").isNotNull).select("serpJoindCol1.*", "pnNnFcsDmnsnCol.nn_fcs_cntry", "pnNnFcsDmnsnCol.inrn_id")

    val serpSelectDfpnNnFcsDmnsnDeDup = getLatestRecs(serpSelectDfpnNnFcsDmnsn1Join, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5"), List("inrn_id"))

    var serpSelectDfpnNnFcsDmnsnFinal = serpSelectDfpnBsnCatFrmwkFinalT.alias("serpJoindCol").join(
      (serpSelectDfpnNnFcsDmnsnDeDup).alias("pnNnFcsDmnsnCol"),
      serpSelectDfpnBsnCatFrmwkFinalT("sls_ord_id") === serpSelectDfpnNnFcsDmnsnDeDup("sls_ord_id") && serpSelectDfpnBsnCatFrmwkFinalT("sls_ord_ln_itm_id") === serpSelectDfpnNnFcsDmnsnDeDup("sls_ord_ln_itm_id") &&
        ((serpSelectDfpnBsnCatFrmwkFinalT("prft_cntr_cd").isNull && serpSelectDfpnNnFcsDmnsnDeDup("prft_cntr_cd").isNull) || serpSelectDfpnBsnCatFrmwkFinalT("prft_cntr_cd") === serpSelectDfpnNnFcsDmnsnDeDup("prft_cntr_cd"))
        && ((serpSelectDfpnBsnCatFrmwkFinalT("sgm_lvl_2").isNull && serpSelectDfpnNnFcsDmnsnDeDup("sgm_lvl_2").isNull) || serpSelectDfpnBsnCatFrmwkFinalT("sgm_lvl_2") === serpSelectDfpnNnFcsDmnsnDeDup("sgm_lvl_2"))
        && ((serpSelectDfpnBsnCatFrmwkFinalT("sgm_lvl_3").isNull && serpSelectDfpnNnFcsDmnsnDeDup("sgm_lvl_3").isNull) || serpSelectDfpnBsnCatFrmwkFinalT("sgm_lvl_3") === serpSelectDfpnNnFcsDmnsnDeDup("sgm_lvl_3"))
        && ((serpSelectDfpnBsnCatFrmwkFinalT("sgm_lvl_4").isNull && serpSelectDfpnNnFcsDmnsnDeDup("sgm_lvl_4").isNull) || serpSelectDfpnBsnCatFrmwkFinalT("sgm_lvl_4") === serpSelectDfpnNnFcsDmnsnDeDup("sgm_lvl_4"))
        && ((serpSelectDfpnBsnCatFrmwkFinalT("sgm_lvl_5").isNull && serpSelectDfpnNnFcsDmnsnDeDup("sgm_lvl_5").isNull) || serpSelectDfpnBsnCatFrmwkFinalT("sgm_lvl_5") === serpSelectDfpnNnFcsDmnsnDeDup("sgm_lvl_5")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry")

    serpSelectDfpnNnFcsDmnsnFinal = serpSelectDfpnNnFcsDmnsnFinal.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_ord")

    serpSelectDfpnNnFcsDmnsnFinal.write.mode("Overwrite").format("ORC").saveAsTable(dbCommonName+".serpBmtJoinTbl5_test")
	
    val serpSelectDfpnNnFcsDmnsnFinalT = spark.sql(s"select * from ${dbCommonName}.serpBmtJoinTbl5_test")
    val serpSelectDfpnFnclFrmwk = serpSelectDfpnNnFcsDmnsnFinalT.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "gl_acct_nr", "MRU", "cst_cntr_cd", "fnctl_ar_cd").distinct

    var serpSelectDfpnFnclFrmwkJoin = serpSelectDfpnFnclFrmwk.alias("serpJoindCol2").join(
      broadcast(pnFnclFrmwkDf).alias("pnFnclFrmwkCol"),
      (serpSelectDfpnFnclFrmwk("prft_cntr_cd") === pnFnclFrmwkDf("pft_cntr") || pnFnclFrmwkDf("pft_cntr") === "all")
        && (substring(serpSelectDfpnFnclFrmwk("gl_acct_nr"), 3, 8) === pnFnclFrmwkDf("acct_cd") || pnFnclFrmwkDf("acct_cd") === "all")
        && (serpSelectDfpnFnclFrmwk("MRU") === pnFnclFrmwkDf("mru_cd") || pnFnclFrmwkDf("mru_cd") === "all")
        && (serpSelectDfpnFnclFrmwk("cst_cntr_cd") === pnFnclFrmwkDf("cst_obj") || pnFnclFrmwkDf("cst_obj") === "all")
        && (serpSelectDfpnFnclFrmwk("fnctl_ar_cd") === pnFnclFrmwkDf("fnctl_ar") || pnFnclFrmwkDf("fnctl_ar") === "all"), "leftouter").filter(pnFnclFrmwkDf("precedence").isNotNull).select("serpJoindCol2.*", "pnFnclFrmwkCol.ff_ln_itm_0", "pnFnclFrmwkCol.ff_ln_itm_1", "pnFnclFrmwkCol.ff_ln_itm_2",
        "pnFnclFrmwkCol.ff_ln_itm_3", "pnFnclFrmwkCol.ff_ln_itm_4", "pnFnclFrmwkCol.ff_ln_itm_5", "pnFnclFrmwkCol.precedence")

    val serpSelectDfpnFnclFrmwkDeDup = getLatestRecs(serpSelectDfpnFnclFrmwkJoin, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "gl_acct_nr", "MRU", "cst_cntr_cd", "fnctl_ar_cd"), List("precedence"))

    var serpSelectDfpnFnclFrmwkFinal = serpSelectDfpnNnFcsDmnsnFinalT.alias("serpJoindCol").join(
      (serpSelectDfpnFnclFrmwkDeDup).alias("pnFnclFrmwkCol"),
      serpSelectDfpnNnFcsDmnsnFinalT("sls_ord_id") === serpSelectDfpnFnclFrmwkDeDup("sls_ord_id") && serpSelectDfpnNnFcsDmnsnFinalT("sls_ord_ln_itm_id") === serpSelectDfpnFnclFrmwkDeDup("sls_ord_ln_itm_id") &&
        ((serpSelectDfpnNnFcsDmnsnFinalT("prft_cntr_cd").isNull && serpSelectDfpnFnclFrmwkDeDup("prft_cntr_cd").isNull) || serpSelectDfpnNnFcsDmnsnFinalT("prft_cntr_cd") === serpSelectDfpnFnclFrmwkDeDup("prft_cntr_cd"))
        && ((serpSelectDfpnNnFcsDmnsnFinalT("gl_acct_nr").isNull && serpSelectDfpnFnclFrmwkDeDup("gl_acct_nr").isNull) || serpSelectDfpnNnFcsDmnsnFinalT("gl_acct_nr") === serpSelectDfpnFnclFrmwkDeDup("gl_acct_nr"))
        && ((serpSelectDfpnNnFcsDmnsnFinalT("MRU").isNull && serpSelectDfpnFnclFrmwkDeDup("MRU").isNull) || serpSelectDfpnNnFcsDmnsnFinalT("MRU") === serpSelectDfpnFnclFrmwkDeDup("MRU"))
        && ((serpSelectDfpnNnFcsDmnsnFinalT("cst_cntr_cd").isNull && serpSelectDfpnFnclFrmwkDeDup("cst_cntr_cd").isNull) || serpSelectDfpnNnFcsDmnsnFinalT("cst_cntr_cd") === serpSelectDfpnFnclFrmwkDeDup("cst_cntr_cd"))
        && ((serpSelectDfpnNnFcsDmnsnFinalT("fnctl_ar_cd").isNull && serpSelectDfpnFnclFrmwkDeDup("fnctl_ar_cd").isNull) || serpSelectDfpnNnFcsDmnsnFinalT("fnctl_ar_cd") === serpSelectDfpnFnclFrmwkDeDup("fnctl_ar_cd")), "leftouter").select("serpJoindCol.*", "pnFnclFrmwkCol.ff_ln_itm_0", "pnFnclFrmwkCol.ff_ln_itm_1", "pnFnclFrmwkCol.ff_ln_itm_2", "pnFnclFrmwkCol.ff_ln_itm_3", "pnFnclFrmwkCol.ff_ln_itm_4", "pnFnclFrmwkCol.ff_ln_itm_5", "pnFnclFrmwkCol.precedence")

    serpSelectDfpnFnclFrmwkFinal.write.mode("Overwrite").format("ORC").saveAsTable(dbCommonName+".serpBmtJoinTbl6_test")

    val serpSelectDfpnFnclFrmwkFinalT = spark.sql(s"select * from ${dbCommonName}.serpBmtJoinTbl6_test")
    val serpSelectDfpnNnFcsDmnsn1 = serpSelectDfpnFnclFrmwkFinalT.select("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "ff_ln_itm_5").distinct

    var serpSelectDfpnNnFcsJoin = serpSelectDfpnNnFcsDmnsn1.alias("serpJoindCol1").join(
      broadcast(pnNnFcsDmnsnDf1).alias("pnNnFcsDmnsnCol1"),
      (serpSelectDfpnNnFcsDmnsn1("prft_cntr_cd") === pnNnFcsDmnsnDf1("prft_ctr_cd") || pnNnFcsDmnsnDf1("prft_ctr_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_2") === pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_2_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_3") === pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_3_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_4") === pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_4_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_5") === pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") || pnNnFcsDmnsnDf1("sgmt_lvl_5_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("ff_ln_itm_5") === pnNnFcsDmnsnDf1("ff_l15_cd") || pnNnFcsDmnsnDf1("ff_l15_cd") === "all")
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_2") != pnNnFcsDmnsnDf1("sgmt_lvl_2_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_3") != pnNnFcsDmnsnDf1("sgmt_lvl_3_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_4") != pnNnFcsDmnsnDf1("sgmt_lvl_4_cd_exclude"))
        && (serpSelectDfpnNnFcsDmnsn1("sgm_lvl_5") != pnNnFcsDmnsnDf1("sgmt_lvl_5_cd_exclude")), "leftouter").filter(pnNnFcsDmnsnDf1("inrn_id").isNotNull).select("serpJoindCol1.*", "pnNnFcsDmnsnCol1.nn_fcs_cntry", "pnNnFcsDmnsnCol1.inrn_id")
    serpSelectDfpnNnFcsJoin = serpSelectDfpnNnFcsJoin.withColumnRenamed("nn_fcs_cntry", "nn_fcs_cntry_actl")

    val serpSelectDfpnNnFcsDeDup = getLatestRecs(serpSelectDfpnNnFcsJoin, List("sls_ord_id", "sls_ord_ln_itm_id", "prft_cntr_cd", "sgm_lvl_2", "sgm_lvl_3", "sgm_lvl_4", "sgm_lvl_5", "ff_ln_itm_5"), List("inrn_id"))

    var serpSelectDfpnNnFcsFinal = serpSelectDfpnFnclFrmwkFinalT.alias("serpJoindCol").join(
      (serpSelectDfpnNnFcsDeDup).alias("pnNnFcsDmnsnCol"),
      serpSelectDfpnFnclFrmwkFinalT("sls_ord_id") === serpSelectDfpnNnFcsDeDup("sls_ord_id") && serpSelectDfpnFnclFrmwkFinalT("sls_ord_ln_itm_id") === serpSelectDfpnNnFcsDeDup("sls_ord_ln_itm_id") &&
        ((serpSelectDfpnFnclFrmwkFinalT("prft_cntr_cd").isNull && serpSelectDfpnNnFcsDeDup("prft_cntr_cd").isNull) || serpSelectDfpnFnclFrmwkFinalT("prft_cntr_cd") === serpSelectDfpnNnFcsDeDup("prft_cntr_cd"))
        && ((serpSelectDfpnFnclFrmwkFinalT("sgm_lvl_2").isNull && serpSelectDfpnNnFcsDeDup("sgm_lvl_2").isNull) || serpSelectDfpnFnclFrmwkFinalT("sgm_lvl_2") === serpSelectDfpnNnFcsDeDup("sgm_lvl_2"))
        && ((serpSelectDfpnFnclFrmwkFinalT("sgm_lvl_3").isNull && serpSelectDfpnNnFcsDeDup("sgm_lvl_3").isNull) || serpSelectDfpnFnclFrmwkFinalT("sgm_lvl_3") === serpSelectDfpnNnFcsDeDup("sgm_lvl_3"))
        && ((serpSelectDfpnFnclFrmwkFinalT("sgm_lvl_4").isNull && serpSelectDfpnNnFcsDeDup("sgm_lvl_4").isNull) || serpSelectDfpnFnclFrmwkFinalT("sgm_lvl_4") === serpSelectDfpnNnFcsDeDup("sgm_lvl_4"))
        && ((serpSelectDfpnFnclFrmwkFinalT("sgm_lvl_5").isNull && serpSelectDfpnNnFcsDeDup("sgm_lvl_5").isNull) || serpSelectDfpnFnclFrmwkFinalT("sgm_lvl_5") === serpSelectDfpnNnFcsDeDup("sgm_lvl_5"))
        && ((serpSelectDfpnFnclFrmwkFinalT("ff_ln_itm_5").isNull && serpSelectDfpnNnFcsDeDup("ff_ln_itm_5").isNull) || serpSelectDfpnFnclFrmwkFinalT("ff_ln_itm_5") === serpSelectDfpnNnFcsDeDup("ff_ln_itm_5")), "leftouter").select("serpJoindCol.*", "pnNnFcsDmnsnCol.nn_fcs_cntry_actl")

    serpSelectDfpnNnFcsFinal.createOrReplaceTempView("serpTempTable5")

    logger.info("********************************************* SERP BMT join completed ")

    val SerpTblDf = spark.sql(s"""
   select distinct
 secrd_rpt_fact_ky                        
, mdm_cust_ky                              
, cst_cntr_ky                              
, pdm_mtrl_mstr_grp_ky                     
, pft_cntr_ky                              
, mgmt_grphy_unt_ky                        
, fnctl_ar_ky                              
, cntry_ky                                 
, sld_to_ky                                
, shp_to_ky                                
, bll_to_ky                                
, vndr_ky                                  
, gl_acct_ky                               
, py_pft_cntr_ky                           
, oy_pft_cntr_ky                           
, fy_pft_cntr_ky                           
, deal_ky                                  
, quote_ky                                 
, opty_ky                                  
, ord_hddr_ky                              
, ord_itm_ky                               
, entrs_lgl_ent_ldgr_ky                    
, cldr_rpt_ky                              
, hp_rcvd_dt_txt                           
, sls_ord_ln_itm_id                        
, sls_ord_id                               
, deal_id                                  
, mkt_rte_cd                               
, opty_id                                  
, ord_typ_cd                               
, mtrl_nr                                  
, src_sys_cd                               
, src_sys_ts                               
, ord_crt_dt                               
, ord_crt_ts                               
, ord_last_chg_dt                          
, hp_rcvd_dt                               
, ord_cgy_cd                               
, ord_cgy_dn                               
, quote_id                                 
, ord_net_vl_amt                           
, ord_dcmnt_curr_cd                        
, ord_hddr_nt_vl_usd_amt                   
, sls_orgn_cd                              
, dstbn_chnl_cd                            
, dvsn_cd                                  
, sls_grp_cd                               
, sls_offc_cd                              
, cst_cntr_cd                              
, fncl_ownr_cd                             
, cust_po_nr                               
, cust_po_typ_cd                           
, cust_po_cgy_cd                           
, sld_to_cd                                
, shp_to_cd                                
, end_cust_cd                              
, bll_to_cd                                
, ord_dlvry_cd                             
, bll_grp_cd                               
, ord_prch_cd                              
, dc_cd                                    
, sls_rep_cd                               
, ord_hddr_stts_cd                         
, ord_itm_stts_cd                          
, sls_dcmt_itm_cgy_cd                      
, mtrl_str_cd                              
, ord_itm_qty                              
, unt_msr_cd                               
, nt_prc_amt                               
, ord_itm_nt_vl_amt                        
, ord_itm_dcmt_curr_cd                     
, nt_prc_usd_amt                           
, ord_itm_nt_vl_usd_amt                    
, cust_ord_itm_po_nr                       
, plnt_cd                                  
, strg_loc_cd                              
, shpg_pt_cd                               
, rte_cd                                   
, ord_itm_crt_dt                           
, ord_itm_crt_ts                           
, prft_cntr_cd                             
, pch_lvl_3                                
, pch_lvl_4                                
, pch_lvl_5                                
, pch_lvl_6                                
, pch_lvl_7                                
, pch_lvl_8                                
, oypl_pch_level_1                         
, oypl_pch_level_2                         
, oypl_pch_level_3                         
, oypl_pch_level_4                         
, oypl_pch_level_5                         
, oypl_pch_level_6                         
, oypl_pch_level_7                         
, oypl_pch_level_8                         
, oypl_pch_level_1_desc                    
, oypl_pch_level_2_desc                    
, oypl_pch_level_3_desc                    
, oypl_pch_level_4_desc                    
, oypl_pch_level_5_desc                    
, oypl_pch_level_6_desc                    
, oypl_pch_level_7_desc                    
, oypl_pch_level_8_desc                    
, py_pft_cntr_cd                           
, fy_pft_cntr_cd                           
, sgmtl_rptg_cd                            
, sgm_lvl_2                                
, sgm_lvl_3                                
, sgm_lvl_4                                
, sgm_lvl_5                                
, sgm_lvl_6                                
, sgm_lvl_7                                
, sgm_lvl_8                                
, ord_itm_vsblty_stts_cd                   
, ord_itm_bndl_qty                         
, ord_itm_prmtn_cd                         
, ord_itm_opty_cd                          
, ord_itm_prch_cd                          
, cust_po_ln_nr                            
, zord_header_sys_stts_ln_nm               
, zord_item_sys_stts_ln_nm                 
, rvn_acctng_itm_src_dcmt_hdr_id                     
, blng_blck_sd_dcmt_cd                     
, prch_agrmnt_nr                           
, ppr_cd                                   
, prch_ord_typ                             
, pmnt_trms_cd                             
, crdt_stts                                
, crdd_cust_rqst_dt                        
, ord_etry_dt                              
, rslr_nr                                  
, bndl_dn                                  
, sr_nr                                    
, bndl_id                                  
, bndl_qty                                 
, mtrl_belonging_to_cus_nm                 
, hdr_hold_cd                              
, itm_hold_cd                              
, estmd_inv_dt                             
, opt_shipment_qty                         
, quote_distribution_date                               
, srv_agrmnt_id                            
, shpg_cnd_cd                              
, ord_vl                                   
, sls_tty_id                               
, dlvry_typ_cd                             
, dlvry_id                                 
, dlvry_itm_id                             
, actl_dlvry_dt                            
, dlvry_itm_cgy_cd                         
, shpmt_id                                 
, shpmt_itm_id                             
, plnd_shp_strt_dt                         
, plnd_shp_end_dt                          
, sm_actl_gds_mvmt_dt                      
, invc_id                                  
, invc_ln_itm_id                           
, blng_typ_cd                              
, actl_inv_dt                              
, base_qty                                 
, unt_qty                                  
, wght_cd                                  
, nt_inv_vl_amt                            
, grs_inv_vl_amt                           
, cp_net_inv_usd_amt                       
, cp_grs_inv_usd_amt                       
, crdt_dbt_ind                             
, disa_ind                                 
, dscnt_ind                                
, CASE WHEN pn_greenlake_flg_dmnsn.greenlake_flg_cd IS NULL THEN 'N' ELSE 'Y' END as grn_lake_ind                          
, dxc_ind                                  
, hpc_ind                                  
, hyperconverged_ind                       
, icoem_ind     
, CASE WHEN nn_fcs_cntry_ord IS NULL THEN 'N' ELSE nn_fcs_cntry_ord END as nn_fcs_ctry_ord_ind  
, CASE WHEN nn_fcs_cntry_actl IS NULL THEN 'N' ELSE nn_fcs_cntry_actl END as nn_fcs_ctry_actl_ind                                                 
, mlt_yr_ind                               
, prepaid_ind                              
, srv_intensity_ind                        
, ln_itm_1_cd                              
, ln_itm_2_cd                              
, ln_itm_3_cd                              
, ln_itm_4_ofr_cd                          
, ln_itm_5_sla_cvrg_cd                     
, ln_itm_6_typ_cd                          
, ln_itm_7_durtn_cd                        
, slng_mtn_lvl_1_cd                        
, slng_mtn_lvl_2_cd                        
, slng_mtn_lvl_3_cd                        
, slng_mtn_lvl_4_cd                        
, slng_mtn_lvl_5_cd                        
, hw_lvl_1_cd                              
, hw_lvl_2_cd                              
, hw_lvl_3_cd                              
, hw_lvl_4_cd                              
, hw_lvl_5_cd                              
, hw_lvl_6_cd                              
, serpTempTable5.bsn_cgy_lvl_1_cd                         
, serpTempTable5.bsn_cgy_lvl_2_cd                         
, serpTempTable5.bsn_cgy_lvl_3_cd                         
, cntrct_id                                
, pob_id                                   
, recon_ky_cd                              
, fscl_yr_nr                               
, fscl_prd_nr                              
, fscl_yr_prd_cd                        
, fscl_qtr_nr                              
, cndn_typ_cd                              
, gl_acct_nr                               
, pstd_rvn_amt                             
, pstd_rvn_curr                            
, pstd_rvn_usd_amt                         
, estmd_rvn_amt                            
, rvn_dlta_qty                             
, estmd_rvn_curr                           
, estmd_rvn_usd_amt                        
, ttl_rvn_amt                              
, ttl_rvn_usd_amt                          
, ln_itm_dcmt_nr                           
, ln_itm_nr                                
, ln_itm_sub_nr                            
, rec_typ_cd                               
, pftblty_sgm_copa_nr                      
, pln_vrsn_copa_cd                         
, crtd_by                                  
, dcmt_crtd_dt                             
, crtd_at                                  
, utc_tm_stamp                             
, pstg_dt                                  
, gds_iss_dt                               
, inv_crtd_dt                              
, copa_pnt_valtn_cd                        
, blld_ind                                 
, blng_prd_cd                              
, rfnc_prcgr_cd                            
, rfnc_orgnl_unt_cd                        
, lgcl_sys_src_dcmt_cd                     
, rfnc_dcmt_copa_ln_itm_cd                 
, itm_frm_rfnc_dcmt_copa_cd                
, rfnc_subitem_cd                          
, cnld_dcmt_cd                             
, cnld_dcmt_it_1_cd                        
, cnld_subnumber_ln_itm_cd                 
, dltd_by_dcmt_cd                          
, dltd_by_itm_cd                           
, cnld_by_dcmt_cd                          
, cnld_dcmt_it_2_cd                        
, co_cd                                    
, ctrlng_ar_cd                             
, bsn_ar_cd                                
, fnctl_ar_cd                              
, ptnr_pft_cntr_cd                         
, sndr_cst_cntr_cd                         
, sndr_bsn_prs_cd                          
, cst_obj_cd                               
, wbs_elmt_cd                              
, eqpmnt_cd                                
, sls_doc_original_cd as sls_doc_orignal_cd                       
, srv_cntrct_cd                            
, otc_cd                                   
, srv_evt_id                               
, ts_sls_mtn_cd                            
, po_odm_ic_sto_lbr_cd                     
, po_itm_cd                                
, ven_odm_ic_pn_labr_cd                    
, poem_cd                                  
, emr_new_mtrl_cd                          
, go_mkt_ofr_id                            
, hpe_fllfillg_plnt_cd                     
, sltn_3_cd                                
, sltn_1_cd                                
, cust_sgm_cd                              
, sltn_2_cd                                
, hghr_lvl_itm_no_cd                       
, ord_rsn_cd                               
, valtn_clss_cd                            
, src_itm_cd                               
, mkt_sgm_cd                               
, mkt_ofrng_cd                             
, curr_typ_valtn_vw_cd                     
, curr_dta_rec_cd                          
, a3_rbt_amt                               
, 70r_rbt_amt                              
, 69r_rbt_amt                              
, 69t_rbt_amt                              
, 15_rbt_amt                               
, 4_rmktd_dm_elvtn_amt                     
, 15r_pmnt_prd_stlmnt_amt                  
, 72_deal_rgst_amt                         
, 74tier_deals_amt                         
, 0709r_prod_prmtns_amt                    
, 26raingstock_amt                         
, 77eend_sls_amt                           
, 77prtnr_spcf_amt                         
, 10spngtdendcusd_oem_amt                  
, 79lwmghiendcustdisc_amt                  
, 72sp_ngtd_endcust_d_amt                  
, dscnt_amt                                
, qty_dscnt_amt as dscnt_qty_amt                                
, prc_rdctn_amt                            
, rvn_amt                                  
, otgng_frgt_amt                           
, vrnc_adjmt_amt                           
, 93pur_agmnt_disc_amt                     
, 2x_shpng_hndl_amt                        
, 2yspl_hndl_amt                           
, 22basic_frgt_amt                         
, 60listnet_pr_adjmt_amt                   
, 35pen_feent_rchd_amt                     
, 75misc_chg_amt                           
, a8bklog_prdcr_prtn_amt                   
, 12hpe_acmgmt_supprt_amt                  
, rw_matspare_prts_amt                     
, emr_cst_amt                              
, pkgg_amt                                 
, sub_asbly_contmfg_amt                    
, fin_brdn_amt                             
, fnshd_mtrls_amt                          
, lohp_amt                                 
, hpe_ovrhd_amt                            
, rylty_amt                                
, vndr_rebates_amt                         
, masking_amt                              
, fees_frgt_duty_amt                       
, cst_elmt_cd                              
, totl_vl_ldgr_curr                        
, fix_vl_ldgr_curr                         
, eurofit_flag                             
, eurofit_split_percentage                 
, acctng_dcmt_cd                           
, ln_itm_within_acctng_dcmt_cd             
, pftblty_anlys_qty_tbl_src_cst_elmt_cd    
, scndry_cst_elmt_cd                       
, sls_qty_amt                              
, ctry_cd                                  
, serpTempTable5.rgn_cd                                   
, mtrl_lng_mtrl_dn                         
, mtrc_cd                                  
, mtrc_dn                                  
, icost_dtl_amt                            
, curr_ky                                  
, dlt_ind                                  
, rec_ts
,icost_dtl_oth_fix_cst_amt
,icost_dtl_var_ryl_cst_amt
,icost_dtl_var_trd_exp_cst_amt
,icost_dtl_var_warr_cst_amt
,icost_dtl_oth_var_cst_amt
,Calc_cst_EK02_usd_amt as entrprs_stndrd_cst_grp_curr_usd_amt      
, brdn_cst  
,ttl_brdn_cst  
,ttl_dly_brdn_cst
,ttl_base_qty_brdn_cst
,ttl_inv_brdn_cst                           
, ttl_cst_sls_amt                          
, ttl_cst_sls_usd_amt                      
, fctry_mrgn_amt                           
, grs_mrgn_amt                             
, grs_mrgn_usd_amt                         
, rt_cnvsn_src                             
, rvn_cnvrsn_rt                            
, entrprs_stndrd_cst_rt                    
, ttl_cst_sls_rt                           
, cp_nt_rvn_amt                            
, cp_nt_rvn_usd_amt 
, CURRENT_TIMESTAMP as ins_ts
, scra_cgy_cd
, sni_risk_asmnt_cgy_cd
, NULL as pstg_prd_nr
, fnc_adjmt_ind
,'N' as fnc_insrt_ind
,'NA' as fnc_insrt_rsn_cd                                                   
, cp_end_cust_prty_id                      
, cp_end_cust_prty_nm                      
, cp_rtm_nm                                
,cp_sldt_prty_id
,cp_shpt_prty_id
,cp_prft_ctr_cd
,cp_segment_cd
, cp_ndp_usd_amt                           
, cp_grs_usd_amt                           
, cp_entprs_std_cst_usd_amt                
, cp_tot_cst_of_sls_usd_amt 
, cp_unit_qty
, NULL as cp_base_qty
, NULL as use_nm
, cp_rev_recgn_cgy_cd 
, CASE WHEN rev_rec_cgy_snp_dmnsn_cp.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn_cp.rev_hd_cd ELSE 'Opportunity' END as cp_rev_hdr_nm
, rvn_rcgn_cgy_cd                          
, CASE WHEN rev_rec_cgy_snp_dmnsn_cp.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn_cp.incd_excld_cd ELSE NULL END as cp_incd_excld                            
, CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.rev_hd_cd ELSE 'Opportunity' END as rev_hd_cd   
, beg_bklg_nm
, cp_bklg_sni_rvn                          
, fscl_week_cd                             
, shp_to_ctry_cd                           
, bsn_typ_cd                                                        
, ctry_nm                                  
, cust_sgm_nm                              
, bsn_rshp_typ_cd                          
, inctrms_prt_1_cndtn_txt                  
, prtl_dlvry_itm_lvl                       
, shrt_txt_sls_ord_itm_nm                  
, inctrms_prt_1_cndtn_cd                   
, src_idoc_nr                              
, idoc_crt_dt_ts                           
, dlvry_pri_hddr_cd                        
, dlvry_pri_itm_cd                         
, dlvry_pri_dn                             
, prod_base_id 
, NULL as cust_nr
,NULL as gc_exch_rate,
NULL as tx_exch_rate,
NULL as lcr_tx_rate,
NULL as acctng_dcmt_id,
NULL as ptnr_mgmt_grphy_unt_cd,
NULL as frly_dfnd_curr_3_amt,
NULL as frly_dfnd_curr_4_amt,
NULL as frly_dfnd_curr_5_amt,
NULL as frly_dfnd_curr_6_amt,
NULL as exch_rate,
NULL as exch_rate_dt,
NULL as acct_nr,
NULL as ptnr_fnctl_ar_cd,
NULL as tc_blc_amt,
NULL as tc_amt,
NULL as co_cd_curr_amt,
NULL as gbl_curr_amt,
NULL as dcmt_pstg_dt,
NULL as dcmt_dt,
NULL as lcr_cd,
NULL as ldgr_grp_cd,
NULL as lgcl_sys_cd,
NULL as ofst_acct_nr,
NULL as ptnr_cst_obj_cd,
NULL as ptnr_entrs_lgl_ent_ldgr_cd,
NULL as rvrsd_itm_ind,
NULL as sndr_lgcl_sys_cd,
NULL as tc_cd,
NULL as ln_itm_txt,
NULL as src_dcmt_nr
, deal_acct_mgmt_lvl_2_id                  
, deal_acct_mgmt_lvl_2_nm                  
, deal_bsn_mdl_cd                          
, deal_bsn_mdl_dn                          
, deal_cust_ltn_nm                         
, deal_cust_nn_ltn_nm                      
, deal_rgst_id                             
, deal_src_sys_cd                          
, deal_deal_src_sys_dn as deal_src_sys_dn                          
, deal_stts_nm                             
, deal_sb_typ_cd                           
, deal_typ_cd                              
, deal_vrsn_nr                             
, deal_vrsn_stts_nm                        
, deal_grphc_scp_nm                        
, deal_indy_id                             
, deal_last_updd_by_eml_id                 
, deal_lead_bsn_unt_cd                     
, deal_misc_crg_cd                         
, deal_prnt_org_id                         
, deal_prnt_org_nm                         
, deal_pyr_prty_id                         
, deal_sls_tty_acct_cnflct_ind             
, deal_sls_tty_acct_nm                     
, deal_src_deal_id                         
, deal_vld_end_ts                          
, deal_vld_strt_ts                         
, deal_ins_ts                              
, deal_upd_ts
, NULL as deal_itm_deal_id,
NULL as total_auth_bdnet_lcl,
NULL as total_auth_bdnet_usd,
NULL as total_rqst_bdnet_lcl,
NULL as total_rqst_bdnet_usd,
NULL as quoted_bdnet,
NULL as deal_itm_lst_prc_amt,
NULL as deal_itm_athzd_big_deal_nt_amt,
NULL as deal_itm_athzd_totl_pct,
NULL as deal_itm_estmd_k_amt,
NULL as deal_itm_xtnd_estmd_k_amt,
NULL as deal_itm_cnsmd_amt,
NULL as deal_itm_cnsmd_qty,
NULL as deal_itm_rmng_amt,
NULL as deal_itm_last_quoted_qty,
NULL as deal_itm_athzd_nt_rvn_amt,
NULL as deal_itm_rmng_qty,
NULL as deal_itm_src_sys_qty,
NULL as deal_itm_lst_prc_usd_amt
, quote_header_sls_qtn_vrsn_sqn_nr_cd      
, asset_quote_nr_cd                        
, asset_quote_vrsn_cd                      
, modified_ts_cd                           
, creation_person_id_id as crtd_by_usr_id                           
, sfdc_status_cd                           
, total_amt                                
, total_list_price_amt                     
, bmi_id_id                                
, nm                                       
, price_geo_cd                             
, asset_quote_nr_and_vrsn_cd               
, org_id_id                                
, creation_ts_cd                           
, currency_cd_cd                           
, sls_qtn_vrsn_typ_cd_cd                   
, cty_cd                                   
, quoteowner_cd                            
, flg_typ_cd                               
, flg_vl_cd                                
, sls_qtn_vrsn_typ_cd_cd as sls_qtn_vrsn_stts_cd_cd                  
, partner_id_id                            
, orig_asset_cd                            
, modified_person_id_id                    
, lead_bu_cd                               
, last_modifier_ngq_profile_cd             
, customer_mdcp_org_id_id                  
, mdcp_opsi_id_id                          
, creator_ngq_profile_cd                   
, creation_person_id_id                    
, completion_ts_cd 
, NULL as bsn_grp
, NULL as ltst_qt_vrsn
, quote_items_product_line_cd              
, lcl_xtnd_nt_amt_cd                       
, qty_cd   
, NULL as opportunity_estimated_revenue_usd
, acct_i_20_nm as accnt_id                                 
, hpe_quote_flags_sls_qtn_id_id as hpe_quote_flags_sls_qtn_id               
, hpe_quote_flags_sls_qtn_vrsn_sqn_nr_cd as hpe_quote_flags_sls_qtn_vrsn_sqn_nr      
, totl_opty_v_cd as ttl_opty_vl                              
, expctd_amt_cd as opty_expctd_amt                          
, opty_totl_amt_cd as opty_totl_amt                            
, opty_totl_amt_cd as opty_val                                 
, bookshi_2_dt as opty_bk_ship_dt                          
, last_mfy_205_dt as opty_lst_mfd_dt                          
, sys_modstam_4_cd as sys_modstam                              
, b_3_nm as bg_cd                                    
, gb_15_nm as gbu_cd                                   
, opportunitystage_nm as opty_stg                                 
, pro_283_nm as prd_nm                                   
, prod_l_5_nm as prd_ln                                   
, sb_prod_l_2_nm as sub_prd_ln                               
, instln_ord_flg                           
, prj_ord                                  
, dlvy_inv_cd                              
, inv_bvr                                  
, pld_inv_dt                               
, hg_vw_bkt                                
, sni_alt_bkt                              
, in_out                                   
, pri_bkt                                  
, in_out_omc_rsk_bkt,
NULL as cs_nr,
NULL as acct_nm,
NULL as rec_typ_i_118_nm,
NULL as stt_130_nm,
NULL as cse_rs_2_nm,
NULL as sb_7_nm,
NULL as cls_15_cd,
NULL as cls_2_dt,
NULL as cse_curr_cd,
NULL as own_i_33_nm,
NULL as crt_37_dt,
NULL as last_mfy_39_dt,
NULL as ctry_submitter_nm,
NULL as q_116_nr,
NULL as cse_comments_nm,
NULL as rg_29_nm,
NULL as wrld_rg_nm,
NULL as wrld_rgn_rgn_nm,
NULL as wrld_rgn_sb_rgn_nm,
NULL as wrld_rgn_sb_rgn_2_nm,
NULL as wrld_rgn_sb_rgn_3_nm,
NULL as ctr_56_nm,
NULL as b_nm,
NULL as cse_age_bsn_dys_dt,
NULL as asng_to_team_nm,
NULL as bsn_ty_2_nm,
NULL as cse_rqstr_eml_nm,
NULL as cls_cse_rsn_nm,
NULL as opendate_dt,
NULL as re_2_nm,
NULL as rsln_stts_nm,
NULL as asscd_cse_nm,
NULL as rte_to_mk_2_nm,
NULL as sld_to_prt_nm,
NULL as prnt_rec_typ_nm,
NULL as rqstr_p_nm,
NULL as sls_ord_amt_cd,
NULL as submitter_em_2_nm,
NULL as db_eml_ref_id_nm,
NULL as cse_own_eml_nm,
NULL as hpe_ord_nr,
NULL as cse_age_cd,
NULL as cse_scnr_nm,
NULL as cust_ph_nm,
NULL as po_amt_cd,
NULL as cb_2_nm,
NULL as clm_rfn_nm,
NULL as inrn_scnr_nm,
NULL as po_nr,
NULL as prch_agrmn_2_nm,
NULL as cse_curr_nm,
NULL as rec_typ_nm,
NULL as geo_bmt_ctry_cd,
NULL as geo_bmt_ctry_nm,
NULL as sb_rgn_lvl_2_cd,
NULL as sb_rgn_cd,
NULL as geo_bmt_rgn_cd,
NULL as due_tm_dt,
NULL as actvy_i_12_nm,
NULL as tsk_rec_typ_i_nm,
NULL as stt_3_nm,
NULL as sb_3_nm,
NULL as tsk_sbt_63_nm,
NULL as tsk_ty_64_nm,
NULL as tsk_sbt_nm,
NULL as workingdaysopen,
NULL as over_25k,
NULL as ge_5_wd,
NULL as aging_bucket,
NULL as unclean_in_sap,
NULL as usd_flag,
NULL as om_org,
NULL as consolidated_amt,
NULL as unbooked_aging,
NULL as op_aging,
NULL as tsk_sbj,
NULL as cc,
NULL as gt,
NULL as sc,
NULL as omc,
NULL as cpq,
NULL as rso,
NULL as others,
NULL as open_tasks,
NULL as status_tasks,
NULL as issue_code,
NULL as cse_own_ro_nm
,  inctrms_prt_2_cndtn_txt                  
, fan_nr                     
, zord_item01_mtrl_acct_asngmt_cd_grp as acct_asngmt_cd_grp                       
,  inctrms_prt_2_cndtn_cd                   
, ord_itm_qty as qty_desc                                 
, ord_bndl_conf_id as ord_bndl_conf_id                         
, case when estmd_invc_date = '00000000' then '' else estmd_invc_date end as estmd_invc_date_hdr                      
, estmd_inv_dt as estmd_inv_dt_itm                         
, sls_mtrc_cd as sls_mtrc_cd                              
, ord_durtn_cd                             
, prod_bs_and_opt_nr                          
, prod_id                    
, srvc_gds_prod_id                              
, pkg_prod_id                         
, pmd_mtrl_mstr_sls_dvsn_cd as mft_prd_ln_cd                            
, pm_mtrl_mstr_sls_dvsn_cd as srvc_gds_prd_ln_cd                       
, prod_hrchy_prod_fmly_cd as mft_prd_fmly_ln_cd                       
, gbl_carepack_hw_prod_ln_id as gbl_crpk_prd_ln_cd                       
, prod_hrchy_prod_typ_cd as bs_prd_typ_cd                            
, e1edka1_ctry_ky_cd_ZC as end_cust_ctry_ky                         
, e1edka1_ctry_ky_cd_RE as invc_rcpnt_ctry_ky                       
, e1edka1_ctry_ky_cd_Z1 as rsllr_ctry_ky                            
, e1edka1_ctry_ky_cd_WE as shp_to_ctry_ky                           
, e1edka1_ctry_ky_cd_AG as sld_to_ctry_ky                           
, e1edp19_idoc_mtrl_i_1_nm_1 as cstmr_prd_cd                             
, sm_prf_dlvry_cfrn_dt as prf_dlvry_cfrn_dt                        
, e1edk03_ido_1_id_22 as prch_ord_dt                              
, rsn_at_ln_itm_cd as rsn_at_ln_itm_cd                         
, intangible_ln_itm_stts_cd as intangible_ln_itm_stts_cd                
, e1edk03_ido_1_id_2 as rqstd_dlvry_dt                           
, cust_grp_3_cd as cust_grp_3_cd                            
, e1edk01_cmplt_dlvry_dfnd_each_sls_ord_cd as dlvry_typ_cnsldt_shp                     
, e1edk01_idoc_dcmt_nr as hpe_ordr_nr                              
, blng_stts_orderrelated_blng_dcmt_cd as invc_stts_cd                             
, itm_stts_cd as itm_stts_cd                              
, ois_trsn_nr as ois_trsn_nr                              
, ord_st_cd as ord_st_cd                                
, atp_chk_flg_cd as atp_chk_flg_cd                           
, sm_dtl_dlvry_grp_nr as shp_grp_nr                               
, sm_dlvry_trns_stts_cd as shp_stts_cd                              
, shp_athzn_ltr_nm as sal_nr         
, NULL as rfnc_dcmt_ln_itm_nr
, NULL as rfnc_dcmt_nr
, NULL as vndr_id
, NULL as dcmt_etry_ts
, NULL as gds_bsn_actvy_dn
, NULL as sls_dcmt_cd
, NULL as soldto_prty_nm
, NULL as shp_to_ptnr_id
, cntrct_strt_dt                           
, cntrct_end_dt
,ff_ln_itm_0 as FF_LI0
,ff_ln_itm_1 as FF_LI1
,ff_ln_itm_2 as FF_LI2
,ff_ln_itm_3 as FF_LI3
,ff_ln_itm_4 as FF_LI4
,ff_ln_itm_5 as FF_LI5
,ff_ln_itm_6 as FF_LI6
,ff_ln_itm_7 as FF_LI7
,rfrnc_dcmt_nr_qlfr
,rfrnc_dcmt_nr
,rfrnc_dcmt_itm_nr
,rfrnc_dcmt_nr_dt
,rfrnc_dcmt_nr_tm
,Calc_cst_EK02_amt
,Calc_cst_EK02_usd_amt
,NULL as dcmt_typ_cd
,exch_rate_nm
,cust_cndn_grp_1_cd
,cust_cndn_grp_2_cd
,cust_cndn_grp_3_cd
,cust_cndn_grp_4_cd
,cust_cndn_grp_5_cd
,cust_cndn_grp_1_cd_1
,cust_cndn_grp_2_cd_1
,cust_cndn_grp_3_cd_1
,cust_cndn_grp_4_cd_1
,cust_cndn_grp_5_cd_1
,exch_rate_12MM
,exch_rate_3MM
,exch_rate_0MM
,exch_rate_typ_id
,ope_bmt_rslr_prty_id
,mdm_ship_to_prty
,mdm_sld_to_prty_nm
,NULL as cust_sgmt_gtm
,NULL as us_geo_sgmt
,NULL as hst_grp_nm
,MRU as mru_cd
,NULL as cst_pl
,ucid_id
,bto_cto_flg
,curnt_sls_div_pft_cntr_cd
,rsn_rjctn_quotations_and_sls_orders_cd
,zord_hdr_ovrl_status
,serpTempTable5.src_sys_upd_ts                           
,serpTempTable5.src_sys_ky                               
,serpTempTable5.lgcl_dlt_ind                             
,serpTempTable5.ins_gmt_ts                               
,serpTempTable5.upd_gmt_ts                               
,serpTempTable5.src_sys_extrc_gmt_ts                     
,serpTempTable5.src_sys_btch_nr                          
,serpTempTable5.fl_nm                                    
,serpTempTable5.ld_jb_nr
from serpTempTable5
--left outer join ${dbCommonName}.pn_greenlake_flg_dmnsn pn_greenlake_flg_dmnsn on serpTempTable5.prft_cntr_cd = pn_greenlake_flg_dmnsn.pft_cntr_cd and pn_greenlake_flg_dmnsn.bsn_cgy_lvl_2_cd = serpTempTable5.bsn_cgy_lvl_2_cd
    left outer join ${dbCommonName}.bmt_pn_greenlake_flg_dmnsn pn_greenlake_flg_dmnsn 
on serpTempTable5.prft_cntr_cd = pn_greenlake_flg_dmnsn.pft_cntr_cd 
and ( UPPER(substring(serpTempTable5.cust_po_nr,1,3)) = UPPER(pn_greenlake_flg_dmnsn.cust_po_id) or  pn_greenlake_flg_dmnsn.cust_po_id ="all") 
and (pn_greenlake_flg_dmnsn.bsn_cgy_lvl_2_cd = serpTempTable5.bsn_cgy_lvl_2_cd 
or pn_greenlake_flg_dmnsn.bsn_cgy_lvl_2_cd = "all" )
left outer join ${dbCommonName}.bmt_rev_rec_cgy_snp_dmnsn rev_rec_cgy_snp_dmnsn_cp on  serpTempTable5.cp_rev_recgn_cgy_cd   = rev_rec_cgy_snp_dmnsn_cp.rev_recgn_cgy_cd
left outer join ${dbCommonName}.bmt_rev_rec_cgy_snp_dmnsn rev_rec_cgy_snp_dmnsn on serpTempTable5.rvn_rcgn_cgy_cd  = rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd
""")

    SerpTblDf.repartition(10).write.format("orc").mode("append").insertInto(tgtTblName)
    
    logger.info("********************************************* SERP data inserted")

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } finally {
    logger.info("//*********************** Log End for SerpDf.scala ************************//")
    sqlCon.close()
    spark.close()    
  }

}
package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object ProfitCenterAllocationSecuredReporting extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true
  val logger = Logger.getLogger(getClass.getName)
  val objName = propertiesObject.getObjName().trim()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  logger.info("//*********************** Log Start for SERPEnrichmentSecuredReport.scala ************************//")
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  //***************************Audit Properties********************************//
  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_secured_serp_pc_allocation_fact_load")
  auditObj.setAudObjectName(objName)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)

  spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 1 * 1024 * 1024 * 1024)

  try {

    Utilities.paramCheck(Seq(objName, ld_jb_nr, batchId, tgtTblConsmtn))

    val dbCommonNameLR1 = propertiesObject.getDbName().trim().split(",")(0)
    val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    /*
     * Profit Center Allocation
     *
     * Step1 – Join sales order with profit center allocation BMT using profit center code as a key
		 * Step2 - For each profit center that exist in 'BMT.From Profit Center', create a line item with Source System Code as 'OFFSET'. Set Gross Revenue and Net Revenue = -1 multiply by the values in the respective attribute where Source System = 'SERP'
		 * Step3 - For each profit center that exist in 'BMT.From Profit Center', create a line items with Source System Code as 'PC ALLOC', CP_PRFT_CTR_CD = 'BMT.To Profit Center', PRFR_CNTR_CD = 'BMT.To Profit Center' and split Gross Revenue and Net Revenue per 'BMT.Allocation Percentage'
     *
     */

    val finalSERPDF = spark.sql(s"select * from ${srcTableName}")

    val pnpftbmtDmnsnDf = spark.sql(s"select * from ${dbCommonNameLR1}.bmt_prft_cntr_allctn_dmnsn where UPPER(lgcl_dlt_flg)='N'")

    var colList = finalSERPDF.columns.toList

    //Step1 – Join sales order with profit centre allocation bmt using profit centre code as a key

    val pnpftbmtDmnsnDfjoin = finalSERPDF.alias("serp").join(
      pnpftbmtDmnsnDf.alias("profit"),
      (finalSERPDF("prft_cntr_cd") === pnpftbmtDmnsnDf("frm_prft_cntr")
        && (finalSERPDF("src_sys_cd") === "SERP" || finalSERPDF("src_sys_cd").like("%EGI-INSERT%") || finalSERPDF("src_sys_cd") === "TRUE_UP")), "inner").
      filter(col("to_prft_cntr").isNotNull).select(
        "serp.*",
        "profit.frm_prft_cntr",
        "profit.to_prft_cntr",
        "profit.alcnt_pcntg")

    //Step3 - For each profit center that exist in 'BMT.From Profit Center', create a line items with Source System Code as 'PC ALLOC', CP_PRFT_CTR_CD = 'BMT.To Profit Center', PRFR_CNTR_CD = 'BMT.To Profit Center' and split Gross Revenue and Net Revenue per 'BMT.Allocation Percentage'

    val profit_df4 = pnpftbmtDmnsnDfjoin.
      withColumn("nt_rvn_amt", col("nt_rvn_amt") * col("alcnt_pcntg")).
      withColumn("grs_rvn_amt", col("grs_rvn_amt") * col("alcnt_pcntg")).
      withColumn("cp_nt_rvn_amt", col("cp_nt_rvn_amt") * col("alcnt_pcntg")).
      withColumn("cp_grs_rvn_amt", col("cp_grs_rvn_amt") * col("alcnt_pcntg")).
      withColumn("src_sys_cd", lit("PC_ADJ"))

    logger.info("++++++++++++++############ PC ADJ data added ############++++++++++++++")

    var profit_df4_final = profit_df4.drop("prft_cntr_cd", "frm_prft_cntr", "alcnt_pcntg")

    profit_df4_final = profit_df4_final.withColumnRenamed("to_prft_cntr", "prft_cntr_cd").
      withColumn("secrd_rpt_fact_ky", expr("""crc64(lower(concat(coalesce(prft_cntr_cd,""),src_sys_cd,coalesce(secrd_rpt_fact_ky,""),row_number() over (partition by prft_cntr_cd order by ins_gmt_ts))))"""))

    profit_df4_final = profit_df4_final.select(colList.head, colList.tail: _*)

    //val final_df = finalSERPDF.select(colList.head, colList.tail: _*).union(profit_df4_final)

    val profit_offset = pnpftbmtDmnsnDf.select("frm_prft_cntr").filter(col("alcnt_pcntg") =!= "0").distinct

    val profit_offset_join = finalSERPDF.alias("serp5").join(
      profit_offset.alias("profit"),
      (finalSERPDF("prft_cntr_cd") === profit_offset("frm_prft_cntr")
        && (finalSERPDF("src_sys_cd") === "SERP" || finalSERPDF("src_sys_cd").like("%EGI-INSERT%") || finalSERPDF("src_sys_cd") === "TRUE_UP")), "inner").
      select("serp5.*")

    //Step2 - For each profit centre that exist in 'BMT.From Profit Center', create a line item with Source System Code as 'OFFSET'. Set Gross Revenue and Net Revenue = -1 multiply by the values in the respective attribute where Source System = 'SERP'

    var final_offset1 = profit_offset_join.withColumn("nt_rvn_amt", -col("nt_rvn_amt")).
      withColumn("grs_rvn_amt", -col("grs_rvn_amt")).
      withColumn("cp_nt_rvn_amt", -col("cp_nt_rvn_amt")).
      withColumn("cp_grs_rvn_amt", -col("cp_grs_rvn_amt")).
      withColumn("src_sys_cd", lit("PC_OFFSET")).
      withColumn("secrd_rpt_fact_ky", expr("""crc64(lower(concat("PC_OFFSET",coalesce(secrd_rpt_fact_ky,""),row_number() over (partition by "PC_OFFSET" order by ins_gmt_ts))))"""))

    logger.info("++++++++++++++############ PC OFFSET data added ############++++++++++++++")

    final_offset1 = final_offset1.select(colList.head, colList.tail: _*)

    var finalDataLoadDF = final_offset1.union(profit_df4_final).withColumn("ins_ts", from_unixtime(unix_timestamp()))

    val tgtColumns = spark.sql(s"select * from " + tgtTblConsmtn + " limit 0").columns

    // re-arrange columns based on target table
    finalDataLoadDF = finalDataLoadDF.select(Utilities.loadSelectExpr(finalDataLoadDF.columns, tgtColumns): _*)

    finalDataLoadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(tgtTblConsmtn)

    logger.info("++++++++++++++############ Data inserted ############++++++++++++++")

    val tgtCount = spark.sql(s"select * from ${tgtTblConsmtn} where src_sys_cd like 'PC_%'").count.toInt

    tgtCount match {
      case 0 =>
        logger.error("//************* Data Load Failed")
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    } case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } finally {
    logger.info("//*********************** Log End for SERPSecuredReporting.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
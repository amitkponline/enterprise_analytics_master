package com.hpe.batch.driver.facts.balance_sheet_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
object BsrCust extends App {
 //**************************Driver properties******************************//
  
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val ins_ts=Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
  val upd_ts=null
  val ld_jb_id=ld_jb_nr+'_'+batchId
  logger.info("First log")

  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

  val transformeSrcdDF = spark.sql("""select count(*) from """ + propertiesObject.getSrcTblConsmtn() )

  val src_count = transformeSrcdDF.count().toInt
  
  var dbNameSrc = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0)
  
  logger.info("Target Database: "+dbNameConsmtn)
  
  logger.info("Source DataBase: "+dbNameSrc)  
  
import spark.implicits._
  val CurrentQuarter=propertiesObject.getCurrentQuarter()
  val PreviousQuarter=propertiesObject.getPreviousQuarter()
  val CurrentYear=propertiesObject.getCurrentYear()
  val PreviousYear=propertiesObject.getPreviousYear()
  try{
  var curr_ytd_val="(1)"
  var prev_ytd_val="(1)"
  var curr_prev_qrtr_query="select"
  var curr_prev_ytd_query="select"
  if (CurrentQuarter=="1"){
      curr_ytd_val="(0,1,2,3)"
    }
    else if(CurrentQuarter=="2"){
      curr_ytd_val="(0,1,2,3,4,5,6)"
    }
    else if(CurrentQuarter=="3"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
    }
    else if(CurrentQuarter=="4"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
    }
    if (PreviousQuarter=="1"){
      prev_ytd_val="(0,1,2,3)"
    }
    else if(PreviousQuarter=="2"){
      prev_ytd_val="(0,1,2,3,4,5,6)"
    }
    else if(PreviousQuarter=="3"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
    }
    else if(PreviousQuarter=="4"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
    }
 
  val df = spark.sql(s"""select * from ${dbNameConsmtn}.bsr_temp where driver_name not like 'Hist%' and logic not like '%ea_fin_r2_2itg.gnrl_ldgr_ln_itm_aggrt_ofset%'""")
  var fin_col_list=List[String]()
  for (i<-df.collect()){
    var curr_val=0.004
    var prev_val=0.007
    val legalcompanycode_cd_1=i.getAs[String](0)
    val group_accnt_nm_1=i.getAs[String](1)
    val thresholdtext_cd_1=i.getAs[String](2)
    val mapping_country_with_threshold_ctry_cd=i.getAs[String](3)
    val mapping_country_with_threshold_countrygroup_cd=i.getAs[String](4)
    val mapping_country_with_threshold_rgn_cd=i.getAs[String](5)
    val tr_cd_1=i.getAs[String](6)
    val thresholdvalue_cd_1=i(7)
    val thresholdpercent_cd_1=i(8)
    val driver_name_1=i.getAs[String](17)
    var d=i.getAs[String](18)
    var ytd=i.getAs[String](19)
    val b: Array[String]=d.split("from")
    val split_query=b(1)
    if (ytd=="Y"){
    curr_prev_qrtr_query="select cust_nr,sum(a.curr_val) as curr_val,sum(a.prev_val) as prev_val from (select cust_nr,(case when pstg_prd_nr in "+curr_ytd_val+" and fscl_yr_nr='"+CurrentYear+"' then sum(gbl_curr_amt) else 0.0 END) as curr_val,(case when pstg_prd_nr in "+prev_ytd_val+" and fscl_yr_nr='"+PreviousYear+"' then sum(gbl_curr_amt) else 0.0 END) as prev_val from "+split_query+" group by cust_nr, pstg_prd_nr in "+curr_ytd_val+" , fscl_yr_nr='"+CurrentYear+"' , pstg_prd_nr in "+prev_ytd_val+" , fscl_yr_nr='"+PreviousYear+"') a group by a.cust_nr"
    }
    else{
    curr_prev_qrtr_query="select cust_nr,sum(a.curr_val) as curr_val,sum(a.prev_val) as prev_val from (select cust_nr,(case when qrtr_attrbt='"+CurrentQuarter+"' and fscl_yr_nr='"+CurrentYear+"' then sum(gbl_curr_amt) else 0.0 END) as curr_val,(case when qrtr_attrbt='"+PreviousQuarter+"' and fscl_yr_nr='"+PreviousYear+"' then sum(gbl_curr_amt) else 0.0 END) as prev_val from "+split_query+" group by cust_nr, qrtr_attrbt='"+CurrentQuarter+"' , fscl_yr_nr='"+CurrentYear+"' , qrtr_attrbt='"+PreviousQuarter+"' , fscl_yr_nr='"+PreviousYear+"') a group by a.cust_nr"
    }
    val curr_amt=spark.sql(curr_prev_qrtr_query)
    for (j<-curr_amt.collect()){
      val cust_nr=j.getAs[String](0)
      curr_val=j.getAs[Double](1)
      prev_val=j.getAs[Double](2)
    val fin_value=mapping_country_with_threshold_ctry_cd+'#'+
    mapping_country_with_threshold_countrygroup_cd+'#'+
    mapping_country_with_threshold_rgn_cd+'#'+tr_cd_1+'#'+thresholdtext_cd_1+'#'+
    thresholdvalue_cd_1+'#'+thresholdpercent_cd_1+'#'+legalcompanycode_cd_1+'#'+group_accnt_nm_1+'#'+
    driver_name_1+'#'+cust_nr+'#'+CurrentQuarter+'#'+CurrentYear+'#'+curr_val+'#'+PreviousQuarter+'#'+
    PreviousYear+'#'+prev_val+'#'+upd_ts+'#'+src_sys_ky+
    '#'+ins_ts+'#'+upd_ts+'#'+upd_ts+'#'+upd_ts+'#'+upd_ts+'#'+ld_jb_id+'#'+ins_ts
    fin_col_list=fin_value::fin_col_list
    }
  }
  var fin_df=fin_col_list.toDF("ctry_cd_1")
  var fin_df_1=fin_df.withColumn("ctry_cd", split(col("ctry_cd_1"), "\\#").getItem(0))
  .withColumn("countrygroup_cd", split(col("ctry_cd_1"), "\\#").getItem(1))
  .withColumn("rgn_cd", split(col("ctry_cd_1"), "\\#").getItem(2))
  .withColumn("tr_cd", split(col("ctry_cd_1"), "\\#").getItem(3))
  .withColumn("thresholdtext_cd", split(col("ctry_cd_1"), "\\#").getItem(4))
  .withColumn("thresholdvalue_cd", split(col("ctry_cd_1"), "\\#").getItem(5))
  .withColumn("thresholdpercent_cd", split(col("ctry_cd_1"), "\\#").getItem(6))
  .withColumn("legalcompanycode_cd", split(col("ctry_cd_1"), "\\#").getItem(7))
  .withColumn("group_accnt_nm", split(col("ctry_cd_1"), "\\#").getItem(8))
  .withColumn("driver_name", split(col("ctry_cd_1"), "\\#").getItem(9))
  .withColumn("cust_nr", split(col("ctry_cd_1"), "\\#").getItem(10))
  .withColumn("curr_quarter", split(col("ctry_cd_1"), "\\#").getItem(11))
  .withColumn("curr_year", split(col("ctry_cd_1"), "\\#").getItem(12))
  .withColumn("curr_quarter_amt", split(col("ctry_cd_1"), "\\#").getItem(13))
  .withColumn("prev_quarter", split(col("ctry_cd_1"), "\\#").getItem(14))
  .withColumn("prev_year", split(col("ctry_cd_1"), "\\#").getItem(15))
  .withColumn("prev_qrtr_amt", split(col("ctry_cd_1"), "\\#").getItem(16))
  .withColumn("src_sys_upd_ts", split(col("ctry_cd_1"), "\\#").getItem(17))
  .withColumn("src_sys_ky", split(col("ctry_cd_1"), "\\#").getItem(18))
  .withColumn("ins_gmt_ts", split(col("ctry_cd_1"), "\\#").getItem(19))
  .withColumn("upd_gmt_ts", split(col("ctry_cd_1"), "\\#").getItem(20))
  .withColumn("src_sys_extrc_gmt_ts", split(col("ctry_cd_1"), "\\#").getItem(21))
  .withColumn("src_sys_btch_nr", split(col("ctry_cd_1"), "\\#").getItem(22))
  .withColumn("fl_nm", split(col("ctry_cd_1"), "\\#").getItem(23))
  .withColumn("ld_jb_nr", split(col("ctry_cd_1"), "\\#").getItem(24))
  .withColumn("ins_ts", split(col("ctry_cd_1"), "\\#").getItem(25))
  var fin_df_2=fin_df_1.drop("ctry_cd_1")
  fin_df_2.createOrReplaceTempView("balance_sheet_reporting_cust_temp")
  
  val blnce_sht_reprtg_cust_fact="blnce_sht_reprtg_cust_fact"
  
  val transformedDF = spark.sql("select * from balance_sheet_reporting_cust_temp")
  
  var loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + blnce_sht_reprtg_cust_fact, configObject)

  logger.info("Created table: blnce_sht_reprtg_cust_fact")  
  
  //val transformeSrcdDF = spark.sql("""select count(*) from """ + "ea_fin_r2_2itg.blnce_sht_reprtg_cust_fact")
  //val src_count = transformeSrcdDF.count().toInt
  //var loadStatus =src_count


    //************************Completion Audit Entries*******************************//
    val tgt_count = transformedDF.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    //auditObj.setAudObjectName("blnce_sht_reprtg_cust_fact")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(src_count)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } 
  
  catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}

package com.hpe.batch.driver.facts.rar_pivoting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import scala.io.Source
import java.util.Calendar
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window

object RvnRcgnPostingTranspose extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")

  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
  }

  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("RvnRcgnPostingTranspose")
  auditObj.setAudObjectName(propertiesObject.getObjName())
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)

  try {

    /*
     * getLatestRecs to get the latest records
     * @Param df: Data frame on which operations needs to be performed
     * @Param partition_col: List of columns required to create partition
     * @Param sortCols: column name to get the latest record for each partition
     */

    def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
      val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*).desc)
      val rowDF = df.withColumn("rn", row_number().over(part))
      val res = rowDF.filter("rn==1").drop("rn")
      res
    }

    logger.info("Initializing log for RAR POSTING TRANSPOSE, object_id : " + propertiesObject.getObjName())
    var dbNameConsmtn: String = null
    var consmptnTable: String = null
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {

      dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
      consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)

    } else {

      logger.error("Please update tgtTblConsmtn properties to add database name!")

    }

    val dbNameITG = propertiesObject.getDbName().split(",")(0).trim
    val dbNameUAT = propertiesObject.getDbName().split(",")(1).trim

    //Initiating queries to load the tables for Secured Report Allocations
    val pstgTrsnSelectDF = spark.sql(s"""
      select * 
      from 
        ${dbNameConsmtn}.rvn_rcgn_pstg_dmnsn
      where 
        (ststcs_us_cndn_ind <>'X' or ststcs_us_cndn_ind is null) 
        -- and gnrl_ldgr_acct_nr like '003%'
     """)

    val src_count = spark.sql(s"select * from ${dbNameConsmtn}.rvn_rcgn_pstg_dmnsn").count.toInt

    val pstgTrsnDeDupDF = getLatestRecs(pstgTrsnSelectDF, List("rvn_rcncltn_ky","prfm_obgn_id","gnrl_ldgr_acct_nr"), List("ins_gmt_ts"))

    val fahselectDF = spark.sql(s"select * from ${dbNameITG}.fnctl_ar_std_hrchy")

    val glselectDF = spark.sql(s"select distinct gnrl_ldgr_acct_nr,funtional_ar_cd from ${dbNameUAT}.gnrl_ldgr_acct_dmnsn")

    /*val pstgTrsnNetRevenueDF = pstgTrsnDeDupDF.as("a").join(glselectDF.as("c"), col("a.gnrl_ldgr_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").select(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("trsn_curr_amt"), col("scnd_prll_lcl_curr_amt"), col("fa_level_7"), col("fa_level_7_desc"), col("fa_level_8"), col("fa_level_8_desc"), col("fa_level_11"), col("fa_level_11_desc"), col("curr_ky")).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("curr_ky")).pivot("fa_level_7_desc").sum("trsn_curr_amt", "scnd_prll_lcl_curr_amt")*/

    val pstgTrsnNetRevenueDF = pstgTrsnDeDupDF.as("a").join(glselectDF.as("c"), col("a.gnrl_ldgr_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").select(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("trsn_curr_amt"), col("scnd_prll_lcl_curr_amt"), col("fa_level_7"), col("fa_level_7_desc"), col("fa_level_8"), col("fa_level_8_desc"), col("fa_level_11"), col("fa_level_11_desc"), col("curr_ky"), col("entrs_lgl_ent_ldgr_cd"), col("acctng_prncpl_cd"),    col("fscl_yr_nr"), col("pstg_prd_nr"),  col("lcl_curr_ky"), col("scnd_lcl_curr_curr_ky"), col("thrd_prll_lcl_curr_amt"), col("thrd_lcl_curr_curr_ky"),  col("ststcs_us_cndn_ind"), col("prfm_obgn_typ_cd"), col("rtns_itm_ind"),  col("dmy_fnctn_cd"), col("sls_dcmt_typ_cd"), col("sls_dcmt_itm_nr"), col("sls_dcmt_cd"), col("bsn_ar_cd"), col("sgmtl_rptg_sgm_cd"), col("pft_cntr_cd"), col("pftblty_sgm_nr"), col("cst_cntr_cd"), col("ord_nr"), col("sls_ord_nr"), col("sls_ord_itm_nr"), col("wbs_elmt_cd")).filter(col("fa_level_7_desc").isNotNull).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("curr_ky"), col("entrs_lgl_ent_ldgr_cd"), col("acctng_prncpl_cd"),    col("fscl_yr_nr"), col("pstg_prd_nr"),  col("lcl_curr_ky"), col("scnd_lcl_curr_curr_ky"), col("thrd_lcl_curr_curr_ky"), col("ststcs_us_cndn_ind"), col("prfm_obgn_typ_cd"),  col("dmy_fnctn_cd"), col("sls_dcmt_typ_cd"), col("sls_dcmt_itm_nr"), col("sls_dcmt_cd"), col("bsn_ar_cd"), col("sgmtl_rptg_sgm_cd"), col("pft_cntr_cd"), col("pftblty_sgm_nr"), col("cst_cntr_cd"), col("ord_nr"), col("sls_ord_nr"), col("sls_ord_itm_nr"), col("wbs_elmt_cd")).pivot("fa_level_7_desc").sum("trsn_curr_amt", "scnd_prll_lcl_curr_amt")

    val pstgTrsnNetRevenueFinalDF = pstgTrsnNetRevenueDF.columns.foldLeft(pstgTrsnNetRevenueDF) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")) }

    val pstgTrsnGrossDiscountDF = pstgTrsnDeDupDF.as("a").join(glselectDF.as("c"), col("a.gnrl_ldgr_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").select(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("trsn_curr_amt"), col("scnd_prll_lcl_curr_amt"), col("fa_level_8"), col("fa_level_8_desc"), col("fa_level_8"), col("fa_level_8_desc"), col("fa_level_11"), col("fa_level_11_desc"), col("curr_ky"), col("entrs_lgl_ent_ldgr_cd"), col("acctng_prncpl_cd"),    col("fscl_yr_nr"), col("pstg_prd_nr"),  col("lcl_curr_ky"), col("scnd_lcl_curr_curr_ky"), col("thrd_prll_lcl_curr_amt"), col("thrd_lcl_curr_curr_ky"),  col("ststcs_us_cndn_ind"), col("prfm_obgn_typ_cd"), col("rtns_itm_ind"),  col("dmy_fnctn_cd"), col("sls_dcmt_typ_cd"), col("sls_dcmt_itm_nr"), col("sls_dcmt_cd"),  col("bsn_ar_cd"), col("sgmtl_rptg_sgm_cd"), col("pft_cntr_cd"), col("pftblty_sgm_nr"), col("cst_cntr_cd"), col("ord_nr"), col("sls_ord_nr"), col("sls_ord_itm_nr"), col("wbs_elmt_cd")).filter(col("fa_level_8_desc").isNotNull).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("curr_ky"), col("entrs_lgl_ent_ldgr_cd"), col("acctng_prncpl_cd"),    col("fscl_yr_nr"), col("pstg_prd_nr"),  col("lcl_curr_ky"), col("scnd_lcl_curr_curr_ky"), col("thrd_lcl_curr_curr_ky"),  col("ststcs_us_cndn_ind"), col("prfm_obgn_typ_cd"), col("dmy_fnctn_cd"), col("sls_dcmt_typ_cd"), col("sls_dcmt_itm_nr"), col("sls_dcmt_cd"), col("bsn_ar_cd"), col("sgmtl_rptg_sgm_cd"), col("pft_cntr_cd"), col("pftblty_sgm_nr"), col("cst_cntr_cd"), col("ord_nr"), col("sls_ord_nr"), col("sls_ord_itm_nr"), col("wbs_elmt_cd")).pivot("fa_level_8_desc").sum("trsn_curr_amt", "scnd_prll_lcl_curr_amt")

    val pstgTrsnGrossDiscountFinalDF = pstgTrsnGrossDiscountDF.columns.foldLeft(pstgTrsnGrossDiscountDF) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")) }

    val pstgTrsnEstimatedStandardCostDF = pstgTrsnDeDupDF.as("a").join(glselectDF.as("c"), col("a.gnrl_ldgr_acct_nr") === col("c.gnrl_ldgr_acct_nr"), "left").join(fahselectDF.as("b"), col("c.funtional_ar_cd") === col("b.fa_level_13"), "left").select(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("trsn_curr_amt"), col("scnd_prll_lcl_curr_amt"), col("fa_level_11"), col("fa_level_11_desc"), col("fa_level_8"), col("fa_level_8_desc"), col("fa_level_11"), col("fa_level_11_desc"), col("curr_ky"), col("entrs_lgl_ent_ldgr_cd"), col("acctng_prncpl_cd"),    col("fscl_yr_nr"), col("pstg_prd_nr"),  col("lcl_curr_ky"), col("scnd_lcl_curr_curr_ky"), col("thrd_prll_lcl_curr_amt"), col("thrd_lcl_curr_curr_ky"),  col("ststcs_us_cndn_ind"), col("prfm_obgn_typ_cd"), col("rtns_itm_ind"),  col("dmy_fnctn_cd"), col("sls_dcmt_typ_cd"), col("sls_dcmt_itm_nr"), col("sls_dcmt_cd"), col("bsn_ar_cd"), col("sgmtl_rptg_sgm_cd"), col("pft_cntr_cd"), col("pftblty_sgm_nr"), col("cst_cntr_cd"), col("ord_nr"), col("sls_ord_nr"), col("sls_ord_itm_nr"), col("wbs_elmt_cd")).filter(col("fa_level_11_desc").isNotNull).groupBy(col("rvn_rcgn_cntrct_id"), col("prfm_obgn_id"), col("rvn_rcncltn_ky"), col("curr_ky"), col("entrs_lgl_ent_ldgr_cd"), col("acctng_prncpl_cd"),    col("fscl_yr_nr"), col("pstg_prd_nr"),  col("lcl_curr_ky"), col("scnd_lcl_curr_curr_ky"), col("thrd_lcl_curr_curr_ky"),  col("ststcs_us_cndn_ind"), col("prfm_obgn_typ_cd"), col("dmy_fnctn_cd"), col("sls_dcmt_typ_cd"), col("sls_dcmt_itm_nr"), col("sls_dcmt_cd"), col("bsn_ar_cd"), col("sgmtl_rptg_sgm_cd"), col("pft_cntr_cd"), col("pftblty_sgm_nr"), col("cst_cntr_cd"), col("ord_nr"), col("sls_ord_nr"), col("sls_ord_itm_nr"), col("wbs_elmt_cd")).pivot("fa_level_11_desc").sum("trsn_curr_amt", "scnd_prll_lcl_curr_amt")

    val pstgTrsnEstimatedStandardCostFianlDF = pstgTrsnEstimatedStandardCostDF.columns.foldLeft(pstgTrsnEstimatedStandardCostDF) { (newdf, colname) => newdf.withColumnRenamed(colname, colname.replace(" ", "_").replace(",", "").replace("(", "").replace(")", "")) }

    val Keys = "rvn_rcgn_cntrct_id,entrs_lgl_ent_ldgr_cd,acctng_prncpl_cd,rvn_rcncltn_ky,prfm_obgn_id,curr_ky"

    val joinKeys = Keys.split(",").toSeq

    /*var pstgTrsDF = pstgTrsnNetRevenueFinalDF.as("a").join(pstgTrsnGrossDiscountFinalDF.as("b"), col("a.rvn_rcgn_cntrct_id") === col("b.rvn_rcgn_cntrct_id") && col("a.prfm_obgn_id") === col("b.prfm_obgn_id") && col("a.rvn_rcncltn_ky") === col("b.rvn_rcncltn_ky") && col("a.curr_ky") === col("b.curr_ky")).join(pstgTrsnEstimatedStandardCostFianlDF.as("c"), col("b.rvn_rcgn_cntrct_id") === col("c.rvn_rcgn_cntrct_id") && col("b.prfm_obgn_id") === col("c.prfm_obgn_id") && col("b.rvn_rcncltn_ky") === col("c.rvn_rcncltn_ky") && col("b.curr_ky") === col("c.curr_ky"))*/

    var pstgTrsDF = pstgTrsnNetRevenueFinalDF.as("a").join(pstgTrsnGrossDiscountFinalDF.as("b"), joinKeys).join(pstgTrsnEstimatedStandardCostFianlDF.as("c"), joinKeys)

    /*val pstgTrsFinalDF = pstgTrsDF.selectExpr("concat(a.rvn_rcgn_cntrct_id,'_',a.prfm_obgn_id,'_',a.rvn_rcncltn_ky,'_',a.curr_ky)", "a.rvn_rcgn_cntrct_id", "a.prfm_obgn_id", "a.rvn_rcncltn_ky", "Interest_Income_and_Other_sumtrsn_curr_amt", "Interest_Income_and_Other_sumscnd_prll_lcl_curr_amt", "Net_Revenues_sumtrsn_curr_amt", "Net_Revenues_sumscnd_prll_lcl_curr_amt", "Total_Cost_of_Sales_sumtrsn_curr_amt", "Total_Cost_of_Sales_sumscnd_prll_lcl_curr_amt", "Cost_of_Sales_sumtrsn_curr_amt", "Cost_of_Sales_sumscnd_prll_lcl_curr_amt", "Gross_Trade_Revenues_sumtrsn_curr_amt", "Gross_Trade_Revenues_sumscnd_prll_lcl_curr_amt", "Other_Income_and_Expense_sumtrsn_curr_amt", "Other_Income_and_Expense_sumscnd_prll_lcl_curr_amt", "Trade_Discounts_sumtrsn_curr_amt", "Trade_Discounts_sumscnd_prll_lcl_curr_amt", "Contra_Revenue_sumtrsn_curr_amt", "Contra_Revenue_sumscnd_prll_lcl_curr_amt", "`Currency_Gain_&_Loss_sumtrsn_curr_amt`", "`Currency_Gain_&_Loss_sumscnd_prll_lcl_curr_amt`", "Enterprise_Standard_Cost_Total_sumtrsn_curr_amt", "Enterprise_Standard_Cost_Total_sumscnd_prll_lcl_curr_amt", "Inventory_Costs_sumtrsn_curr_amt", "Inventory_Costs_sumscnd_prll_lcl_curr_amt", "Trade_Sales_LEM_sumtrsn_curr_amt", "Trade_Sales_LEM_sumscnd_prll_lcl_curr_amt", "a.curr_ky").
    withColumn("intgtn_fbrc_msg_id", lit(null)).withColumn("src_sys_upd_ts", lit(null)).withColumn("src_sys_ky", lit(null)).withColumn("lgcl_dlt_ind",lit(null)).withColumn("ins_gmt_ts", current_timestamp()).withColumn("upd_gmt_ts", current_timestamp()).withColumn("src_sys_extrc_gmt_ts", current_timestamp()).withColumn("src_sys_btch_nr",lit(null)).withColumn("fl_nm", lit(null)).withColumn("ld_jb_nr", lit(null))*/

    val pstgTrsFinalDF = pstgTrsDF.selectExpr("concat(a.rvn_rcgn_cntrct_id,'_',a.entrs_lgl_ent_ldgr_cd,'_',a.acctng_prncpl_cd,'_',a.rvn_rcncltn_ky,'_',a.prfm_obgn_id,'_',a.rvn_rcgn_cntrct_id) as rvn_rcgn_pstg_trs_ky", "a.entrs_lgl_ent_ldgr_cd", "a.acctng_prncpl_cd", "a.rvn_rcncltn_ky", "a.prfm_obgn_id", "a.curr_ky", "a.fscl_yr_nr", "a.pstg_prd_nr", "a.lcl_curr_ky", "a.scnd_lcl_curr_curr_ky","a.thrd_lcl_curr_curr_ky", "a.rvn_rcgn_cntrct_id","a.ststcs_us_cndn_ind", "a.prfm_obgn_typ_cd", "a.dmy_fnctn_cd", "a.sls_dcmt_typ_cd", "a.sls_dcmt_itm_nr", "a.sls_dcmt_cd", "a.bsn_ar_cd", "a.sgmtl_rptg_sgm_cd", "a.pft_cntr_cd", "a.pftblty_sgm_nr", "a.cst_cntr_cd", "a.ord_nr", "a.sls_ord_nr", "a.sls_ord_itm_nr", "a.wbs_elmt_cd", "null as utc_ts", "Interest_Income_and_Other_sumtrsn_curr_amt", "Interest_Income_and_Other_sumscnd_prll_lcl_curr_amt", "Net_Revenues_sumtrsn_curr_amt", "Net_Revenues_sumscnd_prll_lcl_curr_amt", "Total_Cost_of_Sales_sumtrsn_curr_amt", "Total_Cost_of_Sales_sumscnd_prll_lcl_curr_amt", "Cost_of_Sales_sumtrsn_curr_amt", "Cost_of_Sales_sumscnd_prll_lcl_curr_amt", "Gross_Trade_Revenues_sumtrsn_curr_amt", "Gross_Trade_Revenues_sumscnd_prll_lcl_curr_amt", "Other_Income_and_Expense_sumtrsn_curr_amt", "Other_Income_and_Expense_sumscnd_prll_lcl_curr_amt", "Trade_Discounts_sumtrsn_curr_amt", "Trade_Discounts_sumscnd_prll_lcl_curr_amt", "Contra_Revenue_sumtrsn_curr_amt", "Contra_Revenue_sumscnd_prll_lcl_curr_amt", "`Currency_Gain_&_Loss_sumtrsn_curr_amt` as Currency_Gain_and_Loss_sumtrsn_curr_amt", "`Currency_Gain_&_Loss_sumscnd_prll_lcl_curr_amt` as Currency_Gain_and_Loss_sumscnd_prll_lcl_curr_amt", "Enterprise_Standard_Cost_Total_sumtrsn_curr_amt", "Enterprise_Standard_Cost_Total_sumscnd_prll_lcl_curr_amt", "Inventory_Costs_sumtrsn_curr_amt", "Inventory_Costs_sumscnd_prll_lcl_curr_amt", "Trade_Sales_LEM_sumtrsn_curr_amt", "Trade_Sales_LEM_sumscnd_prll_lcl_curr_amt").withColumn("intgtn_fbrc_msg_id", lit(null)).withColumn("src_sys_upd_ts", lit(null)).withColumn("src_sys_ky", lit(null)).withColumn("lgcl_dlt_ind", lit(null)).withColumn("ins_gmt_ts", current_timestamp()).withColumn("upd_gmt_ts", current_timestamp()).withColumn("src_sys_extrc_gmt_ts", current_timestamp()).withColumn("src_sys_btch_nr", lit(null)).withColumn("fl_nm", lit(null)).withColumn("ld_jb_nr", lit(null))

    val tgtColumns = spark.sql(s"select * from ${dbNameConsmtn}.rvn_rcgn_pstg_pvt_dmnsn").columns
    
    
    val transformedDF = tgtColumns.foldLeft(pstgTrsFinalDF)((pstgTrsFinalDF, c) =>
    pstgTrsFinalDF.withColumnRenamed(c.toString.split(",")(0), c.toString.toLowerCase()))

    
    val finalDataLoadDF = transformedDF.select(Utilities.loadSelectExpr(transformedDF.columns, tgtColumns): _*)
        
    finalDataLoadDF.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn+".rvn_rcgn_pstg_pvt_dmnsn")

    val tgt_count = spark.sql(s"select * from ${dbNameConsmtn}.rvn_rcgn_pstg_pvt_dmnsn").count.toInt

    if (tgt_count <= 0) {
      logger.error("No records to process !")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

    } else {
      logger.info("CDC process completed !")
      auditObj.setAudJobStatusCode("success")
      auditObj.setAudSrcRowCount(src_count)
      auditObj.setAudTgtRowCount(tgt_count)
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } finally {
    sqlCon.close()
    spark.close()
  }
}
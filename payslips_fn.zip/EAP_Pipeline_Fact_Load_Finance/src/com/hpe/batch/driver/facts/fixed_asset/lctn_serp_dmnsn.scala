package com.hpe.batch.driver.facts.fixed_asset

import java.net.ConnectException

import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException

import main.scala.com.hpe.config.AuditLoadObject
import main.scala.com.hpe.config.ConfigObject
import main.scala.com.hpe.config.EnvPropertiesObject
import main.scala.com.hpe.config.SKeyObject
import main.scala.com.hpe.config.SetUpConfiguration
import main.scala.com.hpe.config.StreamingPropertiesObject
import main.scala.com.hpe.utils.Utilities

object lctn_serp_dmnsn extends App {

  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")

  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
    spark.close()
    System.exit(1)
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var srcCount = 0
  var tgtCount = 0
  var jobStatusFlag = true

  //***************************Audit Properties********************************//

  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val fileBasePath = propertiesObject.getFileBasePath()

  //************************Set Audit Entries*******************************//

  auditObj.setAudDataLayerName("ref_cnsmptn")
  auditObj.setAudApplicationName("job_EA_loadConsumption")
  auditObj.setAudObjectName(propertiesObject.getObjName())
  auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
  auditObj.setAudErrorRecords(0)
  auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
  auditObj.setFlNm("")
  auditObj.setSysBtchNr(ld_jb_nr)
  auditObj.setAudSrcRowCount(srcCount)
  auditObj.setAudTgtRowCount(tgtCount)

  try {

    var ref_btch_id = Utilities.readRefBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)
    var cnsmptn_btch_id = Utilities.readCnsmptnBatchId(sqlCon, propertiesObject.getObjName(), auditTbl)

    logger.info("ref_btch_id :- " + ref_btch_id + " cnsmptn_btch_id :- " + cnsmptn_btch_id)

    logger.info("Initializing log for LOCATION SERP DIMENSION, object_id : " + propertiesObject.getObjName())
    auditObj.setAudBatchId(ref_btch_id)

    val consmptnTable = new StringBuilder()
    val dbNameConsmtn = new StringBuilder()
    val srcTable = new StringBuilder()

    if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
      dbNameConsmtn.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0))
      consmptnTable.append(propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1))
      srcTable.append(propertiesObject.getSrcTblConsmtn().trim())
    } else {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      sqlCon.close()
      System.exit(1)
    }

    /* *************************************** Selecting source count ****************************** */
    var ins_gmt_date = ""

    if (cnsmptn_btch_id == "1900-01-01 00:00:00") {
      ins_gmt_date = cnsmptn_btch_id.substring(0, 4) + "-" + cnsmptn_btch_id.substring(5, 7) + "-" + cnsmptn_btch_id.substring(8, 10)
    } else {
      ins_gmt_date = cnsmptn_btch_id.substring(19, 23) + "-" + cnsmptn_btch_id.substring(23, 25) + "-" + cnsmptn_btch_id.substring(25, 27)
    }

    srcCount = spark.sql(s"""select count(*) from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""").first().getLong(0).toInt
    logger.info(s"""select count(*) from ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""")
    logger.info("source count: " + srcCount)
    var tgtTbl = consmptnTable

    /* ****************** Checking if source count is greater than zero or not ********************* */
    if (srcCount > 0) {
      auditObj.setAudSrcRowCount(srcCount)
      
      spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'com.hpe.batch.hive.udfs.CRC64'""")

      /* ****************************** Creating data frame for final with final data set *********************************** */
      val stg_df = spark.sql(s"""SELECT  plnt ,lctn ,txt ,addr_nr ,intgtn_fbrc_msg_id ,src_sys_upd_ts ,src_sys_ky ,lgcl_dlt_ind ,ins_gmt_ts ,upd_gmt_ts ,src_sys_extrc_gmt_ts ,src_sys_btch_nr ,fl_nm ,ld_jb_nr FROM ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""")

      logger.info(s"""SELECT  plnt ,lctn ,txt ,addr_nr ,intgtn_fbrc_msg_id ,src_sys_upd_ts ,src_sys_ky ,lgcl_dlt_ind ,ins_gmt_ts ,upd_gmt_ts ,src_sys_extrc_gmt_ts ,src_sys_btch_nr ,fl_nm ,ld_jb_nr FROM ${srcTable} where date_sub(ins_gmt_dt,-1)>='${ins_gmt_date}' and ld_jb_nr > '${cnsmptn_btch_id}'""")

      /* *********************************Inserting latest data ******************************************* */
      stg_df.repartition(10).write.mode("overwrite").format("orc").insertInto(dbNameConsmtn + "." + tgtTbl)

      /* ************************ selecting target count ****************************************** */
      tgtCount = spark.sql(s"""select count(*) from ${dbNameConsmtn}.${tgtTbl}""").first().getLong(0).toInt
      logger.info(s"""select count(*) from ${dbNameConsmtn}.${tgtTbl}""")
      logger.info("target count: " + tgtCount)

      logger.info("+++++++++++############# Load Successful #############+++++++++++")
      auditObj.setAudTgtRowCount(tgtCount)
      auditObj.setAudJobStatusCode("success")
    } else {
      logger.error("+++++++++++############# No records in source to process #############+++++++++++")
      auditObj.setAudJobStatusCode("failed")
    }

    /* ********************************************* Completion audit entries ************************** */

    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      jobStatusFlag = false
    }

  } finally {
    sqlCon.close()
    spark.close()
    if (!jobStatusFlag) {
      System.exit(1)
    }

  }
}

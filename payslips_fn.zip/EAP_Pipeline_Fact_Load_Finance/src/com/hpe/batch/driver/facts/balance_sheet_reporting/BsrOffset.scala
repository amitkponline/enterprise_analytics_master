package com.hpe.batch.driver.facts.balance_sheet_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
//import main.scala.com.hpe.consumption.processor._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }

import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
object BsrOffset extends App {
 //**************************Driver properties******************************//
  
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)

  //***************************Audit Properties********************************//
  val logger = Logger.getLogger(getClass.getName)
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val ins_ts=Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS")
  val upd_ts=null
  val ld_jb_id=ld_jb_nr+'_'+batchId
  logger.info("First log")
  
  var dbNameConsmtn: String = null
  var consmptnTable: String = null
  if (propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1).size == 2) {
    dbNameConsmtn = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(0)
    consmptnTable = propertiesObject.getTgtTblConsmtn().trim().split("\\.", -1)(1)
  } else {
    logger.error("Please update tgtTblConsmtn properties to add database name!")
    sqlCon.close()
    System.exit(1)
  }

  val consumptionEntryFlag = Utilities.consumptionEntry(sqlCon, propertiesObject.getObjName())

  val transformeSrcdDF = spark.sql("""select count(*) from """ + propertiesObject.getSrcTblConsmtn() )

  val src_count = transformeSrcdDF.count().toInt
  
  var dbNameSrc = propertiesObject.getSrcTblConsmtn().trim().split("\\.", -1)(0)
  
  logger.info("Target Database: "+dbNameConsmtn)
  
  logger.info("Source DataBase: "+dbNameSrc)    

import spark.implicits._
  val CurrentQuarter=propertiesObject.getCurrentQuarter()
  val PreviousQuarter=propertiesObject.getPreviousQuarter()
  val CurrentYear=propertiesObject.getCurrentYear()
  val PreviousYear=propertiesObject.getPreviousYear()
  try{
  var curr_ytd_val="(1)"
  var prev_ytd_val="(1)"
  var curr_period="(1)"
  var prev_period="(1)"
  var curr_prev_qrtr_query="select"
  var curr_prev_ytd_query="select"
  //var loadStatus =0
  if (CurrentQuarter=="1"){
      curr_ytd_val="(0,1,2,3)"
      curr_period="(1,2,3)"
    }
    else if(CurrentQuarter=="2"){
      curr_ytd_val="(0,1,2,3,4,5,6)"
      curr_period="(4,5,6)"
    }
    else if(CurrentQuarter=="3"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
      curr_period="(7,8,9)"
    }
    else if(CurrentQuarter=="4"){
      curr_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
      curr_period="(10,11,12)"
    }
    if (PreviousQuarter=="1"){
      prev_ytd_val="(0,1,2,3)"
      prev_period="(1,2,3)"
    }
    else if(PreviousQuarter=="2"){
      prev_ytd_val="(0,1,2,3,4,5,6)"
      prev_period="(4,5,6)"
    }
    else if(PreviousQuarter=="3"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9)"
      prev_period="(7,8,9)"
    }
    else if(PreviousQuarter=="4"){
      prev_ytd_val="(0,1,2,3,4,5,6,7,8,9,10,11,12)"
      prev_period="(10,11,12)"
    }

//creating separate offset table ea_fin_r2_2itg.blnce_sht_reprtg_offset_fact
 
//spark.sql("drop table if exists ea_fin_r2_2itg.GL_Line_item_aggrt")

val GL_Line_item_aggrt = "GL_Line_item_aggrt"    
    
val transformedDF =  spark.sql(s"""
  -- create table ea_fin_r2_2itg.GL_Line_item_aggrt as 
select entrs_lgl_ent_ldgr_cd, acct_nr, grp_acct_nr, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt, sum(gbl_curr_amt) as gbl_curr_amt  
from """+dbNameConsmtn + "." +"""gnrl_ldgr_ln_itm_acct_number2 where gnrl_ldgr_acctng_cd='0L' 
and fscl_yr_nr in('"""+CurrentYear+"""','"""+PreviousYear+"""') and case when fscl_yr_nr ='"""+PreviousYear+"""' then 
pstg_prd_nr in """+prev_period+""" when fscl_yr_nr='"""+CurrentYear+"""' then pstg_prd_nr in """+curr_period+""" else Null END 
group by 
entrs_lgl_ent_ldgr_cd, acct_nr, grp_acct_nr, acctng_dcmt_id, fscl_yr_nr, pstg_prd_nr, qrtr_attrbt
  """)
  
var loadStatus = Utilities.storeDataFrame(transformedDF, "overwrite", "ORC", dbNameConsmtn + "." + GL_Line_item_aggrt, configObject)

transformedDF.cache()

logger.info("Created table: GL_Line_item_aggrt")  
    
    
//spark.sql("drop table if exists ea_fin_r2_2itg.GLI_aggrt_ofst")

val GLI_aggrt_ofst = "GLI_aggrt_ofst"

val transformedDF2 = spark.sql(s"""
--  create table ea_fin_r2_2itg.GLI_aggrt_ofst as 
select 
a.entrs_lgl_ent_ldgr_cd, a.acct_nr, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt,
b.acct_nr as ofst_acct_nr_calc,
b.grp_acct_nr as ofst_grp_acct_nr_calc,
sum(b.gbl_curr_amt) as ofset_gbl_curr_amt
from """+dbNameConsmtn + "." +"""GL_Line_item_aggrt a, """+dbNameConsmtn + "." +"""GL_Line_item_aggrt b 
where a.acctng_dcmt_id= b.acctng_dcmt_id and a.acct_nr != b.acct_nr and a.fscl_yr_nr=b.fscl_yr_nr and a.entrs_lgl_ent_ldgr_cd = b.entrs_lgl_ent_ldgr_cd  
group by 
a.entrs_lgl_ent_ldgr_cd, a.acct_nr, a.grp_acct_nr, a.fscl_yr_nr, a.pstg_prd_nr, a.qrtr_attrbt, b.acct_nr, b.grp_acct_nr
  """)
  
loadStatus = Utilities.storeDataFrame(transformedDF2, "overwrite", "ORC", dbNameConsmtn + "." + GLI_aggrt_ofst, configObject)

logger.info("Created table: GLI_aggrt_ofst")  
  
//spark.sql("drop table if exists ea_fin_r2_2itg.blnce_sht_reprtg_offset_fact")

val blnce_sht_reprtg_offset_fact = "blnce_sht_reprtg_offset_fact"

val transformedDF3 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.blnce_sht_reprtg_offset_fact as 
select 
b.ctry_cd, b.countrygroup_cd, b.rgn_cd, b.tr_cd, b.thresholdtext_cd, b.thresholdvalue_cd, b.thresholdpercent_cd,
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr, a.acct_nr, a.ofst_acct_nr_calc as ofst_acct, a.ofst_grp_acct_nr_calc as ofst_grp_acct,
case when a.qrtr_attrbt = """+CurrentQuarter+""" then qrtr_attrbt else null end as curr_quarter,
case when a.fscl_yr_nr = """+CurrentYear+""" then fscl_yr_nr else null end as curr_year, 
case when a.fscl_yr_nr = """+CurrentYear+""" and a.pstg_prd_nr in """+curr_period+""" then round(sum(a.ofset_gbl_curr_amt),2) else 0 end as curr_quarter_amt,
case when a.qrtr_attrbt = """+PreviousQuarter+""" then qrtr_attrbt else null end as prev_quarter,
case when a.fscl_yr_nr = """+PreviousYear+""" then fscl_yr_nr else null end as prev_year,
case when a.fscl_yr_nr = """+PreviousYear+""" and a.pstg_prd_nr in """+prev_period+""" then round(sum(a.ofset_gbl_curr_amt),2) else 0 end as prev_qrtr_amt
from """+dbNameConsmtn + "." +"""GLI_aggrt_ofst a inner join """+dbNameConsmtn + "." +"""bsr_threshold_output_fact b on  
a.entrs_lgl_ent_ldgr_cd = b.legalcompanycode_cd and a.grp_acct_nr = b.grp_acct_nr 
group by 
b.ctry_cd,
b.countrygroup_cd, 
b.rgn_cd,
b.tr_cd,
b.thresholdtext_cd, 
b.thresholdvalue_cd,
b.thresholdpercent_cd,
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr, a.acct_nr, a.ofst_grp_acct_nr_calc, a.ofst_acct_nr_calc, a.fscl_yr_nr, a.qrtr_attrbt, a.pstg_prd_nr
  """)

loadStatus = Utilities.storeDataFrame(transformedDF3, "overwrite", "ORC", dbNameConsmtn + "." + blnce_sht_reprtg_offset_fact, configObject)

logger.info("Created table: blnce_sht_reprtg_offset_fact")    
  
//union both driver table and offset table 
  
//spark.sql("drop table if exists ea_fin_r2_2itg.GLI_drv_ofst_aggrt")

val GLI_drv_ofst_aggrt = "GLI_drv_ofst_aggrt"

val transformedDF4 = spark.sql(s"""
--  create table ea_fin_r2_2itg.GLI_drv_ofst_aggrt as 
select 
b.ctry_cd, b.countrygroup_cd, b.rgn_cd, b.tr_cd, b.thresholdtext_cd, b.thresholdvalue_cd, b.thresholdpercent_cd,
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr,
case when c.grp_acc_desc is null then substr(a.ofst_grp_acct_nr_calc, 7,10) else case when a.ofst_grp_acct_nr_calc < '0000001100' then c.grp_acc_desc else concat( c.grp_acc_desc , " - ", substr(a.ofst_grp_acct_nr_calc, 7,10)) end end as driver_name, a.acct_nr,
case when a.qrtr_attrbt = """+CurrentQuarter+""" then qrtr_attrbt else null end as curr_quarter,
case when a.fscl_yr_nr = """+CurrentYear+""" then fscl_yr_nr else null end as curr_year, 
case when a.fscl_yr_nr = """+CurrentYear+""" and a.pstg_prd_nr in """+curr_period+""" then round(sum(a.ofset_gbl_curr_amt),2) else 0 end as curr_quarter_amt,
case when a.qrtr_attrbt = """+PreviousQuarter+""" then qrtr_attrbt else null end as prev_quarter,
case when a.fscl_yr_nr = """+PreviousYear+""" then fscl_yr_nr else null end as prev_year,
case when a.fscl_yr_nr = """+PreviousYear+""" and a.pstg_prd_nr in """+prev_period+""" then round(sum(a.ofset_gbl_curr_amt),2) else 0 end as prev_qrtr_amt
from """+dbNameConsmtn + "." +"""GLI_aggrt_ofst a inner join """+dbNameConsmtn + "." +"""bsr_threshold_output_fact b on  
a.entrs_lgl_ent_ldgr_cd = b.legalcompanycode_cd and a.grp_acct_nr = b.grp_acct_nr 
left join """+dbNameConsmtn + "." +"""grp_acc_tbl c on a.ofst_grp_acct_nr_calc = c.grp_acc_id
group by 
b.ctry_cd,
b.countrygroup_cd, 
b.rgn_cd,
b.tr_cd,
b.thresholdtext_cd, 
b.thresholdvalue_cd,
b.thresholdpercent_cd,
a.entrs_lgl_ent_ldgr_cd, a.grp_acct_nr, a.ofst_grp_acct_nr_calc, a.acct_nr,  a.fscl_yr_nr, a.qrtr_attrbt, a.pstg_prd_nr, c.grp_acc_desc
  """)
  
loadStatus = Utilities.storeDataFrame(transformedDF4, "overwrite", "ORC", dbNameConsmtn + "." + GLI_drv_ofst_aggrt, configObject)

logger.info("Created table: GLI_drv_ofst_aggrt")    
    
//spark.sql("drop table if exists ea_fin_r2_2itg.blnce_sht_reprtg_final_driver_fact")


val transformedDF5 = spark.sql(s"""
 -- create table ea_fin_r2_2itg.blnce_sht_reprtg_final_driver_fact as 
 select ctry_cd,
countrygroup_cd,
rgn_cd,
tr_cd,
thresholdtext_cd,
thresholdvalue_cd,
thresholdpercent_cd,
entrs_lgl_ent_ldgr_cd,
grp_acct_nr,
driver_name,
acct_nr,
curr_quarter,
curr_year,
curr_quarter_amt,
prev_quarter,
prev_year,
prev_qrtr_amt,
NULL as src_sys_upd_ts,
NULL as src_sys_ky,
NULL as ins_gmt_ts,
NULL as upd_gmt_ts,
NULL as src_sys_extrc_gmt_ts,
NULL as src_sys_btch_nr,
NULL as fl_nm,
NULL as ld_jb_nr,
NULL as ins_ts from """+dbNameConsmtn + "." +"""gli_drv_ofst_aggrt
union
select ctry_cd,
countrygroup_cd,
rgn_cd,
tr_cd,
thresholdtext_cd,
thresholdvalue_cd,
thresholdpercent_cd,
legalcompanycode_cd,
group_accnt_nm,
driver_name,
acct_nr,
cast(curr_quarter as string),
curr_year,
curr_quarter_amt,
cast(prev_quarter as string),
prev_year,
prev_qrtr_amt,
src_sys_upd_ts,
src_sys_ky,
ins_gmt_ts,
upd_gmt_ts,
src_sys_extrc_gmt_ts,
src_sys_btch_nr,
fl_nm,
ld_jb_nr,
ins_ts from """+dbNameConsmtn + "." +"""blnce_sht_reprtg_driver_fact
  """)

loadStatus = Utilities.storeDataFrame(transformedDF5, "overwrite", "ORC", dbNameConsmtn + "." + consmptnTable, configObject)

logger.info("Created table: blnce_sht_reprtg_final_driver_fact")  

    //************************Completion Audit Entries*******************************//

val tgt_count = transformedDF5.count().toInt

    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_EA_loadConsumption")
    //auditObj.setAudObjectName("blnce_sht_reprtg_driver_fact")
    auditObj.setAudObjectName(propertiesObject.getObjName())
    auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    if (loadStatus) {
      auditObj.setAudJobStatusCode("success")
    } else {
      auditObj.setAudJobStatusCode("failed")
    }
    auditObj.setAudSrcRowCount(0)
    auditObj.setAudTgtRowCount(tgt_count)
    auditObj.setAudErrorRecords(0)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)
    auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
    Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

  } 
  
  catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
      sqlCon.close()
      System.exit(1)
    }
  }
  spark.close()
  sqlCon.close()
  
}

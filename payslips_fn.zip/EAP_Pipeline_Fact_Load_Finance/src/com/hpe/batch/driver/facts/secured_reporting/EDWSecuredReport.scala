package com.hpe.batch.driver.facts.secured_reporting

import main.scala.com.hpe.config._
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global
import main.scala.com.hpe.utils.{ Utilities, _ }
import org.apache.spark.sql.functions._
import org.apache.log4j.Logger
import main.scala.com.hpe.config._
import org.apache.spark.sql.SparkSession
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.apache.spark.sql.functions._
import scala.collection.Seq
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger
import java.net.ConnectException
import java.util.HashMap
import java.util.Calendar
import scala.io.Source
import org.apache.spark.storage.StorageLevel._

object EDWSecuredReport extends App {
  val configObject: ConfigObject = SetUpConfiguration.setup(0L, "")
  val spark = configObject.spark
  val logger = Logger.getLogger(getClass.getName)

  val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
  if (args == null || args.isEmpty) {
    logger.error("Invalid number of arguments passed., Arguments Usage: <Properties file path> <Batch Id - yyyyMMddHHmmss>")
  }
  val propertiesFilePath = String.valueOf(args(0).trim())
  val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
  val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"

  val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
  val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
  val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)
  val auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()
  val sqlCon = Utilities.getConnection(envPropertiesObject)
  var jobStatusFlag = true
  var fileBasePath = propertiesObject.getFileBasePath()
  val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
  val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
  val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
  val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
  val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
  val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)
  val batchId = Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
  val srcTableName = propertiesObject.getSrcTblConsmtn().trim()
  val tgtTblConsmtn = propertiesObject.getTgtTblConsmtn().trim()
  val dbName = propertiesObject.getDbName().trim()
  val objName = propertiesObject.getObjName()

  logger.info("//*********************** Log Start for EDWSecuredReport.scala ************************//")
  auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))

  try {

    Utilities.paramCheck(Seq(ld_jb_nr, batchId, tgtTblConsmtn, fileBasePath, dbName))

    //***************************Audit Properties********************************//
    auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
    auditObj.setAudDataLayerName("ref_cnsmptn")
    auditObj.setAudApplicationName("job_secrd_edw_fact_load")
    auditObj.setAudObjectName(objName)
    auditObj.setAudCreatedBy(configObject.getSsc().sparkContext.sparkUser)
    auditObj.setFlNm("")
    auditObj.setSysBtchNr(ld_jb_nr)

    if (tgtTblConsmtn.split("\\.", -1).size != 2) {
      logger.error("Please update tgtTblConsmtn properties to add database name!")
      throw new IllegalArgumentException("Please update tgtTblConsmtn properties to add database name!")
    }

    /*    if (dbName.split(",", -1).size != 3) {
      logger.error("Please update common dbName properties to add database name!")
      throw new IllegalArgumentException("Please update dbName properties to add database name!")
    }*/

    val dbCommonR2_2 = dbName.split(",")(0)
    val dbCommonUAT = dbName.split(",")(1)
    val dbCommonR2_3 = dbName.split(",")(2)
    val dbCommonR2_3UAT = dbName.split(",")(3)
    val dbTemp = dbName.split(",")(4)

    val srcCount = spark.sql(s"select * from ${srcTableName}").count.toInt

    val tgtColumns = spark.sql("select * from " + tgtTblConsmtn + " limit 0").columns

    // fiscal year period calculation

    val cal = Calendar.getInstance()
    val Year = cal.get(Calendar.YEAR)
    val Month1 = cal.get(Calendar.MONTH)
    var Month = Month1 + 1
    val prev_year = Year - 1
    val prev_year_str = prev_year.toString()
    val year1 = Year + 1
    var Month_val = Month.toString()
    var year_val = Year.toString()
    var next_year = year1.toString()

    var fscl_yr_prd = ""

    if ((Month_val == "11") || (Month_val == "12")) {
      if (Month_val == "11") {
        fscl_yr_prd = year_val + "4"
      } else {
        fscl_yr_prd = next_year + "1"
      } //year+Q
    } else if (Month_val == "1") { fscl_yr_prd = year_val + "1" }

    else if ((Month_val == "2") || (Month_val == "3") || (Month_val == "4")) {
      if (Month_val == "2") {
        fscl_yr_prd = year_val + "1"
      } else {
        fscl_yr_prd = year_val + "2"
      }
    } else if ((Month_val == "5") || (Month_val == "6") || (Month_val == "7")) {
      if (Month_val == "5") {
        fscl_yr_prd = year_val + "2"
      } else {
        fscl_yr_prd = year_val + "3"
      }
    } else if ((Month_val == "8") || (Month_val == "9") || (Month_val == "10")) {
      if (Month_val == "8") {
        fscl_yr_prd = year_val + "3"
      } else {
        fscl_yr_prd = year_val + "4"
      }
    }
    val fscl_yr_prd_con = fscl_yr_prd.toInt // due unavailability of data currently, 20194 considered

    //val fscl_yr_prd_con = "20194"

    spark.sql("""CREATE TEMPORARY FUNCTION crc64 AS 'main.scala.com.hpe.utils.CRC64'""")

    logger.info("//*********************** fiscal year period value: " + fscl_yr_prd_con)

    val srcDF = spark.sql(s"""
SELECT distinct 
	crc32(LOWER(CONCAT(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.so_id, ""), COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.so_ln_itm_id, "")))) AS secrd_rpt_fact_ky,
	crc32(LOWER(COALESCE(s4_bp_end_cust_id, "")) )AS mdm_cust_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.prod_id, ""))) AS pdm_mtrl_mstr_grp_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.s4_prft_ctr_cd, ""))) AS pft_cntr_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.s4_seg_cd, ""))) AS mgmt_grphy_unt_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.func_area_cd, ""))) AS fnctl_ar_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.sldt_cust_id, ""))) AS sld_to_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.shpt_cust_id, ""))) AS shp_to_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.bilt_cust_id, ""))) AS bll_to_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.gl_grp_acct_id, ""))) AS gl_acct_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.drvd_deal_id, ""))) AS deal_ky,
	crc32(LOWER(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.so_id, ""))) AS ord_hddr_ky,
	crc32(LOWER(concat(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.so_id, ""), COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.so_ln_itm_id, "")))) AS ord_itm_ky,
	ords_secrd_nn_secrd_psn_edw_dmnsn.so_ln_itm_id AS sls_ord_ln_itm_id,
	case when ords_secrd_nn_secrd_psn_edw_dmnsn.so_id = '?' then null else ords_secrd_nn_secrd_psn_edw_dmnsn.so_id end AS sls_ord_id,
	ords_secrd_nn_secrd_psn_edw_dmnsn.drvd_deal_id AS deal_id,
	ords_secrd_nn_secrd_psn_edw_dmnsn.so_type_cd AS ord_typ_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.prod_id AS mtrl_nr,
	split(ords_secrd_nn_secrd_psn_edw_dmnsn.prod_id,'#')[0] as prod_base_id,
	concat('EDW','_',SO_SRC_SYS_KY) AS src_sys_cd,
	from_unixtime(unix_timestamp(ords_secrd_nn_secrd_psn_edw_dmnsn.ord_crt_dt,'yyyy/MM/dd'),'yyyy-MM-dd') AS ord_crt_dt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.legl_co_cd AS sls_orgn_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.cust_po_id AS cust_po_nr,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sldt_cust_id AS sld_to_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.shpt_cust_id AS shp_to_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.end_cust_id AS end_cust_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.bilt_cust_id AS bll_to_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_unit_qt AS ord_itm_qty,
	ords_secrd_nn_secrd_psn_edw_dmnsn.net_dealer_prc_usd_am,
	ords_secrd_nn_secrd_psn_edw_dmnsn.doc_crncy_cd AS ord_itm_dcmt_curr_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.net_dealer_prc_usd_am AS nt_prc_usd_amt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_net_usd_am_ord_itm_nt_vl AS ord_itm_nt_vl_usd_amt,
	from_unixtime(unix_timestamp(ords_secrd_nn_secrd_psn_edw_dmnsn.ord_itm_crt_dt,
	'yyyy/MM/dd'),
	'yyyy-MM-dd') AS ord_itm_crt_dt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.s4_prft_ctr_cd AS prft_cntr_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.s4_seg_cd AS sgmtl_rptg_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.so_stat_cd AS zord_header_sys_stts_ln_nm,
	ords_secrd_nn_secrd_psn_edw_dmnsn.so_dtl_stat_cd AS zord_item_sys_stts_ln_nm,
	CAST(ords_secrd_nn_secrd_psn_edw_dmnsn.ship_id AS VARCHAR(10)) AS shpmt_id,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sch_ship_dt AS plnd_shp_end_dt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.bill_doc_id AS invc_id,
	ords_secrd_nn_secrd_psn_edw_dmnsn.bill_doc_ln_itm_id AS invc_ln_itm_id,
	from_unixtime(unix_timestamp(ords_secrd_nn_secrd_psn_edw_dmnsn.bill_doc_dt,
	'yyyy/MM/dd'),
	'yyyy-MM-dd') AS actl_inv_dt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_qt AS base_qty,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_unit_qt AS unt_qty,
	CAST(ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_net_usd_am AS VARCHAR(18)) AS nt_inv_vl_amt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_net_usd_am_nt_inv_vl AS cp_net_inv_usd_amt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_grs_usd_am AS cp_grs_inv_usd_amt,
	CASE
		WHEN ords_secrd_nn_secrd_psn_edw_dmnsn.cust_po_id like '%ICOEM%' then 'Y'
		ELSE 'N'
  END AS icoem_ind,
	ords_secrd_nn_secrd_psn_edw_dmnsn.gl_grp_acct_id AS grp_acct_id,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_net_usd_am AS estmd_rvn_amt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_net_usd_am_totl_rvn_amt AS ttl_rvn_amt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_net_usd_am AS ttl_rvn_usd_amt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.func_area_cd AS ptnr_fnctl_ar_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_net_usd_am_nt_inv_vl AS cp_nt_rvn_usd_amt,
	CURRENT_TIMESTAMP AS ins_ts,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sldt_cust_id AS cp_sldt_prty_id,
	ords_secrd_nn_secrd_psn_edw_dmnsn.shpt_cust_id AS cp_shpt_prty_id,
	ords_secrd_nn_secrd_psn_edw_dmnsn.s4_prft_ctr_cd AS cp_prft_ctr_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.s4_seg_cd AS cp_segment_cd,
	ords_secrd_nn_secrd_psn_edw_dmnsn.net_dealer_prc_usd_am AS cp_ndp_usd_amt,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_grs_usd_am AS cp_grs_usd_amt,
	CAST(ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_unit_qt AS DOUBLE) AS cp_unit_qty,
	ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_qt AS cp_base_qty,
	ords_secrd_nn_secrd_psn_edw_dmnsn.src_sys_upd_ts AS src_sys_upd_ts,
	ords_secrd_nn_secrd_psn_edw_dmnsn.src_sys_ky AS src_sys_ky,
	ords_secrd_nn_secrd_psn_edw_dmnsn.lgcl_dlt_ind AS lgcl_dlt_ind,
	ords_secrd_nn_secrd_psn_edw_dmnsn.ins_gmt_ts AS ins_gmt_ts,
	ords_secrd_nn_secrd_psn_edw_dmnsn.upd_gmt_ts AS upd_gmt_ts,
	ords_secrd_nn_secrd_psn_edw_dmnsn.src_sys_extrc_gmt_ts AS src_sys_extrc_gmt_ts,
	ords_secrd_nn_secrd_psn_edw_dmnsn.src_sys_btch_nr AS src_sys_btch_nr,
	ords_secrd_nn_secrd_psn_edw_dmnsn.fl_nm AS fl_nm,
	ords_secrd_nn_secrd_psn_edw_dmnsn.ld_jb_nr AS ld_jb_nr,
  CONCAT (substring(clndr_rpt.fisc_yr_mth_cd,1,4),
	CASE
		WHEN substring(clndr_rpt.fisc_yr_mth_cd,5,2) IN ('01','02','03') THEN '1'
		WHEN substring(clndr_rpt.fisc_yr_mth_cd,5,2) IN ('04','05','06') THEN '2'
		WHEN substring(clndr_rpt.fisc_yr_mth_cd,5,2) IN ('07','08','09') THEN '3'
		WHEN substring(clndr_rpt.fisc_yr_mth_cd,5,2) IN ('10','11','12') THEN '4'
		ELSE NULL
  END) AS fscl_yr_prd_filter,
  ords_secrd_nn_secrd_psn_edw_dmnsn.so_stat_cd as ord_hddr_stts_cd, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.so_dtl_stat_cd as ord_itm_stts_cd, -- added as part of LR1
  crc32(lower(concat(coalesce(ords_secrd_nn_secrd_psn_edw_dmnsn.ship_id,""),coalesce(ords_secrd_nn_secrd_psn_edw_dmnsn.SHIP_LN_ITM_ID,"")))) as dlvry_itm_ky, -- added as part of LR1
  crc32(LOWER(concat(COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.bill_doc_id,""),COALESCE(ords_secrd_nn_secrd_psn_edw_dmnsn.bill_doc_ln_itm_id,"")))) as invc_itm_ky, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.ship_id as dlvry_id, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.ship_ln_itm_id as dlvry_itm_id, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.DSTRB_CHNL_CD as dstbn_chnl_cd, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.sldt_cust_id as cp_sld_to_cd, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_entprs_std_cst_usd_am as cp_entprs_std_cst_usd_amt, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_cst_of_sls_usd_am as cp_tot_cst_of_sls_usd_amt, -- added as part of LR1
  null as dvsn_cd, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_cst_of_sls_usd_am as ttl_cst_sls_usd_amt, -- added as part of LR1 
  ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_grs_usd_am AS grs_mrgn_usd_amt, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.sec_non_sec_posn_entprs_std_cst_usd_am AS entrprs_stndrd_cst_grp_curr_usd_amt, -- added as part of LR1
  ords_secrd_nn_secrd_psn_edw_dmnsn.sls_chnl_cd,
  concat( rev_recgn_dt_yr,	"-" ,
	CASE
		WHEN (substr(ords_secrd_nn_secrd_psn_edw_dmnsn.ord_crt_dt,5,3)) IN ('001','002','003') THEN 'Q1'
		WHEN (substr(ords_secrd_nn_secrd_psn_edw_dmnsn.ord_crt_dt,5,3)) IN ('004','005','006') THEN 'Q2'
		WHEN (substr(ords_secrd_nn_secrd_psn_edw_dmnsn.ord_crt_dt,5,3)) IN ('007','008','009' ) THEN 'Q3'
		WHEN (substr(ords_secrd_nn_secrd_psn_edw_dmnsn.ord_crt_dt,5,3)) IN ('010','011','012' ) THEN 'Q4'
		ELSE NULL
  END ) as fscl_yr_qtr_dsply_cd,
  substring(clndr_rpt.fisc_yr_mth_cd,1,4) AS fscl_yr_nr,
  substring(clndr_rpt.fisc_yr_mth_cd,5,2) AS fscl_prd_nr,
  clndr_rpt.fisc_yr_mth_dsply_cd AS fscl_yr_prd_cd,
  clndr_rpt.fisc_qtr_cd AS fscl_qtr_nr
FROM
	${srcTableName} ords_secrd_nn_secrd_psn_edw_dmnsn
	LEFT OUTER JOIN ${dbCommonR2_3UAT}.clndr_rpt clndr_rpt on ords_secrd_nn_secrd_psn_edw_dmnsn.rev_recgn_dt = clndr_rpt.cldr_dt
WHERE
ords_secrd_nn_secrd_psn_edw_dmnsn.SO_SRC_SYS_KY NOT IN ('2867','2869')
""").filter(col("fscl_yr_prd_filter") >= fscl_yr_prd_con or col("fscl_yr_prd_filter").isNull or col("fscl_yr_prd_filter") === "19001")

    val bmtcntrynm = spark.sql(s"select * from ${dbCommonR2_3UAT}.bmt_cntry_nm_dmnsn order by rl_id asc")

    val bmtcntrynmrefined = bmtcntrynm.withColumn("input_table", when(col("inp_tl") === "NA", col("inp_fld")).
      otherwise(concat(col("inp_tl"), lit("."), col("inp_fld")))).withColumn("output_field", when(col("opt_tbl") === "NA", col("opt_fld")).
      otherwise(concat(col("opt_tbl"), lit("."), col("opt_fld"))))

    val bmtcntrynmds = bmtcntrynmrefined.collect.map(c => " when " + c(19) + " " + c(5) + " (" + c(6) + ") then " + c(20))

    var countryname = "case"

    for (i <- 0 to (bmtcntrynmds.length - 1)) { if (bmtcntrynmds(i).contains("'Unknown GEO'")) countryname += " else 'unkown geo' end" else countryname += bmtcntrynmds(i) }

    val finalCountry = countryname.replace("bmt_pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd", "pft_cntr_std_hrchy.pch_level_7")

    val df_ob_scra = spark.sql(s"""
      select 
      sc_bklg_cgy_cd,
      so_id,
      CASE
		    WHEN LENGTH(ob_scra_fd_srtr_dmnsn.so_ln_itm_id) <= 6 THEN LPAD(ob_scra_fd_srtr_dmnsn.so_ln_itm_id,6,"0")
		    ELSE ob_scra_fd_srtr_dmnsn.so_ln_itm_id
      END as so_ln_itm_id
      from ${dbCommonUAT}.ob_scra_fd_srtr_dmnsn""")

    val df_sni_asmnt_fd_srtr = spark.sql(s"select so_id,rev_rec_cd from ${dbCommonUAT}.sni_asmnt_fd_srtr_dmnsn")

    val df_ord_adj = spark.sql(s"select sls_ord_id,rvn_rcgn_cgy_cd,mkt_rte_cd,end_cust_prty_id from ${dbCommonR2_3UAT}.bmt_ord_dmnsn_adjmt_dmnsn")

    val df_scra_rev_rec_cgy = spark.sql(s"select sc_bklg_cgy_cd,rev_recgn_cgy_cd from ${dbCommonUAT}.scra_rev_rec_cgy_dmnsn")

    val df_bmt_pn_disa_flg = spark.sql(s"select pft_cntr_cd,sld_to_id from ${dbCommonR2_2}.bmt_pn_disa_flg_dmnsn")

    val df_bmt_pn_so_hypr_hpc_dxc_flg = spark.sql(s"select sls_ord_id,source from ${dbCommonR2_3UAT}.bmt_pn_so_hypr_hpc_dxc_flg_dmnsn")

    val df_bmt_pn_srv_intensity = spark.sql(s"select * from ${dbCommonR2_3UAT}.bmt_pn_srv_intensity_dmnsn")

    val df_fscl_cldr_dmnsn = spark.sql(s"select *,from_unixtime(unix_timestamp(fscl_cldr_dmnsn.fscl_cldr_dt,'yyyy-MM-dd HH:mm:ss.SS'),'yyyy-MM-dd') as ord_crt_dt from ${dbCommonUAT}.fscl_cldr_dmnsn")

    val df_sls_chnl = spark.sql(s"select * from ${dbCommonR2_3UAT}.bmt_sls_chnl_dmnsn")

    val df_seg = spark.sql(s"select * from ${dbCommonR2_3}.segment_std_hrchy")
    /**/
    val df_bmt_cust_alt_hrchy = spark.sql(s"select * from ${dbCommonR2_3UAT}.bmt_cust_alt_hrchy_dmnsn")

    val df_pft_cntr_std = spark.sql(s" select * from ${dbCommonR2_3UAT}.pft_cntr_std_hrchy")

    val df_bmt_sgm_alt_hrchy = spark.sql(s"select * from ${dbCommonR2_3UAT}.bmt_sgm_alt_hrchy_dmnsn")

    val df_bmt_pft_cntr_alt_hrchy = spark.sql(s"select * from ${dbCommonR2_3UAT}.bmt_pft_cntr_alt_hrchy_dmnsn")

    val df_bmt_sab_cut_off_fd_srtr = spark.sql(s"select * from ${dbCommonR2_3UAT}.bmt_sab_cut_off_fd_srtr_dmnsn")

    val df_edw_stg1 = srcDF.as("edw").join(
      df_ob_scra.as("ob_scra_fd_srtr_dmnsn"),
      col("edw.sls_ord_id") === col("ob_scra_fd_srtr_dmnsn.so_id") &&
        col("edw.sls_ord_ln_itm_id") === col("ob_scra_fd_srtr_dmnsn.so_ln_itm_id"), "left").
      join(df_sni_asmnt_fd_srtr.as("sni_asmnt_fd_srtr_dmnsn"), col("edw.sls_ord_id") === col("sni_asmnt_fd_srtr_dmnsn.so_id"), "left").
      join(df_ord_adj.as("ord_dmnsn_adjmt_dmnsn"), col("edw.sls_ord_id") === col("ord_dmnsn_adjmt_dmnsn.sls_ord_id"), "left").
      join(df_sls_chnl.as("sls_chnl_dmnsn"), col("edw.sls_chnl_cd") === col("sls_chnl_dmnsn.sls_chnl_cd"), "left").
      join(df_scra_rev_rec_cgy.as("scra_rev_rec_cgy_dmnsn"), col("ob_scra_fd_srtr_dmnsn.sc_bklg_cgy_cd") === col("scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd"), "left").
      join(df_bmt_pn_disa_flg.as("pn_disa_flg_dmnsn"), col("edw.prft_cntr_cd") === col("pn_disa_flg_dmnsn.pft_cntr_cd") &&
        col("edw.sld_to_cd") === col("pn_disa_flg_dmnsn.sld_to_id"), "left").

    //val edwStage1load = df_edw_stg1.select(Utilities.loadSelectExpr(df_edw_stg1.columns, tgtColumns): _*)
    //edwStage1load.repartition(40).write.mode("overwrite").format("orc").insertInto("ea_support_temp.edw_stg1")

    //val df_edw_stg2 = df_edw_stg1.as("edw").
    
    join(df_bmt_pn_so_hypr_hpc_dxc_flg.as("pn_so_hypr_hpc_dxc_flg_dmnsn"), col("edw.sls_ord_id") === col("pn_so_hypr_hpc_dxc_flg_dmnsn.sls_ord_id"), "left").
      join(df_bmt_pn_srv_intensity.as("pn_srv_intensity_dmnsn"), col("edw.mtrl_nr") === col("pn_srv_intensity_dmnsn.prod_id"), "left").
      join(df_fscl_cldr_dmnsn.as("fscl_cldr_dmnsn"), col("edw.ord_crt_dt") === col("fscl_cldr_dmnsn.ord_crt_dt"), "left").
      join(df_seg.as("segment_std_hrchy"), col("edw.sgmtl_rptg_cd") === col("segment_std_hrchy.sg_level_8"), "left").
      join(df_bmt_cust_alt_hrchy.as("bmt_cust_alt_hrchy_dmnsn"), col("edw.end_cust_cd") === col("bmt_cust_alt_hrchy_dmnsn.prty_id"), "left").
      join(df_pft_cntr_std.as("pft_cntr_std_hrchy"), col("edw.prft_cntr_cd") === col("pft_cntr_std_hrchy.pch_level_8"), "left").
      join(df_bmt_sgm_alt_hrchy.as("bmt_sgm_alt_hrchy_dmnsn"), col("edw.sgmtl_rptg_cd") === col("bmt_sgm_alt_hrchy_dmnsn.sgm_cd"), "left").
      join(df_bmt_pft_cntr_alt_hrchy.as("bmt_pft_cntr_alt_hrchy_dmnsn"), col("edw.prft_cntr_cd") === col("bmt_pft_cntr_alt_hrchy_dmnsn.pft_cntr_cd"), "left").
      join(df_bmt_sab_cut_off_fd_srtr.as("sab_cut_off_fd_srtr_dmnsn"), col("edw.fscl_yr_qtr_dsply_cd") === col("sab_cut_off_fd_srtr_dmnsn.fscl_yr_qtr_dsply_cd") &&
        col("edw.sgmtl_rptg_cd") === col("sab_cut_off_fd_srtr_dmnsn.sgm_cd"), "left").//selectExpr("edw.*")
      selectExpr(
        "edw.*",
        "ob_scra_fd_srtr_dmnsn.sc_bklg_cgy_cd AS scra_cgy_cd",
        "sni_asmnt_fd_srtr_dmnsn.rev_rec_cd AS sni_risk_asmnt_cgy_cd",
        "CASE WHEN ord_dmnsn_adjmt_dmnsn.sls_ord_id IS NULL THEN edw.end_cust_cd ELSE ord_dmnsn_adjmt_dmnsn.end_cust_prty_id  END AS cp_end_cust_prty_id",
        "CASE WHEN ord_dmnsn_adjmt_dmnsn.mkt_rte_cd IS NULL THEN sls_chnl_dmnsn.rtm ELSE ord_dmnsn_adjmt_dmnsn.mkt_rte_cd END AS cp_mkt_rte_cd",
        "CASE WHEN ord_dmnsn_adjmt_dmnsn.sls_ord_id IS NULL THEN edw.end_cust_cd ELSE ord_dmnsn_adjmt_dmnsn.end_cust_prty_id END AS mdm_id",
        "sls_chnl_dmnsn.rtm AS mkt_rte_cd",
        "CASE WHEN pn_disa_flg_dmnsn.sld_to_id IS NULL THEN 'N' ELSE 'Y' END AS disa_ind",
        "'N' AS grn_lake_ind",
        "CASE WHEN UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn.source) LIKE '%DXC%' THEN 'Y' ELSE 'N' END AS dxc_ind",
        "CASE WHEN UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn.source) LIKE '%HPC%' THEN 'Y' ELSE 'N' END AS hpc_ind",
        "CASE WHEN UPPER(pn_so_hypr_hpc_dxc_flg_dmnsn.source) LIKE '%Hyperconverged%' THEN 'Y' ELSE 'N' END AS hyperconverged_ind",
        "CASE WHEN pn_srv_intensity_dmnsn.srv_intensity_flg_cd IS NULL THEN 'N' ELSE 'Y' END AS srv_intensity_ind",
        """CASE
		       WHEN ord_dmnsn_adjmt_dmnsn.sls_ord_id IS NULL THEN
		         CASE
			        WHEN sni_asmnt_fd_srtr_dmnsn.rev_rec_cd IS NOT NULL AND lower(sni_asmnt_fd_srtr_dmnsn.rev_rec_cd) = "include" THEN sni_asmnt_fd_srtr_dmnsn.rev_rec_cd
			        WHEN scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd IS NOT NULL AND lower(scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd) = "include" THEN scra_rev_rec_cgy_dmnsn.rev_recgn_cgy_cd
			       ELSE NULL
	         END
	         ELSE ord_dmnsn_adjmt_dmnsn.rvn_rcgn_cgy_cd
           END AS cp_rev_recgn_cgy_cd""",
        """CASE
		         WHEN sni_asmnt_fd_srtr_dmnsn.rev_rec_cd IS NOT NULL THEN sni_asmnt_fd_srtr_dmnsn.rev_rec_cd
		         WHEN scra_rev_rec_cgy_dmnsn.sc_bklg_cgy_cd IS NOT NULL THEN scra_rev_rec_cgy_dmnsn.rev_recgn_cgy_cd
		         ELSE NULL
           END AS rvn_rcgn_cgy_cd""",
        "CASE WHEN edw.ord_crt_dt <= sab_cut_off_fd_srtr_dmnsn.beg_sab_cutoff_dt THEN 'Y' ELSE 'N' END AS beg_bklg_nm",
        "fscl_cldr_dmnsn.week_in_qtr_cd AS fscl_week_cd",
        s"${finalCountry} AS ctry_nm",
        "bmt_cust_alt_hrchy_dmnsn.cust_mppg_23_cd AS cust_sgm_nm")

    val tgtColumnsStg = spark.sql(s"select * from ${dbTemp}.edw_stg2 limit 0").columns    
        
    val edwStage2load = df_edw_stg1.select(Utilities.loadSelectExpr(df_edw_stg1.columns, tgtColumnsStg): _*)
    edwStage2load.repartition(40).write.mode("overwrite").format("orc").insertInto(dbTemp+".edw_stg2")
        
    val df_edw_stg2 = spark.sql(s"select * from ${dbTemp}.edw_stg2")
        
    val df_party = spark.sql(s"select * from ${dbCommonR2_3UAT}.prty_fact")

    val df_rev_rec_cgy_snp = spark.sql(s"select rev_recgn_cgy_cd,rev_hd_cd,incd_excld_cd from ${dbCommonUAT}.bmt_rev_rec_cgy_snp_dmnsn")

    val finalEDWDF = df_edw_stg2.drop("cp_end_cust_prty_nm").drop("cp_rev_hdr_nm").drop("cp_incd_excld").drop("rev_hd_cd").as("edw_stg").
      join(df_party.as("prty"),col("edw_stg.mdm_id") === col("prty.mdm_id"),"left").
      join(broadcast(df_rev_rec_cgy_snp).as("rev_rec_cgy_snp_dmnsn"), col("edw_stg.cp_rev_recgn_cgy_cd") === col("rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd"), "left").selectExpr(
        "edw_stg.*",
        "prty.prty_nm AS cp_end_cust_prty_nm",
        "CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.rev_hd_cd ELSE NULL END AS cp_rev_hdr_nm",
        "CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.incd_excld_cd ELSE NULL END AS cp_incd_excld",
        "CASE WHEN rev_rec_cgy_snp_dmnsn.rev_recgn_cgy_cd IS NOT NULL THEN rev_rec_cgy_snp_dmnsn.rev_hd_cd ELSE NULL END AS rev_hd_cd")

    //logger.info("//************* Data Count " + finalEDWDF.count.toLong)

    val finalLoadDF = finalEDWDF.select(Utilities.loadSelectExpr(finalEDWDF.columns, tgtColumns): _*)
    finalLoadDF.repartition(40).write.mode("overwrite").format("orc").insertInto(tgtTblConsmtn)
 
    val tgtCount = spark.sql(s"select * from ${tgtTblConsmtn} where src_sys_cd like 'EDW%'").count.toInt

    tgtCount match {
      case 0 =>
        logger.info("//************* Data Load Failed")

        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("failed")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)

      case _ =>
        logger.info("//************* Data Loaded into " + tgtTblConsmtn + " ,count:" + tgtCount)
        auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobStatusCode("success")
        auditObj.setAudSrcRowCount(srcCount)
        auditObj.setAudTgtRowCount(tgtCount)
        auditObj.setAudErrorRecords(0)
        auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
        auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
        Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }

  } catch {

    case sslException: InterruptedException => {
      logger.error("Interrupted Exception")
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_EDW_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case nseException: NoSuchElementException => {
      logger.error("No Such element found: " + nseException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_EDW_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case anaException: AnalysisException => {
      logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_EDW_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case connException: ConnectException => {
      logger.error("Connection Exception: " + connException.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_EDW_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case illegalArgs: IllegalArgumentException => {
      logger.error("Connection Exception: " + illegalArgs.printStackTrace())
      auditObj.setAudBatchId(ld_jb_nr + "_" + batchId)
      auditObj.setAudDataLayerName("ref_cnsmptn")
      auditObj.setAudApplicationName("job_secured_EDW_fact")
      auditObj.setAudObjectName(objName)
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
    case allException: Exception => {
      logger.error("Connection Exception: " + allException.printStackTrace())
      auditObj.setAudJobStatusCode("failed")
      auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
      auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
      Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
    }
  } finally {
    logger.info("//*********************** Log End for EDWSecuredReport.scala ************************//")
    sqlCon.close()
    spark.close()
  }

}
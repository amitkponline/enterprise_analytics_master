package com.hpe.batch.driver.gl

import java.net.ConnectException
import java.util.HashMap

import main.scala.com.hpe.config.{ StreamingPropertiesObject, _ }

import org.apache.log4j.Logger
import org.apache.spark.sql.{ AnalysisException, Row }
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{ StringType, StructField, StructType }
import org.apache.spark.storage.StorageLevel

import scala.collection.Map
import java.sql.Connection
import main.scala.com.hpe.utils.Utilities
import org.tukaani.xz.check.CRC64
import com.github.snksoft.crc.CRC
import java.text.SimpleDateFormat
import org.apache.spark.sql.SparkSession

object GLFactLoader {

  //Initialized Log
  val logger = Logger.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    if (args == null || args.isEmpty || args.length != 1) {
      println("Invalid number of arguments passed.")
      println("Arguments Usage: <Properties file path>")
      println("Stopping the flow")
      System.exit(1)
    }
    logger.info("Number of argument passed is:::" + args.length)
    val propertiesFilePath = String.valueOf(args(0).trim())
    var offsetColumnName = "intgtn_fbrc_msg_id"
    val auditObj: AuditLoadObject = new AuditLoadObject("", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "")
    var sqlCon: Connection = null
    var auditTbl: String = null
    val format = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
    val propertiesObject: StreamingPropertiesObject = Utilities.getStreamingPropertiesobject(propertiesFilePath)
    val configObject: ConfigObjectBatch = SetUpConfigurationBatch.setup()
    val sKeyFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "sKey"
    val sk: SKeyObject = Utilities.getSKeyPropertiesobject(sKeyFilePath)
    val envPropertiesFilePath = propertiesFilePath.substring(0, propertiesFilePath.lastIndexOf("/") + 1) + "connection.properties"
    val envPropertiesObject: EnvPropertiesObject = Utilities.getEnvPropertiesobject(envPropertiesFilePath, sk)

    val appName = configObject.getSpark().sparkContext.appName
    val appId = configObject.getSpark().sparkContext.applicationId
    var isAppAlreadyRunning = Utilities.isJobAlreadyRunning(envPropertiesObject, appName, appId)
    logger.info("============isAppAlreadyRunning::::" + isAppAlreadyRunning)
    var spark:SparkSession = null
    if (!isAppAlreadyRunning) {
      try {

        auditTbl = envPropertiesObject.getMySqlDBName() + "." + envPropertiesObject.getMySqlAuditTbl()

        val src_sys_ky = propertiesObject.getMasterDataFields().split(",", -1)(0)
        val fl_nm = propertiesObject.getMasterDataFields().split(",", -1)(1)
        val ld_jb_nr = propertiesObject.getMasterDataFields().split(",", -1)(2)
        val jb_nm = propertiesObject.getMasterDataFields().split(",", -1)(3)
        val config_obj_file_nm = propertiesObject.getMasterDataFields().split(",", -1)(4)

        //val auditBatchId = ld_jb_nr + "_" + Utilities.getCurrentTimestamp("yyyyMMddHHmmss")

        val generateSeqID = udf(Utilities.crc64 _)

        spark = configObject.spark
        var minDate = "2017-01-01"
        //source for trsn ref table
        var srcTblConsmtn = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblRef()
        //trsn ref table name
        val tgtTblRef = propertiesObject.getDbName() + "." + propertiesObject.getSrcTblConsmtn()
        //fact table name
        val tgtTblConsmtn = propertiesObject.getDbName() + "." + propertiesObject.getTgtTblConsmtn()
        // New method to get BatchIds
        sqlCon = Utilities.getConnection(envPropertiesObject)
        val refBatchIdList: List[String] = Utilities.readRefBatchIdListNew(sqlCon, propertiesObject.getObjName(), auditTbl)
        var src_count = Utilities.readRefCount(sqlCon, propertiesObject.getObjName())
        sqlCon.close()
        val refCols = propertiesObject.getRefCols()
        val trsnRefCol = spark.sql("select * from " + tgtTblRef + " limit 0")
        //val auditBatchId = ld_jb_nr + "_" + Utilities.getCurrentTimestamp("yyyyMMddHHmmss")
        if (refBatchIdList.length != 0) {
          val customSQL4 = propertiesObject.getCustomSQL4()
          val orderDmnsnDf = spark.sql(customSQL4)
          orderDmnsnDf.createOrReplaceTempView("orderDmnsnDf")
          val minBatchId = refBatchIdList.map(x => (x, x.reverse.slice(0, 14).reverse)).minBy(_._2)._1
          logger.info("Min Batch id in transaction is:::=" + minBatchId)
          val inputFormat = new SimpleDateFormat("yyyyMMddHHmmss")
          val outputFormat = new SimpleDateFormat("yyyy-MM-dd")
          minDate = outputFormat.format(inputFormat.parse(minBatchId.split("_")(2)))
          logger.info("########################minDate::::" + minDate)
          auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          logger.info("-------------->>>>>>>>Got List<<<<<<<<<<<<<<----------------" + refBatchIdList)
          val auditBatchId = refBatchIdList.map(x => (x, x.reverse.slice(0, 14).reverse)).maxBy(_._2)._1
          val maxDate = outputFormat.format(inputFormat.parse(auditBatchId.split("_")(2)))
          logger.info("Max daily partition value:::"+maxDate)
          val refDfInc = spark.sql(f"""select * from ${srcTblConsmtn} where ins_gmt_dt>='${minDate}'""").select(col("*")).filter(col("ld_jb_nr") isin (refBatchIdList: _*))

          val cst_cntr_grp_hrchy = spark.sql(propertiesObject.getCustomSQL5())
          val eap_config_tbl = propertiesObject.getConfigTable()
          cst_cntr_grp_hrchy.createOrReplaceTempView("cst_cntr_grp_hrchy")
          val refDfLatest = Utilities.getLatestRecs(refDfInc, List("gnrl_ldgr_acctng_cd", "entrs_lgl_ent_ldgr_cd", "fscl_yr_nr", "acctng_dcmt_id", "pstg_itm_ldgr_cd"), List("extract_ts")).withColumn("ld_jb_nr", lit(auditBatchId))
          refDfLatest.createOrReplaceTempView("refDfLatest")
          refDfLatest.printSchema()
          logger.info("ref cols===========================" + refCols)
          val prdNr = refDfLatest.select("pstg_prd_nr").distinct().collect.map(row => row.getLong(0)).toSeq
          val yrNr = refDfLatest.select("fscl_yr_nr").distinct().collect.map(row => row.getLong(0)).toSeq
          val refDfReq = spark.sql(f""" select ${refCols} from refDfLatest a left join orderDmnsnDf inr on a.ord_nr = inr.ord_id LEFT JOIN ${eap_config_tbl} gl ON ( a.mgmt_grphy_unt_cd = gl.in_put) LEFT JOIN cst_cntr_grp_hrchy c1 ON ( a.cst_cntr_cd = c1.cst_cntr_cd ) """).drop("ins_gmt_dt")
          val refLatestCrc64WoScDf = refDfReq.withColumn("gnrl_ldgr_ln_itm_ky", generateSeqID(refDfReq("gnrl_ldgr_ln_itm_ky_t"), refDfReq("acctng_dcmt_ln_itm_nr_salt"))).withColumn("ins_gmt_dt", lit(maxDate).cast("date"))

          var refLatestCrc64Df = refLatestCrc64WoScDf.select(trsnRefCol.columns.head, trsnRefCol.columns.tail: _*)
          refLatestCrc64Df.createOrReplaceTempView("refLatestCrc64Df")
          
          //get existing matching data
          val latestDistintSurrKeys = refLatestCrc64Df.select(col("gnrl_ldgr_ln_itm_ky")).persist(StorageLevel.MEMORY_AND_DISK_SER)
          val existingRefPartitions = spark.sql("select distinct ins_gmt_dt, gnrl_ldgr_ln_itm_ky from " + tgtTblRef + " union all select distinct ins_gmt_dt, gnrl_ldgr_ln_itm_ky from refLatestCrc64Df").join(latestDistintSurrKeys, Seq("gnrl_ldgr_ln_itm_ky"), "inner").select(col("ins_gmt_dt")).distinct().collect.map(row => row.getDate(0)).toSeq
          var allTobeOverwrite = spark.sql("select * from " + tgtTblRef).where(col("yr_nr").isin(yrNr: _*)).where(col("prd_nr").isin(prdNr: _*)).where(col("ins_gmt_dt").isin(existingRefPartitions: _*))

          var unChangedRef = allTobeOverwrite.join(refLatestCrc64Df, Seq("gnrl_ldgr_ln_itm_ky"), "left_anti")
          
          val incRefDf = unChangedRef.select(trsnRefCol.columns.head, trsnRefCol.columns.tail: _*).union(refLatestCrc64Df)
          val status = Utilities.storeDataFrame(incRefDf, "overwrite", "ORC", tgtTblRef)
          var tgt_count = refLatestCrc64Df.count//spark.sql("select count(*) from " + tgtTblRef + " where ld_jb_nr='" + auditBatchId + "'").first().getLong(0) //ctrlDfNullRemovedDistinct.count()
          //initialize audit

          auditObj.setAudBatchId(auditBatchId)
          auditObj.setAudDataLayerName("ref_cnsmptn")
          auditObj.setAudApplicationName("job_EA_loadTrsnRef")
          auditObj.setAudObjectName(propertiesObject.getObjName())
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          if (status) {
            auditObj.setAudJobStatusCode("success")
            auditObj.setAudSrcRowCount(src_count)
            auditObj.setAudTgtRowCount(tgt_count)
            auditObj.setAudErrorRecords(0)
            auditObj.setAudCreatedBy(spark.sparkContext.sparkUser)
            auditObj.setFlNm("")
            auditObj.setSysBtchNr(ld_jb_nr)
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            sqlCon = Utilities.getConnection(envPropertiesObject)
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            sqlCon.close()
          } else {
            auditObj.setAudJobStatusCode("failed")
            auditObj.setAudSrcRowCount(src_count)
            auditObj.setAudTgtRowCount(tgt_count)
            auditObj.setAudErrorRecords(0)
            auditObj.setAudCreatedBy(spark.sparkContext.sparkUser)
            auditObj.setFlNm("")
            auditObj.setSysBtchNr(ld_jb_nr)
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            sqlCon = Utilities.getConnection(envPropertiesObject)
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            sqlCon.close()
            System.exit(1)
          }
          
        }
        //

        // New method to get BatchIds of trsn ref
        sqlCon = Utilities.getConnection(envPropertiesObject)
        val refTrsnBatchIdList: List[String] = Utilities.readFactBatchIdListNew(sqlCon, propertiesObject.getObjName(), auditTbl)
        src_count = Utilities.readFactCount(sqlCon, propertiesObject.getObjName())
        sqlCon.close()
        val factColsFromRef = propertiesObject.getFactCols()
        val factsCol = spark.sql("select * from " + tgtTblConsmtn + " limit 0")
        if (refTrsnBatchIdList.length != 0) {
          auditObj.setAudJobStartTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          val minBatchId = refTrsnBatchIdList.map(x => (x, x.reverse.slice(0, 14).reverse)).minBy(_._2)._1
          logger.info("Min Batch id in fact is:::=" + minBatchId)
          val inputFormat = new SimpleDateFormat("yyyyMMddHHmmss")
          val outputFormat = new SimpleDateFormat("yyyy-MM-dd")
          minDate = outputFormat.format(inputFormat.parse(minBatchId.split("_")(2)))
          val filterKey = propertiesObject.getFilterKey().trim
          logger.info("-------------->>>>>>>>Got List<<<<<<<<<<<<<<----------------" + refTrsnBatchIdList)
          val auditBatchId = refTrsnBatchIdList.map(x => (x, x.reverse.slice(0, 14).reverse)).maxBy(_._2)._1
          
          
          val filterCol = filterKey.split('|')(0).trim
          val filterVal = filterKey.split('|')(1).trim
          var refTrsnDf = spark.sql(f"""select ${factColsFromRef} from ${tgtTblRef} where ins_gmt_dt>='${minDate}'""")
            .select(col("*")).filter(col("ld_jb_nr") isin (refTrsnBatchIdList: _*))
            .filter(col(filterCol) === filterVal)

          refTrsnDf.write.mode("Overwrite").format("ORC").saveAsTable(propertiesObject.getDbName() + ".refTrsnDf_tmp")
          refTrsnDf = spark.sql(s"select * from ${propertiesObject.getDbName()}.refTrsnDf_tmp")
          refTrsnDf.createOrReplaceTempView("refTrsnDf")
          val coDf = spark.sql(propertiesObject.getCustomSQL())
          val glaMasterDf = spark.sql(propertiesObject.getCustomSQL2())
          val joinCoDf = refTrsnDf.join(coDf, Seq("entrs_lgl_ent_ldgr_cd"), "left").drop("ld_jb_nr")
          var joinAll = joinCoDf.join(glaMasterDf, joinCoDf.col("acct_nr") === glaMasterDf.col("gnrl_ldgr_acct_nr"), "left").withColumn("ld_jb_nr", lit(auditBatchId))
          joinAll.createOrReplaceTempView("joinAll")
          
          val existingFactPartitions = spark.sql("select distinct prd_nr from refTrsnDf").select(col("prd_nr")).collect.map(row => row.getLong(0)).toSeq
          //val prdNr = refTrsnDf.select("pstg_prd_nr").distinct().collect.map(row => row.getLong(0)).toSeq
          val yrNr = refTrsnDf.select("yr_nr").distinct().collect.map(row => row.getLong(0)).toSeq
          var allTobeOverwrite = spark.sql("select * from " + tgtTblConsmtn).where(col("yr_nr").isin(yrNr: _*)).where(col("prd_nr").isin(existingFactPartitions: _*))
          val customSQL3 = propertiesObject.getCustomSQL3()
          val incFact = spark.sql(f"""select ${customSQL3} from joinAll""")
          val unChangedFact = allTobeOverwrite.join(incFact, Seq("gl_fact_key"), "left_anti")
          val incAllFactDf = unChangedFact.select(factsCol.columns.head, factsCol.columns.tail: _*).union(incFact)
          val status = Utilities.storeDataFrame(incAllFactDf, "overwrite", "ORC", tgtTblConsmtn,120)
          var tgt_count = incFact.count //spark.sql("select count(*) from " + tgtTblConsmtn + " where ld_jb_nr='" + auditBatchId + "'").first().getLong(0) //ctrlDfNullRemovedDistinct.count()
          //initialize audit

          auditObj.setAudBatchId(auditBatchId)
          auditObj.setAudDataLayerName("reftrsn_cnsmptn")
          auditObj.setAudApplicationName("job_EA_loadTrsnRef")
          auditObj.setAudObjectName(propertiesObject.getObjName())
          auditObj.setAudLoadTimeStamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss.SSS"))
          if (status) {
            auditObj.setAudJobStatusCode("success")
            auditObj.setAudSrcRowCount(src_count)
            auditObj.setAudTgtRowCount(tgt_count)
            auditObj.setAudErrorRecords(0)
            auditObj.setAudCreatedBy(spark.sparkContext.sparkUser)
            auditObj.setFlNm("")
            auditObj.setSysBtchNr(ld_jb_nr)
            sqlCon = Utilities.getConnection(envPropertiesObject)
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            sqlCon.close()
            spark.sql(s"truncate table ${propertiesObject.getDbName()}.refTrsnDf_tmp" )
          } else {
            auditObj.setAudJobStatusCode("failed")
            auditObj.setAudSrcRowCount(src_count)
            auditObj.setAudTgtRowCount(tgt_count)
            auditObj.setAudErrorRecords(0)
            auditObj.setAudCreatedBy(spark.sparkContext.sparkUser)
            auditObj.setFlNm("")
            auditObj.setSysBtchNr(ld_jb_nr)
            sqlCon = Utilities.getConnection(envPropertiesObject)
            auditObj.setAudJobEndTimestamp(Utilities.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"))
            auditObj.setAudJobDuration((((format.parse(auditObj.getAudJobEndTimestamp()).getTime - format.parse(auditObj.getAudJobStartTimeStamp()).getTime).toString()).toInt / 1000).toString())
            Utilities.insertIntoAudit(sqlCon, auditObj, auditTbl)
            sqlCon.close()
            spark.sql(s"truncate table ${propertiesObject.getDbName()}.refTrsnDf_tmp" )
            System.exit(1)
          }
          
        }

      } catch {

        case intException: InterruptedException => {
          logger.error("Interrupted Exception" + intException.printStackTrace())
          System.exit(1)
        }
        case nseException: NoSuchElementException => {
          logger.error("No Such element found: " + nseException.printStackTrace())
          System.exit(1)
        }
        case anaException: AnalysisException => {
          logger.error("SQL Analysis Exception: " + anaException.printStackTrace())
          System.exit(1)
        }
        case connException: ConnectException => {
          logger.error("Connection Exception: " + connException.printStackTrace())
          System.exit(1)
        }
      }finally{
        if(sqlCon!=null){
          sqlCon.close()
        }
        spark.sql(s"truncate table ${propertiesObject.getDbName()}.refTrsnDf_tmp" )
      }
    } else {
      logger.error("Application with same name is already running in yarn")
      System.exit(1)

    }
  }
}
package main.scala.com.hpe.utils

import java.io.{ FileNotFoundException, IOException }
import java.math.BigInteger
import java.security.{ MessageDigest, NoSuchAlgorithmException }
import java.sql.{ Connection, DriverManager, ResultSet, Statement }
import java.util.{ HashMap, Properties }

import com.github.opendevl.JFlat
import main.scala.com.hpe.config._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{ FileSystem, Path }
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.{ broadcast, col, lit, udf, _ }
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{ DataFrame, SQLContext }
import org.joda.time.DateTime
import org.joda.time.format.{ DateTimeFormat, DateTimeFormatter }

import scala.collection.mutable.{ Map, _ }
import scala.util.control.Breaks.break
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.Row
import org.apache.spark.sql.expressions.Window
import com.github.snksoft.crc.CRC
import scala.collection.Seq

import org.apache.http.client.config.RequestConfig
import org.apache.http.HttpHost
import org.apache.http.client.CredentialsProvider
import org.apache.http.impl.client.BasicCredentialsProvider
import org.apache.http.auth.AuthScope
import org.apache.http.auth.UsernamePasswordCredentials
import org.apache.http.impl.client.HttpClientBuilder
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.client.methods.HttpGet
import org.apache.http.HttpResponse
import org.apache.http.util.EntityUtils
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import java.util.Base64
import org.apache.http.HttpHeaders
import org.apache.log4j.Logger
import org.apache.spark.sql.AnalysisException
import java.net.ConnectException


object Utilities {
  val log = Logger.getLogger(getClass.getName)
  val ISOFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

  /**
   * removeDuplicates function removes the duplicate rows from a DataFrame.
   *
   * @param DataFrame : Input DataFrame
   * @return DataFrame    : DataFrame with unique rows
   */
  def removeDuplicates(inputDF: DataFrame): DataFrame = {
    log.info("Removing duplicate rows")
    val columnList = inputDF.drop("intgtn_fbrc_msg_id").drop("ins_gmt_ts").columns
    val de_dup_DF = inputDF.dropDuplicates(columnList)
    log.info("Count After Dropping the Duplicate Rows :" + de_dup_DF.count())
    return de_dup_DF
  }

  /**
   * @param str
   * @return
   */
  def getStreamingPropertiesobject(str: String): StreamingPropertiesObject = {
    val propfileSystem: FileSystem = FileSystem.get(new Configuration)
    val propFileInputStream = propfileSystem.open(new Path(str))
    var properties: Properties = new Properties();
    properties.load(propFileInputStream);
    //	      var properties: Properties = null
    var pObj: StreamingPropertiesObject = null
    log.info("++++++++++++++++++++++++++" + str)
    try {
      //						  properties.load(new FileInputStream(str))
      //							val path = getClass.getResource(str)
      log.info("########################################Utilities::::::::::::::" + str.toString())
      if (str != null) {
        /*										val source = Source.fromURL(path)
                    properties = new Properties()
                    properties.load(source.bufferedReader())*/
        pObj = new StreamingPropertiesObject(
          properties.getProperty("objName"),
          properties.getProperty("autoCommit"),
          properties.getProperty("dbName"),
          properties.getProperty("ctrl_doc_num"),
          properties.getProperty("topicList"),
          properties.getProperty("tableNameMapping"),
          properties.getProperty("tgt_ctrl_tbl"),
          properties.getProperty("NulchkCol"),
          properties.getProperty("lnchkVal"),
          properties.getProperty("DtfmtchkCol"),
          properties.getProperty("intchkCol"),
          properties.getProperty("doublechkCol"),
          properties.getProperty("booleanchkCol"),
          properties.getProperty("longchkCol"),
          properties.getProperty("rcdDelimiter"),
          properties.getProperty("colListSep"),
          properties.getProperty("filterExpression"),
          properties.getProperty("tgtTblRw"),
          properties.getProperty("tgtTblErr"),
          properties.getProperty("tgtTblRef"),
          properties.getProperty("tgtTblConsmtn"),
          properties.getProperty("srcTblConsmtn"),
          properties.getProperty("unqKeyCols"),
          properties.getProperty("masterDataFields"),
          properties.getProperty("hiveJsonRawMap"),
          properties.getProperty("hiveJsonCtrlMap"),
          properties.getProperty("lookUpTable"),
          properties.getProperty("customSQL"),
          properties.getProperty("dateCastFields"),
          properties.getProperty("consumerGroupVal"),
          properties.getProperty("currencyCastFields"),
          properties.getProperty("maxRatePerPartition"),
          properties.getProperty("surrKey"),
          properties.getProperty("naturalKeys"),
          properties.getProperty("objectType"),
          properties.getProperty("latestEntryKey"),
          properties.getProperty("multipleSurrKeyInd"),
          properties.getProperty("filterKey"),
          properties.getProperty("apiName"),
          properties.getProperty("deleteflag"),
          properties.getProperty("deletejoinCol"),
          properties.getProperty("deleteTableName"),
          properties.getProperty("CurrentQuarter"),
          properties.getProperty("PreviousQuarter"),
          properties.getProperty("CurrentYear"),
          properties.getProperty("PreviousYear"),
          properties.getProperty("hive_ref_table_mtrl_prcmt_typ_ref"),
          properties.getProperty("hive_ref_table_prdn_sply_ar_ref"),
          properties.getProperty("hive_ref_table_bll_mtrl_ref"),
          properties.getProperty("hive_ref_table_mtrl_bll_mtrl_ref"),
          properties.getProperty("hive_ref_table_bll_mtrl_itm_ref"),
          properties.getProperty("hive_ref_table_bll_mtrl_cmpnnt_ref"),
          properties.getProperty("hive_ref_table_bll_mtrl_usg_ref"),
          properties.getProperty("hive_ref_table_bll_mtrl_stts_ref"),
          properties.getProperty("hive_ref_table_bll_mtrl_itm_cgy_ref"),
          properties.getProperty("hive_ref_table_mtrl_prvn_ref"),
          properties.getProperty("hive_ref_table_spare_prt_grp_ref"),
          properties.getProperty("hive_ref_table_cst_relevancy_ref"),
          properties.getProperty("hive_ref_table_prchg_org_ref"),
          properties.getProperty("hive_ref_table_cmpnnt_cnsmpn_dbn_ref"),
          properties.getProperty("hive_ref_table_cltn_fml_ref"),
          properties.getProperty("hive_ref_table_bll_mtrl_itm_grp_ref"),
          properties.getProperty("hive_ref_table_explsn_typ_ref"),
          properties.getProperty("keys_mtrl_prcmt_typ_ref"),
          properties.getProperty("keys_prdn_sply_ar_ref"),
          properties.getProperty("keys_bll_mtrl_ref"),
          properties.getProperty("keys_mtrl_bll_mtrl_ref"),
          properties.getProperty("keys_bll_mtrl_itm_ref"),
          properties.getProperty("keys_bll_mtrl_cmpnnt_ref"),
          properties.getProperty("keys_bll_mtrl_usg_ref"),
          properties.getProperty("keys_bll_mtrl_stts_ref"),
          properties.getProperty("keys_bll_mtrl_itm_cgy_ref"),
          properties.getProperty("keys_mtrl_prvn_ref"),
          properties.getProperty("keys_spare_prt_grp_ref"),
          properties.getProperty("keys_cst_relevancy_ref"),
          properties.getProperty("keys_prchg_org_ref"),
          properties.getProperty("keys_cmpnnt_cnsmpn_dbn_ref"),
          properties.getProperty("keys_cltn_fml_ref"),
          properties.getProperty("keys_bll_mtrl_itm_grp_ref"),
          properties.getProperty("keys_explsn_typ_ref"),
          properties.getProperty("hive_ref_table_unt_msr_ref"),
          properties.getProperty("hive_ref_table_chrc_mstr_ref"),
          properties.getProperty("hive_ref_table_chrc_lng_ref"),
          properties.getProperty("hive_ref_table_chrc_vl_ref"),
          properties.getProperty("hive_ref_table_clss_chrc_ref"),
          properties.getProperty("hive_ref_table_sls_dvsn_ref"),
          properties.getProperty("hive_ref_table_chrc_vl_lng_ref"),
          properties.getProperty("hive_ref_table_clss_hdr_lng_ref"),
          properties.getProperty("hive_ref_table_dcmt_typ_ref"),
          properties.getProperty("hive_ref_table_chrc_grp_ref"),
          properties.getProperty("hive_ref_table_clss_grp_ref"),
          properties.getProperty("hive_ref_table_clss_hdr_ref"),
          properties.getProperty("hive_ref_table_clss_typ_ref"),
          properties.getProperty("hive_ref_table_clss_stts_ref"),
          properties.getProperty("keys_unt_msr_ref"),
          properties.getProperty("keys_chrc_mstr_ref"),
          properties.getProperty("keys_chrc_lng_ref"),
          properties.getProperty("keys_chrc_vl_ref"),
          properties.getProperty("keys_clss_chrc_ref"),
          properties.getProperty("keys_sls_dvsn_ref"),
          properties.getProperty("keys_chrc_vl_lng_ref"),
          properties.getProperty("keys_clss_hdr_lng_ref"),
          properties.getProperty("keys_dcmt_typ_ref"),
          properties.getProperty("keys_chrc_grp_ref"),
          properties.getProperty("keys_clss_grp_ref"),
          properties.getProperty("keys_clss_hdr_ref"),
          properties.getProperty("keys_clss_typ_ref"),
          properties.getProperty("keys_clss_stts_ref"),
          properties.getProperty("refCols"),
          properties.getProperty("factCols"),
          properties.getProperty("customSQL2"),
          properties.getProperty("customSQL3"),
          properties.getProperty("fileBasePath",""),
          properties.getProperty("period",""),
          properties.getProperty("runDate",""),
          properties.getProperty("fnclOwnrCd",""),
          properties.getProperty("customSQL4"),
          properties.getProperty("configTable"),
          properties.getProperty("customSQL5"),
          properties.getProperty("hive_ref_table"),
          properties.getProperty("hive_ref_table_deal_rslr_a_ref"),
          properties.getProperty("hive_ref_table_deal_rslr_b_ref"),
          properties.getProperty("hive_ref_table_deal_sls_rep_ref"),
          properties.getProperty("hive_ref_table_deal_usr_ref"),
          properties.getProperty("hive_ref_table_deal_prc_qlty_bnd_ref"),
          properties.getProperty("hive_ref_table_deal_prc_dsc_ref"),
          properties.getProperty("hive_ref_table_deal_prty_rol_ref"),
          properties.getProperty("hive_ref_table_deal_itm_dscnt_scl_ref"),
          properties.getProperty("hive_ref_table_deal_ref"),
          properties.getProperty("hive_ref_table_deal_bndl_ref"),
          properties.getProperty("hive_ref_table_deal_bndl_itm_ref"),
          properties.getProperty("hive_ref_table_deal_itm_ref"),
          properties.getProperty("hive_ref_table_deal_euv_ref"),
          properties.getProperty("hive_ref_table_deal_upd_euv_ref"),
          properties.getProperty("hive_ref_table_deal_bdln_guid_ref"),
          properties.getProperty("hive_ref_table_deal_ldisc_guid_ref"),
          properties.getProperty("hive_ref_table_deal_guid_ref"),
          properties.getProperty("hive_ref_table_deal_pqb_ref"),
          properties.getProperty("hive_ref_table_deal_d_aud_rslra_ref"),
          properties.getProperty("hive_ref_table_deal_d_aud_rslrb_ref"),
          properties.getProperty("hive_ref_table_deal_dct_out_ref"),
          properties.getProperty("hive_ref_table_deal_dct_in_ref"),
          properties.getProperty("hive_ref_table_deal_atch_ref"),
          properties.getProperty("hive_ref_table_deal_cmt_ref"),
          properties.getProperty("keys_deal_rslr_a_ref"),
          properties.getProperty("keys_deal_rslr_b_ref"),
          properties.getProperty("keys_deal_sls_rep_ref"),
          properties.getProperty("keys_deal_usr_ref"),
          properties.getProperty("keys_deal_prc_qlty_bnd_ref"),
          properties.getProperty("keys_deal_prc_dsc_ref"),
          properties.getProperty("keys_deal_prty_rol_ref"),
          properties.getProperty("keys_deal_itm_dscnt_scl_ref"),
          properties.getProperty("keys_deal_ref"),
          properties.getProperty("keys_deal_bndl_ref"),
          properties.getProperty("keys_deal_bndl_itm_ref"),
          properties.getProperty("keys_deal_itm_ref"),
          properties.getProperty("keys_deal_euv_ref"),
          properties.getProperty("keys_deal_upd_euv_ref"),
          properties.getProperty("keys_deal_bdln_guid_ref"),
          properties.getProperty("keys_deal_ldisc_guid_ref"),
          properties.getProperty("keys_deal_guid_ref"),
          properties.getProperty("keys_deal_pqb_ref"),
          properties.getProperty("keys_deal_d_aud_rslra_ref"),
          properties.getProperty("keys_deal_d_aud_rslrb_ref"),
          properties.getProperty("keys_deal_dct_out_ref"),
          properties.getProperty("keys_deal_dct_in_ref"),
          properties.getProperty("keys_deal_atch_ref"),
          properties.getProperty("keys_deal_cmt_ref"),
          properties.getProperty("AuditTbl"),
          properties.getProperty("reprocessDays"),
          properties.getProperty("directElmtTyp",""),
          properties.getProperty("inDirectElmtTyp",""),
          properties.getProperty("totalElmtTyp",""),
          properties.getProperty("srcCol",""),
          properties.getProperty("repartitionNo",""),
          properties.getProperty("groupByKey",""),
          properties.getProperty("variableElmtTyp",""),
          properties.getProperty("batchID","")
          )

      }
      return pObj
    } catch {
      case ex: FileNotFoundException => 
        ex.printStackTrace()
        return null
      case io_ex: IOException => 
        io_ex.printStackTrace()
        return null

    }

  }

  def getFilePropertiesobject(str: String): FilePropertiesObject = {
    val propfileSystem: FileSystem = FileSystem.get(new Configuration)
    val propFileInputStream = propfileSystem.open(new Path(str))
    var properties: Properties = new Properties();
    properties.load(propFileInputStream);
    //	      var properties: Properties = null
    var pObj: FilePropertiesObject = null
    log.info("++++++++++++++++++++++++++" + str)
    try {
      //						  properties.load(new FileInputStream(str))
      //							val path = getClass.getResource(str)
      log.info("########################################Utilities::::::::::::::" + str.toString())
      if (str != null) {
        /*										val source = Source.fromURL(path)
                    properties = new Properties()
                    properties.load(source.bufferedReader())*/
        pObj = new FilePropertiesObject(
          properties.getProperty("objName"),
          properties.getProperty("dbName"),
          properties.getProperty("fileBasePath"),
          properties.getProperty("delimiter"),
          properties.getProperty("archiveFileBasePath"),
          properties.getProperty("rejectFileBasePath"),
          properties.getProperty("NulchkCol"),
          properties.getProperty("lnchkVal"),
          properties.getProperty("DtfmtchkCol"),
          properties.getProperty("intchkCol"),
          properties.getProperty("doublechkCol"),
          properties.getProperty("booleanchkCol"),
          properties.getProperty("rcdDelimiter"),
          properties.getProperty("tgtTblRw"),
          properties.getProperty("tgtTblErr"),
          properties.getProperty("tgtTblRef"),
          properties.getProperty("tgtTblEnr"),
          properties.getProperty("unqKeyCols"),
          properties.getProperty("sqlPropertyPath"),
          properties.getProperty("masterDataFields"),
          properties.getProperty("headerOptions"),
          properties.getProperty("enclosedBy"),
          properties.getProperty("refrencedColumnMap"),
          properties.getProperty("loadType"),
          properties.getProperty("customSQL"),
          properties.getProperty("rejFileForErrorRec"))
      }
      return pObj
    } catch {
      case ex: FileNotFoundException => return null
      case ex: IOException           => return null

    }

  }

  /*def getSQLPropertiesObject(path: String): SQLPropertiesObject = {
    val propfileSystem: FileSystem = FileSystem.get(new Configuration)
    val propFileInputStream = propfileSystem.open(new Path(path))
    var properties: Properties = new Properties();
    properties.load(propFileInputStream);
    //	      var properties: Properties = null
    var sqlObj: SQLPropertiesObject = null
    try {
      if (path != null) {
        sqlObj = new SQLPropertiesObject(
          properties.getProperty("mySqlHostName"),
          properties.getProperty("mySqlDBName"),
          properties.getProperty("mySqlUserName"),
          properties.getProperty("mySqlPassword"),
          properties.getProperty("mySqlPort"),
          properties.getProperty("mySqlAuditTbl"))
      }
      return sqlObj
    } catch {
      case ex: FileNotFoundException => return null
      case ex: IOException => return null

    }

  }*/

  def getTransformationPropertiesObject(path: String): TransformationPropetiesObject = {
    val propfileSystem: FileSystem = FileSystem.get(new Configuration)
    val propFileInputStream = propfileSystem.open(new Path(path))
    var properties: Properties = new Properties();
    properties.load(propFileInputStream);
    //	      var properties: Properties = null
    var sqlObj: TransformationPropetiesObject = null
    try {
      if (path != null) {
        sqlObj = new TransformationPropetiesObject(
          properties.getProperty("lookUpTables"),
          properties.getProperty("customSQL1"),
          properties.getProperty("customSQL2"))
      }
      return sqlObj
    } catch {
      case ex: FileNotFoundException => return null
      case ex: IOException           => return null

    }

  }

  def getKafkaparam(kafkaObject: KafkaPropetiesObject, envPropObj: EnvPropertiesObject): Map[String, Object] = {
    var kafkaParams = Map[String, Object](
      "bootstrap.servers" -> envPropObj.getBrokersList(),
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> kafkaObject.getConsumergroup(),
      "auto.offset.reset" -> kafkaObject.getOffsetResetVal(),
      "enable.auto.commit" -> (kafkaObject.getPropertiesObject().getAutoCommit().toBoolean: java.lang.Boolean),
      "security.protocol" -> "SSL",
      "ssl.truststore.location" -> envPropObj.getTrustStoreLoc(),
      "ssl.truststore.password" -> envPropObj.getTrustPwd(),
      "ssl.keystore.location" -> envPropObj.getKeyStoreLocation(),
      "ssl.keystore.password" -> envPropObj.getKeyStorePwd(),
      "ssl.key.password" -> envPropObj.getKeyPwd(),
      "fetch.message.max.bytes" -> "15000000",
      "max.partition.fetch.bytes" -> "15000000")

    return kafkaParams
  }

  def getConnection(envPropertiesObject: EnvPropertiesObject): Connection = {
    val host = envPropertiesObject.getMySqlHostName()
    val port = envPropertiesObject.getMySqlPort()
    val username = envPropertiesObject.getMySqlUserName()
    val password = envPropertiesObject.getMySqlPassword()
    val dbName = envPropertiesObject.getMySqlDBName()
    try {
      Class.forName("com.mysql.jdbc.Driver");
      var con: Connection = DriverManager.getConnection("jdbc:mysql://" + host + ":" + port + "/" + dbName, username, password);
      return con
    } catch {
      case e: Exception => 
        e.printStackTrace() 
        return null
    }
  }

  def insertIntoAudit(sqlcon: Connection, auditObj: AuditLoadObject, fulltblName: String) = {

    try {
      log.info("WRITING INTO AUDIT LOG -- ")
      val audBatchId = auditObj.getAudBatchId()
      val audApplicationName = auditObj.getAudApplicationName
      val audObjectName = auditObj.getAudObjectName
      val audLayerName = auditObj.getAudDataLayerName
      val audStatusCode = auditObj.getAudJobStatusCode
      val audJobEndTimestamp = auditObj.getAudJobEndTimestamp()
      val audLoadTimeStamp = auditObj.getAudLoadTimeStamp()
      val audSrcRowCount = auditObj.getAudSrcRowCount()
      val audTgtRowCount = auditObj.getAudTgtRowCount()
      val audErrorRecords = auditObj.getAudErrorRecords()
      val audCreatedBy = auditObj.getAudCreatedBy()
      val audJobStartTimestamp = auditObj.getAudJobStartTimeStamp()
      val jobDuration = auditObj.getAudJobDuration()
      val flNm = auditObj.getFlNm()
      val sysBtchNr = auditObj.getSysBtchNr()

      val auditSQL = "INSERT INTO " + fulltblName + " SELECT \"" + audBatchId + "\" as btch_id, \"" + audApplicationName + "\" as appl_nm,\"" + audObjectName + "\" as obj_nm , \"" + audLayerName + "\" as dta_lyr_nm, \"" + audStatusCode + "\" as jb_stts_cd, \"" + audJobEndTimestamp + "\" as jb_cmpltn_ts, \"" + audLoadTimeStamp + "\" as ld_ts, \"" + audSrcRowCount + "\" as src_rec_qty, \"" + audTgtRowCount + "\" as tgt_rec_qty, \"" + audErrorRecords + "\" as err_rec_qty, \"" + audCreatedBy + "\" as crtd_by_nm ,\"" + audJobStartTimestamp + "\" as jb_strt_ts,\"" + jobDuration + "\" as jb_durtn_tm_ss,\"" + flNm + "\" as fl_nm,\"" + sysBtchNr + "\" as sys_btch_nr"
      log.info("===================Print SQL :: " + auditSQL)
      val preparedStmt = sqlcon.prepareStatement(auditSQL);
      preparedStmt.execute();

      log.info("INSERTED INTO AUDIT LOG")
    } catch {
      case e: Exception => e.printStackTrace()

    }

  }

  def readHistMaxLoadTimestamp(sqlcon: Connection, objName: String): String = {
    var max_ld_ts: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(ld_ts) is NULL then '1900-01-01 00:00:00' else max(ld_ts) end as max_ld_ts from jb_aud_tbl where  dta_lyr_nm='hist_raw' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and tgt_rec_qty >0 and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("max(ld_ts)=" + rs.getTimestamp("max_ld_ts"))
        max_ld_ts = rs.getTimestamp("max_ld_ts").toString()
      }
      // close ResultSet rs
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_ld_ts
  }
  def readRefMaxLoadTimestamp(sqlcon: Connection, objName: String): String = {
    var max_ld_ts: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(ld_ts) is NULL then '1900-01-01 00:00:00' else max(ld_ts) end as max_ld_ts from jb_aud_tbl where  dta_lyr_nm='ref-snap' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        val r = rs.getArray("")
        log.info("max(ld_ts)=" + rs.getTimestamp("max_ld_ts"))
        println("---------------->>>>>>>>>>>>>Before String Convertion<<<<<<<<<--------------" + rs.getTimestamp("max_ld_ts"))
        max_ld_ts = rs.getTimestamp("max_ld_ts").toString()
        println("---------------->>>>>>>>>>>>>After String Convertion<<<<<<<<<--------------" + max_ld_ts)

        if (max_ld_ts.length() != 0) {
          val ldTsArray = max_ld_ts.split("\\.")
          if (ldTsArray(1).length() > 6) {
            val str1 = ldTsArray(0).concat(".").concat(ldTsArray(1).substring(6))
            println("---------------->>>>>>>>>>>>>After Trim Convertion<<<<<<<<<--------------" + str1)
            max_ld_ts = str1
          } else
            max_ld_ts
        } else
          max_ld_ts
      }
      // close ResultSet rs
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_ld_ts
  }
  def readRefCount(sqlcon: Connection, objName: String): Long = {
    var refCount: Option[Long] = None
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select sum(tgt_rec_qty) as ref_count from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='rw_ref' and lower(jb_stts_cd)='success' and btch_id > (select COALESCE(max(btch_id),'') from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd) ='success')"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("refCount = " + rs.getLong("ref_count"))
        refCount = Option(rs.getLong("ref_count"))
      }
      // close ResultSet rs
      rs.close();

    } catch {
      case e: Exception => e.printStackTrace()

    }
    refCount match {
      case Some(value) => value
      case None        => 0L
    }

  }
  
  def readRefCount(sqlcon: Connection, objName: String, batchIds:String): Long = {
    var refCount: Option[Long] = None
    
    try {
      val partitionsList = batchIds.split(",").map(_.trim).map(_.toString())
      var filter = ""
      partitionsList.foreach {
        x =>
          filter = filter + "'" + x + "',"
      }
      filter = filter.dropRight(1)
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select sum(tgt_rec_qty) as ref_count from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='rw_ref' and lower(jb_stts_cd)='success' and btch_id in("+filter+")"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("refCount = " + rs.getLong("ref_count"))
        refCount = Option(rs.getLong("ref_count"))
      }
      // close ResultSet rs
      rs.close();

    } catch {
      case e: Exception => e.printStackTrace()

    }
    refCount match {
      case Some(value) => value
      case None        => 0L
    }

  }
  
  def readFactCount(sqlcon: Connection, objName: String): Long = {
    var refCount: Option[Long] = None
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select sum(tgt_rec_qty) as ref_count from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd)='success' and btch_id > (select COALESCE(max(btch_id),'') from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='reftrsn_cnsmptn' and lower(jb_stts_cd) ='success')"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("refCount = " + rs.getLong("ref_count"))
        refCount = Option(rs.getLong("ref_count"))
      }
      // close ResultSet rs
      rs.close();

    } catch {
      case e: Exception => e.printStackTrace()

    }
    refCount match {
      case Some(value) => value
      case None        => 0L
    }

  }
  
  def readFactCount(sqlcon: Connection, objName: String, batchIds:String ): Long = {
    var refCount: Option[Long] = None
    
    try {
      val partitionsList = batchIds.split(",").map(_.trim).map(_.toString())
      var filter = ""
      partitionsList.foreach {
        x =>
          filter = filter + "'" + x + "',"
      }
      filter = filter.dropRight(1)
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select sum(tgt_rec_qty) as ref_count from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd)='success' and btch_id in ("+filter+")"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("refCount = " + rs.getLong("ref_count"))
        refCount = Option(rs.getLong("ref_count"))
      }
      // close ResultSet rs
      rs.close();

    } catch {
      case e: Exception => e.printStackTrace()

    }
    refCount match {
      case Some(value) => value
      case None        => 0L
    }

  }

  def consumptionEntry(sqlcon: Connection, objName: String): Boolean = {
    var consumptionName: String = ""
    try {
      log.info("Reading Consumption Entry from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select group_concat(dta_lyr_nm) as dta_lyr_nm_list from jb_aud_tbl where dta_lyr_nm='cnsmptn' and lower(jb_stts_cd) = 'success' and obj_nm='" + objName + "'"
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      while (rs.next()) {
        log.info("consumptionName" + rs.getString("dta_lyr_nm_list"))
        if (rs.getString("dta_lyr_nm_list") == null)
          consumptionName = ""
        else
          consumptionName = rs.getString("dta_lyr_nm_list")
      }
      rs.close();

    } catch {
      case e: Exception => e.printStackTrace()

    }
    if (consumptionName.isEmpty) {
      true
    } else {
      false
    }

  }

  @scala.annotation.tailrec
  def getResult(resultSet: ResultSet, list: List[String] = Nil): List[String] = {
    if (resultSet.next()) {
      val value = resultSet.getString("btch_id").trim()
      getResult(resultSet, value :: list)
    } else {
      list
    }
  }

  /**
   * @param sqlcon
   * @param objName
   * @return
   */
  def readRefBatchIdList(sqlcon: Connection, objName: String): List[String] = {

    var btch_id_list: List[String] = Nil

    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select btch_id from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='rw_ref' and lower(jb_stts_cd) ='success' and btch_id > (select COALESCE(max(btch_id),'') from amc.jb_aud_tbl where obj_nm='" + objName + "' and dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd) ='success')"
      //val auditSQL = "select sum(tgt_rec_qty) sum from jb_aud_tbl where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and obj_nm='" + objName + "' group by dta_lyr_nm"

      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      btch_id_list = getResult(rs)
      //Extact result from ResultSet rs
      /* while (rs.next()) {
        log.info("max(tgt_rec_qty)=" + rs.getArray("btch_id_list"))
        btch_id_list = btch_id_list :: rs.getArray("btch_id_list")
      }*/
      // close ResultSet rs
      rs.close()

    } catch {
      case e: Exception => e.printStackTrace()

    }
    btch_id_list
  }

  def readRefBatchId(sqlcon: Connection, objName: String): String = {
    var max_ld_ts: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select max(btch_id) from jb_aud_tbl where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("max(btch_id)=" + rs.getTimestamp("max_ld_ts"))
        max_ld_ts = rs.getTimestamp("max_ld_ts").toString()
      }
      // close ResultSet rs
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_ld_ts
  }
	
def readMaxRefBatchId(sqlcon: Connection, objName: String): String = {
    
    var btch_id: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      
      /*val auditSQL = "select btch_id from amc.jb_aud_tbl main where obj_nm='"+srcObjName+"' and dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and btch_id > (select COALESCE(max(btch_id),'') as batch_id from amc.jb_aud_tbl where obj_nm='"+trgObjName+"' and dta_lyr_nm='"+dataLayerName+"');";*/ 
      val auditSQL = "select COALESCE(max(btch_id),'19001231000000') as btch_id  from amc.jb_aud_tbl where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      /*btch_id_list = getResult(rs)*/
      //Extact result from ResultSet rs
      
     while (rs.next()) {
        log.info("btch_id=" + rs.getString("btch_id"))
        btch_id = rs.getString("btch_id")
      }
      // close ResultSet rs
      println ("list of batch ids needs to be refreshed"+ btch_id)
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    btch_id
  }	

def readRefBatchId(sqlcon: Connection, objName: String,audTbl:String): String = {
    var max_btch_id: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(btch_id) is NULL then '1900-01-01 00:00:00' else max(btch_id) end as max_btch_id from "+audTbl+" where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      
      while (rs.next()) {
        log.info("max(btch_id)=" + rs.getString("max_btch_id"))
        max_btch_id = rs.getString("max_btch_id")
        
      }
      
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_btch_id
  }
  
  def readCnsmptnBatchId(sqlcon: Connection, objName: String,audTbl: String): String = {
    var max_btch_id: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(btch_id) is NULL then '1900-01-01 00:00:00' else max(btch_id) end as max_btch_id from "+audTbl+" where dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd) = 'success' and ld_ts <> '9999-12-31 00:00:00' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      
      val rs: ResultSet = stmt.executeQuery(auditSQL)
   
      while (rs.next()) {
        log.info("max(btch_id)=" + rs.getString("max_btch_id"))
        max_btch_id = rs.getString("max_btch_id")
      }
      
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_btch_id
  }
	
  def validateNotNull(sqlContext: HiveContext, df: DataFrame, primary_key_col_list: List[String]): List[DataFrame] = {
    var primary_correct_col = ""
    var primary_incorrect_col = ""

    for (z <- primary_key_col_list) {
      primary_correct_col = primary_correct_col + "and length(trim(" + z + "))>0 and  trim(" + z + ")<>'(null)' and trim(" + z + ") not like '%?'"
      primary_incorrect_col = primary_incorrect_col + "OR " + z + " is null OR length(trim(" + z + "))=0  OR trim(" + z + ")='(null)' OR trim(" + z + ") like '%?'"
    }
    df.show
    df.createOrReplaceTempView("null_data")
    val valid_select_query = "select * from null_data where " + (primary_correct_col.drop(3))
    val invalid_select_query = "select * from null_data where " + (primary_incorrect_col.drop(2))

    log.info("valid_records_query:- " + valid_select_query)
    log.info("invalid_records_query:- " + invalid_select_query)

    val validDF = sqlContext.sql(valid_select_query)
    val invalidDF = sqlContext.sql(invalid_select_query)
    List(validDF, invalidDF)
  }

  def convertDateTime(dt: String, fmt: String): String = {
    try {
      val dateFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern(fmt)
      val jodatime: DateTime = dateFormatGeneration.parseDateTime(dt);
      val str: String = ISOFormatGeneration.print(jodatime);
      str
    } catch {
      case xe: IllegalArgumentException => return null
      case xe: NullPointerException     => return null
    }
  }

  /**
   * getCurrentTimestamp function returns the current timestamp in ISO format
   *
   * @return : current timestamp in ISO format
   */
  def getCurrentTimestamp(): String = {
    val ISOFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS");
    val now: DateTime = new org.joda.time.DateTime()
    ISOFormatGeneration.print(now)
  }

  def getCurrentTimestamp(format: String): String = {
    val ISOFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern(format)
    //("yyyy-MM-dd HH:mm:ss.SSS");
    val now: DateTime = new org.joda.time.DateTime()
    ISOFormatGeneration.print(now)
  }

  def addNullCurrConvCols(exchngType: String, finalDF2: DataFrame): DataFrame = {

    //  var exchngType = "Budget"
    var finalDF = finalDF2
    // if (!finalDF2.columns.contains(exchngType + "_Currency_Rate_Valid")) {
    finalDF = finalDF.withColumn(exchngType + "_Currency_Rate_Valid", lit(null: String).cast(StringType)).withColumn("OPE_" + exchngType + "_Rate", lit(null: String).cast(StringType)).withColumn("OPE_" + exchngType + "_Rate_Amount_USD", lit(null: String).cast(StringType))

    finalDF

  }

  /**
   * @param hiveContext
   * @param dbName
   * @param tgtTableName
   * @return
   */
  def getTableCount(hiveContext: HiveContext, dbName: String, tgtTableName: String): Long = {
    val tableName = dbName + "." + tgtTableName
    val df = hiveContext.table(tableName)
    return df.count()
  }

  /**
   * storeDataFrame function stores the data frame to input HIVE table
   *
   * @param transformedDF : DataFrame to be stored
   * @param saveMode      : Mode of saving (OverWrite,Append,Ignore,ErrofIfExists)
   * @param storageFormat : Storage format for the target table (ORC,Parquet etc)
   * @param targetTable   :	Target HIVE table name with Database name
   * @return Boolean			: flag to indicate if the action was successful or not
   */
  def storeDataFrame(transformedDF: DataFrame, saveMode: String, storageFormat: String, targetTable: String): Boolean = {
    try {
      val tblCount = transformedDF.count
      log.info("Writing to HIVE TABLE : " + targetTable + " :: DataFrame Count :" + tblCount)
      if (tblCount > 0 && transformedDF != null && saveMode.trim().length() != 0 && storageFormat.trim().length() != 0 && targetTable.trim().length() != 0) {
        log.info("SAVE MODE::" + saveMode + " Table Name :: " + targetTable + " Format :: " + storageFormat)
        transformedDF.write.mode(saveMode).format(storageFormat.trim()).insertInto(targetTable.trim())
        return true
      } else {
        return false
      }

    } catch {
      case e: Exception =>
        e.printStackTrace();
        log.error("ERROR Writing to HIVE TABLE : " + targetTable);
        return false;
    }
  }
  
  /**
   * storeDataFrame function stores the data frame to input HIVE table
   *
   * @param transformedDF : DataFrame to be stored
   * @param saveMode      : Mode of saving (OverWrite,Append,Ignore,ErrofIfExists)
   * @param storageFormat : Storage format for the target table (ORC,Parquet etc)
   * @param targetTable   :	Target HIVE table name with Database name
   * @return Boolean			: flag to indicate if the action was successful or not
   */
  def storeDataFrame(transformedDF: DataFrame, saveMode: String, storageFormat: String, targetTable: String, numPartitions: Integer): Boolean = {
    try {
      val tblCount = transformedDF.count
      log.info("Writing to HIVE TABLE : " + targetTable + " :: DataFrame Count :" + tblCount)
      if (tblCount > 0 && transformedDF != null && saveMode.trim().length() != 0 && storageFormat.trim().length() != 0 && targetTable.trim().length() != 0) {
        log.info("SAVE MODE::" + saveMode + " Table Name :: " + targetTable + " Format :: " + storageFormat)
        transformedDF.coalesce(numPartitions).write.mode(saveMode).format(storageFormat.trim()).insertInto(targetTable.trim())
        return true
      } else {
        return false
      }

    } catch {
      case e: Exception =>
        e.printStackTrace();
        log.error("ERROR Writing to HIVE TABLE : " + targetTable);
        return false;
    }
  }

  /**
   * @param rdd
   * @return
   */
  def hive_json_mapper(rdd: RDD[String]): String = {
    var sql = ""
    rdd.collect.foreach { x =>
      val cols = x.split(';').toList
      cols.foreach { y =>
        sql = sql + y.replace("|", " AS ") + ","
      }
    }
    sql = sql.dropRight(1)
    return sql
  }

  def getJsonHeaders(rdd: RDD[String], dlmit: String): String = {
    var stringHeader: String = ""
    rdd.collect.foreach { x =>
      val cols = x.split(';').toList
      cols.foreach { y =>
        stringHeader = stringHeader.trim() + y.split("\\|")(0).trim() + dlmit.trim()
      }
    }
    stringHeader = stringHeader.substring(0, stringHeader.lastIndexOf(dlmit))
    return stringHeader
  }

  def final_hive_json_mapper(rdd: RDD[String]): String = {
    var sql = ""
    rdd.collect.foreach { x =>
      val cols = x.split(';').toList
      cols.foreach { y =>
        sql = sql + y.replace("|", " AS ") + ","
      }
    }
    sql = "select " + sql.dropRight(1) + " FROM Temp_DF"
    return sql
  }

  def prepareDateDoubleFormatQuery(colList: Array[String], dtFmtCol: String, doubleCol: String): String = {
    var sql = ""
    var hm: Map[String, String] = scala.collection.mutable.Map[String, String]()
    var dCol: List[String] = List()
    if (doubleCol != null && doubleCol.size != 0) {
      dCol = doubleCol.split(",").toList
    }
    if (dtFmtCol != null && dtFmtCol.size != 0) {
      val colArray = dtFmtCol.split(',').toList

      colArray.foreach { x =>
        //if(x.split('|').toList(1).trim().length()<=10){
        hm.put(x.split('|').toList(0).trim().toLowerCase(), x.split('|').toList(1).trim())
        //}
      }
    }
    colList.foreach { x =>
      if (hm.contains(x)) {
        sql = sql + "case when " + x + " in ('0','00000000') then null else from_unixtime(unix_timestamp(" + x + " ,'" + hm.getOrElse(x, "yyyy-MM-dd HH:mm:ss") + "'), 'yyyy-MM-dd HH:mm:ss')" + " end AS " + x + ","
      } else if (dCol.contains(x)) {
        sql = sql + "CAST ( " + x + " AS DOUBLE ) AS " + x + ","
      } else {
        sql = sql + x + " AS " + x + ","
      }
    }
    sql = "select " + sql.dropRight(1) + " FROM Temp_DF"
    return sql

  }

  def prepareConsumptionQuery(colList: Array[String]): String = {
    var sql = ""

    colList.foreach { x =>

      sql = sql + x + " AS " + x + ","

    }
    sql = "select " + sql.dropRight(1) + " FROM temp_view"
    return sql

  }

  /**
   * @param sqlQuery
   * @param colMap
   * @return
   */
  def sqlGenerator(sqlQuery: String, colMap: Map[String, List[String]]): Map[String, String] = {
    var colWithSQL = scala.collection.mutable.Map[String, String]()

    for ((cols, listNull) <- colMap) {
      var sql = sqlQuery
      listNull.foreach { x =>
        sql = sql.replaceAllLiterally(x + " AS", "NULL AS")
      }
      colWithSQL(cols) = "select " + sql + " FROM Temp_DF"
    }
    return colWithSQL
  }

  /**
   * @param str
   * @return
   */
  def jsonToString(str: String, delimeter: String, header: String): String = {
    try {
      val flatMe = new JFlat(str);

      return flatMe.json2Sheet().headerSeparator("_").write2csv(delimeter)
    } catch {
      case ex: Exception =>
        //log.fatal("Exception while parsing JSON")
        log.fatal("Exception Parsing JSON:" + ex)
        //System.exit(1)
        var error = StringBuilder.newBuilder
        error.append("\n")
        val list: Array[String] = header.split(delimeter)
        var count: Int = 0
        for (fileds <- list) {
          if (count == 0) {
            //val subEx = ex.getCause.toString().replaceAll("\n", " ")
            error.append(" Exception while Parsing JSON : " + str.substring(0, 100) + ".... with exception :" + ex.getCause).append(delimeter)
          } else {
            error.append("N/A").append(delimeter)
          }
          count = count + 1
        }
        // error =
        return header + error.substring(0, error.lastIndexOf(delimeter))
      //val flatMe = new JFlat("{\"LastModifiedDate\":\"Exception Parsing JSON\"}");
      //return flatMe.json2Sheet().headerSeparator("_").write2csv(delimeter)

    }
  }

  /**
   * @param str
   * @return
   */
  def generateHiveColumns(rdd: RDD[String]): List[String] = {
    var hiveColList = List[String]()
    rdd.collect.foreach { x =>
      val mapList = x.split(";").toList
      mapList.foreach { x =>
        hiveColList = x.split("\\|")(0).trim() :: hiveColList
      }
      hiveColList = hiveColList.filter(_ != "NULL")
    }
    return hiveColList
  }

  def generateHeaderMap(jsonHeaderDF: DataFrame, jsonColList: List[String], delimter: String): Map[String, List[String]] = {
    var headerMap = scala.collection.mutable.Map[String, List[String]]()

    jsonHeaderDF.rdd.map(_.getString(0)).collect().foreach { x =>
      log.info("==================================headerColumn======" + x)
      var p = x.split(delimter, -1).toList
      p = jsonColList.diff(p)
      headerMap(x) = p
    }
    return headerMap
  }

  def insert(list: List[String], i: Int, value: String): List[String] = {
    val (front, back) = list.splitAt(i)
    front ++ List(value) ++ back
  }

  /*def nullPutUDF(str: String, delimeter: String, header: String, cols: String): String = {
    import collection.breakOut
    var colList: List[String] = cols.split(delimeter).map(_.trim)(breakOut)
    var trimmedList: List[String] = str.split(delimeter).map(_.trim)(breakOut)
    var headerTrimmedList: List[String] = header.split(delimeter).map(_.trim)(breakOut)
    var i = 0;
    for (i <- 0 to colList.size - 1) {
      if (i > headerTrimmedList.size - 1) {
        trimmedList = Utilities.insert(trimmedList, i, null)
        headerTrimmedList = Utilities.insert(headerTrimmedList, i, null)
      } else if (!colList(i).equalsIgnoreCase(headerTrimmedList(i))) {
        trimmedList = Utilities.insert(trimmedList, i, null)
        headerTrimmedList = Utilities.insert(headerTrimmedList, i, null)
      }

    }
    return trimmedList.mkString(delimeter)



  }*/
  def CreateMap(data: List[String], header: List[String]): Map[String, String] = {
    import scala.collection.breakOut
    val hm: LinkedHashMap[String, String] = (header zip data)(breakOut)
    return hm
  }

  def nullPutUDF(str: String, delimeter: String, header: String, cols: String): String = {

    import collection.breakOut
    var colList: List[String] = cols.toUpperCase().split(delimeter).map(_.trim)(breakOut)
    var trimmedList: List[String] = str.split(delimeter, -1).map(_.trim)(breakOut)
    var headerTrimmedList: List[String] = header.toUpperCase().split(delimeter, -1).map(_.trim)(breakOut)
    var hm: Map[String, String] = CreateMap(trimmedList, headerTrimmedList)
    var fullMap: Map[String, String] = collection.mutable.LinkedHashMap[String, String]()
    /*for(i <- 0 until colList.size)
{
	val newKey:String=colList(i).toUpperCase()
	val newVal:String=hm.getOrElse(newKey, "\"null\"")
	fullMap.put(newKey, newVal)
}*/
    colList.foreach { x =>
      val newKey: String = x.toUpperCase()
      var newVal: String = hm.getOrElse(newKey, "")
      val tags = "a|abbr|acronym|address|applet|area|article|aside|audio|b|base|basefont|bdo|big|blockquote|body|br|button|canvas|caption|center|cite|code|col|colgroup|datalist|dd|del|dfn|div|dl|dt|em|embed|fieldset|figcaption|figure|font|footer|form|frame|frameset|head|header|h1|h2|h3|h4|h5|h6|hr|html|i|iframe|img|input|ins|kbd|label|legend|li|link|main|map|mark|meta|meter|nav|noscript|object|ol|optgroup|option|p|param|pre|progress|q|s|samp|script|section|select|small|source|span|strike|strong|style|sub|sup|table|tbody|td|textarea|tfoot|th|thead|time|title|tr|u|ul|var|video|wbr"
      if (newVal.contains("/>") || newVal.contains("</") || newVal.contains("<br>") || newVal.contains("<area>") || newVal.contains("<base>") || newVal.contains("<col>") || newVal.contains("<hr>") || newVal.contains("<img>") || newVal.contains("<input>") || newVal.contains("<link>") || newVal.contains("<meta>") || newVal.contains("<param>") || newVal.contains("<source>")) newVal = newVal.replaceAll("\\<(" + tags + ").*?>", " ").replaceAll("\\</(" + tags + ").*?>", " ").replaceAll("\\\\\\\\", "\\\\") else newVal = newVal.replaceAll("\\\\\\\\", "\\\\")
      if (newVal != null && newVal.length() > 2) {
        newVal = "\"" + newVal.substring(1, newVal.length() - 1).trim() + "\""
      }
      fullMap.put(newKey, newVal)
    }
    fullMap.valuesIterator.toList.mkString(delimeter)

  }

  def generateSeqID(naturalKey: String): Long = {
    var m: MessageDigest = null
    var seqId: Long = 0
    try {
      m = MessageDigest.getInstance("MD5")
      m.reset()
      m.update(naturalKey.getBytes, 0, naturalKey.getBytes.length)
      val digest: Array[Byte] = m.digest()
      val bigInt: BigInteger = new BigInteger(digest)
      val original: Long = bigInt.longValue()
      var signum: Int = java.lang.Long.signum(original)
      seqId = original
      while (signum == -1) {
        val m1: MessageDigest = MessageDigest.getInstance("MD5")
        m1.reset()
        m1.update(("" + seqId).getBytes, 0, ("" + seqId).getBytes.length)
        val digest1: Array[Byte] = m1.digest()
        val bigInt1: BigInteger = new BigInteger(digest1)
        seqId = bigInt1.longValue()
        signum = java.lang.Long.signum(seqId)
      }
    } catch {
      case e: NoSuchAlgorithmException => e.printStackTrace()
    }
    seqId
  }
  
  def crc64(naturalKey: String, salt: String): Long = {
    val tableDriven:CRC = new CRC(CRC.Parameters.CRC64ECMA)
    return salt.toLong+tableDriven.calculateCRC(naturalKey.getBytes());
  }

  
  def readRefBatchIdListNew(sqlcon: Connection, objName: String,auditTbl: String): List[String] = {

    var btch_id_list: List[String] = Nil

    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select btch_id from "+auditTbl+" where obj_nm='" + objName + "' and dta_lyr_nm='rw_ref' and lower(jb_stts_cd) ='success' and reverse(substring(reverse(COALESCE(btch_id,'')),1,instr(reverse(COALESCE(btch_id,'')),'_')-1)) > (select reverse(substring(reverse(COALESCE(max(btch_id),'')),1,instr(reverse(COALESCE(max(btch_id),'')),'_')-1)) from "+auditTbl+" where obj_nm='" + objName + "' and dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd) ='success')"
      //val auditSQL = "select sum(tgt_rec_qty) sum from jb_aud_tbl where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and obj_nm='" + objName + "' group by dta_lyr_nm"

      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      btch_id_list = getResult(rs)
      //Extact result from ResultSet rs
      /* while (rs.next()) {
        log.info("max(tgt_rec_qty)=" + rs.getArray("btch_id_list"))
        btch_id_list = btch_id_list :: rs.getArray("btch_id_list")
      }*/
      // close ResultSet rs
      rs.close()

    } catch {
      case e: Exception => e.printStackTrace()

    }
    btch_id_list
  } 
  
  def readFactBatchIdListNew(sqlcon: Connection, objName: String,auditTbl: String): List[String] = {

    var btch_id_list: List[String] = Nil

    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select btch_id from "+auditTbl+" where obj_nm='" + objName + "' and dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd) ='success' and reverse(substring(reverse(COALESCE(btch_id,'')),1,instr(reverse(COALESCE(btch_id,'')),'_')-1)) > (select reverse(substring(reverse(COALESCE(max(btch_id),'')),1,instr(reverse(COALESCE(max(btch_id),'')),'_')-1)) from "+auditTbl+" where obj_nm='" + objName + "' and dta_lyr_nm='reftrsn_cnsmptn' and lower(jb_stts_cd) ='success')"
      //val auditSQL = "select sum(tgt_rec_qty) sum from jb_aud_tbl where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and obj_nm='" + objName + "' group by dta_lyr_nm"

      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      btch_id_list = getResult(rs)
      //Extact result from ResultSet rs
      /* while (rs.next()) {
        log.info("max(tgt_rec_qty)=" + rs.getArray("btch_id_list"))
        btch_id_list = btch_id_list :: rs.getArray("btch_id_list")
      }*/
      // close ResultSet rs
      rs.close()

    } catch {
      case e: Exception => e.printStackTrace()

    }
    btch_id_list
  } 
  /*def nullifyEmptyStrings(df: DataFrame): DataFrame = {
    var in = df
    for (e <- df.columns) {
      in = in.withColumn(e, when(length(col(e)) === 0, lit(null: String)).otherwise(col(e)))
    }
    */
  /**
   *
   * To be re-visited for performance check
   * val hm=scala.collection.immutable.HashMap(""->"null")
   * val hmm = hm+(""->null)
   *
   * val in=df.na.replace(df.columns.toSeq,hmm.toMap)
   *
   */ /*

    in
  }*/

  def nullifyEmptyStrings(df: DataFrame): DataFrame = {
    val sqlCtx = df.sqlContext
    val schema = df.schema
    val updatedField = schema.map(x => StructField(x.name, x.dataType, true))
    val updatedSchema = StructType(updatedField)
    val rdd = df.rdd.map(
      row =>
        row.toSeq.map {
          case ""        => null
          case otherwise => otherwise
        })
      .map(Row.fromSeq)

    sqlCtx.createDataFrame(rdd, updatedSchema)
  }

  /**
   * trimAllColumns function is used to trim both trailing and leading whitespaces
   */
  def trimAllColumns(df: DataFrame): DataFrame = {
    var inDf = df
    for (c_name <- df.columns) {
      inDf = inDf.withColumn(c_name, trim(col(c_name)))
    }

    inDf
  }

  def performCDC(sqlContext: SQLContext, history_df: DataFrame, incremental_df: DataFrame, primary_key_col_list: Array[String]): DataFrame = {
    import sqlContext.implicits._
    log.info("Starting CDC")
    val dataSchema = history_df.columns
    //    val final_incremental_df = incremental_df.except(history_df)
    val dfInnerJoin = history_df.filter(col("dl_load_flag")
      .eqNullSafe("Y")).as("L1").join(broadcast(incremental_df), primary_key_col_list)
      .select($"L1.*").select(dataSchema.head, dataSchema.tail: _*)
    val unchangedData = history_df.except(dfInnerJoin)
    val changedData = dfInnerJoin.drop("dl_load_flag").withColumn("dl_load_flag", lit("N")).select(dataSchema.head, dataSchema.tail: _*)
    val finalData = unchangedData.unionAll(incremental_df.drop("dl_load_date").withColumn("dl_load_date", lit(getCurrentTimestamp)).select(dataSchema.head, dataSchema.tail: _*))
      .unionAll(changedData)
    log.info("Completed CDC !!!")
    finalData
  }

  /**
   * validateNotNull function checks whether the primary key column has
   * Null values and if any, loads them to the error table
   *
   * @param SQLContext
   * @param DataFrame which contains the input table data
   * @param List      which contains the primary key columns read from the yaml file
   * @return DataFrame of valid and invalid records
   */

  def validateNotNull(sqlContext: SQLContext, df: DataFrame, primary_key_col_list: List[String]): List[DataFrame] = {
    var primary_correct_col = ""
    var primary_incorrect_col = ""

    for (z <- primary_key_col_list) {
      primary_correct_col = primary_correct_col + "and length(trim(" + z + "))>0 and  trim(" + z + ")<>'(null)' and trim(" + z + ") not like '%?'"
      primary_incorrect_col = primary_incorrect_col + "OR " + z + " is null OR length(trim(" + z + "))=0  OR trim(" + z + ")='(null)' OR trim(" + z + ") like '%?'"

    }
    df.registerTempTable("incoming_data")
    val valid_select_query = "select * from incoming_data where " + (primary_correct_col.drop(3))
    val invalid_select_query = "select * from incoming_data where " + (primary_incorrect_col.drop(2))

    log.info("valid_records_query:- " + valid_select_query)
    log.info("invalid_records_query:- " + invalid_select_query)

    val validDF = sqlContext.sql(valid_select_query)
    val invalidDF = sqlContext.sql(invalid_select_query)

    List(validDF, invalidDF)

  }

  /**
   * ValidateReferentialIntegrity function checks if all the
   * referential integrity constrains are satisfied and if not,
   * loads those records to the error table
   *
   * @param SQLContext
   * @param HashMap
   * @param DataFrame contains the input table data
   * @param List      contains the columns to be checked for referential integrity, read from the yaml file
   * @return DataFrame records which satisfy and don't satisfy the constraint
   */

  def validateReferentialIntegrity(sqlContext: SQLContext, m: HashMap[String, String], dfInput: DataFrame, colNames: List[String]): List[DataFrame] = {
    val colList = m.keySet().toArray().toList
    var trueList = dfInput
    var falseList = dfInput.limit(0)
    for (list <- colList) {
      val stringToSplit = m.get(list).toUpperCase()

      val finalArray = stringToSplit.split(",")
      val inListInter: (String => String) = (arg: String) => {
        if (finalArray.contains(arg.toUpperCase())) "true" else "false"
      }
      val sqlfunc = udf(inListInter)

      val interDF = dfInput.withColumn("Result", sqlfunc(col(list.toString())))
      interDF.registerTempTable("interDF_tbl")

      val resdf = sqlContext.sql("""select * from interDF_tbl where Result = "false"""")
      val falseListInter = resdf.drop("Result")
      falseList = falseList.unionAll(falseListInter)

    }
    if (!(colNames.isEmpty)) {
      falseList = falseList.dropDuplicates(colNames)
    }
    List(trueList, falseList)
  }

  /**
   * ValidateDateFormat function checks if the date fields
   * in the data frame are in the format expected in yaml file
   * and if not, load those records to the error table
   *
   * @param SparkContext
   * @param SQLContext
   * @param DataFrame contains the records which passed the referential integrity check
   * @param HashMap
   * @return DataFrame data set of all and error records
   */

  def historyCheck(sqlcon: Connection, auditObj: AuditLoadObject, fileName: String, fulltblName: String): Boolean = {
    log.info("Reading from Audit table")

    var status: Boolean = false
    try {
      //checking the file is already loaded to the table or not.
      val stmt: Statement = sqlcon.createStatement()

      val auditSQL = "select * from " + fulltblName + " where fl_nm=\"" + fileName + "\" and jb_stts_cd = \"success\""
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      if (rs.getRow > 0) {
        log.info("File has already been ingested")
        status = false
      } else {
        status = true
      }
      // close ResultSet rs
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    return status
  }

  def archiveFile(fileLocation: String, archiveLocation: String, fs: FileSystem): Unit = {
    //log.info("hadoop fs -mv " + fileLocation + " " +"hdfs://EAHPEDEV"+archiveLocation)
    log.info(archiveLocation + fileLocation.toString().substring(fileLocation.toString().lastIndexOf("/") + 1))
    fs.rename(new Path(fileLocation), new Path(archiveLocation + fileLocation.toString().substring(fileLocation.toString().lastIndexOf("/") + 1)))
    //val processStatus: Process  = Process("hadoop fs -mv " + fileLocation + " " +"hdfs://EAHPEDEV"+archiveLocation).run()
    /*val processStatus: Process  = Process(s"""hdfs dfs -mv $fileLocation $archiveLocation""").run()

    log.info("archival status:" + processStatus)
    if (processStatus == 0)
      return true
    else
      return false
      *
      */
  }

  def truncateTable(dbName: String, tableName: String, sqlc: HiveContext): Boolean = {
    try {
      sqlc.sql(f"""insert overwrite table $dbName.$tableName select * from $dbName.$tableName limit 0 """)
      var noOfRecords = sqlc.sql(f"""select count(1) from $dbName.$tableName""")
      log.info("no of records in table :" + noOfRecords.count())
      if (noOfRecords.count() > 1)
        return false
      else
        return true
    } catch {
      case t:
        Throwable => log.error(tableName + " not found in the database" + dbName); return true

    }

  }

  def validateHeader(inputRDD: RDD[String], indicator: String): RDD[String] = {
    val headerrDD = inputRDD.first()
    val rawinputRDD = inputRDD.filter(row => row != headerrDD)
    return rawinputRDD
  }

  def checkForRfrentilaIntegrity(sqlcontext: SQLContext, bmtcol: ListBuffer[String], m: HashMap[String, String], inputDF: DataFrame): Boolean = {

    val refrencetable = m.keySet().toArray().toList
    val maptoBMTcol = bmtcol.map(x => col(x))
    val validationdf = inputDF.select(maptoBMTcol: _*)

    for (table <- refrencetable) {
      val stringToSplit = m.get(table).toUpperCase()
      val finalArray = stringToSplit.split(",").toArray.toList
      val refrenceCol = finalArray.map(c => col(c))
      val refrenceDF = sqlcontext.sql(f"""select * from $table""")
      val maptoCol = refrenceDF.select(refrenceCol: _*)

      if (validationdf.except(refrenceDF).count() > 0) {
        return false
        break()
      }
    }

    return true
  }

  def getcurrCastFields(result: DataFrame, currCol: String): DataFrame = {

    var tempDF: DataFrame = result
    try {

      tempDF = tempDF.withColumn(currCol, when(trim(tempDF.col(currCol)).contains("-")
        && locate("-", trim(tempDF.col(currCol))) === length(trim(tempDF.col(currCol))), concat(lit("-"), regexp_replace(trim(tempDF.col(currCol)), "-", "")))
        .otherwise(trim(tempDF.col(currCol))))
    } catch {
      case ex: Exception => ex.printStackTrace()
    }
    return tempDF
  }
  def getEnvPropertiesobject(str: String, sk:SKeyObject): EnvPropertiesObject =
    {

      import scala.collection.JavaConversions._
      try {
        val propfileSystem: FileSystem = FileSystem.get(new Configuration)
        val propFileInputStream = propfileSystem.open(new Path(str))
        var properties: Properties = new Properties();
        properties.load(propFileInputStream);
        var pObj: EnvPropertiesObject = null
        log.info("++++++++++++++++++++++++++" + str)

        log.info("########################################Utilities::::::::::::::" + str.toString())
        if (str != null) {
          pObj = new EnvPropertiesObject(
            properties.getProperty("brokersList"),
            properties.getProperty("trustStoreLocString"),
            AES.decrypt(properties.getProperty("trustPwd"),sk.getSKey()),
            properties.getProperty("keyStoreLocation"),
            AES.decrypt(properties.getProperty("keyStorePwd"),sk.getSKey()),
            AES.decrypt(properties.getProperty("keyPwd"),sk.getSKey()),
            properties.getProperty("mySqlHostName"),
            properties.getProperty("mySqlDBName"),
            properties.getProperty("mySqlUserName"),
            AES.decrypt(properties.getProperty("mySqlPassword"),sk.getSKey()),
            properties.getProperty("mySqlPort"),
            properties.getProperty("mySqlAuditTbl"),
            properties.getProperty("ambariHost"),
            properties.getProperty("ambariPort"),
            properties.getProperty("ambariUser"),
            AES.decrypt(properties.getProperty("ambariPwd"),sk.getSKey()),
            properties.getProperty("clusterName"),
            properties.getProperty("rmPort"),
            properties.getProperty("rmUser"),
            AES.decrypt(properties.getProperty("rmPwd"),sk.getSKey()))
        }
        return pObj
      } catch {
        case ex: FileNotFoundException =>
          {
            log.error("Please place the \"connection.properties\" file in " + str + " path")
            sys.exit(1)
          }
        case ex: IOException => { sys.exit(1) }

      }

    }
  
  def getSKeyPropertiesobject(str: String): SKeyObject =
  {
    val propfileSystem: FileSystem = FileSystem.newInstance(new Configuration)
    val propFileInputStream = propfileSystem.open(new Path(str))
    try {
      var properties: Properties = new Properties();
      properties.load(propFileInputStream);
      var pObj: SKeyObject = null
      log.info("++++++++++++++++++++++++++" + str)

      log.info("########################################Utilities::::::::::::::" + str.toString())
      if (str != null) {
        pObj = new SKeyObject(
          properties.getProperty("sKey")
        )
      }
      return pObj
    } catch {
      case ex: FileNotFoundException =>
      {log.error("Please place the \"sKey\" file in "+str+" path"  )
        sys.exit(1)}
      case ex: IOException           => {sys.exit(1)}

    }finally{
      if(propFileInputStream!=null){
        propFileInputStream.close()
      }
      if(propfileSystem!=null){
        propfileSystem.close()
      }
      
    }

  }
  
  def getLatestRecs(df: DataFrame, partition_col: List[String], sortCols: List[String]): DataFrame = {
    val part = Window.partitionBy(partition_col.head, partition_col: _*).orderBy(array(sortCols.head, sortCols: _*).desc)
    val rowDF = df.withColumn("rn", row_number().over(part))
    val res = rowDF.filter("rn==1").drop("rn")
    res
  }
  /**
   * save dataframe into external table after switching the location.
   *
   *
   * @param df									: Input DataFrame
   * @param saveMode   					: Different mode of saving like Append or Overwrite
   * @param storageFormat				: Storage format in hive table like ORC
   * @param targetTable					:	Target table name with database eg(ea_fin.expns_rpt_trsn)
   * @param configurationObject	:	com.hpe.config.ConfigObjectNonStreaming
   * @return boolean   				  : returns true or false based on success or failure
   */
  def storeDataFrame(df: DataFrame, saveMode: String, storageFormat: String, targetTable: String, configurationObject: ConfigObject): Boolean = {
    //def switchExternalTableLocation(df: DataFrame, configurationObject: ConfigObjectNonStreaming, dbName: String, tableName: String): Boolean = {
    try {
      if (saveMode.equalsIgnoreCase("overwrite")) {
        val spark = configurationObject.getSpark()

        val dbName = targetTable.split("\\.")(0)
        val tableName = targetTable.split("\\.")(1)
        var currLoc: String = null

        //Current Location in Spark 2.2///
        /* val metadata = spark.sharedState.externalCatalog.getTable(finalDbName, tableName)
    		 val currLoc = metadata.location.toString()*/
        //End of spark 2.2 current location//

        //Current Location in spark 2.1///
        import spark.implicits._
        val dfLoc = spark.sql("describe formatted " + dbName + "." + tableName)
        val rows = dfLoc.filter(dfLoc("col_name").contains("Location") && dfLoc("data_type").contains("hdfs://")).select("data_type").as[String].collect

        currLoc = rows(0)

        //for (location <- rows) { currLoc = location }
        //End of spark 2.2 current location//
        val my_df  = spark.sql("Select * from " + dbName + "." + tableName+" limit 1")
        val my_schema: StructType = my_df.schema;
        val fields: Array[StructField] = my_schema.fields;
        var fieldStr = ""
        fields.foreach { f =>
          fieldStr = fieldStr + f.name + " " + f.dataType.typeName + ",";
        }

        var writeLocation: String = null
        if (currLoc != null && (currLoc takeRight (1)).equals("2")) {
          writeLocation = currLoc.substring(0, currLoc.length() - 1)
        } else {
          writeLocation = currLoc + "2"
        }

        log.info("#######Curr Location::::=" + currLoc + " Write Location is::::::=" + writeLocation)
        
        //df.write.mode("Overwrite").format("ORC").save(writeLocation)
        //create the table using the dataframe schema
        spark.sql("create table if not exists " + dbName + "." + tableName + "_temporary(" + fieldStr.substring(0, fieldStr.length() - 1) +
          ") ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde' STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat' OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat' LOCATION  '" + writeLocation + "'")
        
        //Temp Table DDL
        log.info("Temp Table DDL is###############: "+"create table if not exists " + dbName + "." + tableName + "_temporary(" + fieldStr.substring(0, fieldStr.length() - 1) +
          ") ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde' STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat' OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat' LOCATION  '" + writeLocation + "'")
        //write the dataframe data to the hdfs location for the created Hive table
        df.repartition(10).write.mode("Overwrite").format("ORC").insertInto(dbName + "." + tableName + "_temporary")
        spark.sql("ALTER TABLE " + dbName + "." + tableName + " SET LOCATION '" + writeLocation + "/'")
        //spark.sql("ALTER TABLE " + dbName + "." + tableName+"_temporary" + " SET LOCATION '" + currLoc + "/'")
        //spark.sql("insert overwrite table "+ dbName + "." + tableName+"_temporary select * from " + dbName + "." + tableName + " limit 0" )
        log.info("Drop table######: "+"drop table if exists " + dbName + "." + tableName + "_temporary")
        spark.sql("drop table if exists " + dbName + "." + tableName + "_temporary")
        /*val fs=FileSystem.get(spark.sparkContext.hadoopConfiguration)
        if(fs.exists(new Path(currLoc)))
          fs.delete(new Path(currLoc),true)*/
        return true
      } else {
        log.info("Cannot do switching while save mode is not overwrite!")
        false
      }

    } catch {
      case e: Exception =>
        e.printStackTrace()
        return false
    }
  }
  
    def paramCheck(param: Seq[String]) {
    val msg = "Arguments [%s] does not match expected value."
    for (i <- 0 until param.size) {
      val arg = param(i)
      if (arg.length <= 0) {
        throw new IllegalArgumentException(msg.format(arg))
      }
    }
  }

  def loadSelectExpr(myCols: Array[String], allCols: Array[String]) = {
    allCols.toList.map(x => x match {
      case x if myCols.contains(x) => col(x)
      case _                       => lit(null).as(x)
    })
  }
  
    def readHistMaxLoadTimestampFact(sqlcon: Connection, objName: String): String = {
    var max_ld_ts: String = null
    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select case when max(btch_id) is null then 'aa_aa_19000101000000' else max(btch_id) end as max_ld_ts from amc.jb_aud_tbl where  dta_lyr_nm='ref_cnsmptn' and lower(jb_stts_cd) = 'success' and obj_nm='" + objName + "'"
      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      //Extact result from ResultSet rs
      while (rs.next()) {
        log.info("max(ld_ts)=" + rs.getString("max_ld_ts"))
        max_ld_ts = rs.getString("max_ld_ts").toString()
        max_ld_ts =  max_ld_ts.reverse.substring(0,14).reverse
      }
      // close ResultSet rs
      rs.close();
    } catch {
      case e: Exception => e.printStackTrace()

    }
    max_ld_ts
  } 
/**
   * isJobAlreadyRunning function checks if any yarn application is already running with same name *
   * @param envPropertiesObject : EnvPropertiesObject containing all connection details
   * @param appName      				: Name of the yarn application to be checked
   * @return Boolean 						: returns true if the an application with same name is already running in yarn
   */
  def isJobAlreadyRunning(envPropertiesObject: EnvPropertiesObject, appName: String, appId: String): Boolean = {
    var isAppAlreadyRunning = false
    try {
      val CONNECTION_TIMEOUT_MS = 20000 // Timeout in millis (20 sec).
      
      val requestConfig = RequestConfig.custom()
        .setConnectionRequestTimeout(CONNECTION_TIMEOUT_MS)
        .setConnectTimeout(CONNECTION_TIMEOUT_MS)
        .setSocketTimeout(CONNECTION_TIMEOUT_MS)
        .setAuthenticationEnabled(true)
        .build()

      /*get active rm */
      var host =envPropertiesObject.getAmbariHost() //"16.229.62.10" //"hnr01n01-i.hpeit.hpecorp.net"
      var port = envPropertiesObject.getAmbariPort().toInt//8443
      var target: HttpHost = new HttpHost(host, port, "https")
      var user = envPropertiesObject.getAmbariUser()//"srvc_nextgen_hitg"
      var pwd = envPropertiesObject.getAmbariPwd()//
      val clusterName =envPropertiesObject.getClusterName()// "EAP-ITG"
      //val appName = "job_ea_sc_serp_prod_mtrl_mstr_wrapper"
      var encoding: String = Base64.getEncoder().encodeToString((user + ":" + pwd).getBytes()) //Base64Encoder.encode(user + ":" + pwd);

      var credsProvider: CredentialsProvider = new BasicCredentialsProvider()
      /*credsProvider.setCredentials(
      new AuthScope(target.getHostName(), target.getPort()),
      new UsernamePasswordCredentials(user, pwd))*/
      //CloseableHttpClient httpclient = HttpClients.custom()

      //HttpClientBuilder.create().build()

      var client: CloseableHttpClient = HttpClientBuilder.create().build()

      var url = "https://" + host + ":" + port + "/api/v1/clusters/" + clusterName + "/host_components?HostRoles/component_name=RESOURCEMANAGER&HostRoles/ha_state=ACTIVE"
      var get = new HttpGet(url)
      get.setHeader(HttpHeaders.AUTHORIZATION, "Basic " + encoding)
      log.info("++++++++++++++Ambari Rest API URL::::::::::::::" + url)

      get.setConfig(requestConfig)

      val responseRm: HttpResponse = client.execute(get)
      val statusRm = responseRm.getStatusLine.getStatusCode
      if (statusRm == 200) {
        val contentRm = responseRm.getEntity.getContent
        val jsonRm: String = EntityUtils.toString(responseRm.getEntity())
        val jobjRm: JsonObject = new JsonParser().parse(jsonRm).getAsJsonObject

        // val items: JsonArray = jobjRm.get("items").getAsJsonArray
        host = jobjRm.get("items").getAsJsonArray.get(0).getAsJsonObject.get("HostRoles").getAsJsonObject.get("host_name").getAsString
        log.info("Active RM: " + host)

        //host = "hnr02n02-i.hpeit.hpecorp.net"
        port = envPropertiesObject.getRmPort().toInt//8090
        //val protocol = "https"
        user = envPropertiesObject.getRmUser()//"srvc_nextgen_hitg"
        
        pwd = envPropertiesObject.getRmPwd()//
        target = new HttpHost(host, port, "https")

        credsProvider = new BasicCredentialsProvider()
        credsProvider.setCredentials(
          new AuthScope(target.getHostName(), target.getPort()),
          new UsernamePasswordCredentials(user, pwd))
        //CloseableHttpClient httpclient = HttpClients.custom()

        //HttpClientBuilder.create().build()

        client = HttpClientBuilder.create().build()

        url = "https://" + host + ":" + port + "/ws/v1/cluster/apps?states=ACCEPTED,RUNNING&user=" + user + "&applicationTypes=SPARK&deSelects=resourceRequests"
        get = new HttpGet(url)

        //Set config to Get
        get.setConfig(requestConfig)

        //post.setEntity(EntityBuilder.create.setText("some text to post to API").build())

        val response: HttpResponse = client.execute(get)
        val status = response.getStatusLine.getStatusCode
        if (status == 200) {
          val content = response.getEntity.getContent
          val json: String = EntityUtils.toString(response.getEntity())
          val jobj: JsonObject = new JsonParser().parse(json).getAsJsonObject

          val apps: JsonObject = jobj.get("apps").getAsJsonObject
          val appsList: JsonArray = apps.get("app").getAsJsonArray

          val it = appsList.iterator();
          while (it.hasNext()) {
            val element: JsonElement = it.next()
            if (appName.equalsIgnoreCase(element.getAsJsonObject().get("name").getAsString()) && !appId.equalsIgnoreCase(element.getAsJsonObject().get("id").getAsString())) {
              isAppAlreadyRunning = true
              log.error(appName + " is already in RUNNING or in ACCEPTED state having application id " + element.getAsJsonObject().get("id").getAsString()+" by "+user)
            }
          }
        } else {
           log.info("Unable to connect to RM Rest service on " + url + " getting " + status + " code")
        }
      } else {
        log.info("Unable to connect to Ambari Rest service on " + url + " getting " + statusRm + " code")
      }
    } catch {
      case sslException: InterruptedException => {
        log.error("Interrupted Exception" + sslException.printStackTrace())
        System.exit(1)
      }
      case nseException: NoSuchElementException => {
        log.error("No Such element found: " + nseException.printStackTrace())
        System.exit(1)
      }
      case connException: ConnectException => {
        log.error("Connection Exception: " + connException.printStackTrace())
        System.exit(1)
      }
      case exception: Exception => {
        log.error("Exception:" + exception.printStackTrace())
        System.exit(1)
      }
    }
    
    return isAppAlreadyRunning

  }
  
  def readRefIntrmdteBatchIdListNew(sqlcon: Connection, objName: String,auditTbl: String): List[String] = {

    var btch_id_list: List[String] = Nil

    try {
      log.info("Reading from Audit table")

      val stmt: Statement = sqlcon.createStatement()
      val auditSQL = "select btch_id from "+auditTbl+" where obj_nm='" + objName + "' and dta_lyr_nm='rw_ref' and lower(jb_stts_cd) ='success' and reverse(substring(reverse(COALESCE(btch_id,'')),1,instr(reverse(COALESCE(btch_id,'')),'_')-1)) > (select reverse(substring(reverse(COALESCE(max(btch_id),'')),1,instr(reverse(COALESCE(max(btch_id),'')),'_')-1)) from "+auditTbl+" where obj_nm='" + objName + "' and dta_lyr_nm='ref_intrmdte' and lower(jb_stts_cd) ='success')"
      //val auditSQL = "select sum(tgt_rec_qty) sum from jb_aud_tbl where dta_lyr_nm='rw_ref' and lower(jb_stts_cd) = 'success' and obj_nm='" + objName + "' group by dta_lyr_nm"

      log.info("===================Print SQL :: " + auditSQL)
      //val preparedStmt = sqlcon.prepareStatement(auditSQL);
      val rs: ResultSet = stmt.executeQuery(auditSQL)
      btch_id_list = getResult(rs)
      //Extact result from ResultSet rs
      /* while (rs.next()) {
        log.info("max(tgt_rec_qty)=" + rs.getArray("btch_id_list"))
        btch_id_list = btch_id_list :: rs.getArray("btch_id_list")
      }*/
      // close ResultSet rs
      rs.close()

    } catch {
      case e: Exception => e.printStackTrace()

    }
    btch_id_list
  }


}
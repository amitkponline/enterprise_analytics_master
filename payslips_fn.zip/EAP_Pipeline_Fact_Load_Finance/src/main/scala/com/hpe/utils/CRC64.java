package main.scala.com.hpe.utils;

import org.apache.hadoop.hive.ql.exec.UDF;

public class CRC64 extends UDF {

	
	private final long POLY64REV = 0xa17870f5d4f51b49L;//0xc96c5795d7870f42L;
//	0xcA17870F5D4F51B49L

	private long[] LOOKUPTABLE;

	private void makeLkpTable(){
		LOOKUPTABLE = new long[0x100];
		for (int i = 0; i < 0x100; i++) {
			long v = i;
			for (int j = 0; j < 8; j++) {
				if ((v & 1) == 1) {
					v = (v >>> 1) ^ POLY64REV;
				} else {
					v = (v >>> 1);
				}
			}
			LOOKUPTABLE[i] = v;
		}
	}

	/**
	 * Calculates the CRC64_ANTI checksum for the given data array.
	 * 
	 * @param data
	 *            data to calculate checksum for
	 * @return checksum value
	 */
	public long checksum(final byte[] data) {
		long sum = 0;
		for (final byte b : data) {
			final int lookupidx = ((int) sum ^ b) & 0xff;
			sum = (sum >>> 8) ^ this.LOOKUPTABLE[lookupidx];
		}
		if(sum<0){
			sum=sum*-1;
		}
		return sum;
	}
	public long checksum(final String data) {
		return checksum(data.getBytes());
		
	}
	public long evaluate(String data){
		data = (data == null?"":data);
		this.makeLkpTable();
		return this.checksum(data);
	}
	
	public long evaluate(Object...data){
		String res = "";
		for(Object c : data){
//			System.out.println(String.valueOf(c));
			res+=String.valueOf(c);
		}
		return this.evaluate(res);
	}
	
	/*public static void main(String[] args){
		CRC64 c64 = new CRC64();
//		System.out.println(c64.evaluate("2|BR10000081|123456789123456789012"));
//		System.out.println(c64.evaluate("2|RU10000035|123456789123456789012"));
//		System.out.println(c64.evaluate(String.valueOf("")));
		//"2|BR10000081","2|RU10000035" 
	}*/
}
